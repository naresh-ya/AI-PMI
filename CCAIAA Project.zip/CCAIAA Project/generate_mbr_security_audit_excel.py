"""
MMIANA Dev Account (986995923613) - Security & Performance Audit Workbook
Generates a multi-sheet Excel report.
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

OUT = r"c:\code\CCAIAA Project\MMIANA_Dev_Security_Audit_986995923613.xlsx"

HEADER_FILL = PatternFill("solid", fgColor="1B2A4A")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11, name="Calibri")
TITLE_FONT = Font(color="1B2A4A", bold=True, size=16, name="Calibri")
SUB_FONT = Font(color="555555", size=10, italic=True, name="Calibri")
CELL_FONT = Font(size=10, name="Calibri")
WRAP = Alignment(wrap_text=True, vertical="top", horizontal="left")
CENTER = Alignment(horizontal="center", vertical="center")
THIN = Side(style="thin", color="D0D0D0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

SEV_FILL = {
    "HIGH": PatternFill("solid", fgColor="F8CBAD"),
    "MEDIUM": PatternFill("solid", fgColor="FFE699"),
    "LOW": PatternFill("solid", fgColor="C6E0B4"),
    "INFO": PatternFill("solid", fgColor="DDEBF7"),
}
STATUS_FILL = {
    "Open": PatternFill("solid", fgColor="F8CBAD"),
    "To Verify": PatternFill("solid", fgColor="FFE699"),
    "No Action": PatternFill("solid", fgColor="C6E0B4"),
}
ALT_FILL = PatternFill("solid", fgColor="F5F7FA")

wb = openpyxl.Workbook()


def style_header_row(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        cell.border = BORDER


def write_sheet(ws, title, subtitle, headers, rows, widths, sev_col=None, status_col=None, row_h=40):
    ws.sheet_view.showGridLines = False
    ws.cell(row=1, column=1, value=title).font = TITLE_FONT
    ws.cell(row=2, column=1, value=subtitle).font = SUB_FONT
    hr = 4
    for i, h in enumerate(headers, 1):
        ws.cell(row=hr, column=i, value=h)
    style_header_row(ws, hr, len(headers))
    r = hr + 1
    for ridx, row in enumerate(rows):
        for i, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=i, value=val)
            cell.font = CELL_FONT
            cell.alignment = WRAP
            cell.border = BORDER
            if ridx % 2 == 1:
                cell.fill = ALT_FILL
        if sev_col:
            sv = ws.cell(row=r, column=sev_col).value
            if sv in SEV_FILL:
                ws.cell(row=r, column=sev_col).fill = SEV_FILL[sv]
                ws.cell(row=r, column=sev_col).alignment = CENTER
                ws.cell(row=r, column=sev_col).font = Font(bold=True, size=10)
        if status_col:
            stv = ws.cell(row=r, column=status_col).value
            if stv in STATUS_FILL:
                ws.cell(row=r, column=status_col).fill = STATUS_FILL[stv]
                ws.cell(row=r, column=status_col).alignment = CENTER
        ws.row_dimensions[r].height = row_h
        r += 1
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = ws.cell(row=hr + 1, column=1)


# ---------- Sheet 1: Overview ----------
ws = wb.active
ws.title = "Overview"
ws.sheet_view.showGridLines = False
ws.cell(row=1, column=1, value="MMIANA Dev Account - Security & Performance Audit").font = TITLE_FONT
ws.cell(row=2, column=1, value="AWS Account: 986995923613 (mmiana-dev / local)  |  Region: eu-west-1").font = SUB_FONT
ws.cell(row=3, column=1, value=f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}  |  Access: tlz_developer (read-only)").font = SUB_FONT
overview = [
    ["Audit Scope", "IAM roles, inline/managed policies, IAM users, access keys for MMIANA application resources (isynesis, mbr-kpi, master-narrative, excel-agent, AgentCore, KB, etc.)."],
    ["Explicitly Excluded", "Centrally-managed landing-zone & security tooling: DEEP-*, tlz_*, deep-*, csr-*, CspmMonitorAws, tenableio-connector, PAN-OS-*, flexnet_*, snow_*, SageMaker service-catalog roles, AWS service-linked roles. DO NOT modify these."],
    ["Account profile", "~145 IAM roles (much busier than ccaiaa-dev). Many short-suffix auto-generated roles (…-role-xxxxxxxx) and numerous test/demo roles."],
    ["Total findings", "5 High, 5 Medium, 4 Low/Info"],
    ["Top risk", "terraform_svc static AdministratorAccess key + MULTIPLE roles carrying AmazonS3FullAccess."],
    ["Key difference vs CCAIAA", "S3FullAccess appears on several roles (LambdaBedrockAccess, lambda-s3-bedrock-role, agent-aws-s3-test-role). Far more orphaned/auto-generated roles to clean up."],
    ["Important caveat", "Most roles are Terraform-managed (terraform_svc). Fix in IaC code, not console, to avoid drift & recreation."],
    ["Sheets", "1) Overview  2) Security Findings  3) IAM Roles Inventory  4) Policies to Fix/Remove  5) IAM Users & Keys  6) Performance Improvements  7) Action Plan"],
]
r = 5
for k, v in overview:
    ws.cell(row=r, column=1, value=k).font = Font(bold=True, size=10, color="1B2A4A")
    c = ws.cell(row=r, column=2, value=v); c.font = CELL_FONT; c.alignment = WRAP
    ws.row_dimensions[r].height = 44
    r += 1
ws.column_dimensions["A"].width = 26
ws.column_dimensions["B"].width = 115


# ---------- Sheet 2: Security Findings ----------
ws2 = wb.create_sheet("Security Findings")
headers = ["ID", "Severity", "Area", "Resource", "Finding", "Risk / Impact", "Recommended Fix", "Status"]
rows = [
    ["H1", "HIGH", "IAM User / Key", "terraform_svc",
     "IAM user with AdministratorAccess + static keys. Active key AKIA...IUZT (2026-10-15). Inactive key AKIA...Q3F (2026-08-25) still present.",
     "Static long-lived admin credential = highest-value target. Inactive key still a latent liability.",
     "Delete inactive key now. Rotate active key. Migrate Terraform to OIDC / assumable role.", "Open"],
    ["H2", "HIGH", "IAM Policy", "LambdaBedrockAccess",
     "Role has AmazonS3FullAccess + custom LambdaBedrock policy.",
     "Full access to all buckets in account; exceeds need.",
     "Replace AmazonS3FullAccess with bucket/prefix-scoped policy for the buckets this lambda actually uses.", "Open"],
    ["H3", "HIGH", "IAM Policy", "lambda-s3-bedrock-role",
     "Role has AmazonS3FullAccess + AWSLambdaBasicExecutionRole.",
     "Full S3 access across the account.",
     "Scope S3 to the specific bucket(s)/prefix(es) used.", "Open"],
    ["H4", "HIGH", "IAM Key", "vault_svc",
     "Access key AKIA...JA6M created 2026-03-27 (~7 months, never rotated). Oldest active key.",
     "Static keys >90 days violate rotation best practice.",
     "Rotate; confirm Vault still needs static key else delete user.", "Open"],
    ["H5", "HIGH", "IAM Policy", "Multiple roles with S3FullAccess",
     "AmazonS3FullAccess appears on several roles (LambdaBedrockAccess, lambda-s3-bedrock-role, agent-aws-s3-test-role and likely others).",
     "Systemic over-permissioning pattern; large aggregate blast radius.",
     "Audit every role for S3FullAccess; replace with scoped bucket policies. Make it a Terraform module standard.", "To Verify"],
    ["M1", "MEDIUM", "IAM Role", "AgentCoreProxyLambdaRole",
     "CloudWatchLogsFullAccess + AgentCoreAccess inline. Last used 2026-05-15 (stale ~6 months).",
     "Over-broad logs access; possibly orphaned (MMIANA app evolved).",
     "Scope CloudWatchLogsFullAccess to own log group; verify role still used else delete.", "To Verify"],
    ["M2", "MEDIUM", "IAM Role", "Test/Demo roles (many)",
     "Numerous test/demo roles: mmiana-unified-test-role, Testcode-role-z9g94wxu, testclaude-role-ncjyyif7, testing-role-hqkprguw, testing_access-role-9p8apg2j, demo-role-cwtpuj18, agent-aws-s3-test-role, codebuild-Test-Varun-service-role.",
     "Abandoned test roles accumulate privileges + audit noise.",
     "Confirm unused -> delete in bulk. Add naming/TTL policy for future test roles.", "To Verify"],
    ["M3", "MEDIUM", "IAM Role", "Orphaned auto-generated roles",
     "Many short-suffix roles (…-role-xxxxxxxx) from repeated deploys: profiler_only-role-* (2), isynesis-insights-generator-role-* (2), mbr-output-indicator-role-* (2), getmonth variants (getmonth/getMoth/getmonth_all/get-current-ui-month).",
     "Duplicate/near-duplicate roles from iterative dev; expand surface.",
     "Consolidate duplicates; delete superseded versions.", "To Verify"],
    ["M4", "MEDIUM", "IAM Role", "AmplifySSRLoggingRole-* (9 roles)",
     "9 Amplify SSR logging roles exist (one per app/branch build).",
     "Accumulation from repeated Amplify app/branch creation.",
     "Map to live Amplify apps/branches; delete those for deleted apps.", "To Verify"],
    ["M5", "MEDIUM", "IAM Key", "bitbucket-amplify-deployer",
     "Only an INACTIVE key (AKIA...4QUL, 2026-05-20) present; no active key.",
     "If Amplify deploy still needed, config may be broken; if not, user is stale.",
     "Verify deploy path. Delete inactive key; delete user if Amplify deploy not used from this account.", "To Verify"],
    ["L1", "INFO", "IAM Policy", "AgentCoreProxyLambdaRole inline (AgentCoreAccess)",
     "Uses a named inline policy rather than FullAccess for AgentCore - reasonable pattern.",
     "Low — review scope of AgentCoreAccess for exact ARNs.",
     "Confirm AgentCoreAccess targets specific runtime/memory ARNs.", "To Verify"],
    ["L2", "LOW", "IAM Role", "SageMaker service-catalog roles",
     "Large set of AmazonSageMakerServiceCatalogProducts* roles present.",
     "Low — created by SageMaker; may be unused if SageMaker isn't active.",
     "If SageMaker not used in MMIANA, remove the SageMaker domain to clean these up.", "To Verify"],
    ["L3", "LOW", "IAM Role", "TurnoffEC2-role-j9m57thq",
     "Utility role to stop EC2 (cost automation).",
     "Low — verify still wired to a schedule/lambda.",
     "Keep if active; delete if the automation was removed.", "To Verify"],
    ["L4", "LOW", "General", "~145 total roles",
     "Very high role count for one app account indicates sprawl.",
     "Operational/audit overhead; harder to reason about least-privilege.",
     "Establish role lifecycle (tagging, TTL, IaC ownership) and periodic cleanup.", "Open"],
]
write_sheet(ws2, "Security Findings", "Prioritized IAM & account findings for the MMIANA application layer.",
            headers, rows, [6, 10, 14, 34, 52, 46, 54, 11], sev_col=2, status_col=8, row_h=70)


# ---------- Sheet 3: IAM Roles Inventory ----------
ws3 = wb.create_sheet("IAM Roles Inventory")
headers = ["Role Name", "Purpose (inferred)", "Last Used", "Policies (observed)", "Over-Privileged?", "Verdict"]
rows = [
    ["AgentCoreProxyLambdaRole", "AgentCore proxy lambda", "2026-05-15 (stale)", "CloudWatchLogsFullAccess, AWSLambdaBasicExecutionRole, inline AgentCoreAccess", "Partial (logs full)", "VERIFY / scope logs"],
    ["AgentCoreRuntimeRole", "AgentCore runtime", "(slow to read)", "(verify)", "Review", "VERIFY"],
    ["LambdaBedrockAccess", "Lambda -> Bedrock", "n/a", "LambdaBedrock, AWSLambdaBasicExecutionRole, AmazonS3FullAccess", "YES - S3 full", "SCOPE S3 (H2)"],
    ["lambda-s3-bedrock-role", "Lambda S3+Bedrock", "n/a", "AWSLambdaBasicExecutionRole, AmazonS3FullAccess", "YES - S3 full", "SCOPE S3 (H3)"],
    ["agent-aws-s3-test-role", "S3 test", "(slow to read)", "(likely S3 full)", "Likely", "VERIFY / DELETE"],
    ["agentcorembr002-role-cxygsh1q", "AgentCore MBR", "n/a", "(auto-generated)", "Review", "VERIFY"],
    ["chunk-document-lambda-role", "Doc chunking", "n/a", "(lambda)", "Review", "KEEP (verify scope)"],
    ["lambda-docx-chunking-role", "DOCX chunking", "n/a", "(lambda)", "Review", "KEEP (verify scope)"],
    ["isynesis-lambda-role / -execution-role / -fargate-role", "iSynesis compute", "n/a", "(lambda/fargate)", "Review", "KEEP (consolidate?)"],
    ["isynesis-insights-generator-role-jh4g0ic9 / -vf626p1y", "iSynesis insights (dup)", "n/a", "(auto-generated x2)", "Review", "CONSOLIDATE"],
    ["iSynesisAgentCoreRole / IsynesisInsightsAgentCoreRole", "iSynesis AgentCore", "n/a", "(agentcore)", "Review", "KEEP (verify)"],
    ["master-narrative-ecs-task-role / -execution-role / lambda-ecs-role", "Master narrative ECS", "n/a", "(ecs)", "Review", "KEEP (verify)"],
    ["mbr-kpi-lambda-role / mbr-kpi-generator-role-t7u41nm9", "MBR KPI", "n/a", "(lambda)", "Review", "KEEP (consolidate)"],
    ["mbr-output-indicator-role-mmhjezfb / -t1g2k0qc", "MBR output indicator (dup)", "n/a", "(auto-generated x2)", "Review", "CONSOLIDATE"],
    ["mbr-secondary-insights-role-gavco6lc", "MBR secondary insights", "n/a", "(lambda)", "Review", "VERIFY"],
    ["excel-agent-lambda-role / excel-agent-profiler-role-sy6c0jsd", "Excel agent", "n/a", "(lambda)", "Review", "VERIFY"],
    ["profiler_only-role-8pyux0xk / -iaeyx7ce", "Profiler (dup)", "n/a", "(auto-generated x2)", "Review", "CONSOLIDATE"],
    ["getmonth-role-* / getMoth-role-* / getmonth_all-role-* / get-current-ui-month-role-*", "Month helper (dup set)", "n/a", "(auto-generated)", "Review", "CONSOLIDATE / DELETE dups"],
    ["AmazonBedrockExecutionRoleForKnowledgeBase_Oct / _zqpy8", "KB execution", "n/a", "(KB service role)", "Review", "KEEP live KB; delete orphan"],
    ["AmazonBedrockExecutionRoleForAgents_AEXQ49DTW4", "Bedrock Agents", "n/a", "(agent service role)", "Review", "VERIFY + DELETE if unused"],
    ["askiron_knowledgebase-role-sg9s0sxm", "AskIron KB", "n/a", "(kb)", "Review", "VERIFY (different product?)"],
    ["AmplifySSRLoggingRole-* (9)", "Amplify SSR logging", "n/a", "(amplify)", "Review", "DELETE for dead apps (M4)"],
    ["mmiana-unified-test-role", "Unified test", "(slow)", "(test)", "Review", "DELETE"],
    ["Testcode-role-z9g94wxu", "Test code", "(slow)", "(test)", "Review", "DELETE"],
    ["testclaude-role-ncjyyif7", "Claude test", "(slow)", "(test)", "Review", "DELETE"],
    ["testing-role-hqkprguw / testing_access-role-9p8apg2j", "Testing", "(slow)", "(test)", "Review", "DELETE"],
    ["demo-role-cwtpuj18", "Demo", "(slow)", "(demo)", "Review", "DELETE"],
    ["codebuild-Test-Varun-service-role", "Personal test CodeBuild", "(slow)", "(codebuild)", "Review", "DELETE"],
    ["TurnoffEC2-role-j9m57thq", "EC2 cost automation", "(slow)", "(lambda)", "Review", "KEEP if active"],
    ["cognito-user-export-role-dk9fv83u", "Cognito export", "n/a", "(lambda)", "Review", "VERIFY"],
    ["langsmith-agent-s3-reader", "LangSmith S3 read", "n/a", "(lambda)", "Review", "KEEP (verify scope)"],
]
write_sheet(ws3, "IAM Roles Inventory (MMIANA application roles)",
            "Baseline landing-zone & SageMaker service-catalog roles excluded - do not modify. 'slow' = IAM read timed out; verify live.",
            headers, rows, [50, 30, 18, 48, 16, 32], row_h=30)


# ---------- Sheet 4: Policies to Fix / Remove ----------
ws4 = wb.create_sheet("Policies to Fix or Remove")
headers = ["Target", "Policy", "Type", "Current Permission", "Problem", "Action", "Replacement / Scoped Policy"]
rows = [
    ["LambdaBedrockAccess", "AmazonS3FullAccess", "AWS Managed", "s3:* on *", "Full access to all buckets", "DETACH + replace",
     "Inline: s3:GetObject,s3:PutObject on the specific bucket/prefix this lambda uses"],
    ["lambda-s3-bedrock-role", "AmazonS3FullAccess", "AWS Managed", "s3:* on *", "Full access to all buckets", "DETACH + replace",
     "Inline: scope to the specific bucket/prefix"],
    ["agent-aws-s3-test-role", "(likely AmazonS3FullAccess)", "AWS Managed", "s3:* on *", "Test role with broad S3", "VERIFY + DELETE role", "n/a - remove test role"],
    ["AgentCoreProxyLambdaRole", "CloudWatchLogsFullAccess", "AWS Managed", "logs:* on *", "Full CloudWatch Logs", "DETACH + replace",
     "logs:CreateLogGroup/Stream,PutLogEvents on this role's own log group ARN only"],
    ["terraform_svc (user)", "AdministratorAccess", "AWS Managed", "* on *", "Full admin on static key", "REVIEW + permissions boundary; migrate to OIDC",
     "Scope to services Terraform manages, or add a permissions boundary"],
    ["(account-wide)", "AmazonS3FullAccess usage", "AWS Managed", "s3:* on *", "Appears on multiple roles", "AUDIT ALL + replace",
     "Standardise a scoped S3 policy module in Terraform"],
    ["(account-wide)", "Customer-managed policies", "Customer Managed", "various", "Likely orphaned/detached", "CLEANUP",
     "Find policies with 0 attachments -> review -> delete"],
]
write_sheet(ws4, "Policies to Fix or Remove",
            "Over-privileged or unused policies. Prefer fixing in Terraform/IaC where applicable.",
            headers, rows, [30, 30, 16, 20, 30, 42, 52], row_h=52)


# ---------- Sheet 5: IAM Users & Keys ----------
ws5 = wb.create_sheet("IAM Users & Keys")
headers = ["User", "Access Key", "Key Status", "Key Created", "Age Concern", "Attached Policy", "Action"]
rows = [
    ["terraform_svc", "AKIA...WMXPIUZT", "Active", "2026-10-15", "Rotate on schedule", "AdministratorAccess, app_account_restrictions", "Rotate + migrate to OIDC"],
    ["terraform_svc", "AKIA...QLBY2Q3F", "Inactive", "2026-08-25", "Disabled but not deleted", "(same user)", "DELETE key now"],
    ["vault_svc", "AKIA...Q2CFJA6M", "Active", "2026-03-27", "~7 months - oldest key", "(verify)", "Rotate; verify still needed"],
    ["bitbucket-amplify-deployer", "AKIA...5IC34QUL", "Inactive", "2026-05-20", "Only an inactive key", "(verify)", "Verify deploy path; delete key/user if unused"],
]
write_sheet(ws5, "IAM Users & Access Keys",
            "Static long-lived credentials. Prefer role-assumption / OIDC over static keys.",
            headers, rows, [28, 22, 12, 14, 24, 42, 34], row_h=32)


# ---------- Sheet 6: Performance Improvements ----------
ws6 = wb.create_sheet("Performance Improvements")
headers = ["ID", "Area", "Observation", "Improvement", "Benefit", "Effort"]
rows = [
    ["P1", "LLM Cost/Perf", "MMIANA is heavy on Claude Sonnet 4 (144M+ input tokens/mo).", "Enable Bedrock prompt caching for repeated prompts.", "50-90% input-token cost reduction; lower latency.", "Low"],
    ["P2", "LLM Routing", "Large models used for all steps incl. simple ones.", "Route classification/formatting to Claude Haiku.", "~10x cheaper for those calls.", "Medium"],
    ["P3", "Role Sprawl", "~145 IAM roles, many auto-generated duplicates.", "Consolidate via Terraform modules; delete superseded roles.", "Simpler audits, smaller surface.", "Medium"],
    ["P4", "Observability", "LangSmith tracing active (16k+ traces/mo in Aug).", "Disable/sample LangSmith in production.", "Removes LangSmith trace cost.", "Low"],
    ["P5", "ECS / Fargate", "master-narrative & isynesis run ECS/Fargate.", "Right-size task CPU/memory; use Fargate Spot for non-critical.", "Compute cost reduction.", "Medium"],
    ["P6", "Lambda", "Many lambdas; verify memory sizing & VPC need.", "Right-size memory; remove unneeded VPC attachment.", "Lower cost + cold-start latency.", "Medium"],
    ["P7", "S3", "Document/output storage likely unbounded.", "Add S3 lifecycle rules (IA transition / expiry).", "Storage cost reduction.", "Low"],
    ["P8", "SageMaker", "SageMaker domain + many service-catalog roles present.", "If SageMaker unused, delete domain to stop fixed cost.", "Removes idle SageMaker cost.", "Low"],
    ["P9", "EC2", "TurnoffEC2 automation role exists.", "Confirm EC2 stop schedule is active; extend to all non-prod EC2.", "Off-hours compute savings.", "Low"],
    ["P10", "Amplify", "9 Amplify SSR logging roles => multiple apps/branches.", "Delete unused Amplify apps/branches.", "Lower Amplify + log cost.", "Low"],
    ["P11", "Supply Chain", "Pin dependency versions & image digests.", "Pin exact versions (per LiteLLM incident guidance).", "Reproducible, safer builds.", "Low"],
]
write_sheet(ws6, "Performance & Cost Improvements",
            "Application and infrastructure efficiency opportunities for MMIANA.",
            headers, rows, [6, 18, 46, 48, 38, 10], row_h=42)


# ---------- Sheet 7: Action Plan ----------
ws7 = wb.create_sheet("Action Plan")
headers = ["Priority", "Task", "Related ID", "Owner", "Pre-req / Caution", "Status"]
rows = [
    ["1 - Now", "Delete terraform_svc inactive access key", "H1", "Platform/DevOps", "Confirm not referenced", "Open"],
    ["1 - Now", "Rotate terraform_svc + vault_svc keys", "H1,H4", "Platform/DevOps", "Update Vault/consumers with new keys", "Open"],
    ["1 - Now", "Replace AmazonS3FullAccess on LambdaBedrockAccess", "H2", "App team", "Test after change; fix in Terraform if IaC", "Open"],
    ["1 - Now", "Replace AmazonS3FullAccess on lambda-s3-bedrock-role", "H3", "App team", "Test after change", "Open"],
    ["1 - Now", "Account-wide audit of S3FullAccess usage", "H5", "App team", "Enumerate all roles; standardise scoped policy", "To Verify"],
    ["2 - Soon", "Scope/verify AgentCoreProxyLambdaRole (logs full, stale)", "M1", "App team", "Confirm still used", "To Verify"],
    ["2 - Soon", "Delete test/demo roles in bulk", "M2", "App team", "Confirm no live resource uses them", "To Verify"],
    ["2 - Soon", "Consolidate duplicate auto-generated roles", "M3", "App team", "Map each to live resource first", "To Verify"],
    ["2 - Soon", "Delete Amplify SSR logging roles for dead apps", "M4", "Platform/DevOps", "Map to live Amplify apps", "To Verify"],
    ["2 - Soon", "Resolve bitbucket-amplify-deployer (inactive-only key)", "M5", "Platform/DevOps", "Confirm deploy path", "To Verify"],
    ["3 - Hygiene", "Remove SageMaker domain/roles if unused", "L2,P8", "Platform/DevOps", "Confirm SageMaker not used", "To Verify"],
    ["3 - Hygiene", "Establish role lifecycle (tagging/TTL/IaC ownership)", "L4,P3", "Platform/DevOps", "Governance change", "Open"],
    ["3 - Hygiene", "Migrate static service keys to OIDC/roles", "H1,H4", "Platform/DevOps", "Design + test OIDC", "Open"],
    ["Perf-1", "Enable Bedrock prompt caching", "P1", "App team", "Validate compatibility", "Open"],
    ["Perf-2", "Disable/sample LangSmith in production", "P4", "App team", "Keep in dev/debug only", "Open"],
    ["Perf-3", "Right-size ECS/Fargate + Lambda", "P5,P6", "App team", "Review utilization metrics", "Open"],
    ["Perf-4", "Add S3 lifecycle rules", "P7", "App team", "Agree retention with business", "Open"],
]
write_sheet(ws7, "Action Plan",
            "Prioritized tasks. '1-Now' = security risk; '2-Soon' = least-privilege cleanup; 'Perf' = efficiency.",
            headers, rows, [12, 56, 14, 18, 40, 11], status_col=6, row_h=34)

wb.save(OUT)
print(f"Saved: {OUT}")
print(f"Sheets: {wb.sheetnames}")
