#!/bin/bash

set -e

echo "Starting buildscript_lambda.sh"
echo "Current directory:"
pwd

echo "Listing current directory:"
ls -la

AWS_REGION="${AWS_REGION:-eu-west-1}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-603433800649}"
ECR_REPOSITORY_NAME="${ECR_REPOSITORY_NAME:-ca-lambda-workbench}"
IMAGE_TAG="${IMAGE_TAG:-lambda-latest}"

REPOSITORY_URI="$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ECR_REPOSITORY_NAME"

echo "AWS Region: $AWS_REGION"
echo "AWS Account ID: $AWS_ACCOUNT_ID"
echo "ECR Repository Name: $ECR_REPOSITORY_NAME"
echo "Repository URI: $REPOSITORY_URI"
echo "Image Tag: $IMAGE_TAG"

echo "Moving to Proxy_lambda build context"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROXY_LAMBDA_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROXY_LAMBDA_DIR"

echo "Proxy Lambda directory:"
pwd

echo "Listing Proxy_lambda files:"
ls -la

echo "Listing docker_build files:"
ls -la docker_build

echo "Listing lambda_scripts files:"
ls -la lambda_scripts

echo "Checking or creating ECR repository: $ECR_REPOSITORY_NAME"

aws ecr describe-repositories \
  --repository-names "$ECR_REPOSITORY_NAME" \
  --region "$AWS_REGION" >/dev/null 2>&1 || \
aws ecr create-repository \
  --repository-name "$ECR_REPOSITORY_NAME" \
  --region "$AWS_REGION"

echo "Logging in to Amazon ECR"

aws ecr get-login-password --region "$AWS_REGION" | \
docker login --username AWS --password-stdin "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"

echo "Setting up Docker buildx"

docker buildx create --name lambdaBuilder --use || docker buildx use lambdaBuilder

docker buildx inspect --bootstrap

echo "Starting Lambda Docker image build"

docker buildx build \
  --platform linux/amd64 \
  --provenance=false \
  -f docker_build/Dockerfile.lambda \
  -t "$REPOSITORY_URI:$IMAGE_TAG" \
  --push \
  .

echo "Lambda Docker image built and pushed successfully"
echo "Final image URI: $REPOSITORY_URI:$IMAGE_TAG"

echo "buildscript_lambda.sh completed successfully"