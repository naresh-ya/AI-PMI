import boto3
import json
import uuid
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

AWS_REGION = "eu-west-1"

AGENT_RUNTIME_ARN = (
    "arn:aws:bedrock-agentcore:eu-west-1:603433800649:"
    "runtime/caWorkbenchAgentcore-vrKjOJ5qFA"
)

agentcore_client = boto3.client("bedrock-agentcore", region_name=AWS_REGION)


def trigger_agentcore_runtime_async(
    query: str,
    session_id: str,
    actor_id: str,
    namespace: str,
    job_id: str,
    conversation_id: str,
    user_message_id: str,
    assistant_message_id: str
) -> None:
    payload = {
        "prompt": query,
        "session_id": session_id,
        "user_id": actor_id,

        "input": query,
        "sessionId": session_id,
        "userId": actor_id,

        "actorId": actor_id,
        "namespace": namespace,
        "memory_namespace": namespace,
        "memory_session_id": session_id,

        "job_id": job_id,
        "conversation_id": conversation_id,
        "user_message_id": user_message_id,
        "assistant_message_id": assistant_message_id
    }

    logger.info(f"Triggering AgentCore Runtime directly for job: {job_id}")

    response = agentcore_client.invoke_agent_runtime(
        agentRuntimeArn=AGENT_RUNTIME_ARN,
        runtimeSessionId=session_id,
        payload=json.dumps(payload).encode("utf-8"),
        contentType="application/json",
        accept="application/json",
        traceId=f"Root=1-{uuid.uuid4().hex[:8]}-{uuid.uuid4().hex[:24]}"
    )

    logger.info(f"AgentCore direct runtime trigger accepted for job: {job_id}")
    logger.info(f"AgentCore response contentType: {response.get('contentType')}")