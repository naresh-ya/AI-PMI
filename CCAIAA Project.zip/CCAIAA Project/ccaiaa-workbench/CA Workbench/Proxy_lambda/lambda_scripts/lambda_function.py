"""
CA Workbench Chat API - Main Lambda Handler
Routes requests to appropriate handlers
"""

import json
import logging
from typing import Dict, Any, Optional
import os

# Import route handlers
from route_handlers import (
    list_conversations_handler,
    create_conversation_handler,
    get_conversation_handler,
    update_conversation_handler,
    delete_conversation_handler,
    get_messages_handler,
    send_message_handler,
    get_job_status_handler,
)

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_int_env(name: str, default: int) -> int:
    """
    Safely read integer environment variable.
    """
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid integer value for {name}. Using default: {default}")
        return default

def lambda_handler(event, context):
    """
    Main Lambda handler - routes requests to appropriate handlers
    
    Supports two invocation types:
    1. API Gateway (HTTP requests)
    2. Direct invocation (async job processing)
    """
    logger.info(f"Lambda invoked with event: {json.dumps(event)}")
    
    # Otherwise, handle as API Gateway request
    try:
        # Parse request
        method = event.get('httpMethod', 'GET')
        path = event.get('path', '/')
        body = json.loads(event.get('body', '{}')) if event.get('body') else {}
        query_params = event.get('queryStringParameters') or {}

        # Handle OPTIONS before auth check
        if method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-User-Id',
                    'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS'
                },
                'body': ''
            }

        # Extract user_id from request context
        user_id = extract_user_id(event, body, query_params)

        if not user_id:
            return {
                'statusCode': 401,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-User-Id',
                    'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Unauthorized',
                    'message': 'Missing user identity'
                })
            }
        
        logger.info(f"Request: {method} {path} from user: {user_id}")
        
        # Route to appropriate handler
        response = route_request(method, path, user_id, body, query_params)
        
        # Add CORS headers
        response['headers'] = response.get('headers', {})
        response['headers'].update({
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-User-Id',
            'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS'
        })
        
        return response
        
    except Exception as e:
        logger.error(f"Error handling request: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }


def extract_user_id(
    event: Dict[str, Any],
    body: Dict[str, Any] = None,
    query_params: Dict[str, Any] = None
) -> Optional[str]:
    """
    Extract user_id from request context.

    Priority:
    1. Cognito authorizer claims
    2. Custom authorizer context
    3. Header X-User-Id
    4. Query parameter user_id
    5. JSON body user_id
    6. Return Non* if no user identity is found
    """

    body = body or {}
    query_params = query_params or {}

    # 1. Try Cognito authorizer claims
    try:
        claims = event.get('requestContext', {}).get('authorizer', {}).get('claims', {})
        user_id = claims.get('sub') or claims.get('cognito:username') or claims.get('email')
        if user_id:
            return user_id
    except Exception:
        pass

    # 2. Try custom authorizer context
    try:
        authorizer = event.get('requestContext', {}).get('authorizer', {})
        user_id = authorizer.get('user_id') or authorizer.get('principalId')
        if user_id:
            return user_id
    except Exception:
        pass

    # 3. Try headers, case-insensitive
    try:
        headers = event.get('headers') or {}
        headers_lower = {
            str(k).lower(): v
            for k, v in headers.items()
            if k is not None
        }

        user_id = (
            headers.get('X-User-Id')
            or headers.get('x-user-id')
            or headers_lower.get('x-user-id')
        )

        if user_id:
            return user_id
    except Exception:
        pass

    # 4. Try query string parameter, useful for GET requests
    try:
        user_id = (
            query_params.get('user_id')
            or query_params.get('userId')
            or query_params.get('user')
        )

        if user_id:
            return user_id
    except Exception:
        pass

    # 5. Try JSON body, useful for POST requests
    try:
        user_id = (
            body.get('user_id')
            or body.get('userId')
            or body.get('user')
        )

        if user_id:
            return user_id
    except Exception:
        pass

    
    # 6. No user identity found
    logger.warning("No user_id found in request")
    return None



def route_request(
    method: str,
    path: str,
    user_id: str,
    body: Dict[str, Any],
    query_params: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Route request to appropriate handler based on method and path
    """
    # Parse path segments
    segments = [s for s in path.split('/') if s]
    
    # Route: /conversations
    if len(segments) == 1 and segments[0] == 'conversations':
        if method == 'GET':
            return list_conversations_handler(user_id, query_params)
        elif method == 'POST':
            return create_conversation_handler(user_id, body)
    
    # Route: /conversations/{conversation_id}
    elif len(segments) == 2 and segments[0] == 'conversations':
        conversation_id = segments[1]
        
        if method == 'GET':
            return get_conversation_handler(user_id, conversation_id)
        elif method == 'PATCH':
            return update_conversation_handler(user_id, conversation_id, body)
        elif method == 'DELETE':
            return delete_conversation_handler(user_id, conversation_id)
    
    # Route: /conversations/{conversation_id}/messages
    elif len(segments) == 3 and segments[0] == 'conversations' and segments[2] == 'messages':
        conversation_id = segments[1]
        
        if method == 'GET':
            return get_messages_handler(user_id, conversation_id, query_params)
    
    # Route: /messages
    elif len(segments) == 1 and segments[0] == 'messages':
        if method == 'POST':
            return send_message_handler(user_id, body)
    
    
    # Route: /jobs/{job_id}
    elif len(segments) == 2 and segments[0] == 'jobs':
        job_id = segments[1]
        
        if method == 'GET':
            return get_job_status_handler(user_id, job_id)

    # Route: / (health check)
    elif len(segments) == 0 or (len(segments) == 1 and segments[0] == ''):
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'status': 'healthy',
                'service': 'CA Workbench Chat API',
                'version': '2.0.0'
            })
        }
    
    # Not found
    return {
        'statusCode': 404,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps({
            'error': 'Not found',
            'path': path,
            'method': method
        })
    }


# For local testing
if __name__ == "__main__":
    # Test event
    test_event = {
        'httpMethod': 'GET',
        'path': '/',
        'headers': {
            'X-User-Id': 'test-user-123'
        },
        'queryStringParameters': None,
        'body': None
    }
    
    result = lambda_handler(test_event, None)
    print(json.dumps(result, indent=2))
