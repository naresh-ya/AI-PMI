"""
Route Handlers for CA Workbench Chat API
Handles all API endpoint logic
"""

import json
import uuid
import boto3
from decimal import Decimal
from datetime import datetime, timezone
from typing import Dict, Any, Optional
import logging

# Import helper modules
from db_helpers import (
    create_conversation, get_conversation, list_conversations,
    update_conversation, delete_conversation,
    create_message, get_messages, update_message,
    create_job, get_job, update_job_status,
    save_message_content_to_s3, load_message_content_from_s3
)

from agentcore_client import trigger_agentcore_runtime_async

logger = logging.getLogger()
logger.setLevel(logging.INFO)

AGENT_RUNTIME_ARN = 'arn:aws:bedrock-agentcore:eu-west-1:603433800649:runtime/caWorkbenchAgentcore-vrKjOJ5qFA'

def decimal_default(obj):
    """
    Convert DynamoDB Decimal values into JSON-safe values.
    DynamoDB returns all numbers as Decimal, which json.dumps cannot serialize directly.
    """
    if isinstance(obj, Decimal):
        if obj % 1 == 0:
            return int(obj)
        return float(obj)

    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def api_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Standard API Gateway response helper.
    Handles DynamoDB Decimal serialization and CORS headers.
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-User-Id',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
        },
        'body': json.dumps(body, default=decimal_default)
    }

def is_conversation_unavailable(conversation: Optional[Dict[str, Any]]) -> bool:
    """
    Return True if conversation does not exist or is soft-deleted.
    """
    return not conversation or conversation.get("is_deleted") is True

def generate_conversation_title(message: str, max_length: int = 60) -> str:
    """
    Generate a simple chat title from the first user message.

    This is deterministic and does not require an LLM call.
    """
    title = " ".join(str(message or "").strip().split())

    if not title:
        return "New Chat"

    if len(title) <= max_length:
        return title

    return title[:max_length].rstrip() + "..."

# ============================================================================
# CONVERSATION HANDLERS
# ============================================================================

def list_conversations_handler(user_id: str, query_params: Dict[str, Any]) -> Dict[str, Any]:
    """
    List all conversations for a user
    GET /conversations
    """
    try:
        logger.info(f"Listing conversations for user: {user_id}")
        
        limit = int(query_params.get('limit', 30))
        conversations = list_conversations(user_id, limit=limit)
        
        return api_response(200, {
            'conversations': conversations,
            'count': len(conversations)
        })
        
    except Exception as e:
        logger.error(f"Error listing conversations: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


def create_conversation_handler(user_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create a new conversation
    POST /conversations
    Body: {"title": "My Conversation"}
    """
    try:
        logger.info(f"Creating conversation for user: {user_id}")
        
        title = body.get('title', 'New Chat')
        conversation_id = f"conv-{uuid.uuid4()}"
        
        conversation = create_conversation(user_id, conversation_id, title)
        
        return api_response(201, conversation)
        
    except Exception as e:
        logger.error(f"Error creating conversation: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


def get_conversation_handler(user_id: str, conversation_id: str) -> Dict[str, Any]:
    """
    Get a specific conversation
    GET /conversations/{conversation_id}
    """
    try:
        logger.info(f"Getting conversation: {conversation_id} for user: {user_id}")
        
        conversation = get_conversation(user_id, conversation_id)
        if is_conversation_unavailable(conversation):
                    return api_response(404, {'error': 'Conversation not found'})

        return api_response(200, conversation)

    except Exception as e:
            logger.error(f"Error getting conversation: {str(e)}")
            return api_response(500, {'error': str(e)})



def update_conversation_handler(user_id: str, conversation_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Update a conversation
    PATCH /conversations/{conversation_id}
    Body: {"title": "Updated Title"}
    """
    try:
        logger.info(f"Updating conversation: {conversation_id} for user: {user_id}")
        
        existing = get_conversation(user_id, conversation_id)
        if is_conversation_unavailable(existing):
            return api_response(404, {'error': 'Conversation not found'})
        
        # Update conversation
        updated = update_conversation(user_id, conversation_id, **body)
        
        return api_response(200, updated)
    
    except Exception as e:
            logger.error(f"Error updating conversation: {str(e)}")
            return api_response(500, {'error': str(e)})
   
    
def delete_conversation_handler(user_id: str, conversation_id: str) -> Dict[str, Any]:
    """
    Delete a conversation (soft delete)
    DELETE /conversations/{conversation_id}
    """
    try:
        logger.info(f"Deleting conversation: {conversation_id} for user: {user_id}")
        
        # Verify conversation exists and belongs to user
        existing = get_conversation(user_id, conversation_id)
        if is_conversation_unavailable(existing):
            return api_response(404, {'error': 'Conversation not found'})
        
        # Soft delete
        delete_conversation(user_id, conversation_id)
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'message': 'Conversation deleted successfully'})
        }
        
    except Exception as e:
        logger.error(f"Error deleting conversation: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


# ============================================================================
# MESSAGE HANDLERS
# ============================================================================

def get_messages_handler(user_id: str, conversation_id: str, query_params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get all messages in a conversation
    GET /conversations/{conversation_id}/messages
    """
    try:
        logger.info(f"Getting messages for conversation: {conversation_id}")
        logger.info(f"Messages query params: {query_params}")
        
        # Verify conversation exists, belongs to user, and is not deleted
        conversation = get_conversation(user_id, conversation_id)
        if is_conversation_unavailable(conversation):
                    return api_response(404, {'error': 'Conversation not found'})

        
        
        logger.info(f"Messages query params: {query_params}")

        limit = int(query_params.get('limit', 50))
        logger.info(f"Messages limit resolved to: {limit}")

        messages = get_messages(conversation_id, limit=limit)

        # Hydrate full content from S3 for user and assistant messages
        for message in messages:
            if message.get("content_storage") == "S3":
                try:
                    full_content = load_message_content_from_s3(
                        s3_bucket=message["content_s3_bucket"],
                        s3_key=message["content_s3_key"]
                    )

                    message["content"] = full_content

                except Exception as e:
                    logger.error(
                        f"Failed to load message content from S3: "
                        f"conversation_id={conversation_id}, "
                        f"message_id={message.get('message_id')}, "
                        f"error={str(e)}"
                    )

                    # Fallback to preview if S3 load fails
                    message["content"] = message.get("content_preview", "")

        return api_response(200, {
            'messages': messages,
            'count': len(messages),
            'conversation_id': conversation_id
        })
        
    except Exception as e:
        logger.error(f"Error getting messages: {str(e)}")
        return api_response(500, {'error': str(e)})


def send_message_handler(user_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Send a message (async processing)
    POST /messages
    Body: {
        "conversation_id": "conv-123",
        "message": "What are tobacco regulations in Thailand?"
    }
    
    Returns immediately with job_id for status polling
    """
    try:
        logger.info(f"Sending message for user: {user_id}")
        
        # Validate input
        conversation_id = body.get('conversation_id')
        query = body.get('message')
        
        if not conversation_id or not query:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'error': 'conversation_id and message are required'})
            }
        
        # Verify conversation exists, belongs to user, and is not deleted
        conversation = get_conversation(user_id, conversation_id)
        if is_conversation_unavailable(conversation):
            return api_response(404, {'error': 'Conversation not found'})

        
        # Auto-title a new conversation from the first user message.
        # This keeps "New Chat" only as a temporary placeholder.
        try:
            current_title = conversation.get("title", "New Chat")
            current_message_count = int(conversation.get("message_count", 0))

            if current_message_count == 0 and current_title == "New Chat":
                auto_title = generate_conversation_title(query)

                update_conversation(
                    user_id=user_id,
                    conversation_id=conversation_id,
                    title=auto_title
                )

                logger.info(
                    f"Auto-updated conversation title: conversation_id={conversation_id}, title={auto_title}"
                )

        except Exception as e:
            # Title generation failure should not block message processing.
            logger.warning(f"Failed to auto-update conversation title: {str(e)}")

        # Generate IDs
        user_message_id = f"msg-{uuid.uuid4().hex[:8]}"
        assistant_message_id = f"msg-{uuid.uuid4().hex[:8]}"
        job_id = f"job-{uuid.uuid4().hex[:8]}"
        
        # Store full user message content in S3
        user_content_metadata = save_message_content_to_s3(
            user_id=user_id,
            conversation_id=conversation_id,
            message_id=user_message_id,
            role='user',
            content=query
        )

        # Create user message with preview + S3 pointer in DynamoDB
        user_message = create_message(
            conversation_id=conversation_id,
            message_id=user_message_id,
            user_id=user_id,
            role='user',
            content=user_content_metadata["content_preview"],
            status='COMPLETED',
            **user_content_metadata
        )

        # Create assistant message placeholder
        assistant_message = create_message(
            conversation_id=conversation_id,
            message_id=assistant_message_id,
            user_id=user_id,
            role='assistant',
            content='',
            status='PENDING',
            job_id=job_id
        )
        
        job = create_job(
            job_id=job_id,
            user_id=user_id,
            conversation_id=conversation_id,
            user_message_id=user_message_id,
            assistant_message_id=assistant_message_id,
            query=user_content_metadata["content_preview"],
            agent_runtime_arn=AGENT_RUNTIME_ARN,
            query_storage="S3",
            query_s3_bucket=user_content_metadata["content_s3_bucket"],
            query_s3_key=user_content_metadata["content_s3_key"],
            query_length=user_content_metadata["content_length"],
            query_truncated=user_content_metadata["content_truncated"]
        )
        
        # Trigger AgentCore Runtime.
        # AgentCore Runtime will update DynamoDB directly using job_id.
        try:
            trigger_agentcore_runtime_async(
                query=query,
                session_id=conversation_id,
                actor_id=user_id,
                namespace=f"/users/{user_id}/",
                job_id=job_id,
                conversation_id=conversation_id,
                user_message_id=user_message_id,
                assistant_message_id=assistant_message_id
            )

            logger.info(f"AgentCore runtime trigger accepted for job: {job_id}")

        except Exception as e:
            logger.error(f"Failed to trigger AgentCore runtime for job {job_id}: {str(e)}")

            user_safe_error_message = (
                "I'm sorry, something went wrong while processing your request. "
                "Please try again."
            )

            update_job_status(
                job_id,
                'FAILED',
                error_message="Processing failed"
            )

            update_message(
                conversation_id=conversation_id,
                message_sort_key=assistant_message['message_sort_key'],
                content=user_safe_error_message,
                status='FAILED'
            )
            
            return api_response(500, {
                'job_id': job_id,
                'conversation_id': conversation_id,
                'user_message_id': user_message_id,
                'assistant_message_id': assistant_message_id,
                'status': 'FAILED',
                'error_message': 'Processing failed'
            })

        
        # Return immediately with job info
        return {
            'statusCode': 202,  # Accepted
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'job_id': job_id,
                'conversation_id': conversation_id,
                'user_message_id': user_message_id,
                'assistant_message_id': assistant_message_id,
                'status': 'PENDING',
                'message': 'Message processing started. Poll /jobs/{job_id} for status.'
            })
        }
        
    except Exception as e:
        logger.error(f"Error sending message: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


# ============================================================================
# JOB HANDLERS
# ============================================================================

def get_job_status_handler(user_id: str, job_id: str) -> Dict[str, Any]:
    """
    Get job status
    GET /jobs/{job_id}

    Security:
    Only the user who owns the job can retrieve it.
    """
    try:
        logger.info(f"Getting job status: {job_id} for user: {user_id}")

        job = get_job(job_id)

        if not job:
            return api_response(404, {'error': 'Job not found'})

        # Security check: prevent cross-user job access
        if job.get('user_id') != user_id:
            logger.warning(
                f"Forbidden job access attempt: job_id={job_id}, "
                f"job_owner={job.get('user_id')}, request_user={user_id}"
            )
            return api_response(403, {'error': 'Forbidden'})

        # If job is completed or failed, include the assistant message
        response_data = dict(job)
        if job.get('status') in ['COMPLETED', 'FAILED']:
            messages = get_messages(job['conversation_id'], limit=100)
            assistant_message = next(
                (m for m in messages if m['message_id'] == job['assistant_message_id']),
                None
            )

            if assistant_message:
                # Hydrate full assistant content from S3 if available
                if assistant_message.get("content_storage") == "S3":
                    try:
                        full_content = load_message_content_from_s3(
                            s3_bucket=assistant_message["content_s3_bucket"],
                            s3_key=assistant_message["content_s3_key"]
                        )

                        assistant_message["content"] = full_content

                    except Exception as e:
                        logger.error(
                            f"Failed to load assistant message content from S3: "
                            f"job_id={job_id}, message_id={assistant_message.get('message_id')}, error={str(e)}"
                        )

                        # Fallback to preview if S3 load fails
                        assistant_message["content"] = assistant_message.get("content_preview", "")

                response_data['assistant_message'] = assistant_message
            
        return api_response(200, response_data)

    except Exception as e:
        logger.error(f"Error getting job status: {str(e)}")
        return api_response(500, {'error': str(e)})
