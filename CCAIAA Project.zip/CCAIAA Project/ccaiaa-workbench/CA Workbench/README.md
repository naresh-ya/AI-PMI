# CA Workbench

CA Workbench is a standalone conversational agent application designed to support an agentic framework using LangGraph and LangChain. The application is intended to run as a containerized workload and will later be deployed using AWS AgentCore Runtime.

This repository contains the initial Docker-based build setup required to package the application, build a Docker image through AWS CodeBuild, and push the image to Amazon Elastic Container Registry, Amazon ECR.

## Purpose

The purpose of this application is to provide a conversational interaction chatbot that can be extended into a full agentic framework.

The planned architecture will use:

- LangGraph for agent workflow orchestration
- LangChain for LLM integration and tool chaining
- AWS AgentCore Runtime for hosting and running the agentic application
- Agent memory for maintaining contextual and conversational state
- Docker for packaging the application runtime
- AWS CodeBuild for automated image build execution
- Amazon ECR for storing Docker images

## Current Scope

This is the first stage of the setup.

The current implementation focuses only on:

1. Creating a basic project structure
2. Creating a test FastAPI application
3. Creating a Docker image definition
4. Creating a CodeBuild build entry point
5. Creating a shell script to build and push the Docker image
6. Preparing the image for storage in Amazon ECR

AgentCore Runtime deployment, memory integration, LangGraph workflow logic, and production chatbot capabilities will be added in later stages.

## Repository Structure

```text
CA Workbench/
+-- app/
�   +-- main.py
+-- Dockerfile
+-- requirements.txt
+-- buildspec.yml
+-- buildscript.sh
+-- .dockerignore
+-- README.md
```

## File Details

### app/main.py

Contains a basic FastAPI application with test endpoints.

Current endpoints:

```text
GET /
GET /test
```

These endpoints are used only to validate that the Docker container is running successfully.

### Dockerfile

Defines the Docker image for the application.

Current responsibilities:

- Uses Python 3.11 slim base image
- Sets the working directory
- Installs Python dependencies
- Copies application source code
- Exposes port 8080
- Starts the FastAPI application using Uvicorn

### requirements.txt

Contains Python dependencies required for the current test application and future agentic framework setup.

Current dependencies include:

- FastAPI
- Uvicorn
- LangChain
- LangGraph

### buildspec.yml

AWS CodeBuild entry point.

Current responsibilities:

- Changes directory to CA Workbench
- Gives execution permission to buildscript.sh
- Runs buildscript.sh

CodeBuild should use this buildspec path:

```text
CA Workbench/buildspec.yml
```

### buildscript.sh

Main build execution script.

Current responsibilities:

- Logs build context details
- Logs in to Amazon ECR
- Builds the Docker image
- Tags the image as latest
- Pushes the image to Amazon ECR

Current ECR target:

```text
603433800649.dkr.ecr.eu-west-1.amazonaws.com/ca-workbench:latest
```

### .dockerignore

Excludes unnecessary files from the Docker build context.

This helps keep the Docker image build clean and lightweight.

## Current ECR Repository

```text
Repository name: ca-workbench
AWS Account ID: 603433800649
AWS Region: eu-west-1
Repository URI: 603433800649.dkr.ecr.eu-west-1.amazonaws.com/ca-workbench
Image tag: latest
```

## Current Build Flow

```text
CodeBuild starts
    ?
CodeBuild runs CA Workbench/buildspec.yml
    ?
buildspec.yml enters CA Workbench folder
    ?
buildspec.yml runs buildscript.sh
    ?
buildscript.sh logs in to Amazon ECR
    ?
Docker image is built using Dockerfile
    ?
Docker image is pushed to Amazon ECR
```

## Planned Future Flow

```text
Developer pushes code to Bitbucket
    ?
AWS CodeBuild clones repository
    ?
Docker image is built
    ?
Docker image is pushed to Amazon ECR
    ?
AWS AgentCore Runtime uses the ECR image
    ?
Conversational agent application runs as a managed runtime
```

## Future Enhancements

The following capabilities will be added in later stages:

- LangGraph-based agent workflow
- LangChain tool integration
- Agent memory support
- Conversational state management
- Runtime configuration using environment variables
- Secrets integration using AWS Secrets Manager or Parameter Store
- AgentCore Runtime deployment
- Production image tagging strategy using commit IDs
- Automated build triggers from Bitbucket
- Health check and observability improvements

## Notes

This repository is currently in the initial infrastructure setup phase.

The current application is a test container only. It is not yet the final production chatbot or final AgentCore Runtime implementation.

The immediate objective is to validate the Docker build and ECR push process through AWS CodeBuild.
