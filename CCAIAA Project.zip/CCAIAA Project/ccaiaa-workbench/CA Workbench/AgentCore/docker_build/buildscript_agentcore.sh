#!/bin/bash

set -e

echo "Starting buildscript_agentcore.sh for ARM64"
echo "Current directory:"
pwd

echo "Listing files:"
ls -la

AWS_REGION="eu-west-1"
AWS_ACCOUNT_ID="603433800649"
ECR_REPOSITORY_NAME="ca-workbench"

REPOSITORY_URI="$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ECR_REPOSITORY_NAME"

IMAGE_TAG="agentcore-latest"

echo "AWS Region: $AWS_REGION"
echo "AWS Account ID: $AWS_ACCOUNT_ID"
echo "ECR Repository Name: $ECR_REPOSITORY_NAME"
echo "Repository URI: $REPOSITORY_URI"
echo "Image Tag: $IMAGE_TAG"

echo "Logging in to Amazon ECR"

aws ecr get-login-password --region "$AWS_REGION" | docker login --username AWS --password-stdin "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"

echo "Setting up Docker buildx for ARM64"

# Create buildx builder if it doesn't exist
docker buildx create --name arm64builder --use || docker buildx use arm64builder

# Inspect builder
docker buildx inspect --bootstrap

echo "Starting ARM64 Docker image build"

# Build for ARM64 platform (required by Agent Core Runtime)
# Build from parent directory (AgentCore) to access both folders
cd ..
docker buildx build \
  --platform linux/arm64 \
  -f docker_build/Dockerfile.agentcore \
  -t "$REPOSITORY_URI:$IMAGE_TAG" \
  --push \
  .

echo "ARM64 Docker image built and pushed successfully"

echo "Final image URI: $REPOSITORY_URI:$IMAGE_TAG"

echo "buildscript_agentcore.sh completed successfully"
