"""
Gemini Web Search client - Fallback for Tavily search failures
Uses Gemini's native google_search grounding tool via private LiteLLM gateway
"""
import os
import json
import urllib.request
import ssl
from typing import Dict, Any, List


def gemini_web_search(query: str, max_results: int = 5) -> Dict[str, Any]:
    """
    Execute a web search using Gemini's google_search grounding tool
    Routes through private LiteLLM gateway (matches Lambda configuration)
    
    Args:
        query: Search query
        max_results: Maximum number of results to return (default: 5)
        
    Returns:
        Dictionary with search results in Tavily-compatible format:
        {
            "results": [
                {"title": str, "url": str, "content": str, "score": float},
                ...
            ],
            "answer": str (optional AI-generated answer),
            "error": str (if failed)
        }
    """
    # Get private gateway credentials (required)
    litellm_token = os.environ.get("LITELLM_TOKEN") or os.environ.get("AWS_BEARER_TOKEN_BEDROCK")
    gemini_model = os.environ.get("GEMINI_MODEL", "gemini-2.5-pro")
    
    if not litellm_token:
        return {
            "results": [],
            "error": "LITELLM_TOKEN or AWS_BEARER_TOKEN_BEDROCK not found in environment variables"
        }
    
    # Private LiteLLM gateway URL
    litellm_url = os.environ.get(
        "LITELLM_URL",
        "https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions"
    )
    
    print(f"[GEMINI] Searching for: {query[:100]}...")
    print(f"[GEMINI] Using Gemini google_search grounding tool")
    print(f"[GEMINI] Model: {gemini_model}")
    print(f"[GEMINI] Gateway: {litellm_url}")
    
    # Prepare request body
    body = {
        "model": gemini_model,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0,
        "max_tokens": 2048,
        "tools": [{"google_search": {}}],  # Enable Google Search grounding
    }
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {litellm_token}",
    }
    
    try:
        # Create SSL context
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        # Create request
        req = urllib.request.Request(
            litellm_url,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        
        print("[GEMINI] Sending request to private gateway...")
        
        # Execute request
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        # Extract content and grounding metadata
        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        grounding_meta = data.get('vertex_ai_grounding_metadata', [])
        grounding_used = any(bool(g) for g in grounding_meta)
        
        print(f"[GEMINI] Response received, grounding used: {grounding_used}")
        
        # Extract cited sources from grounding chunks
        sources = []
        try:
            for entry in grounding_meta:
                for chunk in (entry.get('groundingChunks') or []):
                    web = chunk.get('web') or {}
                    if web.get('uri'):
                        sources.append({
                            'title': web.get('title', 'No title'),
                            'url': web['uri'],
                            'content': content[:500],  # Use part of the answer as content
                            'score': 0.8,  # Default score for Gemini results
                        })
        except Exception as e:
            print(f"[GEMINI] Warning: Failed to extract sources: {e}")
        
        # Limit to max_results
        sources = sources[:max_results]
        
        print(f"[GEMINI] Success! Got {len(sources)} results")
        
        return {
            'results': sources,
            'answer': content.strip() if content else None,
            'grounding_used': grounding_used,
            'output_len': len(content),
        }
        
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8', errors='replace')
        print(f"[GEMINI] HTTP Error {e.code}: {e.reason}")
        print(f"[GEMINI] Error details: {error_body}")
        return {
            'results': [],
            'error': f"HTTP {e.code}: {e.reason}",
            'error_details': error_body
        }
    except Exception as e:
        print(f"[GEMINI] Error: {type(e).__name__}: {str(e)}")
        return {
            'results': [],
            'error': str(e),
            'error_type': type(e).__name__
        }


def gemini_search_fallback(query: str, max_results: int = 5, tavily_error: str = None) -> Dict[str, Any]:
    """
    Fallback search using Gemini when Tavily fails
    
    Args:
        query: Search query
        max_results: Maximum number of results
        tavily_error: Error message from Tavily (for logging)
        
    Returns:
        Dictionary with search results in Tavily-compatible format
    """
    print()
    print("=" * 80)
    print("[FALLBACK] Tavily search failed, trying Gemini google_search...")
    if tavily_error:
        print(f"[FALLBACK] Tavily error: {tavily_error}")
    print("=" * 80)
    print()
    
    result = gemini_web_search(query, max_results)
    
    if result.get('results'):
        print(f"[FALLBACK] ✅ Gemini fallback successful! Got {len(result['results'])} results")
    else:
        print(f"[FALLBACK] ❌ Gemini fallback also failed: {result.get('error', 'Unknown error')}")
    
    return result
