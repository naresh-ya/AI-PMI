"""
Main web search interface
Hybrid: Tavily + parallel Scrapling extraction + conditional Gemini fallback

Required flow:
1. Tavily returns top candidate URLs.
2. Process candidates in parallel batches.
3. Stop once max usable sources are collected.
4. If URL is a direct file, use Tavily content.
5. If URL is a normal webpage, try Scrapling first.
6. If Scrapling fails and Tavily content is good enough, use Tavily content.
7. If Scrapling fails and Tavily content is weak/empty, try Gemini.
8. If Gemini fails, use Tavily fallback anyway.
"""

from typing import Dict, Any, List, Optional
import os
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

from .tavily_client import tavily_search
from .scrapling_client import scrapling_fetch_url
from .gemini_client import gemini_fetch_url

logger = logging.getLogger(__name__)


def get_int_env(name: str, default: int) -> int:
    """
    Safely read integer environment variable.
    """
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid integer value for {name}. Using default: {default}")
        return default


def is_direct_file_url(url: str) -> bool:
    """
    Check if URL is a direct file.
    """
    if not url:
        return False

    file_extensions = [
        ".pdf",
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
        ".ppt",
        ".pptx",
        ".zip",
        ".tar",
        ".gz"
    ]

    clean_url = url.lower().split("?")[0].split("#")[0]

    return any(clean_url.endswith(ext) for ext in file_extensions)


def get_tavily_fallback_content(result: Dict[str, Any]) -> str:
    """
    Return the best available Tavily content/snippet.
    """
    return (
        result.get("raw_content")
        or result.get("content")
        or result.get("snippet")
        or ""
    )


def normalize_content(content: Optional[str], max_chars: int) -> str:
    """
    Normalize and truncate content to avoid oversized synthesis prompts.
    """
    if not content:
        return ""

    text = str(content).strip()

    if max_chars > 0 and len(text) > max_chars:
        return text[:max_chars] + "\n\n...[truncated]"

    return text


def build_source_result(
    url: str,
    title: str,
    content: str,
    source: str,
    error: Optional[str] = None
) -> Dict[str, Any]:
    """
    Standardize source result shape.
    """
    return {
        "url": url,
        "title": title,
        "content": content,
        "content_length": len(content) if content else 0,
        "source": source,
        "error": error
    }


def process_single_search_result(
    result: Dict[str, Any],
    index: int,
    extraction_timeout: int,
    gemini_timeout: int,
    content_max_chars: int,
    tavily_min_content_chars: int
) -> Dict[str, Any]:
    """
    Process one Tavily search result.

    Logic:
    - File URL: use Tavily content.
    - Normal URL: try Scrapling.
    - If Scrapling fails and Tavily content is good enough, use Tavily.
    - If Tavily content is weak, try Gemini.
    - If Gemini fails, use Tavily fallback anyway.
    """
    url = result.get("url", "")
    title = result.get("title", "")
    tavily_content = normalize_content(
        get_tavily_fallback_content(result),
        content_max_chars
    )

    logger.info(f"Processing search result {index}: {url}")

    if not url:
        return build_source_result(
            url=url,
            title=title,
            content=tavily_content,
            source="tavily_snippet",
            error="missing_url"
        )

    if is_direct_file_url(url):
        logger.info(f"Direct file detected. Using Tavily content for result {index}: {url}")

        return build_source_result(
            url=url,
            title=title,
            content=tavily_content,
            source="tavily_raw",
            error=None
        )

    # Try Scrapling first
    logger.info(
        f"Trying Scrapling for result {index}: {url} "
        f"with timeout={extraction_timeout}s"
    )

    scrapling_result = scrapling_fetch_url(
        url=url,
        timeout=extraction_timeout,
        extract_format="markdown"
    )

    if (
        scrapling_result.get("error") is None
        and scrapling_result.get("content")
    ):
        scrapling_content = normalize_content(
            scrapling_result.get("content", ""),
            content_max_chars
        )

        logger.info(f"Scrapling succeeded for result {index}: {url}")

        return build_source_result(
            url=url,
            title=title,
            content=scrapling_content,
            source="scrapling",
            error=None
        )

    scrapling_error = scrapling_result.get("error")
    logger.warning(
        f"Scrapling failed for result {index}: {url}. "
        f"Error: {scrapling_error}"
    )

    # If Tavily content is good enough, use it and skip Gemini
    if len(tavily_content) >= tavily_min_content_chars:
        logger.info(
            f"Using Tavily fallback for result {index} because content length "
            f"{len(tavily_content)} >= {tavily_min_content_chars}: {url}"
        )

        return build_source_result(
            url=url,
            title=title,
            content=tavily_content,
            source="tavily_snippet",
            error=f"Scrapling failed: {scrapling_error}"
        )

    # Tavily content is weak, try Gemini fallback
    logger.info(
        f"Tavily content weak for result {index}. "
        f"Trying Gemini fallback for URL: {url}"
    )

    gemini_result = gemini_fetch_url(
        url=url,
        timeout=gemini_timeout
    )

    if (
        gemini_result.get("error") is None
        and gemini_result.get("content")
    ):
        gemini_content = normalize_content(
            gemini_result.get("content", ""),
            content_max_chars
        )

        logger.info(f"Gemini fallback succeeded for result {index}: {url}")

        return build_source_result(
            url=url,
            title=title,
            content=gemini_content,
            source="gemini",
            error=None
        )

    gemini_error = gemini_result.get("error")
    logger.warning(
        f"Gemini fallback failed for result {index}: {url}. "
        f"Error: {gemini_error}"
    )

    # Final fallback to Tavily even if weak/empty
    return build_source_result(
        url=url,
        title=title,
        content=tavily_content,
        source="tavily_snippet",
        error=f"Scrapling failed: {scrapling_error}; Gemini failed: {gemini_error}"
    )


def execute_web_search(
    query: str,
    max_results: int = 5,
    search_depth: str = "basic",
    include_domains: Optional[List[str]] = None,
    exclude_domains: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Execute hybrid web search.

    Tavily candidate discovery:
    - Uses WEB_SEARCH_CANDIDATE_RESULTS, default 10.

    Usable source collection:
    - Collects max WEB_MAX_USABLE_SOURCES, default 5.

    Parallel processing:
    - Processes candidates in batches of WEB_EXTRACTION_PARALLELISM, default 5.
    """
    try:
        candidate_results = get_int_env("WEB_SEARCH_CANDIDATE_RESULTS", 10)
        max_usable_sources = get_int_env("WEB_MAX_USABLE_SOURCES", 5)
        extraction_parallelism = get_int_env("WEB_EXTRACTION_PARALLELISM", 5)
        extraction_timeout = get_int_env("WEB_EXTRACTION_TIMEOUT_SECONDS", 12)
        gemini_timeout = get_int_env("WEB_GEMINI_FALLBACK_TIMEOUT_SECONDS", 15)
        content_max_chars = get_int_env("WEB_CONTENT_MAX_CHARS", 6000)
        tavily_min_content_chars = get_int_env("WEB_TAVILY_MIN_CONTENT_CHARS", 300)

        # Ensure sane values
        candidate_results = max(candidate_results, max_usable_sources)
        extraction_parallelism = max(1, extraction_parallelism)
        max_usable_sources = max(1, max_usable_sources)

        logger.info(f"Web search query: {query}")
        logger.info(f"Web search candidate results: {candidate_results}")
        logger.info(f"Web max usable sources: {max_usable_sources}")
        logger.info(f"Web extraction parallelism: {extraction_parallelism}")
        logger.info(f"Web extraction timeout seconds: {extraction_timeout}")
        logger.info(f"Web Gemini fallback timeout seconds: {gemini_timeout}")
        logger.info(f"Web content max chars: {content_max_chars}")
        logger.info(f"Web Tavily min content chars: {tavily_min_content_chars}")

        # Step 1: Tavily search for candidate URLs
        search_result = tavily_search(
            query=query,
            search_depth=search_depth,
            max_results=candidate_results,
            include_domains=include_domains,
            exclude_domains=exclude_domains,
            include_answer=True,
            include_raw_content=True
        )

        if "error" in search_result:
            return {
                "status": "error",
                "error": search_result["error"],
                "query": query,
                "results": []
            }

        search_results = search_result.get("results", [])

        if not search_results:
            return {
                "status": "success",
                "query": query,
                "answer": search_result.get("answer", ""),
                "results": [],
                "message": "No results found"
            }

        usable_sources = []
        total_candidates = len(search_results)

        # Step 2: Process candidates in parallel batches
        for batch_start in range(0, total_candidates, extraction_parallelism):
            if len(usable_sources) >= max_usable_sources:
                break

            batch = search_results[batch_start:batch_start + extraction_parallelism]

            logger.info(
                f"Processing web search batch starting at index {batch_start + 1}. "
                f"Batch size: {len(batch)}"
            )

            futures = []

            with ThreadPoolExecutor(max_workers=extraction_parallelism) as executor:
                for batch_offset, result in enumerate(batch):
                    index = batch_start + batch_offset + 1

                    futures.append(
                        executor.submit(
                            process_single_search_result,
                            result,
                            index,
                            extraction_timeout,
                            gemini_timeout,
                            content_max_chars,
                            tavily_min_content_chars
                        )
                    )

                for future in as_completed(futures):
                    try:
                        processed_result = future.result()
                    except Exception as e:
                        logger.error(
                            f"Error processing search result in parallel batch: {str(e)}",
                            exc_info=True
                        )
                        continue

                    # Treat any result shape as usable, even Tavily fallback,
                    # as long as it has URL/title/content or at least a URL.
                    if processed_result:
                        usable_sources.append(processed_result)

                    if len(usable_sources) >= max_usable_sources:
                        logger.info(
                            f"Collected {len(usable_sources)} usable sources. "
                            "Stopping web result processing."
                        )
                        break

        # Step 3: Trim to max usable sources
        usable_sources = usable_sources[:max_usable_sources]

        return {
            "status": "success",
            "query": query,
            "answer": search_result.get("answer", ""),
            "total_candidates": total_candidates,
            "total_results": len(usable_sources),
            "results": usable_sources,
            "sources_used": {
                "tavily_raw": sum(1 for r in usable_sources if r["source"] == "tavily_raw"),
                "scrapling": sum(1 for r in usable_sources if r["source"] == "scrapling"),
                "gemini": sum(1 for r in usable_sources if r["source"] == "gemini"),
                "tavily_snippet": sum(1 for r in usable_sources if r["source"] == "tavily_snippet")
            },
            "extraction_config": {
                "candidate_results": candidate_results,
                "max_usable_sources": max_usable_sources,
                "extraction_parallelism": extraction_parallelism,
                "extraction_timeout_seconds": extraction_timeout,
                "gemini_timeout_seconds": gemini_timeout,
                "content_max_chars": content_max_chars,
                "tavily_min_content_chars": tavily_min_content_chars,
                "fallback_logic": [
                    "tavily_search",
                    "file_url_uses_tavily",
                    "normal_url_tries_scrapling",
                    "if_scrapling_fails_and_tavily_good_use_tavily",
                    "if_tavily_weak_try_gemini",
                    "if_gemini_fails_use_tavily"
                ]
            }
        }

    except Exception as e:
        logger.error(f"Web search failed: {str(e)}", exc_info=True)

        return {
            "status": "error",
            "error": str(e),
            "query": query,
            "results": []
        }