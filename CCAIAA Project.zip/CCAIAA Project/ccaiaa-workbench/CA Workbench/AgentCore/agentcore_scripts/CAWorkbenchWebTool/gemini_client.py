"""
Gemini client wrapper for URL content fetching.

Used as fallback when:
- Scrapling fails
- Tavily content/snippet is weak or empty

This fallback must be bounded by timeout so web search does not block chatbot response.
"""

import os
import json
import urllib.request
import urllib.error
import ssl
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


def get_int_env(name: str, default: int) -> int:
    """
    Safely read integer environment variable.
    """
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid integer value for {name}. Using default: {default}")
        return default


def gemini_fetch_url(
    url: str,
    timeout: Optional[int] = None
) -> Dict[str, Any]:
    """
    Fetch URL content using Gemini as fallback.

    Args:
        url: URL to fetch/summarize.
        timeout: Request timeout in seconds. If None, uses env/default.

    Returns:
        Dictionary with content and metadata.
    """
    try:
        gemini_api_key = os.environ.get("GEMINI_API_KEY")

        if not gemini_api_key:
            return {
                "url": url,
                "content": None,
                "error": "GEMINI_API_KEY not found in environment variables"
            }

        gemini_model = os.environ.get("GEMINI_MODEL", "gemini-2.5-pro")
        timeout_seconds = timeout or get_int_env("WEB_GEMINI_FALLBACK_TIMEOUT_SECONDS", 15)
        max_output_tokens = get_int_env("WEB_GEMINI_MAX_OUTPUT_TOKENS", 4000)

        logger.info(f"Gemini fallback model: {gemini_model}")
        logger.info(f"Gemini fallback timeout_seconds: {timeout_seconds}")
        logger.info(f"Gemini fallback max_output_tokens: {max_output_tokens}")
        logger.info(f"Gemini fallback URL: {url}")

        gemini_url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{gemini_model}:generateContent?key={gemini_api_key}"
        )

        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": (
                                "Fetch and summarize the useful factual content from this URL. "
                                "Focus on information relevant to research synthesis. "
                                "Do not include unrelated navigation text. "
                                f"URL: {url}"
                            )
                        }
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0,
                "maxOutputTokens": max_output_tokens
            }
        }

        req = urllib.request.Request(
            gemini_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, context=ctx, timeout=timeout_seconds) as response:
            result = json.loads(response.read())

        candidates = result.get("candidates", [])

        if candidates:
            parts = (
                candidates[0]
                .get("content", {})
                .get("parts", [])
            )

            if parts and isinstance(parts[0], dict) and "text" in parts[0]:
                content = parts[0]["text"]

                return {
                    "url": url,
                    "content": content,
                    "content_length": len(content),
                    "error": None,
                    "source": "gemini",
                    "model": gemini_model,
                    "timeout_seconds": timeout_seconds
                }

        return {
            "url": url,
            "content": None,
            "error": "No content returned from Gemini",
            "model": gemini_model,
            "timeout_seconds": timeout_seconds
        }


        return {
            "url": url,
            "content": None,
            "error": "No content returned from Gemini",
            "model": gemini_model,
            "timeout_seconds": timeout_seconds
        }

    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")

        logger.error(f"Gemini fallback HTTP error {e.code}: {e.reason}")
        logger.error(error_body[:1000])

        return {
            "url": url,
            "content": None,
            "error": f"Gemini HTTP error {e.code}: {e.reason}",
            "error_body": error_body[:1000]
        }

    except Exception as e:
        logger.error(f"Gemini fetch error for URL {url}: {str(e)}", exc_info=True)

        return {
            "url": url,
            "content": None,
            "error": f"Gemini fetch error: {str(e)}"
        }