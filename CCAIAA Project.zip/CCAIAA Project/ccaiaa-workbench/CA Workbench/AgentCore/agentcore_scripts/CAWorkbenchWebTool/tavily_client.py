"""
Tavily API client wrapper with Gemini fallback
"""
import os
import json
from typing import Dict, Any, List, Optional

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    import urllib.request
    import ssl


def tavily_search(
    query: str,
    search_depth: str = "advanced",
    max_results: int = 5,
    include_domains: Optional[List[str]] = None,
    exclude_domains: Optional[List[str]] = None,
    include_answer: bool = False,
    include_raw_content: bool = False
) -> Dict[str, Any]:
    """
    Execute a Tavily search via private LiteLLM gateway (matches Lambda configuration)
    
    Args:
        query: Search query
        search_depth: "basic" or "advanced" (default: "advanced")
        max_results: Maximum number of results (default: 5)
        include_domains: List of domains to include
        exclude_domains: List of domains to exclude
        include_answer: Include AI-generated answer (not supported by gateway)
        include_raw_content: Include raw page content (not supported by gateway)
        
    Returns:
        Dictionary with search results
    """
    # Get private gateway credentials (required)
    litellm_token = os.environ.get("LITELLM_TOKEN") or os.environ.get("AWS_BEARER_TOKEN_BEDROCK")
    
    if not litellm_token:
        return {
            "error": "LITELLM_TOKEN or AWS_BEARER_TOKEN_BEDROCK not found in environment variables",
            "results": []
        }
    
    # Always use private LiteLLM gateway (matches Lambda configuration)
    tavily_url = "https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily"
    headers = {
        "Authorization": f"Bearer {litellm_token}",
        "Content-Type": "application/json"
    }
    
    # Force advanced search depth for better results
    payload = {
        "query": query,
        "max_results": max_results,
        "search_depth": "advanced",  # Always use advanced mode
    }
    
    # Add domain filters if provided
    if include_domains:
        payload["include_domains"] = include_domains
    if exclude_domains:
        payload["exclude_domains"] = exclude_domains
    
    print(f"[TAVILY] Searching for: {query[:100]}...")
    print(f"[TAVILY] Using PRIVATE gateway (matches Lambda)")
    print(f"[TAVILY] API URL: {tavily_url}")
    print(f"[TAVILY] Max results: {max_results}, Depth: advanced (forced)")
    print(f"[TAVILY] Using requests library: {REQUESTS_AVAILABLE}")
    
    if REQUESTS_AVAILABLE:
        # Use requests library (recommended)
        try:
            
            # Disable SSL verification for corporate proxies
            print("[TAVILY] Sending request to private gateway...")
            response = requests.post(
                tavily_url,
                json=payload,
                headers=headers,
                verify=False,
                timeout=60
            )
            
            response.raise_for_status()
            result = response.json()
            
            print(f"[TAVILY] Success! Got {len(result.get('results', []))} results")
            return result
            
        except Exception as e:
            print(f"[TAVILY] Error: {type(e).__name__}: {str(e)}")
            
            # Try Gemini fallback
            try:
                from gemini_search import gemini_search_fallback
                print("[TAVILY] Attempting Gemini fallback...")
                return gemini_search_fallback(query, max_results, tavily_error=str(e))
            except Exception as fallback_error:
                print(f"[TAVILY] Gemini fallback also failed: {fallback_error}")
                return {
                    "error": f"Tavily failed: {str(e)}, Gemini fallback failed: {str(fallback_error)}",
                    "error_type": type(e).__name__,
                    "results": []
                }
    else:
        # Fallback to urllib if requests not available
        print("[TAVILY] WARNING: requests library not available, using urllib")
        try:
            import urllib.request
            import ssl
            
            req = urllib.request.Request(
                tavily_url,
                data=json.dumps(payload).encode("utf-8"),
                headers=headers,
                method="POST"
            )
            
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            with urllib.request.urlopen(req, context=ctx, timeout=60) as response:
                result = json.loads(response.read().decode("utf-8"))
                print(f"[TAVILY] Success! Got {len(result.get('results', []))} results")
                return result
                
        except Exception as e:
            print(f"[TAVILY] Error: {type(e).__name__}: {str(e)}")
            
            # Try Gemini fallback
            try:
                from gemini_search import gemini_search_fallback
                print("[TAVILY] Attempting Gemini fallback...")
                return gemini_search_fallback(query, max_results, tavily_error=str(e))
            except Exception as fallback_error:
                print(f"[TAVILY] Gemini fallback also failed: {fallback_error}")
                return {
                    "error": f"Tavily failed: {str(e)}, Gemini fallback failed: {str(fallback_error)}",
                    "error_type": type(e).__name__,
                    "results": []
                }
