"""
CA Workbench Web Search Tool
Tavily + Scrapling + Gemini fallback
"""

__version__ = "1.0.0"
