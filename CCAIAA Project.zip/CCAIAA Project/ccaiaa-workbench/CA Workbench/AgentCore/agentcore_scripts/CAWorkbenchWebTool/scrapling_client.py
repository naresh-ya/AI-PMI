"""
Scrapling client wrapper for content fetching.

Used by web_search.py as the first URL extraction method after Tavily discovery.

Important:
- This module must not use a long default timeout.
- Web search should remain responsive even when some websites are slow or block scraping.
"""

from typing import Dict, Any, List, Optional
import os
import logging

logger = logging.getLogger(__name__)


def get_int_env(name: str, default: int) -> int:
    """
    Safely read integer environment variable.
    """
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid integer value for {name}. Using default: {default}")
        return default


def scrapling_fetch_url(
    url: str,
    timeout: Optional[int] = None,
    extract_format: str = "markdown"
) -> Dict[str, Any]:
    """
    Fetch content from a URL using Scrapling.

    Args:
        url: The URL to fetch.
        timeout: Timeout in seconds. If None, uses WEB_EXTRACTION_TIMEOUT_SECONDS.
        extract_format: Format to extract content: 'markdown', 'text', or 'html'.

    Returns:
        Dictionary with status, url, content, and error if any.
    """
    try:
        from scrapling.fetchers import Fetcher

        timeout_seconds = timeout or get_int_env("WEB_EXTRACTION_TIMEOUT_SECONDS", 12)

        logger.info(f"Scrapling fetch URL: {url}")
        logger.info(f"Scrapling timeout_seconds: {timeout_seconds}")
        logger.info(f"Scrapling extract_format: {extract_format}")

        fetcher = Fetcher()

        response = fetcher.get(
            url,
            timeout=timeout_seconds,
            stealthy_headers=True
        )

        status = getattr(response, "status", None)

        if status != 200:
            logger.warning(f"Scrapling non-200 response for URL {url}: {status}")

            return {
                "url": url,
                "status": status,
                "content": None,
                "content_length": 0,
                "error": f"HTTP {status}"
            }

        if extract_format == "text":
            content = response.get_all_text()
        elif extract_format == "html":
            content = response.body
        else:
            # Scrapling markdown support may vary by response object.
            # get_all_text() is safer and good enough for synthesis context.
            content = response.get_all_text()

        content = content or ""

        logger.info(
            f"Scrapling fetch succeeded for URL {url}. "
            f"Content length: {len(content)}"
        )

        return {
            "url": url,
            "status": status,
            "content": content,
            "content_length": len(content),
            "error": None
        }

    except ImportError:
        logger.error("Scrapling not installed. Install with: pip install 'scrapling[fetchers]'")

        return {
            "url": url,
            "status": None,
            "content": None,
            "content_length": 0,
            "error": "Scrapling not installed. Run: pip install 'scrapling[fetchers]'"
        }

    except Exception as e:
        logger.warning(f"Scrapling fetch failed for URL {url}: {str(e)}")

        return {
            "url": url,
            "status": None,
            "content": None,
            "content_length": 0,
            "error": str(e)
        }


def scrapling_fetch_multiple_urls(
    urls: List[str],
    timeout: Optional[int] = None,
    extract_format: str = "markdown"
) -> List[Dict[str, Any]]:
    """
    Fetch content from multiple URLs using Scrapling.

    Note:
    This helper remains sequential for backward compatibility.
    The main web_search.py now handles parallel batch processing.

    Args:
        urls: List of URLs to fetch.
        timeout: Timeout in seconds per URL. If None, uses WEB_EXTRACTION_TIMEOUT_SECONDS.
        extract_format: Format to extract content.

    Returns:
        List of dictionaries with results for each URL.
    """
    results = []

    timeout_seconds = timeout or get_int_env("WEB_EXTRACTION_TIMEOUT_SECONDS", 12)

    logger.info(f"Scrapling multiple fetch count: {len(urls)}")
    logger.info(f"Scrapling multiple fetch timeout_seconds: {timeout_seconds}")

    for url in urls:
        result = scrapling_fetch_url(
            url=url,
            timeout=timeout_seconds,
            extract_format=extract_format
        )
        results.append(result)

    return results