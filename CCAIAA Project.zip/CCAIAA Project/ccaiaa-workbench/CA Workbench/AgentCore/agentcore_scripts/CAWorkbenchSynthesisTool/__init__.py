"""
CA Workbench Synthesis Tool
Synthesizes results from multiple sources
"""
