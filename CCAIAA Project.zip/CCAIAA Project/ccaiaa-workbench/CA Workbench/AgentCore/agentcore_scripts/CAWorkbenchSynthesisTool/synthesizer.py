"""
Synthesis Tool - Combines results from multiple sources using LLM
REAL IMPLEMENTATION - Uses Internal LiteLLM Endpoint

Legacy synthesis tool.
Active memory-aware synthesis is handled by:
langgraph_orchestrator/nodes/synthesis.py

This file is still kept configurable in case older workflows import it.
"""

from typing import Dict, Any, List, Optional
import os
import json
import urllib.request
import urllib.error
import ssl
import logging
import re
import html
import boto3

logger = logging.getLogger(__name__)

SYNTHESIZER_PROMPT_ID = os.environ.get(
    "SYNTHESIZER_PROMPT_ID",
    "26AXASKSFB"
)

SYNTHESIZER_PROMPT_REGION = os.environ.get(
    "SYNTHESIZER_PROMPT_REGION",
    "eu-west-1"
)


def get_int_env(name: str, default: int) -> int:
    """
    Safely read integer environment variable.
    """
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid integer value for {name}. Using default: {default}")
        return default


def get_float_env(name: str, default: float) -> float:
    """
    Safely read float environment variable.
    """
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid float value for {name}. Using default: {default}")
        return default


def get_latest_synthesizer_prompt_version(client, prompt_id: str) -> str:
    """
    Get latest published numeric version from AWS Prompt Management.

    Does not use DRAFT.
    Raises error if no published numeric version exists.
    """

    response = client.list_prompts(promptIdentifier=prompt_id)

    versions = []

    for summary in response.get("promptSummaries", []):
        version = str(summary.get("version", "")).strip()

        if version.isdigit():
            versions.append(int(version))

    if not versions:
        raise ValueError(
            f"No published numeric versions found for synthesizer prompt_id={prompt_id}"
        )

    return str(max(versions))

def fetch_latest_synthesizer_prompt_from_aws() -> Dict[str, str]:
    """
    Fetch latest published Synthesizer prompt from AWS Bedrock Prompt Management.

    Uses:
    - SYNTHESIZER_PROMPT_ID
    - SYNTHESIZER_PROMPT_REGION

    Always retrieves latest numeric published version.
    Does not use DRAFT.
    """

    client = boto3.client(
        "bedrock-agent",
        region_name=SYNTHESIZER_PROMPT_REGION
    )

    latest_version = get_latest_synthesizer_prompt_version(
        client=client,
        prompt_id=SYNTHESIZER_PROMPT_ID
    )

    response = client.get_prompt(
        promptIdentifier=SYNTHESIZER_PROMPT_ID,
        promptVersion=latest_version
    )

    variants = response.get("variants", [])

    if not variants:
        raise ValueError(
            f"No variants found in synthesizer prompt_id={SYNTHESIZER_PROMPT_ID}, version={latest_version}"
        )

    default_variant_name = response.get("defaultVariant")
    selected_variant = None

    if default_variant_name:
        for variant in variants:
            if variant.get("name") == default_variant_name:
                selected_variant = variant
                break

    if selected_variant is None:
        selected_variant = variants[0]

    template_config = selected_variant.get("templateConfiguration", {})
    chat_config = template_config.get("chat", {})

    if not chat_config:
        raise ValueError(
            f"Synthesizer prompt must be CHAT template. prompt_id={SYNTHESIZER_PROMPT_ID}, version={latest_version}"
        )

    system_prompt = ""
    user_prompt = ""

    system_blocks = chat_config.get("system", []) or []

    if system_blocks:
        system_prompt = system_blocks[0].get("text", "") or ""

    messages = chat_config.get("messages", []) or []

    for message in messages:
        role = str(message.get("role", "")).lower()

        if role == "user":
            content_blocks = message.get("content", []) or []

            if content_blocks:
                user_prompt = content_blocks[0].get("text", "") or ""
                break

    if not user_prompt:
        raise ValueError(
            f"User prompt template not found in synthesizer prompt_id={SYNTHESIZER_PROMPT_ID}, version={latest_version}"
        )

    logger.info(
        "Fetched latest synthesizer prompt from AWS Prompt Management | prompt_id=%s | version=%s | variant=%s",
        SYNTHESIZER_PROMPT_ID,
        latest_version,
        selected_variant.get("name")
    )

    return {
        "system_prompt": system_prompt,
        "user_prompt": user_prompt,
        "version": latest_version,
        "prompt_id": SYNTHESIZER_PROMPT_ID,
        "variant": selected_variant.get("name")
    }

def render_synthesizer_prompt(
    template: str,
    variables: Dict[str, Any]
) -> str:
    """
    Render Synthesizer prompt template variables.

    Uses simple {{variable}} replacement so it matches AWS Prompt Management
    template syntax used in Planner.
    """

    rendered = str(template or "")

    for key, value in variables.items():
        placeholder = "{{" + key + "}}"

        if value is None:
            safe_value = ""
        elif isinstance(value, (list, dict)):
            safe_value = json.dumps(value, ensure_ascii=False, default=str)
        else:
            safe_value = str(value)

        rendered = rendered.replace(placeholder, safe_value)

    return rendered

def build_synthesizer_prompt_from_aws(
    user_query: str,
    research_query: str,
    intent: str,
    synthesis_mode: str,
    requires_research: Optional[bool],
    memory_scope: Optional[List[str]],
    context_instruction: Optional[str],
    format_instruction: Optional[str],
    facts: str,
    preferences: str,
    previous_response: str,
    research_context: str
) -> Dict[str, str]:
    """
    Build Synthesizer system/user prompts from AWS Prompt Management.
    """

    prompt_bundle = fetch_latest_synthesizer_prompt_from_aws()

    variables = {
        "current_date": os.environ.get("CURRENT_DATE", ""),
        "user_query": user_query or "",
        "research_query": research_query or "",
        "intent": intent or "",
        "synthesis_mode": synthesis_mode or "",
        "requires_research": requires_research,
        "memory_scope": memory_scope or [],
        "context_instruction": context_instruction or "None",
        "format_instruction": format_instruction or "None",
        "facts": facts or "No relevant long-term facts provided.",
        "preferences": preferences or "No user preferences provided.",
        "previous_response": previous_response or "No previous assistant response provided.",
        "research_context": research_context or "No research results provided."
    }

    system_prompt = render_synthesizer_prompt(
        prompt_bundle.get("system_prompt", ""),
        variables
    )

    user_prompt = render_synthesizer_prompt(
        prompt_bundle.get("user_prompt", ""),
        variables
    )

    logger.info(
        "Using AWS Prompt Management synthesizer prompt | prompt_id=%s | version=%s | variant=%s | system_chars=%s | user_chars=%s",
        prompt_bundle.get("prompt_id"),
        prompt_bundle.get("version"),
        prompt_bundle.get("variant"),
        len(system_prompt or ""),
        len(user_prompt or "")
    )

    return {
        "system_prompt": system_prompt,
        "user_prompt": user_prompt,
        "prompt_id": prompt_bundle.get("prompt_id"),
        "version": prompt_bundle.get("version"),
        "variant": prompt_bundle.get("variant")
    }


def synthesize_results(
    web_results: Optional[List[Dict[str, Any]]] = None,
    kb_results: Optional[Dict[str, Any]] = None,
    curated_results: Optional[Dict[str, Any]] = None,
    query: str = ""
) -> Dict[str, Any]:
    """
    Synthesize results from multiple sources using LLM.

    Args:
        web_results: Results from web search
        kb_results: Results from knowledge base
        curated_results: Results from curated URLs
        query: Original user query

    Returns:
        Dictionary with synthesis results including formatted narrative
    """
    try:
        # ------------------------------------------------------------------
        # LiteLLM configuration
        # ------------------------------------------------------------------
        litellm_url = (
            os.environ.get("LITELLM_URL")
            or os.environ.get("AWS_LITELLM_ENDPOINT")
            or "https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions"
        )

        litellm_model = (
            os.environ.get("LEGACY_SYNTHESIS_LLM_MODEL")
            or os.environ.get("SYNTHESIS_LLM_MODEL")
            or os.environ.get("LITELLM_MODEL")
            or "bedrock/us.anthropic.claude-sonnet-4-6"
        )

        litellm_key = (
            os.environ.get("LITELLM_TOKEN")
            or os.environ.get("BEDROCK_BEARER_TOKEN")
        )

        max_tokens = get_int_env("LEGACY_SYNTHESIS_MAX_TOKENS", 32000)
        temperature = get_float_env("LEGACY_SYNTHESIS_TEMPERATURE", 0.3)
        timeout_seconds = get_int_env("LEGACY_SYNTHESIS_TIMEOUT_SECONDS", 400)

        logger.info(f"Legacy synthesis LLM model: {litellm_model}")
        logger.info(f"Legacy synthesis max_tokens: {max_tokens}")
        logger.info(f"Legacy synthesis temperature: {temperature}")
        logger.info(f"Legacy synthesis timeout_seconds: {timeout_seconds}")

        if not litellm_key:
            return {
                "status": "error",
                "message": "LITELLM_TOKEN or BEDROCK_BEARER_TOKEN not set in environment",
                "query": query,
                "synthesis_text": None,
                "citations": [],
                "metadata": {"error": "missing_token"}
            }

        # ------------------------------------------------------------------
        # Count available results
        # ------------------------------------------------------------------
        web_count = len(web_results) if web_results else 0
        kb_available = kb_results is not None and kb_results.get("status") != "coming_soon"
        curated_available = curated_results is not None and curated_results.get("status") != "coming_soon"

        # ------------------------------------------------------------------
        # Prepare context from all sources
        # ------------------------------------------------------------------
        context_parts = []
        citations = []

        if web_results:
            context_parts.append("## Web Search Results\n")
            for i, result in enumerate(web_results, 1):
                title = result.get("title", "No title")
                url = result.get("url", "No URL")
                content = result.get("content", "")[:1000]

                context_parts.append(f"### Source {i}: {title}\n")
                context_parts.append(f"URL: {url}\n")
                context_parts.append(f"Content: {content}...\n\n")

                citations.append({
                    "source_number": i,
                    "title": title,
                    "url": url,
                    "type": "web_search"
                })

        if kb_available:
            context_parts.append("## Knowledge Base Results\n")
            context_parts.append(str(kb_results))
            context_parts.append("\n\n")

        if curated_available:
            context_parts.append("## Curated URLs Results\n")
            context_parts.append(str(curated_results))
            context_parts.append("\n\n")

        full_context = "".join(context_parts)

        # ------------------------------------------------------------------
        # Create synthesis prompt
        # ------------------------------------------------------------------
        synthesis_prompt = f"""You are an expert research analyst. Your task is to synthesize information from multiple sources into a comprehensive, well-structured narrative.

User Query:
{query}

Available Information:
{full_context}

Instructions:
1. Create a comprehensive response that directly answers the user's query.
2. Structure your response with clear headings and subheadings.
3. Use bullet points for key information.
4. Include relevant details from the sources.
5. Make the content highly readable and well-organized.
6. Cite sources using [Source N] notation where appropriate.
7. Ensure the narrative flows logically.
8. Do not fabricate facts. If the available sources do not contain live or exact data, say that clearly.
9. Produce the final frontend-ready answer.

Format your response as follows:

# [Main Title]

## Overview
[Brief introduction/summary]

## [Key Section 1]
- Key point 1 [Source N]
- Key point 2 [Source N]
- Key point 3 [Source N]

## [Key Section 2]
- Key point 1 [Source N]
- Key point 2 [Source N]

## Key Takeaways
- Takeaway 1
- Takeaway 2
- Takeaway 3

Generate a well-structured, informative narrative now:"""

        logger.info(f"Legacy synthesis prompt length: {len(synthesis_prompt)}")

        # ------------------------------------------------------------------
        # Prepare LiteLLM request
        # Use OpenAI-compatible chat format.
        # ------------------------------------------------------------------
        headers = {
            "Authorization": f"Bearer {litellm_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": litellm_model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are an expert research analyst who creates comprehensive, well-structured narratives from multiple sources."
                },
                {
                    "role": "user",
                    "content": synthesis_prompt
                }
            ],
            "max_tokens": max_tokens,
            "temperature": temperature
        }

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(
            litellm_url,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST"
        )

        with urllib.request.urlopen(req, context=ctx, timeout=timeout_seconds) as response:
            raw = response.read().decode("utf-8", errors="replace")
            res = json.loads(raw)

        synthesis_text = (
            res.get("choices", [{}])[0]
            .get("message", {})
            .get("content")
        )

        if not synthesis_text:
            return {
                "status": "error",
                "message": "No content in LLM response",
                "query": query,
                "synthesis_text": None,
                "citations": citations,
                "metadata": {
                    "error": "empty_response",
                    "model": litellm_model
                }
            }

        return {
            "status": "success",
            "query": query,
            "synthesis_text": synthesis_text,
            "sources_used": {
                "web_search": web_count,
                "knowledge_base": "available" if kb_available else "not_available",
                "curated_urls": "available" if curated_available else "not_available"
            },
            "citations": citations,
            "metadata": {
                "tool": "legacy_synthesis",
                "model": litellm_model,
                "endpoint": litellm_url,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "timeout_seconds": timeout_seconds,
                "implementation_status": "active",
                "total_sources": len(citations)
            }
        }

    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")
        logger.error(f"Legacy synthesis HTTP error {e.code}: {e.reason}")
        logger.error(error_body[:1000])

        return {
            "status": "error",
            "message": f"HTTP Error {e.code}: {e.reason}",
            "query": query,
            "synthesis_text": None,
            "citations": [],
            "metadata": {
                "error": "http_error",
                "error_code": e.code,
                "error_body": error_body
            }
        }

    except Exception as e:
        logger.error(f"Legacy synthesis failed: {str(e)}", exc_info=True)

        return {
            "status": "error",
            "message": f"Synthesis failed: {str(e)}",
            "query": query,
            "synthesis_text": None,
            "citations": [],
            "metadata": {"error": str(e)}
        }


# ============================================================================
# NEW MEMORY-AWARE SYNTHESIS FUNCTIONS
# ============================================================================

def limit_memory_items(items, limit: int):
    """
    Limit memory items to the latest N entries.
    If limit is 0 or less, return empty list.
    """
    if not items or limit <= 0:
        return []

    return list(items)[-limit:]


def synthesize_format_only(
    user_query: str,
    short_term_memory: List[Dict[str, Any]],
    format_instructions: Optional[str]
) -> Dict[str, Any]:
    """
    Reformat previous response without new research
    
    Args:
        user_query: Current user query (format request)
        short_term_memory: Recent conversation history
        format_instructions: Desired format (bullet list, concise, etc.)
        
    Returns:
        Synthesis result with reformatted response
    """
    logger.info("Synthesizing format-only followup")

    logger.info(
        "Format-only selected memory | short_term=%s",
        len(short_term_memory or [])
    )
    
    try:
        # Extract previous assistant response
        previous_response = extract_previous_response(short_term_memory)

        logger.info(
            "Format-only synthesis previous_response_chars=%s | format_instructions=%s",
            len(previous_response or ""),
            str(format_instructions or "")[:300]
        )
        
        if not previous_response:
            return {
                'status': 'error',
                'message': 'No previous response found to reformat',
                'synthesis_text': 'I could not find a previous assistant response to reformat.',
                'citations': [],
                'metadata': {
                    'error': 'No previous response found to reformat'
                }
            }
        
        # Build reformat prompt
        prompt_bundle = build_synthesizer_prompt_from_aws(
            user_query=user_query,
            research_query=user_query,
            intent="followup_format_only",
            synthesis_mode="reformat_previous_response",
            requires_research=False,
            memory_scope=["short_term"],
            context_instruction="Reformat the previous assistant response only.",
            format_instruction=format_instructions,
            facts="",
            preferences="",
            previous_response=previous_response,
            research_context=""
        )

        synthesis_text = call_llm_for_synthesis(
            prompt=prompt_bundle["user_prompt"],
            system_prompt=prompt_bundle["system_prompt"]
        )

        return {
            'status': 'success',
            'message': 'Response reformatted',
            'synthesis_text': synthesis_text,
            'citations': [],
            'metadata': {
                'intent': 'followup_format_only',
                'synthesis_mode': 'reformat_previous_response',
                'format_instructions': format_instructions,
                'prompt_id': prompt_bundle.get("prompt_id"),
                'prompt_version': prompt_bundle.get("version"),
                'prompt_variant': prompt_bundle.get("variant")
            }
        }
        
    except Exception as e:
        logger.error(f"Error in format-only synthesis: {str(e)}", exc_info=True)
        error_text = (
            "I'm sorry, but I could not reformat the previous response due to an internal error. "
            f"Error: {str(e)}"
        )
        return {
            'status': 'error',
            'message': f'Reformat failed: {str(e)}',
            'synthesis_text': error_text,
            'citations': [],
            'metadata': {
                'error': str(e),
                'error_type': type(e).__name__
            }
        }


def synthesize_with_memory(
    user_query: str,
    research_query: str,
    intent: str,
    synthesis_mode: str,
    requires_research: Optional[bool],
    memory_scope: Optional[List[str]],
    context_instruction: Optional[str],
    format_instruction: Optional[str],
    planner_reason: Optional[str],
    web_results: List[Dict[str, Any]],
    kb_results: Optional[Dict[str, Any]],
    curated_results: Optional[Dict[str, Any]],
    selected_memory: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Combine previous response with new research
    
    Args:
        user_query: Current user query
        enhanced_query: Reconstructed query with additions
        web_results: New web search results
        kb_results: New KB results
        curated_results: New curated results
        selected_memory: Full memory context
        format_instructions: Optional format instructions
        
    Returns:
        Synthesis result combining old + new
    """
    logger.info("Synthesizing content modification followup")

    logger.info(
        "Follow-up selected memory | short_term=%s | facts=%s | preferences=%s | summaries=%s",
        len(selected_memory.get("short_term", []) or []),
        len(selected_memory.get("long_term_facts", []) or []),
        len(selected_memory.get("preferences", []) or []),
        len(selected_memory.get("summaries", []) or [])
    )

    logger.info(
        "Follow-up synthesis inputs | intent=%s | synthesis_mode=%s | requires_research=%s | memory_scope=%s",
        intent,
        synthesis_mode,
        requires_research,
        memory_scope
    )

    logger.info(
        "Follow-up synthesis query inputs | user_query=%s | research_query=%s",
        user_query[:300],
        research_query[:300]
    )

    logger.info(
        "Follow-up synthesis instruction inputs | context_instruction=%s | format_instruction=%s",
        str(context_instruction or "")[:500],
        str(format_instruction or "")[:500]
    )
    
    try:
        # Extract previous response
        previous_response = extract_previous_response(selected_memory.get('short_term', []))

        # Collect normalized sources from web, KB, and curated results.
        # This becomes the single source of truth for:
        # - prompt context
        # - citation metadata
        # - deterministic Sources section
        sources = collect_sources_from_results(
            web_results=web_results,
            kb_results=kb_results,
            curated_results=curated_results
        )

        # Build context from normalized sources.
        # Source numbering here matches citation metadata exactly.
        new_context = build_context_from_sources(sources)

        # Build citations from the same normalized sources.
        citations = extract_citations_from_sources(sources)

        # Build combined synthesis prompt
        facts = format_facts_for_synthesis(
            selected_memory.get("long_term_facts", [])
        )

        preferences = extract_user_preferences(
            selected_memory.get("preferences", [])
        )

        prompt_bundle = build_synthesizer_prompt_from_aws(
            user_query=user_query,
            research_query=research_query,
            intent=intent,
            synthesis_mode=synthesis_mode,
            requires_research=requires_research,
            memory_scope=memory_scope,
            context_instruction=context_instruction,
            format_instruction=format_instruction,
            facts=facts,
            preferences=preferences,
            previous_response=previous_response,
            research_context=new_context
        )

        synthesis_text = call_llm_for_synthesis(
            prompt=prompt_bundle["user_prompt"],
            system_prompt=prompt_bundle["system_prompt"]
        )
        
        # Remove any LLM-generated Sources section and append deterministic sources.
        synthesis_text = finalize_synthesis_text(
            synthesis_text=synthesis_text,
            citations=citations
        )

        web_sources_count = len(web_results or [])

        kb_sources_count = 0
        if kb_results and kb_results.get("status") == "success":
            kb_sources_count = len(kb_results.get("sources") or kb_results.get("results") or [])

        curated_sources_count = 0
        if curated_results and curated_results.get("status") == "success":
            curated_sources_count = len(curated_results.get("sources") or curated_results.get("results") or [])

        return {
            'status': 'success',
            'message': 'Combined synthesis completed',
            'synthesis_text': synthesis_text,
            'citations': citations,
            'metadata': {
                'intent': intent,
                'synthesis_mode': synthesis_mode,
                'requires_research': requires_research,
                'memory_scope': memory_scope,
                'research_query': research_query,
                'context_instruction': context_instruction,
                'format_instruction': format_instruction,
                'planner_reason': planner_reason,
                'prompt_id': prompt_bundle.get("prompt_id"),
                'prompt_version': prompt_bundle.get("version"),
                'prompt_variant': prompt_bundle.get("variant"),
                'new_sources_count': len(citations),
                'web_sources_count': web_sources_count,
                'kb_sources_count': kb_sources_count,
                'curated_sources_count': curated_sources_count
            }
        }
        
    except Exception as e:
        logger.error(f"Error in combined synthesis: {str(e)}", exc_info=True)
        error_text = (
            "I'm sorry, but I could not complete the combined synthesis due to an internal error. "
            f"Error: {str(e)}"
        )
        return {
            'status': 'error',
            'message': f'Combined synthesis failed: {str(e)}',
            'synthesis_text': error_text,
            'citations': [],
            'metadata': {
                'error': str(e),
                'error_type': type(e).__name__
            }
        }


def synthesize_new_question(
    user_query: str,
    research_query: str,
    intent: str,
    synthesis_mode: str,
    requires_research: Optional[bool],
    memory_scope: Optional[List[str]],
    context_instruction: Optional[str],
    format_instruction: Optional[str],
    planner_reason: Optional[str],
    web_results: List[Dict[str, Any]],
    kb_results: Optional[Dict[str, Any]],
    curated_results: Optional[Dict[str, Any]],
    selected_memory: Dict[str, Any]
    ) -> Dict[str, Any]:
    """
    Full synthesis for new question
    
    Args:
        user_query: User's query
        web_results: Web search results
        kb_results: KB results
        curated_results: Curated results
        selected_memory: Full memory (for preferences)
        
    Returns:
        Synthesis result
    """
    logger.info("Synthesizing new question")

    logger.info(
        "New question selected memory | short_term=%s | facts=%s | preferences=%s | summaries=%s",
        len(selected_memory.get("short_term", []) or []),
        len(selected_memory.get("long_term_facts", []) or []),
        len(selected_memory.get("preferences", []) or []),
        len(selected_memory.get("summaries", []) or [])
    )

    logger.info(
        "New question synthesis inputs | intent=%s | synthesis_mode=%s | requires_research=%s | memory_scope=%s",
        intent,
        synthesis_mode,
        requires_research,
        memory_scope
    )

    logger.info(
        "New question synthesis query inputs | user_query=%s | research_query=%s",
        user_query[:300],
        research_query[:300]
    )
    
    try:
        # Collect normalized sources from web, KB, and curated results.
        # This becomes the single source of truth for:
        # - prompt context
        # - citation metadata
        # - deterministic Sources section
        sources = collect_sources_from_results(
            web_results=web_results,
            kb_results=kb_results,
            curated_results=curated_results
        )

        # Build context from normalized sources.
        # Source numbering here matches citation metadata exactly.
        context = build_context_from_sources(sources)

        # Build citations from the same normalized sources.
        citations = extract_citations_from_sources(sources)

        # Check for user preferences in long-term memory.
        preferences = extract_user_preferences(selected_memory.get('preferences', []))

        # Build synthesis prompt.
        facts = format_facts_for_synthesis(
        selected_memory.get("long_term_facts", [])
        )

        prompt_bundle = build_synthesizer_prompt_from_aws(
            user_query=user_query,
            research_query=research_query,
            intent=intent,
            synthesis_mode=synthesis_mode,
            requires_research=requires_research,
            memory_scope=memory_scope,
            context_instruction=context_instruction,
            format_instruction=format_instruction,
            facts=facts,
            preferences=preferences,
            previous_response="",
            research_context=context
        )

        synthesis_text = call_llm_for_synthesis(
            prompt=prompt_bundle["user_prompt"],
            system_prompt=prompt_bundle["system_prompt"]
        )

        # Remove any LLM-generated Sources section and append deterministic sources.
        synthesis_text = finalize_synthesis_text(
            synthesis_text=synthesis_text,
            citations=citations
        )

        web_sources_count = len(web_results or [])

        kb_sources_count = 0
        if kb_results and kb_results.get("status") == "success":
            kb_sources_count = len(kb_results.get("sources") or kb_results.get("results") or [])

        curated_sources_count = 0
        if curated_results and curated_results.get("status") == "success":
            curated_sources_count = len(curated_results.get("sources") or curated_results.get("results") or [])

        return {
            'status': 'success',
            'message': 'Synthesis completed',
            'synthesis_text': synthesis_text,
            'citations': citations,
            'metadata': {
                'intent': intent,
                'synthesis_mode': synthesis_mode,
                'requires_research': requires_research,
                'memory_scope': memory_scope,
                'research_query': research_query,
                'context_instruction': context_instruction,
                'format_instruction': format_instruction,
                'planner_reason': planner_reason,
                'sources_count': len(citations),
                'web_sources_count': web_sources_count,
                'kb_sources_count': kb_sources_count,
                'curated_sources_count': curated_sources_count,
                'prompt_id': prompt_bundle.get("prompt_id"),
                'prompt_version': prompt_bundle.get("version"),
                'prompt_variant': prompt_bundle.get("variant"),
            }
        }
        
    except Exception as e:
        logger.error(f"Error in new question synthesis: {str(e)}", exc_info=True)
        error_text = (
            "I'm sorry, but I could not complete the synthesis due to an internal error. "
            f"Error: {str(e)}"
        )
        return {
            'status': 'error',
            'message': f'Synthesis failed: {str(e)}',
            'synthesis_text': error_text,
            'citations': [],
            'metadata': {
                'error': str(e),
                'error_type': type(e).__name__
            }
        }


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def clean_title(value: Any) -> str:
    """
    Normalize source titles for citation metadata and Sources section.

    Converts HTML entities such as:
    - &amp; -> &
    - &quot; -> "
    - &lt; -> <
    - &gt; -> >
    """
    title = str(value or "Untitled Source").strip()

    if not title:
        return "Untitled Source"

    # Decode repeatedly to handle double-encoded values like &amp;amp;
    for _ in range(3):
        decoded = html.unescape(title)
        if decoded == title:
            break
        title = decoded

    return " ".join(title.split())

def clean_url(value: Any) -> str:
    """
    Normalize source URLs so citation metadata and Sources section store plain URLs only.

    Handles:
    - plain URLs
    - HTML anchor tags like <a href="https://example.com">...</a>
    - HTML entities such as &quot; and &amp;quot;
    - newline/source-number artifacts
    """
    url = str(value or "").strip()

    if not url:
        return ""

    # Decode common HTML entities, including double-encoded values.
    for _ in range(3):
        decoded = html.unescape(url)
        if decoded == url:
            break
        url = decoded

    # If URL is an HTML anchor, extract href value.
    href_match = re.search(
        r'href\s*=\s*[^"\']+["\']',
        url,
        flags=re.IGNORECASE
    )

    if href_match:
        href_value = href_match.group(1).strip()

        href_url_match = re.search(r'https?://[^\s<>"\']+', href_value)
        if href_url_match:
            return href_url_match.group(0).strip().rstrip('",.;)')

        return href_value.strip().rstrip('",.;)')

    # Otherwise extract the first http/https URL from the text.
    url_match = re.search(r'https?://[^\s<>"\']+', url)
    if url_match:
        return url_match.group(0).strip().rstrip('",.;)')

    # Fallback: keep first whitespace-delimited token.
    return re.split(r"\s+", url)[0].strip().rstrip('",.;)')


def truncate_text(text: Any, max_chars: int = 3000) -> str:
    """
    Normalize and truncate source content for synthesis context.
    """
    value = str(text or "").strip()

    if max_chars > 0 and len(value) > max_chars:
        return value[:max_chars] + "\n\n...[truncated]"

    return value


def collect_sources_from_results(
    web_results: List[Dict[str, Any]],
    kb_results: Optional[Dict[str, Any]],
    curated_results: Optional[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    Collect web, KB, and curated sources into one normalized list.

    This list becomes the single source of truth for:
    - context source numbering
    - citation metadata
    - deterministic Sources section

    This prevents the LLM from seeing Source 9 while metadata only has Source 8.
    """
    sources = []
    seen = set()

    def add_source(
        source_type: str,
        title: str,
        url: str,
        content: str,
        relevance_score: Any = None
    ) -> None:
        normalized_title = clean_title(title)
        clean_source_url = clean_url(url)
        clean_content = truncate_text(content, 3000)

        dedupe_key = (
            source_type,
            normalized_title.lower(),
            clean_source_url.lower()
        )

        if dedupe_key in seen:
            return

        seen.add(dedupe_key)

        sources.append({
            "source_number": len(sources) + 1,
            "title": normalized_title,
            "url": clean_source_url,
            "type": source_type,
            "content": clean_content,
            "relevance_score": relevance_score
        })

    # Web results
    for result in web_results or []:
        add_source(
            source_type="web_search",
            title=result.get("title", "No title"),
            url=result.get("url", ""),
            content=result.get("content", "") or result.get("summary", "")
        )

    # Knowledge Base results
    if kb_results and kb_results.get("status") == "success":
        kb_sources = (
            kb_results.get("sources")
            or kb_results.get("results")
            or []
        )

        for source in kb_sources:
            add_source(
                source_type="knowledge_base",
                title=source.get("title", "Untitled KB Document"),
                url=source.get("url", ""),
                content=source.get("summary", "") or source.get("content", ""),
                relevance_score=source.get("relevance_score", "")
            )

    # Curated URL results
    if curated_results and curated_results.get("status") == "success":
        curated_sources = (
            curated_results.get("sources")
            or curated_results.get("results")
            or []
        )

        for source in curated_sources:
            add_source(
                source_type="curated_url",
                title=source.get("title", "Curated Source"),
                url=source.get("url", ""),
                content=source.get("content", "") or source.get("summary", "")
            )

    return sources


def build_context_from_sources(sources: List[Dict[str, Any]]) -> str:
    """
    Build synthesis context from normalized sources.

    Source numbering here exactly matches citation metadata.
    """
    context_parts = []

    if not sources:
        return ""

    context_parts.append("## Research Sources\n\n")

    for source in sources:
        source_number = source.get("source_number")
        title = source.get("title", "Untitled Source")
        url = source.get("url", "")
        source_type = source.get("type", "source")
        content = source.get("content", "")
        relevance_score = source.get("relevance_score", "")

        context_parts.append(f"### Source {source_number}: {title}\n")
        context_parts.append(f"Type: {source_type}\n")

        if url:
            context_parts.append(f"URL: {url}\n")

        if relevance_score not in ("", None):
            context_parts.append(f"Relevance score: {relevance_score}\n")

        context_parts.append(f"Content: {content}\n\n")

    return "".join(context_parts)


def extract_citations_from_sources(
    sources: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    Build citation metadata from normalized sources.
    """
    citations = []

    for source in sources or []:
        citations.append({
            "source_number": source.get("source_number"),
            "title": source.get("title", "Untitled Source"),
            "url": source.get("url", ""),
            "type": source.get("type", "source")
        })

    return citations


def strip_sources_section(text: str) -> str:
    """
    Remove any LLM-generated Sources section.

    We append a deterministic Sources section separately to avoid malformed
    source formatting such as '[7 Title' or missing brackets.
    """
    if not text:
        return ""

    pattern = r"\n\s*##\s+Sources\s*\n.*$"

    cleaned = re.sub(
        pattern,
        "",
        text,
        flags=re.IGNORECASE | re.DOTALL
    ).strip()

    return cleaned


def append_deterministic_sources_section(
    text: str,
    citations: List[Dict[str, Any]]
) -> str:
    """
    Append a clean Sources section from citation metadata.
    """
    if not citations:
        return text.strip()

    lines = [text.strip(), "", "## Sources", ""]

    for citation in citations:
        source_number = citation.get("source_number")
        title = citation.get("title", "Untitled Source")
        url = clean_url(citation.get("url", ""))

        lines.append(f"[{source_number}] {title}")

        if url:
            lines.append(f"    {url}")

        lines.append("")

    return "\n".join(lines).strip()


def finalize_synthesis_text(
    synthesis_text: str,
    citations: List[Dict[str, Any]]
) -> str:
    """
    Final cleanup for LLM output.

    - Handles None safely
    - Removes LLM-generated Sources section
    - Appends deterministic Sources section from metadata
    """
    safe_text = str(synthesis_text or "").strip()

    cleaned_text = strip_sources_section(safe_text)
    return append_deterministic_sources_section(cleaned_text, citations)

def extract_previous_response(short_term: List[Dict[str, Any]]) -> str:
    """
    Extract the last assistant response from short-term memory.

    Handles role values from AWS AgentCore Memory:
    - ASSISTANT
    - assistant
    - USER
    - user
    """
    for event in reversed(short_term or []):
        role = str(event.get('role', '')).lower()
        if role == 'assistant':
            return event.get('content', '')
    return ""

def format_facts_for_synthesis(facts_memory: List[Any]) -> str:
    """
    Format selected long-term facts for synthesis.
    These should be used only when directly relevant to the current query.
    """
    facts = []

    for item in facts_memory or []:
        if isinstance(item, dict):
            content = item.get("content", "")
        else:
            content = str(item)

        content = str(content or "").strip()

        if content:
            facts.append(content)

    if facts:
        return "Relevant long-term facts:\n" + "\n".join(f"- {fact}" for fact in facts)

    return ""

def extract_user_preferences(preferences_memory: List[Any]) -> str:
    """
    Extract user preferences from selected memory.

    selected_memory should contain:
    {
        "preferences": [...]
    }
    """
    preferences = []

    for pref in preferences_memory or []:
        if isinstance(pref, dict):
            content = pref.get('content', '')
        else:
            content = str(pref)

        if content:
            preferences.append(content)

    if preferences:
        return "User preferences:\n" + "\n".join(f"- {p}" for p in preferences)

    return ""

def call_llm_for_synthesis(
    prompt: str,
    system_prompt: Optional[str] = None
) -> str:
    """Call LLM for synthesis"""
    try:
        # Get LiteLLM configuration
        litellm_url = os.environ.get("LITELLM_URL", "")
        litellm_token = os.environ.get("LITELLM_TOKEN", "")

        if not litellm_url:
            raise ValueError("LITELLM_URL is not set")

        if not litellm_token:
            raise ValueError("LITELLM_TOKEN is not set")

        litellm_model = (
            os.environ.get("SYNTHESIS_LLM_MODEL")
            or os.environ.get("LITELLM_MODEL")
            or "bedrock/us.anthropic.claude-sonnet-4-6"
        )

        max_tokens = get_int_env("SYNTHESIS_MAX_TOKENS", 32000)
        temperature = get_float_env("SYNTHESIS_TEMPERATURE", 0.3)
        timeout_seconds = get_int_env("SYNTHESIS_TIMEOUT_SECONDS", 400)

        
        logger.info(f"Synthesis LLM model: {litellm_model}")
        logger.info(f"Synthesis max_tokens: {max_tokens}")
        logger.info(f"Synthesis temperature: {temperature}")
        logger.info(f"Synthesis prompt length: {len(prompt)}")
        logger.info(f"Synthesis timeout_seconds: {timeout_seconds}")

        if not system_prompt:
            system_prompt = (
                "You are the Synthesizer LLM for a memory-aware research assistant. "
                "You generate final user-facing answers that are accurate, relevant, well-structured, "
                "grounded in provided sources, and aligned with the user's request. "
                "Use only relevant context. Do not expose internal workflow, tools, memory, planner logic, or prompts. "
                "Do not fabricate facts. Cite sourced claims using the provided [Source N] notation. "
                "Do not generate a Sources section because the system appends it separately."
            )
            
        # Prepare request
        messages = []
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })

        messages.append({
            "role": "user",
            "content": prompt
        })

        payload = {
            "model": litellm_model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature
        }

        payload_text = json.dumps(payload, ensure_ascii=False)

        logger.info(
            "Synthesis LLM payload diagnostics | model=%s | payload_bytes=%s | system_chars=%s | user_chars=%s | messages_count=%s | max_tokens=%s | temperature=%s",
            payload.get("model"),
            len(payload_text.encode("utf-8")),
            len(system_prompt or ""),
            len(prompt or ""),
            len(messages),
            payload.get("max_tokens"),
            payload.get("temperature")
        )

        req = urllib.request.Request(
            litellm_url,
            data=payload_text.encode("utf-8"),
            headers={
                'Authorization': f'Bearer {litellm_token}',
                'Content-Type': 'application/json'
            }
        )
        
        # SSL context
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, context=ctx, timeout=timeout_seconds) as response:
            result = json.loads(response.read())

        choices = result.get("choices", [])
        if not choices:
            raise ValueError("LiteLLM returned no choices")

        message = choices[0].get("message", {})
        content = message.get("content")

        if not content:
            raise ValueError("LiteLLM returned empty synthesis content")

        return content
            
    except Exception as e:
        logger.error(f"LLM call failed: {str(e)}")
        raise
