"""
CA Workbench Knowledge Base Tool
"""

__version__ = "1.0.0"
