"""
AWS Bedrock Knowledge Base retrieval tool for CA Workbench.

Phase 1 implementation:
- Uses AWS Bedrock Knowledge Base retrieve API
- Uses HYBRID retrieval with semantic fallback
- Builds semantic query variants from the Planner research_query
- Supports optional LLM query enrichment
- Supports optional soft theme metadata mapping
- No reranker in Phase 1
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import logging
import os
import re
import ssl
import urllib.request
import urllib.error

import boto3

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def clean_source_url(value: Any) -> str:
    """
    Normalize source URLs.

    Removes embedded newline/source-number artifacts such as:
    https://...pdf\n\n[7
    """
    url = str(value or "").strip()

    if not url:
        return ""

    # Keep only the first whitespace-delimited token.
    # SharePoint URLs encode spaces as %20, so this is safe.
    url = re.split(r"\s+", url)[0].strip()

    return url

# ---------------------------------------------------------------------------
# Environment helpers
# ---------------------------------------------------------------------------

def get_int_env(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid integer value for {name}. Using default: {default}")
        return default


def get_float_env(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid float value for {name}. Using default: {default}")
        return default


def get_bool_env(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


def get_litellm_config() -> Dict[str, str]:
    return {
        "url": os.environ.get(
            "LITELLM_URL",
            "https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions"
        ),
        "token": (
            os.environ.get("LITELLM_TOKEN")
            or os.environ.get("BEDROCK_BEARER_TOKEN")
            or os.environ.get("AWS_BEARER_TOKEN_BEDROCK")
            or ""
        ),
        "model": (
            os.environ.get("KB_LLM_MODEL")
            or os.environ.get("PLANNER_LLM_MODEL")
            or os.environ.get("LITELLM_MODEL")
            or "bedrock/us.anthropic.claude-sonnet-4-6"
        )
    }


# ---------------------------------------------------------------------------
# JSON/LLM helpers
# ---------------------------------------------------------------------------

def extract_json_from_llm_response(raw: str) -> Optional[Any]:
    """
    Parse JSON from an LLM response.

    Handles:
    - Raw JSON
    - ```json fenced JSON
    - Extra prose around JSON
    """
    if not raw:
        return None

    text = raw.strip()

    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].strip().startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()

    try:
        return json.loads(text)
    except Exception:
        pass

    for open_char, close_char in (("{", "}"), ("[", "]")):
        start = text.find(open_char)
        end = text.rfind(close_char)
        if start != -1 and end != -1 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except Exception:
                continue

    return None


def call_litellm_json(
    prompt: str,
    max_tokens: int,
    timeout_seconds: int,
    temperature: float = 0.0
) -> Optional[Any]:
    """
    Minimal LiteLLM JSON caller.
    Non-fatal: returns None on any error.
    """
    cfg = get_litellm_config()

    if not cfg["token"]:
        logger.warning("KB LLM call skipped because LiteLLM token is not configured")
        return None

    try:
        logger.info(f"KB LLM model: {cfg['model']}")
        logger.info(f"KB LLM max_tokens: {max_tokens}")
        logger.info(f"KB LLM timeout_seconds: {timeout_seconds}")

        payload = {
            "model": cfg["model"],
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        headers = {
            "Authorization": f"Bearer {cfg['token']}",
            "Content-Type": "application/json",
        }

        req = urllib.request.Request(
            cfg["url"],
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST"
        )

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, context=ctx, timeout=timeout_seconds) as response:
            result = json.loads(response.read().decode("utf-8"))

        raw = (
            result.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "")
            .strip()
        )

        return extract_json_from_llm_response(raw)

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:1000]
        logger.warning(f"KB LLM HTTP error {e.code}: {body}")
        return None

    except Exception as e:
        logger.warning(f"KB LLM call failed non-fatally: {str(e)}")
        return None


# ---------------------------------------------------------------------------
# Semantic query helpers
# ---------------------------------------------------------------------------

def extract_semantic_signals(
    topic: str,
    background: str,
    use_case: str,
    category: str,
    jurisdiction: str = ""
) -> Dict[str, str]:
    """
    Extract semantic KB retrieval signals.

    For current chatbot flow, topic/background are usually the Planner research_query.
    """
    timeout_seconds = get_int_env("KB_LLM_TIMEOUT_SECONDS", 60)
    max_tokens = get_int_env("KB_SIGNAL_MAX_TOKENS", 300)

    if topic or background:
        prompt = f"""
You are a semantic signal extractor for a document vector retrieval system.

Given the raw user/research input below, extract only the domain-relevant semantic content that would help retrieve matching documents from a knowledge base.

Topic:
{topic or "N/A"}

Background:
{background or "N/A"}

Jurisdiction:
{jurisdiction or "N/A"}

Use case:
{use_case or "N/A"}

Category:
{category or "N/A"}

Extract:
1. topic_core: 3 to 12 words capturing the core subject. Preserve compound domain concepts.
2. background_signal: up to 150 characters of domain-relevant facts from the background.

Rules:
- Remove generic words like tell me, explain, current, latest, details, document, submission, about.
- Keep company names, regulation names, authorities, product names, policy terms, key acronyms, and domain concepts.
- Return ONLY JSON with exactly these keys:
  {{
    "topic_core": "...",
    "background_signal": "..."
  }}
"""

        result = call_litellm_json(
            prompt=prompt,
            max_tokens=max_tokens,
            timeout_seconds=timeout_seconds,
            temperature=0.0
        )

        if isinstance(result, dict) and result.get("topic_core"):
            topic_core = str(result.get("topic_core", "")).strip()
            background_signal = str(result.get("background_signal", "")).strip()

            logger.info(
                f"KB semantic signals | topic_core='{topic_core}' | "
                f"background_signal='{background_signal}'"
            )

            return {
                "topic_core": topic_core,
                "background_signal": background_signal
            }

    # Regex fallback
    stopwords = {
        "a", "an", "the", "for", "of", "in", "on", "at", "to", "with",
        "and", "or", "but", "is", "are", "was", "were", "be", "been",
        "about", "regarding", "related", "concerning", "tell", "me",
        "explain", "current", "latest", "details", "add", "also"
    }

    tokens = re.split(r"[\s,;:()\-_/]+", (topic or "").lower())
    topic_core = " ".join(
        token for token in tokens
        if token and token not in stopwords and len(token) > 2
    )

    background_signal = re.sub(r"\s+", " ", background or "").strip()[:150]

    return {
        "topic_core": topic_core,
        "background_signal": background_signal
    }


def derive_intent(use_case: str, category: str) -> str:
    intent_map = {
        "submission": "regulatory submission compliance",
        "report": "policy analysis report",
        "communication": "stakeholder communication",
        "response": "regulatory response",
        "application": "regulatory application",
        "representation": "industry representation",
        "briefing": "policy briefing",
        "comment": "public comment regulatory",
        "appeal": "regulatory appeal",
        "petition": "regulatory petition",
        "answer": "research answer",
        "chat_research": "research answer",
    }

    combined = f"{use_case} {category}".lower()

    for key, value in intent_map.items():
        if key in combined:
            return value

    return (use_case or category or "research answer").strip()


def derive_entity(target_audience: str) -> str:
    entity_map = {
        "cbic": "customs excise authority",
        "gst": "goods services tax authority",
        "mohfw": "health ministry regulator",
        "ministry of health": "health ministry regulator",
        "who": "world health organization international",
        "cpcb": "environment pollution control authority",
        "fssai": "food safety standards authority",
        "sebi": "securities exchange board regulator",
        "rbi": "reserve bank central authority",
        "parliament": "legislative authority",
        "committee": "parliamentary standing committee",
        "ministry": "government ministry authority",
        "department": "government department",
        "tribunal": "judicial regulatory tribunal",
    }

    lower_value = (target_audience or "").lower()

    for key, value in entity_map.items():
        if key in lower_value:
            return value

    return (target_audience or "").strip()


def llm_enrich_queries(
    topic_core: str,
    intent: str,
    entity: str,
    jurisdiction: str,
    background_signal: str
) -> List:
    """
    Generate up to 2 additional semantic KB queries.
    """
    if not topic_core:
        return []

    timeout_seconds = get_int_env("KB_LLM_TIMEOUT_SECONDS", 60)
    max_tokens = get_int_env("KB_QUERY_ENRICH_MAX_TOKENS", 300)

    prompt = f"""
Generate exactly 2 short semantic search queries for a vector database retrieval task.

Structured input:
- Topic: {topic_core}
- Intent: {intent or "N/A"}
- Target entity: {entity or "N/A"}
- Jurisdiction: {jurisdiction or "N/A"}
- Domain context: {background_signal or "N/A"}

Rules:
- Each query must be 5 to 14 words.
- Reflect domain document meaning, not casual user phrasing.
- Query 1 should be generic and not mention jurisdiction unless essential.
- Query 2 can include jurisdiction/entity if useful.
- Output ONLY a JSON array of 2 strings.
"""

    result = call_litellm_json(
        prompt=prompt,
        max_tokens=max_tokens,
        timeout_seconds=timeout_seconds,
        temperature=0.0
    )

    if isinstance(result, list):
        return [
            str(item).strip()
            for item in result
            if isinstance(item, str) and item.strip()
        ][:2]

    return []


def build_query_candidates(requirements: Dict[str, Any],signals: Dict[str, str]) -> List:
    """
    Build deterministic + LLM-enriched + planned KB queries.
    """
    topic = requirements.get("topic", "")
    background = requirements.get("background", "")
    jurisdiction = requirements.get("jurisdiction", "")
    category = requirements.get("category", "")
    use_case = requirements.get("use_case", "")
    target_audience = requirements.get("target_audience", "")

    topic_core = signals.get("topic_core", "")
    background_signal = signals.get("background_signal", "")
    intent = derive_intent(use_case, category)
    entity = derive_entity(target_audience)

    base_query = " ".join(
        item for item in [
            jurisdiction,
            topic_core,
            background_signal,
            intent,
            entity
        ]
        if item
    ).strip()

    deterministic_queries = [
        base_query,
        " ".join(item for item in [jurisdiction, topic_core, background_signal, intent] if item).strip(),
        " ".join(item for item in [entity, jurisdiction, topic_core, background_signal] if item).strip(),
        " ".join(item for item in [category, intent, jurisdiction, topic_core, background_signal] if item).strip(),
        " ".join(item for item in [topic_core, background_signal, intent] if item).strip(),
        " ".join(item for item in [topic_core, intent, entity, background_signal] if item).strip(),
    ]

    llm_queries = llm_enrich_queries(
        topic_core=topic_core,
        intent=intent,
        entity=entity,
        jurisdiction=jurisdiction,
        background_signal=background_signal
    )

    planned_queries = requirements.get("_planned_queries", []) or []
    if isinstance(planned_queries, str):
        planned_queries = [planned_queries]

    all_queries = deterministic_queries + llm_queries + planned_queries

    seen = set()
    deduped = []

    for query in all_queries:
        if not query:
            continue

        query_clean = str(query).strip()
        query_key = query_clean.lower()

        if query_key and query_key not in seen:
            seen.add(query_key)
            deduped.append(query_clean)

    max_queries = get_int_env("KB_MAX_QUERIES", 8)
    final_queries = deduped[:max_queries]

    logger.info(
        f"KB semantic queries | count={len(final_queries)} | "
        f"deterministic={len([q for q in deterministic_queries if q])} | "
        f"llm={len(llm_queries)} | planned={len(planned_queries)}"
    )

    return final_queries


# ---------------------------------------------------------------------------
# Theme mapping
# ---------------------------------------------------------------------------

def map_kb_theme(topic_core: str, background_signal: str, jurisdiction: str) -> Dict[str, str]:
    """
    Map query to KB theme metadata filters.

    Soft filter only. If filtered retrieval fails, we retry without theme filters.
    """
    if not get_bool_env("KB_THEME_MAPPING_ENABLED", True):
        return {"level_1": "", "level_2": ""}

    if not topic_core:
        return {"level_1": "", "level_2": ""}

    timeout_seconds = get_int_env("KB_LLM_TIMEOUT_SECONDS", 60)
    max_tokens = get_int_env("KB_THEME_MAX_TOKENS", 150)

    prompt = f"""
You are classifying a research query for a knowledge base metadata filter.

Topic:
{topic_core}

Background:
{background_signal[:300]}

Jurisdiction:
{jurisdiction or "N/A"}

LEVEL 1 OPTIONS, pick the single best match:
- Smoke-free products (SFP)/ heated tobacco products (HTP)
- Combustible cigarettes
- Corporate Equity


LEVEL 2 OPTIONS, pick the single best match:
- Regulatory, Product standard system
- Fiscal and Taxes
- Illicit Trade
- Scientific
- Youth Access Prevention
- Sustainability
- Others

Return ONLY JSON:
{{
  "level_1": "...",
  "level_2": "..."
}}

If the topic does not clearly fit, use "Others".
"""

    result = call_litellm_json(
        prompt=prompt,
        max_tokens=max_tokens,
        timeout_seconds=timeout_seconds,
        temperature=0.0
    )

    if not isinstance(result, dict):
        return {"level_1": "", "level_2": ""}

    level_1 = str(result.get("level_1", "")).strip()
    level_2 = str(result.get("level_2", "")).strip()

    if level_1.strip().lower() == "others":
        level_1 = ""

    if level_2.strip().lower() == "others":
        level_2 = ""

    logger.info(f"KB theme mapping | level_1='{level_1}' | level_2='{level_2}'")

    return {
        "level_1": level_1,
        "level_2": level_2
    }


# ---------------------------------------------------------------------------
# Bedrock KB integration
# ---------------------------------------------------------------------------

_bedrock_agent_runtime = None


def get_bedrock_agent_runtime_client():
    global _bedrock_agent_runtime

    if _bedrock_agent_runtime is None:
        region = (
            os.environ.get("KB_REGION")
            or os.environ.get("AWS_REGION")
            or "eu-west-1"
        )

        _bedrock_agent_runtime = boto3.client(
            "bedrock-agent-runtime",
            region_name=region
        )

    return _bedrock_agent_runtime


def search_pmi_knowledge_base(
    query: str,
    max_results: int = 10,
    filters: Optional[Dict[str, Any]] = None,
    jurisdiction: str = "",
    theme_level_1: str = "",
    theme_level_2: str = ""
) -> List[Dict[str, Any]]:
    """
    Search PMI Bedrock Knowledge Base using AWS Bedrock retrieve API.
    """
    if not query or not query.strip():
        return []

    knowledge_base_id = os.environ.get("BEDROCK_KB_ID", "OSJDPJLTNC")
    client = get_bedrock_agent_runtime_client()

    retrieval_config = {
        "vectorSearchConfiguration": {
            "numberOfResults": min(max_results, 25),
            "overrideSearchType": "HYBRID"
        }
    }

    jur = jurisdiction or (filters.get("jurisdiction", "") if filters else "")
    filter_conditions = []

    if jur:
        filter_conditions.append({
            "orAll": [
                {"equals": {"key": "jurisdiction", "value": jur}},
                {"equals": {"key": "jurisdiction", "value": "global"}},
                {"equals": {"key": "jurisdiction", "value": "Global"}},
            ]
        })

    if theme_level_1:
        filter_conditions.append({
            "stringContains": {
                "key": "theme-level-1",
                "value": theme_level_1
            }
        })

    if theme_level_2:
        filter_conditions.append({
            "stringContains": {
                "key": "theme-level-2",
                "value": theme_level_2
            }
        })

    if filter_conditions:
        if len(filter_conditions) == 1:
            retrieval_config["vectorSearchConfiguration"]["filter"] = filter_conditions[0]
        else:
            retrieval_config["vectorSearchConfiguration"]["filter"] = {
                "andAll": filter_conditions
            }

    try:
        try:
            response = client.retrieve(
                knowledgeBaseId=knowledge_base_id,
                retrievalQuery={"text": query},
                retrievalConfiguration=retrieval_config
            )
        except Exception as hybrid_error:
            if retrieval_config["vectorSearchConfiguration"].get("overrideSearchType") == "HYBRID":
                logger.warning(
                    f"Bedrock KB HYBRID retrieve failed. Retrying semantic search. "
                    f"Error: {hybrid_error}"
                )

                retrieval_config["vectorSearchConfiguration"].pop("overrideSearchType", None)

                response = client.retrieve(
                    knowledgeBaseId=knowledge_base_id,
                    retrievalQuery={"text": query},
                    retrievalConfiguration=retrieval_config
                )
            else:
                raise

        raw_results = response.get("retrievalResults", [])

        transformed = []

        for result in raw_results:
            content = result.get("content", {}).get("text", "")
            score = result.get("score", 0.0)
            location = result.get("location", {})
            s3_location = location.get("s3Location", {})
            s3_uri = s3_location.get("uri", "")
            metadata = result.get("metadata", {}) or {}

            # Extract document title from metadata or S3 URI
            doc_title = metadata.get("source-filename", "")

            if not doc_title and s3_uri:
                doc_title = (
                    s3_uri.split("/")[-1]
                    .rsplit(".", 1)[0]
                    .replace("_", " ")
                    .replace("-", " ")
                )

            sharepoint_url = clean_source_url(metadata.get("url", "") or s3_uri)

            transformed.append({
                "content": content,
                "similarity_score": round(float(score), 4),
                "document_title": doc_title,
                "metadata": {
                    "file_name": s3_uri.split("/")[-1] if s3_uri else "",
                    "sharepoint_url": sharepoint_url,
                    "s3_uri": s3_uri,
                    "jurisdiction": metadata.get("jurisdiction", ""),
                    "theme_level_1": metadata.get("theme-level-1", ""),
                    "theme_level_2": metadata.get("theme-level-2", ""),
                    "language": metadata.get("language", "English"),
                    "file_extension": metadata.get("file-extension", ""),
                    "owner": metadata.get("owner", ""),
                    "department": metadata.get("department", ""),
                },
                "sharepoint_url": sharepoint_url
            })

        max_score = max(
            (item.get("similarity_score", 0) for item in transformed),
            default=0
        )

        logger.info(
            f"Bedrock KB query | query='{query[:80]}' | "
            f"results={len(transformed)} | max_score={max_score}"
        )

        return transformed

    except Exception as e:
        logger.error(f"Bedrock KB search failed: {str(e)}", exc_info=True)
        return []


# ---------------------------------------------------------------------------
# Main retrieval function
# ---------------------------------------------------------------------------

def build_requirements_from_query(query: str) -> Dict[str, Any]:
    """
    Current chatbot flow usually provides only Planner research_query.

    We convert that into a flexible requirements object so the same KB logic
    can later support richer structured fields.
    """
    clean_query = (query or "").strip()

    return {
        "topic": clean_query,
        "background": clean_query,
        "jurisdiction": "",
        "category": "chat_research",
        "use_case": "answer",
        "target_audience": "",
        "_planned_queries": [clean_query] if clean_query else []
    }


def retrieve_from_kb(query: str, max_results: int = 5) -> Dict[str, Any]:
    """
    Retrieve relevant documents from PMI Bedrock Knowledge Base.

    Args:
        query: Planner research_query or enhanced query.
        max_results: Maximum final KB sources to return.

    Returns:
        Dictionary with status, results, sources, citations, queries, and metadata.
    """
    try:
        if not query or not query.strip():
            return {
                "status": "success",
                "query": query,
                "results": [],
                "sources": [],
                "citations": [],
                "queries": [],
                "metadata": {
                    "tool": "kb_retrieval",
                    "implementation_status": "active",
                    "message": "Empty query"
                }
            }

        logger.info(f"KB retrieval started for query: {query}")

        kb_vector_max_results = get_int_env("KB_VECTOR_MAX_RESULTS", 15)
        kb_final_max_results = get_int_env("KB_FINAL_MAX_RESULTS", max_results)
        kb_min_score = get_float_env("KB_MIN_SCORE", 0.50)
        kb_source_max_chars = get_int_env("KB_SOURCE_MAX_CHARS", 12000)

        final_limit = max(1, min(max_results, kb_final_max_results))

        requirements = build_requirements_from_query(query)

        signals = extract_semantic_signals(
            topic=requirements.get("topic", ""),
            background=requirements.get("background", ""),
            use_case=requirements.get("use_case", ""),
            category=requirements.get("category", ""),
            jurisdiction=requirements.get("jurisdiction", "")
        )

        theme = map_kb_theme(
            topic_core=signals.get("topic_core", ""),
            background_signal=signals.get("background_signal", ""),
            jurisdiction=requirements.get("jurisdiction", "")
        )

        query_candidates = build_query_candidates(requirements, signals)

        if not query_candidates:
            query_candidates = [query]

        used_query = query_candidates[0]
        kb_results = []
        filters = {}

        jurisdiction = requirements.get("jurisdiction", "")

        # First pass: with soft theme filters if available
        for candidate_query in query_candidates:
            results = search_pmi_knowledge_base(
                query=candidate_query,
                max_results=kb_vector_max_results,
                filters=filters,
                jurisdiction=jurisdiction,
                theme_level_1=theme.get("level_1", ""),
                theme_level_2=theme.get("level_2", "")
            )

            if not results:
                logger.info(f"KB query no results | query='{candidate_query[:80]}'")
                continue

            max_score = max(
                (item.get("similarity_score", 0) for item in results),
                default=0
            )

            logger.info(
                f"KB query result | query='{candidate_query[:80]}' | "
                f"results={len(results)} | max_score={max_score}"
            )

            if max_score >= kb_min_score:
                kb_results = results
                used_query = candidate_query
                logger.info(f"KB hit with theme filters | query='{candidate_query[:80]}'")
                break

        # Fallback pass: if theme filters produced no accepted result, retry without themes
        if not kb_results and (theme.get("level_1") or theme.get("level_2")):
            logger.info("KB fallback: retrying without theme filters")

            for candidate_query in query_candidates:
                results = search_pmi_knowledge_base(
                    query=candidate_query,
                    max_results=kb_vector_max_results,
                    filters=filters,
                    jurisdiction=jurisdiction
                )

                if not results:
                    continue

                max_score = max(
                    (item.get("similarity_score", 0) for item in results),
                    default=0
                )

                if max_score >= kb_min_score:
                    kb_results = results
                    used_query = candidate_query
                    logger.info(f"KB fallback hit | query='{candidate_query[:80]}'")
                    break

        sources = []
        citations = []
        seen_titles = set()

        for index, result in enumerate(kb_results):
            score = float(result.get("similarity_score", 0))

            if score < kb_min_score:
                continue

            doc_name = (
                result.get("document_title")
                or result.get("metadata", {}).get("file_name")
                or f"Document_{index + 1}"
            )

            metadata = result.get("metadata", {}) or {}

            sharepoint_url = (
                result.get("sharepoint_url")
                or metadata.get("sharepoint_url")
                or metadata.get("sharepoint_link")
                or metadata.get("source_url")
                or metadata.get("url")
                or metadata.get("s3_uri")
                or ""
            )

            sharepoint_url = clean_source_url(sharepoint_url)

            if "metadata.json" in str(doc_name).lower() or "metadata.json" in str(sharepoint_url).lower():
                continue

            content = result.get("content", "") or ""

            if kb_source_max_chars > 0 and len(content) > kb_source_max_chars:
                content = content[:kb_source_max_chars] + "\n\n...[truncated]"

            source = {
                "title": doc_name,
                "source": "PMI Knowledge Base",
                "type": "internal_knowledge",
                "date": datetime.now().strftime("%Y-%m-%d"),
                "relevance_score": round(score, 4),
                "summary": content,
                "url": sharepoint_url
            }

            sources.append(source)

            if doc_name not in seen_titles:
                seen_titles.add(doc_name)

                citations.append({
                    "title": doc_name,
                    "url": sharepoint_url,
                    "source_type": "knowledge_base"
                })

            if len(sources) >= final_limit:
                break

        max_score_final = max(
            (item.get("relevance_score", 0) for item in sources),
            default=0
        )

        logger.info(
            f"KB retrieval completed | sources={len(sources)} | "
            f"used_query='{used_query[:80]}' | max_score={max_score_final}"
        )

        return {
            "status": "success",
            "query": query,
            "results": sources,
            "sources": sources,
            "citations": citations,
            "queries": [used_query] + [q for q in query_candidates if q != used_query],
            "metadata": {
                "tool": "kb_retrieval",
                "implementation_status": "active",
                "used_query": used_query,
                "query_count": len(query_candidates),
                "results_count": len(sources),
                "citations_count": len(citations),
                "max_score": max_score_final,
                "min_score": kb_min_score,
                "theme_level_1": theme.get("level_1", ""),
                "theme_level_2": theme.get("level_2", ""),
                "theme_mapping_enabled": get_bool_env("KB_THEME_MAPPING_ENABLED", True),
                "vector_max_results": kb_vector_max_results,
                "final_max_results": final_limit,
                "reranker_enabled": False
            }
        }

    except Exception as e:
        logger.error(f"KB retrieval failed: {str(e)}", exc_info=True)

        return {
            "status": "error",
            "query": query,
            "results": [],
            "sources": [],
            "citations": [],
            "queries": [],
            "error": str(e),
            "metadata": {
                "tool": "kb_retrieval",
                "implementation_status": "active",
                "error": str(e),
                "reranker_enabled": False
            }
        }