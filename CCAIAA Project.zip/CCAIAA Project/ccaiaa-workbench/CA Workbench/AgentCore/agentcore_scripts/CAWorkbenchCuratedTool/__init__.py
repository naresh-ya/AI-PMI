"""
CA Workbench Curated URL Processing Tool
"""

__version__ = "1.0.0"
