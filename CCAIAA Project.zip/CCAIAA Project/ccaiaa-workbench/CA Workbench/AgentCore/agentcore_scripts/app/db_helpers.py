"""
DynamoDB Helper Functions for CA Workbench Chat
Handles all database operations for conversations, messages, and jobs
"""

import boto3
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from decimal import Decimal
import os

# Initialize logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb', region_name='eu-west-1')

# Table references
conversations_table = dynamodb.Table('ChatConversations')
messages_table = dynamodb.Table('ChatMessages')
jobs_table = dynamodb.Table('ChatJobs')

# S3 references for full chat message content
s3_client = boto3.client('s3', region_name='eu-west-1')
CHAT_CONTENT_BUCKET = os.environ.get('CHAT_CONTENT_BUCKET', 'ccaiaa-workbench-dev')
CHAT_CONTENT_PREFIX = os.environ.get('CHAT_CONTENT_PREFIX', 'chat-messages')
CONTENT_PREVIEW_LENGTH = int(os.environ.get('CONTENT_PREVIEW_LENGTH', '3000'))


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def convert_decimals(obj: Any) -> Any:
    """
    Recursively convert Decimal objects to int or float for JSON serialization
    
    Args:
        obj: Object that may contain Decimal values
        
    Returns:
        Object with Decimals converted to int/float
    """
    if isinstance(obj, list):
        return [convert_decimals(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimals(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        # Convert to int if it's a whole number, otherwise float
        if obj % 1 == 0:
            return int(obj)
        else:
            return float(obj)
    else:
        return obj


def build_message_content_s3_key(
    user_id: str,
    conversation_id: str,
    message_id: str,
    role: str
) -> str:
    """
    Build S3 key for storing full message content.

    Structure:
    chat-messages/{user_id}/{conversation_id}/{message_id}/user.txt
    chat-messages/{user_id}/{conversation_id}/{message_id}/assistant.md
    """
    extension = "md" if role == "assistant" else "txt"

    return (
        f"{CHAT_CONTENT_PREFIX}/"
        f"{user_id}/"
        f"{conversation_id}/"
        f"{message_id}/"
        f"{role}.{extension}"
    )


def create_content_preview(content: str, max_length: int = CONTENT_PREVIEW_LENGTH) -> str:
    """
    Create preview text for DynamoDB.
    """
    content = content or ""

    if len(content) <= max_length:
        return content

    return content[:max_length]


def save_message_content_to_s3(
    user_id: str,
    conversation_id: str,
    message_id: str,
    role: str,
    content: str
) -> Dict[str, Any]:
    """
    Save full message content to S3 and return DynamoDB metadata fields.
    """
    content = content or ""

    s3_key = build_message_content_s3_key(
        user_id=user_id,
        conversation_id=conversation_id,
        message_id=message_id,
        role=role
    )

    content_type = "text/markdown" if role == "assistant" else "text/plain"

    s3_client.put_object(
        Bucket=CHAT_CONTENT_BUCKET,
        Key=s3_key,
        Body=content.encode("utf-8"),
        ContentType=content_type
    )

    return {
        "content_preview": create_content_preview(content),
        "content_storage": "S3",
        "content_s3_bucket": CHAT_CONTENT_BUCKET,
        "content_s3_key": s3_key,
        "content_length": len(content),
        "content_truncated": len(content) > CONTENT_PREVIEW_LENGTH
    }


def load_message_content_from_s3(s3_bucket: str, s3_key: str) -> str:
    """
    Load full message content from S3.
    """
    response = s3_client.get_object(
        Bucket=s3_bucket,
        Key=s3_key
    )

    return response["Body"].read().decode("utf-8")

# ============================================================================
# CONVERSATION OPERATIONS
# ============================================================================


def get_conversation(user_id: str, conversation_id: str) -> Optional[Dict[str, Any]]:
    """
    Get a specific conversation
    
    Args:
        user_id: User ID
        conversation_id: Conversation ID
        
    Returns:
        Conversation item or None if not found
    """
    response = conversations_table.get_item(
        Key={
            'user_id': user_id,
            'conversation_id': conversation_id
        }
    )
    return response.get('Item')


def update_conversation(user_id: str, conversation_id: str, **kwargs) -> Dict[str, Any]:
    """
    Update conversation attributes
    
    Args:
        user_id: User ID
        conversation_id: Conversation ID
        **kwargs: Attributes to update (title, last_message_at, message_count, etc.)
        
    Returns:
        Updated conversation item
    """
    timestamp = datetime.now(timezone.utc).isoformat()
    
    # Build update expression with ExpressionAttributeNames for reserved keywords
    update_parts = ['updated_at = :updated']
    attr_values = {':updated': timestamp}
    attr_names = {}
    
    for key, value in kwargs.items():
        attr_name = f'#{key}'
        update_parts.append(f'{attr_name} = :{key}')
        attr_values[f':{key}'] = value
        attr_names[attr_name] = key  # FIX: Protect against DynamoDB reserved keywords
    
    update_expression = 'SET ' + ', '.join(update_parts)
    
    update_params = {
        'Key': {
            'user_id': user_id,
            'conversation_id': conversation_id
        },
        'UpdateExpression': update_expression,
        'ExpressionAttributeValues': attr_values,
        'ReturnValues': 'ALL_NEW'
    }
    
    # Only add ExpressionAttributeNames if we have any
    if attr_names:
        update_params['ExpressionAttributeNames'] = attr_names
    
    response = conversations_table.update_item(**update_params)
    return response.get('Attributes', {})

# ============================================================================
# MESSAGE OPERATIONS
# ============================================================================
def get_messages(conversation_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    """
    Get messages in a conversation, latest first.

    Args:
        conversation_id: Conversation ID
        limit: Maximum number of messages to return

    Returns:
        List of message items, newest first
    """
    response = messages_table.query(
        KeyConditionExpression='conversation_id = :cid',
        ExpressionAttributeValues={
            ':cid': conversation_id
        },
        Limit=limit,
        ScanIndexForward=False  # Newest first
    )
    return response.get('Items', [])

def update_message(
    conversation_id: str,
    message_sort_key: str,
    **kwargs
) -> Dict[str, Any]:
    """
    Update message attributes
    
    Args:
        conversation_id: Conversation ID
        message_sort_key: Message sort key (created_at#message_id)
        **kwargs: Attributes to update
        
    Returns:
        Updated message item
    """
    timestamp = datetime.now(timezone.utc).isoformat()
    
    # Build update expression with ExpressionAttributeNames for reserved keywords
    update_parts = ['updated_at = :updated']
    attr_values = {':updated': timestamp}
    attr_names = {}
    
    for key, value in kwargs.items():
        attr_name = f'#{key}'
        update_parts.append(f'{attr_name} = :{key}')
        attr_values[f':{key}'] = value
        attr_names[attr_name] = key  # FIX: Protect against DynamoDB reserved keywords
    
    update_expression = 'SET ' + ', '.join(update_parts)
    
    update_params = {
        'Key': {
            'conversation_id': conversation_id,
            'message_sort_key': message_sort_key
        },
        'UpdateExpression': update_expression,
        'ExpressionAttributeValues': attr_values,
        'ReturnValues': 'ALL_NEW'
    }
    
    # Only add ExpressionAttributeNames if we have any
    if attr_names:
        update_params['ExpressionAttributeNames'] = attr_names
    
    response = messages_table.update_item(**update_params)
    return response.get('Attributes', {})


# ============================================================================
# JOB OPERATIONS
# ============================================================================
def get_job(job_id: str) -> Optional[Dict[str, Any]]:
    """
    Get a job by ID
    
    Args:
        job_id: Job ID
        
    Returns:
        Job item or None if not found (with Decimals converted)
    """
    response = jobs_table.get_item(
        Key={'job_id': job_id}
    )
    item = response.get('Item')
    if item:
        # Convert Decimal objects to int/float for JSON serialization
        return convert_decimals(item)
    return None


def update_job_status(
    job_id: str,
    status: str,
    **kwargs
) -> Dict[str, Any]:
    """
    Update job status and attributes
    
    Args:
        job_id: Job ID
        status: New status
        **kwargs: Additional attributes to update
        
    Returns:
        Updated job item
    """
    timestamp = datetime.now(timezone.utc).isoformat()
    
    # Log job status update
    logger.info(f"Updating job status: {job_id} -> {status}")
    if kwargs:
        logger.info(f"  Additional attributes: {list(kwargs.keys())}")
    
    # Build update expression
    update_parts = ['#status = :status', 'updated_at = :updated']
    attr_values = {
        ':status': status,
        ':updated': timestamp
    }
    attr_names = {'#status': 'status'}
    
    # Add completion timestamp if completed
    if status == 'COMPLETED':
        update_parts.append('completed_at = :completed')
        attr_values[':completed'] = timestamp
    
    # Add optional attributes with ExpressionAttributeNames to handle reserved keywords
    for key, value in kwargs.items():
        attr_name = f'#{key}'
        update_parts.append(f'{attr_name} = :{key}')
        attr_values[f':{key}'] = value
        attr_names[attr_name] = key  # FIX: Protect against DynamoDB reserved keywords
    
    update_expression = 'SET ' + ', '.join(update_parts)
    
    logger.info(f"  UpdateExpression: {update_expression}")
    
    response = jobs_table.update_item(
        Key={'job_id': job_id},
        UpdateExpression=update_expression,
        ExpressionAttributeNames=attr_names,
        ExpressionAttributeValues=attr_values,
        ReturnValues='ALL_NEW'
    )
    
    logger.info(f"Job status updated successfully: {job_id}")
    return response.get('Attributes', {})
