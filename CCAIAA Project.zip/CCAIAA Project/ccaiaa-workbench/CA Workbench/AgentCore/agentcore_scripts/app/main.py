"""
AWS Bedrock Agent Core Runtime - FastAPI Application with Memory-Aware LangGraph

Compatible with AgentCore Runtime requirements AND Gateway.

Flow:
- Accepts both "input" Gateway format and "prompt" direct format
- Accepts both "sessionId" Gateway format and "session_id" direct format
- Uses memory-aware LangGraph orchestrator
- Returns Gateway-compatible response format
"""

import os
import sys
import json
import time
import logging
import traceback
import re
import html
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone

from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Import memory-aware LangGraph orchestrator
from langgraph_orchestrator.memory_aware_main import orchestrate_request

from app.db_helpers import (
    update_job_status,
    get_messages,
    update_message,
    get_conversation,
    update_conversation,
    save_message_content_to_s3
)



# ----------------------------------------------------------------------------
# Logging Setup
# ----------------------------------------------------------------------------

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s"
)

logger = logging.getLogger("ca-workbench-agentcore")
logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))


def safe_truncate(value: Any, max_len: int = 1000) -> str:
    """
    Safely truncate large values for logs.
    """
    try:
        text = value if isinstance(value, str) else json.dumps(value, default=str)
    except Exception:
        text = str(value)

    if len(text) > max_len:
        return text[:max_len] + "...[truncated]"

    return text

def clean_html_url(value: Any) -> str:
    """
    Convert citation URL values into plain URLs.

    Handles cases like:
    <a href="https://example.com" ...>https://example.com</a>

    Returns:
    https://example.com
    """
    if not value:
        return ""

    text = str(value).strip()
    text = html.unescape(text)

    # If value contains an HTML anchor, prefer href value.
    href_match = re.search(r'href=[^"\']+["\']', text)
    if href_match:
        return href_match.group(1).strip()

    # If value contains a raw URL, extract first URL.
    url_match = re.search(r'https?://[^\s"<>\']+', text)
    if url_match:
        return url_match.group(0).strip().rstrip(",")

    return text


def sanitize_citations(citations: Any) -> List[Dict[str, Any]]:
    """
    Sanitize citation objects before storing in S3/DynamoDB.
    Keeps title/type/source_number but cleans URL.
    """
    if not isinstance(citations, list):
        return []

    sanitized = []

    for cite in citations:
        if not isinstance(cite, dict):
            continue

        cleaned = dict(cite)
        cleaned["url"] = clean_html_url(cleaned.get("url", ""))

        sanitized.append(cleaned)

    return sanitized

def log_metadata(metadata: Dict[str, Any]) -> None:
    """
    Log important metadata fields returned from memory-aware workflow.
    """
    if not metadata:
        logger.warning("[AGENTCORE] No metadata returned from workflow")
        return

    logger.info("[AGENTCORE] Workflow metadata summary:")
    logger.info(f"  intent={metadata.get('intent')}")
    logger.info(f"  requires_research={metadata.get('requires_research')}")
    logger.info(f"  memory_scope={metadata.get('memory_scope')}")
    logger.info(f"  research_query={safe_truncate(metadata.get('research_query'), 500)}")
    logger.info(f"  synthesis_mode={metadata.get('synthesis_mode')}")
    logger.info(f"  format_instruction={safe_truncate(metadata.get('format_instruction'), 500)}")
    logger.info(f"  memory_stored={metadata.get('memory_stored')}")
    logger.info(f"  synthesis_status={metadata.get('synthesis_status')}")
    logger.info(f"  powered_by={metadata.get('powered_by')}")

    steps = metadata.get("steps", [])
    errors = metadata.get("errors", [])

    logger.info(f"  steps_count={len(steps) if isinstance(steps, list) else 0}")
    logger.info(f"  errors_count={len(errors) if isinstance(errors, list) else 0}")

    if steps:
        logger.info(f"  steps={safe_truncate(steps, 1500)}")

    if errors:
        logger.error(f"  errors={safe_truncate(errors, 1500)}")


# ----------------------------------------------------------------------------
# FastAPI App
# ----------------------------------------------------------------------------

app = FastAPI(title="CA Workbench AgentCore Runtime with Memory-Aware LangGraph")

# ----------------------------------------------------------------------------
# Background Job Lifecycle Tracking
# ----------------------------------------------------------------------------
ACTIVE_BACKGROUND_JOBS = set()

def mark_job_busy(job_id: str) -> None:
    """
    Mark a background job as active.
    Used by /ping to report HealthyBusy.
    """
    if job_id:
        ACTIVE_BACKGROUND_JOBS.add(job_id)
        logger.info(
            f"[AGENTCORE] Marked job busy: {job_id}. "
            f"Active jobs={len(ACTIVE_BACKGROUND_JOBS)}"
        )


def mark_job_done(job_id: str) -> None:
    """
    Mark a background job as completed/failed.
    Used by /ping to return Healthy when no jobs are active.
    """
    if job_id:
        ACTIVE_BACKGROUND_JOBS.discard(job_id)
        logger.info(
            f"[AGENTCORE] Marked job done: {job_id}. "
            f"Active jobs={len(ACTIVE_BACKGROUND_JOBS)}"
        )

# ----------------------------------------------------------------------------
# Environment Configuration
# ----------------------------------------------------------------------------

LITELLM_TOKEN = os.environ.get("LITELLM_TOKEN", "")
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY", "")
LITELLM_URL = os.environ.get("LITELLM_URL", "")
LITELLM_MODEL = os.environ.get("LITELLM_MODEL", "")
AWS_REGION = os.environ.get("AWS_REGION", "eu-west-1")
AWS_MEMORY_ID = os.environ.get("AWS_MEMORY_ID", "CA_Workbench_Memory-62CKDsBH4r")

# Model configuration
PLANNER_LLM_MODEL = os.environ.get("PLANNER_LLM_MODEL", "")
PLANNER_MAX_TOKENS = os.environ.get("PLANNER_MAX_TOKENS", "")
PLANNER_TEMPERATURE = os.environ.get("PLANNER_TEMPERATURE", "")
PLANNER_TIMEOUT_SECONDS = os.environ.get("PLANNER_TIMEOUT_SECONDS", "")

SYNTHESIS_LLM_MODEL = os.environ.get("SYNTHESIS_LLM_MODEL", "")
SYNTHESIS_MAX_TOKENS = os.environ.get("SYNTHESIS_MAX_TOKENS", "")
SYNTHESIS_TEMPERATURE = os.environ.get("SYNTHESIS_TEMPERATURE", "")
SYNTHESIS_TIMEOUT_SECONDS = os.environ.get("SYNTHESIS_TIMEOUT_SECONDS", "")

INTENT_LLM_MODEL = os.environ.get("INTENT_LLM_MODEL", "")
INTENT_MAX_TOKENS = os.environ.get("INTENT_MAX_TOKENS", "")
INTENT_TEMPERATURE = os.environ.get("INTENT_TEMPERATURE", "")
INTENT_TIMEOUT_SECONDS = os.environ.get("INTENT_TIMEOUT_SECONDS", "")

LEGACY_SYNTHESIS_LLM_MODEL = os.environ.get("LEGACY_SYNTHESIS_LLM_MODEL", "")
LEGACY_SYNTHESIS_MAX_TOKENS = os.environ.get("LEGACY_SYNTHESIS_MAX_TOKENS", "")
LEGACY_SYNTHESIS_TEMPERATURE = os.environ.get("LEGACY_SYNTHESIS_TEMPERATURE", "")
LEGACY_SYNTHESIS_TIMEOUT_SECONDS = os.environ.get("LEGACY_SYNTHESIS_TIMEOUT_SECONDS", "")

# Web search configuration
WEB_SEARCH_CANDIDATE_RESULTS = os.environ.get("WEB_SEARCH_CANDIDATE_RESULTS", "")
WEB_MAX_USABLE_SOURCES = os.environ.get("WEB_MAX_USABLE_SOURCES", "")
WEB_EXTRACTION_PARALLELISM = os.environ.get("WEB_EXTRACTION_PARALLELISM", "")
WEB_EXTRACTION_TIMEOUT_SECONDS = os.environ.get("WEB_EXTRACTION_TIMEOUT_SECONDS", "")
WEB_TAVILY_MIN_CONTENT_CHARS = os.environ.get("WEB_TAVILY_MIN_CONTENT_CHARS", "")
WEB_GEMINI_FALLBACK_TIMEOUT_SECONDS = os.environ.get("WEB_GEMINI_FALLBACK_TIMEOUT_SECONDS", "")
WEB_GEMINI_MAX_OUTPUT_TOKENS = os.environ.get("WEB_GEMINI_MAX_OUTPUT_TOKENS", "")
WEB_CONTENT_MAX_CHARS = os.environ.get("WEB_CONTENT_MAX_CHARS", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")


#Kb configuration
BEDROCK_KB_ID = os.environ.get("BEDROCK_KB_ID", "")
KB_REGION = os.environ.get("KB_REGION", "")
KB_LLM_MODEL = os.environ.get("KB_LLM_MODEL", "")
KB_SIGNAL_MAX_TOKENS = os.environ.get("KB_SIGNAL_MAX_TOKENS", "")
KB_QUERY_ENRICH_MAX_TOKENS = os.environ.get("KB_QUERY_ENRICH_MAX_TOKENS", "")
KB_THEME_MAX_TOKENS = os.environ.get("KB_THEME_MAX_TOKENS", "")
KB_LLM_TIMEOUT_SECONDS = os.environ.get("KB_LLM_TIMEOUT_SECONDS", "")
KB_MAX_QUERIES = os.environ.get("KB_MAX_QUERIES", "")
KB_VECTOR_MAX_RESULTS = os.environ.get("KB_VECTOR_MAX_RESULTS", "")
KB_FINAL_MAX_RESULTS = os.environ.get("KB_FINAL_MAX_RESULTS", "")
KB_MIN_SCORE = os.environ.get("KB_MIN_SCORE", "")
KB_THEME_MAPPING_ENABLED = os.environ.get("KB_THEME_MAPPING_ENABLED", "")
KB_SOURCE_MAX_CHARS = os.environ.get("KB_SOURCE_MAX_CHARS", "")

# Set environment variables for downstream tools
os.environ["BEDROCK_BEARER_TOKEN"] = LITELLM_TOKEN
os.environ["TAVILY_API_KEY"] = TAVILY_API_KEY
#test

logger.info("[AGENTCORE] Application starting")
logger.info(f"[AGENTCORE] LOG_LEVEL={LOG_LEVEL}")
logger.info(f"[AGENTCORE] AWS_REGION={AWS_REGION}")
logger.info(f"[AGENTCORE] AWS_MEMORY_ID={AWS_MEMORY_ID}")
logger.info(f"[AGENTCORE] LITELLM_URL set={bool(LITELLM_URL)}")
logger.info(f"[AGENTCORE] LITELLM_MODEL={LITELLM_MODEL}")
logger.info(f"[AGENTCORE] LITELLM_TOKEN set={bool(LITELLM_TOKEN)}")
logger.info(f"[AGENTCORE] TAVILY_API_KEY set={bool(TAVILY_API_KEY)}")

logger.info("[AGENTCORE] Web search configuration:")
logger.info(f"[AGENTCORE] WEB_SEARCH_CANDIDATE_RESULTS={WEB_SEARCH_CANDIDATE_RESULTS or 'not set'}")
logger.info(f"[AGENTCORE] WEB_MAX_USABLE_SOURCES={WEB_MAX_USABLE_SOURCES or 'not set'}")
logger.info(f"[AGENTCORE] WEB_EXTRACTION_PARALLELISM={WEB_EXTRACTION_PARALLELISM or 'not set'}")
logger.info(f"[AGENTCORE] WEB_EXTRACTION_TIMEOUT_SECONDS={WEB_EXTRACTION_TIMEOUT_SECONDS or 'not set'}")
logger.info(f"[AGENTCORE] WEB_TAVILY_MIN_CONTENT_CHARS={WEB_TAVILY_MIN_CONTENT_CHARS or 'not set'}")
logger.info(f"[AGENTCORE] WEB_GEMINI_FALLBACK_TIMEOUT_SECONDS={WEB_GEMINI_FALLBACK_TIMEOUT_SECONDS or 'not set'}")
logger.info(f"[AGENTCORE] WEB_GEMINI_MAX_OUTPUT_TOKENS={WEB_GEMINI_MAX_OUTPUT_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] WEB_CONTENT_MAX_CHARS={WEB_CONTENT_MAX_CHARS or 'not set'}")
logger.info(f"[AGENTCORE] GEMINI_MODEL={GEMINI_MODEL or 'not set'}")
logger.info(f"[AGENTCORE] GEMINI_API_KEY set={bool(GEMINI_API_KEY)}")

#KB configurations logs
logger.info("[AGENTCORE] KB retrieval configuration:")
logger.info(f"[AGENTCORE] BEDROCK_KB_ID={BEDROCK_KB_ID or 'not set'}")
logger.info(f"[AGENTCORE] KB_REGION={KB_REGION or 'not set'}")
logger.info(f"[AGENTCORE] KB_LLM_MODEL={KB_LLM_MODEL or 'not set'}")
logger.info(f"[AGENTCORE] KB_SIGNAL_MAX_TOKENS={KB_SIGNAL_MAX_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] KB_QUERY_ENRICH_MAX_TOKENS={KB_QUERY_ENRICH_MAX_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] KB_THEME_MAX_TOKENS={KB_THEME_MAX_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] KB_LLM_TIMEOUT_SECONDS={KB_LLM_TIMEOUT_SECONDS or 'not set'}")
logger.info(f"[AGENTCORE] KB_MAX_QUERIES={KB_MAX_QUERIES or 'not set'}")
logger.info(f"[AGENTCORE] KB_VECTOR_MAX_RESULTS={KB_VECTOR_MAX_RESULTS or 'not set'}")
logger.info(f"[AGENTCORE] KB_FINAL_MAX_RESULTS={KB_FINAL_MAX_RESULTS or 'not set'}")
logger.info(f"[AGENTCORE] KB_MIN_SCORE={KB_MIN_SCORE or 'not set'}")
logger.info(f"[AGENTCORE] KB_THEME_MAPPING_ENABLED={KB_THEME_MAPPING_ENABLED or 'not set'}")
logger.info(f"[AGENTCORE] KB_SOURCE_MAX_CHARS={KB_SOURCE_MAX_CHARS or 'not set'}")

logger.info("[AGENTCORE] LLM configuration:")
logger.info(f"[AGENTCORE] DEFAULT LITELLM_MODEL={LITELLM_MODEL or 'not set'}")

logger.info(f"[AGENTCORE] PLANNER_LLM_MODEL={PLANNER_LLM_MODEL or 'not set'}")
logger.info(f"[AGENTCORE] PLANNER_MAX_TOKENS={PLANNER_MAX_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] PLANNER_TEMPERATURE={PLANNER_TEMPERATURE or 'not set'}")
logger.info(f"[AGENTCORE] PLANNER_TIMEOUT_SECONDS={PLANNER_TIMEOUT_SECONDS or 'not set'}")

logger.info(f"[AGENTCORE] SYNTHESIS_LLM_MODEL={SYNTHESIS_LLM_MODEL or 'not set'}")
logger.info(f"[AGENTCORE] SYNTHESIS_MAX_TOKENS={SYNTHESIS_MAX_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] SYNTHESIS_TEMPERATURE={SYNTHESIS_TEMPERATURE or 'not set'}")
logger.info(f"[AGENTCORE] SYNTHESIS_TIMEOUT_SECONDS={SYNTHESIS_TIMEOUT_SECONDS or 'not set'}")
logger.info("[AGENTCORE] Synthesis memory limit configuration:")
logger.info(
    f"[AGENTCORE] SYNTHESIS_SHORT_TERM_MEMORY_LIMIT="
    f"{os.environ.get('SYNTHESIS_SHORT_TERM_MEMORY_LIMIT') or 'not set'}"
)
logger.info(
    f"[AGENTCORE] SYNTHESIS_FACTS_MEMORY_LIMIT="
    f"{os.environ.get('SYNTHESIS_FACTS_MEMORY_LIMIT') or 'not set'}"
)
logger.info(
    f"[AGENTCORE] SYNTHESIS_PREFERENCES_MEMORY_LIMIT="
    f"{os.environ.get('SYNTHESIS_PREFERENCES_MEMORY_LIMIT') or 'not set'}"
)
logger.info(
    f"[AGENTCORE] SYNTHESIS_SUMMARIES_MEMORY_LIMIT="
    f"{os.environ.get('SYNTHESIS_SUMMARIES_MEMORY_LIMIT') or 'not set'}"
)

logger.info(f"[AGENTCORE] INTENT_LLM_MODEL={INTENT_LLM_MODEL or 'not set'}")
logger.info(f"[AGENTCORE] INTENT_MAX_TOKENS={INTENT_MAX_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] INTENT_TEMPERATURE={INTENT_TEMPERATURE or 'not set'}")
logger.info(f"[AGENTCORE] INTENT_TIMEOUT_SECONDS={INTENT_TIMEOUT_SECONDS or 'not set'}")

logger.info(f"[AGENTCORE] LEGACY_SYNTHESIS_LLM_MODEL={LEGACY_SYNTHESIS_LLM_MODEL or 'not set'}")
logger.info(f"[AGENTCORE] LEGACY_SYNTHESIS_MAX_TOKENS={LEGACY_SYNTHESIS_MAX_TOKENS or 'not set'}")
logger.info(f"[AGENTCORE] LEGACY_SYNTHESIS_TEMPERATURE={LEGACY_SYNTHESIS_TEMPERATURE or 'not set'}")
logger.info(f"[AGENTCORE] LEGACY_SYNTHESIS_TIMEOUT_SECONDS={LEGACY_SYNTHESIS_TIMEOUT_SECONDS or 'not set'}")


# ----------------------------------------------------------------------------
# Request Model
# ----------------------------------------------------------------------------

class InvocationRequest(BaseModel):
    """
    Request modelinvocation, and Proxy Lambda payload.

    Supported input formats:
    - Gateway: input/sessionId/userId
    - Direct: prompt/session_id/user_id
    - Proxy Lambda: prompt, actorId, namespace, session_id
    """

    # Gateway format
    input: Optional[str] = None
    sessionId: Optional[str] = None
    userId: Optional[str] = None

    # Direct format
    prompt: Optional[str] = None
    session_id: Optional[str] = None
    user_id: Optional[str] = None

    # Proxy Lambda / AgentCore memory fields
    actorId: Optional[str] = None
    namespace: Optional[str] = None
    memory_namespace: Optional[str] = None
    memory_session_id: Optional[str] = None

    # Optional curated URLs
    curated_urls: Optional[List[str]] = None
    
    # Async job fields from Proxy Lambda
    job_id: Optional[str] = None
    conversation_id: Optional[str] = None
    user_message_id: Optional[str] = None
    assistant_message_id: Optional[str] = None


    @property
    def user_input(self):
        """
        Get user input from either Gateway or direct field.
        """
        return self.input or self.prompt or ""

    @property
    def session(self):
        """
        Get session ID from either Gateway, direct field, or memory session field.
        """
        return (
            self.sessionId
            or self.session_id
            or self.memory_session_id
            or f"session-{int(os.times().elapsed * 1000)}"
        )

    @property
    def user(self):
        """
        Get user ID from either Gateway, direct field, or actorId.
        """
        return (
            self.userId
            or self.user_id
            or self.actorId
            or "anonymous"
        )


# ----------------------------------------------------------------------------
# Health Check
# ----------------------------------------------------------------------------

@app.get("/ping")
def ping():
    """
    Health check endpoint required by AgentCore Runtime.

    Returns HealthyBusy while background jobs are running.
    Returns Healthy when runtime is idle.
    """
    
    logger.info(f"[AGENTCORE] /ping called. Active jobs={len(ACTIVE_BACKGROUND_JOBS)}")

    if ACTIVE_BACKGROUND_JOBS:
        return {
            "status": "HealthyBusy",
            "service": "CA Workbench AgentCore Runtime",
            "memory_aware": True,
            "active_jobs": len(ACTIVE_BACKGROUND_JOBS)
        }

    return {
        "status": "Healthy",
        "service": "CA Workbench AgentCore Runtime",
        "memory_aware": True,
        "active_jobs": 0
    }

def process_chat_job_background(request_data: Dict[str, Any]) -> None:
    """
    Background processor for async chat jobs.

    Responsibilities:
    - update job IN_PROGRESS
    - run orchestrate_request(...)
    - update assistant message
    - update job COMPLETED / FAILED
    - update conversation metadata
    """
    request_start = time.time()

    job_id = request_data.get("job_id")
    conversation_id = request_data.get("conversation_id")
    assistant_message_id = request_data.get("assistant_message_id")

    user_query = (
        request_data.get("input")
        or request_data.get("prompt")
        or ""
    )

    session_id = (
        request_data.get("sessionId")
        or request_data.get("session_id")
        or request_data.get("memory_session_id")
    )

    user_id = (
        request_data.get("userId")
        or request_data.get("user_id")
        or request_data.get("actorId")
    )

    curated_urls = request_data.get("curated_urls")

    try:
        logger.info(
            f"[AGENTCORE] Background job started: "
            f"job_id={job_id}, conversation_id={conversation_id}"
        )

        mark_job_busy(job_id)

        update_job_status(
            job_id,
            "IN_PROGRESS",
            started_at=datetime.now(timezone.utc).isoformat()
        )

        workflow_start = time.time()

        logger.info(
            f"[AGENTCORE] Starting orchestration: "
            f"job_id={job_id}, session_id={session_id}, user_id={user_id}"
        )

        result = orchestrate_request(
            user_query=user_query,
            session_id=session_id,
            user_id=user_id,
            curated_urls=curated_urls,
            synthesize=True
        )

        workflow_duration_ms = int((time.time() - workflow_start) * 1000)

        response_text = result.get("text", "")
        metadata = result.get("metadata", {}) or {}

        # Sanitize citation URLs before storing or appending sources
        citations = sanitize_citations(metadata.get("citations", []) or [])
        metadata["citations"] = citations

        if citations and "## Sources" not in response_text:
            response_text += "\n\n## Sources\n"
            for cite in citations:
                response_text += f"\n[{cite.get('source_number')}] {cite.get('title')}\n"
                response_text += f"    {cite.get('url')}\n"

        total_duration_ms = int((time.time() - request_start) * 1000)

        metadata["runtime_diagnostics"] = {
            "workflow_duration_ms": workflow_duration_ms,
            "total_duration_ms": total_duration_ms,
            "response_length": len(response_text),
            "citations_count": len(citations)
        }

        messages = get_messages(conversation_id, limit=100)
        assistant_message = next(
            (m for m in messages if m.get("message_id") == assistant_message_id),
            None
        )

        if assistant_message:
            # Store full assistant response in S3
            assistant_content_metadata = save_message_content_to_s3(
                user_id=user_id,
                conversation_id=conversation_id,
                message_id=assistant_message_id,
                role="assistant",
                content=response_text
            )

            # Store preview + S3 pointer in DynamoDB
            update_message(
                conversation_id=conversation_id,
                message_sort_key=assistant_message["message_sort_key"],
                content=assistant_content_metadata["content_preview"],
                status="COMPLETED",
                citations=citations,
                metadata={
                    "intent": metadata.get("intent"),
                    "requires_research": metadata.get("requires_research"),
                    "synthesis_mode": metadata.get("synthesis_mode"),
                    "use_tools": metadata.get("use_tools"),
                    "memory_scope": metadata.get("memory_scope"),
                    "runtime_diagnostics": metadata.get("runtime_diagnostics", {}),
                    "citations": citations,
                    "errors": metadata.get("errors", [])
                },
                **assistant_content_metadata
            )
        else:
            logger.warning(
                f"[AGENTCORE] Assistant placeholder not found: "
                f"conversation_id={conversation_id}, assistant_message_id={assistant_message_id}"
            )

        update_job_status(
            job_id,
            "COMPLETED",
            result_summary={
                "intent": metadata.get("intent"),
                "requires_research": metadata.get("requires_research"),
                "synthesis_mode": metadata.get("synthesis_mode"),
                "use_tools": metadata.get("use_tools"),
                "runtime_diagnostics": metadata.get("runtime_diagnostics", {}),
                "citations_count": len(citations),
                "response_length": len(response_text),
                "errors": metadata.get("errors", [])
            }
        )

        conversation = get_conversation(user_id, conversation_id)
        current_count = int(conversation.get("message_count", 0)) if conversation else 0

        update_conversation(
            user_id=user_id,
            conversation_id=conversation_id,
            last_message_at=datetime.now(timezone.utc).isoformat(),
            message_count=current_count + 2
        )

        mark_job_done(job_id)

        logger.info(f"[AGENTCORE] Background job completed: {job_id}")

    except Exception as e:
        total_duration_ms = int((time.time() - request_start) * 1000)

        logger.error(f"[AGENTCORE] Background job failed: {job_id}, error={str(e)}")
        logger.error(traceback.format_exc())

        mark_job_done(job_id)

        user_safe_error_message = (
            "I'm sorry, something went wrong while processing your request. "
            "Please try again."
        )

        try:
            update_job_status(
                job_id,
                "FAILED",
                error_message="Processing failed",
                runtime_diagnostics={
                    "total_duration_ms": total_duration_ms
                }
            )

            messages = get_messages(conversation_id, limit=100)
            assistant_message = next(
                (m for m in messages if m.get("message_id") == assistant_message_id),
                None
            )

            if assistant_message:
                update_message(
                    conversation_id=conversation_id,
                    message_sort_key=assistant_message["message_sort_key"],
                    content=user_safe_error_message,
                    status="FAILED",
                    metadata={
                        "error_message": "Processing failed",
                        "runtime_diagnostics": {
                            "total_duration_ms": total_duration_ms
                        }
                    }
                )

        except Exception as persist_error:
            logger.error(f"[AGENTCORE] Failed to persist failed job state: {str(persist_error)}")
            logger.error(traceback.format_exc())

# ----------------------------------------------------------------------------
# Invocation Endpoint
# ----------------------------------------------------------------------------

@app.post("/invocations")
def invocations(request: InvocationRequest, background_tasks: BackgroundTasks):
    """
    Main AgentCore invocation endpoint.

    Executes memory-aware LangGraph workflow:
    - Memory retrieval
    - Planner LLM
    - Conditional research
    - Synthesizer
    - Memory storage
    """
    request_start = time.time()

    try:
        logger.info("[AGENTCORE] /invocations called")

        # Log request shape, not full sensitive content
        logger.info(
            "[AGENTCORE] Request fields present: "
            f"input={request.input is not None}, "
            f"prompt={request.prompt is not None}, "
            f"sessionId={request.sessionId is not None}, "
            f"session_id={request.session_id is not None}, "
            f"userId={request.userId is not None}, "
            f"user_id={request.user_id is not None}, "
            f"job_id={request.job_id is not None}, "
            f"conversation_id={request.conversation_id is not None}, "
            f"assistant_message_id={request.assistant_message_id is not None}, "
            f"curated_urls_count={len(request.curated_urls or [])}"
        )

        user_query = request.user_input
        session_id = request.session
        user_id = request.user
        curated_urls = request.curated_urls

        job_id = request.job_id
        conversation_id = request.conversation_id
        assistant_message_id = request.assistant_message_id

        logger.info(f"[AGENTCORE] Resolved user_query present: {bool(user_query)}")
        logger.info(f"[AGENTCORE] Resolved session_id: {session_id}")
        logger.info(f"[AGENTCORE] Resolved user_id: {user_id}")
        logger.info(f"[AGENTCORE] Request actorId: {request.actorId}")
        logger.info(f"[AGENTCORE] Request namespace: {request.namespace}")
        logger.info(f"[AGENTCORE] Request memory_namespace: {request.memory_namespace}")
        logger.info(f"[AGENTCORE] Request memory_session_id: {request.memory_session_id}")

        if not user_query:
            logger.warning("[AGENTCORE] No input provided in request")
            return {
                "Output": {
                    "error": "No input provided"
                },
                "Version": "1.0"
            }
        
        # --------------------------------------------------------------------
        # Async job mode: accept job and process in background
        # --------------------------------------------------------------------
        if request.job_id:
            logger.info(
                f"[AGENTCORE] Async job accepted: "
                f"job_id={request.job_id}, "
                f"conversation_id={request.conversation_id}"
            )

            background_tasks.add_task(
                process_chat_job_background,
                request.dict()
            )

            return {
                "Output": {
                    "text": "Job accepted for background processing.",
                    "sessionId": session_id,
                    "userId": user_id,
                    "metadata": {
                        "job_id": request.job_id,
                        "status": "ACCEPTED"
                    }
                },
                "Version": "1.0"
            }

        logger.info(f"[AGENTCORE] User ID: {user_id}")
        logger.info(f"[AGENTCORE] Session ID: {session_id}")
        logger.info(f"[AGENTCORE] Query length: {len(user_query)}")
        logger.info(f"[AGENTCORE] Query preview: {safe_truncate(user_query, 500)}")

        if curated_urls:
            logger.info(f"[AGENTCORE] Curated URLs provided: {len(curated_urls)}")
            logger.debug(f"[AGENTCORE] Curated URLs: {safe_truncate(curated_urls, 1000)}")

        # --------------------------------------------------------------------
        # Execute memory-aware LangGraph workflow
        # --------------------------------------------------------------------

        logger.info("[AGENTCORE] Executing memory-aware LangGraph workflow")

        workflow_start = time.time()

        result = orchestrate_request(
            user_query=user_query,
            session_id=session_id,
            user_id=user_id,
            curated_urls=curated_urls,
            synthesize=True
        )

        workflow_duration_ms = int((time.time() - workflow_start) * 1000)

        logger.info(f"[AGENTCORE] Workflow completed in {workflow_duration_ms} ms")

        response_text = result.get("text", "")
        metadata = result.get("metadata", {}) or {}

        # Sanitize citation URLs before returning or appending sources
        citations = sanitize_citations(metadata.get("citations", []) or [])
        metadata["citations"] = citations

        logger.info(f"[AGENTCORE] Response text length: {len(response_text)}")
        logger.info(f"[AGENTCORE] Citations count: {len(citations)}")

        log_metadata(metadata)

        # Add citations if available and not already included
        if citations and "## Sources" not in response_text:
            logger.info("[AGENTCORE] Appending citations to response text")
            response_text += "\n\n## Sources\n"
            for cite in citations:
                response_text += f"\n[{cite.get('source_number')}] {cite.get('title')}\n"
                response_text += f"    {cite.get('url')}\n"

        total_duration_ms = int((time.time() - request_start) * 1000)

        logger.info("[AGENTCORE] Invocation completed successfully")
        logger.info(f"[AGENTCORE] Total invocation time: {total_duration_ms} ms")

        # Add runtime diagnostics to metadata
        metadata["runtime_diagnostics"] = {
            "workflow_duration_ms": workflow_duration_ms,
            "total_duration_ms": total_duration_ms,
            "response_length": len(response_text),
            "citations_count": len(citations)
        }

        # Return in Gateway-compatible format
        return {
            "Output": {
                "text": response_text,
                "sessionId": session_id,
                "userId": user_id,
                "metadata": metadata
            },
            "Version": "1.0"
        }
    
    except Exception as e:
        total_duration_ms = int((time.time() - request_start) * 1000)

        logger.error(f"[AGENTCORE] Error in /invocations after {total_duration_ms} ms: {str(e)}")
        logger.error(traceback.format_exc())

        return {
            "Output": {
                "error": "Processing failed",
                "type": "InternalError",
                "sessionId": request.session,
                "userId": request.user,
                "metadata": {
                    "runtime_diagnostics": {
                        "total_duration_ms": total_duration_ms
                    }
                }
            },
            "Version": "1.0"
        }

        
# ----------------------------------------------------------------------------
# Root Endpoint
# ----------------------------------------------------------------------------

@app.get("/")
def root():
    """
    Root endpoint for basic service information.
    """
    logger.debug("[AGENTCORE] Root endpoint called")

    return {
        "service": "CA Workbench AgentCore Runtime with Memory-Aware LangGraph",
        "status": "running",
        "version": "3.0.0-memory-aware",
        "gateway_compatible": True,
        "memory_aware": True,
        "flow": [
            "Memory Retrieval",
            "Planner LLM",
            "Conditional Research",
            "Synthesizer",
            "Memory Storage"
        ],
        "endpoints": {
            "ping": "GET /ping",
            "invocations": "POST /invocations"
        },
        "features": {
            "planner_llm": True,
            "memory_retrieval": True,
            "short_term_memory": "actorId + sessionId",
            "facts_memory": "/facts/{actorId}/",
            "preferences_memory": "/preferences/{actorId}/",
            "conditional_research": True,
            "synthesizer_always_runs": True,
            "memory_storage": "store_interaction"
        },
        "accepts_formats": [
            "Gateway: input/sessionId/userId",
            "Direct: prompt/session_id/user_id"
        ]
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)