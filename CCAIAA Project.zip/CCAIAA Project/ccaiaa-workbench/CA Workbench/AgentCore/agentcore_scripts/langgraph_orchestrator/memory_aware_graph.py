"""
Memory-Aware LangGraph Workflow
Integrates AWS Memory for context-aware followup questions
"""
from langgraph.graph import StateGraph, END
from typing import Dict, Any
import logging

from .state import AgentState
from .nodes import (
    memory_retrieval_node,
    planner_node,
    memory_context_selection_node,
    web_search_node,
    kb_retrieval_node,
    curated_urls_node,
    synthesis_node,
    memory_storage_node
)

logger = logging.getLogger(__name__)


def should_run_tools(state: AgentState) -> str:
    """
    Decide whether research agents should run.

    Planner output controls this:
    - requires_research = True  -> run research agents
    - requires_research = False -> skip research agents

    Backward compatibility:
    - use_tools is also supported.
    """
    requires_research = state.get('requires_research')

    if requires_research is None:
        requires_research = state.get('use_tools', True)

    if requires_research:
        logger.info("[ROUTER] requires_research=True -> running research agents")
        return "run_tools"

    logger.info("[ROUTER] requires_research=False -> skipping research agents")
    return "skip_tools"


def aggregate_results_node(state: AgentState) -> Dict[str, Any]:
    """
    Aggregate results from all parallel nodes
    """
    logger.info("[AGGREGATE] Collecting results from parallel tools...")
    
    web_count = len(state.get('web_results', [])) if state.get('web_results') else 0
    kb_status = state.get('kb_results', {}).get('status', 'none') if state.get('kb_results') else 'none'
    curated_status = state.get('curated_results', {}).get('status', 'none') if state.get('curated_results') else 'none'
    
    logger.info(f"[AGGREGATE] Web results: {web_count}")
    logger.info(f"[AGGREGATE] KB status: {kb_status}")
    logger.info(f"[AGGREGATE] Curated status: {curated_status}")
    
    return {
        'steps': ['Results aggregated from parallel tools']
    }

def route_after_planner(state: AgentState) -> str:
    """
    Route after planner.

    If planner failed, stop normal processing and send to planner error response.
    Otherwise continue to memory context selection.
    """
    intent = state.get("intent")
    synthesis_mode = state.get("synthesis_mode")

    if intent == "planner_error" or synthesis_mode == "planner_error":
        logger.error("[ROUTER] planner_error detected -> planner_error_response")
        return "planner_error"

    logger.info("[ROUTER] planner completed -> memory_context_selection")
    return "continue"


def planner_error_response_node(state: AgentState) -> Dict[str, Any]:
    """
    Convert planner failure into a controlled user-facing response.

    This prevents the graph from continuing to memory selection,
    research tools, or synthesis when planner failed.
    """
    error_message = (
        "I’m sorry, but I could not determine how to process this request because "
        "the planner service failed. Please retry in a moment."
    )

    existing_steps = state.get("steps") or []
    existing_errors = state.get("errors") or []

    metadata = dict(state.get("metadata") or {})
    metadata.update({
        "intent": "planner_error",
        "requires_research": False,
        "use_tools": False,
        "synthesis_mode": "planner_error",
        "synthesis_status": "error",
        "planner_reason": state.get("planner_reason"),
        "errors": existing_errors,
        "steps": existing_steps + ["Planner error response generated"]
    })

    return {
        "intent": "planner_error",
        "requires_research": False,
        "use_tools": False,
        "memory_scope": [],
        "research_query": state.get("user_query", ""),
        "enhanced_query": state.get("user_query", ""),
        "synthesis_mode": "planner_error",
        "synthesis_status": "error",
        "format_instruction": None,
        "format_instructions": None,
        "context_instruction": "Planner failed. Normal research and synthesis were skipped.",
        "planner_reason": state.get("planner_reason"),
        "response": error_message,
        "synthesis_text": error_message,
        "citations": [],
        "metadata": metadata,
        "errors": existing_errors,
        "steps": existing_steps + ["Planner error response generated"]
    }

def create_memory_aware_workflow_v2() -> StateGraph:
    """
    Memory-aware workflow using Planner LLM.

    Flow:
    START
      -> Memory Retrieval
      -> Planner LLM
      -> Memory Context Selection
      -> Research Router
          -> if requires_research=True: research agents -> aggregate
          -> if requires_research=False: skip research
      -> Synthesizer
      -> Memory Storage
      -> END
    """
    workflow = StateGraph(AgentState)

    # Add nodes
    workflow.add_node("memory_retrieval", memory_retrieval_node)
    workflow.add_node("planner", planner_node)
    workflow.add_node("planner_error_response", planner_error_response_node)
    workflow.add_node("memory_context_selection", memory_context_selection_node)

    workflow.add_node("parallel_start", lambda state: {
        "steps": ["Starting research agents"]
    })

    workflow.add_node("web_search", web_search_node)
    workflow.add_node("kb_retrieval", kb_retrieval_node)

    # IMPORTANT:
    # Do not name this node "curated_urls"
    # because curated_urls is already a state key.
    workflow.add_node("curated_processor", curated_urls_node)

    workflow.add_node("aggregate", aggregate_results_node)

    # IMPORTANT:
    # Do not name this node "synthesis"
    # because synthesis is already a state key.
    workflow.add_node("synthesis_node", synthesis_node)

    workflow.add_node("memory_storage", memory_storage_node)

    # Entry point
    workflow.set_entry_point("memory_retrieval")

    # Memory -> Planner
    workflow.add_edge("memory_retrieval", "planner")

    # Planner -> either continue or stop with a controlled planner error response
    workflow.add_conditional_edges(
        "planner",
        route_after_planner,
        {
            "continue": "memory_context_selection",
            "planner_error": "planner_error_response"
        }
    )

    workflow.add_edge("planner_error_response", END)

    # Conditional routing after planner/context selection
    workflow.add_conditional_edges(
        "memory_context_selection",
        should_run_tools,
        {
            "run_tools": "parallel_start",
            "skip_tools": "synthesis_node"
        }
    )

    # Research agents
    workflow.add_edge("parallel_start", "web_search")
    workflow.add_edge("parallel_start", "kb_retrieval")
    workflow.add_edge("parallel_start", "curated_processor")

    # Aggregate research chunks
    workflow.add_edge("web_search", "aggregate")
    workflow.add_edge("kb_retrieval", "aggregate")
    workflow.add_edge("curated_processor", "aggregate")

    # Aggregate -> Synthesizer
    workflow.add_edge("aggregate", "synthesis_node")

    # Synthesizer -> Memory Storage -> END
    workflow.add_edge("synthesis_node", "memory_storage")
    workflow.add_edge("memory_storage", END)

    logger.info("Memory-aware planner workflow v2 created successfully")

    return workflow.compile()



# ============================================================================
# VISUALIZATION HELPER
# ============================================================================

def visualize_workflow():
    """
    Print ASCII visualization of the workflow
    """
    print("""
Memory-Aware LangGraph Workflow
================================

START
  ↓
[Memory Retrieval] ← Fetch conversation history from AWS Memory
  ↓
[Intent Classification] ← Classify: new_question, followup_format_only, followup_content_modification
  ↓
[Memory Context Selection] ← Select memory & decide use_tools
  ↓
  ├─→ [use_tools=True] ─→ PARALLEL TOOLS
  │                        ├─→ [Web Search]
  │                        ├─→ [KB Retrieval]
  │                        └─→ [Curated URLs]
  │                             ↓
  │                        [Aggregate Results]
  │                             ↓
  └─→ [use_tools=False] ──────→ [Synthesis] ← Memory-aware response generation
                                      ↓
                                [Memory Storage] ← Save conversation turn
                                      ↓
                                    END

Intent Flows:
-------------
1. new_question: 
   Full flow with tools → comprehensive synthesis

2. followup_format_only: 
   Skip tools → reformat previous response

3. followup_content_modification: 
   Full flow with enhanced query → combined synthesis
""")


if __name__ == "__main__":
    # Visualize the workflow
    visualize_workflow()
    
    # Create and compile the workflow
    try:
        workflow = create_memory_aware_workflow_v2()
        print("\n✅ Workflow compiled successfully!")
    except Exception as e:
        print(f"\n❌ Workflow compilation failed: {e}")
