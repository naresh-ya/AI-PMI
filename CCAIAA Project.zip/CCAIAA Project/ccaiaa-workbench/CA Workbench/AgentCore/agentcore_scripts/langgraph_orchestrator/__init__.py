"""
LangGraph Orchestrator for CA Workbench
Multi-tool orchestration with LLM-based routing
"""

__version__ = "1.0.0"
