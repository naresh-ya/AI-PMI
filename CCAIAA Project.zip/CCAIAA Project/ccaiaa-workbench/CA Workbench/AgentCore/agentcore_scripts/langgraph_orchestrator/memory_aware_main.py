"""
Memory-Aware Main Entry Point for LangGraph Orchestrator
Integrates AWS Memory for context-aware followup questions
"""
import os
import logging
from typing import Dict, Any, Optional
from .memory_aware_graph import create_memory_aware_workflow_v2
from .state import AgentState

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create workflow once at module level
workflow = None


def get_workflow():
    """
    Get or create the workflow instance (lazy initialization)
    """
    global workflow
    if workflow is None:
        logger.info("Initializing memory-aware workflow...")
        workflow = create_memory_aware_workflow_v2()
        logger.info("Memory-aware workflow initialized successfully")
    return workflow


def orchestrate_request(
    user_query: str,
    session_id: str,
    user_id: str,
    curated_urls: Optional[list] = None,
    synthesize: bool = True
) -> Dict[str, Any]:
    """
    Main orchestration function with memory awareness
    
    Args:
        user_query: User's input query
        session_id: Session identifier for conversation continuity
        user_id: User identifier for personalization
        curated_urls: Optional list of URLs to process
        synthesize: Whether to synthesize results (default: True)
        
    Returns:
        Dictionary with response and metadata
        
    Example:
        >>> result = orchestrate_request(
        ...     user_query="What are Thailand HTP regulations?",
        ...     session_id="session-123",
        ...     user_id="user-456"
        ... )
        >>> print(result['text'])
    """
    try:
        logger.info(f"Processing request for session: {session_id}, user: {user_id}")
        logger.info(f"Query: {user_query[:100]}...")
        
        # Validate required parameters
        if not session_id:
            raise ValueError("session_id is required for memory-aware orchestration")
        
        if not user_id:
            raise ValueError("user_id is required for memory-aware orchestration")
        
        # Initialize state with all required fields
        initial_state: AgentState = {
            # Core fields
            'user_query': user_query,
            'session_id': session_id,
            'user_id': user_id,

            # Memory fields
            # Populated by memory_retrieval_node
            'memory_context': {},

            # Planner fields
            # Populated by planner_node
            'intent': None,
            'intent_details': {},
            'requires_research': True,
            'memory_scope': ['facts', 'preferences'],
            'research_query': user_query,
            'synthesis_mode': 'fresh_research_answer',
            'format_instruction': None,
            'context_instruction': None,
            'planner_reason': None,

            # Memory selection fields
            # Populated by memory_context_selection_node
            'selected_memory': {},

            # Backward compatibility fields
            'query_type': None,
            'use_tools': True,
            'enhanced_query': user_query,
            'format_instructions': None,

            # Tool results
            # Populated by research nodes
            'web_results': [],
            'kb_results': None,
            'curated_results': None,
            'curated_urls': curated_urls or [],

            # Synthesis fields
            # Populated by synthesis_node
            'synthesis': None,
            'synthesize': synthesize,
            'final_response': '',

            # Memory storage fields
            # Populated by memory_storage_node
            'memory_stored': False,

            # Tracking fields
            'steps': [],
            'errors': [],
            'metadata': {}
        }
        
        # Get workflow instance
        wf = get_workflow()
        
        # Execute workflow
        logger.info("Executing memory-aware workflow...")
        final_state = wf.invoke(initial_state)
        
        # Extract synthesis result
        synthesis = final_state.get('synthesis', {})
        synthesis_text = synthesis.get('synthesis_text', 'No response generated')
        
        # Build response
        response = {
            'text': synthesis_text,
            'sessionId': session_id,
            'userId': user_id,
            'metadata': {
                # Planner output
                'intent': final_state.get('intent', 'unknown'),
                'requires_research': final_state.get('requires_research'),
                'memory_scope': final_state.get('memory_scope', []),
                'research_query': final_state.get('research_query'),
                'synthesis_mode': final_state.get('synthesis_mode'),
                'format_instruction': final_state.get('format_instruction'),
                'context_instruction': final_state.get('context_instruction'),
                'planner_reason': final_state.get('planner_reason'),

                # Backward compatibility/debug
                'use_tools': final_state.get('use_tools', True),
                'enhanced_query': final_state.get('enhanced_query', user_query),

                # Memory/debug
                'memory_stored': final_state.get('memory_stored', False),

                # Execution details
                'steps': final_state.get('steps', []),
                'errors': final_state.get('errors', []),

                # Synthesis details
                'citations': synthesis.get('citations', []),
                'synthesis_status': synthesis.get('status', 'unknown'),
                'synthesis_metadata': synthesis.get('metadata', {}),

                'powered_by': 'LangGraph + AWS AgentCore Memory + LiteLLM'
            }
        }
        
        logger.info(f"Request completed successfully. Intent: {final_state.get('intent')}")
        return response
        
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}", exc_info=True)
        
        # Return error response
        return {
            'text': f"Error processing request: {str(e)}",
            'sessionId': session_id,
            'userId': user_id,
            'metadata': {
                'error': str(e),
                'error_type': type(e).__name__,
                'powered_by': 'LangGraph + AWS Memory + LiteLLM'
            }
        }


def orchestrate_request_simple(
    user_query: str,
    session_id: str = "default",
    user_id: str = "default_user"
) -> Dict[str, Any]:
    """
    Simplified orchestration function for backward compatibility
    
    Args:
        user_query: User's input query
        session_id: Session identifier (default: "default")
        user_id: User identifier (default: "default_user")
        
    Returns:
        Dictionary with response and metadata
    """
    return orchestrate_request(
        user_query=user_query,
        session_id=session_id,
        user_id=user_id,
        synthesize=True
    )


def create_orchestrator_graph():
    """
    Create and return the orchestrator graph
    For testing and inspection purposes
    
    Returns:
        Compiled LangGraph workflow
    """
    return get_workflow()


# ============================================================================
# TESTING HELPERS
# ============================================================================

def test_new_question():
    """Test new question scenario"""
    print("\n" + "="*80)
    print("TEST: New Question")
    print("="*80)
    
    result = orchestrate_request(
        user_query="What are Thailand HTP regulations?",
        session_id="test-session-1",
        user_id="test-user-1"
    )
    
    print(f"\nIntent: {result['metadata']['intent']}")
    print(f"Use Tools: {result['metadata']['use_tools']}")
    print(f"Response: {result['text'][:200]}...")
    print(f"Memory Stored: {result['metadata']['memory_stored']}")


def test_followup_format_only():
    """Test format-only followup scenario"""
    print("\n" + "="*80)
    print("TEST: Followup Format Only")
    print("="*80)
    
    # First query
    result1 = orchestrate_request(
        user_query="What are Thailand HTP regulations?",
        session_id="test-session-2",
        user_id="test-user-2"
    )
    print(f"\n[Query 1] Intent: {result1['metadata']['intent']}")
    
    # Followup query (format change)
    result2 = orchestrate_request(
        user_query="Make it more concise",
        session_id="test-session-2",
        user_id="test-user-2"
    )
    print(f"\n[Query 2] Intent: {result2['metadata']['intent']}")
    print(f"[Query 2] Use Tools: {result2['metadata']['use_tools']}")
    print(f"[Query 2] Response: {result2['text'][:200]}...")


def test_followup_content_modification():
    """Test content modification followup scenario"""
    print("\n" + "="*80)
    print("TEST: Followup Content Modification")
    print("="*80)
    
    # First query
    result1 = orchestrate_request(
        user_query="What are Thailand HTP regulations?",
        session_id="test-session-3",
        user_id="test-user-3"
    )
    print(f"\n[Query 1] Intent: {result1['metadata']['intent']}")
    
    # Followup query (add content)
    result2 = orchestrate_request(
        user_query="Also add excise duty information",
        session_id="test-session-3",
        user_id="test-user-3"
    )
    print(f"\n[Query 2] Intent: {result2['metadata']['intent']}")
    print(f"[Query 2] Use Tools: {result2['metadata']['use_tools']}")
    print(f"[Query 2] Enhanced Query: {result2['metadata']['enhanced_query']}")
    print(f"[Query 2] Response: {result2['text'][:200]}...")


if __name__ == "__main__":
    """
    Run tests when executed directly
    """
    print("\n" + "="*80)
    print("MEMORY-AWARE LANGGRAPH ORCHESTRATOR - TEST SUITE")
    print("="*80)
    
    # Check environment variables
    required_vars = ['LITELLM_URL', 'LITELLM_TOKEN', 'AWS_MEMORY_ENDPOINT']
    missing_vars = [var for var in required_vars if not os.environ.get(var)]
    
    if missing_vars:
        print(f"\n⚠️  Warning: Missing environment variables: {', '.join(missing_vars)}")
        print("Tests may fail without proper configuration.\n")
    
    # Run tests
    try:
        test_new_question()
        test_followup_format_only()
        test_followup_content_modification()
        
        print("\n" + "="*80)
        print("✅ All tests completed!")
        print("="*80 + "\n")
        
    except Exception as e:
        print(f"\n❌ Test failed: {str(e)}\n")
        raise
