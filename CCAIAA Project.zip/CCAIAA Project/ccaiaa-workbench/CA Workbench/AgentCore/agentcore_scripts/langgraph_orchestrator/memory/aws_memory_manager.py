"""
AWS AgentCore Memory Manager
Wrapper for AWS Bedrock AgentCore Memory API using boto3
"""
import boto3
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
import os

logger = logging.getLogger(__name__)


class AWSMemoryManager:
    """
    Manager for AWS Bedrock AgentCore Memory operations
    Handles short-term (events) and long-term (extracted memories) storage and retrieval
    Uses boto3 client for AWS runtime environment
    """
    
    def __init__(
        self,
        memory_id: str = "CA_Workbench_Memory-62CKDsBH4r",
        region_name: str = "eu-west-1"
    ):
        """
        Initialize AWS Memory Manager
        
        Args:
            memory_id: AWS AgentCore Memory ID
            region_name: AWS region
        """
        self.memory_id = memory_id
        self.region_name = region_name
        
        # Initialize boto3 client for Bedrock AgentCore (correct client for AWS runtime)
        self.client = boto3.client(
            'bedrock-agentcore',
            region_name=region_name
        )
        
        logger.info(f"Initialized AWSMemoryManager with memory_id={memory_id}, region={region_name}")
    
    def get_short_term_memory(
        self,
        user_id: str,
        session_id: str,
        max_results: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Retrieve recent conversation turns (short-term memory) using list_events
        
        Args:
            user_id: User identifier (actor_id in AWS)
            session_id: Session identifier
            max_results: Number of recent turns to retrieve (default: 5, recommended: 5-10)
            
        Returns:
            List of conversation events with role and content
            
        Note:
            Isolation: User ID + Session ID (no context leak possible)
        """
        try:
            logger.info(f"Fetching short-term memory: user={user_id}, session={session_id}, max={max_results}")
            
            response = self.client.list_events(
                memoryId=self.memory_id,
                actorId=user_id,
                sessionId=session_id,
                maxResults=max_results,
                includePayloads=True
            )
            
            # Parse events into structured format
            events = []
            # API returns 'events' not 'eventSummaries'
            if 'events' in response:
                for event in response['events']:
                    # Extract payload if available
                    if 'payload' in event:
                        for payload_item in event['payload']:
                            if 'conversational' in payload_item:
                                conv = payload_item['conversational']
                                events.append({
                                    'role': conv.get('role', 'UNKNOWN'),
                                    'content': conv.get('content', {}).get('text', ''),
                                    'timestamp': event.get('eventTimestamp'),
                                    'event_id': event.get('eventId')
                                })

            for idx, item in enumerate(events, 1):
                logger.info(
                    "Short-term memory item %s | event_id=%s | timestamp=%s | role=%s | preview=%s",
                    idx,
                    item.get("event_id"),
                    item.get("timestamp"),
                    item.get("role"),
                    str(item.get("content", ""))[:200]
                )

            # Sort events by timestamp to ensure chronological order.
            # AgentCore list_events order should not be assumed.
            events.sort(
                key=lambda item: item.get("timestamp") or datetime.min.replace(tzinfo=timezone.utc)
            )

            # Keep only the latest max_results payload items after sorting.
            events = events[-max_results:]

            for idx, item in enumerate(events, 1):
                logger.info(
                    "Short-term memory selected item %s | event_id=%s | timestamp=%s | role=%s | preview=%s",
                    idx,
                    item.get("event_id"),
                    item.get("timestamp"),
                    item.get("role"),
                    str(item.get("content", ""))[:200]
                )

            logger.info(f"Retrieved {len(events)} short-term memory events after sorting")
            return events
                        
        except Exception as e:
            logger.error(f"Error fetching short-term memory: {str(e)}")
            return []
    
    def get_long_term_facts(
        self,
        user_id: str,
        query: str,
        max_results: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant facts using semantic search (long-term memory)
        
        Args:
            user_id: User identifier
            query: Search query for semantic matching
            max_results: Maximum number of facts to retrieve (default: 5, recommended: 3-5)
            
        Returns:
            List of relevant facts with content and relevance scores
            
        Note:
            Isolation: User ID only via namespace /facts/{user_id}/ (no context leak possible)
            Uses FactExtractor strategy for semantic fact extraction
        """
        try:
            logger.info(f"Searching long-term facts: user={user_id}, query='{query}', max={max_results}")
            
            # FIXED: Use namespace (not namespacePath) with memoryStrategyId
            response = self.client.retrieve_memory_records(
                memoryId=self.memory_id,
                namespace=f"/facts/{user_id}/",  # User-specific namespace
                searchCriteria={
                    'searchQuery': query,
                    'memoryStrategyId': 'FactExtractor-E9riyZ4gi8',  # Required for semantic search
                    'topK': max_results  # Top K most relevant results
                },
                maxResults=max_results
            )
            
            # Parse retrieved facts
            facts = []
            if 'memoryRecordSummaries' in response:
                for record in response['memoryRecordSummaries']:
                    facts.append({
                        'record_id': record.get('memoryRecordId'),
                        'content': record.get('content', {}).get('text', ''),
                        'metadata': record.get('metadata', {}),
                        'namespace': record.get('namespace', '')
                    })

            for idx, fact in enumerate(facts, 1):
                logger.info(
                    "Long-term fact item %s | record_id=%s | namespace=%s | preview=%s",
                    idx,
                    fact.get("record_id"),
                    fact.get("namespace"),
                    str(fact.get("content", ""))[:200]
                )
                
            logger.info(f"Retrieved {len(facts)} long-term facts")
            return facts
            
        except Exception as e:
            logger.error(f"Error fetching long-term facts: {str(e)}")
            return []
    
    def get_user_preferences(
        self,
        user_id: str,
        max_results: int = 5
    ) -> List[str]:
        """
        Retrieve user preferences from long-term memory
        
        Args:
            user_id: User identifier
            max_results: Maximum number of preferences to retrieve (default: 5, recommended: 3-5)
            
        Returns:
            List of user preference strings
            
        Note:
            Isolation: User ID only via namespace /preferences/{user_id}/ (no context leak possible)
            Uses PreferenceLearner strategy to extract user work patterns and interests
        """
        try:
            logger.info(f"Fetching user preferences: user={user_id}, max={max_results}")
            
            # FIXED: Use namespace (not namespacePath) with memoryStrategyId
            response = self.client.retrieve_memory_records(
                memoryId=self.memory_id,
                namespace=f"/preferences/{user_id}/",  # User-specific namespace
                searchCriteria={
                    'searchQuery': 'What does this user prefer or commonly work on?',
                    'memoryStrategyId': 'PreferenceLearner-Z4naPmFhHJ',  # Required for preference extraction
                    'topK': max_results  # Top K most relevant preferences
                },
                maxResults=max_results
            )
            
            # Parse preferences
            preferences = []
            if 'memoryRecordSummaries' in response:
                for record in response['memoryRecordSummaries']:
                    content = record.get('content', {}).get('text', '')
                    if content:
                        preferences.append(content)

            for idx, preference in enumerate(preferences, 1):
                logger.info(
                    "User preference item %s | preview=%s",
                    idx,
                    str(preference)[:200]
                )
                
            logger.info(f"Retrieved {len(preferences)} user preferences")
            return preferences
            
        except Exception as e:
            logger.error(f"Error fetching user preferences: {str(e)}")
            return []
    
    def get_session_summaries(
        self,
        user_id: str,
        max_results: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Retrieve session summaries from long-term memory
        
        Args:
            user_id: User identifier
            max_results: Maximum number of summaries to retrieve (default: 10, recommended: 5-10)
            
        Returns:
            List of session summaries with content and metadata
            
        Note:
            Isolation: User ID only via namespacePath /summaries/{user_id}/ (no context leak possible)
            Uses SessionSummarizer strategy to create topic-organized session summaries
        """
        try:
            logger.info(f"Fetching session summaries: user={user_id}, max={max_results}")
            
            # Use namespacePath to get all summaries across sessions
            response = self.client.list_memory_records(
                memoryId=self.memory_id,
                namespacePath=f"/summaries/{user_id}/",  # User-specific path
                memoryStrategyId='SessionSummarizer-Ieb691B4ry',
                maxResults=max_results
            )
            
            # Parse summaries
            summaries = []
            if 'memoryRecordSummaries' in response:
                for record in response['memoryRecordSummaries']:
                    summaries.append({
                        'record_id': record.get('memoryRecordId'),
                        'content': record.get('content', {}).get('text', ''),
                        'namespace': record.get('namespaces', [''])[0],
                        'metadata': record.get('metadata', {})
                    })

            for idx, summary in enumerate(summaries, 1):
                logger.info(
                    "Session summary item %s | record_id=%s | namespace=%s | preview=%s",
                    idx,
                    summary.get("record_id"),
                    summary.get("namespace"),
                    str(summary.get("content", ""))[:200]
                )
                
            logger.info(f"Retrieved {len(summaries)} session summaries")
            return summaries
            
        except Exception as e:
            logger.error(f"Error fetching session summaries: {str(e)}")
            return []
    
    def retrieve_full_memory(
        self,
        user_id: str,
        session_id: str,
        query: str,
        short_term_limit: int = 10,
        long_term_limit: int = 15,
        summary_limit: int = 5
    ) -> Dict[str, Any]:
        """
        Retrieve all memory types at once (optimized for Phase 1)
        
        Args:
            user_id: User identifier
            session_id: Session identifier
            query: Current user query for semantic search
            short_term_limit: Number of recent turns to retrieve (default: 5)
            long_term_limit: Number of facts/preferences to retrieve (default: 5)
            summary_limit: Number of session summaries to retrieve (default: 10)
            
        Returns:
            Dictionary containing all memory types
            
        Note:
            Recommended settings:
            - short_term_limit: 5 turns
            - long_term_limit: 5 results (facts and preferences)
            - summary_limit: 10 summaries
        """
        logger.info(f"Retrieving full memory for user={user_id}, session={session_id}")

        short_term = []
        long_term_facts = []
        preferences = []
        summaries = []

        if short_term_limit > 0:
            short_term = self.get_short_term_memory(
                user_id,
                session_id,
                short_term_limit
            )

        if long_term_limit > 0:
            long_term_facts = self.get_long_term_facts(
                user_id,
                query,
                long_term_limit
            )
            preferences = self.get_user_preferences(
                user_id,
                long_term_limit
            )

        if summary_limit > 0:
            summaries = self.get_session_summaries(
                user_id,
                summary_limit
            )

        logger.info(
            "Memory retrieval limits | short_term=%s | long_term=%s | summaries=%s",
            short_term_limit,
            long_term_limit,
            summary_limit
        )

        logger.info(
            "Full memory retrieval completed | short_term_count=%s | facts_count=%s | preferences_count=%s | summaries_count=%s",
            len(short_term),
            len(long_term_facts),
            len(preferences),
            len(summaries)
        )
                
        return {
            "short_term": short_term,
            "long_term_facts": long_term_facts,
            "preferences": preferences,
            "summaries": summaries
        }
    
    def store_event(
        self,
        user_id: str,
        session_id: str,
        message: str,
        role: str = "USER"
    ) -> bool:
        """
        Store a conversation event (USER or ASSISTANT message) using create_event
        
        Args:
            user_id: User identifier
            session_id: Session identifier
            message: Message content
            role: Message role (USER or ASSISTANT)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            logger.info(f"Storing {role} event: user={user_id}, session={session_id}")
            
            response = self.client.create_event(
                memoryId=self.memory_id,
                actorId=user_id,
                sessionId=session_id,
                eventTimestamp=datetime.now(timezone.utc),  # Use timezone-aware datetime
                payload=[
                    {
                        'conversational': {
                            'content': {
                                'text': message
                            },
                            'role': role
                        }
                    }
                ]
            )
            
            logger.info(f"Successfully stored {role} event")
            return True
            
        except Exception as e:
            logger.error(f"Error storing event: {str(e)}")
            return False
    
    def store_interaction(
        self,
        user_id: str,
        session_id: str,
        user_message: str,
        assistant_message: str
    ) -> bool:
        """
        Store a complete interaction (USER + ASSISTANT messages) in a single event
        
        Args:
            user_id: User identifier
            session_id: Session identifier
            user_message: User's message
            assistant_message: Assistant's response
            
        Returns:
            True if interaction stored successfully
        """
        try:
            logger.info(f"Storing interaction: user={user_id}, session={session_id}")
            
            response = self.client.create_event(
                memoryId=self.memory_id,
                actorId=user_id,
                sessionId=session_id,
                eventTimestamp=datetime.now(timezone.utc),  # Use timezone-aware datetime
                payload=[
                    {
                        'conversational': {
                            'content': {'text': user_message},
                            'role': 'USER'
                        }
                    },
                    {
                        'conversational': {
                            'content': {'text': assistant_message},
                            'role': 'ASSISTANT'
                        }
                    }
                ]
            )
            
            logger.info("Interaction stored successfully. AWS will auto-extract long-term memories.")
            return True
            
        except Exception as e:
            logger.error(f"Error storing interaction: {str(e)}")
            return False
