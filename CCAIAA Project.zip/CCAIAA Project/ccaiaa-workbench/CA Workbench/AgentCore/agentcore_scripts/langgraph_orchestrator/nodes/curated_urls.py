"""
Curated URLs Node - Thin wrapper for CAWorkbenchCuratedTool
"""
from typing import Dict, Any
from ..state import AgentState
from CAWorkbenchCuratedTool.curated_processor import process_curated_urls


def curated_urls_node(state: AgentState) -> Dict[str, Any]:
    """
    Process curated URLs (runs in parallel)
    Returns only the keys to update
    """
    try:
        user_query = (
            state.get('research_query')
            or state.get('enhanced_query')
            or state.get('user_query', '')
        )
        curated_urls = state.get('curated_urls') or []
        
        print(f"[CURATED URLS] Starting with {len(curated_urls)} URLs...")
        
        # If no curated URLs provided, try to extract from query
        if not curated_urls:
            import re
            curated_urls = re.findall(
                r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',
                user_query
            )
        
        # Execute curated URL processing
        results = process_curated_urls(
            urls=curated_urls,
            extract_format="markdown"
        )
        
        print(f"[CURATED URLS] Completed: {len(curated_urls)} URLs")
        return {
            'curated_results': results,
            'steps': [f"Curated URLs processed: {len(curated_urls)} URLs"]
        }
        
    except Exception as e:
        error_msg = f"Curated URLs exception: {str(e)}"
        print(f"[CURATED URLS] Exception: {str(e)}")
        return {
            'curated_results': None,
            'errors': [error_msg],
            'steps': [error_msg]
        }
