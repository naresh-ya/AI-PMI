"""
Web Search Node - Thin wrapper for CAWorkbenchWebTool
"""
from typing import Dict, Any
from ..state import AgentState
from CAWorkbenchWebTool.web_search import execute_web_search


def web_search_node(state: AgentState) -> Dict[str, Any]:
    """
    Execute web search (runs in parallel)
    Returns only the keys to update
    """
    try:
        user_query = (
            state.get('research_query')
            or state.get('enhanced_query')
            or state.get('user_query', '')
        )
        
        print(f"[WEB SEARCH] Starting for query: {user_query[:50]}...")
        
        # Execute web search
        results = execute_web_search(
            query=user_query,
            max_results=5,
            search_depth="basic"
        )
        
        if results.get('status') == 'success':
            print(f"[WEB SEARCH] Completed: {len(results.get('results', []))} results")
            return {
                'web_results': results.get('results', []),
                'steps': [f"Web search completed: {len(results.get('results', []))} results"]
            }
        else:
            error_msg = f"Web search error: {results.get('error', 'Unknown error')}"
            print(f"[WEB SEARCH] Error: {results.get('error')}")
            return {
                'web_results': [],
                'errors': [error_msg],
                'steps': [error_msg]
            }
        
    except Exception as e:
        error_msg = f"Web search exception: {str(e)}"
        print(f"[WEB SEARCH] Exception: {str(e)}")
        return {
            'web_results': [],
            'errors': [error_msg],
            'steps': [error_msg]
        }
