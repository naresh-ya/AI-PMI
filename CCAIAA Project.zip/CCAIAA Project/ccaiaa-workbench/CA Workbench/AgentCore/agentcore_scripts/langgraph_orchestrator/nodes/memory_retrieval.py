"""
Memory Retrieval Node
Fetches conversation memory from AWS AgentCore Memory
"""
import logging
from typing import Dict, Any
from ..state import AgentState
from ..memory.aws_memory_manager import AWSMemoryManager

logger = logging.getLogger(__name__)


def memory_retrieval_node(state: AgentState) -> Dict[str, Any]:
    """
    Retrieve full memory context from AWS AgentCore Memory
    
    Phase 1 Approach: Always fetch full memory (quality-first)
    - Short-term: Last 5 conversation turns
    - Long-term: Semantic search for relevant facts
    - Preferences: User preferences and settings
    
    Args:
        state: Current agent state with user_id, session_id, and query
        
    Returns:
        Updated state with memory_context populated
    """
    logger.info("=== MEMORY RETRIEVAL NODE ===")
    
    try:
        # Extract required fields from state
        user_id = state.get('user_id')
        session_id = state.get('session_id')
        query = state.get('user_query', '')
        
        # Validate required fields
        if not user_id:
            logger.warning("No user_id provided, skipping memory retrieval")
            return {
                'memory_context': {
                    'short_term': [],
                    'long_term_facts': [],
                    'preferences': []
                },
                'steps': ['Memory retrieval skipped: no user_id']
            }
        
        if not session_id:
            logger.warning("No session_id provided, using default")
            session_id = f"session_{user_id}_default"
        
        logger.info(f"Retrieving memory for user_id={user_id}, session_id={session_id}")
        
        # Initialize AWS Memory Manager
        memory_manager = AWSMemoryManager(
            memory_id="CA_Workbench_Memory-62CKDsBH4r",
            region_name="eu-west-1"
        )
        
        # Retrieve full memory (Phase 1: always fetch everything)
        memory_context = memory_manager.retrieve_full_memory(
            user_id=user_id,
            session_id=session_id,
            query=query
        )
        
        # Log memory retrieval results
        short_term_count = len(memory_context.get('short_term', []))
        long_term_count = len(memory_context.get('long_term_facts', []))
        preferences_count = len(memory_context.get('preferences', []))
        
        logger.info(f"Memory retrieved: {short_term_count} short-term, "
                   f"{long_term_count} long-term facts, {preferences_count} preferences")
        
        # Return updated state
        return {
            'memory_context': memory_context,
            'steps': [
                f'Memory retrieved: {short_term_count} recent turns, '
                f'{long_term_count} facts, {preferences_count} preferences'
            ]
        }
        
    except Exception as e:
        logger.error(f"Error in memory retrieval: {str(e)}", exc_info=True)
        
        # Return empty memory context on error (graceful degradation)
        return {
            'memory_context': {
                'short_term': [],
                'long_term_facts': [],
                'preferences': [],
                'summaries': []
            },
            'errors': [f'Memory retrieval error: {str(e)}'],
            'steps': ['Memory retrieval failed, continuing without memory']
        }


def format_memory_for_logging(memory_context: Dict[str, Any]) -> str:
    """
    Format memory context for logging (helper function)
    
    Args:
        memory_context: Memory context dictionary
        
    Returns:
        Formatted string for logging
    """
    lines = []
    
    # Short-term memory
    short_term = memory_context.get('short_term', [])
    if short_term:
        lines.append("=== SHORT-TERM MEMORY ===")
        for i, event in enumerate(short_term[-3:], 1):  # Last 3 for brevity
            role = event.get('role', 'unknown')
            content = event.get('content', '')[:100]  # Truncate
            lines.append(f"{i}. [{role}] {content}...")
    
    # Long-term facts
    facts = memory_context.get('long_term_facts', [])
    if facts:
        lines.append("\n=== LONG-TERM FACTS ===")
        for i, fact in enumerate(facts[:3], 1):  # Top 3 for brevity
            content = fact.get('content', '')[:100]
            score = fact.get('score', 0.0)
            lines.append(f"{i}. [score: {score:.2f}] {content}...")
    
    # Preferences
    preferences = memory_context.get('preferences', [])
    if preferences:
        lines.append("\n=== USER PREFERENCES ===")
        for i, pref in enumerate(preferences[:3], 1):  # Top 3 for brevity
            lines.append(f"{i}. {pref[:100]}...")
    
    return "\n".join(lines) if lines else "No memory available"
