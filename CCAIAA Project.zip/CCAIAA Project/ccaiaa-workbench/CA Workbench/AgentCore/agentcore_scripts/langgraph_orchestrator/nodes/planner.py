"""
Planner LLM Node

Responsible for:
- Classifying query intent
- Deciding memory scope
- Deciding whether research is required
- Producing research_query for research agents
- Producing synthesis_mode for synthesizer

This node does NOT generate the final answer.
"""
import boto3
import os
import json
import ssl
import logging
import urllib.request
from typing import Dict, Any, List
from datetime import datetime, timezone
import urllib.error

from ..state import AgentState

logger = logging.getLogger(__name__)

def get_int_env(name: str, default: int) -> int:
    """
    Safely read integer environment variable.
    """
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid integer value for {name}. Using default: {default}")
        return default

def limit_memory_items(items, limit: int):
    """
    Limit memory items to the latest N entries.
    If limit is 0 or less, return empty list.
    """
    if not items or limit <= 0:
        return []

    return list(items)[-limit:]


def get_float_env(name: str, default: float) -> float:
    """
    Safely read float environment variable.
    """
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        logger.warning(f"Invalid float value for {name}. Using default: {default}")
        return default

VALID_INTENTS = {
    "new_question",
    "followup_research",
    "followup_format_only"
}
PLANNER_PROMPT_ID = "6SXZARKDW9"
PLANNER_PROMPT_REGION = "eu-west-1"

VALID_SYNTHESIS_MODES = {
    "fresh_research_answer",
    "combine_previous_context_with_new_research",
    "reformat_previous_response"
}


def planner_node(state: AgentState) -> Dict[str, Any]:
    """
    Planner LLM node.

    Inputs:
    - user_query
    - memory_context

    Outputs:
    - intent
    - requires_research
    - memory_scope
    - research_query
    - synthesis_mode
    - format_instruction
    - context_instruction
    - planner_reason

    The planner only decides the flow. It does not answer the user.
    """

    logger.info("=== PLANNER NODE ===")

    try:
        user_query = state.get("user_query", "")
        memory_context = state.get("memory_context", {}) or {}

        planner_short_term_limit = int(os.environ.get("PLANNER_SHORT_TERM_MEMORY_LIMIT", "5"))
        planner_facts_limit = int(os.environ.get("PLANNER_FACTS_MEMORY_LIMIT", "0"))
        planner_preferences_limit = int(os.environ.get("PLANNER_PREFERENCES_MEMORY_LIMIT", "0"))

        short_term = limit_memory_items(
            memory_context.get("short_term", []) or [],
            planner_short_term_limit
        )

        facts = limit_memory_items(
            memory_context.get("long_term_facts", []) or [],
            planner_facts_limit
        )

        preferences = limit_memory_items(
            memory_context.get("preferences", []) or [],
            planner_preferences_limit
        )

        logger.info(
            "Planner memory limits applied | short_term=%s | facts=%s | preferences=%s",
            len(short_term),
            len(facts),
            len(preferences)
        )

        recent_conversation_text = format_recent_conversation(short_term)
        facts_text = format_facts_for_planner(facts)
        preferences_text = format_preferences_for_planner(preferences)

        logger.info(f"Planning for query: {user_query[:150]}")
        logger.info(f"Short-term memory events: {len(short_term)}")
        logger.info(f"Facts: {len(facts)}")
        logger.info(f"Preferences: {len(preferences)}")

        planner_result = call_planner_llm(
            user_query=user_query,
            recent_conversation=recent_conversation_text,
            facts=facts_text,
            preferences=preferences_text
        )

        normalized = normalize_planner_result(
            planner_result=planner_result,
            user_query=user_query
        )

        logger.info(f"Planner intent: {normalized['intent']}")
        logger.info(f"Requires research: {normalized['requires_research']}")
        logger.info(f"Research query: {normalized.get('research_query')}")
        logger.info(f"Synthesis mode: {normalized['synthesis_mode']}")

        return {
            "intent": normalized["intent"],
            "requires_research": normalized["requires_research"],
            "memory_scope": normalized["memory_scope"],
            "research_query": normalized.get("research_query"),
            "synthesis_mode": normalized["synthesis_mode"],
            "format_instruction": normalized.get("format_instruction"),
            "context_instruction": normalized.get("context_instruction"),
            "planner_reason": normalized.get("reason"),

            # Backward compatibility with existing code
            "use_tools": normalized["requires_research"],
            "enhanced_query": normalized.get("research_query") or user_query,
            "format_instructions": normalized.get("format_instruction"),
            "intent_details": normalized,

            "steps": [
                f"Planner intent: {normalized['intent']}",
                f"Requires research: {normalized['requires_research']}",
                f"Synthesis mode: {normalized['synthesis_mode']}"
            ]
        }

    except Exception as e:
        logger.error(f"Planner node error: {str(e)}", exc_info=True)

        # Safe failure: stop workflow rather than continuing with an uncertain plan
        return {
            "intent": "planner_error",
            "requires_research": False,
            "memory_scope": [],
            "research_query": state.get("user_query", ""),
            "synthesis_mode": "planner_error",
            "format_instruction": None,
            "context_instruction": "Planner failed. Do not continue with research or synthesis.",
            "planner_reason": f"Planner failed: {str(e)}",

            "use_tools": False,
            "enhanced_query": state.get("user_query", ""),
            "format_instructions": None,
            "intent_details": {
                "intent": "planner_error",
                "reason": f"Planner failed: {str(e)}"
            },

            "errors": [f"Planner error: {str(e)}"],
            "steps": ["Planner failed, stopping workflow"]
        }

def preview_head_tail(value: str, head_chars: int = 160, tail_chars: int = 160) -> str:
    """
    Return compact head/tail preview for logs.
    Avoids printing full memory content into CloudWatch.
    """
    text = str(value or "").replace("\n", "\\n").strip()

    if len(text) <= head_chars + tail_chars + 20:
        return text

    head = text[:head_chars]
    tail = text[-tail_chars:]

    return f"{head} ... [snip {len(text) - head_chars - tail_chars} chars] ... {tail}"


def format_recent_conversation(short_term: List[Dict[str, Any]]) -> str:
    """
    Format recent conversation for Planner.

    User messages are kept full.
    Assistant messages are trimmed because they can be very long.

    The number of memory items is already controlled by:
    PLANNER_SHORT_TERM_MEMORY_LIMIT
    """

    if not short_term:
        return "No previous conversation available."

    assistant_char_limit = get_int_env(
        "PLANNER_ASSISTANT_MESSAGE_CHAR_LIMIT",
        700
    )

    lines = []

    for idx, event in enumerate(short_term or [], 1):
        role = str(event.get("role", "unknown") or "unknown").lower()

        original_content = str(event.get("content", "") or "").strip()

        if not original_content:
            continue

        # Normalize whitespace to keep prompt compact.
        normalized_content = " ".join(original_content.split())
        original_chars = len(normalized_content)

        included_content = normalized_content
        capped = False
        cap_limit = "not_applicable"

        if role == "user":
            # Keep full user message.
            label = "User"

        elif role == "assistant":
            # Trim assistant response for Planner only.
            label = "Assistant"
            cap_limit = assistant_char_limit

            if len(normalized_content) > assistant_char_limit:
                included_content = normalized_content[:assistant_char_limit].rstrip() + "..."
                capped = True

        else:
            label = role
            cap_limit = assistant_char_limit

            if len(normalized_content) > assistant_char_limit:
                included_content = normalized_content[:assistant_char_limit].rstrip() + "..."
                capped = True

        included_chars = len(included_content)

        lines.append(f"{label}: {included_content}")

        logger.info(
            "Planner recent conversation item | idx=%s | event_id=%s | timestamp=%s | role=%s | original_chars=%s | included_chars=%s | cap_limit=%s | capped=%s | included_preview=%s | original_tail=%s",
            idx,
            event.get("event_id"),
            event.get("timestamp"),
            role,
            original_chars,
            included_chars,
            cap_limit,
            capped,
            preview_head_tail(included_content, head_chars=180, tail_chars=180),
            preview_head_tail(normalized_content[-360:], head_chars=180, tail_chars=180) if role == "assistant" else "not_applicable"
        )

    return "\n".join(lines) if lines else "No previous conversation available."

def format_facts_for_planner(facts: List[Dict[str, Any]]) -> str:
    """
    Format semantic facts for planner.
    Keep this short because planner only needs signal, not full answer context.
    """

    if not facts:
        return "No relevant facts available."

    lines = []

    for idx, fact in enumerate(facts[:5], 1):
        content = fact.get("content", "")
        if content:
            lines.append(f"{idx}. {content[:500]}")

    return "\n".join(lines) if lines else "No relevant facts available."


def format_preferences_for_planner(preferences: List[Any]) -> str:
    """
    Format user preferences for planner.
    """

    if not preferences:
        return "No user preferences available."

    lines = []

    for idx, pref in enumerate(preferences[:5], 1):
        if isinstance(pref, dict):
            content = pref.get("content", "")
        else:
            content = str(pref)

        if content:
            lines.append(f"{idx}. {content[:300]}")

    return "\n".join(lines) if lines else "No user preferences available."

def render_prompt_template(template: str, values: Dict[str, Any]) -> str:
    """
    Replace AWS Prompt Management {{variable}} placeholders with runtime values.
    """

    rendered = template or ""

    for key, value in values.items():
        rendered = rendered.replace("{{" + key + "}}", str(value))

    return rendered


def get_latest_planner_prompt_version(client, prompt_id: str) -> str:
    """
    Get latest published numeric version from AWS Prompt Management.

    Does not use DRAFT.
    Raises error if no published numeric version exists.
    """

    response = client.list_prompts(promptIdentifier=prompt_id)

    versions = []

    for summary in response.get("promptSummaries", []):
        version = str(summary.get("version", "")).strip()

        if version.isdigit():
            versions.append(int(version))

    if not versions:
        raise ValueError(
            f"No published numeric versions found for planner prompt_id={prompt_id}"
        )

    return str(max(versions))


def fetch_latest_planner_prompt_from_aws() -> Dict[str, str]:
    """
    Fetch latest published Planner prompt from AWS Bedrock Prompt Management.

    Uses hardcoded:
    - PLANNER_PROMPT_ID
    - PLANNER_PROMPT_REGION

    Always retrieves latest numeric published version.
    Does not use DRAFT.
    """

    client = boto3.client(
        "bedrock-agent",
        region_name=PLANNER_PROMPT_REGION
    )

    latest_version = get_latest_planner_prompt_version(
        client=client,
        prompt_id=PLANNER_PROMPT_ID
    )

    response = client.get_prompt(
        promptIdentifier=PLANNER_PROMPT_ID,
        promptVersion=latest_version
    )

    variants = response.get("variants", [])

    if not variants:
        raise ValueError(
            f"No variants found in planner prompt_id={PLANNER_PROMPT_ID}, version={latest_version}"
        )

    default_variant_name = response.get("defaultVariant")
    selected_variant = None

    if default_variant_name:
        for variant in variants:
            if variant.get("name") == default_variant_name:
                selected_variant = variant
                break

    if selected_variant is None:
        selected_variant = variants[0]

    template_config = selected_variant.get("templateConfiguration", {})
    chat_config = template_config.get("chat", {})

    if not chat_config:
        raise ValueError(
            f"Planner prompt must be CHAT template. prompt_id={PLANNER_PROMPT_ID}, version={latest_version}"
        )

    system_prompt = ""
    user_prompt = ""

    system_blocks = chat_config.get("system", []) or []

    if system_blocks:
        system_prompt = system_blocks[0].get("text", "") or ""

    messages = chat_config.get("messages", []) or []

    for message in messages:
        role = str(message.get("role", "")).lower()

        if role == "user":
            content_blocks = message.get("content", []) or []

            if content_blocks:
                user_prompt = content_blocks[0].get("text", "") or ""
                break

    if not user_prompt:
        raise ValueError(
            f"User prompt template not found in planner prompt_id={PLANNER_PROMPT_ID}, version={latest_version}"
        )

    logger.info(
        "Fetched latest planner prompt from AWS Prompt Management | prompt_id=%s | version=%s | variant=%s",
        PLANNER_PROMPT_ID,
        latest_version,
        selected_variant.get("name")
    )

    return {
        "system_prompt": system_prompt,
        "user_prompt": user_prompt,
        "version": latest_version,
        "prompt_id": PLANNER_PROMPT_ID,
        "variant": selected_variant.get("name")
    }


def call_planner_llm(
    user_query: str,
    recent_conversation: str,
    facts: str,
    preferences: str
) -> Dict[str, Any]:
    """
    Call LLM to produce structured planning JSON.
    """
    
    litellm_url = os.environ.get("LITELLM_URL", "")
    litellm_token = os.environ.get("LITELLM_TOKEN", "")

    litellm_model = (
        os.environ.get("PLANNER_LLM_MODEL")
        or os.environ.get("LITELLM_MODEL")
        or "bedrock/us.anthropic.claude-opus-4-8"
    )

    max_tokens = get_int_env("PLANNER_MAX_TOKENS", 4000)
    temperature = get_float_env("PLANNER_TEMPERATURE", 0.0)
    timeout_seconds = get_int_env("PLANNER_TIMEOUT_SECONDS", 120)

    if not litellm_url:
        raise ValueError("LITELLM_URL environment variable is missing")

    if not litellm_token:
        raise ValueError("LITELLM_TOKEN environment variable is missing")

    current_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    prompt_values = {
        "current_date": current_date,
        "user_query": user_query,
        "recent_conversation": recent_conversation,
        "facts": facts,
        "preferences": preferences
    }

    planner_prompt = fetch_latest_planner_prompt_from_aws()

    system_prompt = render_prompt_template(
        planner_prompt.get("system_prompt", ""),
        prompt_values
    )

    user_prompt = render_prompt_template(
        planner_prompt.get("user_prompt", ""),
        prompt_values
    )

    logger.info(
        "Using AWS Prompt Management planner prompt | prompt_id=%s | version=%s | system_chars=%s | user_chars=%s",
        planner_prompt.get("prompt_id"),
        planner_prompt.get("version"),
        len(system_prompt),
        len(user_prompt)
    )
    
    logger.info(f"Planner LLM model: {litellm_model}")
    logger.info(f"Planner max_tokens: {max_tokens}")
    logger.info(f"Planner temperature: {temperature}")

    messages = []

    if system_prompt:
        messages.append({
            "role": "system",
            "content": system_prompt
        })

    messages.append({
        "role": "user",
        "content": user_prompt
    })

    payload = {
        "model": litellm_model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature
    }
    
    payload_text = json.dumps(payload, ensure_ascii=False)

    logger.info(
        "Planner LLM payload diagnostics | model=%s | payload_bytes=%s | system_chars=%s | user_chars=%s | messages_count=%s | max_tokens=%s | temperature=%s",
        payload.get("model"),
        len(payload_text.encode("utf-8")),
        len(system_prompt),
        len(user_prompt),
        len(payload.get("messages", [])),
        payload.get("max_tokens"),
        payload.get("temperature")
    )

    logger.info(
        "Planner LLM payload preview | first_1000_chars=%s",
        payload_text[:1000]
    )

    req = urllib.request.Request(
        litellm_url,
        data=payload_text.encode("utf-8"),
        headers={
            "Authorization": f"Bearer {litellm_token}",
            "Content-Type": "application/json"
        }
    )

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    try:
        with urllib.request.urlopen(req, context=ctx, timeout=timeout_seconds) as response:
            response_body = response.read().decode("utf-8", errors="replace")
            result = json.loads(response_body)
            content = result["choices"][0]["message"]["content"].strip()

    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")
        logger.error(
            "Planner LLM HTTPError | status=%s | reason=%s | body=%s",
            e.code,
            e.reason,
            error_body,
            exc_info=True
        )
        raise

    except Exception as e:
        logger.error(f"Planner LLM call failed: {str(e)}", exc_info=True)
        raise


    try:
        cleaned_content = extract_json_from_llm_response(content)
        return json.loads(cleaned_content)
    except json.JSONDecodeError:
        logger.error(f"Planner LLM returned invalid JSON: {content}")
        raise ValueError(f"Planner LLM returned invalid JSON: {content}")

def extract_json_from_llm_response(content: str) -> str:
    """
    Extract JSON from LLM response.

    Handles:
    - Raw JSON
    - ```json fenced JSON
    - ``` fenced JSON
    - Extra text before/after JSON
    """
    if not content:
        return "{}"

    text = content.strip()

    # Remove markdown fenced code block
    if text.startswith("```"):
        lines = text.splitlines()

        # Remove opening fence, e.g. ```json or ```
        if lines and lines[0].strip().startswith("```"):
            lines = lines[1:]

        # Remove closing fence
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]

        text = "\n".join(lines).strip()

    # If there is extra text, extract from first { to last }
    start = text.find("{")
    end = text.rfind("}")

    if start != -1 and end != -1 and end > start:
        text = text[start:end + 1]

    return text

def normalize_planner_result(
    planner_result: Dict[str, Any],
    user_query: str
) -> Dict[str, Any]:
    """
    Validate and normalize planner output.
    """

    intent = planner_result.get("intent") or "new_question"

    if intent not in VALID_INTENTS:
        intent = "new_question"

    if intent == "new_question":
        requires_research = True
        memory_scope = ["facts", "preferences"]
        research_query = planner_result.get("research_query") or user_query
        synthesis_mode = "fresh_research_answer"
        format_instruction = None

    elif intent == "followup_research":
        requires_research = True
        memory_scope = ["short_term", "facts", "preferences"]
        research_query = planner_result.get("research_query") or user_query
        synthesis_mode = "combine_previous_context_with_new_research"
        format_instruction = planner_result.get("format_instruction")

    else:
        intent = "followup_format_only"
        requires_research = False
        memory_scope = ["short_term"]
        research_query = None
        synthesis_mode = "reformat_previous_response"
        format_instruction = (
            planner_result.get("format_instruction")
            or user_query
        )

    context_instruction = planner_result.get("context_instruction") or ""
    reason = planner_result.get("reason") or ""

    if synthesis_mode not in VALID_SYNTHESIS_MODES:
        synthesis_mode = "fresh_research_answer"

    return {
        "intent": intent,
        "requires_research": requires_research,
        "memory_scope": memory_scope,
        "research_query": research_query,
        "synthesis_mode": synthesis_mode,
        "format_instruction": format_instruction,
        "context_instruction": context_instruction,
        "reason": reason
    }