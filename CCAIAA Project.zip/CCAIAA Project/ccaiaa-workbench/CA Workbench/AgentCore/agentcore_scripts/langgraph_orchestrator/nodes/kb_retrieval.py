"""
KB Retrieval Node - Thin wrapper for CAWorkbenchKBTool
"""
from typing import Dict, Any
from ..state import AgentState
from CAWorkbenchKBTool.kb_retrieval import retrieve_from_kb


def kb_retrieval_node(state: AgentState) -> Dict[str, Any]:
    """
    Execute KB retrieval (runs in parallel)
    Returns only the keys to update
    """
    try:
        user_query = (
            state.get('research_query')
            or state.get('enhanced_query')
            or state.get('user_query', '')
        )
        
        print(f"[KB RETRIEVAL] Starting for query: {user_query[:50]}...")
        
        # Execute KB retrieval
        results = retrieve_from_kb(
            query=user_query,
            max_results=5
        )
        
        print(f"[KB RETRIEVAL] Completed: {results.get('status')}")
        return {
            'kb_results': results,
            'steps': ["KB retrieval completed"]
        }
        
    except Exception as e:
        error_msg = f"KB retrieval exception: {str(e)}"
        print(f"[KB RETRIEVAL] Exception: {str(e)}")
        return {
            'kb_results': None,
            'errors': [error_msg],
            'steps': [error_msg]
        }
