"""
Synthesis Node - Thin wrapper that calls CAWorkbenchSynthesisTool
Handles 3 scenarios: new_question, followup_format_only, followup_content_modification
"""
import os
import logging
from typing import Dict, Any
from ..state import AgentState

# Import synthesis functions from tool
import sys
from pathlib import Path

# Add CAWorkbenchSynthesisTool to path
tool_path = Path(__file__).parent.parent.parent / "CAWorkbenchSynthesisTool"
if str(tool_path) not in sys.path:
    sys.path.insert(0, str(tool_path))

from synthesizer import (
    synthesize_format_only,
    synthesize_with_memory,
    synthesize_new_question,
    limit_memory_items,
    get_int_env
)

logger = logging.getLogger(__name__)

def preview_head_tail(value: Any, head_chars: int = 500, tail_chars: int = 500) -> str:
    """
    Return compact head/tail preview for synthesis memory logs.
    Shows first N and last N characters without logging full memory payload.
    """
    text = str(value or "").replace("\n", "\\n").strip()

    if len(text) <= head_chars + tail_chars + 20:
        return text

    head = text[:head_chars]
    tail = text[-tail_chars:]

    return f"{head} ... [snip {len(text) - head_chars - tail_chars} chars] ... {tail}"


def synthesis_node(state: AgentState) -> Dict[str, Any]:
    """
    Synthesizer node.

    This node ALWAYS runs and produces the final frontend-ready response.

    It supports three synthesis modes:
    1. fresh_research_answer
       - Fresh query
       - Uses research chunks + facts + preferences

    2. combine_previous_context_with_new_research
       - Follow-up requiring new research
       - Uses previous conversation + new research chunks + facts + preferences

    3. reformat_previous_response
       - Follow-up format-only
       - Uses previous assistant response only
       - No new research
    """
    logger.info("=== SYNTHESIS NODE ===")

    try:
        # Extract parameters from state
        user_query = state.get('user_query', '')
        intent = state.get('intent', 'new_question')
        synthesis_mode = state.get('synthesis_mode')

        # Backward compatibility if synthesis_mode is missing
        if not synthesis_mode:
            if intent == 'followup_format_only':
                synthesis_mode = 'reformat_previous_response'
            elif intent in ('followup_research', 'followup_content_modification'):
                synthesis_mode = 'combine_previous_context_with_new_research'
            else:
                synthesis_mode = 'fresh_research_answer'

        research_query = (
            state.get('research_query')
            or state.get('enhanced_query')
            or user_query
        )

        selected_memory = state.get("selected_memory") or {}

        if not isinstance(selected_memory, dict):
            logger.warning(
                "selected_memory is not a dict. Type=%s. Resetting to empty dict.",
                type(selected_memory).__name__
            )
            selected_memory = {}

        # Apply memory limits
        synthesis_short_term_limit = get_int_env("SYNTHESIS_SHORT_TERM_MEMORY_LIMIT", 5)
        synthesis_facts_limit = get_int_env("SYNTHESIS_FACTS_MEMORY_LIMIT", 5)
        synthesis_preferences_limit = get_int_env("SYNTHESIS_PREFERENCES_MEMORY_LIMIT", 5)
        synthesis_summaries_limit = get_int_env("SYNTHESIS_SUMMARIES_MEMORY_LIMIT", 0)

        memory_scope = state.get("memory_scope") or []

        if isinstance(memory_scope, str):
            memory_scope = [memory_scope]

        if not memory_scope:
            if synthesis_mode == "reformat_previous_response":
                memory_scope = ["short_term"]
            elif synthesis_mode == "combine_previous_context_with_new_research":
                memory_scope = ["short_term", "facts", "preferences"]
            else:
                memory_scope = ["facts", "preferences"]

        limited_short_term = limit_memory_items(
            selected_memory.get("short_term") or [],
            synthesis_short_term_limit
        )

        limited_facts = limit_memory_items(
            selected_memory.get("long_term_facts") or [],
            synthesis_facts_limit
        )

        limited_preferences = limit_memory_items(
            selected_memory.get("preferences") or [],
            synthesis_preferences_limit
        )

        limited_summaries = limit_memory_items(
            selected_memory.get("summaries") or [],
            synthesis_summaries_limit
        )

        selected_memory = {
            **selected_memory,
            "short_term": limited_short_term if "short_term" in memory_scope else [],
            "long_term_facts": limited_facts if "facts" in memory_scope else [],
            "preferences": limited_preferences if "preferences" in memory_scope else [],
            "summaries": limited_summaries if "summaries" in memory_scope else []
        }
        
        logger.info(
            "Synthesis memory scope applied | memory_scope=%s | short_term=%s | facts=%s | preferences=%s | summaries=%s",
            memory_scope,
            len(selected_memory.get("short_term", [])),
            len(selected_memory.get("long_term_facts", [])),
            len(selected_memory.get("preferences", [])),
            len(selected_memory.get("summaries", []))
        )

        # Detailed synthesis memory visibility.
        # This confirms the exact memory payload passed into CAWorkbenchSynthesisTool.
        for idx, item in enumerate(selected_memory.get("short_term", []), 1):
            content = str(item.get("content", "") or "").strip()
            normalized_content = " ".join(content.split())

            logger.info(
                "SYNTHESIS short_term item | idx=%s | event_id=%s | timestamp=%s | role=%s | original_chars=%s | included_chars=%s | preview=%s",
                idx,
                item.get("event_id"),
                item.get("timestamp"),
                item.get("role"),
                len(normalized_content),
                len(normalized_content),
                preview_head_tail(normalized_content)
            )

        for idx, fact in enumerate(selected_memory.get("long_term_facts", []), 1):
            content = str(fact.get("content", "") or "").strip()
            normalized_content = " ".join(content.split())

            logger.info(
                "SYNTHESIS fact item | idx=%s | record_id=%s | namespace=%s | original_chars=%s | included_chars=%s | preview=%s",
                idx,
                fact.get("record_id"),
                fact.get("namespace"),
                len(normalized_content),
                len(normalized_content),
                preview_head_tail(normalized_content)
            )

        for idx, preference in enumerate(selected_memory.get("preferences", []), 1):
            content = str(preference or "").strip()
            normalized_content = " ".join(content.split())

            logger.info(
                "SYNTHESIS preference item | idx=%s | original_chars=%s | included_chars=%s | preview=%s",
                idx,
                len(normalized_content),
                len(normalized_content),
                preview_head_tail(normalized_content)
            )

        for idx, summary in enumerate(selected_memory.get("summaries", []), 1):
            content = str(summary.get("content", "") or "").strip()
            normalized_content = " ".join(content.split())

            logger.info(
                "SYNTHESIS summary item | idx=%s | record_id=%s | namespace=%s | original_chars=%s | included_chars=%s | preview=%s",
                idx,
                summary.get("record_id"),
                summary.get("namespace"),
                len(normalized_content),
                len(normalized_content),
                preview_head_tail(normalized_content)
            )

        format_instruction = (
            state.get('format_instruction')
            or state.get('format_instructions')
        )
        context_instruction = state.get('context_instruction')

        web_results = state.get('web_results', []) or []
        kb_results = state.get('kb_results')
        curated_results = state.get('curated_results')

        logger.info(f"Synthesis mode: {synthesis_mode}")
        logger.info(f"Intent: {intent}")
        logger.info(f"Research query: {research_query}")
        logger.info(f"Format instruction: {format_instruction}")
        logger.info(f"Web results: {len(web_results)}")
        logger.info(f"KB results: {'Present' if kb_results else 'None'}")
        logger.info(f"Curated results: {'Present' if curated_results else 'None'}")

        # Call appropriate synthesis function from tool
        if synthesis_mode == 'reformat_previous_response':
            synthesis_result = synthesize_format_only(
                user_query=user_query,
                short_term_memory=selected_memory.get('short_term', []),
                format_instructions=format_instruction
            )

        elif synthesis_mode == 'combine_previous_context_with_new_research':
            synthesis_result = synthesize_with_memory(
                user_query=user_query,
                research_query=research_query,
                intent=intent,
                synthesis_mode=synthesis_mode,
                requires_research=state.get("requires_research"),
                memory_scope=memory_scope,
                context_instruction=context_instruction,
                format_instruction=format_instruction,
                planner_reason=state.get("planner_reason"),
                web_results=web_results,
                kb_results=kb_results,
                curated_results=curated_results,
                selected_memory=selected_memory
            )

        else:
            synthesis_result = synthesize_new_question(
                user_query=user_query,
                research_query=research_query,
                intent=intent,
                synthesis_mode=synthesis_mode,
                requires_research=state.get("requires_research"),
                memory_scope=memory_scope,
                context_instruction=context_instruction,
                format_instruction=format_instruction,
                planner_reason=state.get("planner_reason"),
                web_results=web_results,
                kb_results=kb_results,
                curated_results=curated_results,
                selected_memory=selected_memory
            )

        # Add planner/context details into synthesis metadata
        synthesis_result.setdefault('metadata', {})
        synthesis_result['metadata'].update({
            'intent': intent,
            'synthesis_mode': synthesis_mode,
            'research_query': research_query,
            'requires_research': state.get('requires_research'),
            'memory_scope': state.get('memory_scope'),
            'format_instruction': format_instruction,
            'context_instruction': context_instruction,
            'planner_reason': state.get('planner_reason')
        })

        logger.info(f"Synthesis completed: {synthesis_result.get('status')}")

        return {
            'synthesis': synthesis_result,
            'steps': [f'Synthesis completed using mode: {synthesis_mode}']
        }

    except Exception as e:
        logger.error(f"Error in synthesis: {str(e)}", exc_info=True)

        return {
            'synthesis': {
                'status': 'error',
                'message': f'Synthesis failed: {str(e)}',
                'synthesis_text': None,
                'metadata': {
                    'error': str(e),
                    'error_type': type(e).__name__
                }
            },
            'errors': [f'Synthesis error: {str(e)}'],
            'steps': ['Synthesis failed']
        }
