"""
Memory Context Selection Node
Selects appropriate memory context based on classified intent
"""
import logging
from typing import Dict, Any
from ..state import AgentState

logger = logging.getLogger(__name__)


def memory_context_selection_node(state: AgentState) -> Dict[str, Any]:
    """
    Select memory context based on Planner LLM output.

    Planner output controls:
    - intent
    - requires_research
    - memory_scope
    - research_query
    - synthesis_mode
    - format_instruction

    Memory usage rules:
    - Fresh query:
        facts + preferences
        research required

    - Follow-up requiring research:
        short_term + facts + preferences
        research required using research_query

    - Follow-up format-only:
        short_term only
        no research
        synthesizer reformats previous assistant response
    """
    logger.info("=== MEMORY CONTEXT SELECTION NODE ===")

    try:
        intent = state.get('intent', 'new_question')
        requires_research = state.get('requires_research', True)
        memory_scope = state.get('memory_scope') or ['facts', 'preferences']
        research_query = state.get('research_query') or state.get('user_query', '')
        synthesis_mode = state.get('synthesis_mode') or 'fresh_research_answer'
        format_instruction = state.get('format_instruction') or state.get('format_instructions')
        context_instruction = state.get('context_instruction')

        memory_context = state.get('memory_context', {}) or {}

        logger.info(f"Intent: {intent}")
        logger.info(f"Requires research: {requires_research}")
        logger.info(f"Memory scope: {memory_scope}")
        logger.info(f"Research query: {research_query}")
        logger.info(f"Synthesis mode: {synthesis_mode}")

        selected_memory = {}

        if 'short_term' in memory_scope:
            selected_memory['short_term'] = memory_context.get('short_term', []) or []

        if 'facts' in memory_scope:
            selected_memory['long_term_facts'] = memory_context.get('long_term_facts', []) or []

        if 'preferences' in memory_scope:
            selected_memory['preferences'] = memory_context.get('preferences', []) or []

        if 'summaries' in memory_scope:
            selected_memory['summaries'] = memory_context.get('summaries', []) or []

        return {
            'selected_memory': selected_memory,

            # Current graph compatibility
            'use_tools': requires_research,

            # New planner contract
            'requires_research': requires_research,
            'research_query': research_query,
            'synthesis_mode': synthesis_mode,
            'format_instruction': format_instruction,
            'context_instruction': context_instruction,

            # Backward compatibility
            'enhanced_query': research_query,
            'format_instructions': format_instruction,

            'steps': [
                f'Memory selected for intent: {intent}',
                f'Memory scope: {memory_scope}',
                f'Requires research: {requires_research}',
                f'Synthesis mode: {synthesis_mode}'
            ]
        }

    except Exception as e:
        logger.error(f"Error in memory context selection: {str(e)}", exc_info=True)

        fallback_query = state.get('user_query', '')

        return {
            'selected_memory': state.get('memory_context', {}) or {},
            'use_tools': True,
            'requires_research': True,
            'research_query': fallback_query,
            'synthesis_mode': 'fresh_research_answer',
            'format_instruction': None,
            'context_instruction': 'Memory selection failed. Defaulting to fresh research flow.',

            # Backward compatibility
            'enhanced_query': fallback_query,
            'format_instructions': None,

            'errors': [f'Memory selection error: {str(e)}'],
            'steps': ['Memory selection failed, defaulting to fresh research flow']
        }


def reconstruct_query(
    original_query: str,
    intent_details: Dict[str, Any],
    short_term: list
) -> str:
    """
    Reconstruct query by combining original query with content additions
    
    Args:
        original_query: Current user query
        intent_details: Intent details with content_additions and original_query
        short_term: Short-term memory to extract original query if needed
        
    Returns:
        Enhanced query string
    """
    try:
        # Get content additions
        content_additions = intent_details.get('content_additions', [])
        
        # Try to extract original query from intent_details
        extracted_original = intent_details.get('original_query')
        
        # If no original query in intent_details, try to extract from short-term memory
        if not extracted_original and short_term:
            # Look for the last user query in short-term memory
            for event in reversed(short_term):
                if event.get('role') == 'user':
                    extracted_original = event.get('content', '')
                    break
        
        # Build enhanced query
        if extracted_original and content_additions:
            # Combine original query with additions
            additions_str = ', '.join(content_additions)
            enhanced = f"{extracted_original} AND {additions_str}"
            logger.info(f"Reconstructed query: '{enhanced}'")
            return enhanced
        elif content_additions:
            # Just add content to current query
            additions_str = ', '.join(content_additions)
            enhanced = f"{original_query} AND {additions_str}"
            logger.info(f"Enhanced query with additions: '{enhanced}'")
            return enhanced
        else:
            # No reconstruction needed
            return original_query
            
    except Exception as e:
        logger.error(f"Error reconstructing query: {str(e)}")
        return original_query


def extract_original_query_from_memory(short_term: list) -> str:
    """
    Extract the original user query from short-term memory
    
    Args:
        short_term: List of recent conversation events
        
    Returns:
        Original query string or empty string
    """
    if not short_term:
        return ""
    
    # Find the last user message (before current one)
    user_messages = [
        event.get('content', '')
        for event in short_term
        if event.get('role') == 'user'
    ]
    
    # Return second-to-last user message (last one is current query)
    if len(user_messages) >= 2:
        return user_messages[-2]
    elif len(user_messages) == 1:
        return user_messages[0]
    else:
        return ""
