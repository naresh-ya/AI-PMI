"""
Memory Storage Node
Saves conversation turn (user query + assistant response) back to AWS Memory
"""
import logging
from typing import Dict, Any
from ..state import AgentState
from ..memory.aws_memory_manager import AWSMemoryManager

logger = logging.getLogger(__name__)


def memory_storage_node(state: AgentState) -> Dict[str, Any]:
    """
    Store conversation turn in AWS AgentCore Memory.

    Stores only the short-term conversation event:
    - USER message
    - ASSISTANT final synthesized response

    AWS AgentCore Memory will automatically handle long-term extraction:
    - facts
    - preferences
    - summaries
    """
    logger.info("=== MEMORY STORAGE NODE ===")

    try:
        session_id = state.get('session_id')
        user_id = state.get('user_id')
        user_query = state.get('user_query', '')
        synthesis = state.get('synthesis', {}) or {}

        if not session_id:
            logger.warning("No session_id provided, skipping memory storage")
            return {
                'memory_stored': False,
                'steps': ['Memory storage skipped: no session_id']
            }

        if not user_id:
            logger.warning("No user_id provided, skipping memory storage")
            return {
                'memory_stored': False,
                'steps': ['Memory storage skipped: no user_id']
            }

        assistant_response = synthesis.get('synthesis_text') or ''

        if not assistant_response:
            logger.warning("No assistant response to store")
            return {
                'memory_stored': False,
                'steps': ['Memory storage skipped: no assistant response']
            }

        logger.info(
            f"Storing interaction in AWS AgentCore Memory: "
            f"user_id={user_id}, session_id={session_id}"
        )

        
        logger.info(
            "Memory storage content check | user_query_len=%s | assistant_response_len=%s | assistant_preview=%s",
            len(user_query),
            len(assistant_response),
            assistant_response[:500]
        )

        memory_manager = AWSMemoryManager()

        success = memory_manager.store_interaction(
            user_id=user_id,
            session_id=session_id,
            user_message=user_query,
            assistant_message=assistant_response
        )

        if success:
            logger.info("Conversation turn stored successfully in AWS AgentCore Memory")
            return {
                'memory_stored': True,
                'steps': [
                    f'Conversation turn stored in AWS AgentCore Memory for session: {session_id}'
                ]
            }

        logger.warning("AWS AgentCore Memory store_interaction returned False")
        return {
            'memory_stored': False,
            'errors': ['Memory storage failed: store_interaction returned False'],
            'steps': ['Memory storage failed']
        }

    except Exception as e:
        logger.error(f"Error storing memory: {str(e)}", exc_info=True)

        # Memory storage failure should not break the user response.
        return {
            'memory_stored': False,
            'errors': [f'Memory storage error: {str(e)}'],
            'steps': ['Memory storage failed non-critical']
        }


def store_interaction_metadata(
    memory_manager: AWSMemoryManager,
    state: AgentState,
    session_id: str,
    user_id: str
) -> None:
    """
    Store additional metadata about the interaction
    
    Args:
        memory_manager: AWS Memory Manager instance
        state: Current agent state
        session_id: Session ID
        user_id: User ID
    """
    try:
        # Extract metadata
        intent = state.get('intent', 'unknown')
        intent_details = state.get('intent_details', {})
        web_results_count = len(state.get('web_results', []))
        kb_status = state.get('kb_results', {}).get('status', 'none')
        curated_status = state.get('curated_results', {}).get('status', 'none')
        use_tools = state.get('use_tools', True)
        
        # Build metadata content
        metadata_content = {
            'intent': intent,
            'intent_context': intent_details.get('context', ''),
            'use_tools': use_tools,
            'web_results_count': web_results_count,
            'kb_status': kb_status,
            'curated_status': curated_status,
            'format_instructions': state.get('format_instructions'),
            'enhanced_query': state.get('enhanced_query')
        }
        
        # Store as METADATA type
        memory_manager.add_memory(
            session_id=session_id,
            user_id=user_id,
            memory_type='METADATA',
            content=str(metadata_content),
            metadata={
                'type': 'interaction_metadata',
                'timestamp': get_current_timestamp()
            }
        )
        
        logger.info("Stored interaction metadata")
        
    except Exception as e:
        logger.warning(f"Failed to store interaction metadata: {str(e)}")


def store_user_preference(
    memory_manager: AWSMemoryManager,
    session_id: str,
    user_id: str,
    preference_type: str,
    preference_value: str
) -> str:
    """
    Store a user preference for long-term memory
    
    Args:
        memory_manager: AWS Memory Manager instance
        session_id: Session ID
        user_id: User ID
        preference_type: Type of preference (format, detail_level, etc.)
        preference_value: Preference value
        
    Returns:
        Memory ID of stored preference
    """
    try:
        memory_id = memory_manager.add_memory(
            session_id=session_id,
            user_id=user_id,
            memory_type='PREFERENCE',
            content=f"{preference_type}: {preference_value}",
            metadata={
                'preference_type': preference_type,
                'preference_value': preference_value,
                'timestamp': get_current_timestamp()
            }
        )
        
        logger.info(f"Stored user preference: {preference_type} = {preference_value}")
        return memory_id
        
    except Exception as e:
        logger.error(f"Failed to store user preference: {str(e)}")
        raise


def get_current_timestamp() -> str:
    """Get current timestamp in ISO format"""
    from datetime import datetime
    return datetime.utcnow().isoformat() + 'Z'


def cleanup_old_memories(
    memory_manager: AWSMemoryManager,
    session_id: str,
    user_id: str,
    max_messages: int = 50
) -> None:
    """
    Clean up old memories to prevent unbounded growth
    
    Args:
        memory_manager: AWS Memory Manager instance
        session_id: Session ID
        user_id: User ID
        max_messages: Maximum number of messages to keep
    """
    try:
        # This would require additional AWS Memory API support
        # For now, just log the intent
        logger.info(f"Memory cleanup check for session {session_id} (max: {max_messages})")
        
        # Future implementation:
        # 1. Query all memories for session
        # 2. Sort by timestamp
        # 3. Delete oldest if count > max_messages
        # 4. Keep PREFERENCE type memories always
        
    except Exception as e:
        logger.warning(f"Memory cleanup failed: {str(e)}")
