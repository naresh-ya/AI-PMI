"""
State management for LangGraph orchestrator
"""
from typing import TypedDict, Optional, Dict, Any, List, Annotated
from operator import add


class AgentState(TypedDict):
    """
    State for the agent workflow - supports parallel execution
    Uses Annotated with reducers for keys that can be updated by multiple parallel nodes
    """
    # Input (read-only, not updated by parallel nodes)
    user_query: str
    session_id: str
    user_id: str  # User identifier for memory operations
    curated_urls: Optional[List[str]]  # Optional curated URLs
    
    # Memory context (retrieved from AWS AgentCore Memory)
    memory_context: Optional[Dict[str, Any]]  # Full memory: short-term + long-term + preferences
    selected_memory: Optional[Dict[str, Any]]  # Selected memory based on intent
     
    # Routing / planner output
    query_type: Optional[str]  # Legacy: 'new_question' or 'followup_question'

    # Planner intent:
    # - new_question
    # - followup_research
    # - followup_format_only
    intent: Optional[str]

    # Full planner details returned by Planner LLM
    intent_details: Optional[Dict[str, Any]]

    # Whether research agents should run
    requires_research: Optional[bool]

    # Memory scope selected by planner:
    # Examples:
    # - ['facts', 'preferences']
    # - ['short_term', 'facts', 'preferences']
    # - ['short_term']
    memory_scope: Optional[List[str]]

    
    # Memory storage
    memory_stored: Optional[bool]
    memory_storage_status: Optional[str]

    # Query that research agents should use.
    # For fresh query, usually same/cleaned user query.
    # For follow-up research, this should be rewritten for ONLY the new information requested.
    research_query: Optional[str]

    # Synthesizer mode:
    # - fresh_research_answer
    # - combine_previous_context_with_new_research
    # - reformat_previous_response
    synthesis_mode: Optional[str]

    # Formatting instruction for format-only follow-ups
    format_instruction: Optional[str]

    # Instruction telling synthesizer how to use memory/context
    context_instruction: Optional[str]

    # Human-readable planner reason for logs/debugging
    planner_reason: Optional[str]

    # Backward compatibility fields
    synthesize: Optional[bool]  # Deprecated - synthesizer always runs
    use_tools: Optional[bool]  # Backward compatible alias for requires_research

    # Query enhancement - backward compatibility
    enhanced_query: Optional[str]  # Backward compatible alias for research_query
    format_instructions: Optional[str]  # Backward compatible alias for format_instruction

    # Tool execution results (each node updates its own key - no conflicts)
    web_results: Optional[List[Dict[str, Any]]]
    kb_results: Optional[Dict[str, Any]]
    curated_results: Optional[Dict[str, Any]]
    
    # Synthesis (single node updates)
    synthesis: Optional[Dict[str, Any]]
    
    # Response generation (single node updates)
    final_response: str
    
    # Metadata (single node updates)
    metadata: Dict[str, Any]
    
    # Steps and errors - use Annotated with add reducer for parallel updates
    steps: Annotated[List[str], add]  # Multiple nodes can add steps
    errors: Annotated[List[str], add]  # Multiple nodes can add errors
