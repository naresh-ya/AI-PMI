# ccaiaa-workbench Repository - File Structure

**Repository:** https://source.app.pconnect.biz/scm/ccaiaa/ccaiaa-workbench.git  
**Branch:** feature/workbench  
**Latest Commit:** 1f4a044  
**Date:** 2026-07-15

---

## 📊 Repository Statistics

- **Total Files:** 77 files
- **Python Files:** 24 (.py files)
- **Cache Files:** 20 (.pyc files)
- **Documentation:** 5 (.md files)
- **Configuration:** 5 files (.dockerignore, .env.template, requirements.txt, buildspec.yml, shell scripts)

---

## 📁 Complete Directory Structure

```
ccaiaa-workbench/
└── CA Workbench/
    ├── .dockerignore
    ├── Dockerfile.agentcore
    ├── README.md
    ├── requirements.txt
    ├── buildscript.sh
    ├── buildscript_agentcore.sh
    ├── buildspec.yml
    │
    ├── app/
    │   └── main.py
    │
    ├── CAWorkbenchCuratedTool/
    │   ├── __init__.py
    │   ├── curated_processor.py
    │   └── __pycache__/
    │       ├── __init__.cpython-314.pyc
    │       └── curated_processor.cpython-314.pyc
    │
    ├── CAWorkbenchKBTool/
    │   ├── __init__.py
    │   ├── kb_retrieval.py
    │   └── __pycache__/
    │       ├── __init__.cpython-314.pyc
    │       └── kb_retrieval.cpython-314.pyc
    │
    ├── CAWorkbenchSynthesisTool/
    │   ├── __init__.py
    │   ├── synthesizer.py
    │   └── __pycache__/
    │       ├── __init__.cpython-314.pyc
    │       └── synthesizer.cpython-314.pyc
    │
    ├── CAWorkbenchWebTool/
    │   ├── __init__.py
    │   ├── gemini_client.py
    │   ├── gemini_search.py
    │   ├── scrapling_client.py
    │   ├── tavily_client.py
    │   ├── web_search.py
    │   ├── requirements.txt
    │   └── __pycache__/
    │       ├── __init__.cpython-314.pyc
    │       ├── gemini_client.cpython-314.pyc
    │       ├── gemini_search.cpython-314.pyc
    │       ├── scrapling_client.cpython-314.pyc
    │       ├── tavily_client.cpython-314.pyc
    │       └── web_search.cpython-314.pyc
    │
    ├── langgraph_orchestrator/
    │   ├── __init__.py
    │   ├── .env.template
    │   ├── requirements.txt
    │   ├── README_MEMORY_INTEGRATION.md
    │   ├── MEMORY_INTEGRATION_GUIDE.md
    │   ├── MEMORY_INTEGRATION_COMPLETE.md
    │   ├── AWS_MEMORY_API_VERIFICATION_REPORT.md
    │   ├── final_workflow.py
    │   ├── graph.py
    │   ├── main.py
    │   ├── memory_aware_graph.py
    │   ├── memory_aware_main.py
    │   ├── parallel_graph.py
    │   ├── router.py
    │   ├── state.py
    │   │
    │   ├── __pycache__/
    │   │   ├── __init__.cpython-314.pyc
    │   │   ├── final_workflow.cpython-314.pyc
    │   │   ├── graph.cpython-314.pyc
    │   │   ├── main.cpython-314.pyc
    │   │   ├── memory_aware_graph.cpython-314.pyc
    │   │   ├── memory_aware_main.cpython-314.pyc
    │   │   ├── parallel_graph.cpython-314.pyc
    │   │   ├── router.cpython-314.pyc
    │   │   └── state.cpython-314.pyc
    │   │
    │   ├── memory/
    │   │   ├── __init__.py
    │   │   ├── aws_memory_manager.py
    │   │   └── __pycache__/
    │   │       ├── __init__.cpython-314.pyc
    │   │       └── aws_memory_manager.cpython-314.pyc
    │   │
    │   ├── nodes/
    │   │   ├── __init__.py
    │   │   ├── intent_classifier.py
    │   │   ├── memory_context_selector.py
    │   │   ├── memory_retrieval.py
    │   │   ├── memory_storage.py
    │   │   ├── synthesis.py
    │   │   └── __pycache__/
    │   │       ├── __init__.cpython-314.pyc
    │   │       ├── memory_context_selector.cpython-314.pyc
    │   │       ├── memory_retrieval.cpython-314.pyc
    │   │       └── memory_storage.cpython-314.pyc
    │   │
    │   └── troubleshooting/
    │       ├── test_memory_api_direct.py
    │       ├── test_memory_integration_local.py
    │       └── test_venv.py
    │
    └── memory_context/
        ├── __init__.py
        ├── memory_checker.py
        └── __pycache__/
            ├── __init__.cpython-314.pyc
            └── memory_checker.cpython-314.pyc
```

---

## 📝 Detailed File Listing

### Root Level Files
```
CA Workbench/.dockerignore
CA Workbench/Dockerfile.agentcore
CA Workbench/README.md
CA Workbench/requirements.txt
CA Workbench/buildscript.sh
CA Workbench/buildscript_agentcore.sh
CA Workbench/buildspec.yml
```

### App Module
```
CA Workbench/app/main.py
```

### CAWorkbenchCuratedTool (Curated Content Processing)
```
CA Workbench/CAWorkbenchCuratedTool/__init__.py
CA Workbench/CAWorkbenchCuratedTool/curated_processor.py
CA Workbench/CAWorkbenchCuratedTool/__pycache__/__init__.cpython-314.pyc
CA Workbench/CAWorkbenchCuratedTool/__pycache__/curated_processor.cpython-314.pyc
```

### CAWorkbenchKBTool (Knowledge Base Tool)
```
CA Workbench/CAWorkbenchKBTool/__init__.py
CA Workbench/CAWorkbenchKBTool/kb_retrieval.py
CA Workbench/CAWorkbenchKBTool/__pycache__/__init__.cpython-314.pyc
CA Workbench/CAWorkbenchKBTool/__pycache__/kb_retrieval.cpython-314.pyc
```

### CAWorkbenchSynthesisTool (Synthesis Tool)
```
CA Workbench/CAWorkbenchSynthesisTool/__init__.py
CA Workbench/CAWorkbenchSynthesisTool/synthesizer.py
CA Workbench/CAWorkbenchSynthesisTool/__pycache__/__init__.cpython-314.pyc
CA Workbench/CAWorkbenchSynthesisTool/__pycache__/synthesizer.cpython-314.pyc
```

### CAWorkbenchWebTool (Web Search Tool)
```
CA Workbench/CAWorkbenchWebTool/__init__.py
CA Workbench/CAWorkbenchWebTool/gemini_client.py
CA Workbench/CAWorkbenchWebTool/gemini_search.py
CA Workbench/CAWorkbenchWebTool/scrapling_client.py
CA Workbench/CAWorkbenchWebTool/tavily_client.py
CA Workbench/CAWorkbenchWebTool/web_search.py
CA Workbench/CAWorkbenchWebTool/requirements.txt
CA Workbench/CAWorkbenchWebTool/__pycache__/__init__.cpython-314.pyc
CA Workbench/CAWorkbenchWebTool/__pycache__/gemini_client.cpython-314.pyc
CA Workbench/CAWorkbenchWebTool/__pycache__/gemini_search.cpython-314.pyc
CA Workbench/CAWorkbenchWebTool/__pycache__/scrapling_client.cpython-314.pyc
CA Workbench/CAWorkbenchWebTool/__pycache__/tavily_client.cpython-314.pyc
CA Workbench/CAWorkbenchWebTool/__pycache__/web_search.cpython-314.pyc
```

### LangGraph Orchestrator (Main Orchestration)
```
CA Workbench/langgraph_orchestrator/__init__.py
CA Workbench/langgraph_orchestrator/.env.template
CA Workbench/langgraph_orchestrator/requirements.txt
CA Workbench/langgraph_orchestrator/README_MEMORY_INTEGRATION.md
CA Workbench/langgraph_orchestrator/MEMORY_INTEGRATION_GUIDE.md
CA Workbench/langgraph_orchestrator/MEMORY_INTEGRATION_COMPLETE.md
CA Workbench/langgraph_orchestrator/AWS_MEMORY_API_VERIFICATION_REPORT.md
CA Workbench/langgraph_orchestrator/final_workflow.py
CA Workbench/langgraph_orchestrator/graph.py
CA Workbench/langgraph_orchestrator/main.py
CA Workbench/langgraph_orchestrator/memory_aware_graph.py
CA Workbench/langgraph_orchestrator/memory_aware_main.py
CA Workbench/langgraph_orchestrator/parallel_graph.py
CA Workbench/langgraph_orchestrator/router.py
CA Workbench/langgraph_orchestrator/state.py
CA Workbench/langgraph_orchestrator/__pycache__/__init__.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/final_workflow.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/graph.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/main.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/memory_aware_graph.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/memory_aware_main.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/parallel_graph.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/router.cpython-314.pyc
CA Workbench/langgraph_orchestrator/__pycache__/state.cpython-314.pyc
```

### LangGraph Orchestrator - Memory Module
```
CA Workbench/langgraph_orchestrator/memory/__init__.py
CA Workbench/langgraph_orchestrator/memory/aws_memory_manager.py
CA Workbench/langgraph_orchestrator/memory/__pycache__/__init__.cpython-314.pyc
CA Workbench/langgraph_orchestrator/memory/__pycache__/aws_memory_manager.cpython-314.pyc
```

### LangGraph Orchestrator - Nodes Module
```
CA Workbench/langgraph_orchestrator/nodes/__init__.py
CA Workbench/langgraph_orchestrator/nodes/intent_classifier.py
CA Workbench/langgraph_orchestrator/nodes/memory_context_selector.py
CA Workbench/langgraph_orchestrator/nodes/memory_retrieval.py
CA Workbench/langgraph_orchestrator/nodes/memory_storage.py
CA Workbench/langgraph_orchestrator/nodes/synthesis.py
CA Workbench/langgraph_orchestrator/nodes/__pycache__/__init__.cpython-314.pyc
CA Workbench/langgraph_orchestrator/nodes/__pycache__/memory_context_selector.cpython-314.pyc
CA Workbench/langgraph_orchestrator/nodes/__pycache__/memory_retrieval.cpython-314.pyc
CA Workbench/langgraph_orchestrator/nodes/__pycache__/memory_storage.cpython-314.pyc
```

### LangGraph Orchestrator - Troubleshooting
```
CA Workbench/langgraph_orchestrator/troubleshooting/test_memory_api_direct.py
CA Workbench/langgraph_orchestrator/troubleshooting/test_memory_integration_local.py
CA Workbench/langgraph_orchestrator/troubleshooting/test_venv.py
```

### Memory Context Module
```
CA Workbench/memory_context/__init__.py
CA Workbench/memory_context/memory_checker.py
CA Workbench/memory_context/__pycache__/__init__.cpython-314.pyc
CA Workbench/memory_context/__pycache__/memory_checker.cpython-314.pyc
```

---

## 🏗️ Architecture Overview

### Main Components

1. **App Module** (`app/`)
   - `main.py` - Main application entry point

2. **Tool Modules**
   - **CAWorkbenchCuratedTool** - Curated content processing
   - **CAWorkbenchKBTool** - Knowledge base retrieval
   - **CAWorkbenchSynthesisTool** - Content synthesis
   - **CAWorkbenchWebTool** - Web search (Tavily, Gemini, Scrapling)

3. **LangGraph Orchestrator** (`langgraph_orchestrator/`)
   - **Core Files:**
     - `main.py` - Main orchestrator
     - `memory_aware_main.py` - Memory-aware orchestrator
     - `graph.py` - Graph definition
     - `memory_aware_graph.py` - Memory-aware graph
     - `parallel_graph.py` - Parallel execution graph
     - `final_workflow.py` - Final workflow implementation
     - `router.py` - Request routing
     - `state.py` - State management
   
   - **Memory Module** (`memory/`)
     - `aws_memory_manager.py` - AWS memory management
   
   - **Nodes Module** (`nodes/`)
     - `intent_classifier.py` - Intent classification
     - `memory_context_selector.py` - Memory context selection
     - `memory_retrieval.py` - Memory retrieval
     - `memory_storage.py` - Memory storage
     - `synthesis.py` - Synthesis node
   
   - **Troubleshooting** (`troubleshooting/`)
     - Test scripts for memory integration

4. **Memory Context Module** (`memory_context/`)
   - `memory_checker.py` - Memory checking utilities

---

## 📦 Build & Deployment Files

### Docker
- `Dockerfile.agentcore` - AgentCore Docker configuration
- `.dockerignore` - Docker ignore patterns

### Build Scripts
- `buildscript.sh` - Standard build script
- `buildscript_agentcore.sh` - AgentCore build script
- `buildspec.yml` - AWS CodeBuild specification

### Dependencies
- `requirements.txt` (root) - Main dependencies
- `CAWorkbenchWebTool/requirements.txt` - Web tool dependencies
- `langgraph_orchestrator/requirements.txt` - Orchestrator dependencies

### Configuration
- `langgraph_orchestrator/.env.template` - Environment template

---

## 📚 Documentation Files

1. **README.md** - Main repository documentation
2. **README_MEMORY_INTEGRATION.md** - Memory integration overview
3. **MEMORY_INTEGRATION_GUIDE.md** - Memory integration guide
4. **MEMORY_INTEGRATION_COMPLETE.md** - Memory integration completion report
5. **AWS_MEMORY_API_VERIFICATION_REPORT.md** - AWS Memory API verification

---

## 🔧 Recent Changes (Commit: 1f4a044)

### Deleted Files (Cleanup)
- ❌ `CA Workbench/Dockerfile` (removed - using Dockerfile.agentcore)
- ❌ `CA Workbench/app/main_agentcore.py` (temp file)
- ❌ `CA Workbench/app/main_fixed.py` (temp file)
- ❌ `CA Workbench/app/main_original_backup.py` (backup file)

### Commit Message
```
chore: Remove temporary and backup files
- Removed Dockerfile, main_agentcore.py, main_fixed.py, main_original_backup.py
```

---

## 🎯 Key Features

### 1. Multi-Tool Integration
- **Curated Content** - Structured content processing
- **Knowledge Base** - KB retrieval and search
- **Web Search** - Multiple search providers (Tavily, Gemini, Scrapling)
- **Synthesis** - Content synthesis and summarization

### 2. LangGraph Orchestration
- **Memory-Aware Processing** - AWS memory integration
- **Parallel Execution** - Parallel graph processing
- **Intent Classification** - Smart routing based on intent
- **State Management** - Comprehensive state tracking

### 3. Memory Management
- **AWS Integration** - AWS memory API integration
- **Context Selection** - Smart context selection
- **Memory Retrieval** - Efficient memory retrieval
- **Memory Storage** - Persistent memory storage

### 4. AgentCore Deployment
- **Docker Support** - AgentCore Docker configuration
- **AWS CodeBuild** - Automated build pipeline
- **Build Scripts** - Automated build and deployment

---

## 🚀 Deployment

### Build Commands
```bash
# Standard build
./buildscript.sh

# AgentCore build
./buildscript_agentcore.sh
```

### Docker Build
```bash
docker build -f Dockerfile.agentcore -t ca-workbench-agentcore .
```

### AWS CodeBuild
Uses `buildspec.yml` for automated builds

---

## 📊 File Type Breakdown

| Type | Count | Purpose |
|------|-------|---------|
| Python (.py) | 24 | Source code |
| Cache (.pyc) | 20 | Compiled Python |
| Markdown (.md) | 5 | Documentation |
| Config | 5 | Configuration files |
| Shell (.sh) | 2 | Build scripts |
| **Total** | **77** | **All files** |

---

## 🔗 Repository Information

- **Repository:** ccaiaa-workbench
- **Branch:** feature/workbench
- **Remote:** https://source.app.pconnect.biz/scm/ccaiaa/ccaiaa-workbench.git
- **Latest Commit:** 1f4a044
- **Status:** ✅ Clean working tree

---

**Generated:** 2026-07-15  
**Python Version:** 3.14  
**Framework:** LangGraph + LiteLLM + Tavily + Gemini + Scrapling
