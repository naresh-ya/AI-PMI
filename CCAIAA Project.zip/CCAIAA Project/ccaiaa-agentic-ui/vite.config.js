import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: './',  // Use relative paths for assets
  server: {
    port: 3000,
    open: true,
    // Dev-only proxy for the CA Workbench API. Requests to /workbench-api are
    // forwarded server-side to API Gateway, so the browser treats them as
    // same-origin and never sends the CORS preflight (OPTIONS) that's failing
    // for routes whose CORS isn't configured on the backend (e.g.
    // /draft/categories). This applies to `vite dev` only — a production build
    // hits API Gateway directly and still needs CORS enabled there.
    proxy: {
      '/workbench-api': {
        target: 'https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod',
        changeOrigin: true,
        secure: false,
        rewrite: (path) => path.replace(/^\/workbench-api/, ''),
      },
    },
  },
})
