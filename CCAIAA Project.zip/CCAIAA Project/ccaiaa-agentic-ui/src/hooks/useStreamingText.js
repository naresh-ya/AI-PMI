import { useEffect, useRef, useState } from "react";

/**
 * useStreamingText
 * ---------------------------------------------------------------------------
 * Reveals `fullText` progressively instead of dumping it into the DOM in one
 * paint, producing the "tokens arriving over time" feel of Copilot/ChatGPT.
 *
 * Our backend (see services/api.js `pollAgentResponse`) returns the
 * assistant's answer as a single completed string once the job finishes —
 * it does not emit token-by-token chunks over SSE/WebSocket. To still get a
 * genuine streaming *experience* from that shape, this hook plays the final
 * text back at a controlled reveal rate on the client, the same technique
 * Copilot/ChatGPT clients fall back to for buffered responses.
 *
 * If/when the backend is upgraded to real token streaming (SSE, fetch
 * ReadableStream, WebSocket), swap this hook's input from "final string" to
 * "chunk appended over time" — the component using it (ChatMessageBubble)
 * doesn't need to change, since it only cares about `displayedText` /
 * `isStreaming`.
 *
 * Design choices for performance & UX:
 *  - Uses a fixed-interval timer (not one state update per character) so the
 *    number of re-renders is bounded regardless of response length —
 *    thousands of words stream in ~`maxDurationMs` using the same number of
 *    ticks as a one-sentence reply.
 *  - Reveal speed adapts to text length: short replies stream at a natural
 *    reading pace, long replies speed up automatically so the user isn't
 *    stuck waiting minutes for a multi-thousand-word answer to finish.
 *  - `onTick` fires on every reveal step so the caller can re-run the
 *    "auto-scroll if near bottom" check while content grows.
 *  - `onComplete` fires exactly once, the moment the reveal actually
 *    finishes on its own (never on the instant/non-active path, since that
 *    text was never "revealed" to begin with). This is the hook's way of
 *    telling the caller "this message is done streaming — if you're
 *    persisting an isStreaming flag on the message itself, this is when to
 *    clear it" so the message doesn't replay the typing effect the next
 *    time its bubble mounts (e.g. switching chats and back).
 *
 * @param {Object} options
 * @param {string} options.fullText   The complete text to reveal.
 * @param {boolean} options.isActive  Set false to render `fullText` instantly
 *                                    (e.g. for messages loaded from history).
 * @param {string|number} options.streamKey  Unique id for the message being
 *                                    streamed; changing it resets the reveal.
 * @param {number} [options.minCharsPerSecond=250]
 * @param {number} [options.maxDurationMs=4000]
 * @param {number} [options.tickMs=30]
 * @param {() => void} [options.onTick]
 * @param {() => void} [options.onComplete]
 */
export function useStreamingText({
  fullText,
  isActive,
  streamKey,
  minCharsPerSecond = 250,
  maxDurationMs = 4000,
  tickMs = 30,
  onTick,
  onComplete,
}) {
  const [displayedText, setDisplayedText] = useState(
    isActive ? "" : fullText || "",
  );
  const [isStreaming, setIsStreaming] = useState(Boolean(isActive));

  // Keep the latest onTick/onComplete without forcing the effect below to
  // re-subscribe.
  const onTickRef = useRef(onTick);
  onTickRef.current = onTick;
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const intervalRef = useRef(null);
  const lastStreamKeyRef = useRef(streamKey);

  useEffect(() => {
    const text = fullText || "";

    // Non-streaming path: render instantly (used for messages restored from
    // conversation history — only the live in-flight answer should type out).
    if (!isActive) {
      setDisplayedText(text);
      setIsStreaming(false);
      return;
    }

    // Reset the reveal whenever we start streaming a *different* message.
    lastStreamKeyRef.current = streamKey;
    setDisplayedText("");
    setIsStreaming(true);

    const totalChars = text.length;
    if (totalChars === 0) {
      setIsStreaming(false);
      onCompleteRef.current?.();
      return;
    }

    // Bound total reveal time for very long responses while keeping short
    // ones from feeling instant.
    const effectiveCharsPerSecond = Math.max(
      minCharsPerSecond,
      totalChars / (maxDurationMs / 1000),
    );
    const charsPerTick = Math.max(
      1,
      Math.ceil((effectiveCharsPerSecond * tickMs) / 1000),
    );

    let revealed = 0;
    intervalRef.current = setInterval(() => {
      revealed = Math.min(totalChars, revealed + charsPerTick);
      setDisplayedText(text.slice(0, revealed));
      onTickRef.current?.();

      if (revealed >= totalChars) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
        setIsStreaming(false);
        onCompleteRef.current?.();
      }
    }, tickMs);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- intentionally
    // keyed on streamKey/isActive/fullText only; interval params are stable.
  }, [fullText, isActive, streamKey]);

  return { displayedText, isStreaming };
}

export default useStreamingText;
