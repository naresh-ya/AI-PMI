import { useCallback, useEffect, useRef, useState } from "react";

/**
 * useAutoScrollChat
 * ---------------------------------------------------------------------------
 * Implements the "smart auto-scroll" behavior used by modern AI chat UIs
 * (Copilot, ChatGPT, Teams, Slack):
 *
 *  - While the user is near the bottom of the scroll container, new content
 *    (streamed tokens, new messages) keeps the viewport pinned to the latest
 *    message automatically.
 *  - The instant the user scrolls away from the bottom — even mid-stream —
 *    auto-scroll is disabled so their reading position is preserved. New
 *    content keeps rendering underneath without forcing the viewport down.
 *  - Exposes `showJumpButton` so the caller can render a floating "jump to
 *    latest" button, and `jumpToBottom()` to handle its click.
 *
 * IMPORTANT: the scroll container must use normal chronological DOM order
 * (oldest message first, newest last) with `overflow-y: auto`, and a bottom
 * sentinel element (via `bottomRef`) placed after the last message. This
 * avoids the cross-browser inconsistencies of `flex-direction: column-reverse`
 * scrollTop math, which is why the message list order matters here.
 *
 * @param {Object} options
 * @param {number} [options.threshold=100] "Near bottom" distance in pixels.
 */
export function useAutoScrollChat({ threshold = 100 } = {}) {
  // The scrollable element itself (attach to the message-list <div>).
  const containerRef = useRef(null);
  // An empty sentinel <div> rendered immediately after the last message —
  // scrolling this into view is more robust than computing scrollHeight
  // manually (it accounts for images/markdown reflow, etc.).
  const bottomRef = useRef(null);

  // Mirrors `shouldAutoScroll` in a ref so the scroll listener (and any
  // streaming tick callback) always reads the latest value synchronously,
  // without needing to re-subscribe the DOM listener on every state change.
  const shouldAutoScrollRef = useRef(true);

  const [shouldAutoScroll, setShouldAutoScrollState] = useState(true);
  const [showJumpButton, setShowJumpButton] = useState(false);

  /** Returns true if the container is scrolled within `threshold`px of the bottom. */
  const isNearBottom = useCallback(() => {
    const el = containerRef.current;
    if (!el) return true;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    return distanceFromBottom <= threshold;
  }, [threshold]);

  // Single place that keeps the ref, state, and jump-button visibility in sync.
  const applyAutoScrollState = useCallback((value) => {
    shouldAutoScrollRef.current = value;
    setShouldAutoScrollState(value);
    setShowJumpButton(!value);
  }, []);

  // Re-evaluate "near bottom" on every user scroll (throttled via rAF so we
  // never do this work more than once per frame, even on trackpad/inertial
  // scrolling that fires dozens of scroll events per second).
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    let rafPending = false;
    const handleScroll = () => {
      if (rafPending) return;
      rafPending = true;
      requestAnimationFrame(() => {
        applyAutoScrollState(isNearBottom());
        rafPending = false;
      });
    };

    el.addEventListener("scroll", handleScroll, { passive: true });
    return () => el.removeEventListener("scroll", handleScroll);
  }, [isNearBottom, applyAutoScrollState]);

  /**
   * Call this after appending new content (new message, streamed chunk).
   * Only actually scrolls when the user is currently anchored to the bottom
   * — this is what keeps the viewport pinned during streaming without ever
   * yanking the view back down while someone is reading up above.
   */
  const scrollToBottomIfAllowed = useCallback((behavior = "auto") => {
    if (!shouldAutoScrollRef.current) return;
    bottomRef.current?.scrollIntoView({ behavior, block: "end" });
  }, []);

  /**
   * Explicit "jump to latest" — always scrolls (used by the floating
   * down-arrow button) and re-enables auto-scroll for subsequent content.
   */
  const jumpToBottom = useCallback(
    (behavior = "smooth") => {
      bottomRef.current?.scrollIntoView({ behavior, block: "end" });
      applyAutoScrollState(true);
    },
    [applyAutoScrollState],
  );

  return {
    containerRef,
    bottomRef,
    shouldAutoScroll,
    showJumpButton,
    scrollToBottomIfAllowed,
    jumpToBottom,
    isNearBottom,
  };
}

export default useAutoScrollChat;
