import { useCallback, useEffect, useRef, useState } from "react";

/**
 * useSpeechRecognition
 * ---------------------------------------------------------------------------
 * Thin wrapper around the browser's built-in Web Speech API
 * (SpeechRecognition / webkitSpeechRecognition) for voice-to-text input.
 * No external service, API key, or network call of ours is involved — this
 * is purely a browser feature (supported in Chrome, Edge, Safari 14.1+, and
 * Samsung Internet; not supported in Firefox without a flag).
 *
 * Usage:
 *   const { isSupported, isListening, toggleListening } = useSpeechRecognition({
 *     onResult: (transcript) => setChatInput((prev) => `${prev}${transcript}`),
 *   });
 *
 * @param {Object} options
 * @param {(transcript: string) => void} options.onResult - called with the
 *   finalized transcript text once the user pauses/stops speaking a phrase.
 *   Only *final* results are reported (not interim/in-progress guesses), so
 *   this is safe to append directly onto existing input text.
 * @param {(error: string) => void} [options.onError] - called with a short
 *   error reason (e.g. "not-allowed", "no-speech") if recognition fails.
 * @param {string} [options.lang="en-US"] - recognition language.
 */
export function useSpeechRecognition({ onResult, onError, lang = "en-US" } = {}) {
  const SpeechRecognitionClass =
    typeof window !== "undefined"
      ? window.SpeechRecognition || window.webkitSpeechRecognition
      : null;
  const isSupported = Boolean(SpeechRecognitionClass);

  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef(null);

  // Keep the latest callbacks available to the recognition event handlers
  // without needing to tear down/recreate the recognizer on every render.
  const onResultRef = useRef(onResult);
  onResultRef.current = onResult;
  const onErrorRef = useRef(onError);
  onErrorRef.current = onError;

  useEffect(() => {
    if (!isSupported) return;

    const recognition = new SpeechRecognitionClass();
    recognition.lang = lang;
    // Keeps listening across pauses instead of stopping after the first
    // phrase — closer to how a "press mic, speak a full message" input
    // should behave.
    recognition.continuous = true;
    // Also surface interim (in-progress) results internally so the mic
    // stays visibly "live", but we only ever report finalized text via
    // onResult to avoid callers double-appending partial guesses.
    recognition.interimResults = true;

    recognition.onresult = (event) => {
      let finalTranscript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          finalTranscript += result[0].transcript;
        }
      }
      if (finalTranscript.trim()) {
        onResultRef.current?.(finalTranscript.trim());
      }
    };

    recognition.onerror = (event) => {
      onErrorRef.current?.(event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      recognition.onresult = null;
      recognition.onerror = null;
      recognition.onend = null;
      recognition.stop();
      recognitionRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- recreate only
    // when support/lang actually change; callbacks are read via refs above.
  }, [isSupported, lang]);

  const startListening = useCallback(() => {
    if (!recognitionRef.current || isListening) return;
    try {
      recognitionRef.current.start();
      setIsListening(true);
    } catch (error) {
      // start() throws if called while already running (e.g. a rapid
      // double-click) — safe to ignore, the recognizer stays as-is.
      onErrorRef.current?.(error?.message || "start-failed");
    }
  }, [isListening]);

  const stopListening = useCallback(() => {
    if (!recognitionRef.current || !isListening) return;
    recognitionRef.current.stop();
    setIsListening(false);
  }, [isListening]);

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  return {
    isSupported,
    isListening,
    startListening,
    stopListening,
    toggleListening,
  };
}

export default useSpeechRecognition;
