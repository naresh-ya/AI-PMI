import { useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import { AppProvider, useApp } from "./context/AppContext";
import Layout from "./components/Layout";
import ToastContainer from "./components/ui/Toast";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import NewRequest from "./components/NewRequest";
import RequestDetail from "./components/RequestDetail";
import ApprovalQueue from "./components/ApprovalQueue";
import SignedDocuments from "./components/SignedDocuments";
import ScrollToTop from "./components/ui/ScrollToTop";
import AuthCallback from "./components/AuthCallback";
import { getAuthenticatedUser } from "./services/cognitoService";

/**
 * ProtectedRoute — redirects to /login if not authenticated.
 */
function AuthInitializer({ children }) {
  const { login, logout } = useApp();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function init() {
      try {
        const user = await getAuthenticatedUser();

        if (user) {
          login({
            username: user.username,
          });
        } else {
          logout();
        }
      } finally {
        setLoading(false);
      }
    }

    init();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return children;
}

function ProtectedRoute({ children }) {
  const { state } = useApp();
  if (!state.isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return children;
}

function AppRoutes() {
  const { state, login } = useApp();
  useEffect(() => {
    async function init() {
      const user = await getAuthenticatedUser();
      if (user) {
        login({
          username: user.username,
        });
      }
    }

    init();
  }, []);

  return (
    <Routes>
      {/* Public route */}
      <Route
        path="/login"
        element={
          state.isAuthenticated ? <Navigate to="/" replace /> : <Login />
        }
      />
      <Route path="/callback" element={<AuthCallback />} />
      {/* Protected routes — wrapped in Layout */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/new-request"
        element={
          <ProtectedRoute>
            <Layout>
              <NewRequest />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/request/:id"
        element={
          <ProtectedRoute>
            <Layout>
              <RequestDetail />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/approvals"
        element={
          <ProtectedRoute>
            <Layout>
              <ApprovalQueue />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/signed-documents"
        element={
          <ProtectedRoute>
            <Layout>
              <SignedDocuments />
            </Layout>
          </ProtectedRoute>
        }
      />
      {/* Catch-all */}
      <Route
        path="*"
        element={
          <Navigate to={state.isAuthenticated ? "/" : "/login"} replace />
        }
      />
    </Routes>
  );
}

function App() {
  return (
    <AppProvider>
      <Router>
        <AuthInitializer>
          <ScrollToTop />
          <AppRoutes />
          <ToastContainer />
        </AuthInitializer>
      </Router>
    </AppProvider>
  );
}

export default App;
