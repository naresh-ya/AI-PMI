/**
 * Mock Data for PMI Agentic AI Platform
 *
 * Used during development while the backend API is under construction.
 * All screens use this data as the default, with API calls attempted first.
 */

// ─── Dashboard Requests ──────────────────────────────────────────────────────

export const MOCK_REQUESTS = [
  {
    request_id: "req_a1b2c3d4e5f6",
    id: 1,
    topic:
      "Government Submission – Anticipated Excise Rule Changes on Heated Tobacco Products",
    category: "Government Advocacy",
    useCase:
      "Document to govt in anticipation / influence of regulation change",
    document_type:
      "Government Advocacy – Document to govt in anticipation / influence of regulation change",
    jurisdiction: "India",
    status: "research",
    progress: 65,
    priority: "high",
    deadline: "2026-03-25",
    target_audience: "CBIC (Department of Revenue)",
    created_at: "2026-03-14T09:00:00.000Z",
    background:
      "CBIC is considering amendments to the excise duty notification for novel tobacco products including heated tobacco. PMI needs to submit a comprehensive position paper.",
    regulationTopic: "Excise duty structure for heated tobacco products",
    agentActivity: [
      { agent: "Input Validator", status: "completed", time: "15 min ago" },
      { agent: "Master Researcher", status: "in-progress", time: "now" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "3 min",
        findings:
          "Request validated. All required fields present. Target audience: CBIC. Jurisdiction: India. Language: English. Output: Word document.",
        confidence: 96,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "in-progress",
        duration: "45 min (ongoing)",
        findings:
          "Coordinating 3 sub-agents. Currently processing sources from PMI SharePoint, government databases, and academic repositories.",
        confidence: null,
        subAgents: [
          {
            name: "2.1 Internal Knowledge Agent",
            status: "completed",
            progress: 100,
            findings: "Found 23 PMI documents on excise regulations",
          },
          {
            name: "2.2 Database Crawling Agent",
            status: "in-progress",
            progress: 75,
            findings:
              "Processing PubMed and Scopus – 67 papers identified so far",
          },
          {
            name: "2.3 Web Crawling Agent",
            status: "in-progress",
            progress: 60,
            findings:
              "Crawling CBIC and MoHFW websites – 12 notifications found",
          },
        ],
      },
      {
        agent: "3. Master Drafting Agent",
        status: "pending",
        duration: "Not started",
        findings:
          "Waiting for research to complete. Will orchestrate Content Analysis and Content Drafting sub-agents. Est. 30 minutes.",
        confidence: null,
        subAgents: [
          {
            name: "3.1 Content Analysis Agent",
            status: "pending",
            progress: 0,
            findings: "Awaiting research data",
          },
          {
            name: "3.2 Content Drafting Agent",
            status: "pending",
            progress: 0,
            findings: "Awaiting analysis results",
          },
        ],
      },
      {
        agent: "4. Master Review Agent",
        status: "pending",
        duration: "Not started",
        findings:
          "Will orchestrate 3 specialist agents: Compliance & Risk, Regulatory, and Legal. Est. 10 minutes.",
        confidence: null,
        subAgents: [
          {
            name: "4.1 Compliance & Risk Review",
            status: "pending",
            progress: 0,
            findings: "Will check: youth claims, warnings, disclaimers",
          },
          {
            name: "4.2 Regulatory Review",
            status: "pending",
            progress: 0,
            findings: "Will verify: COTPA, FCTC compliance",
          },
          {
            name: "4.3 Legal Review",
            status: "pending",
            progress: 0,
            findings: "Will review: legal terminology, formal tone",
          },
        ],
      },
    ],
    timeline: [
      {
        time: "09:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "09:00 AM",
        event: "⚙️ Workflow orchestration initiated",
        type: "system",
      },
      {
        time: "09:00 AM",
        event: "🔍 Input Validator: Starting validation...",
        type: "agent",
      },
      {
        time: "09:03 AM",
        event: "✅ Input Validator: Request validated (96% confidence)",
        type: "agent",
      },
      {
        time: "09:03 AM",
        event: "🔬 Master Researcher: Deploying 3 sub-agents...",
        type: "agent",
      },
      {
        time: "09:05 AM",
        event: "📁 2.1 Internal Knowledge Agent: Scanning PMI SharePoint...",
        type: "agent",
      },
      {
        time: "09:15 AM",
        event: "✅ 2.1 Internal Knowledge: Found 23 relevant documents",
        type: "agent",
      },
      {
        time: "09:15 AM",
        event: "🗄️ 2.2 Database Crawling Agent: Querying academic databases...",
        type: "agent",
      },
      {
        time: "09:35 AM",
        event: "🌐 2.3 Web Crawling Agent: Processing CBIC notifications...",
        type: "agent",
      },
      {
        time: "09:45 AM",
        event: "🔄 Master Researcher: Research in progress (65% complete)...",
        type: "agent",
      },
    ],
  },
  {
    request_id: "req_f7g8h9i0j1k2",
    id: 2,
    topic: "Govt Advocacy Letter – MoHFW Tobacco Control Program Consultation",
    category: "Government Advocacy",
    useCase: "Point of View (PoV) on a topic to govt",
    document_type:
      "Government Advocacy – Point of View (PoV) on a topic to govt",
    jurisdiction: "India",
    status: "pending-approval",
    progress: 95,
    priority: "high",
    deadline: "2026-03-22",
    target_audience: "Ministry of Health & Family Welfare",
    created_at: "2026-03-13T08:30:00.000Z",
    background:
      "MoHFW is reviewing tobacco control measures under the National Tobacco Control Program. PMI seeks to provide evidence-based policy recommendations.",
    regulationTopic: "Tobacco control measures and public health policy",
    agentActivity: [
      { agent: "All Agents Complete", status: "completed", time: "30 min ago" },
      { agent: "Awaiting Final Approval", status: "pending", time: "now" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "3 min",
        findings:
          "Request validated. All required fields present. Target audience: MoHFW. High priority processing initiated.",
        confidence: 96,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "completed",
        duration: "1h 2min",
        findings:
          "Successfully orchestrated 3 sub-agents. Compiled 110 citations: PMI SharePoint (23 docs), CBIC notifications (12), Academic databases (67 papers), WHO TobReg (8 guidelines).",
        confidence: 92,
        subAgents: [
          {
            name: "2.1 Internal Knowledge Agent",
            status: "completed",
            progress: 100,
            findings:
              "Scanned PMI SharePoint – Found 23 policy briefs and legal memos",
          },
          {
            name: "2.2 Database Crawling Agent",
            status: "completed",
            progress: 100,
            findings:
              "Queried PubMed, Scopus, Lancet – Retrieved 67 peer-reviewed papers",
          },
          {
            name: "2.3 Web Crawling Agent",
            status: "completed",
            progress: 100,
            findings:
              "Crawled CBIC website, MoHFW portal – Extracted 12 notifications and 8 WHO guidelines",
          },
        ],
      },
      {
        agent: "3. Master Drafting Agent",
        status: "completed",
        duration: "30 min",
        findings:
          "Produced 2,450-word document with 8 sections. All citations properly formatted in APA style with snapshot dates.",
        confidence: 94,
        subAgents: [
          {
            name: "3.1 Content Analysis Agent",
            status: "completed",
            progress: 100,
            findings:
              "Analyzed 110 sources, identified key themes, recommended 8-section structure",
          },
          {
            name: "3.2 Content Drafting Agent",
            status: "completed",
            progress: 100,
            findings:
              "Generated draft with formal tone, all citations and disclaimers included",
          },
        ],
      },
      {
        agent: "4. Master Review Agent",
        status: "completed",
        duration: "9 min",
        findings:
          "All compliance checks passed. Document approved with 98% confidence. Ready for HITL gate.",
        confidence: 98,
        subAgents: [
          {
            name: "4.1 Compliance & Risk Review",
            status: "completed",
            progress: 100,
            findings:
              "No youth-targeted claims, all statutory warnings present",
          },
          {
            name: "4.2 Regulatory Review",
            status: "completed",
            progress: 100,
            findings: "COTPA 2003 and FCTC obligations respected",
          },
          {
            name: "4.3 Legal Review",
            status: "completed",
            progress: 100,
            findings: "Legal terminology accurate, formal tone maintained",
          },
        ],
      },
    ],
    timeline: [
      {
        time: "08:30 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "08:30 AM",
        event: "⚙️ Workflow orchestration initiated",
        type: "system",
      },
      {
        time: "08:30 AM",
        event: "🔍 Input Validator: Starting validation...",
        type: "agent",
      },
      {
        time: "08:33 AM",
        event: "✅ Input Validator: Request validated (96% confidence)",
        type: "agent",
      },
      {
        time: "08:33 AM",
        event: "🔬 Master Researcher: Deploying 3 sub-agents...",
        type: "agent",
      },
      {
        time: "08:45 AM",
        event: "✅ 2.1 Internal Knowledge: Found 23 PMI documents",
        type: "agent",
      },
      {
        time: "09:05 AM",
        event: "✅ 2.2 Database Crawler: Retrieved 67 papers",
        type: "agent",
      },
      {
        time: "09:20 AM",
        event:
          "✅ 2.3 Web Crawler: Extracted 12 notifications + 8 WHO guidelines",
        type: "agent",
      },
      {
        time: "09:35 AM",
        event:
          "✅ Master Researcher: Research complete – 110 citations compiled",
        type: "agent",
      },
      {
        time: "09:35 AM",
        event: "✍️ Master Drafting: Deploying 2 sub-agents...",
        type: "agent",
      },
      {
        time: "09:50 AM",
        event: "✅ 3.1 Content Analysis: 8-section structure recommended",
        type: "agent",
      },
      {
        time: "10:05 AM",
        event: "✅ 3.2 Content Drafting: Draft completed – 2,450 words",
        type: "agent",
      },
      {
        time: "10:05 AM",
        event: "🔎 Master Review: Initiating multi-agent review...",
        type: "agent",
      },
      {
        time: "10:07 AM",
        event: "✅ 4.1 Compliance: All checks passed",
        type: "agent",
      },
      {
        time: "10:08 AM",
        event: "✅ 4.2 Regulatory: Full compliance confirmed",
        type: "agent",
      },
      { time: "10:10 AM", event: "✅ 4.3 Legal: Review passed", type: "agent" },
      {
        time: "10:10 AM",
        event: "✅ Master Review: Document approved (98% confidence)",
        type: "agent",
      },
      {
        time: "10:14 AM",
        event: "📄 Document ready for HITL approval gate",
        type: "system",
      },
    ],
  },
  {
    request_id: "req_draft_review_001",
    id: 4,
    topic:
      "Industry Position Paper – Differential Taxation for Smoke-Free Products",
    category: "Industry Advocacy",
    useCase: "White papers on a policy / product",
    document_type: "Industry Advocacy – White papers on a policy / product",
    jurisdiction: "India",
    status: "draft",
    progress: 78,
    priority: "high",
    deadline: "2026-03-28",
    target_audience: "FICCI Tobacco Committee",
    created_at: "2026-03-15T10:00:00.000Z",
    background:
      "FICCI is preparing a consolidated industry position paper on differential taxation. PMI needs to contribute a technical white paper with global evidence on risk-proportionate taxation frameworks for smoke-free products.",
    regulationTopic: "Differential taxation for smoke-free alternatives",
    agentActivity: [
      { agent: "Master Drafter", status: "completed", time: "30 min ago" },
      { agent: "Awaiting HITL Draft Review", status: "pending", time: "now" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "2 min",
        findings:
          "Request validated. All fields present. Target audience: FICCI. Document type: White Paper.",
        confidence: 97,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "completed",
        duration: "48 min",
        findings:
          "Compiled 67 citations from all sources. Strong evidence base for differential taxation frameworks.",
        confidence: 93,
        subAgents: [
          {
            name: "2.1 Internal Knowledge Agent",
            status: "completed",
            progress: 100,
            findings: "15 PMI position papers on taxation policy",
          },
          {
            name: "2.2 Database Crawling Agent",
            status: "completed",
            progress: 100,
            findings: "38 academic papers on tobacco taxation economics",
          },
          {
            name: "2.3 Web Crawling Agent",
            status: "completed",
            progress: 100,
            findings: "14 government and WHO policy documents",
          },
        ],
      },
      {
        agent: "3. Master Drafting Agent",
        status: "completed",
        duration: "28 min",
        findings:
          "Produced 1,850-word white paper with 8 sections. All citations formatted in APA style. HITL quality gate pending.",
        confidence: 94,
        subAgents: [
          {
            name: "3.1 Content Analysis Agent",
            status: "completed",
            progress: 100,
            findings:
              "Identified 8-section structure with executive summary and global comparison framework",
          },
          {
            name: "3.2 Content Drafting Agent",
            status: "completed",
            progress: 100,
            findings:
              "Generated draft with formal tone, 67 citations, statutory disclaimers included",
          },
        ],
      },
      {
        agent: "4. Master Review Agent",
        status: "pending",
        duration: "Not started",
        findings:
          "Awaiting HITL approval of draft before initiating compliance review.",
        confidence: null,
        subAgents: [
          {
            name: "4.1 Compliance & Risk Review",
            status: "pending",
            progress: 0,
            findings: "Will check: youth claims, warnings, disclaimers",
          },
          {
            name: "4.2 Regulatory Review",
            status: "pending",
            progress: 0,
            findings: "Will verify: COTPA, FCTC compliance",
          },
          {
            name: "4.3 Legal Review",
            status: "pending",
            progress: 0,
            findings: "Will review: legal terminology, formal tone",
          },
        ],
      },
    ],
    timeline: [
      {
        time: "10:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "10:00 AM",
        event: "⚙️ Workflow orchestration initiated",
        type: "system",
      },
      {
        time: "10:02 AM",
        event: "✅ Input Validator: Request validated (97% confidence)",
        type: "agent",
      },
      {
        time: "10:02 AM",
        event: "🔬 Master Researcher: Deploying 3 sub-agents...",
        type: "agent",
      },
      {
        time: "10:18 AM",
        event: "✅ 2.1 Internal Knowledge: Found 15 PMI taxation documents",
        type: "agent",
      },
      {
        time: "10:32 AM",
        event:
          "✅ 2.2 Database Crawler: Retrieved 38 papers on taxation economics",
        type: "agent",
      },
      {
        time: "10:42 AM",
        event: "✅ 2.3 Web Crawler: Extracted 14 government/WHO documents",
        type: "agent",
      },
      {
        time: "10:50 AM",
        event: "✅ Master Researcher: Research complete – 67 citations",
        type: "agent",
      },
      {
        time: "10:50 AM",
        event: "✍️ Master Drafting: Deploying 2 sub-agents...",
        type: "agent",
      },
      {
        time: "11:02 AM",
        event: "✅ 3.1 Content Analysis: 8-section structure recommended",
        type: "agent",
      },
      {
        time: "11:18 AM",
        event:
          "✅ 3.2 Content Drafting: Draft completed – 1,850 words, 67 citations",
        type: "agent",
      },
      {
        time: "11:18 AM",
        event: "📄 Draft ready for HITL quality gate review",
        type: "system",
      },
    ],
  },
  {
    request_id: "req_l3m4n5o6p7q8",
    id: 3,
    topic: "Parliamentary Committee Submission – Tobacco Taxation Policy",
    category: "Government Advocacy",
    useCase: "Document to govt after a regulation change",
    document_type:
      "Government Advocacy – Document to govt after a regulation change",
    jurisdiction: "India",
    status: "completed",
    progress: 100,
    priority: "high",
    deadline: "2026-03-10",
    target_audience: "Parliamentary Standing Committee",
    created_at: "2026-03-08T07:00:00.000Z",
    background:
      "Parliamentary Standing Committee is reviewing proposed amendments to tobacco-related legislation.",
    regulationTopic: "Legislative proposals related to tobacco regulation",
    agentActivity: [
      { agent: "All Agents", status: "completed", time: "6d ago" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "2 min",
        findings: "Request validated successfully.",
        confidence: 98,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "completed",
        duration: "55 min",
        findings: "Compiled 89 citations from all sources.",
        confidence: 91,
      },
      {
        agent: "3. Master Drafting Agent",
        status: "completed",
        duration: "25 min",
        findings: "Generated 3,200-word submission with 10 sections.",
        confidence: 93,
      },
      {
        agent: "4. Master Review Agent",
        status: "completed",
        duration: "8 min",
        findings: "All compliance checks passed. Document approved.",
        confidence: 97,
      },
    ],
    timeline: [
      {
        time: "07:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "07:00 AM",
        event: "⚙️ Workflow orchestration initiated",
        type: "system",
      },
      {
        time: "07:02 AM",
        event: "✅ Input Validator: Request validated (98% confidence)",
        type: "agent",
      },
      {
        time: "07:57 AM",
        event: "✅ Master Researcher: 89 citations compiled",
        type: "agent",
      },
      {
        time: "08:22 AM",
        event: "✅ Master Drafting: 3,200-word document ready",
        type: "agent",
      },
      {
        time: "08:30 AM",
        event: "✅ Master Review: All checks passed (97%)",
        type: "agent",
      },
      {
        time: "08:35 AM",
        event: "✅ Document approved and delivered",
        type: "system",
      },
    ],
  },
  // ─── Vietnam ─────────────────────────
  {
    request_id: "req_vn_001",
    id: 5,
    topic: "Regulatory Position Paper – Vietnam Tobacco Control Law Amendment",
    category: "Government Advocacy",
    useCase:
      "Document to govt in anticipation / influence of regulation change",
    document_type:
      "Government Advocacy – Document to govt in anticipation / influence of regulation change",
    jurisdiction: "Vietnam",
    status: "research",
    progress: 55,
    priority: "high",
    deadline: "2026-04-05",
    target_audience: "Vietnam Ministry of Health (MoH)",
    created_at: "2026-03-16T06:00:00.000Z",
    background:
      "Vietnam's Ministry of Health is drafting amendments to the 2012 Tobacco Control Law to address heated tobacco and e-cigarettes. PMI needs to submit a position paper with global evidence on risk-proportionate regulation before the April consultation deadline.",
    regulationTopic:
      "Tobacco Control Law amendment – heated tobacco classification",
    agentActivity: [
      { agent: "Input Validator", status: "completed", time: "1d ago" },
      { agent: "Master Researcher", status: "in-progress", time: "now" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "2 min",
        findings: "Request validated. Jurisdiction: Vietnam. Target: MoH.",
        confidence: 95,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "in-progress",
        duration: "40 min (ongoing)",
        findings:
          "Deploying 3 sub-agents. Searching Vietnamese govt databases, WHO WPRO, and academic repositories.",
        confidence: null,
        subAgents: [
          {
            name: "2.1 Internal Knowledge Agent",
            status: "completed",
            progress: 100,
            findings: "11 PMI documents on Vietnam tobacco regulation",
          },
          {
            name: "2.2 Database Crawling Agent",
            status: "in-progress",
            progress: 65,
            findings: "29 papers on ASEAN tobacco regulation identified",
          },
          {
            name: "2.3 Web Crawling Agent",
            status: "in-progress",
            progress: 50,
            findings: "Crawling Vietnam MoH and WHO WPRO websites",
          },
        ],
      },
      {
        agent: "3. Master Drafting Agent",
        status: "pending",
        duration: "Not started",
        findings: "Awaiting research completion.",
        confidence: null,
      },
      {
        agent: "4. Master Review Agent",
        status: "pending",
        duration: "Not started",
        findings: "Awaiting draft.",
        confidence: null,
      },
    ],
    timeline: [
      {
        time: "06:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "06:02 AM",
        event: "✅ Input Validator: Request validated (95% confidence)",
        type: "agent",
      },
      {
        time: "06:02 AM",
        event: "🔬 Master Researcher: Deploying 3 sub-agents...",
        type: "agent",
      },
      {
        time: "06:15 AM",
        event:
          "✅ 2.1 Internal Knowledge: Found 11 Vietnam-related PMI documents",
        type: "agent",
      },
      {
        time: "06:35 AM",
        event: "🔄 2.2 Database Crawler: 29 ASEAN tobacco papers identified",
        type: "agent",
      },
      {
        time: "06:40 AM",
        event: "🌐 2.3 Web Crawler: Processing Vietnam MoH portal...",
        type: "agent",
      },
    ],
  },
  // ─── Thailand ────────────────────────
  {
    request_id: "req_th_001",
    id: 6,
    topic:
      "Government Response – Thailand FDA Heated Tobacco Product Classification",
    category: "Government Advocacy",
    useCase: "Response / reply to govt",
    document_type: "Government Advocacy – Response / reply to govt",
    jurisdiction: "Thailand",
    status: "pending-approval",
    progress: 92,
    priority: "high",
    deadline: "2026-03-24",
    target_audience: "Thailand Food and Drug Administration (FDA)",
    created_at: "2026-03-14T04:00:00.000Z",
    background:
      "Thailand FDA has issued a consultation on classifying heated tobacco products under the existing Tobacco Products Control Act B.E. 2560 (2017). PMI must respond with scientific evidence on product differentiation and risk assessment frameworks used in Japan and the UK.",
    regulationTopic: "Heated tobacco product classification under Thai FDA",
    agentActivity: [
      { agent: "All Agents Complete", status: "completed", time: "2h ago" },
      { agent: "Awaiting Final Approval", status: "pending", time: "now" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "2 min",
        findings: "Request validated. Jurisdiction: Thailand. High priority.",
        confidence: 96,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "completed",
        duration: "52 min",
        findings:
          "Compiled 78 citations. Strong evidence from Japan (44% cigarette decline) and UK (340% HTP growth) under differential frameworks.",
        confidence: 93,
        subAgents: [
          {
            name: "2.1 Internal Knowledge Agent",
            status: "completed",
            progress: 100,
            findings: "9 PMI documents on Thailand and ASEAN regulation",
          },
          {
            name: "2.2 Database Crawling Agent",
            status: "completed",
            progress: 100,
            findings: "42 papers on HTP classification science",
          },
          {
            name: "2.3 Web Crawling Agent",
            status: "completed",
            progress: 100,
            findings: "27 Thai FDA and WHO SEARO documents",
          },
        ],
      },
      {
        agent: "3. Master Drafting Agent",
        status: "completed",
        duration: "32 min",
        findings:
          "Generated 2,100-word response with global comparison: UK (340% HTP sales growth), Japan (44% cigarette decline), NZ (risk-linked excise), Sweden (5.6% smoking prevalence).",
        confidence: 95,
        subAgents: [
          {
            name: "3.1 Content Analysis Agent",
            status: "completed",
            progress: 100,
            findings:
              "Recommended 7-section structure with scientific evidence focus",
          },
          {
            name: "3.2 Content Drafting Agent",
            status: "completed",
            progress: 100,
            findings:
              "Formal response with 78 citations, all statutory disclaimers",
          },
        ],
      },
      {
        agent: "4. Master Review Agent",
        status: "completed",
        duration: "8 min",
        findings:
          "All compliance checks passed. Thai Tobacco Act B.E. 2560 compliance verified. Document approved at 96% confidence.",
        confidence: 96,
        subAgents: [
          {
            name: "4.1 Compliance & Risk Review",
            status: "completed",
            progress: 100,
            findings: "No promotional content, statutory warnings present",
          },
          {
            name: "4.2 Regulatory Review",
            status: "completed",
            progress: 100,
            findings: "Thai FDA Act B.E. 2560 compliance confirmed",
          },
          {
            name: "4.3 Legal Review",
            status: "completed",
            progress: 100,
            findings: "Legal terminology accurate for Thai regulatory context",
          },
        ],
      },
    ],
    timeline: [
      {
        time: "04:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "04:02 AM",
        event: "✅ Input Validator: Request validated (96%)",
        type: "agent",
      },
      {
        time: "04:54 AM",
        event: "✅ Master Researcher: 78 citations compiled",
        type: "agent",
      },
      {
        time: "05:26 AM",
        event: "✅ Master Drafting: 2,100-word response ready",
        type: "agent",
      },
      {
        time: "05:34 AM",
        event: "✅ Master Review: All checks passed (96%)",
        type: "agent",
      },
      {
        time: "05:36 AM",
        event: "📄 Document ready for HITL approval gate",
        type: "system",
      },
    ],
  },
  // ─── Bangladesh ──────────────────────
  {
    request_id: "req_bd_001",
    id: 7,
    topic: "Policy Briefing – Bangladesh Tobacco Taxation Reform Impact",
    category: "External Communications",
    useCase: "Press releases and media responses",
    document_type:
      "External Communications – Press releases and media responses",
    jurisdiction: "Bangladesh",
    status: "draft",
    progress: 72,
    priority: "medium",
    deadline: "2026-03-30",
    target_audience: "Bangladesh National Board of Revenue (NBR)",
    created_at: "2026-03-15T08:00:00.000Z",
    background:
      "Bangladesh NBR is proposing a restructuring of tobacco taxation with a supplementary duty increase of 15% on all tobacco products. PMI needs to present evidence that differential taxation (as seen in UK, Japan, Sweden) better serves public health and revenue goals than uniform rate increases.",
    regulationTopic: "Supplementary duty restructuring for tobacco products",
    agentActivity: [
      { agent: "Master Drafter", status: "in-progress", time: "now" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "3 min",
        findings: "Request validated. Jurisdiction: Bangladesh. NBR audience.",
        confidence: 94,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "completed",
        duration: "45 min",
        findings:
          "Compiled 52 citations. Key evidence: UK 340% HTP growth, Japan 44% cigarette decline, NZ risk-linked excise framework.",
        confidence: 90,
        subAgents: [
          {
            name: "2.1 Internal Knowledge Agent",
            status: "completed",
            progress: 100,
            findings: "8 PMI documents on South Asian tobacco taxation",
          },
          {
            name: "2.2 Database Crawling Agent",
            status: "completed",
            progress: 100,
            findings: "31 papers on tobacco taxation in developing economies",
          },
          {
            name: "2.3 Web Crawling Agent",
            status: "completed",
            progress: 100,
            findings: "13 NBR circulars and Bangladesh Finance Ministry docs",
          },
        ],
      },
      {
        agent: "3. Master Drafting Agent",
        status: "in-progress",
        duration: "20 min (ongoing)",
        findings:
          "Drafting policy briefing with global comparison framework including UK, NZ, Japan, Sweden evidence.",
        confidence: null,
        subAgents: [
          {
            name: "3.1 Content Analysis Agent",
            status: "completed",
            progress: 100,
            findings:
              "6-section structure with differential taxation comparison",
          },
          {
            name: "3.2 Content Drafting Agent",
            status: "in-progress",
            progress: 60,
            findings:
              "Generating draft with Bangladesh-specific revenue modelling",
          },
        ],
      },
      {
        agent: "4. Master Review Agent",
        status: "pending",
        duration: "Not started",
        findings: "Awaiting draft completion.",
        confidence: null,
      },
    ],
    timeline: [
      {
        time: "08:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "08:03 AM",
        event: "✅ Input Validator: Request validated (94%)",
        type: "agent",
      },
      {
        time: "08:48 AM",
        event: "✅ Master Researcher: 52 citations compiled",
        type: "agent",
      },
      {
        time: "08:48 AM",
        event: "✍️ Master Drafting: Deploying 2 sub-agents...",
        type: "agent",
      },
      {
        time: "09:00 AM",
        event: "✅ 3.1 Content Analysis: 6-section structure recommended",
        type: "agent",
      },
      {
        time: "09:08 AM",
        event: "🔄 3.2 Content Drafting: In progress (60%)...",
        type: "agent",
      },
    ],
  },
  // ─── Malaysia ────────────────────────
  {
    request_id: "req_my_001",
    id: 8,
    topic:
      "Industry Advocacy – Malaysia Excise Duty Framework for Smoke-Free Products",
    category: "Industry Advocacy",
    useCase: "Presentation on regulation / products",
    document_type: "Industry Advocacy – Presentation on regulation / products",
    jurisdiction: "Malaysia",
    status: "completed",
    progress: 100,
    priority: "high",
    deadline: "2026-03-12",
    target_audience: "Malaysian Ministry of Finance & Royal Malaysian Customs",
    created_at: "2026-03-09T05:00:00.000Z",
    background:
      "Malaysia's Royal Customs is reviewing the excise framework for novel tobacco products. PMI presented evidence from the UK (340% HTP sales growth under differential taxation), Japan (44% cigarette consumption decline), and Sweden (EU's lowest 5.6% smoking prevalence) to support risk-proportionate excise treatment.",
    regulationTopic:
      "Excise duty framework for heated tobacco and vape products",
    agentActivity: [
      { agent: "All Agents", status: "completed", time: "8d ago" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "2 min",
        findings:
          "Request validated. Jurisdiction: Malaysia. Dual audience: MoF + Customs.",
        confidence: 97,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "completed",
        duration: "50 min",
        findings:
          "Compiled 85 citations including UK, NZ, Japan, Sweden differential taxation data.",
        confidence: 94,
      },
      {
        agent: "3. Master Drafting Agent",
        status: "completed",
        duration: "35 min",
        findings:
          "Generated 2,800-word advocacy presentation with 9 sections and global comparison tables.",
        confidence: 95,
      },
      {
        agent: "4. Master Review Agent",
        status: "completed",
        duration: "10 min",
        findings:
          "All compliance checks passed. Document approved at 97% confidence.",
        confidence: 97,
      },
    ],
    timeline: [
      {
        time: "05:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "05:02 AM",
        event: "✅ Input Validator: Request validated (97%)",
        type: "agent",
      },
      {
        time: "05:52 AM",
        event: "✅ Master Researcher: 85 citations compiled",
        type: "agent",
      },
      {
        time: "06:27 AM",
        event: "✅ Master Drafting: 2,800-word presentation ready",
        type: "agent",
      },
      {
        time: "06:37 AM",
        event: "✅ Master Review: All checks passed (97%)",
        type: "agent",
      },
      {
        time: "06:40 AM",
        event: "✅ Document approved and delivered",
        type: "system",
      },
    ],
  },
  // ─── Bhutan ──────────────────────────
  {
    request_id: "req_bt_001",
    id: 9,
    topic:
      "Internal Assessment – Bhutan Tobacco Control Act Impact on Smoke-Free Products",
    category: "Internal Communications",
    useCase: "Internal communications on regulations & impact assessments",
    document_type:
      "Internal Communications – Internal communications on regulations & impact assessments",
    jurisdiction: "Bhutan",
    status: "research",
    progress: 40,
    priority: "medium",
    deadline: "2026-04-10",
    target_audience: "PMI APAC Regulatory Affairs Team",
    created_at: "2026-03-16T09:00:00.000Z",
    background:
      "Bhutan's Tobacco Control Act of 2010 was one of the world's strictest, banning all sales. The 2021 amendment partially lifted the ban. PMI needs an internal assessment of the current regulatory landscape and potential market access pathways for smoke-free alternatives, considering the New Zealand model of risk-linked regulation.",
    regulationTopic:
      "Bhutan Tobacco Control Act 2010 (amended 2021) – smoke-free product implications",
    agentActivity: [
      { agent: "Master Researcher", status: "in-progress", time: "now" },
    ],
    agentWorkflow: [
      {
        agent: "1. Input Validator",
        status: "completed",
        duration: "3 min",
        findings:
          "Request validated. Jurisdiction: Bhutan. Internal audience. Sensitivity: High.",
        confidence: 93,
      },
      {
        agent: "2. Master Researcher Agent",
        status: "in-progress",
        duration: "25 min (ongoing)",
        findings:
          "Limited public sources for Bhutan. Leveraging WHO SEARO data and regional comparisons.",
        confidence: null,
        subAgents: [
          {
            name: "2.1 Internal Knowledge Agent",
            status: "completed",
            progress: 100,
            findings: "4 PMI documents on Bhutan regulatory landscape",
          },
          {
            name: "2.2 Database Crawling Agent",
            status: "in-progress",
            progress: 45,
            findings:
              "12 papers on Bhutan tobacco policy and South Asian regulation",
          },
          {
            name: "2.3 Web Crawling Agent",
            status: "in-progress",
            progress: 30,
            findings:
              "Crawling Royal Government of Bhutan and WHO SEARO portals",
          },
        ],
      },
      {
        agent: "3. Master Drafting Agent",
        status: "pending",
        duration: "Not started",
        findings: "Awaiting research.",
        confidence: null,
      },
      {
        agent: "4. Master Review Agent",
        status: "pending",
        duration: "Not started",
        findings: "Awaiting draft.",
        confidence: null,
      },
    ],
    timeline: [
      {
        time: "09:00 AM",
        event: "Request submitted by Arvind Yadav",
        type: "user",
      },
      {
        time: "09:03 AM",
        event: "✅ Input Validator: Request validated (93%)",
        type: "agent",
      },
      {
        time: "09:03 AM",
        event: "🔬 Master Researcher: Deploying 3 sub-agents...",
        type: "agent",
      },
      {
        time: "09:15 AM",
        event:
          "✅ 2.1 Internal Knowledge: Found 4 Bhutan-related PMI documents",
        type: "agent",
      },
      {
        time: "09:25 AM",
        event:
          "🔄 Master Researcher: Limited sources — expanding to regional databases...",
        type: "agent",
      },
    ],
  },
  // ─── User Saved Drafts ─────────────────────────
  {
    request_id: "req_user_draft_001",
    id: 10,
    topic: "Excise Policy Consultation Response – Vietnam MoH",
    category: "Government Advocacy",
    useCase: "Response / reply to govt",
    document_type: "Government Advocacy – Response / reply to govt",
    jurisdiction: "Vietnam",
    status: "user-draft",
    progress: 0,
    priority: "high",
    deadline: "2026-04-15",
    target_audience: "Vietnam Ministry of Health",
    created_at: "2026-03-16T14:30:00.000Z",
    background:
      "Vietnam MoH has published a new consultation on heated tobacco excise policy. Need to prepare a comprehensive response with global evidence.",
    regulationTopic: "Excise policy for heated tobacco products",
    agentActivity: [],
    agentWorkflow: [],
    timeline: [
      { time: "02:30 PM", event: "Draft saved by Arvind Yadav", type: "user" },
    ],
  },
  {
    request_id: "req_user_draft_002",
    id: 11,
    topic:
      "FICCI Annual Conference – PMI Position on Risk-Proportionate Regulation",
    category: "Industry Advocacy",
    useCase: "Presentation on regulation / products",
    document_type: "Industry Advocacy – Presentation on regulation / products",
    jurisdiction: "India",
    status: "user-draft",
    progress: 0,
    priority: "medium",
    deadline: "",
    target_audience: "FICCI Members & Industry Leaders",
    created_at: "2026-03-15T16:00:00.000Z",
    background: "",
    regulationTopic: "",
    agentActivity: [],
    agentWorkflow: [],
    timeline: [
      { time: "04:00 PM", event: "Draft saved by Arvind Yadav", type: "user" },
    ],
  },
];

// ─── Policy Updates ──────────────────────────────────────────────────────────

export const MOCK_POLICY_UPDATES = [
  {
    id: 1,
    source: "MoHFW India",
    title:
      "National Tobacco Control Program – New consultation on heated tobacco regulation",
    date: "2026-03-15",
    priority: "high",
    jurisdiction: "India",
  },
  {
    id: 2,
    source: "CBIC",
    title:
      "Draft notification on excise duty structure for alternative tobacco products",
    date: "2026-03-14",
    priority: "high",
    jurisdiction: "India",
  },
  {
    id: 3,
    source: "Vietnam MoH",
    title:
      "Vietnam Ministry of Health publishes draft amendment to 2012 Tobacco Control Law – heated tobacco provisions",
    date: "2026-03-16",
    priority: "high",
    jurisdiction: "Vietnam",
  },
  {
    id: 4,
    source: "Thailand FDA",
    title:
      "Thai FDA opens public consultation on heated tobacco product classification under Tobacco Act B.E. 2560",
    date: "2026-03-15",
    priority: "high",
    jurisdiction: "Thailand",
  },
  {
    id: 5,
    source: "Bangladesh NBR",
    title:
      "Bangladesh National Board of Revenue proposes 15% supplementary duty increase on all tobacco products",
    date: "2026-03-14",
    priority: "high",
    jurisdiction: "Bangladesh",
  },
  {
    id: 6,
    source: "Malaysia Customs",
    title:
      "Royal Malaysian Customs Department issues review notice on excise framework for novel tobacco products",
    date: "2026-03-13",
    priority: "medium",
    jurisdiction: "Malaysia",
  },
  {
    id: 7,
    source: "WHO TobReg",
    title:
      "Updated guidelines on tobacco harm reduction – relevance to FCTC obligations",
    date: "2026-03-13",
    priority: "medium",
    jurisdiction: "Global",
  },
  {
    id: 8,
    source: "PIB",
    title: "Press release on Parliamentary Standing Committee hearing schedule",
    date: "2026-03-12",
    priority: "medium",
    jurisdiction: "India",
  },
  {
    id: 9,
    source: "Bhutan RGOB",
    title:
      "Royal Government of Bhutan – MoH clarification on 2021 Tobacco Control Act amendment and import provisions",
    date: "2026-03-11",
    priority: "medium",
    jurisdiction: "Bhutan",
  },
];

// ─── Notifications ───────────────────────────────────────────────────────────

export const MOCK_NOTIFICATIONS = [
  {
    id: "notif_1",
    title: "Draft Ready for Review",
    message:
      "MoHFW Tobacco Control Consultation letter is ready for your final approval.",
    type: "approval", // approval | info | warning
    read: false,
    requestId: "req_f7g8h9i0j1k2",
    time: "10 min ago",
    timestamp: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
  },
  {
    id: "notif_2",
    title: "Research Phase Complete",
    message:
      "Excise Rule Changes research gathered 110 citations. Master Drafter is now generating the document.",
    type: "info",
    read: false,
    requestId: "req_a1b2c3d4e5f6",
    time: "25 min ago",
    timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
  },
  {
    id: "notif_4",
    title: "Draft Ready for Review",
    message:
      "FICCI Differential Taxation white paper draft is ready. 1,850 words, 67 citations. Please review before it moves to compliance.",
    type: "approval",
    read: false,
    requestId: "req_draft_review_001",
    time: "30 min ago",
    timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
  },
  {
    id: "notif_3",
    title: "Policy Alert: CBIC Update",
    message:
      "New CBIC draft notification on excise duty structure detected. May be relevant to your active requests.",
    type: "warning",
    read: true,
    requestId: null,
    time: "2 hours ago",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
];

// ─── HITL Mock Checkpoints ───────────────────────────────────────────────────

export const MOCK_HITL_CHECKPOINTS = {
  // Request 2 has a pending final review checkpoint
  req_20260604043238_c27200ae: [
    {
      "hitl_id": "hitl_req_20260604043238_c27200ae_researcher_1748900123",
      "request_id": "req_20260604043238_c27200ae",
      "agent_name": "master_researcher",
      "status": "pending",
      "created_at": "2026-06-01T08:30:00+00:00",
      "topic": "Excise Duty Revision on Heated Tobacco Products",
      "user_id": "user_001",
      "retry_count": 0,
      "human_decision": null,
      "human_feedback": null,
      "removed_source_ids": [],
      "completed_at": null,
      "completed_by": null,
      "source_summary": {
        "total": 7,
        "uploaded_file": 1,
        "knowledge_base": 2,
        "external_url": 1,
        "internal_url": 1,
        "web_search": 2
      },
      "sources": [
        {
          "source_id": "src_001",
          "title": "HTP_Excise_Brief_2026.docx",
          "source_type": "uploaded_file",
          "relevance_score": null,
          "url": "",
          "summary": "PMI internal background note on the current excise structure for heated tobacco products in India. Notes that HTPs are taxed at par with cigarettes under COTPA despite significantly different risk profiles. Proposes a tiered duty structure aligned with Japan and South Korea precedents.",
          "reason": "Extracted from a user-uploaded input document. Included because it was explicitly provided as a reference for this request."
        },
        {
          "source_id": "src_002",
          "title": "HTP Excise Policy Brief 2024",
          "source_type": "knowledge_base",
          "relevance_score": 89,
          "url": "https://pmi.sharepoint.com/sites/CA/Documents/HTP_Excise_Policy_Brief_2024.pdf",
          "summary": "Comprehensive internal policy brief covering aerosol analysis data comparing HTP emissions to cigarette smoke across 12 harmful constituents. Includes regulatory precedents from Japan, South Korea, and EU member states applying differential excise treatment.",
          "reason": "Retrieved from PMI Knowledge Base with 89% semantic relevance to the research query. Selected as a primary internal reference."
        },
        {
          "source_id": "src_003",
          "title": "India Tobacco Tax Analysis 2025",
          "source_type": "knowledge_base",
          "relevance_score": 76,
          "url": "https://pmi.sharepoint.com/sites/CA/Documents/India_Tax_Analysis_2025.pdf",
          "summary": "Analysis of India's current tobacco excise framework under COTPA and GST. Covers CBIC notification history, duty rates by product category, and revenue impact modelling for a proposed three-tier structure.",
          "reason": "Retrieved from PMI Knowledge Base with 76% semantic relevance to the research query. Selected as a primary internal reference."
        },
        {
          "source_id": "src_004",
          "title": "cbic.gov.in",
          "source_type": "external_url",
          "relevance_score": 75,
          "url": "https://cbic.gov.in",
          "summary": "Central Board of Indirect Taxes and Customs portal. Contains latest circulars on GST and customs classification. Q1 2026 circular acknowledges novel tobacco product classification as an active policy area under review by the board.",
          "reason": "Retrieved from an external web link provided with the request. Included as a user-specified reference source."
        },
        {
          "source_id": "src_005",
          "title": "CBIC",
          "source_type": "internal_url",
          "relevance_score": 80,
          "url": "https://www.cbic.gov.in/",
          "summary": "Official Indian CBIC portal for GST and customs policies, updates, and taxpayer services. Selected by LLM as most relevant curated link for excise duty topic in India jurisdiction. Description match: customs, indirect tax, policy updates.",
          "reason": "Retrieved from an internal web link (SharePoint / PMI intranet). Selected for internal policy context with high relevance (80%)."
        },
        {
          "source_id": "src_006",
          "title": "CBIC Circular on Tobacco Product Taxation Q1 2026",
          "source_type": "web_search",
          "relevance_score": 82,
          "url": "https://cbic.gov.in/circulars/2026/tobacco-classification-q1.html",
          "summary": "CBIC has issued revised guidance on the classification of novel tobacco products including heated tobacco products and nicotine pouches. The circular confirms that the board is evaluating a risk-proportionate taxation framework aligned with international standards.",
          "reason": "Surfaced via external web search on the research topic. Selected for high topical relevance (82%)."
        },
        {
          "source_id": "src_007",
          "title": "Japan Risk-Tiered Tobacco Tax — A Model for Emerging Markets",
          "source_type": "web_search",
          "relevance_score": 74,
          "url": "https://taxfoundation.org/japan-tobacco-tax-tiered-structure-2025",
          "summary": "Analysis of Japan's three-tier tobacco excise structure introduced in 2018. HTPs are taxed at approximately 55% of the cigarette rate. Cigarette volumes declined 35% between 2016 and 2020 with no net excise revenue loss. Cited as a model for emerging market regulatory reform.",
          "reason": "Surfaced via external web search on the research topic. Selected for moderate topical relevance (74%)."
        }
      ]
    }
  ],
  // Request 1 has a pending research review checkpoint
  req_20260601063017_0ca80811: [
    {
      hitl_id: "hitl_req_20260601063017_0ca80811_master_researcher_001",
      request_id: "req_20260601063017_0ca80811",
      agent_name: "master_researcher",
      intervention_type: "approval_required",
      status: "pending",
      priority: "high",
      created_at: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
      agent_output: {
        research_strategy: {
          approach:
            "Multi-source triangulation with evidence quality assessment and chronological policy tracking across 4 research domains.",
          domains: [
            "PMI Internal SharePoint",
            "Government Databases (CBIC, MoHFW)",
            "Academic Literature (PubMed, Scopus)",
            "WHO/International Organizations",
          ],
        },
        sources_found: {
          internal: "23 PMI SharePoint documents",
          government: "12 CBIC/MoHFW notifications",
          academic: "67 papers (PubMed, Scopus, Lancet)",
          international: "8 WHO TobReg guidelines",
        },
        citation_count: 110,
        evidence_quality_score: 92,
        key_findings: [
          "CBIC has issued 3 draft notifications in last 6 months related to excise on novel tobacco products",
          "International trend toward differential taxation based on product risk profiles (India, Thailand, Vietnam)",
          "67 peer-reviewed papers support harm reduction approaches for smoke-free alternatives",
          "MoHFW NTCP objectives can be aligned with risk-proportionate regulation framework",
          "PMI prior submissions from 2024-2025 establish consistent regulatory position on excise matters",
        ],
        knowledge_gaps: [
          "State-level excise data for FY 2025-26 not yet published",
          "Recent parliamentary debate transcripts on tobacco taxation not available in public domain",
        ],
        policy_intelligence: {
          description:
            "The Policy Intelligence Generator continuously monitors laws, gazettes, consultation portals, court orders, tax/excise updates, pack/label rules, and trade restrictions. The following alerts were fed into the Researcher before it began its analysis.",
          alerts: [
            {
              source: "CBIC",
              title:
                "Draft notification on excise duty structure for alternative tobacco products",
              date: "2026-03-14",
              jurisdiction: "India",
              relevance: "high",
              summary:
                "CBIC published a draft notification proposing revised excise duty brackets for heated tobacco products under Tariff Heading 2404. The proposed rates are 12% higher than current levels, effective April 2026.",
            },
            {
              source: "MoHFW India",
              title:
                "National Tobacco Control Program – New consultation on heated tobacco regulation",
              date: "2026-03-15",
              jurisdiction: "India",
              relevance: "high",
              summary:
                "MoHFW has opened a 30-day public consultation on regulating heated tobacco products under COTPA 2003. The consultation references WHO FCTC Article 5.3 guidelines.",
            },
            {
              source: "WHO TobReg",
              title:
                "Updated guidelines on tobacco harm reduction – relevance to FCTC obligations",
              date: "2026-03-13",
              jurisdiction: "Global",
              relevance: "medium",
              summary:
                "WHO Tobacco Regulation advisory released updated guidelines on harm reduction approaches, acknowledging the role of differential risk assessment for novel tobacco products.",
            },
            {
              source: "PIB",
              title:
                "Parliamentary Standing Committee hearing schedule – Tobacco taxation agenda",
              date: "2026-03-12",
              jurisdiction: "India",
              relevance: "medium",
              summary:
                "Press Information Bureau confirmed Parliamentary Standing Committee hearing on tobacco taxation for March 25, 2026. PMI may be invited for industry consultations.",
            },
          ],
        },
      },
    },
  ],
  // Request 4 has a pending draft review checkpoint
  req_draft_review_001: [
    {
      hitl_id: "hitl_req_draft_review_001_master_drafter_001",
      request_id: "req_draft_review_001",
      agent_name: "master_drafter",
      intervention_type: "quality_gate",
      status: "pending",
      priority: "high",
      created_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      agent_output: {
        confidence: 94,
        quality_score: 91,
        word_count: 1850,
        section_count: 8,
        citations_used: 67,
        tone_analysis: {
          overall: "Formal & Evidence-Based",
          dimensions: {
            Formality: "High (95/100)",
            Neutrality: "Strong (92/100)",
            "Evidence-Based": "Excellent (96/100)",
            "Non-Promotional": "Compliant (100/100)",
          },
        },
        document_outline: [
          {
            title: "Executive Summary",
            summary:
              "Overview of PMI position on differential taxation as a harm-reduction-aligned fiscal instrument for smoke-free products.",
          },
          {
            title: "Background & Context",
            summary:
              "Evolution of tobacco taxation across Asia-Pacific and the emergence of smoke-free product categories in six key jurisdictions.",
          },
          {
            title: "Regional Regulatory Landscape",
            summary:
              "Comparative analysis of India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan regulatory developments and taxation models.",
          },
          {
            title: "Economic Impact Analysis",
            summary:
              "Revenue modelling, consumer substitution patterns, and illicit trade reduction under differential taxation.",
          },
          {
            title: "Public Health Alignment",
            summary:
              "How risk-proportionate taxation supports NTCP objectives and aligns with FCTC Article 6 guidelines.",
          },
          {
            title: "Regulatory Framework Proposal",
            summary:
              "Proposed excise structure with tiered rates based on scientifically-assessed product risk categories.",
          },
          {
            title: "Stakeholder Considerations",
            summary:
              "Impact analysis for farmers, retailers, state revenues, and public health outcomes across Indian states.",
          },
          {
            title: "Recommendations & Next Steps",
            summary:
              "Actionable policy recommendations for FICCI submission to government stakeholders.",
          },
        ],
        key_messages: [
          "Differential taxation is a globally recognized tool to incentivize switching from combustible to smoke-free products.",
          "India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan present significant opportunities for risk-proportionate taxation with measurable public health benefits.",
          "India's existing GST and excise framework can accommodate differential rates without requiring legislative amendment.",
          "Revenue-neutral modelling shows potential for increased compliance and reduced illicit trade volumes.",
          "WHO FCTC Article 6 guidelines explicitly support price and tax measures that discourage the most harmful products.",
        ],
        draft_content: `INDUSTRY POSITION PAPER\n\nDifferential Taxation for Smoke-Free Products: A Risk-Proportionate Fiscal Framework\n\nPrepared for: FICCI Tobacco Committee\nDate: March 2026\n\n─────────────────────────────────────────\n\nEXECUTIVE SUMMARY\n\nPhilip Morris International respectfully submits this position paper to the FICCI Tobacco Committee, presenting evidence-based recommendations for the adoption of a differential taxation framework for smoke-free products across key Asia-Pacific markets. Drawing on regulatory developments in India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan, this paper demonstrates that risk-proportionate taxation can serve as an effective fiscal instrument that simultaneously advances public health objectives while maintaining government revenue stability.\n\nKey findings from our analysis of 67 peer-reviewed sources and 14 government policy documents indicate that differential taxation frameworks present significant opportunities for reducing combustible cigarette consumption across all six jurisdictions.\n\n1. BACKGROUND & CONTEXT\n\nThe tobacco taxation landscape across Asia-Pacific has evolved significantly in recent years. Regulatory bodies in India (CBIC), Vietnam (MoH), Thailand (FDA), Bangladesh (NBR), Malaysia (Customs), and Bhutan (MoH) have each issued draft notifications or consultations addressing excise duty structures for novel tobacco products, signaling regional policy openness to differentiation.\n\nCurrently, most jurisdictions apply similar effective tax rates to all tobacco products regardless of their relative risk profiles — a framework that does not incentivize consumers to switch to potentially less harmful alternatives.\n\n2. REGIONAL REGULATORY LANDSCAPE\n\n2.1 India — CBIC has issued three draft notifications in six months on excise for novel tobacco products. The GST framework can accommodate differential rates without legislative amendment. Potential for 8–15% volume shift from combustibles.\n\n2.2 Vietnam — The Ministry of Health has published a draft amendment to the 2012 Tobacco Control Law with specific provisions for heated tobacco. Vietnam's growing middle class presents a significant opportunity for harm reduction through fiscal incentives.\n\n2.3 Thailand — The Thai FDA has opened public consultation on heated tobacco product classification under the Tobacco Products Control Act B.E. 2560. Risk-proportionate taxation could support public health goals aligned with the National Health Development Plan.\n\n2.4 Bangladesh — The National Board of Revenue proposes a 15% supplementary duty increase on all tobacco products. A differentiated approach could incentivize switching while maintaining revenue targets.\n\n2.5 Malaysia — Royal Malaysian Customs Department has issued a review notice on excise framework for novel tobacco products. Malaysia's existing tiered duty structure provides a natural foundation for risk-based differentiation.\n\n2.6 Bhutan — The Ministry of Health is reviewing tobacco product classifications. As a country with strong public health commitments, Bhutan could pioneer harm-reduction-aligned taxation in South Asia.\n\n[Sections 3–8: Economic Impact Analysis, Public Health Alignment, Regulatory Framework Proposal, Stakeholder Considerations, Recommendations & Next Steps]\n\n─────────────────────────────────────────\nDISCLAIMER: This document is prepared for policy discussion purposes only and does not constitute product promotion. All assertions are supported by cited peer-reviewed sources and official government data.`,
      },
    },
  ],
  // Approval queue items checkpoints
  req_appr_draft_001: [
    {
      hitl_id: "hitl_req_appr_draft_001_master_drafter_001",
      request_id: "req_appr_draft_001",
      agent_name: "master_drafter",
      intervention_type: "quality_gate",
      status: "pending",
      priority: "high",
      created_at: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
      agent_output: {
        confidence: 94,
        quality_score: 91,
        word_count: 1850,
        section_count: 8,
        citations_used: 67,
        tone_analysis: {
          overall: "Formal & Evidence-Based",
          dimensions: {
            Formality: "High (95/100)",
            Neutrality: "Strong (92/100)",
            "Evidence-Based": "Excellent (96/100)",
            "Non-Promotional": "Compliant (100/100)",
          },
        },
        document_outline: [
          {
            title: "Executive Summary",
            summary:
              "PMI position on differential taxation for smoke-free products.",
          },
          {
            title: "Global Taxation Landscape",
            summary:
              "International comparison of risk-proportionate tax frameworks across India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan.",
          },
          {
            title: "Economic Evidence",
            summary:
              "Revenue impact and trade compliance data from adopting markets.",
          },
          {
            title: "Policy Recommendations",
            summary: "Proposed framework for FICCI submission to government.",
          },
        ],
        key_messages: [
          "Differential taxation encourages transition from combustible to smoke-free products.",
          "International evidence supports revenue neutrality of risk-proportionate tax frameworks.",
          "India's GST structure can accommodate differential rates without legislative changes.",
        ],
        draft_content:
          "INDUSTRY POSITION PAPER\n\nDifferential Taxation for Smoke-Free Products\n\nPrepared for: FICCI Tobacco Committee | March 2026\n\nEXECUTIVE SUMMARY\n\nThis paper presents evidence-based recommendations for adopting differential taxation for smoke-free products, drawing on regulatory developments across India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan...\n\n[Full 1,850-word document with 8 sections and 67 citations]",
      },
    },
  ],
  req_appr_research_001: [
    {
      hitl_id: "hitl_req_appr_research_001_master_researcher_001",
      request_id: "req_appr_research_001",
      agent_name: "master_researcher",
      intervention_type: "approval_required",
      status: "pending",
      priority: "medium",
      created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      agent_output: {
        confidence: 91,
        research_strategy: {
          approach:
            "Multi-source analysis of CBIC notification with financial impact modelling and regulatory comparison.",
          domains: [
            "CBIC Notifications",
            "PMI Internal Finance Data",
            "Industry Reports",
            "WHO/WTO Trade Guidelines",
          ],
        },
        sources_found: {
          internal: "12 PMI finance and strategy documents",
          government: "5 CBIC notifications and 3 MoF circulars",
          academic: "18 trade policy and taxation economics papers",
          international: "4 WHO/WTO guidelines on tobacco trade",
        },
        citation_count: 45,
        evidence_quality_score: 91,
        key_findings: [
          "New CBIC notification increases effective excise on heated tobacco by 12% from April 2026",
          "Impact modelling suggests 8-15% volume decline in the first quarter post-implementation",
          "Three Indian states have requested exemptions for smoke-free categories under GST council provisions",
          "PMI's prior submissions to CBIC in 2024-2025 provide a consistent baseline for escalation arguments",
          "WHO Framework Convention Article 6 guidelines support differentiated pricing to reduce combustible use",
        ],
        knowledge_gaps: [
          "State-level revenue impact data for Q4 FY 2025-26 not yet published by MoF",
          "CBIC internal deliberation minutes not available in public domain",
          "Competitor pricing response strategies not publicly disclosed",
        ],
        policy_intelligence: {
          description:
            "Policy Intelligence Generator flagged the following regulatory developments relevant to this research.",
          alerts: [
            {
              source: "CBIC",
              title:
                "New notification on excise duty for heated tobacco products",
              date: "2026-03-14",
              jurisdiction: "India",
              relevance: "high",
              summary:
                "CBIC notification increases effective excise on heated tobacco by 12% from April 2026. This is the primary trigger for this internal impact assessment.",
            },
            {
              source: "MoF India",
              title:
                "Finance Ministry circular on GST council provisions for smoke-free categories",
              date: "2026-03-12",
              jurisdiction: "India",
              relevance: "high",
              summary:
                "Three Indian states have formally requested exemptions for smoke-free product categories under GST council provisions.",
            },
          ],
        },
      },
    },
  ],
  // Thailand final review checkpoint
  req_th_001: [
    {
      hitl_id: "hitl_req_th_001_master_reviewer_001",
      request_id: "req_th_001",
      agent_name: "master_reviewer",
      intervention_type: "quality_gate",
      status: "pending",
      priority: "high",
      created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      agent_output: {
        confidence: 96,
        quality_score: 94,
        compliance_checks: [
          {
            check: "All assertions carry citations with snapshot dates",
            status: "passed",
          },
          {
            check: "No youth-targeted or misleading health claims",
            status: "passed",
          },
          {
            check: "Statutory warnings and mandatory disclaimers included",
            status: "passed",
          },
          { check: "FCTC obligations respected", status: "passed" },
          {
            check: "Formal, neutral, non-promotional tone maintained",
            status: "passed",
          },
          {
            check: "Thailand FDA Act B.E. 2560 compliance verified",
            status: "passed",
          },
        ],
        risk_assessment: {
          overall_risk: "medium",
          dimensions: {
            "Reputational Risk": "low",
            "Legal Risk": "low",
            "Regulatory Risk": "medium",
            "Political Sensitivity": "high",
          },
          mitigations: [
            "Ensure all scientific evidence references peer-reviewed publications only",
            "Add disclaimer that PMI respects Thailand's sovereign regulatory authority",
            "Reference FCTC Article 5.3 transparency obligations proactively",
          ],
        },
        specialist_reviews: [
          {
            name: "Compliance & Risk Review",
            icon: "⚖️",
            status: "passed",
            summary:
              "No promotional content detected. All statutory warnings for Thailand market present.",
          },
          {
            name: "Regulatory Review",
            icon: "📋",
            status: "passed",
            summary:
              "Thai Tobacco Products Control Act B.E. 2560 and FCTC obligations fully respected.",
          },
          {
            name: "Legal Review",
            icon: "⚖️",
            status: "passed",
            summary:
              "Legal terminology appropriate for Thai regulatory submission context.",
          },
        ],
      },
    },
  ],
};

// ─── Approval Queue Mock ─────────────────────────────────────────────────────

export const MOCK_APPROVALS = [
  {
    request_id: "req_f7g8h9i0j1k2",
    topic: "Govt Advocacy Letter – MoHFW Tobacco Control Program Consultation",
    category: "Government Advocacy",
    useCase: "Point of View (PoV) on a topic to govt",
    document_type:
      "Government Advocacy – Point of View (PoV) on a topic to govt",
    jurisdiction: "India",
    target_audience: "Ministry of Health & Family Welfare",
    deadline: "2026-03-22",
    created_at: "2026-03-13T08:30:00.000Z",
    status: "pending-approval",
    priority: "high",
    background:
      "MoHFW is reviewing tobacco control measures under the National Tobacco Control Program. PMI seeks to provide evidence-based policy recommendations.",
    regulationTopic: "Tobacco control measures and public health policy",
    agentStage: "Master Reviewer",
    wordCount: 2450,
    citationCount: 110,
    confidenceScore: 98,
    hitlCheckpoint: MOCK_HITL_CHECKPOINTS["req_20260604043238_c27200ae"][0],
  },
  {
    request_id: "req_appr_draft_001",
    topic:
      "White Paper – Industry Position on Differential Taxation for Smoke-Free Products",
    category: "Industry Advocacy",
    useCase: "White papers on a policy / product",
    document_type: "Industry Advocacy – White papers on a policy / product",
    jurisdiction: "India",
    target_audience: "FICCI Tobacco Committee",
    deadline: "2026-03-28",
    created_at: "2026-03-15T10:00:00.000Z",
    status: "pending-approval",
    priority: "high",
    background:
      "FICCI is preparing a consolidated industry position paper on differential taxation. PMI needs to contribute a technical white paper with global evidence.",
    regulationTopic: "Differential taxation for smoke-free alternatives",
    agentStage: "Master Drafter",
    wordCount: 1850,
    citationCount: 67,
    confidenceScore: 94,
    hitlCheckpoint: {
      hitl_id: "hitl_req_appr_draft_001_master_drafter_001",
      request_id: "req_appr_draft_001",
      agent_name: "master_drafter",
      intervention_type: "quality_gate",
      status: "pending",
      priority: "high",
      created_at: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
      agent_output: {
        confidence: 94,
        quality_score: 91,
        word_count: 1850,
        section_count: 8,
        citations_used: 67,
        tone_analysis: {
          overall: "Formal & Evidence-Based",
          dimensions: {
            Formality: "High (95/100)",
            Neutrality: "Strong (92/100)",
            "Evidence-Based": "Excellent (96/100)",
            "Non-Promotional": "Compliant (100/100)",
          },
        },
        document_outline: [
          {
            title: "Executive Summary",
            summary:
              "PMI position on differential taxation for smoke-free products.",
          },
          {
            title: "Global Taxation Landscape",
            summary:
              "International comparison of risk-proportionate tax frameworks across India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan.",
          },
          {
            title: "Indian Market Context",
            summary:
              "Current GST and excise framework analysis with CBIC notification history.",
          },
          {
            title: "Economic Evidence",
            summary:
              "Revenue impact modelling, consumer substitution patterns, and illicit trade data.",
          },
          {
            title: "Public Health Case",
            summary:
              "Alignment with NTCP objectives and FCTC Article 6 guidelines.",
          },
          {
            title: "Proposed Tax Framework",
            summary:
              "Tiered excise rates based on product risk categories with revenue projections.",
          },
          {
            title: "Stakeholder Impact",
            summary:
              "Analysis of impact on farmers, retailers, state governments, and consumers.",
          },
          {
            title: "Recommendations",
            summary:
              "Actionable policy recommendations for FICCI submission to government.",
          },
        ],
        key_messages: [
          "Differential taxation is a globally proven mechanism to incentivize transition from combustible to smoke-free products.",
          "India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan are key markets where risk-proportionate taxation can deliver measurable public health outcomes.",
          "India's existing GST framework can accommodate differential excise rates without legislative amendment.",
          "Revenue-neutral modelling shows increased compliance and reduced illicit trade under differential taxation.",
          "WHO FCTC Article 6 explicitly supports price and tax measures discouraging the most harmful products.",
        ],
        draft_content:
          "INDUSTRY POSITION PAPER\n\nDifferential Taxation for Smoke-Free Products: A Risk-Proportionate Fiscal Framework\n\nPrepared for: FICCI Tobacco Committee | March 2026\n\nEXECUTIVE SUMMARY\n\nPhilip Morris International respectfully submits this position paper presenting evidence-based recommendations for the adoption of a differential taxation framework for smoke-free products across key Asia-Pacific markets. Drawing on regulatory developments in India, Vietnam, Thailand, Bangladesh, Malaysia, and Bhutan, this paper demonstrates that risk-proportionate taxation advances public health objectives while maintaining revenue stability.\n\nKey findings from 67 peer-reviewed sources indicate significant opportunities for reducing combustible cigarette consumption across all six jurisdictions through differentiated fiscal instruments.\n\n1. REGIONAL REGULATORY LANDSCAPE\n\nIndia (CBIC), Vietnam (MoH), Thailand (FDA), Bangladesh (NBR), Malaysia (Customs), and Bhutan (MoH) have each issued draft notifications or consultations addressing excise for novel tobacco products...\n\n2. MARKET CONTEXT\n\nThe CBIC has issued three draft notifications in six months addressing excise on novel tobacco products, signaling openness to policy refinement...\n\n[Sections 3-8 continue with Economic Evidence, Public Health Case, Proposed Tax Framework, Stakeholder Impact, and Recommendations]\n\nDISCLAIMER: This document is prepared for policy discussion purposes only and does not constitute product promotion.",
      },
    },
  },
  {
    request_id: "req_appr_research_001",
    topic: "Internal Impact Assessment – New CBIC Notification on Excise Duty",
    category: "Internal Communications",
    useCase: "Internal communications on regulations & impact assessments",
    document_type:
      "Internal Communications – Internal communications on regulations & impact assessments",
    jurisdiction: "India",
    target_audience: "PMI India Leadership Team",
    deadline: "2026-03-20",
    created_at: "2026-03-15T14:00:00.000Z",
    status: "pending-approval",
    priority: "medium",
    background:
      "CBIC has issued a new notification impacting excise duty on heated tobacco products. An internal impact assessment is needed for the India leadership team.",
    regulationTopic: "Excise duty notification impact assessment",
    agentStage: "Master Researcher",
    wordCount: null,
    citationCount: 45,
    confidenceScore: 91,
    hitlCheckpoint: {
      hitl_id: "hitl_req_appr_research_001_master_researcher_001",
      request_id: "req_appr_research_001",
      agent_name: "master_researcher",
      intervention_type: "approval_required",
      status: "pending",
      priority: "medium",
      created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      agent_output: {
        confidence: 91,
        research_strategy: {
          approach:
            "Multi-source analysis of CBIC notification with financial impact modelling and regulatory comparison across jurisdictions.",
          domains: [
            "CBIC Notifications",
            "PMI Internal Finance Data",
            "Industry Reports",
            "WHO/WTO Trade Guidelines",
          ],
        },
        sources_found: {
          internal: "12 PMI finance and strategy documents",
          government: "5 CBIC notifications and 3 MoF circulars",
          academic: "18 trade policy and taxation economics papers",
          international: "4 WHO/WTO guidelines on tobacco trade",
        },
        citation_count: 45,
        evidence_quality_score: 91,
        key_findings: [
          "New CBIC notification increases effective excise on heated tobacco by 12% from April 2026",
          "Impact modelling suggests 8-15% volume decline in the first quarter post-implementation",
          "Three Indian states have requested exemptions for smoke-free categories under GST council provisions",
          "PMI prior submissions to CBIC in 2024-2025 provide consistent baseline for escalation arguments",
          "WHO Framework Convention Article 6 guidelines support differentiated pricing to reduce combustible use",
        ],
        knowledge_gaps: [
          "State-level revenue impact data for Q4 FY 2025-26 not yet published by MoF",
          "CBIC internal deliberation minutes not available in public domain",
          "Competitor pricing response strategies not publicly disclosed",
        ],
      },
    },
  },
  // Thailand – Final Review
  {
    request_id: "req_th_001",
    topic:
      "Government Response – Thailand FDA Heated Tobacco Product Classification",
    category: "Government Advocacy",
    useCase: "Response / reply to govt",
    document_type: "Government Advocacy – Response / reply to govt",
    jurisdiction: "Thailand",
    target_audience: "Thailand Food and Drug Administration (FDA)",
    deadline: "2026-03-24",
    created_at: "2026-03-14T04:00:00.000Z",
    status: "pending-approval",
    priority: "high",
    background:
      "Thailand FDA has issued a consultation on classifying heated tobacco products under the Tobacco Products Control Act B.E. 2560. PMI must respond with scientific evidence from UK (340% HTP growth), Japan (44% cigarette decline), and NZ (risk-linked excise).",
    regulationTopic: "Heated tobacco product classification under Thai FDA",
    agentStage: "Master Reviewer",
    wordCount: 2100,
    citationCount: 78,
    confidenceScore: 96,
    hitlCheckpoint: {
      hitl_id: "hitl_req_th_001_master_reviewer_001",
      request_id: "req_th_001",
      agent_name: "master_reviewer",
      intervention_type: "quality_gate",
      status: "pending",
      priority: "high",
      created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      agent_output: {
        confidence: 96,
        quality_score: 94,
        compliance_checks: [
          {
            check: "All assertions carry citations with snapshot dates",
            status: "passed",
          },
          {
            check: "No youth-targeted or misleading health claims",
            status: "passed",
          },
          {
            check: "Statutory warnings and mandatory disclaimers included",
            status: "passed",
          },
          { check: "FCTC obligations respected", status: "passed" },
          {
            check: "Formal, neutral, non-promotional tone maintained",
            status: "passed",
          },
          {
            check: "Thailand FDA Act B.E. 2560 compliance verified",
            status: "passed",
          },
        ],
        risk_assessment: {
          overall_risk: "medium",
          dimensions: {
            "Reputational Risk": "low",
            "Legal Risk": "low",
            "Regulatory Risk": "medium",
            "Political Sensitivity": "high",
          },
          mitigations: [
            "Ensure all scientific evidence references peer-reviewed publications only",
            "Add disclaimer that PMI respects Thailand's sovereign regulatory authority",
          ],
        },
        specialist_reviews: [
          {
            name: "Compliance & Risk Review",
            icon: "⚖️",
            status: "passed",
            summary:
              "No promotional content. All Thai statutory warnings present.",
          },
          {
            name: "Regulatory Review",
            icon: "📋",
            status: "passed",
            summary: "Thai Tobacco Act B.E. 2560 and FCTC fully respected.",
          },
          {
            name: "Legal Review",
            icon: "⚖️",
            status: "passed",
            summary:
              "Legal terminology appropriate for Thai regulatory context.",
          },
        ],
      },
    },
  },
];

//Mock Reviews
export const MOCK_REVIEWS = [
  {
    review_id: "review_req_th_001",
    request_id: "req_th_001",
    hitl_id: "hitl_req_th_001_master_reviewer_001",
    review_type: "205",
    status: "pending",
    decision: false,
    comments: "",
    section_feedback: "",
    assigned_at: "",
    started_at: "",
    completed_at: "",
    created_at: "",
  },
  {
    review_id: "review_f7g8h9i0j1k2_001",
    request_id: "req_f7g8h9i0j1k2",
    hitl_id: "hitl_req_f7g8h9i0j1k2_master_reviewer_001",
    review_type: "201",
    status: "pending",
    decision: false,
    comments: "",
    section_feedback: "",
    assigned_at: "",
    started_at: "",
    completed_at: "",
    created_at: "",
  },
  {
    review_id: "review_f7g8h9i0j1k2_002",
    request_id: "req_f7g8h9i0j1k2",
    hitl_id: "hitl_req_f7g8h9i0j1k2_master_reviewer_001",
    review_type: "202",
    status: "pending",
    decision: false,
    comments: "",
    section_feedback: "",
    assigned_at: "",
    started_at: "",
    completed_at: "",
    created_at: "",
  },
  {
    review_id: "review_f7g8h9i0j1k2_003",
    request_id: "req_f7g8h9i0j1k2",
    hitl_id: "hitl_req_f7g8h9i0j1k2_master_reviewer_001",
    review_type: "203",
    status: "pending",
    decision: false,
    comments: "",
    section_feedback: "",
    assigned_at: "",
    started_at: "",
    completed_at: "",
    created_at: "",
  },
  {
    review_id: "review_f7g8h9i0j1k2_004",
    request_id: "req_f7g8h9i0j1k2",
    hitl_id: "hitl_req_f7g8h9i0j1k2_master_reviewer_001",
    review_type: "204",
    status: "pending",
    decision: false,
    comments: "",
    section_feedback: "",
    assigned_at: "",
    started_at: "",
    completed_at: "",
    created_at: "",
  },
  {
    review_id: "review_f7g8h9i0j1k2_005",
    request_id: "req_f7g8h9i0j1k2",
    hitl_id: "hitl_req_f7g8h9i0j1k2_master_reviewer_001",
    review_type: "205",
    status: "pending",
    decision: false,
    comments: "",
    section_feedback: "",
    assigned_at: "",
    started_at: "",
    completed_at: "",
    created_at: "",
  },
];

// ─── Helper to find mock request by ID ───────────────────────────────────────

export function getMockRequestById(id) {
  return (
    MOCK_REQUESTS.find(
      (r) => r.request_id === id || String(r.id) === String(id),
    ) ||
    MOCK_APPROVALS.find((r) => r.request_id === id) ||
    null
  );
}

export function getMockHITLCheckpoints(requestId) {
  // Try by request_id first, then by numeric id
  const byReqId = MOCK_HITL_CHECKPOINTS[requestId];
  if (byReqId) return byReqId;

  const req = MOCK_REQUESTS.find((r) => String(r.id) === String(requestId));
  if (req) return MOCK_HITL_CHECKPOINTS[req.request_id] || [];

  // Fallback: check MOCK_APPROVALS for inline hitlCheckpoint
  const approval = MOCK_APPROVALS.find((a) => a.request_id === requestId);
  if (approval?.hitlCheckpoint) return [approval.hitlCheckpoint];

  return [];
}

export function getReviewsByRequestId(id) {
  return MOCK_REVIEWS.filter((review) => {
    return review.request_id == id;
  });
}
