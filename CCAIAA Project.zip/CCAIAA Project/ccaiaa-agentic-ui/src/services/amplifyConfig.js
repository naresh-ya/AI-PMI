import { Amplify } from "aws-amplify";
import { CookieStorage } from "aws-amplify/utils";
import { cognitoUserPoolsTokenProvider } from "aws-amplify/auth/cognito";

const appOrigin = window.location.origin;

const userPoolId = import.meta.env.VITE_COGNITO_USER_POOL_ID;
const userPoolClientId = import.meta.env.VITE_COGNITO_CLIENT_ID;
const domain = import.meta.env.VITE_API_URL;

if (!userPoolId) {
  throw new Error("VITE_COGNITO_USER_POOL_ID is missing");
}

if (!userPoolClientId) {
  throw new Error("VITE_COGNITO_CLIENT_ID is missing");
}

if (!domain) {
  throw new Error("VITE_COGNITO_DOMAIN is missing");
}

console.log(userPoolClientId, userPoolId, domain, appOrigin, "chandra");

const amplifyConfig = {
  Auth: {
    Cognito: {
      userPoolId,
      userPoolClientId,

      loginWith: {
        oauth: {
          domain,
          scopes: ["openid", "email", "profile"],
          redirectSignIn: [`${appOrigin}/callback`],
          redirectSignOut: [`${appOrigin}/login`],
          responseType: "code",
        },
      },
    },
  },
};

console.log("Configuring Amplify", {
  userPoolId,
  userPoolClientId,
  domain,
  redirectSignIn: `${appOrigin}/callback`,
  redirectSignOut: `${appOrigin}/login`,
});

Amplify.configure(amplifyConfig);
cognitoUserPoolsTokenProvider.setKeyValueStorage(
  new CookieStorage({
    path: "/",
    expire: 1,
    sameSite: "lax",
    secure: window.location.protocol === "https:",
  }),
);

console.log("Configured Amplify resources:", Amplify.getConfig());
