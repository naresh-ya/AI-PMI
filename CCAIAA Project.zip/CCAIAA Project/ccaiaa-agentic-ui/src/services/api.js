/**
 * API Service Layer for PMI Agentic AI Platform
 *
 * Centralized API calls with error handling, retry logic, and request/response interceptors.
 * Connects to the backend Lambda API via API Gateway.
 */
import { getAccessToken } from "./cognitoService";
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "/api";
const DOCUMENT_BASE_URL = import.meta.env.VITE_DOCUMENT_BASE_URL || "/api";
const ALL_REQUEST_URL = import.meta.env.VITE_ALL_REQUESTS_URL || "/api";

// CA Workbench draft API (getCategories / getCategoryMetaData /
// draftFormCheck / generateDraft — see draftApiRequest below).
//
//   - `vite dev`: calls go through this SAME-ORIGIN path, which the Vite dev
//     server proxies to API Gateway (see vite.config.js `server.proxy`).
//     Being same-origin, the browser never sends a CORS preflight here,
//     regardless of headers.
//   - Production build: there's no server-side proxy in front of the static
//     build, so these calls go directly to API Gateway (cross-origin) via
//     PROD_WORKBENCH_BASE_URL. To keep the browser from sending a CORS
//     preflight for THOSE calls, draftApiRequest deliberately drops every
//     header that forces one — see its docstring for how the user id and
//     JSON body are carried instead.
//
// IMPORTANT: avoiding the preflight only stops the browser from sending an
// OPTIONS request. It does not make the browser accept the actual GET/POST
// response — that still requires the server to return
// `Access-Control-Allow-Origin` on that response. If API Gateway has no CORS
// support at all on these routes, calls can still fail in production; this
// only removes the preflight as one possible point of failure.
const WORKBENCH_BASE_URL = "/workbench-api";
const PROD_WORKBENCH_BASE_URL =
  "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod";

class ApiError extends Error {
  constructor(message, status, details = null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.details = details;
  }
}

/**
 * Base fetch wrapper with error handling, timeout, and retry
 */
async function workbenchRequest(endpoint, baseUrl, options = {}, userId) {
  const {
    method = "GET",
    body = null,
    headers = {},
    timeout = 30000,
    retries = 2,
  } = options;
  const token = await getAccessToken();
  const config = {
    method,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...headers,
      "X-User-Id": userId,
    },
  };

  if (body) {
    config.body = JSON.stringify(body);
  }

  let lastError = null;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    config.signal = controller.signal;

    try {
      const BASE_URL = baseUrl ? baseUrl : API_BASE_URL;
      const response = await fetch(`${BASE_URL}${endpoint}`, config);
      clearTimeout(timeoutId);

      if (!response.ok && response.status != 409) {
        const errorBody = await response.json().catch(() => ({}));
        throw new ApiError(
          errorBody.error ||
            errorBody.message ||
            `Request failed with status ${response.status}`,
          response.status,
          errorBody.details || null,
        );
      }

      const data = await response.json();
      return data;
    } catch (err) {
      clearTimeout(timeoutId);
      lastError = err;

      if (err.name === "AbortError") {
        lastError = new ApiError("Request timed out", 408);
      }

      // Don't retry client errors (4xx) except 408 and 429
      if (
        err instanceof ApiError &&
        err.status >= 400 &&
        err.status < 500 &&
        err.status !== 408 &&
        err.status !== 429
      ) {
        throw err;
      }

      // Wait before retry (exponential backoff)
      if (attempt < retries) {
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, attempt) * 500),
        );
      }
    }
  }

  throw lastError;
}

/**
 * draftApiRequest — used by the four CA Workbench draft endpoints
 * (getCategories, getCategoryMetaData, draftFormCheck, generateDraft).
 *
 * In `vite dev`, this is identical to workbenchRequest against the
 * same-origin /workbench-api proxy path (see WORKBENCH_BASE_URL above) — no
 * preflight is sent there regardless of headers, since it's same-origin.
 *
 * In a production build, this calls API Gateway directly (cross-origin) and
 * deliberately sends a "simple request" per the Fetch/CORS spec, so the
 * browser never issues an OPTIONS preflight for it:
 *   - method is GET or POST (both CORS-safelisted)
 *   - no custom headers are set — in particular no `X-User-Id` header, since
 *     any custom header forces a preflight. The user id instead travels as a
 *     `user_id` query param (GET) or inside the JSON body (POST).
 *   - no explicit Content-Type is set. For a GET there's no body, so no
 *     Content-Type is sent at all. For a POST, `body` is passed as a plain
 *     string, which makes the browser default the header to
 *     `text/plain;charset=UTF-8` — one of the three CORS-safelisted content
 *     types (`application/json` is NOT safelisted, so it always preflights).
 *
 * NOTE — this only removes the preflight (the OPTIONS request). It does not
 * make the browser accept the actual GET/POST response: that still requires
 * the server to send `Access-Control-Allow-Origin` on that response. If API
 * Gateway has no CORS support at all on these routes, the call can still
 * fail in production even with no preflight in the Network tab.
 *
 * NOTE — declaring `text/plain` while sending JSON text only works if the
 * backend Lambda parses the raw request body as JSON regardless of the
 * declared Content-Type (typical for API Gateway Lambda-proxy integrations,
 * which hand the handler the raw body string either way). If the backend
 * strictly validates Content-Type, this will need revisiting.
 */
async function draftApiRequest(endpoint, userId, options = {}) {
  const { method = "GET", body = null, timeout = 30000, retries = 2 } = options;

  if (import.meta.env.DEV) {
    return workbenchRequest(
      endpoint,
      WORKBENCH_BASE_URL,
      { method, body },
      userId,
    );
  }

  let url = `${PROD_WORKBENCH_BASE_URL}${endpoint}`;
  const config = { method };

  if (method === "GET") {
    if (userId) {
      url += `${endpoint.includes("?") ? "&" : "?"}user_id=${encodeURIComponent(userId)}`;
    }
  } else if (body) {
    // Merge user_id into the payload rather than sending it as a header —
    // callers already include user_id in `body` for the draft-flow POSTs,
    // but fall back to the explicit `userId` argument if they didn't.
    config.body = JSON.stringify({ ...body, user_id: body.user_id ?? userId });
  }

  let lastError = null;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    config.signal = controller.signal;

    try {
      const response = await fetch(url, config);
      clearTimeout(timeoutId);

      if (!response.ok && response.status != 409) {
        const errorBody = await response.json().catch(() => ({}));
        throw new ApiError(
          errorBody.error ||
            errorBody.message ||
            `Request failed with status ${response.status}`,
          response.status,
          errorBody.details || null,
        );
      }

      return await response.json();
    } catch (err) {
      clearTimeout(timeoutId);
      lastError = err;

      if (err.name === "AbortError") {
        lastError = new ApiError("Request timed out", 408);
      }

      if (
        err instanceof ApiError &&
        err.status >= 400 &&
        err.status < 500 &&
        err.status !== 408 &&
        err.status !== 429
      ) {
        throw err;
      }

      if (attempt < retries) {
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, attempt) * 500),
        );
      }
    }
  }

  throw lastError;
}

// updated function
/**
 * Base fetch wrapper with error handling, timeout, and retry
 */
async function request(endpoint, baseUrl, options = {}, document = false) {
  const {
    method = "GET",
    body = null,
    headers = {},
    timeout = 30000,
    retries = 2,
  } = options;
  const token = await getAccessToken();
  const config = {
    method,
    Authorization: `Bearer ${token}`,
    headers: {
      ...headers,
    },
  };

  if (body) {
    config.body = JSON.stringify(body);
  }

  let lastError = null;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    config.signal = controller.signal;

    try {
      const BASE_URL = baseUrl ? baseUrl : API_BASE_URL;
      const response = await fetch(`${BASE_URL}${endpoint}`, config);
      clearTimeout(timeoutId);

      if (!response.ok && response.status != 409) {
        const errorBody = await response.json().catch(() => ({}));
        throw new ApiError(
          errorBody.error ||
            errorBody.message ||
            `Request failed with status ${response.status}`,
          errorBody.message || `Request failed with status ${response.status}`,
          response.status,
          errorBody.details || null,
        );
      }

      const data = await response.json();
      return data;
    } catch (err) {
      clearTimeout(timeoutId);
      lastError = err;

      if (err.name === "AbortError") {
        lastError = new ApiError("Request timed out", 408);
      }

      // Don't retry client errors (4xx) except 408 and 429
      if (
        err instanceof ApiError &&
        err.status >= 400 &&
        err.status < 500 &&
        err.status !== 408 &&
        err.status !== 429
      ) {
        throw err;
      }

      // Wait before retry (exponential backoff)
      if (attempt < retries) {
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, attempt) * 500),
        );
      }
    }
  }

  throw lastError;
}

// ─── Request Endpoints ───────────────────────────────────────────────────────

/**
 * Submit a new document generation request
 */
export async function createRequest(requestData) {
  return request("/requests", null, {
    method: "POST",
    body: {
      ...requestData,
    },
  });
}

/**
 * Get all requests (with optional filters)
 */
export async function listRequests(email = "") {
  const params = new URLSearchParams();
  // if (filters.status) params.append("status", filters.status);
  // if (filters.priority) params.append("priority", filters.priority);
  // if (filters.limit) params.append("limit", filters.limit);
  if (email) params.append("user", email);
  const query = params.toString();
  return request(
    `/requests/latest${query ? `?${query}` : ""}`,
    "https://l0xhkyycki.execute-api.eu-west-1.amazonaws.com/dev",
  );
}

/**
 * Get a single request by ID (with full details)
 */
export async function getRequest(requestId, includeExecution = true) {
  const params = includeExecution ? "?include_execution=true" : "";
  return request(`/requests/${requestId}`, null);
}

/**
 * Get the agent workflow progress for a request
 */
export async function getRequestProgress(requestId) {
  return request(`/requests/${requestId}/progress`, "/api");
}

// ─── HITL Endpoints ──────────────────────────────────────────────────────────

/**
 * Get pending HITL checkpoints for a request
 */
export async function getHITLCheckpoints(hitl_id) {
  return request(`/requests/research/hitl/${hitl_id}`, null);
}

/**
 * Get pending HITL checkpoints for a request
 */
export async function getHITLContent(hitl_id, status) {
  const hitlType = status == "DRAFT_REVIEW_PENDING" ? "draft" : "research";
  return request(`/requests/${hitlType}/hitl/${hitl_id}`, null);
}

/**
 * Get a specific HITL checkpoint details
 */
export async function getHITLCheckpoint(requestId, hitlId) {
  return request(`/requests/${requestId}/hitl/${hitlId}`, "/api");
}

/**
 * Submit HITL decision (approve / reject / revise / escalate)
 */
export async function submitHITLDecision(requestId, hitlId, decision) {
  return request(`/requests/${requestId}/hitl/${hitlId}`, "/api", {
    method: "POST",
    body: {
      decision: decision.action, // 'approve' | 'reject' | 'revise' | 'escalate'
      feedback: decision.feedback || "",
      comments: decision.comments || "",
      modifications: decision.modifications || {},
      reviewer_id: decision.reviewerId || "current_user",
    },
  });
}

/**
 * Submit HITL decision (approve / reject / revise / escalate)
 */
export async function submitResearchHITLDecision(hitlId, hitlPayload) {
  return request(`/requests/research/hitl/${hitlId}`, null, {
    method: "POST",
    body: {
      ...hitlPayload,
    },
  });
}

// ─── Document Endpoints ──────────────────────────────────────────────────────

/**
 * Get the generated document for a request
 */
export async function getDocument(requestId) {
  return request(`/requests/${requestId}/document`, "/api");
}

/**
 * Download the generated document (returns presigned URL)
 */
export async function getDocumentDownloadUrl(requestId) {
  return request(`/requests/${requestId}/document/download`, "/api");
}

// ─── File Upload ─────────────────────────────────────────────────────────────

/**
 * Get a presigned URL for uploading a file
 */
export async function getUploadUrl(fileName, fileType) {
  return request("/uploads/presigned-url", "/api", {
    method: "POST",
    body: { file_name: fileName, file_type: fileType },
  });
}

/**
 * List the signed documents already uploaded by a user, for the Signed
 * Documents page's initial load.
 * GET https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents?user_email=<email>
 */
export async function getSignedDocuments(userEmail) {
  return request(
    `/signed-documents?user_email=${encodeURIComponent(userEmail)}`,
    "https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev",
  );
}

/**
 * Get a presigned upload URL for the Signed Documents page. `isSigned`
 * answers the "Is this document or generated draft signed?" dialog shown
 * before upload (see SignedDocuments.jsx) — true when the user confirms
 * the document already carries the company's signing watermark and is
 * therefore an official company document, false otherwise.
 * POST https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents/upload-url
 * Body: { user_email, file_name, file_type, file_size, is_signed }
 */
export async function getSignedDocumentUploadUrl(
  userEmail,
  fileName,
  fileType,
  fileSize,
  isSigned = false,
) {
  return request(
    "/signed-documents/upload-url",
    "https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev",
    {
      method: "POST",
      body: {
        user_email: userEmail,
        file_name: fileName,
        file_type: fileType,
        file_size: fileSize,
        is_signed: isSigned,
      },
    },
  );
}

/**
 * Delete one or more previously-uploaded signed documents.
 * DELETE https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents
 * Body: { user_email, s3_keys: [<s3_key>, ...] }
 *
 * `s3Keys` accepts an array (same convention as downloadSignedDocuments) so
 * a single call can delete multiple documents at once — SignedDocuments.jsx
 * currently calls this with a single-element array per row (its per-row
 * Delete button), but this also supports a future multi-select delete.
 */
export async function deleteSignedDocuments(userEmail, s3Keys) {
  return request(
    "/signed-documents",
    "https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev",
    {
      method: "DELETE",
      body: {
        user_email: userEmail,
        s3_keys: s3Keys,
      },
    },
  );
}

/**
 * Get download URL(s) for one or more previously-uploaded signed documents.
 * POST https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents/download
 * Body: { user_email, s3_keys: [<s3_key>, ...] }
 *
 * `s3Keys` accepts an array so a single call can request multiple documents
 * at once (per the given payload shape); SignedDocuments.jsx currently
 * calls this with a single-element array per row (its per-row Download
 * button), but this also supports a future multi-select download.
 */
export async function downloadSignedDocuments(userEmail, s3Keys) {
  return request(
    "/signed-documents/download",
    "https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev",
    {
      method: "POST",
      body: {
        user_email: userEmail,
        s3_keys: s3Keys,
      },
    },
  );
}

/**
 * Fetch presigned URL. `baseUrl`/`endpoint` let callers point this at a
 * different upload-url-issuing endpoint (see uploadFileToS3 below) while
 * reusing the exact same request shape — defaults preserve the original
 * /uploads/presigned-url behavior used by NewRequest.jsx.
 */
async function fetchPresignedUrl(
  file,
  baseUrl = null,
  endpoint = "/uploads/presigned-url",
) {
  return request(endpoint, baseUrl, {
    method: "POST",
    body: {
      ...file,
    },
  });
}

function fixPresignedS3Url(url) {
  return url.replace(/&amp;/g, "&");
}

/**
 * Upload a file to a presigned URL, in two steps:
 *   1. fetchPresignedUrl() asks the backend (via `options.endpoint` /
 *      `options.baseUrl`) for a presigned `upload_url` (plus whatever else
 *      it returns, e.g. a file key).
 *   2. PUTs the raw file bytes directly to that presigned URL (straight to
 *      S3, not through API Gateway).
 *
 * `options.baseUrl` / `options.endpoint` default to the original
 * /uploads/presigned-url behavior (NewRequest.jsx's document uploads) — pass
 * overrides to reuse this same flow against a different upload-url endpoint
 * that accepts the same { file_name, file_type } presigned-URL request
 * shape. (The Signed Documents page's uploadSignedDocument() below needs a
 * different payload — { user_email, file_name, file_type, file_size } — so
 * it has its own flow via getSignedDocumentUploadUrl() instead of this
 * override.)
 */
export async function uploadFileToS3(file, options = {}) {
  const { baseUrl = null, endpoint = "/uploads/presigned-url" } = options;
  try {
    const { file_name, file_type } = file;
    const fileMetaData = {
      file_name,
      file_type,
    };
    const fileData = file.file;
    const generatedFileDetails = await fetchPresignedUrl(
      fileMetaData,
      baseUrl,
      endpoint,
    );
    const response = await fetch(
      fixPresignedS3Url(generatedFileDetails.upload_url),
      {
        method: "PUT",
        headers: {
          "Content-Type": fileData.type,
        },
        body: fileData,
      },
    );
    if (response.status == 200) {
      return generatedFileDetails;
    }
  } catch (error) {
    console.log(error);
  }
}

/**
 * Upload a file for the Signed Documents page:
 *   1. getSignedDocumentUploadUrl() gets a presigned URL using the
 *      { user_email, file_name, file_type, file_size, is_signed } payload.
 *   2. PUTs the raw file bytes directly to that presigned URL (straight to
 *      S3, same pattern as uploadFileToS3, including fixPresignedS3Url).
 *
 * `file` is { file: <File object>, file_name, file_type } — same shape
 * SignedDocuments.jsx already builds; `file_size` is read off the File
 * object itself rather than needing to be passed separately. `isSigned`
 * comes from the "Is this document or generated draft signed?" dialog
 * shown before upload — true when the user confirms it's an official,
 * watermarked company document, false otherwise.
 */
export async function uploadSignedDocument(file, userEmail, isSigned = false) {
  try {
    const fileData = file.file;
    const generatedFileDetails = await getSignedDocumentUploadUrl(
      userEmail,
      file.file_name,
      file.file_type,
      fileData.size,
      isSigned,
    );
    const response = await fetch(
      fixPresignedS3Url(generatedFileDetails.upload_url),
      {
        method: "PUT",
        headers: {
          "Content-Type": fileData.type,
        },
        body: fileData,
      },
    );
    if (response.status == 200) {
      return generatedFileDetails;
    }
  } catch (error) {
    console.log(error);
  }
}

export async function deleteFiles(fileKeys) {
  // return request("/file-upload", "/api",{
  //   method: "POST",
  //   body: {
  //     file,
  //   },
  // });
  const promise = new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve({
        success: true,
      });
    }, 3000);
  });
  return promise;
}

export async function downloadGeneratedDocument(documentEndPoint) {
  const fileUrl = `https://pmi-agentic-ai-documents-603433800649-eu-west-1.s3.eu-west-1.amazonaws.com/${documentEndPoint}`;

  const response = await fetch(fileUrl);

  if (!response.ok) {
    throw new Error("Failed to download file");
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  const fileName = fileUrl.split("/").pop();
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.URL.revokeObjectURL(url);
}

export async function fetchDocumentPreview(requestId) {
  return request(
    `/documents/compare/${requestId}`,
    "https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev",
    {},
    true,
  );
}

// ─── Health ──────────────────────────────────────────────────────────────────

/**
 * Health check
 */
export async function healthCheck() {
  return request("/health", "/api", { retries: 0, timeout: 5000 });
}

// ─── Policy Intelligence ─────────────────────────────────────────────────────

/**
 * Get policy updates feed
 */
export async function getPolicyUpdates(emailId) {
  return request(
    `/dev/policy-updates?email=${emailId}`,
    "https://x790ajq294.execute-api.eu-west-1.amazonaws.com",
  );
}
export { ApiError };

// ─── CA Workbench ─────────────────────────────────────────────────────

export async function createNewChat(userId) {
  const chatBody = {
    title: "New Chat",
  };
  return workbenchRequest(
    "/conversations",
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {
      method: "POST",
      body: {
        ...chatBody,
      },
    },
    userId,
  );
}

export async function sendUserMessage(conversationId, message, userId) {
  const chatBody = {
    conversation_id: conversationId,
    message: message,
  };
  return workbenchRequest(
    "/messages",
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {
      method: "POST",
      body: {
        ...chatBody,
      },
    },
    userId,
  );
}

export async function pollAgentResponse(jobId, userId) {
  return workbenchRequest(
    `/jobs/${jobId}`,
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {},
    userId,
  );
}

export async function getConversationIds(userId) {
  return workbenchRequest(
    `/conversations`,
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {},
    userId,
  );
}

export async function getAllMessages(conversationId, userId) {
  return workbenchRequest(
    `/conversations/${conversationId}/messages`,
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {},
    userId,
  );
}

export async function deleteConversation(conversationId, userId) {
  return workbenchRequest(
    `/conversations/${conversationId}`,
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {
      method: "DELETE",
    },
    userId,
  );
}

export async function exportChatMessage(messageId, conversationId, userId) {
  const chatBody = {
    conversation_id: conversationId,
  };
  return workbenchRequest(
    `/chat/messages/${messageId}/export`,
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {
      method: "POST",
      body: {
        ...chatBody,
      },
    },
    userId,
  );
}

export async function downloadChat(downloadUrl, fileId) {
  const response = await fetch(downloadUrl);

  if (!response.ok) {
    throw new Error("Failed to download file");
  }

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  const fileName = fileId;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.URL.revokeObjectURL(url);
}

/**
 * Get the requests currently in a reviewer's approval queue.
 * GET https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev/reviews/assigned?reviewer=<email>
 */
export async function getAssignedReviews(reviewerEmail) {
  return request(
    `/reviews/assigned?reviewer=${encodeURIComponent(reviewerEmail)}`,
    "https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev",
  );
}

/**
 * Fetches the list of reviewers for a given review category, to populate
 * the reviewer dropdown(s) in the Review Configuration tab (see
 * HITLFinalReview.jsx). Only two categories exist on the backend —
 * "CA_Review" (shared across all four CA sub-types: Scientific, Regulatory,
 * Communications, Fiscal) and "Legal_Review" — called the moment that
 * review type's checkbox is checked, not on mount.
 * GET https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev/reviews/reviewers?review_category=<CA_Review|Legal_Review>
 * Response: { review_category, count, reviewers: [{ name, email, role, country }, ...] }
 */
export async function getReviewersByCategory(reviewCategory) {
  return request(
    `/reviews/reviewers?review_category=${encodeURIComponent(reviewCategory)}`,
    "https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev",
  );
}

export async function updateReviews(pendingReviews, request_id, userId) {
  console.log(pendingReviews);
  const chatBody = {
    ...pendingReviews,
  };
  return request(
    `/requests/${request_id}/reviews`,
    "https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev",
    {
      method: "POST",
      body: {
        ...chatBody,
      },
    },
  );
}

/**
 * Submits a reviewer's decision for a request — used by HITLFinalReview for
 * every reviewer role (Scientific, Regulatory, Communication, Fiscal,
 * Legal). Same call regardless of role; only `feedback`/`reviewFlag` (and
 * who's submitting) differ. `feedback` is an empty string when the
 * reviewer has checked "No Review Required". `reviewFlag` is one of
 * "no_review" | "changes_requested" (mutually exclusive checkboxes in
 * HITLFinalReview), or "" if the reviewer left both unchecked.
 * POST https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev/requests/{request_id}/reviews/decision
 * Body: { reviewer, feedback, review_flag }
 */
export async function submitReviewDecision(
  requestId,
  reviewer,
  feedback,
  reviewFlag = "",
) {
  return request(
    `/requests/${requestId}/reviews/decision`,
    "https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev",
    {
      method: "POST",
      body: {
        reviewer,
        feedback: feedback || "",
        review_flag: reviewFlag || "",
      },
    },
  );
}

/**
 * Called when the requestor clicks "Reject Changes" on a
 * REVIEW_CHANGES_REQUESTED request (see HITLFinalReview's
 * handleRejectChanges) — marks the request complete/closed without
 * incorporating the reviewer's requested changes.
 * POST https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev/requests/{request_id}/complete
 * Body: { user_id }
 */
export async function completeRequest(requestId, userId) {
  return request(
    `/requests/${requestId}/complete`,
    "https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev",
    {
      method: "POST",
      body: {
        user_id: userId,
      },
    },
  );
}

/**
 * Called when the requestor clicks "Accept Changes" on a
 * REVIEW_CHANGES_REQUESTED request (see HITLFinalReview's
 * handleAcceptChanges) — kicks off a legal redraft incorporating the
 * reviewer's requested changes. `userComment` is the requestor's own
 * optional note (see the "User Comments" field below the reviewer
 * feedback cards on that screen) — sent as an empty string if left blank.
 * POST https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev/requests/{request_id}/legal-redraft
 * Body: { user_id, user_comment }
 */
export async function submitLegalRedraft(requestId, userId, userComment = "") {
  return request(
    `/requests/${requestId}/legal-redraft`,
    "https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev",
    {
      method: "POST",
      body: {
        user_id: userId,
        user_comment: userComment || "",
      },
    },
  );
}

export async function getCategories(userId) {
  return draftApiRequest(`/draft/categories`, userId);
}

export async function getCategoryMetaData(category, userId) {
  return draftApiRequest(`/draft/metadata/${category}`, userId);
}

export async function draftFormCheck(chatBody, userId) {
  return draftApiRequest(`/chat/draft-form-check`, userId, {
    method: "POST",
    body: chatBody,
  });
}

export async function generateDraft(chatBody, userId) {
  return draftApiRequest(`/chat/generate-draft`, userId, {
    method: "POST",
    body: chatBody,
  });
}

/**
 * Polls the status of an in-flight draft-generation job — generateDraft()
 * now returns immediately with { job_id, status: "PENDING", ... } instead of
 * the finished draft, and this is polled (every 2s — see ChatDraftForm)
 * until the job leaves "PENDING". Same endpoint/host pattern as
 * pollAgentResponse (GET /jobs/{job_id} on the workbench API via
 * workbenchRequest, with the same `X-User-Id` header — this route already
 * works cross-origin in production, unlike the /draft/* routes above), kept
 * as its own function since draft-job polling is a separate concern from
 * chat-message job polling and may end up with a different response shape.
 */
export async function pollDraftJobStatus(jobId, userId) {
  return workbenchRequest(
    `/jobs/${jobId}`,
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
    {},
    userId,
  );
}

/**
 * Given the `s3_key` returned by a finished draft job, fetches a download
 * URL for the generated document. This hits the SAME API Gateway host as the
 * draft workbench routes above (cxb47goss9…/prod — see WORKBENCH_BASE_URL /
 * PROD_WORKBENCH_BASE_URL), so it goes through the plain `request()` helper
 * with that host directly. Every identifying value travels as a query param
 * on a plain GET with no custom headers, which is already a CORS "simple
 * request" — no preflight is sent for it regardless of host.
 *
 * NOTE: being a "simple request" only means no OPTIONS preflight is sent.
 * The actual GET response still needs `Access-Control-Allow-Origin` from the
 * server for the browser to hand the response to this code. Since this is
 * the same host where /draft/categories etc. were missing that header (see
 * draftApiRequest above), this call may hit the same issue in production. If
 * it does, apply the same fix used there.
 */
export async function getDraftDownloadUrl(s3Key, userId, conversationId) {
  // Built as a template string (not URLSearchParams) so the `/` characters
  // inside s3_key stay literal, matching the exact query format this
  // endpoint expects, rather than being percent-encoded to %2F.
  return request(
    `/chat/draft/download?s3_key=${s3Key}&user_id=${userId}&conversation_id=${conversationId}`,
    "https://cxb47goss9.execute-api.eu-west-1.amazonaws.com/prod",
  );
}
