import {
  signInWithRedirect,
  signOut,
  getCurrentUser,
  fetchAuthSession,
} from "aws-amplify/auth";

export async function loginWithCognito() {
  console.log(signInWithRedirect());
  return signInWithRedirect();
}

export async function getAuthenticatedUser() {
  try {
    const session = await fetchAuthSession();
    if (!session.tokens?.accessToken) {
      return null;
    }
    return await getCurrentUser();
  } catch {
    return null;
  }
}

export async function getAccessToken() {
  try {
    const session = await fetchAuthSession();
    return session.tokens?.accessToken?.toString() ?? null;
  } catch {
    return null;
  }
}

export async function logoutFromCognito() {
  await signOut();
}
