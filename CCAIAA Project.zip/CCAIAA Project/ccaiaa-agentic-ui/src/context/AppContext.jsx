import { createContext, useContext, useReducer, useCallback } from "react";
import {
  MOCK_REQUESTS,
  MOCK_POLICY_UPDATES,
  MOCK_NOTIFICATIONS,
  MOCK_REVIEWS,
} from "../data/mockData";
import { logoutFromCognito } from "../services/cognitoService";

// ─── Initial State ───────────────────────────────────────────────────────────

const initialState = {
  isAuthenticated: false,
  user: null,
  requests: MOCK_REQUESTS,
  currentRequest: null,
  loading: {
    requests: false,
    currentRequest: false,
    submitting: false,
    hitl: false,
    conversations: false,
  },
  reviews: MOCK_REVIEWS,
  toasts: [],
  policyUpdates: MOCK_POLICY_UPDATES,
  notifications: MOCK_NOTIFICATIONS,
  duplicateRequests: [],
  chatConversations: [],
  selectedConversationId: null,
  // Chat message cache, keyed by conversation_id. Lives here (not as local
  // state inside AskCA) specifically so it survives AskCA unmounting/
  // remounting — e.g. navigating to another page and coming back, or
  // switching between chats — instead of being wiped every time that
  // component goes away. Whether a conversation has a response "in
  // flight" isn't tracked separately here — it's derived from each
  // message's own `status`/`job_id` fields (see AskCA.jsx), the same
  // fields the backend itself uses.
  messagesByConversationId: {},
};

// ─── Action Types ────────────────────────────────────────────────────────────

const ACTIONS = {
  LOGIN: "LOGIN",
  LOGOUT: "LOGOUT",
  SET_LOADING: "SET_LOADING",
  SET_REQUESTS: "SET_REQUESTS",
  ADD_REQUEST: "ADD_REQUEST",
  UPDATE_REQUEST: "UPDATE_REQUEST",
  SET_DUPLICATE_REQUESTS: "SET_DUPLICATE_REQUESTS",
  SET_CURRENT_REQUEST: "SET_CURRENT_REQUEST",
  SET_POLICY_UPDATES: "SET_POLICY_UPDATES",
  ADD_TOAST: "ADD_TOAST",
  REMOVE_TOAST: "REMOVE_TOAST",
  MARK_NOTIFICATION_READ: "MARK_NOTIFICATION_READ",
  DISMISS_NOTIFICATION: "DISMISS_NOTIFICATION",
  UPDATE_REVIEW: "UPDATE_REVIEW",
  SET_CONVERSATIONS: "SET_CONVERSATIONS",
  ADD_CONVERSATION: "ADD_CONVERSATION",
  UPDATE_CONVERSATION: "UPDATE_CONVERSATION",
  SET_SELECTED_CONVERSATION_ID: "SET_SELECTED_CONVERSATION_ID",
  SET_CONVERSATION_MESSAGES: "SET_CONVERSATION_MESSAGES",
  UPDATE_CONVERSATION_MESSAGES: "UPDATE_CONVERSATION_MESSAGES",
  REPLACE_CONVERSATION_ID: "REPLACE_CONVERSATION_ID",
  REMOVE_CONVERSATION: "REMOVE_CONVERSATION",
};

// ─── Reducer ─────────────────────────────────────────────────────────────────

function appReducer(state, action) {
  switch (action.type) {
    case ACTIONS.LOGIN:
      return { ...state, isAuthenticated: true, user: action.payload };

    case ACTIONS.LOGOUT:
      return { ...state, isAuthenticated: false, user: null };

    case ACTIONS.SET_LOADING:
      return {
        ...state,
        loading: { ...state.loading, [action.key]: action.value },
      };

    case ACTIONS.SET_REQUESTS:
      return { ...state, requests: action.payload };

    case ACTIONS.ADD_REQUEST:
      return { ...state, requests: [action.payload, ...state.requests] };

    case ACTIONS.SET_DUPLICATE_REQUESTS:
      return {
        ...state,
        duplicateRequests: [action.payload, ...state.duplicateRequests],
      };

    case ACTIONS.UPDATE_REQUEST:
      return {
        ...state,
        requests: state.requests.map((r) =>
          r.request_id === action.payload.request_id
            ? { ...r, ...action.payload }
            : r,
        ),
        currentRequest:
          state.currentRequest?.request_id === action.payload.request_id
            ? { ...state.currentRequest, ...action.payload }
            : state.currentRequest,
      };

    case ACTIONS.UPDATE_REVIEW:
      return {
        ...state,
        reviews: state.reviews.map((r) =>
          r.review_id === action.payload.review_id
            ? { ...r, ...action.payload }
            : r,
        ),
      };
    case ACTIONS.SET_CURRENT_REQUEST:
      return { ...state, currentRequest: action.payload };

    case ACTIONS.SET_POLICY_UPDATES:
      return { ...state, policyUpdates: action.payload };

    case ACTIONS.ADD_TOAST:
      return {
        ...state,
        toasts: [...state.toasts, { id: Date.now(), ...action.payload }],
      };

    case ACTIONS.REMOVE_TOAST:
      return {
        ...state,
        toasts: state.toasts.filter((t) => t.id !== action.id),
      };

    case ACTIONS.MARK_NOTIFICATION_READ:
      return {
        ...state,
        notifications: state.notifications.map((n) =>
          n.id === action.id ? { ...n, read: true } : n,
        ),
      };

    case ACTIONS.DISMISS_NOTIFICATION:
      return {
        ...state,
        notifications: state.notifications.filter((n) => n.id !== action.id),
      };

    case ACTIONS.SET_CONVERSATIONS:
      return {
        ...state,
        chatConversations: action.payload,
      };

    case ACTIONS.ADD_CONVERSATION:
      return {
        ...state,
        chatConversations: state.chatConversations.some(
          (c) => c.conversation_id === action.payload.conversation_id,
        )
          ? state.chatConversations
          : [action.payload, ...state.chatConversations],
      };

    case ACTIONS.SET_SELECTED_CONVERSATION_ID:
      return {
        ...state,
        selectedConversationId: action.payload,
      };

    case ACTIONS.UPDATE_CONVERSATION:
      return {
        ...state,
        chatConversations: state?.chatConversations?.map((conversation) => {
          if (
            action.payload?.conversation_id == conversation?.conversation_id
          ) {
            return action?.payload;
          } else {
            return conversation;
          }
        }),
      };

    case ACTIONS.SET_CONVERSATION_MESSAGES:
      return {
        ...state,
        messagesByConversationId: {
          ...state.messagesByConversationId,
          [action.payload.conversationId]: action.payload.messages,
        },
      };

    case ACTIONS.UPDATE_CONVERSATION_MESSAGES: {
      const { conversationId, updater } = action.payload;
      const current = state.messagesByConversationId[conversationId] || [];
      return {
        ...state,
        messagesByConversationId: {
          ...state.messagesByConversationId,
          [conversationId]: updater(current),
        },
      };
    }

    // Used when a locally-created "New Chat" placeholder (a fake
    // conversation_id created client-side, before the backend conversation
    // actually exists) gets promoted to a real conversation once the user
    // sends their first message. Swaps the placeholder id for the real one
    // everywhere it's tracked — the sidebar list, any cached messages, and
    // the currently-selected conversation id — so the chat keeps working
    // (and persists across navigation) under its real id from that point on.
    case ACTIONS.REPLACE_CONVERSATION_ID: {
      const { oldConversationId, conversation } = action.payload;
      const newConversationId = conversation?.conversation_id;
      if (!newConversationId || oldConversationId === newConversationId) {
        return state;
      }

      const oldConversation = state.chatConversations.find(
        (c) => c.conversation_id === oldConversationId,
      );

      const chatConversations = oldConversation
        ? state.chatConversations.map((c) =>
            c.conversation_id === oldConversationId ? conversation : c,
          )
        : [conversation, ...state.chatConversations];

      const messagesByConversationId = { ...state.messagesByConversationId };
      if (oldConversationId in messagesByConversationId) {
        messagesByConversationId[newConversationId] =
          messagesByConversationId[oldConversationId];
        delete messagesByConversationId[oldConversationId];
      }

      return {
        ...state,
        chatConversations,
        messagesByConversationId,
        selectedConversationId:
          state.selectedConversationId === oldConversationId
            ? newConversationId
            : state.selectedConversationId,
      };
    }

    // Removes a conversation from every place it's tracked — the sidebar
    // list and its cached messages — and (if it was the selected one)
    // picks the next available conversation instead. Used both for a
    // normal successful delete AND as the local fallback when the delete
    // API call fails for a conversation the backend never actually has a
    // record of yet (a client-side "New Chat" placeholder that was never
    // sent to, or one whose creation the sidebar list hasn't caught up
    // with) — in either case, removing it locally is correct.
    case ACTIONS.REMOVE_CONVERSATION: {
      const { conversationId } = action.payload;
      const chatConversations = state.chatConversations.filter(
        (c) => c.conversation_id !== conversationId,
      );

      const messagesByConversationId = { ...state.messagesByConversationId };
      delete messagesByConversationId[conversationId];

      return {
        ...state,
        chatConversations,
        messagesByConversationId,
        selectedConversationId:
          state.selectedConversationId === conversationId
            ? chatConversations[0]?.conversation_id || null
            : state.selectedConversationId,
      };
    }

    default:
      return state;
  }
}

// ─── Context ─────────────────────────────────────────────────────────────────

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // ─── Helpers ─────────────────────────────────────────────────────────────

  const setLoading = useCallback((key, value) => {
    dispatch({ type: ACTIONS.SET_LOADING, key, value });
  }, []);

  const setRequests = useCallback((requests) => {
    dispatch({ type: ACTIONS.SET_REQUESTS, payload: requests });
  }, []);

  const addRequest = useCallback((request) => {
    dispatch({ type: ACTIONS.ADD_REQUEST, payload: request });
  }, []);

  const updateRequest = useCallback((request) => {
    dispatch({ type: ACTIONS.UPDATE_REQUEST, payload: request });
  }, []);

  const updateReview = useCallback((review) => {
    dispatch({ type: ACTIONS.UPDATE_REVIEW, payload: review });
  }, []);

  const setDuplicateRequests = useCallback((review) => {
    dispatch({ type: ACTIONS.SET_DUPLICATE_REQUESTS, payload: review });
  }, []);

  const setCurrentRequest = useCallback((request) => {
    dispatch({ type: ACTIONS.SET_CURRENT_REQUEST, payload: request });
  }, []);

  const setPolicyUpdates = useCallback((updates) => {
    dispatch({ type: ACTIONS.SET_POLICY_UPDATES, payload: updates });
  }, []);

  const setConversations = useCallback((conversations) => {
    dispatch({ type: ACTIONS.SET_CONVERSATIONS, payload: conversations });
  }, []);

  const addConversation = useCallback((conversation) => {
    dispatch({ type: ACTIONS.ADD_CONVERSATION, payload: conversation });
  }, []);

  const setSelectedConversationId = useCallback((conversationId) => {
    dispatch({
      type: ACTIONS.SET_SELECTED_CONVERSATION_ID,
      payload: conversationId,
    });
  }, []);

  const removeConversation = useCallback((conversationId) => {
    dispatch({
      type: ACTIONS.REMOVE_CONVERSATION,
      payload: { conversationId },
    });
  }, []);

  const updateConversation = useCallback((conversation) => {
    dispatch({ type: ACTIONS.UPDATE_CONVERSATION, payload: conversation });
  }, []);

  const setConversationMessages = useCallback((conversationId, messages) => {
    dispatch({
      type: ACTIONS.SET_CONVERSATION_MESSAGES,
      payload: { conversationId, messages },
    });
  }, []);

  const updateConversationMessages = useCallback((conversationId, updater) => {
    dispatch({
      type: ACTIONS.UPDATE_CONVERSATION_MESSAGES,
      payload: { conversationId, updater },
    });
  }, []);

  const replaceConversationId = useCallback(
    (oldConversationId, conversation) => {
      dispatch({
        type: ACTIONS.REPLACE_CONVERSATION_ID,
        payload: { oldConversationId, conversation },
      });
    },
    [],
  );

  const addToast = useCallback((toast) => {
    const id = Date.now() + Math.random();
    dispatch({
      type: ACTIONS.ADD_TOAST,
      payload: { ...toast, id },
    });
    // Auto-remove after duration
    const duration = toast.duration || 5000;
    setTimeout(() => {
      dispatch({ type: ACTIONS.REMOVE_TOAST, id });
    }, duration);
  }, []);

  const removeToast = useCallback((id) => {
    dispatch({ type: ACTIONS.REMOVE_TOAST, id });
  }, []);

  const markNotificationRead = useCallback((id) => {
    dispatch({ type: ACTIONS.MARK_NOTIFICATION_READ, id });
  }, []);

  const dismissNotification = useCallback((id) => {
    dispatch({ type: ACTIONS.DISMISS_NOTIFICATION, id });
  }, []);

  const login = useCallback((user) => {
    dispatch({ type: ACTIONS.LOGIN, payload: user });
  }, []);

  const logout = useCallback(async () => {
    try {
      await logoutFromCognito();
    } catch (error) {
      console.error("Cognito logout failed:", error);
    } finally {
      dispatch({ type: ACTIONS.LOGOUT });
      localStorage.removeItem("user");
    }
  }, []);

  const value = {
    state,
    dispatch,
    login,
    logout,
    setLoading,
    setRequests,
    addRequest,
    updateRequest,
    updateReview,
    setCurrentRequest,
    setDuplicateRequests,
    setPolicyUpdates,
    addToast,
    removeToast,
    markNotificationRead,
    dismissNotification,
    setConversations,
    addConversation,
    setSelectedConversationId,
    updateConversation,
    setConversationMessages,
    updateConversationMessages,
    replaceConversationId,
    removeConversation,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}

export default AppContext;
