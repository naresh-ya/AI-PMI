import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  CheckCircle,
  XCircle,
  FileText,
  Eye,
  BookOpen,
  AlertCircle,
  Loader2,
  User,
  Download,
  Clock,
} from "lucide-react";
import {
  fetchDocumentPreview,
  updateReviews,
  submitReviewDecision,
  completeRequest,
  submitLegalRedraft,
  downloadGeneratedDocument,
  getReviewersByCategory,
} from "../services/api";
import { useApp } from "../context/AppContext";
import { DISPLAY_TEXT } from "../utils/constants";
import DocumentVersionPreview from "./DocumentVersionPreview";

// Hardcoded single-reviewer fallback — used for both CA and Legal reviewer
// dropdowns whenever getReviewersByCategory() fails (or comes back with an
// empty `reviewers` list). Same person (moo.jangkamolkulchai@pmi.com —
// matches the demo account Login.jsx already seeds) is used either way, per
// request. Reviewer objects from the real API have no `id` field, only
// name/email/role/country, so `email` doubles as the unique key everywhere
// below.
const FALLBACK_REVIEWER = {
  name: "Moo Jangkamolkulchai",
  email: "moo.jangkamolkulchai@pmi.com",
};
const FALLBACK_REVIEWERS_LIST = [FALLBACK_REVIEWER];

// Review category query param getReviewersByCategory() is called with —
// all four CA sub-types (Scientific/Regulatory/Communications/Fiscal) share
// the SAME category/call; Legal has its own.
const REVIEW_CATEGORY = {
  ca: "CA_Review",
  legal: "Legal_Review",
};

// Pulls the flat reviewer list out of a getReviewersByCategory() response —
// { review_category, count, reviewers: [{ name, email, role, country }] } —
// reading defensively in case `reviewers` is ever missing/not an array.
function extractReviewersList(response) {
  const list = Array.isArray(response?.reviewers) ? response.reviewers : [];
  return list.filter((entry) => entry?.email && entry?.name);
}

// Review Types Configuration (mirrors HITLDraftReview)
const REVIEW_TYPES = {
  ca: {
    label: "CA Review",
    description:
      "Corporate Affairs review including Scientific, Regulatory, and Communications",
    subTypes: {
      scientific: {
        label: "Scientific Review",
        description: "Review scientific claims and evidence",
      },
      regulatory: {
        label: "Regulatory Review",
        description: "Review compliance with regulations",
      },
      communications: {
        label: "Communications Review",
        description: "Review messaging and tone",
      },
      fiscal: {
        label: "Fiscal Review",
        description: "Review compliance with financial policies",
      },
    },
  },
  legal: {
    label: "Legal Review",
    description: "Legal compliance and risk assessment review",
    subTypes: null,
  },
};

// Role codes used across the platform for the final (Master Reviewer) HITL
// gate. "Normal user" is the requestor; the rest are the specialist
// reviewers who each own one of the review-comment fields below.
// Exported so RequestDetail.jsx can infer/assign one of these reviewer
// roles when a user arrives here via the Approval Queue (see
// inferReviewerRoleFromStatus in RequestDetail.jsx).
export const ROLES = {
  NORMAL_USER: "1001",
  SCIENTIFIC_REVIEWER: "1003",
  REGULATORY_REVIEWER: "1004",
  COMMUNICATION_REVIEWER: "1005",
  FISCAL_REVIEWER: "1006",
  LEGAL_REVIEWER: "1007",
};

const REVIEWER_ROLES = [
  ROLES.SCIENTIFIC_REVIEWER,
  ROLES.REGULATORY_REVIEWER,
  ROLES.COMMUNICATION_REVIEWER,
  ROLES.FISCAL_REVIEWER,
  ROLES.LEGAL_REVIEWER,
];

const isReviewerRole = (role) => REVIEWER_ROLES.includes(role);

/**
 * Human-in-the-Loop Review for the Master Reviewer Agent
 *
 * Displays comprehensive compliance review, risk assessment, quality scores,
 * and the final document for approval before government submission.
 */
function HITLFinalReview({
  request,
  onDecisionComplete,
  pendingReviews,
  role,
  email,
}) {
  const { addToast, updateReview } = useApp();
  const [submitting, setSubmitting] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [activeView, setActiveView] = useState("reviews"); // preview | citations | reviews
  const [documentPreview, setDocumentPreview] = useState(null);
  const [selectedFinalVersion, setSelectedFinalVersion] = useState(null);

  // Review selection state used by the "Review Configuration" tab.
  // "No Review" is selected by default.
  const [selectedReviews, setSelectedReviews] = useState({
    noReview: true,
    ca: false,
    legal: false,
  });
  const [selectedCASubTypes, setSelectedCASubTypes] = useState({
    scientific: false,
    regulatory: false,
    communications: false,
    fiscal: false,
  });

  // Reviewer dropdowns for the Review Configuration tab. The four CA
  // sub-types (Scientific/Regulatory/Communications/Fiscal) share ONE list
  // fetched from the CA_Review category; Legal has its own list fetched
  // from the Legal_Review category. Each is fetched on-demand — the first
  // time its checkbox gets checked, not on mount (see
  // caReviewersFetchedRef/legalReviewersFetchedRef below, and
  // loadReviewersForCategory).
  const [caReviewers, setCaReviewers] = useState(FALLBACK_REVIEWERS_LIST);
  const [caReviewersLoading, setCaReviewersLoading] = useState(false);
  const caReviewersFetchedRef = useRef(false);

  const [legalReviewers, setLegalReviewers] = useState(FALLBACK_REVIEWERS_LIST);
  const [legalReviewersLoading, setLegalReviewersLoading] = useState(false);
  const legalReviewersFetchedRef = useRef(false);

  // Keyed by sub-type/"legal" — values are reviewer EMAILS (the API's
  // reviewer objects have no `id` field, only name/email/role/country).
  const [selectedReviewers, setSelectedReviewers] = useState({
    scientific: "",
    regulatory: "",
    communications: "",
    fiscal: "",
    legal: "",
  });

  // Fetches the reviewer list for a review category (see REVIEW_CATEGORY)
  // and stores it in the matching state, defaulting any not-yet-selected
  // dropdown(s) for that category to the first reviewer returned. Falls
  // back to FALLBACK_REVIEWERS_LIST on error or an empty response.
  const loadReviewersForCategory = async (category) => {
    const isCA = category === REVIEW_CATEGORY.ca;
    const setList = isCA ? setCaReviewers : setLegalReviewers;
    const setLoading = isCA ? setCaReviewersLoading : setLegalReviewersLoading;
    setLoading(true);
    let list = FALLBACK_REVIEWERS_LIST;
    try {
      const response = await getReviewersByCategory(category);
      const fetched = extractReviewersList(response);
      if (fetched.length) list = fetched;
    } catch (error) {
      console.log(error);
      // list stays FALLBACK_REVIEWERS_LIST
    }
    setList(list);
    const defaultEmail = list[0]?.email || "";
    setSelectedReviewers((prev) =>
      isCA
        ? {
            ...prev,
            scientific: prev.scientific || defaultEmail,
            regulatory: prev.regulatory || defaultEmail,
            communications: prev.communications || defaultEmail,
            fiscal: prev.fiscal || defaultEmail,
          }
        : { ...prev, legal: prev.legal || defaultEmail },
    );
    setLoading(false);
  };

  const scientificReviewRef = useRef();
  const regulatoryReviewRef = useRef();
  const communicationReviewRef = useRef();
  const fiscalReviewRef = useRef();
  const legalReviewRef = useRef();
  // Requestor's own optional note on the REVIEW_CHANGES_REQUESTED screen
  // (isChangesRequestedForRequestor below) — sits below all the reviewer
  // feedback cards, read on "Accept Changes" (see handleAcceptChanges).
  const userCommentRef = useRef();

  // Each reviewer role gets exactly ONE of three mutually-exclusive
  // checkboxes: "No Review Required", "Review Changes Requested", or
  // "Approved". Rather than a separate boolean per checkbox per role
  // (which would let more than one end up checked at once), each role has
  // a single flag state that's "no_review", "changes_requested",
  // "approved", or "" (none checked yet). Checking one checkbox sets the
  // flag to its value; checking another overwrites it — so only one can
  // ever be true at a time, and unchecking the currently-active one clears
  // the flag back to "".
  //
  // Comment field enabled/disabled by flag:
  //   - "no_review"  -> disabled (nothing to say, textarea cleared)
  //   - "approved"   -> disabled (approved as-is, textarea cleared)
  //   - "changes_requested" (or none checked) -> enabled, so the reviewer
  //     can type what needs to change
  const REVIEW_FLAG = {
    NO_REVIEW: "no_review",
    CHANGES_REQUESTED: "changes_requested",
    APPROVED: "approved",
  };

  const [scientificFlag, setScientificFlag] = useState("");
  const [regulatoryFlag, setRegulatoryFlag] = useState("");
  const [communicationFlag, setCommunicationFlag] = useState("");
  const [fiscalFlag, setFiscalFlag] = useState("");
  const [legalFlag, setLegalFlag] = useState("");

  const navigate = useNavigate();

  // Once a request's status is REVIEW_CHANGES_REQUESTED, the reviewer(s)
  // have already made their decision and the ball is back with the
  // requestor to address the feedback — there's nothing left for ANY
  // reviewer role to do here. Any reviewer landing on this page in that
  // state gets bounced straight to the Dashboard instead of a stale/
  // inactive review screen (see the early `return null` below, which
  // prevents that screen from flashing for a frame before the redirect
  // fires).
  const isChangesRequestedByReviewer =
    request?.status === "REVIEW_CHANGES_REQUESTED" && isReviewerRole(role);

  // Same status, but for the normal user (requestor): show every review
  // field — populated, disabled — so they can read exactly what each
  // reviewer said, and hide every other part of this view (the Review
  // Configuration/Content Preview tabs, the "under review" banner, the
  // decision buttons) since the only actionable thing here is reading the
  // feedback before revising/resubmitting elsewhere.
  const isChangesRequestedForRequestor =
    request?.status === "REVIEW_CHANGES_REQUESTED" &&
    role === ROLES.NORMAL_USER;

  useEffect(() => {
    if (isChangesRequestedByReviewer) {
      addToast({
        type: "info",
        title: "Changes Requested",
        message:
          "This request is back with the requestor for changes — there's nothing further to review here.",
      });
      navigate("/");
    }
  }, [isChangesRequestedByReviewer]);

  useEffect(() => {
    const fetchDocumentData = async () => {
      try {
        const response = await fetchDocumentPreview(request?.request_id);
        setDocumentPreview(response);
        setSelectedFinalVersion(response?.current?.version ?? null);
      } catch (error) {
        console.log(error);
      }
    };
    if (request?.request_id) {
      fetchDocumentData();
    }
  }, [request]);

  const handleReviewerSelect = (subType, reviewerEmail) => {
    setSelectedReviewers((prev) => ({ ...prev, [subType]: reviewerEmail }));
  };

  // True while any of the (applicable) reviewer fields is still empty —
  // i.e. that reviewer hasn't submitted their comment/decision yet. Uses
  // `?.length > 0` (not `.length > 0`) on each field since a request's
  // `review` sub-object commonly has some fields as "" (not applicable to
  // that review_type — e.g. a "legal_only" review leaves
  // scientific/regulatory/communication/fiscal all "") rather than every
  // field always being populated.
  const areReviewsPending = () => {
    if (!pendingReviews) return true;

    const regulatoryReviewOk = pendingReviews?.regulatoryReview?.length > 0;
    const scientificReviewOk = pendingReviews?.scientificReview?.length > 0;
    const communicationsReviewOk =
      pendingReviews?.communicationReview?.length > 0;
    const fiscalReviewOk = pendingReviews?.fiscalReview?.length > 0;
    const legalReviewOk = pendingReviews?.legalReview?.length > 0;

    if (
      regulatoryReviewOk &&
      scientificReviewOk &&
      communicationsReviewOk &&
      fiscalReviewOk &&
      legalReviewOk
    ) {
      return false;
    }

    return true;
  };

  // PLACEHOLDER reviewer names for the "pending review" table shown to the
  // normal user/requestor below (see getPendingReviewTableRows). The
  // backend doesn't return assigned-reviewer names on the request yet —
  // once it does (e.g. a `pendingReviews.scientificReviewerName` field, or
  // similar per type), swap the lookups below for that real field and
  // delete this object.
  const DUMMY_REVIEWER_NAMES = {
    scientificReview: "Aarav Sharma",
    regulatoryReview: "Neha Singh",
    communicationReview: "Priya Verma",
    fiscalReview: "Rohit Gupta",
    legalReview: "Moo Jangkamolkulchai",
  };

  // Builds the rows for the "pending review" table shown to the normal
  // user/requestor while any review is still outstanding. Only includes a
  // row for a review type that's actually part of THIS request (i.e. its
  // pendingReviews field is non-empty) — the same `?.length > 0` check
  // areReviewsPending uses above, so e.g. a legal_only request's table only
  // shows a Legal row, not all five. "completed" mirrors the same field's
  // check used elsewhere on this screen to decide a review is done.
  const getPendingReviewTableRows = () => {
    const rows = [
      { key: "scientificReview", label: "Scientific Review" },
      { key: "regulatoryReview", label: "Regulatory Review" },
      { key: "communicationReview", label: "Communications Review" },
      { key: "fiscalReview", label: "Fiscal Review" },
      { key: "legalReview", label: "Legal Review" },
    ];
    return rows
      .filter((row) => pendingReviews?.[row.key]?.length > 0)
      .map((row) => ({
        ...row,
        reviewer: DUMMY_REVIEWER_NAMES[row.key],
        completed: pendingReviews?.[row.key] !== "pending",
      }));
  };

  const handleReviewToggle = (reviewType) => {
    if (reviewType === "noReview") {
      setSelectedReviews({
        noReview: !selectedReviews.noReview,
        ca: false,
        legal: false,
      });
      setSelectedCASubTypes({
        scientific: false,
        regulatory: false,
        communications: false,
        fiscal: false,
      });
    } else if (reviewType === "ca") {
      const turningOn = !selectedReviews.ca;
      setSelectedReviews((prev) => ({
        ...prev,
        noReview: false,
        ca: turningOn,
      }));
      // Checking CA review automatically checks all of its sub-reviews.
      // Unchecking CA review automatically unchecks all of its sub-reviews.
      setSelectedCASubTypes({
        scientific: turningOn,
        regulatory: turningOn,
        communications: turningOn,
        fiscal: turningOn,
      });
      if (turningOn && !caReviewersFetchedRef.current) {
        caReviewersFetchedRef.current = true;
        loadReviewersForCategory(REVIEW_CATEGORY.ca);
      }
    } else {
      const turningOn = !selectedReviews[reviewType];
      setSelectedReviews((prev) => ({
        ...prev,
        noReview: false,
        [reviewType]: turningOn,
      }));
      if (
        reviewType === "legal" &&
        turningOn &&
        !legalReviewersFetchedRef.current
      ) {
        legalReviewersFetchedRef.current = true;
        loadReviewersForCategory(REVIEW_CATEGORY.legal);
      }
    }
  };

  const handleCASubTypeToggle = (subType) => {
    setSelectedCASubTypes((prev) => {
      const updated = { ...prev, [subType]: !prev[subType] };
      // If every CA sub-review has been unchecked, CA review itself
      // automatically gets unchecked.
      const anySubTypeSelected = Object.values(updated).some((v) => v);
      setSelectedReviews((prevReviews) => ({
        ...prevReviews,
        ca: anySubTypeSelected,
      }));
      if (updated[subType] && !caReviewersFetchedRef.current) {
        caReviewersFetchedRef.current = true;
        loadReviewersForCategory(REVIEW_CATEGORY.ca);
      }
      return updated;
    });
  };

  const isAnyReviewSelected = () => {
    if (selectedReviews.noReview) return true;
    if (selectedReviews.ca) {
      return Object.values(selectedCASubTypes).some((v) => v);
    }
    return selectedReviews.legal;
  };

  // The bottom-right decision button's label depends on whether CA or Legal
  // review has been selected (either one routes the request to further
  // reviewers instead of completing it directly).
  const isCAOrLegalSelected = () =>
    (selectedReviews.ca && Object.values(selectedCASubTypes).some((v) => v)) ||
    selectedReviews.legal;

  const reviewDecisionLabel = isCAOrLegalSelected()
    ? "Proceed to reviews"
    : "Complete Request";

  // Clears the current viewer's own comment textarea whenever either of
  // its two textarea-disabling checkboxes gets checked ("No Review
  // Required" or "Approved") — the flag itself (not free text) is what's
  // sent in that case, so any text already typed shouldn't linger unsent.
  // NOT called for "Review Changes Requested", which leaves the textarea
  // enabled (see each checkbox's own onChange below).
  const setReview = (flagChecked) => {
    switch (true) {
      case role == ROLES.REGULATORY_REVIEWER && flagChecked:
        regulatoryReviewRef.current.value = "";
        break;
      case role == ROLES.SCIENTIFIC_REVIEWER && flagChecked:
        scientificReviewRef.current.value = "";
        break;
      case role == ROLES.COMMUNICATION_REVIEWER && flagChecked:
        communicationReviewRef.current.value = "";
        break;
      case role == ROLES.FISCAL_REVIEWER && flagChecked:
        fiscalReviewRef.current.value = "";
        break;
      case role == ROLES.LEGAL_REVIEWER && flagChecked:
        legalReviewRef.current.value = "";
        break;
    }
  };

  const handleDecision = async (action) => {
    if (action === "cancel") {
      navigate("/");
      return;
    }

    if (action === "start_review") {
      let reviewType = "";
      switch (true) {
        case selectedReviews.noReview:
          reviewType = "no_review";
          break;
        case selectedReviews.ca && selectedReviews.legal:
          reviewType = "ca_and_legal";
          break;
        case selectedReviews.ca && !selectedReviews.legal:
          reviewType = "ca_only";
          break;
        case !selectedReviews.ca && selectedReviews.legal:
          reviewType = "legal_only";
          break;
      }
      const reviewsBody = {
        review_id: "NEW",
        review_type: reviewType,
        requested_by: email,
        scientificReview: selectedCASubTypes?.scientific ? "pending" : "",
        regulatoryReview: selectedCASubTypes?.regulatory ? "pending" : "",
        communicationReview: selectedCASubTypes?.communications
          ? "pending"
          : "",
        fiscalReview: selectedCASubTypes?.fiscal ? "pending" : "",
        regionalFPReview: "pending",
        legalReview: selectedReviews?.legal ? "pending" : "",
        // Selected reviewer's email — prefers the Legal reviewer (matches
        // legal_only/ca_and_legal), falling back to whichever CA sub-type
        // reviewer was selected for ca_only. Empty string for no_review.
        reviewer_email:
          selectedReviewers.legal ||
          selectedReviewers.scientific ||
          selectedReviewers.regulatory ||
          selectedReviewers.communications ||
          selectedReviewers.fiscal ||
          "",
      };
      setSubmitting(true);
      const response = await updateReviews(
        reviewsBody,
        request?.request_id,
        email,
      );
      setTimeout(() => {
        setSubmitting(false);
        addToast({
          type: action === "accept_review" ? "success" : "warning",
          title:
            action === "accept_review" ? "Review Accepted" : "Changes Rejected",
          message:
            action === "accept_review"
              ? "Review changes have been accepted."
              : "Review changes have been rejected.",
        });
        onDecisionComplete?.(action);
      }, 1000);
      return;
    }

    if (action == "submit_review") {
      setSubmitting(true);

      // Same call for every reviewer role — only which field's ref/flag is
      // read differs. Checking either checkbox sends feedback as that
      // checkbox's label text (instead of whatever's left in the textarea)
      // plus the underlying flag value ("no_review"/"changes_requested") so
      // the backend gets a stable machine-readable field instead of having
      // to parse the feedback string.
      let feedback = "";
      let reviewFlag = "";
      // `pendingReviews` is currently always null here (RequestDetail.jsx
      // declares setPendingReviews but never calls it — the reviews object
      // is never actually populated/fetched yet). Guard every mutation on
      // it so that gap doesn't crash this handler: `pendingReviews.x = ...`
      // on null throws synchronously, which was silently aborting this
      // whole function before it ever reached submitReviewDecision() below.
      switch (role) {
        // Only "No Review Required" replaces feedback with fixed label
        // text — the textarea is disabled/cleared for that case, so
        // there's nothing else to send. "Review Changes Requested" leaves
        // the textarea enabled, so the reviewer's actual typed comment is
        // what gets sent (the flag itself already tells the backend it's
        // a change request; the text is the "what needs to change" detail).
        case ROLES.REGULATORY_REVIEWER:
          reviewFlag = regulatoryFlag;
          feedback =
            regulatoryFlag === REVIEW_FLAG.NO_REVIEW
              ? "No Review Required"
              : regulatoryFlag === REVIEW_FLAG.APPROVED
                ? "Approved"
                : regulatoryReviewRef.current.value;
          if (pendingReviews) {
            pendingReviews.regulatoryReview = feedback;
            updateReview(pendingReviews.regulatoryReview);
          }
          break;
        case ROLES.SCIENTIFIC_REVIEWER:
          reviewFlag = scientificFlag;
          feedback =
            scientificFlag === REVIEW_FLAG.NO_REVIEW
              ? "No Review Required"
              : scientificFlag === REVIEW_FLAG.APPROVED
                ? "Approved"
                : scientificReviewRef.current.value;
          if (pendingReviews) {
            pendingReviews.scientificReview = feedback;
            updateReview(pendingReviews.scientificReview);
          }
          break;
        case ROLES.COMMUNICATION_REVIEWER:
          reviewFlag = communicationFlag;
          feedback =
            communicationFlag === REVIEW_FLAG.NO_REVIEW
              ? "No Review Required"
              : communicationFlag === REVIEW_FLAG.APPROVED
                ? "Approved"
                : communicationReviewRef.current.value;
          if (pendingReviews) {
            pendingReviews.communicationReview = feedback;
            updateReview(pendingReviews.communicationReview);
          }
          break;
        case ROLES.FISCAL_REVIEWER:
          reviewFlag = fiscalFlag;
          feedback =
            fiscalFlag === REVIEW_FLAG.NO_REVIEW
              ? "No Review Required"
              : fiscalFlag === REVIEW_FLAG.APPROVED
                ? "Approved"
                : fiscalReviewRef.current.value;
          if (pendingReviews) {
            pendingReviews.fiscalReview = feedback;
            updateReview(pendingReviews.fiscalReview);
          }
          break;
        case ROLES.LEGAL_REVIEWER:
          reviewFlag = legalFlag;
          feedback =
            legalFlag === REVIEW_FLAG.NO_REVIEW
              ? "No Review Required"
              : legalFlag === REVIEW_FLAG.APPROVED
                ? "Approved"
                : legalReviewRef.current.value;
          if (pendingReviews) {
            pendingReviews.legalReview = feedback;
            updateReview(pendingReviews.legalReview);
          }
          break;
      }

      let apiFailed = false;
      try {
        const response = await submitReviewDecision(
          request?.request_id,
          email,
          feedback,
          reviewFlag,
        );
      } catch (error) {
        console.log(error);
        apiFailed = true;
      }

      setTimeout(() => {
        setSubmitting(false);
        addToast(
          apiFailed
            ? {
                type: "warning",
                title: "Submission Failed",
                message: "Something went wrong submitting your review. Please try again.",
              }
            : {
                type: "info",
                title: "Saved",
                message: "Review submitted successfully",
              },
        );
        if (!apiFailed) {
          onDecisionComplete?.(action);
        }
      }, 2000);
    }
  };

  // Requestor's response to reviewer feedback on a REVIEW_CHANGES_REQUESTED
  // request — "Accept Changes" button on isChangesRequestedForRequestor's
  // view below. Sends the real { user_id } payload, then calls
  // onDecisionComplete so RequestDetail.jsx's handleHITLDecisionComplete
  // re-fetches the request via getRequest() — without this, the screen was
  // left showing the stale REVIEW_CHANGES_REQUESTED state after a
  // successful call.
  const handleAcceptChanges = async () => {
    setSubmitting(true);
    try {
      await submitLegalRedraft(
        request?.request_id,
        email,
        userCommentRef.current?.value || "",
      );
      onDecisionComplete?.("accept_changes");
    } catch (error) {
      console.log(error);
      addToast({
        type: "warning",
        title: "Submission Failed",
        message: "Something went wrong. Please try again.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // "Complete Request" button on the DRAFTING_COMPLETED view below — same
  // completeRequest() call that used to sit behind the
  // REVIEW_CHANGES_REQUESTED view's "Reject Changes" button (now removed
  // from there; this is its one remaining home). Sends the real
  // { user_id } payload, then calls onDecisionComplete so
  // RequestDetail.jsx's handleHITLDecisionComplete re-fetches the request.
  const handleCompleteRequest = async () => {
    setSubmitting(true);
    try {
      await completeRequest(request?.request_id, email);
      onDecisionComplete?.("complete_request");
    } catch (error) {
      console.log(error);
      addToast({
        type: "warning",
        title: "Submission Failed",
        message: "Something went wrong. Please try again.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // Downloads the generated document — same call GeneratedDocument.jsx uses
  // for its own Download button (documentPreview covers change tracking/
  // versioning; this fetches the actual file from `document_s3_key`).
  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadGeneratedDocument(request?.document_s3_key);
    } catch (error) {
      console.log(error);
    } finally {
      setDownloading(false);
    }
  };

  // A reviewer is being redirected away (see the effect above) — render
  // nothing but a brief "redirecting" notice rather than the full (now
  // stale/inactive) review screen while navigate("/") takes effect.
  if (isChangesRequestedByReviewer) {
    return (
      <div className="flex items-center justify-center gap-2 py-12 text-gray-500">
        <Loader2 className="h-4 w-4 animate-spin" />
        Redirecting to Dashboard...
      </div>
    );
  }

  // Requestor view for REVIEW_CHANGES_REQUESTED: every review field, shown
  // read-only with whatever feedback each reviewer left (blank for any
  // review type that wasn't part of this request's review_type) — nothing
  // else on this screen is relevant right now, so everything else (the
  // Review Configuration/Content Preview tabs, the "under review" banner,
  // and the decision buttons) is intentionally omitted here rather than
  // reused/hidden piecemeal below.
  if (isChangesRequestedForRequestor) {
    // NOTE: Legal deliberately reads `legal_feedback`, not `legalReview` —
    // in `pendingReviews`, `legalReview` holds a decision code (e.g.
    // "changes_requested"), while the reviewer's actual comment text lives
    // in `legal_feedback`. Every other role stores its comment text
    // directly in its own `*Review` field, so only Legal needs the
    // different key here.
    const reviewFields = [
      { key: "scientificReview", label: "Scientific Review Comments" },
      { key: "regulatoryReview", label: "Regulatory Review Comments" },
      { key: "communicationReview", label: "Communications Review Comments" },
      { key: "fiscalReview", label: "Fiscal Review Comments" },
      { key: "legal_feedback", label: "Legal Review Comments" },
    ];

    return (
      <div className="space-y-6">
        <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4">
          <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-800">Changes Requested</p>
            <p className="text-sm text-amber-700 mt-1">
              {pendingReviews?.feedback ||
                "One or more reviewers have requested changes. Review the feedback below."}
            </p>
          </div>
        </div>

        {/* Only reviewers who actually left a comment get a card — an
            empty/missing field means that review type wasn't part of this
            request's review_type (see the reviewFields NOTE above), so
            there's nothing useful to show for it here. Each visible card
            gets a "Reviewed" checkmark badge next to its title, so it's
            clear at a glance which reviewers have weighed in. */}
        {reviewFields
          .filter((field) => pendingReviews?.[field.key])
          .map((field) => (
            <div
              key={field.key}
              className="border border-gray-200 rounded-lg p-5"
            >
              <div className="flex items-center mb-3">
                <h4 className="font-semibold text-gray-900">{field.label}</h4>
                <span className="ml-2 inline-flex items-center gap-1 text-xs font-medium text-green-600">
                  <CheckCircle className="h-4 w-4" />
                  Reviewed
                </span>
              </div>
              <textarea
                defaultValue={pendingReviews?.[field.key] || ""}
                disabled
                rows={3}
                placeholder="No feedback provided"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-gray-50 text-gray-700 disabled:opacity-100 focus:outline-none"
              />
            </div>
          ))}

        {/* Requestor's own note, below all the reviewer feedback cards —
            unlike those (read-only, populated from pendingReviews), this
            one is editable: the requestor types it here, and it's read
            (via userCommentRef) and sent as `user_comment` when they click
            "Accept Changes" below. */}
        <div className="border border-gray-200 rounded-lg p-5">
          <h4 className="font-semibold text-gray-900 mb-3">User Comments</h4>
          <textarea
            ref={userCommentRef}
            rows={3}
            placeholder="Add any comments before accepting the requested changes..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
          />
        </div>

        {/* Decision Buttons — Cancel needs no explicit behavior of its own
            (handleDecision("cancel") just navigates home). "Reject Changes"
            (completeRequest) now lives on the DRAFTING_COMPLETED view below
            as "Complete Request" instead of here. */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <button
            onClick={() => handleDecision("cancel")}
            className="flex items-center gap-2 px-5 py-2.5 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 font-medium text-sm"
          >
            <XCircle className="h-4 w-4" />
            Cancel
          </button>

          <div className="flex gap-3 ml-auto">
            <button
              onClick={handleAcceptChanges}
              disabled={submitting}
              className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold disabled:opacity-50"
            >
              {submitting ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <CheckCircle className="h-5 w-5" />
              )}
              Accept Changes
            </button>
          </div>
        </div>
      </div>
    );
  }

  // DRAFTING_COMPLETED: shows the document preview with a single
  // "Complete Request" action on the right — this now owns the API call
  // (completeRequest) that used to live on the REVIEW_CHANGES_REQUESTED
  // view's "Reject Changes" button above.
  if (request?.status === "DRAFTING_COMPLETED") {
    return (
      <div className="space-y-6">
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          <div className="p-5">
            {documentPreview?.current ? (
              <DocumentVersionPreview
                previewData={documentPreview}
                selectedFinalVersion={selectedFinalVersion}
                onSelectFinalVersion={setSelectedFinalVersion}
                allowVersionActions={false}
              />
            ) : (
              <div className="text-center py-12 text-gray-400">
                <Eye className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="text-sm">
                  Content preview will appear here when the draft is ready.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-end pt-4 border-t border-gray-200">
          <button
            onClick={handleCompleteRequest}
            disabled={submitting}
            className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold disabled:opacity-50"
          >
            {submitting ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <CheckCircle className="h-5 w-5" />
            )}
            Complete Request
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Document context for reviewers — while a request is actively
          pending with ANY reviewer role (not just the one matching the
          current viewer, checked further below), show the document header
          (mirrors GeneratedDocument.jsx's header, including its Download
          Document button — see handleDownload) and the Content Preview, so
          the reviewer can actually see (and download) the document they're
          reviewing instead of just a blank comment field. Not shown for
          the normal user/requestor — they get their own tabbed Review
          Configuration / Content Preview view below instead. */}
      {isReviewerRole(role) && request?.status !== "REVIEW_NOT_STARTED" && (
        <>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <FileText className="h-8 w-8 text-pmi-blue" />
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    {request?.topic}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {request?.processing_notes}
                  </p>
                </div>
              </div>
              <button
                onClick={handleDownload}
                disabled={downloading || !request?.document_s3_key}
                className="flex items-center gap-2 px-6 py-3 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy transition-colors font-semibold disabled:opacity-50"
              >
                <Download className="h-5 w-5" />
                {downloading ? "Downloading..." : "Download Document"}
              </button>
            </div>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Content Type</p>
                <p className="font-semibold text-gray-900">
                  {request?.validation_result?.topic}
                </p>
              </div>
            </div>
          </div>

          {documentPreview?.current ? (
            <DocumentVersionPreview
              previewData={documentPreview}
              selectedFinalVersion={selectedFinalVersion}
              onSelectFinalVersion={setSelectedFinalVersion}
              allowVersionActions={false}
            />
          ) : (
            <div className="border border-gray-200 rounded-lg text-center py-12 text-gray-400">
              <Eye className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">
                Content preview will appear here when the draft is ready.
              </p>
            </div>
          )}
        </>
      )}

      {/* Content Preview / Review Configuration tabs are only relevant to
          the normal user (requestor) — reviewers go straight to their
          review-comment field below. */}
      {role === ROLES.NORMAL_USER &&
        request?.status == "REVIEW_NOT_STARTED" && (
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <div className="flex border-b border-gray-200">
              {[
                { key: "reviews", label: "Review Configuration", icon: User },
                { key: "preview", label: "Content Preview", icon: Eye },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveView(tab.key)}
                  className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-colors ${
                    activeView === tab.key
                      ? "border-pmi-blue text-pmi-blue bg-blue-50"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="p-5">
              {/* Content Preview */}
              {activeView === "preview" &&
                (documentPreview?.current ? (
                  <DocumentVersionPreview
                    previewData={documentPreview}
                    selectedFinalVersion={selectedFinalVersion}
                    onSelectFinalVersion={setSelectedFinalVersion}
                    allowVersionActions={
                      request?.status === "DRAFT_REVIEW_PENDING"
                    }
                  />
                ) : (
                  <div className="text-center py-12 text-gray-400">
                    <Eye className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">
                      Content preview will appear here when the draft is ready.
                    </p>
                  </div>
                ))}

              {/* Sources & Citations */}
              {activeView === "citations" && (
                <div className="space-y-3">
                  {request?.research_output?.citations &&
                  request?.research_output?.citations.length > 0 ? (
                    <div className="bg-white-50">
                      <div className="mx-3 my-1 flex items-center justify-between">
                        <h4 className="font-semibold text-gray-900">
                          Click on the references links below to open documents
                          in new tab.
                        </h4>
                      </div>
                      <div className="mx-2 my-4">
                        {request?.research_output?.citations
                          .filter(
                            (ref) =>
                              !(
                                ref?.title?.includes(".json") &&
                                ref?.title?.includes("metadata")
                              ),
                          )
                          .map((ref) => {
                            const Icon =
                              DISPLAY_TEXT[ref?.source_type]?.icon || FileText;
                            const color =
                              DISPLAY_TEXT[ref?.source_type]?.color || "Gray";
                            const sourceTitle =
                              DISPLAY_TEXT[ref?.source_type]?.title ||
                              "Knowledge Base";

                            return (
                              <div
                                key={ref?.index}
                                className="flex items-center gap-2 p-1 transition"
                                title={sourceTitle}
                              >
                                <Icon className={`h-5 w-5 shrink-0 ${color}`} />

                                <a
                                  href={ref?.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-600 hover:underline text-sm font-medium truncate"
                                >
                                  {ref?.title}
                                </a>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 italic">
                      Key messages will be displayed here once the draft is
                      ready.
                    </p>
                  )}
                </div>
              )}

              {/* Review Configuration */}
              {activeView === "reviews" && (
                <div className="space-y-6">
                  {/* Review Type Selection */}
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">
                      Select Review Types{" "}
                      <span className="text-red-500">*</span>
                    </h4>
                    <p className="text-sm text-gray-500 mb-4">
                      Choose which reviews are required for this document. Legal
                      review will start after CA review is complete.
                    </p>

                    <div className="space-y-4">
                      {/* No Review Option */}
                      <div
                        className={`border-2 rounded-lg p-4 transition-all ${selectedReviews.noReview ? "border-pmi-blue bg-blue-50" : "border-gray-200"}`}
                      >
                        <label className="flex items-start gap-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedReviews.noReview}
                            onChange={() => handleReviewToggle("noReview")}
                            className="mt-1 h-4 w-4 text-pmi-blue rounded"
                          />
                          <div className="flex-1">
                            <p className="font-medium text-gray-900">
                              No Review
                            </p>
                            <p className="text-sm text-gray-500">
                              Skip review process and proceed directly
                            </p>
                          </div>
                        </label>
                      </div>

                      {/* CA Review */}
                      <div
                        className={`border-2 rounded-lg p-4 transition-all ${selectedReviews.ca ? "border-pmi-blue bg-blue-50" : "border-gray-200"}`}
                      >
                        <label className="flex items-start gap-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedReviews.ca}
                            onChange={() => handleReviewToggle("ca")}
                            className="mt-1 h-4 w-4 text-pmi-blue rounded"
                          />
                          <div className="flex-1">
                            <p className="font-medium text-gray-900">
                              {REVIEW_TYPES.ca.label}
                            </p>
                            <p className="text-sm text-gray-500">
                              {REVIEW_TYPES.ca.description}
                            </p>
                          </div>
                        </label>

                        {/* CA Sub-types — each card is a plain <div> (not a
                            <label>) so the reviewer <select> below can sit
                            inside it without a click on the dropdown also
                            toggling the checkbox via label-click
                            delegation; only the checkbox+text row itself is
                            wrapped in a <label>. */}
                        {selectedReviews.ca && (
                          <div className="mt-4 ml-7 space-y-3">
                            <p className="text-sm font-medium text-gray-700">
                              Select CA Review Types (runs in parallel):
                            </p>
                            <div className="grid grid-cols-3 gap-3">
                              {Object.entries(REVIEW_TYPES.ca.subTypes).map(
                                ([key, subType]) => (
                                  <div
                                    key={key}
                                    className={`p-3 border-2 rounded-lg transition-all ${
                                      selectedCASubTypes[key]
                                        ? "border-pmi-blue bg-white"
                                        : "border-gray-200 bg-white"
                                    }`}
                                  >
                                    <label className="flex items-center gap-2 cursor-pointer">
                                      <input
                                        type="checkbox"
                                        checked={selectedCASubTypes[key]}
                                        onChange={() =>
                                          handleCASubTypeToggle(key)
                                        }
                                        className="h-4 w-4 text-pmi-blue rounded"
                                      />
                                      <p className="text-sm font-medium text-gray-900">
                                        {subType.label}
                                      </p>
                                    </label>
                                    {selectedCASubTypes[key] && (
                                      <div className="mt-2">
                                        <label className="block text-xs text-gray-500 mb-1">
                                          Reviewer
                                        </label>
                                        <select
                                          value={selectedReviewers[key]}
                                          onChange={(e) =>
                                            handleReviewerSelect(
                                              key,
                                              e.target.value,
                                            )
                                          }
                                          disabled={caReviewersLoading}
                                          className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-xs focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none disabled:opacity-50"
                                        >
                                          {caReviewers.map((reviewer) => (
                                            <option
                                              key={reviewer.email}
                                              value={reviewer.email}
                                            >
                                              {reviewer.name}
                                            </option>
                                          ))}
                                        </select>
                                      </div>
                                    )}
                                  </div>
                                ),
                              )}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Legal Review */}
                      <div
                        className={`border-2 rounded-lg p-4 transition-all ${selectedReviews.legal ? "border-pmi-blue bg-blue-50" : "border-gray-200"}`}
                      >
                        <label className="flex items-start gap-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedReviews.legal}
                            onChange={() => handleReviewToggle("legal")}
                            className="mt-1 h-4 w-4 text-pmi-blue rounded"
                          />
                          <div className="flex-1">
                            <p className="font-medium text-gray-900">
                              {REVIEW_TYPES.legal.label}
                            </p>
                            <p className="text-sm text-gray-500">
                              {REVIEW_TYPES.legal.description}
                            </p>
                          </div>
                        </label>
                        {selectedReviews.legal && (
                          <div className="mt-3 ml-7 max-w-xs">
                            <label className="block text-xs text-gray-500 mb-1">
                              Legal Reviewer
                            </label>
                            <select
                              value={selectedReviewers.legal}
                              onChange={(e) =>
                                handleReviewerSelect("legal", e.target.value)
                              }
                              disabled={legalReviewersLoading}
                              className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none disabled:opacity-50"
                            >
                              {legalReviewers.map((reviewer) => (
                                <option key={reviewer.email} value={reviewer.email}>
                                  {reviewer.name}
                                </option>
                              ))}
                            </select>
                          </div>
                        )}
                      </div>
                    </div>

                    {!isAnyReviewSelected() && (
                      <p className="mt-3 text-sm text-amber-600 flex items-center gap-1">
                        <AlertCircle className="h-4 w-4" />
                        Please select at least one review type
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

      {/* Reviewer Input — while a request is actively pending with a
          reviewer (status != REVIEW_NOT_STARTED), only the single
          review-comment field matching the CURRENT VIEWER'S OWN role is
          shown — the other four are hidden entirely (not just disabled),
          via the `role === ROLES.X` check on each field below (which, by
          construction, is never true for the normal user/requestor).
          Once a review is completed, any field that actually has feedback
          content is shown to any viewer regardless of role — e.g. so the
          requestor can read back what each reviewer said — via the
          separate `pendingReviews?.status === "success"` condition on
          each field. */}
      {((pendingReviews?.status?.toLowerCase() == "success" &&
        pendingReviews?.scientificReview) ||
        (request?.status != "REVIEW_NOT_STARTED" &&
          role === ROLES.SCIENTIFIC_REVIEWER)) && (
        <div className="border border-gray-200 rounded-lg p-5">
          <h4 className="font-semibold text-gray-900 mb-3">
            Scientific Review Comments
          </h4>
          <textarea
            defaultValue={pendingReviews?.scientificReview}
            ref={scientificReviewRef}
            rows={3}
            disabled={
              role !== ROLES.SCIENTIFIC_REVIEWER ||
              scientificFlag === REVIEW_FLAG.NO_REVIEW ||
              scientificFlag === REVIEW_FLAG.APPROVED
            }
            placeholder="To reject explain what needs to change..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
          />
          {role === ROLES.SCIENTIFIC_REVIEWER && (
            <div className="flex items-center gap-6 mt-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={scientificFlag === REVIEW_FLAG.NO_REVIEW}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.NO_REVIEW : "";
                    setReview(!!next);
                    setScientificFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">No Review Required</p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={scientificFlag === REVIEW_FLAG.CHANGES_REQUESTED}
                  onChange={(e) => {
                    // Doesn't clear the textarea (unlike "No Review
                    // Required") — the field stays editable/enabled so the
                    // reviewer can type what needs to change.
                    setScientificFlag(
                      e.target.checked ? REVIEW_FLAG.CHANGES_REQUESTED : "",
                    );
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    Review Changes Requested
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={scientificFlag === REVIEW_FLAG.APPROVED}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.APPROVED : "";
                    setReview(!!next);
                    setScientificFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Approved</p>
                </div>
              </label>
            </div>
          )}
        </div>
      )}

      {((pendingReviews?.status?.toLowerCase() == "success" &&
        pendingReviews?.regulatoryReview) ||
        (request?.status != "REVIEW_NOT_STARTED" &&
          role === ROLES.REGULATORY_REVIEWER)) && (
        <div className="border border-gray-200 rounded-lg p-5">
          <h4 className="font-semibold text-gray-900 mb-3">
            {" "}
            Regulatory Review Comments
          </h4>
          <textarea
            ref={regulatoryReviewRef}
            defaultValue={pendingReviews?.regulatoryReview}
            rows={3}
            disabled={
              role !== ROLES.REGULATORY_REVIEWER ||
              regulatoryFlag === REVIEW_FLAG.NO_REVIEW ||
              regulatoryFlag === REVIEW_FLAG.APPROVED
            }
            placeholder="To reject explain what needs to change..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
          />
          {role === ROLES.REGULATORY_REVIEWER && (
            <div className="flex items-center gap-6 mt-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={regulatoryFlag === REVIEW_FLAG.NO_REVIEW}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.NO_REVIEW : "";
                    setReview(!!next);
                    setRegulatoryFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    No Review Required
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={regulatoryFlag === REVIEW_FLAG.CHANGES_REQUESTED}
                  onChange={(e) => {
                    // Doesn't clear the textarea (unlike "No Review
                    // Required") — the field stays editable/enabled so the
                    // reviewer can type what needs to change.
                    setRegulatoryFlag(
                      e.target.checked ? REVIEW_FLAG.CHANGES_REQUESTED : "",
                    );
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    Review Changes Requested
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={regulatoryFlag === REVIEW_FLAG.APPROVED}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.APPROVED : "";
                    setReview(!!next);
                    setRegulatoryFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Approved</p>
                </div>
              </label>
            </div>
          )}
        </div>
      )}

      {((pendingReviews?.status?.toLowerCase() == "success" &&
        pendingReviews?.communicationReview) ||
        (request?.status != "REVIEW_NOT_STARTED" &&
          role === ROLES.COMMUNICATION_REVIEWER)) && (
        <div className="border border-gray-200 rounded-lg p-5">
          <h4 className="font-semibold text-gray-900 mb-3">
            Communications Review Comments
          </h4>
          <textarea
            ref={communicationReviewRef}
            defaultValue={pendingReviews?.communicationReview}
            rows={3}
            disabled={
              role !== ROLES.COMMUNICATION_REVIEWER ||
              communicationFlag === REVIEW_FLAG.NO_REVIEW ||
              communicationFlag === REVIEW_FLAG.APPROVED
            }
            placeholder="To reject explain what needs to change..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
          />
          {role === ROLES.COMMUNICATION_REVIEWER && (
            <div className="flex items-center gap-6 mt-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={communicationFlag === REVIEW_FLAG.NO_REVIEW}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.NO_REVIEW : "";
                    setReview(!!next);
                    setCommunicationFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    No Review Required
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={communicationFlag === REVIEW_FLAG.CHANGES_REQUESTED}
                  onChange={(e) => {
                    // Doesn't clear the textarea (unlike "No Review
                    // Required") — the field stays editable/enabled so the
                    // reviewer can type what needs to change.
                    setCommunicationFlag(
                      e.target.checked ? REVIEW_FLAG.CHANGES_REQUESTED : "",
                    );
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    Review Changes Requested
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={communicationFlag === REVIEW_FLAG.APPROVED}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.APPROVED : "";
                    setReview(!!next);
                    setCommunicationFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Approved</p>
                </div>
              </label>
            </div>
          )}
        </div>
      )}

      {((pendingReviews?.status?.toLowerCase() == "success" &&
        pendingReviews?.fiscalReview) ||
        (request?.status != "REVIEW_NOT_STARTED" &&
          role === ROLES.FISCAL_REVIEWER)) && (
        <div className="border border-gray-200 rounded-lg p-5">
          <h4 className="font-semibold text-gray-900 mb-3">
            Fiscal Review Comments
          </h4>
          <textarea
            ref={fiscalReviewRef}
            defaultValue={pendingReviews?.fiscalReview}
            rows={3}
            disabled={
              role !== ROLES.FISCAL_REVIEWER ||
              fiscalFlag === REVIEW_FLAG.NO_REVIEW ||
              fiscalFlag === REVIEW_FLAG.APPROVED
            }
            placeholder="To reject explain what needs to change..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
          />
          {role === ROLES.FISCAL_REVIEWER && (
            <div className="flex items-center gap-6 mt-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={fiscalFlag === REVIEW_FLAG.NO_REVIEW}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.NO_REVIEW : "";
                    setReview(!!next);
                    setFiscalFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    No Review Required
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={fiscalFlag === REVIEW_FLAG.CHANGES_REQUESTED}
                  onChange={(e) => {
                    // Doesn't clear the textarea (unlike "No Review
                    // Required") — the field stays editable/enabled so the
                    // reviewer can type what needs to change.
                    setFiscalFlag(
                      e.target.checked ? REVIEW_FLAG.CHANGES_REQUESTED : "",
                    );
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    Review Changes Requested
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={fiscalFlag === REVIEW_FLAG.APPROVED}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.APPROVED : "";
                    setReview(!!next);
                    setFiscalFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Approved</p>
                </div>
              </label>
            </div>
          )}
        </div>
      )}

      {((pendingReviews?.status?.toLowerCase() == "success" &&
        pendingReviews?.legalReview) ||
        (request?.status != "REVIEW_NOT_STARTED" &&
          role === ROLES.LEGAL_REVIEWER)) && (
        <div className="border border-gray-200 rounded-lg p-5">
          <h4 className="font-semibold text-gray-900 mb-3">
            Legal Review Comments
          </h4>
          <textarea
            ref={legalReviewRef}
            defaultValue={pendingReviews?.legal_feedback}
            rows={3}
            disabled={
              role !== ROLES.LEGAL_REVIEWER ||
              legalFlag === REVIEW_FLAG.NO_REVIEW ||
              legalFlag === REVIEW_FLAG.APPROVED
            }
            placeholder="To reject explain what needs to change..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
          />
          {role === ROLES.LEGAL_REVIEWER && (
            <div className="flex items-center gap-6 mt-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={legalFlag === REVIEW_FLAG.NO_REVIEW}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.NO_REVIEW : "";
                    setReview(!!next);
                    setLegalFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    No Review Required
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={legalFlag === REVIEW_FLAG.CHANGES_REQUESTED}
                  onChange={(e) => {
                    // Doesn't clear the textarea (unlike "No Review
                    // Required") — the field stays editable/enabled so the
                    // reviewer can type what needs to change.
                    setLegalFlag(
                      e.target.checked ? REVIEW_FLAG.CHANGES_REQUESTED : "",
                    );
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    Review Changes Requested
                  </p>
                </div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={legalFlag === REVIEW_FLAG.APPROVED}
                  onChange={(e) => {
                    const next = e.target.checked ? REVIEW_FLAG.APPROVED : "";
                    setReview(!!next);
                    setLegalFlag(next);
                  }}
                  className="mt-1 h-4 w-4 text-pmi-blue rounded"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Approved</p>
                </div>
              </label>
            </div>
          )}
        </div>
      )}

      {role === ROLES.NORMAL_USER &&
        areReviewsPending() &&
        request?.status != "REVIEW_NOT_STARTED" && (
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-200 bg-gray-50">
              <h4 className="text-base font-semibold text-gray-900">
                Your request is currently under review
              </h4>
              <p className="mt-1 text-sm text-gray-600">
                We will notify you once all reviews are submitted.
              </p>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b border-gray-200">
                  <th className="px-5 py-2.5 font-medium">Review Type</th>
                  <th className="px-5 py-2.5 font-medium">Reviewer</th>
                  <th className="px-5 py-2.5 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {/* PENDING_REVIEW_TABLE_ROWS below builds each row from
                    `pendingReviews` — reviewer NAMES are still hardcoded
                    placeholders (see DUMMY_REVIEWER_NAMES) since the
                    backend doesn't return assigned-reviewer names on the
                    request yet; swap that lookup for the real field once
                    it's available (the review TYPE/STATUS columns already
                    come from the real `pendingReviews` data). */}
                {getPendingReviewTableRows().map((row) => (
                  <tr
                    key={row.key}
                    className="border-b border-gray-100 last:border-0"
                  >
                    <td className="px-5 py-3 font-medium text-gray-900">
                      {row.label}
                    </td>
                    <td className="px-5 py-3 text-gray-600">{row.reviewer}</td>
                    <td className="px-5 py-3">
                      {row.completed ? (
                        <span className="inline-flex items-center gap-1.5 text-green-600 font-medium">
                          <CheckCircle className="h-4 w-4" />
                          Reviewed
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-amber-600 font-medium">
                          <Clock className="h-4 w-4" />
                          Pending
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      {/* Decision Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
        {isReviewerRole(role) && (
          <button
            onClick={() => handleDecision("cancel")}
            disabled={submitting}
            className="flex items-center gap-2 px-5 py-2.5 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 font-medium text-sm disabled:opacity-50"
          >
            <XCircle className="h-4 w-4" />
            Cancel
          </button>
        )}

        <div className="flex gap-3 ml-auto">
          {/* Reviewer roles submit their own review comment. */}
          {isReviewerRole(role) && (
            <button
              onClick={() => handleDecision("submit_review")}
              disabled={submitting}
              className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold disabled:opacity-50"
            >
              {submitting ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <CheckCircle className="h-5 w-5" />
              )}
              Submit Review
            </button>
          )}

          {/* Normal user completes the request or sends it on to CA/Legal
              review, based on what's selected in Review Configuration. */}
          {role === ROLES.NORMAL_USER &&
            request?.status == "REVIEW_NOT_STARTED" && (
              <button
                onClick={() => handleDecision("start_review")}
                disabled={submitting}
                className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold disabled:opacity-50"
              >
                {submitting ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <CheckCircle className="h-5 w-5" />
                )}
                {reviewDecisionLabel}
              </button>
            )}
        </div>
      </div>
    </div>
  );
}

export default HITLFinalReview;
