import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import {
  Brain,
  CheckCircle,
  Loader2,
  Upload,
  Link as LinkIcon,
  X,
  Edit2,
  AlertCircle,
  Info,
  Save,
} from "lucide-react";
import { getTemplate } from "../utils/templates";
import {
  createRequest,
  getRequest,
  getUploadUrl,
  uploadFileToS3,
  deleteFiles,
} from "../services/api";
import { useApp } from "../context/AppContext";
import ConfirmDialog from "./ui/ConfirmDialog";

const JURISDICTIONS = [
  "India",
  "Vietnam",
  "Thailand",
  "Bhutan",
  "Bangladesh",
  "Nepal",
];

const LANGUAGES = ["English", "Vietnamese", "Thai"];

// ─── 4 Pillars with Use Cases ─────────────────────────────────────────────
// const CATEGORIES = {
//   "Official PMI Submission": {
//     icon: "✉️",
//     description: "Content for formal letters on PMI letterhead for submissions to regulators, policymakers and government bodies",
//     useCases: [
//       "Submission (Govt, Regulator, Industry body)",
//       "Follow-up and representation",
//       "Others",
//     ],
//     keys: ["addressed_to", "cc_to", "topic_of_letter"],
//   },
//   "Third Party Submission": {
//     icon: "📄",
//     description: "Content for letters issued via external bodies, where PMI provides the core input or narrative",
//     useCases: [
//       "Point of view",
//       "White paper",
//       "Leave-behind notes",
//       "Product advocacy document",
//       "Others",
//     ],
//     keys: ["target_audience", "annexure"],
//   },
//   "White Papers": {
//     icon: "🤝",
//     description: "Long-form thought leadership including POVs, leave-behinds and research-driven documents for external stakeholders",
//     useCases: [
//       "Business updates",
//       "Communication on regulations",
//       "Parliamentary updates",
//       "Others",
//     ],
//     keys: ["target_audience"],
//   },
//   "Internal Communications": {
//     icon: "📰",
//     description: "Updates for PMI employees, including regulatory changes and parliamentary developments",
//     useCases: ["Campaigns", "Press releases", "Others"],
//     keys: ["target_audience"],
//   },
//   "Media Releases": {
//     icon: "📢",
//     description: "Press-ready content for media publication, including announcements, statements and official releases",
//     useCases: [
//       "Media interviews",
//       "Meeting prep",
//       "Panel discussions",
//       "Speeches",
//       "Others",
//     ],
//     keys: ["target_audience"],
//   },
//   "Narrative Builder": {
//     icon: "📢",
//     description: "Preparation material for interviews, meetings, panel discussions and speeches to support leadership engagement at external events",
//     useCases: [
//       "Media interviews",
//       "Meeting prep",
//       "Panel discussions",
//       "Speeches",
//       "Others",
//     ],
//     keys: ["target_audience"],
//   },
// };

const CATEGORIES = {
  "Official PMI Submission": {
    icon: "🏛️",
    description:
      "Content for formal letters on PMI letterhead for submissions to regulators, policymakers and government bodies",
    keys: ["addressed_to", "cc_to"],
  },
  "Third Party Submission": {
    icon: "🧾",
    description:
      "Content for letters issued via external bodies, where PMI provides the core input or narrative",
    keys: ["addressed_to", "cc_to"],
  },
  "White Papers": {
    icon: "📘",
    description:
      "Long-form thought leadership including POVs, leave-behinds and research-driven documents for external stakeholders",
    keys: ["annexure", "target_audience"],
  },
  "Internal Communications": {
    icon: "🏢",
    description:
      "Updates for PMI employees, including regulatory changes and parliamentary developments",
    keys: ["target_audience"],
  },
  "Media Releases": {
    icon: "📰",
    description:
      "Press-ready content for media publication, including announcements, statements and official releases",
    keys: [],
  },
  "Narrative Builder": {
    icon: "🎤",
    description:
      "Preparation material for interviews, meetings, panel discussions and speeches to support leadership engagement at external events",
    keys: ["target_audience"],
  },
};

const CATEGORY_KEYS = Object.keys(CATEGORIES);

const CATEGORY_KEY_SETS = {};

// Master list of every category-conditional field key used anywhere in the
// wizard (across all current AND legacy CATEGORIES definitions). Used to
// strip stray/orphaned fields — e.g. "topic_of_letter", which no longer
// belongs to any category's `keys` array but may still linger on a draft
// record loaded from the backend — regardless of which category they used
// to belong to.
const ALL_CONDITIONAL_KEYS = Array.from(
  new Set([
    ...Object.values(CATEGORIES).flatMap((c) => c.keys),
    "addressed_to",
    "cc_to",
    "topic_of_letter",
    "target_audience",
    "annexure",
  ]),
);

const OUTPUT_FILE_TYPES = ["Microsoft Word (.docx)"];
const steps = [
  { num: 1, label: "Category" },
  { num: 2, label: "Details" },
  { num: 3, label: "Context" },
  { num: 4, label: "Review & Submit" },
];

function NewRequest() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const {
    setDuplicateRequests,
    addToast,
    addRequest,
    updateRequest,
    setLoading,
    state,
  } = useApp();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [savingDraft, setSavingDraft] = useState(false);
  const [editingDraftId, setEditingDraftId] = useState(null);
  const [draftValuesChanged, setDraftValuesChanged] = useState(false);
  const [alertBoxData, setAlertBoxData] = useState({
    showAlert: false,
    title: null,
    message: null,
    confirmLabel: null,
    cancelLabel: null,
    variant: null,
    onConfirmMethod: null,
    onCancelMethod: null,
  });

  const [formData, setFormData] = useState({
    category: "",
    document_type: "",
    topic: "",
    jurisdiction: "",
    deadline: "",
    target_language: "English",
    output_file_type: "Microsoft Word (.docx)",
    background: "",
    stakeholders: "",
    priority: "high",
    tone_requirements:
      "Formal, neutral, compliance-first, fact-based and non-promotional",
  });

  const [topicTitle, setTopicTitle] = useState("");
  const [specificUrlTitle, setSpecificurl] = useState("");
  const [backgroundInformationTitle, setBackgroundInformationTitle] =
    useState("");

  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [uploadedFilesKeys, setUploadedFilesKeys] = useState([]);
  const [urls, setUrls] = useState([]);
  const [newUrl, setNewUrl] = useState("");
  const [isTemplateApplied, setIsTemplateApplied] = useState(false);
  const [errors, setErrors] = useState({});
  const [showAlertBox, setAlertBoxDisplay] = useState(false);
  const [showDuplicateAlert, setDuplicateAltert] = useState(false);
  const [duplicateRequest, setDuplicateRequest] = useState(null);

  // ─── Load Draft from Query Param ──────────────────────────────────────────
  // Only runs when opening an existing draft (i.e. a `draft` id is present
  // in the URL, as when navigating here from the Dashboard). A brand new
  // request (no `draft` param) leaves the form untouched.
  useEffect(() => {
    const draftId = searchParams.get("draft");
    if (!draftId) return;

    const applyDraftRequest = (draftRequest) => {
      if (!draftRequest || draftRequest.status !== "DRAFT") return;

      setEditingDraftId(draftId);
      setTitles(draftRequest.category);

      // Jump to last meaningful step
      let targetStep = 1;
      if (draftRequest.background) {
        targetStep = 4; // Review & Submit
      } else if (draftRequest.topic) {
        targetStep = 2; // Request Details
      } else if (draftRequest.category) {
        targetStep = 1;
      }
      // Auto-submit if ?submit=true
      if (searchParams.get("submit") === "true") {
        targetStep = 4;
      }

      setFormData((prev) => {
        const merged = { ...prev, ...draftRequest };

        // When the draft jumps straight past Step 1 (Category), the
        // category → field visibility rules normally enforced by
        // addRemoveRequestProperties() on the "Next" click from Step 1
        // never run. Enforce the same category-key rules here — minus the
        // destructive reset of already-loaded values — so only the fields
        // relevant to this draft's category are shown on later steps.
        if (
          targetStep !== 1 &&
          draftRequest.category &&
          CATEGORIES[draftRequest.category]
        ) {
          const allowedKeys = CATEGORIES[draftRequest.category].keys || [];
          ALL_CONDITIONAL_KEYS.forEach((key) => {
            if (!allowedKeys.includes(key)) {
              delete merged[key];
            }
          });
          allowedKeys.forEach((key) => {
            if (!(key in merged)) {
              merged[key] = "";
            }
          });
        }

        return merged;
      });

      // Restore previously uploaded files and reference URLs, which live
      // in component state rather than formData. Prefer the richer
      // uploadedFilesMetadata (file name + size) saved alongside the draft;
      // fall back to deriving a name from the S3 key for older drafts saved
      // before this metadata existed.
      if (
        Array.isArray(draftRequest.uploadedFilesMetadata) &&
        draftRequest.uploadedFilesMetadata.length > 0
      ) {
        setUploadedFiles(
          draftRequest.uploadedFilesMetadata.map((meta) => {
            const fileName =
              meta.file_name ||
              meta.file_key?.split("/").pop() ||
              meta.file_key;
            return {
              id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
              file_key: meta.file_key,
              file: { name: fileName, size: meta.file_size || 0 },
              isUploading: false,
              hasUploadedSuccessfully: true,
              uploadAttempted: true,
              file_name: fileName,
            };
          }),
        );
      } else if (
        Array.isArray(draftRequest.uploadedFileKeys) &&
        draftRequest.uploadedFileKeys.length > 0
      ) {
        setUploadedFiles(
          draftRequest.uploadedFileKeys.map((key) => {
            const fileName = key?.split("/").pop() || key;
            return {
              id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
              file_key: key,
              file: { name: fileName, size: 0 },
              isUploading: false,
              hasUploadedSuccessfully: true,
              uploadAttempted: true,
              file_name: fileName,
            };
          }),
        );
      }
      if (Array.isArray(draftRequest.urls) && draftRequest.urls.length > 0) {
        setUrls(draftRequest.urls);
      }

      setStep(targetStep);
      setIsTemplateApplied(true); // Prevent template from overwriting loaded draft
    };

    // Show whatever is already available locally (from the dashboard list)
    // right away, so the form isn't blank while the network call is in flight.
    const localDraftRequest = state.requests.find(
      (r) => r.request_id === draftId,
    );
    if (localDraftRequest) {
      applyDraftRequest(localDraftRequest);
    }

    // Fetch the full request record (same API used on the Request Details
    // page) so fields missing from the lightweight dashboard list get
    // populated too.
    (async () => {
      try {
        const fullDraftRequest = await getRequest(draftId);
        applyDraftRequest(fullDraftRequest);
      } catch (error) {
        // API unavailable — keep whatever was loaded from local state above.
      }
    })();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-populate form when use case changes
  useEffect(() => {
    if (formData.use_case && !isTemplateApplied) {
      // Try matching a template by use-case or derived document_type
      const template =
        getTemplate(formData.document_type) || getTemplate(formData.use_case);
      if (template) {
        setFormData((prev) => ({
          ...prev,
          ...template,
        }));
        setIsTemplateApplied(true);
      }
    }
    if (!formData.use_case) {
      setIsTemplateApplied(false);
    }
  }, [formData.use_case, formData.document_type, isTemplateApplied]);

  const validateStep = (currentStep) => {
    const newErrors = {};

    if (currentStep === 1) {
      if (!formData.category)
        newErrors.category = "Please select a document type";
    }

    if (currentStep === 2) {
      if (!formData.topic || formData.topic.length < 10) {
        newErrors.topic = "Topic/Subject must be at least 10 characters";
      }
      if (!formData.jurisdiction)
        newErrors.jurisdiction = "Jurisdiction is required";
      if ("addressed_to" in formData && !formData.addressed_to)
        newErrors.addressed_to = "Addressed to is required";
      if ("topic_of_letter" in formData && !formData.topic_of_letter)
        newErrors.topic_of_letter = "Topic of letter is required";
      if (!formData.deadline) newErrors.deadline = "Deadline is required";

      const deadlineDate = new Date(formData.deadline);
      const today = new Date();
      if (deadlineDate <= today) {
        newErrors.deadline = "Deadline must be in the future";
      }
    }

    if (currentStep === 3) {
      if (!formData.background || formData.background.length < 20) {
        newErrors.background =
          "Background information is required (min 20 characters)";
      }

      if (uploadedFiles.length > 0) {
        uploadedFiles.forEach((fileItem) => {
          if (
            (!fileItem.hasUploadedSuccessfully &&
              fileItem.uploadAttempted &&
              !fileItem.isUploading) ||
            fileItem.isUploading
          ) {
            newErrors.uploads =
              "Some files are still pending upload. Complete the upload to continue.";
          }
        });
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      if (step < 4) {
        if (step == 1) {
          addRemoveRequestProperties(formData.category);
        }
        setStep(step + 1);
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
      setErrors({});
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const deleteUploadedFiles = async (fileKey) => {
    return deleteFiles(fileKey);
  };

  const uploadSingleFile = async (index) => {
    const fileItem = uploadedFiles[index];
    try {
      setUploadedFiles((prev) => {
        return prev.map((item) => {
          if (item.id === fileItem.id) {
            return {
              ...item,
              isUploading: true,
            };
          }

          return item;
        });
      });
      const uploadedFileResponse = await uploadFileToS3(fileItem);
      if (uploadedFileResponse.success) {
        setUploadedFiles((prev) => {
          return prev.map((item) => {
            if (item.id === fileItem.id) {
              return {
                ...item,
                isUploading: false,
                hasUploadedSuccessfully: true,
                fileKey: uploadedFileResponse.key,
                uploadAttempted: true,
              };
            }

            return item;
          });
        });
      }
    } catch (error) {
      setUploadedFiles((prev) => {
        return prev.map((item) => {
          return item.id == fileItem.id
            ? {
                ...item,
                isUploading: false,
                hasUploadedSuccessfully: false,
                uploadAttempted: true,
              }
            : item;
        });
      });
    }
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    const maxSize = 10 * 1024 * 1024; // 10MB
    const validFiles = files.filter((f) => {
      if (f.size > maxSize) {
        addToast({
          type: "warning",
          message: `${f.name} exceeds 10MB limit and was skipped.`,
        });
        return false;
      }
      return true;
    });
    const fileItems = [];
    validFiles.forEach((file) => {
      const fileItem = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        file_key: "",
        file: file,
        isUploading: false,
        hasUploadedSuccessfully: false,
        uploadAttempted: false,
        file_name: file.name,
        file_type: file.type,
      };
      fileItems.push(fileItem);
    });
    if (fileItems.length > 0) {
      setUploadedFiles((prev) => [...prev, ...fileItems]);
    }
    for (const fileItem of fileItems) {
      try {
        fileItem.isUploading = true;
        const uploadedFileItem = await uploadFileToS3(fileItem);
        if (uploadedFileItem.file_key) {
          setUploadedFiles((prev) => {
            return prev.map((item) => {
              if (item.id === fileItem.id) {
                return {
                  ...item,
                  isUploading: false,
                  hasUploadedSuccessfully: true,
                  file_key: uploadedFileItem.file_key,
                  uploadAttempted: true,
                };
              }

              return item;
            });
          });
        }
      } catch (error) {
        setUploadedFiles((prev) => {
          return prev.map((item) => {
            return item.id == fileItem.id
              ? {
                  ...item,
                  isUploading: false,
                  hasUploadedSuccessfully: false,
                  uploadAttempted: true,
                }
              : item;
          });
        });
      }
    }
  };

  const removeFile = async (index) => {
    if (uploadedFiles[index].fileKey) {
      try {
        const response = await deleteUploadedFiles(
          uploadedFiles[index].fileKey,
        );
        if (response.success) {
          setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
        }
      } catch (error) {}
    } else {
      setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const addUrl = () => {
    if (newUrl && isValidUrl(newUrl)) {
      setUrls((prev) => [...prev, newUrl]);
      setNewUrl("");
    } else if (newUrl) {
      addToast({
        type: "warning",
        message: "Please enter a valid URL (http:// or https://)",
      });
    }
  };

  const removeUrl = (index) => {
    setUrls((prev) => prev.filter((_, i) => i !== index));
  };

  const isValidUrl = (string) => {
    try {
      const url = new URL(string);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch (_) {
      return false;
    }
  };

  const jumpToStep = (targetStep) => {
    setStep(targetStep);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSaveAsDraft = async () => {
    try {
      setSavingDraft(true);
      const draftObject = {
        ...formData,
        uploadedFileKeys: uploadedFiles.map((file) => file.file_key),
        uploadedFilesMetadata: uploadedFiles.map((file) => ({
          file_key: file.file_key,
          file_name: file.file_name || file.file?.name || "",
          file_size: file.file?.size ?? 0,
        })),
        urls: urls,
        isDraft: true,
        user_id: state.user.email,
        created_at: "",
        updated_at: "",
        completed_at: "",
        status: "submitted",
        progress: 0,
      };
      //delete draftObject["document_type"];
      const response = await createRequest(draftObject);
      setSavingDraft(false);
      addToast({
        type: "info",
        title: "Draft submitted!",
        message: `Your request "${formData.topic}" has been saved as a draft.`,
        duration: 6000,
      });
      if (editingDraftId) {
        updateRequest(draftObject);
      } else {
        addRequest(draftObject);
      }
      navigate("/");
    } catch (error) {
      setSavingDraft(false);
      addToast({
        type: "warning",
        title: "Error",
        message: JSON.stringify(error),
      });
    }
  };

  const handleSubmit = async (bypassDuplicateRequest) => {
    try {
      setIsSubmitting(true);
      const requestObject = {
        ...formData,
        uploadedFileKeys: uploadedFiles.map((file) => file.file_key),
        uploadedFilesMetadata: uploadedFiles.map((file) => ({
          file_key: file.file_key,
          file_name: file.file_name || file.file?.name || "",
          file_size: file.file?.size ?? 0,
        })),
        urls: urls,
        isSubmit: true,
        user_id: state.user.email,
        request_id: "NEW",
        created_at: "",
        updated_at: "",
        completed_at: "",
        bypass_duplicate_check: bypassDuplicateRequest,
        progress: 0,
        enable_topic_relevance_check: true,
      };

      //delete requestObject["document_type"];
      const response = await createRequest(requestObject);
      if (response?.status == "SIMILAR_REQUEST_EXISTS") {
        handleDuplicateAlert(response);
      } else if (response.status == "CANCELLED") {
        setAlertBoxData({
          showAlert: true,
          title: "Request Cancelled",
          message:
            "This request was cancelled due to an irrelevant topic/details entered. Please raise a new request with the correct details.",
          confirmLabel: "OK",
          cancelLabel: null,
          variant: "primary",
          onConfirmMethod: () => {
            cancelMethod();
          },
          onCancelMethod: null,
        });
        setIsSubmitting(false);
        setStep(1);
      } else if (response.status == "SUBMITTED") {
        setIsSubmitting(false);
        addToast({
          type: "info",
          title: "Request Submitted!",
          message: `Your request "${formData.topic}" has been submitted. Agents will begin processing shortly.`,
          duration: 6000,
        });
        const updatedRequestObject = {
          ...requestObject,
          ...response,
        };
        delete updatedRequestObject["message"];
        addRequest(updatedRequestObject);
        navigate("/");
      }
    } catch (error) {
      setIsSubmitting(false);
      addToast({
        type: "warning",
        title: "Error",
        message: JSON.stringify(error),
      });
    }
  };

  const handleDuplicateAlert = (response) => {
    setIsSubmitting(false);
    setDuplicateRequest(response?.existing_requests[0]);
    setAlertBoxData({
      showAlert: true,
      title: "Duplicate Request",
      message:
        "It looks like a similar request already exists. Submitting another may create duplicates. Would you like to continue anyway?",
      confirmLabel: "Submit Anyway",
      cancelLabel: "Review Existing Request",
      variant: "danger",
      onConfirmMethod: () => {
        cancelMethod();
        handleSubmit(true);
      },
      onCancelMethod: () => {
        cancelMethod();
        setDuplicateRequests(duplicateRequest);
        navigate(`/request/${duplicateRequest?.request_id}`, {
          state: { isDuplicate: true },
        });
      },
    });
  };

  const handleDialogConfirmation = () => {
    if (uploadedFiles.length > 0) {
      for (let i = 0; i < uploadedFiles.length; i++) {
        removeFile(index);
      }
    }
    navigate("/");
  };

  function setTitles(docType) {
    switch (docType) {
      case "Third Party Submission":
      case "Official PMI Submission":
        setTopicTitle("Subject");
        setBackgroundInformationTitle(
          "Background and reference information (Please provide a brief context for generating this letter along with a  profile of target audience and their interests/ concerns)",
        );
        setSpecificurl(
          "Specify any specific URLs you want agent to search (Optional)",
        );
        break;
      case "White Papers":
        setTopicTitle("Topic");
        setBackgroundInformationTitle(
          "Background and reference information (Please provide a brief context of generating this document along with  information on main sections you want to have in the document)",
        );
        setSpecificurl(
          "Specify any specific URLs you you want agent to search (Optional)",
        );
        break;
      case "Internal Communications":
        setTopicTitle("Subject");
        setBackgroundInformationTitle(
          "Background and reference information (Please provide a brief context of generating this content)",
        );
        setSpecificurl("Specify any specific URLs you have in mind (Optional)");
        break;
      case "Media Releases":
        setTopicTitle("Topic");
        setBackgroundInformationTitle(
          "Background and reference information (Please provide a brief context of generating this content)",
        );
        setSpecificurl("Specify any specific URLs you have in mind (Optional)");
        break;
      case "Narrative Builder":
        setTopicTitle("Topic");
        setBackgroundInformationTitle(
          "Background and reference information (Please provide a brief context of generating this content along with a profile of target audience and their interests/ concerns as per your knowledge)",
        );
        setSpecificurl("Specify any specific URLs you have in mind (Optional)");
        break;
    }
  }

  function addRemoveRequestProperties(docType) {
    // if (!draftValuesChanged && editingDraftId) {
    //   return;
    // }
    setTitles(docType);
    const newFormData = structuredClone(formData);

    const allowedKeys = CATEGORIES[docType]?.keys || [];
    ALL_CONDITIONAL_KEYS.forEach((key) => {
      if (!allowedKeys.includes(key)) {
        delete newFormData[key];
      }
    });

    allowedKeys.forEach((key) => {
      newFormData[key] = "";
    });

    for (let key in newFormData) {
      if (
        key != "target_language" &&
        key != "output_file_type" &&
        key != "priority" &&
        key != "tone_requirements" &&
        key != "category" &&
        key != "use_case" &&
        key != "others"
      ) {
        newFormData[key] = "";
      }
    }

    setFormData(newFormData);
  }

  function addRemoveOthers(useCase) {
    const tempFormData = {
      ...formData,
      use_case: useCase,
      document_type: `${formData.category} – ${useCase}`,
    };
    if (useCase.toLowerCase() == "others") {
      tempFormData["others"] = "";
    } else {
      delete tempFormData["others"];
    }
    setFormData(tempFormData);
  }

  const cancelMethod = () => {
    setAlertBoxData({
      showAlert: false,
      title: null,
      message: null,
      confirmLabel: null,
      cancelLabel: null,
      variant: null,
      onConfirmMethod: null,
      onCancelMethod: null,
    });
  };

  return (
    <div className="w-full px-8 py-8">
      <ConfirmDialog
        open={alertBoxData?.showAlert}
        title={alertBoxData?.title}
        message={alertBoxData?.message}
        confirmLabel={alertBoxData?.confirmLabel}
        cancelLabel={alertBoxData?.cancelLabel}
        variant={alertBoxData?.variant}
        onConfirm={() => {
          alertBoxData?.onConfirmMethod();
        }}
        onCancel={() => {
          alertBoxData?.onCancelMethod();
        }}
      />

      {/* Page Title */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">New Request</h1>
        <p className="text-gray-600">Submit a new content request.</p>
      </div>

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-start">
          {steps.map((s, i, arr) => (
            <div key={s.num} className="flex items-start flex-1 last:flex-none">
              <div className="flex flex-col items-center">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full border-2 font-semibold text-sm ${
                    s.num < step
                      ? "bg-green-500 border-green-500 text-white"
                      : s.num === step
                        ? "bg-pmi-blue border-pmi-blue text-white"
                        : "bg-white border-gray-300 text-gray-400"
                  }`}
                >
                  {s.num < step ? <CheckCircle className="h-6 w-6" /> : s.num}
                </div>

                <span
                  className={`mt-2 text-xs font-medium whitespace-nowrap ${
                    s.num < step
                      ? "text-green-600"
                      : s.num === step
                        ? "text-pmi-blue"
                        : "text-gray-400"
                  }`}
                >
                  {s.label}
                </span>
              </div>

              {i < arr.length - 1 && (
                <div className="flex-1 pt-5 px-3">
                  <div
                    className={`h-0.5 w-full ${
                      s.num < step ? "bg-green-500" : "bg-gray-300"
                    }`}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Form Card */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        {/* Step 1: Category & Use Case */}
        {step === 1 && (
          <div>
            {/* Category Selection */}
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Select Content Type
            </h2>
            <p className="text-gray-500 text-sm mb-5">
              Choose the content type that best fits your request
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {CATEGORY_KEYS.map((cat) => {
                const { icon, description } = CATEGORIES[cat];
                const isSelected = formData.category === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      setFormData((prev) => ({
                        ...prev,
                        category: cat,
                        use_case: "", // reset when category changes
                        document_type: "",
                      }));
                      if (editingDraftId) {
                        setDraftValuesChanged(true);
                      }
                      setIsTemplateApplied(false);
                    }}
                    className={`flex items-start gap-3 p-4 border-2 rounded-lg text-left transition-all ${
                      isSelected
                        ? "border-pmi-blue bg-blue-50 ring-1 ring-pmi-blue/30"
                        : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    <span className="text-2xl mt-0.5">{icon}</span>
                    <div>
                      <p
                        className={`font-semibold ${
                          isSelected ? "text-pmi-blue" : "text-gray-900"
                        }`}
                      >
                        {cat}
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
            {errors.category && (
              <p className="mb-4 text-sm text-red-600 flex items-center gap-1">
                <AlertCircle className="h-4 w-4" /> {errors.category}
              </p>
            )}

            {/* {formData.category &&
              CATEGORIES[formData.category]["useCases"].length > 0 && (
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    Select Use Case
                  </h2>
                  <p className="text-gray-500 text-sm mb-4">
                    Choose the specific use case under{" "}
                    <span className="font-medium text-gray-700">
                      {formData.category}
                    </span>
                  </p>

                  <div className="space-y-2">
                    {CATEGORIES[formData.category].useCases.map((uc) => {
                      const isSelected = formData.use_case === uc;
                      return (
                        <label
                          key={uc}
                          className={`flex items-center p-3.5 border-2 rounded-lg cursor-pointer transition-all ${isSelected
                            ? "border-pmi-blue bg-blue-50"
                            : "border-gray-200 hover:border-gray-300"
                            }`}
                        >
                          <input
                            type="radio"
                            name="use_case"
                            value={uc}
                            checked={isSelected}
                            onChange={(e) => {
                              const selected = e.target.value;
                              addRemoveOthers(selected);
                              setIsTemplateApplied(false);
                            }}
                            className="h-4 w-4 text-pmi-blue flex-shrink-0 focus:outline-none"
                          />
                          <span className="ml-3 text-sm font-medium text-gray-900">
                            {uc}
                          </span>
                        </label>
                      );
                    })}
                  </div>
                  {errors.use_case && (
                    <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                      <AlertCircle className="h-4 w-4" /> {errors.use_case}
                    </p>
                  )}
                </div>
              )} */}
            {/* {"others" in formData && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Please specify use case{" "}
                  <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.others}
                  onChange={(e) =>
                    setFormData({ ...formData, others: e.target.value })
                  }
                  placeholder=""
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.others ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                />
                {errors.others && (
                  <p className="mt-1 text-sm text-red-600">{errors.others}</p>
                )}
              </div>
            )} */}
          </div>
        )}

        {/* Step 2: Details */}
        {step === 2 && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              Request Details
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {topicTitle} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.topic}
                  onChange={(e) =>
                    setFormData({ ...formData, topic: e.target.value })
                  }
                  placeholder="e.g., Government submission on anticipated excise rule changes for heated tobacco products"
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.topic ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                />
                {errors.topic && (
                  <p className="mt-1 text-sm text-red-600">{errors.topic}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Jurisdiction <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.jurisdiction}
                  onChange={(e) =>
                    setFormData({ ...formData, jurisdiction: e.target.value })
                  }
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.jurisdiction ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                >
                  <option value="">Select jurisdiction...</option>
                  {JURISDICTIONS.map((j) => (
                    <option key={j} value={j}>
                      {j}
                    </option>
                  ))}
                </select>
                {errors.jurisdiction && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.jurisdiction}
                  </p>
                )}
              </div>

              {/* <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Jurisdiction <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.jurisdiction}
                    onChange={(e) =>
                      setFormData({ ...formData, jurisdiction: e.target.value })
                    }
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.jurisdiction ? "border-red-300" : "border-gray-300"}`}
                  >
                    <option value="">Select jurisdiction...</option>
                    {JURISDICTIONS.map((j) => (
                      <option key={j} value={j}>
                        {j}
                      </option>
                    ))}
                  </select>
                  {errors.jurisdiction && (
                    <p className="mt-1 text-sm text-red-600">
                      {errors.jurisdiction}
                    </p>
                  )}
                </div>

                {formData.targetAudience && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Target Audience <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.targetAudience}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          targetAudience: e.target.value,
                        })
                      }
                      placeholder="e.g., Ministry of Health & Family Welfare, CBIC, Parliamentary Standing Committee"
                      className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.targetAudience ? "border-red-300" : "border-gray-300"}`}
                    />
                    {errors.targetAudience && (
                      <p className="mt-1 text-sm text-red-600">
                        {errors.targetAudience}
                      </p>
                    )}
                  </div>
                )}
              </div> */}

              {"target_audience" in formData && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Recipient
                  </label>
                  <input
                    type="text"
                    value={formData.target_audience}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        target_audience: e.target.value,
                      })
                    }
                    placeholder="e.g., Ministry of Health & Family Welfare, CBIC, Parliamentary Standing Committee"
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.target_audience ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                  />
                  {errors.target_audience && (
                    <p className="mt-1 text-sm text-red-600">
                      {errors.target_audience}
                    </p>
                  )}
                </div>
              )}

              {"addressed_to" in formData && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Addressed To <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.addressed_to}
                    onChange={(e) =>
                      setFormData({ ...formData, addressed_to: e.target.value })
                    }
                    placeholder="e.g. Ministry of Health"
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.addressed_to ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                  />
                  {errors.addressed_to && (
                    <p className="mt-1 text-sm text-red-600">
                      {errors.addressed_to}
                    </p>
                  )}
                </div>
              )}

              {"cc_to" in formData && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    CC
                  </label>
                  <input
                    type="text"
                    value={formData.cc_to}
                    onChange={(e) =>
                      setFormData({ ...formData, cc_to: e.target.value })
                    }
                    placeholder="e.g. Department of Health & Family Welfare"
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.cc_to ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                  />
                  {errors.cc_to && (
                    <p className="mt-1 text-sm text-red-600">{errors.cc_to}</p>
                  )}
                </div>
              )}

              {"topic_of_letter" in formData && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Topic of letter
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.topic_of_letter}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        topic_of_letter: e.target.value,
                      })
                    }
                    placeholder="e.g. Excise duty structure, Tobacco control measures, Product regulations"
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.topic_of_letter ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                  />
                  {errors.topic_of_letter && (
                    <p className="mt-1 text-sm text-red-600">
                      {errors.topic_of_letter}
                    </p>
                  )}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Deadline <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={formData.deadline}
                  min={new Date().toISOString().split("T")[0]}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      deadline: e.target.value,
                    })
                  }
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.deadline ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                />
                {errors.deadline && (
                  <p className="mt-1 text-sm text-red-600">{errors.deadline}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Context */}
        {step === 3 && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              Additional Context & Requirements
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {backgroundInformationTitle}{" "}
                  <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={formData.background}
                  onChange={(e) =>
                    setFormData({ ...formData, background: e.target.value })
                  }
                  placeholder="Provide context: relevant gazette notifications, consultation documents, anticipated regulatory changes..."
                  rows={5}
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.background ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                />
                {errors.background && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.background}
                  </p>
                )}
              </div>

              {"annexure" in formData && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Annexures (Please provide information on what annexures are
                    needed)
                  </label>
                  <input
                    type="text"
                    value={formData.annexure}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        annexure: e.target.value,
                      })
                    }
                    placeholder=""
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent ${errors.annexure ? "border-red-300" : "border-gray-300"} focus:outline-none`}
                  />
                </div>
              )}

              {/* <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Specific sources to look for information (Optional)
                </label>
                <textarea
                  value={formData.sources}
                  onChange={(e) =>
                    setFormData({ ...formData, sources: e.target.value })
                  }
                  placeholder="e.g., WHO TobReg, CBIC website, MoHFW notifications..."
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Default sources: PMI SharePoint, WHO, CBIC, MoHFW, NTCP, PIB,
                  PubMed, Scopus, Lancet, BMJ
                </p>
              </div> */}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Key stakeholders (Optional)
                </label>
                <input
                  type="text"
                  value={formData.stakeholders}
                  onChange={(e) =>
                    setFormData({ ...formData, stakeholders: e.target.value })
                  }
                  placeholder="e.g., Ministry officials, Parliamentary members, Industry associations"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tone and language requirements (Optional)
                </label>
                <textarea
                  value={formData.tone_requirements}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      tone_requirements: e.target.value,
                    })
                  }
                  rows={2}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Target Language
                </label>
                <select
                  value={formData.target_language}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      target_language: e.target.value,
                    })
                  }
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none`}
                >
                  <option value="">Select target language...</option>
                  {LANGUAGES.map((j) => (
                    <option key={j} value={j}>
                      {j}
                    </option>
                  ))}
                </select>
              </div>

              {/* Business Rules Info Box */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="text-sm font-semibold text-blue-900 mb-2">
                  📋 Business Rules Applied Automatically:
                </h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>
                    ✓ All assertions will carry citations + snapshot dates
                  </li>
                  <li>✓ No youth-targeted or misleading health claims</li>
                  <li>
                    ✓ Statutory warnings and mandatory disclaimers included
                  </li>
                  <li>
                    ✓ Legal/Compliance HITL approval required before submission
                  </li>
                  <li>✓ Jurisdiction tagging and applicability dates</li>
                </ul>
              </div>

              {/* File Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Upload className="h-4 w-4 inline mr-1" />
                  Upload Supporting Documents (Optional)
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-pmi-blue transition-colors">
                  <input
                    type="file"
                    multiple
                    accept=".pdf,.docx,.xlsx,.jpg,.png,.pptx"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                    <p className="text-sm text-gray-600">
                      Click to upload or drag and drop
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      PDF, Word, Excel, PowerPoint, Images (Max 10MB each)
                    </p>
                  </label>
                </div>
                {true && (
                  <div className="mt-3 space-y-2">
                    {uploadedFiles?.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded-lg"
                      >
                        <span className="text-sm text-gray-700 flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          {file.file.name} ({(file.file.size / 1024).toFixed(1)}{" "}
                          KB)
                        </span>
                        <div className="flex items-center justify-center gap-4">
                          {!file.hasUploadedSuccessfully &&
                            file.uploadAttempted &&
                            !file.isUploading && (
                              <button
                                onClick={() => uploadSingleFile(index)}
                                className="text-red-500 hover:text-red-700"
                              >
                                Retry
                              </button>
                            )}
                          {file.uploadAttempted && !file.isUploading && (
                            <button
                              onClick={() => removeFile(index)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          )}
                          {file.isUploading && (
                            <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                {errors.uploads && (
                  <p className="mt-1 text-sm text-red-600">{errors.uploads}</p>
                )}
              </div>

              {/* URL References */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <LinkIcon className="h-4 w-4 inline mr-1" />
                  {specificUrlTitle}
                </label>
                <div className="flex space-x-2">
                  <input
                    type="url"
                    value={newUrl}
                    onChange={(e) => setNewUrl(e.target.value)}
                    onKeyDown={(e) =>
                      e.key === "Enter" && (e.preventDefault(), addUrl())
                    }
                    placeholder="https://cbic.gov.in/resources/..."
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
                  />
                  <button
                    onClick={addUrl}
                    disabled={!isValidUrl(newUrl)}
                    className="px-4 py-2 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy disabled:bg-gray-300 disabled:cursor-not-allowed"
                  >
                    Add
                  </button>
                </div>
                {urls.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {urls.map((url, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded-lg"
                      >
                        <a
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-pmi-blue hover:underline flex items-center truncate mr-2"
                        >
                          <LinkIcon className="h-4 w-4 mr-2 flex-shrink-0" />
                          {url}
                        </a>
                        <button
                          onClick={() => removeUrl(index)}
                          className="text-red-500 hover:text-red-700 flex-shrink-0"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Review & Submit */}
        {step === 4 && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Review & Submit
            </h2>
            <p className="text-gray-600 mb-6">
              Review all details before submitting. Click Edit to make changes.
            </p>

            <div className="space-y-6">
              {/* Category & Use Case */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-md font-semibold text-gray-900">
                    Content Type
                  </h3>
                  <button
                    onClick={() => jumpToStep(1)}
                    className="flex items-center text-sm text-pmi-blue hover:text-pmi-navy"
                  >
                    <Edit2 className="h-4 w-4 mr-1" /> Edit
                  </button>
                </div>
                <div className="space-y-2">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Content Type
                    </p>
                    <p className="text-gray-900 font-medium flex items-center gap-2">
                      <span>{CATEGORIES[formData.category]?.icon}</span>
                      {formData.category}
                    </p>
                  </div>
                  {/* <div>
                    <p className="text-sm font-medium text-gray-600">
                      Use Case
                    </p>
                    <p className="text-gray-900">{formData.use_case}</p>
                  </div> */}
                  {/* {"others" in formData && (
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Others
                      </p>
                      <p className="text-gray-900">{formData.others}</p>
                    </div>
                  )} */}
                </div>
              </div>

              {/* Details */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-md font-semibold text-gray-900">
                    Request Details
                  </h3>
                  <button
                    onClick={() => jumpToStep(2)}
                    className="flex items-center text-sm text-pmi-blue hover:text-pmi-navy"
                  >
                    <Edit2 className="h-4 w-4 mr-1" /> Edit
                  </button>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {topicTitle}
                    </p>
                    <p className="text-gray-900">{formData.topic}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Jurisdiction
                      </p>
                      <p className="text-gray-900">{formData.jurisdiction}</p>
                    </div>
                    {"target_audience" in formData && (
                      <div>
                        <p className="text-sm font-medium text-gray-600">
                          Recipient
                        </p>
                        <p className="text-gray-900">
                          {formData.target_audience}
                        </p>
                      </div>
                    )}
                  </div>
                  {"cc_to" in formData && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-gray-600">
                          Addressed To
                        </p>
                        <p className="text-gray-900">{formData.addressed_to}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-600">CC</p>
                        <p className="text-gray-900">{formData.cc_to}</p>
                      </div>
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-4">
                    {"topic_of_letter" in formData && (
                      <div>
                        <p className="text-sm font-medium text-gray-600">
                          Topic of letter
                        </p>
                        <p className="text-gray-900">
                          {formData.topic_of_letter}
                        </p>
                      </div>
                    )}
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Deadline
                      </p>
                      <p className="text-gray-900">
                        {formData.deadline
                          ? new Date(formData.deadline).toLocaleDateString()
                          : "—"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Context */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-md font-semibold text-gray-900">
                    Context & Requirements
                  </h3>
                  <button
                    onClick={() => jumpToStep(3)}
                    className="flex items-center text-sm text-pmi-blue hover:text-pmi-navy"
                  >
                    <Edit2 className="h-4 w-4 mr-1" /> Edit
                  </button>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Background
                    </p>
                    <p className="text-gray-900 text-sm">
                      {formData.background}
                    </p>
                  </div>
                  {"annexures" in formData && (
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Annexures
                      </p>
                      <p className="text-gray-900 text-sm">
                        {formData.annexures}
                      </p>
                    </div>
                  )}
                  {formData.sources && (
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Sources
                      </p>
                      <p className="text-gray-900 text-sm whitespace-pre-line">
                        {formData.sources}
                      </p>
                    </div>
                  )}
                  {formData.stakeholders && (
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Stakeholders
                      </p>
                      <p className="text-gray-900">{formData.stakeholders}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Tone Requirements
                    </p>
                    <p className="text-gray-900 text-sm">
                      {formData.tone_requirements}
                    </p>
                  </div>
                  {formData?.target_language && (
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Target Language
                      </p>
                      <p className="text-gray-900 text-sm">
                        {formData?.target_language}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Uploaded Files */}
              {uploadedFiles.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-md font-semibold text-gray-900 mb-2">
                    Uploaded Files ({uploadedFiles.length})
                  </h3>
                  <div className="space-y-1">
                    {uploadedFiles.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center text-sm text-gray-700"
                      >
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        {file.file.name} ({(file.file.size / 1024).toFixed(1)}{" "}
                        KB)
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Reference URLs */}
              {urls.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-md font-semibold text-gray-900 mb-2">
                    Reference URLs ({urls.length})
                  </h3>
                  <div className="space-y-1">
                    {urls.map((url, index) => (
                      <a
                        key={index}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-sm text-pmi-blue hover:underline"
                      >
                        <LinkIcon className="h-4 w-4 mr-2 flex-shrink-0" />
                        {url}
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* What Happens Next */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start">
                  <Info className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-blue-900">
                    <p className="font-semibold mb-1">What happens next?</p>
                    <ul className="space-y-1 ml-4 list-disc">
                      <li>
                        <strong>Save as Draft</strong> — Saves your request for
                        later editing (no AI flow triggered)
                      </li>
                      <li>
                        <strong>Submit</strong> — Kicks off the AI flow.
                        Following steps will be followed:
                      </li>
                      <li className="ml-4">
                        Input Validator verifies your request inputs. You will
                        be informed if it is a duplicate request
                      </li>
                      <li className="ml-4">
                        Master Researcher gathers evidence →{" "}
                        <em>Evidence presented to you for review</em>
                      </li>
                      <li className="ml-4">
                        Master Drafter creates the document →{" "}
                        <em>Draft presented to you for review and download</em>
                      </li>
                      <li className="ml-4">
                        Estimated time for research: 8-10 minutes
                      </li>
                      <li className="ml-4">
                        Post research approval by you, estimated time for
                        document drafting: 4-5 minutes{" "}
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
          <button
            onClick={handleBack}
            disabled={step === 1}
            className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Back
          </button>
          {step == 4 && (
            <div className="flex gap-3">
              <button
                onClick={handleSaveAsDraft}
                disabled={isSubmitting || savingDraft}
                className="flex items-center justify-center px-6 py-2 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {savingDraft ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Saving as draft...
                  </>
                ) : (
                  <>
                    <Save className="h-5 w-5 mr-2" />
                    Save as Draft
                  </>
                )}
              </button>
              <button
                onClick={() => {
                  handleSubmit(false);
                }}
                disabled={isSubmitting || savingDraft}
                className="flex items-center justify-center px-6 py-2 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Submitting Request...
                  </>
                ) : (
                  <>
                    <Brain className="h-5 w-5 mr-2" />
                    Submit
                  </>
                )}
              </button>
            </div>
          )}
          <div>
            <button
              onClick={() =>
                setAlertBoxData({
                  showAlert: true,
                  title: "Unsaved Changes",
                  message:
                    "Do you want to cancel? Any unsaved data will be lost.",
                  confirmLabel: "Yes, Cancel",
                  cancelLabel: "Continue with request",
                  variant: "danger",
                  onConfirmMethod: handleDialogConfirmation,
                  onCancelMethod: cancelMethod,
                })
              }
              className="mx-2 px-6 py-2 border border-red-500 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              Cancel
            </button>
            {step < 4 && (
              <button
                onClick={handleNext}
                className="px-6 py-2 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy"
              >
                Next
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default NewRequest;
