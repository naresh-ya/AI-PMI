import { useCallback, useEffect, useRef, useState } from "react";
import {
  FileSignature,
  Upload,
  Download,
  Trash2,
  FileText,
  Loader2,
  AlertCircle,
  RotateCcw,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import {    
  deleteSignedDocuments,
  downloadSignedDocuments,
  getSignedDocuments,
  uploadSignedDocument,
} from "../services/api";
import ConfirmDialog from "./ui/ConfirmDialog";
import LoadingSpinner from "./ui/LoadingSpinner";

// Normalizes one entry from getSignedDocuments() into the row shape this
// table renders. Confirmed response shape:
//   {
//     user_email: "...",
//     count: 1,
//     files: [
//       { s3_key, file_name, stored_name, size, last_modified, etag }
//     ],
//     next_token: null,
//     is_truncated: false
//   }
// `uploadedByDisplay` lets the caller show the current user's display name
// (from AppContext) instead of the raw email the API itself returns, so
// this column reads the same for a document loaded from the list as it does
// for one just uploaded this session (see addFiles below).
//
// NOTE: pagination (`next_token` / `is_truncated`) isn't handled yet — only
// the first page the API returns is loaded.
function normalizeSignedDocument(doc, uploadedByDisplay) {
  return {
    id: doc?.s3_key || `doc-${crypto.randomUUID()}`,
    name: doc?.file_name || doc?.stored_name || "Untitled document",
    size: doc?.size ?? 0,
    uploadedBy: uploadedByDisplay || "—",
    uploadedAt: doc?.last_modified ? new Date(doc.last_modified) : null,
    // The list endpoint returns `s3_key`, not a ready-to-use URL — Download
    // for these rows fetches a real URL on click via
    // downloadSignedDocuments() (see handleDownload).
    fileKey: doc?.s3_key || "",
    etag: doc?.etag || "",
    status: "uploaded",
  };
}

function normalizeSignedDocumentsResponse(response, uploadedByDisplay) {
  const rawList = Array.isArray(response?.files) ? response.files : [];
  return rawList.map((doc) =>
    normalizeSignedDocument(doc, uploadedByDisplay || response?.user_email),
  );
}

// Pulls a usable URL for one document out of downloadSignedDocuments()'s
// response. Its exact shape isn't pinned down (only the request payload was
// specified), so this checks several plausible shapes: a single URL string,
// an object keyed by s3_key, or an array of { s3_key, download_url } /
// { s3_key, url } entries.
function extractSignedDocumentDownloadUrl(response, s3Key) {
  if (typeof response === "string") return response;
  if (response?.download_url && !response?.files && !response?.urls) {
    return response.download_url;
  }
  if (response?.urls?.[s3Key]) return response.urls[s3Key];
  const entries = Array.isArray(response)
    ? response
    : response?.files || response?.downloads || [];
  const match = entries.find((entry) => entry?.s3_key === s3Key);
  return match?.download_url || match?.url || "";
}

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB — matches NewRequest's upload limit
const ACCEPTED_FILE_TYPES = ".pdf,.doc,.docx,.jpg,.jpeg,.png";

function formatFileSize(bytes) {
  if (!bytes) return "—";
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  return `${value.toFixed(unitIndex > 0 && value < 10 ? 1 : 0)} ${units[unitIndex]}`;
}

function formatUploadedAt(date) {
  if (!date || Number.isNaN(date.getTime())) return "—";
  return `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

/**
 * SignedDocuments
 * ---------------------------------------------------------------------------
 * A SharePoint-style document list: an "Upload File" button top-right of the
 * table (opens the native file picker — no drag-and-drop dropzone) above a
 * table of documents, each row with Download/Delete actions on the right.
 * Empty state keeps the table header visible and shows "No documents" in the
 * body.
 *
 * Uploading is real: each selected file is sent via uploadSignedDocument()
 * (api.js), which calls getSignedDocumentUploadUrl() —
 * POST https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents/upload-url
 * with { user_email, file_name, file_type, file_size } — to get a presigned
 * URL, then PUTs the file straight to S3. Each row shows its own upload
 * state (uploading / failed-with-retry) independently, so one failure
 * doesn't block the others.
 *
 * On mount, the list is loaded for real via getSignedDocuments(userEmail) —
 * GET https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents?user_email=<email>
 * — merged with any documents uploaded earlier this session (so a document
 * that isn't in the backend response yet, e.g. one still "uploading" or one
 * the LIST endpoint hasn't caught up with, doesn't disappear from the
 * table).
 *
 * Deleting is real too: confirming the ConfirmDialog calls
 * deleteSignedDocuments(user_email, [s3_key]) —
 * DELETE https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents
 * with { user_email, s3_keys: [...] } — and on success re-fetches the list
 * (fetchDocuments) so the table reflects the backend's own state afterward.
 * A row whose upload never succeeded (no `fileKey` yet) skips the API call
 * and is just removed locally, since the backend has no record of it to
 * delete.
 *
 * Downloading is real too: clicking Download on a row uses its local
 * object URL when one exists (documents uploaded this session — instant,
 * no network round-trip needed), and otherwise calls
 * downloadSignedDocuments(user_email, [s3_key]) —
 * POST https://p3e6nk579c.execute-api.eu-west-1.amazonaws.com/dev/signed-documents/download
 * with { user_email, s3_keys: [...] } — to get a download URL for
 * documents loaded from the list, which only have an `s3_key` (see
 * normalizeSignedDocument), then triggers a real browser navigation to
 * that URL (not fetch()+blob, to sidestep needing CORS on wherever the
 * download URL points — same approach used for the draft-download flow in
 * ChatDraftForm).
 */
function SignedDocuments() {
  const { state, addToast } = useApp();
  const { user } = state;

  const [documents, setDocuments] = useState([]);
  const [documentsLoading, setDocumentsLoading] = useState(true);
  const [documentsLoadError, setDocumentsLoadError] = useState(false);
  const [documentPendingDelete, setDocumentPendingDelete] = useState(null);
  const [deletingDocument, setDeletingDocument] = useState(false);
  // The files picked from the native file input, held here (as a plain
  // array — NOT the input's own live FileList, see handleFileInputChange's
  // comment for why) while the "Is this document or generated draft
  // signed?" dialog is open (see handleFileInputChange/handleSignedChoice)
  // — upload doesn't start until the user answers.
  const [pendingUploadFiles, setPendingUploadFiles] = useState(null);
  // Tracks which row(s) currently have a downloadSignedDocuments() call in
  // flight, keyed by document id — a Set so multiple rows can download
  // independently without fighting over a single boolean.
  const [downloadingDocIds, setDownloadingDocIds] = useState(() => new Set());
  const fileInputRef = useRef(null);

  // Tracks every object URL ever created (not just the currently-listed
  // ones) so the unmount cleanup below can revoke all of them — a plain
  // `documents` dependency would only see whatever was in state the moment
  // the effect was set up.
  const objectUrlsRef = useRef([]);
  useEffect(() => {
    return () => {
      objectUrlsRef.current.forEach((url) => URL.revokeObjectURL(url));
    };
  }, []);

  // Loads the user's previously-uploaded signed documents on mount. Merges
  // into (rather than replaces) current state so anything uploaded earlier
  // this session — which may not exist in the backend response yet, e.g.
  // still "uploading" — isn't dropped by this refresh.
  const fetchDocuments = useCallback(async () => {
    if (!user?.email) {
      setDocumentsLoading(false);
      return;
    }
    setDocumentsLoading(true);
    setDocumentsLoadError(false);
    try {
      const response = await getSignedDocuments(user.email);
      const loadedDocuments = normalizeSignedDocumentsResponse(
        response,
        user?.name,
      );
      setDocuments((prev) => {
        const sessionOnly = prev.filter(
          (localDoc) =>
            !loadedDocuments.some(
              (loadedDoc) =>
                loadedDoc.id === localDoc.id ||
                (loadedDoc.fileKey && loadedDoc.fileKey === localDoc.fileKey),
            ),
        );
        return [...sessionOnly, ...loadedDocuments];
      });
    } catch (error) {
      console.log(error);
      setDocumentsLoadError(true);
    } finally {
      setDocumentsLoading(false);
    }
  }, [user?.email]);

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);

  // Uploads a single file via uploadSignedDocument() and updates just that
  // row's status in place — kept separate from addFiles so a failed upload
  // can be retried (re-runs this for the same row) without re-selecting the
  // file or disturbing any other in-flight uploads. `isSigned` is the
  // answer to the "Is this document or generated draft signed?" dialog
  // shown before upload (see handleSignedChoice) — stored on the row
  // itself so a retry (handleRetryUpload) reuses the same answer without
  // asking again.
  const uploadDocument = async (docId, file, isSigned) => {
    setDocuments((prev) =>
      prev.map((d) =>
        d.id === docId ? { ...d, status: "uploading", error: false } : d,
      ),
    );
    try {
      const uploadResult = await uploadSignedDocument(
        {
          file,
          file_name: file.name,
          file_type: file.type,
        },
        user?.email,
        isSigned,
      );
      if (!uploadResult?.upload_url) {
        throw new Error("Upload did not return a valid result");
      }
      setDocuments((prev) =>
        prev.map((d) =>
          d.id === docId
            ? {
                ...d,
                status: "uploaded",
                fileKey: uploadResult.file_key || uploadResult.key || "",
              }
            : d,
        ),
      );
      addToast({ type: "success", message: `${file.name} uploaded.` });
    } catch (error) {
      console.log(error);
      setDocuments((prev) =>
        prev.map((d) => (d.id === docId ? { ...d, status: "error" } : d)),
      );
      addToast({
        type: "warning",
        message: `Failed to upload ${file.name}. Please try again.`,
      });
    }
  };

  // `isSigned` — the answer to the "Is this document or generated draft
  // signed?" dialog (see handleFileInputChange/handleSignedChoice below) —
  // is applied to every file in this batch and stored on each row (used by
  // handleRetryUpload, and by uploadDocument to pass along `is_signed` on
  // the API call).
  const addFiles = (fileList, isSigned) => {
    const files = Array.from(fileList || []);
    if (files.length === 0) return;

    const accepted = [];
    files.forEach((file) => {
      if (file.size > MAX_FILE_SIZE) {
        addToast({
          type: "warning",
          message: `${file.name} exceeds 10MB limit and was skipped.`,
        });
        return;
      }
      accepted.push(file);
    });
    if (accepted.length === 0) return;

    // Add a row per file immediately (status "uploading") so the table
    // reflects progress right away, then kick off each file's real upload.
    const newDocuments = accepted.map((file) => {
      const objectUrl = URL.createObjectURL(file);
      objectUrlsRef.current.push(objectUrl);
      return {
        id: `doc-${crypto.randomUUID()}`,
        name: file.name,
        size: file.size,
        uploadedBy: user?.name || "You",
        uploadedAt: new Date(),
        objectUrl,
        file,
        isSigned,
        status: "uploading",
      };
    });

    setDocuments((prev) => [...newDocuments, ...prev]);
    newDocuments.forEach((doc) => uploadDocument(doc.id, doc.file, isSigned));
  };

  // Selecting file(s) doesn't upload immediately — it stashes the picked
  // files (as a plain array, copied out of the input's live FileList
  // before it gets reset below) and opens the "Is this document or
  // generated draft signed?" dialog first (see pendingUploadFiles /
  // handleSignedChoice below); the actual addFiles() call (and therefore
  // the API call) only happens once the user answers Yes or No there.
  const handleFileInputChange = (e) => {
    // `e.target.files` is a LIVE FileList tied to the input's own current
    // selection, not a snapshot — resetting `e.target.value` below clears
    // that same list back to empty. Array.from() here copies the files out
    // into a real array BEFORE that reset, so pendingUploadFiles (read
    // later, once the user answers the dialog) still has the picked files
    // instead of silently ending up empty. That's what was causing no
    // upload/API call to happen: addFiles() would immediately return via
    // its `if (files.length === 0) return;` guard, with no visible error.
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      setPendingUploadFiles(files);
    }
    // Reset so selecting the same file again still fires onChange.
    e.target.value = "";
  };

  // Answers the "Is this document or generated draft signed?" dialog —
  // proceeds with the upload (now that we know whether to send
  // is_signed: true or false), for every file that was picked. Cancel
  // (isSigned === null) discards the pending selection entirely, uploading
  // nothing.
  const handleSignedChoice = (isSigned) => {
    if (isSigned !== null && pendingUploadFiles) {
      addFiles(pendingUploadFiles, isSigned);
    }
    setPendingUploadFiles(null);
  };

  const handleUploadButtonClick = () => fileInputRef.current?.click();

  const handleRetryUpload = (doc) =>
    uploadDocument(doc.id, doc.file, doc.isSigned);

  // Triggers a real browser navigation to `url` (rather than fetch()+blob)
  // so this doesn't depend on CORS on whatever host the download URL points
  // to — same approach used for the draft-download flow in ChatDraftForm.
  const triggerBrowserDownload = (url, fileName) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  // Prefers the local object URL (instant, no network round-trip — used for
  // documents uploaded this session). Otherwise calls
  // downloadSignedDocuments() for a real download URL, since a document
  // loaded from the list only has an `s3_key` (see normalizeSignedDocument).
  const handleDownload = async (doc) => {
    if (doc.objectUrl) {
      triggerBrowserDownload(doc.objectUrl, doc.name);
      return;
    }
    if (!doc.fileKey || downloadingDocIds.has(doc.id)) return;

    setDownloadingDocIds((prev) => new Set(prev).add(doc.id));
    try {
      const response = await downloadSignedDocuments(user?.email, [
        doc.fileKey,
      ]);
      const url = extractSignedDocumentDownloadUrl(response, doc.fileKey);
      if (!url) throw new Error("No download URL in response");
      triggerBrowserDownload(url, doc.name);
    } catch (error) {
      console.log(error);
      addToast({
        type: "warning",
        message: `Failed to download ${doc.name}. Please try again.`,
      });
    } finally {
      setDownloadingDocIds((prev) => {
        const next = new Set(prev);
        next.delete(doc.id);
        return next;
      });
    }
  };

  const handleDeleteClick = (doc) => setDocumentPendingDelete(doc);
  const handleCancelDelete = () => setDocumentPendingDelete(null);

  // Deletes via deleteSignedDocuments(user_email, [s3_key]), then re-fetches
  // the list on success so the table reflects the backend's own state
  // afterward rather than just trusting the local removal.
  //
  // A row with no `fileKey` (status "error" — its upload never succeeded,
  // so there's nothing on the backend to delete yet) skips the API call
  // entirely and is just removed locally.
  const handleConfirmDelete = async () => {
    if (!documentPendingDelete) return;
    const docToDelete = documentPendingDelete;

    if (!docToDelete.fileKey) {
      if (docToDelete.objectUrl) {
        URL.revokeObjectURL(docToDelete.objectUrl);
        objectUrlsRef.current = objectUrlsRef.current.filter(
          (url) => url !== docToDelete.objectUrl,
        );
      }
      setDocuments((prev) => prev.filter((d) => d.id !== docToDelete.id));
      setDocumentPendingDelete(null);
      return;
    }

    setDeletingDocument(true);
    try {
      await deleteSignedDocuments(user?.email, [docToDelete.fileKey]);

      if (docToDelete.objectUrl) {
        URL.revokeObjectURL(docToDelete.objectUrl);
        objectUrlsRef.current = objectUrlsRef.current.filter(
          (url) => url !== docToDelete.objectUrl,
        );
      }
      // Remove it from local state BEFORE re-fetching: fetchDocuments'
      // merge logic keeps any local document that isn't matched in the
      // fresh response (so a document that's still "uploading" — the
      // backend legitimately doesn't have a record of it yet — survives a
      // refresh). Without removing it here first, this doc — now correctly
      // absent from the backend's response because it was just deleted —
      // would be treated the exact same way and get merged right back in.
      setDocuments((prev) => prev.filter((d) => d.id !== docToDelete.id));
      addToast({
        type: "success",
        message: `${docToDelete.name} deleted.`,
      });
      setDocumentPendingDelete(null);
      await fetchDocuments();
    } catch (error) {
      console.log(error);
      addToast({
        type: "warning",
        message: `Failed to delete ${docToDelete.name}. Please try again.`,
      });
    } finally {
      setDeletingDocument(false);
    }
  };

  return (
    <div className="px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <FileSignature className="h-6 w-6 text-pmi-blue" />
          Signed Documents
        </h2>
      </div>

      <div className="flex items-center justify-between px-5 py-4">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={ACCEPTED_FILE_TYPES}
          onChange={handleFileInputChange}
          className="hidden"
          id="signed-document-upload"
        />
        <button
          type="button"
          onClick={handleUploadButtonClick}
          className="inline-flex items-center gap-2 px-4 py-2 bg-pmi-blue text-white rounded-lg text-sm font-medium hover:bg-pmi-navy transition-colors"
        >
          <Upload className="h-4 w-4" />
          Upload File
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-pmi-border overflow-hidden">
        {/* Document table — SharePoint-style list. Header row stays visible
            even with zero documents; only the body switches to the empty
            state. */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-pmi-border bg-pmi-surface/60 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <th className="px-5 py-3">Name</th>
                <th className="px-5 py-3">Uploaded By</th>
                <th className="px-5 py-3">Uploaded On</th>
                <th className="px-5 py-3">Size</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-pmi-border/60">
              {documentsLoading ? (
                <tr>
                  <td colSpan={5} className="px-5 py-16">
                    <LoadingSpinner message="Loading documents..." />
                  </td>
                </tr>
              ) : documentsLoadError ? (
                <tr>
                  <td colSpan={5} className="px-5 py-16 text-center">
                    <AlertCircle className="h-10 w-10 text-red-300 mx-auto mb-3" />
                    <p className="text-gray-500 font-medium">
                      Couldn't load documents
                    </p>
                    <button
                      type="button"
                      onClick={fetchDocuments}
                      className="mt-2 text-sm text-pmi-blue hover:text-pmi-navy font-medium underline"
                    >
                      Try again
                    </button>
                  </td>
                </tr>
              ) : documents.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-16 text-center">
                    <FileText className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 font-medium">No documents</p>
                    <p className="text-sm text-gray-400 mt-1">
                      Click "Upload File" to get started
                    </p>
                  </td>
                </tr>
              ) : (
                documents.map((doc) => (
                  <tr
                    key={doc.id}
                    className="hover:bg-pmi-light/40 transition-colors"
                  >
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <FileText className="h-4 w-4 text-pmi-blue flex-shrink-0" />
                        <span className="truncate font-medium text-gray-900">
                          {doc.name}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-gray-600 whitespace-nowrap">
                      {doc.uploadedBy}
                    </td>
                    <td className="px-5 py-3 text-gray-500 whitespace-nowrap">
                      {formatUploadedAt(doc.uploadedAt)}
                    </td>
                    <td className="px-5 py-3 text-gray-500 whitespace-nowrap">
                      {formatFileSize(doc.size)}
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        {doc.status === "uploading" && (
                          <span className="inline-flex items-center gap-1.5 text-xs text-gray-500">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            Uploading...
                          </span>
                        )}
                        {doc.status === "error" && (
                          <>
                            <span className="inline-flex items-center gap-1 text-xs text-red-500">
                              <AlertCircle className="h-3.5 w-3.5" />
                              Failed
                            </span>
                            <button
                              type="button"
                              onClick={() => handleRetryUpload(doc)}
                              title="Retry upload"
                              className="p-1.5 rounded-md text-gray-400 hover:text-pmi-blue hover:bg-pmi-blue/10 transition-colors"
                            >
                              <RotateCcw className="h-4 w-4" />
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDownload(doc)}
                          disabled={
                            doc.status !== "uploaded" ||
                            !(doc.objectUrl || doc.fileKey) ||
                            downloadingDocIds.has(doc.id)
                          }
                          title="Download"
                          className="p-1.5 rounded-md text-gray-400 hover:text-pmi-blue hover:bg-pmi-blue/10 disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-gray-400 transition-colors"
                        >
                          {downloadingDocIds.has(doc.id) ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Download className="h-4 w-4" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteClick(doc)}
                          disabled={doc.status === "uploading"}
                          title="Delete"
                          className="p-1.5 rounded-md text-gray-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-gray-400 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <ConfirmDialog
        open={Boolean(documentPendingDelete)}
        title="Delete document?"
        message={`Are you sure you want to delete "${documentPendingDelete?.name}"? This action cannot be undone.`}
        confirmLabel={deletingDocument ? "Deleting..." : "Delete"}
        confirmDisabled={deletingDocument}
        cancelLabel="Cancel"
        variant="danger"
        onConfirm={handleConfirmDelete}
        onCancel={handleCancelDelete}
      />

      {/* "Is this document or generated draft signed?" — shown after
          picking file(s), before any upload/API call starts (see
          handleFileInputChange/handleSignedChoice). Yes/No are both real
          answers (not a confirm-vs-cancel pair), so this is its own small
          dialog rather than reusing ConfirmDialog, which only supports one
          "confirm" action. */}
      {pendingUploadFiles && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => handleSignedChoice(null)}
          />
          <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-pmi-blue/10 flex items-center justify-center">
                <FileSignature className="h-5 w-5 text-pmi-blue" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">
                  Is this document or generated draft signed?
                </h3>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => handleSignedChoice(null)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSignedChoice(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                No, not signed
              </button>
              <button
                onClick={() => handleSignedChoice(true)}
                className="px-4 py-2 text-sm font-medium rounded-lg bg-pmi-blue hover:bg-pmi-navy text-white"
              >
                Yes, it's signed
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default SignedDocuments;
