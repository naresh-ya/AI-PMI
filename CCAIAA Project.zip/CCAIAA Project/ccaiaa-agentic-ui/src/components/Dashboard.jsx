import { useState, useEffect, useCallback, useRef } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import {
  FileText,
  Clock,
  CheckCircle,
  TrendingUp,
  Globe,
  Activity,
  RefreshCw,
  AlertCircle,
  Edit2,
  Search,
  X,
  MessageSquare,
  Send,
  Circle,
  Edit,
  UserCheck,
  Eye,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import {
  listRequests,
  getPolicyUpdates,
  getConversationIds,
} from "../services/api";
import { MOCK_REQUESTS, MOCK_POLICY_UPDATES } from "../data/mockData";
import LoadingSpinner from "./ui/LoadingSpinner";
import AskCA from "./AskCA";
import { STATUS_LIST } from "../utils/constants";

function Dashboard() {
  const location = useLocation();
  const navigate = useNavigate();
  const sourceMenu = location?.state?.from
    ? location?.state?.from
    : "dashboard";
  const {
    state,
    setRequests,
    setPolicyUpdates,
    setLoading,
    addToast,
    setConversations,
    setSelectedConversationId,
  } = useApp();
  const {
    duplicateRequests,
    user,
    requests,
    policyUpdates,
    loading,
    selectedConversationId,
  } = state;
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [policySearchQuery, setPolicySearchQuery] = useState("");
  const [mainTab, setMainTab] = useState("requests");
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState([
    {
      role: "assistant",
      content:
        "Hello! I'm your AI assistant for PMI Corporate Affairs. Ask me about requests, regulatory updates, or anything related to your workflow.",
      timestamp: new Date(),
    },
  ]);
  const [dashboardStats, setDashboardStats] = useState({
    incompleteCount: 0,
    draftCount: 0,
    researchCount: 0,
    reviewCount: 0,
    hitlCount: 0,
    completedCount: 0,
  });

  const [fetchLatestStatus, setFetchLatestStatus] = useState(true);
  const isFirstLoad = useRef(true);
  const originalRequests = useRef(new Map());
  const [progressVisibleMap, setProgressVisibleMap] = useState({});

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    const userMessage = {
      role: "user",
      content: chatInput,
      timestamp: new Date(),
    };
    setChatMessages((prev) => [...prev, userMessage]);
    setChatInput("");
    // TODO: Replace with real chat API call
    setTimeout(() => {
      const aiMessage = {
        role: "assistant",
        content:
          "I can help you with that. Let me look into the latest regulatory updates and request statuses. Is there a specific jurisdiction or document type you're interested in?",
        timestamp: new Date(),
      };
      setChatMessages((prev) => [...prev, aiMessage]);
    }, 1000);
  };

  const fetchRequests = useCallback(async () => {
    if (isFirstLoad.current) {
      setLoading("requests", true);
      isFirstLoad.current = false;
    }
    try {
      const data = await listRequests(user?.email.toLowerCase());
      let tempIncompleteCount = 0,
        tempDraftCount = 0,
        tempResearchCount = 0,
        tempReviewCount = 0,
        tempHITLCount = 0,
        tempCompletedCount = 0;
      for (const key in data) {
        const keyValue = data[key];

        if (typeof keyValue == "number" && key in STATUS_LIST) {
          switch (STATUS_LIST[key]?.cardStatus) {
            case "Incomplete":
              tempIncompleteCount = tempIncompleteCount + keyValue;
              break;
            case "Research":
              tempResearchCount = tempResearchCount + keyValue;
              break;
            case "Draft":
              tempDraftCount = tempDraftCount + keyValue;
              break;
            case "Review":
              tempReviewCount = tempReviewCount + keyValue;
              break;
            case "HITL":
              tempHITLCount = tempHITLCount + keyValue;
              break;
            case "Completed":
              tempCompletedCount = tempCompletedCount + keyValue;
              break;
          }
        }
      }
      setDashboardStats({
        incompleteCount: tempIncompleteCount,
        draftCount: tempDraftCount,
        researchCount: tempResearchCount,
        reviewCount: tempReviewCount,
        hitlCount: tempHITLCount,
        completedCount: tempCompletedCount,
      });
      let updatedRequests = Array.isArray(data) ? data : data.records || [];
      updatedRequests.forEach((request) => {
        if (!originalRequests.current.has(request.request_id)) {
          originalRequests.current.set(request.request_id, request);
        }
      });
      updatedRequests.forEach((request) => {
        const prev = originalRequests.current.get(request.request_id);

        if (
          prev?.status !== request.status &&
          request.status === "DRAFTING_COMPLETED"
        ) {
          setProgressVisibleMap((prevMap) => ({
            ...prevMap,
            [request.request_id]: true,
          }));

          originalRequests.current.set(request.request_id, request);

          setTimeout(() => {
            setProgressVisibleMap((prevMap) => ({
              ...prevMap,
              [request.request_id]: false,
            }));
          }, 3000);
        }
      });
      const allComplete = updatedRequests?.every(
        (request) => request?.status == "DRAFTING_COMPLETED",
      );
      setRequests(Array.isArray(data) ? data : updatedRequests || []);
      setFetchLatestStatus(!allComplete);
    } catch (err) {
      // Fallback: seed with mock data when API is unavailable
      if (requests.length === 0) {
        setRequests(MOCK_REQUESTS);
      }
    } finally {
      setLoading("requests", false);
    }
  }, [setRequests, setLoading, requests.length]);

  const fetchPolicyUpdates = useCallback(async () => {
    try {
      setLoading("policies", true);
      const data = await getPolicyUpdates(user?.email.toLowerCase());
      setPolicyUpdates(Array.isArray(data) ? data : data.records || []);
      setLoading("policies", false);
    } catch {
      // Fallback: seed with mock policy updates when API is unavailable
      setLoading("policies", false);
      if (policyUpdates.length === 0) {
        setPolicyUpdates(MOCK_POLICY_UPDATES);
      }
    }
  }, [setPolicyUpdates, policyUpdates.length]);

  const fetchConversations = useCallback(async () => {
    try {
      setLoading("conversations", true);
      const conversationIdsResponse = await getConversationIds(
        user?.email?.replace("@", "").replace(/\./g, "_"),
      );
      const conversations = conversationIdsResponse?.conversations || [];
      setConversations(conversations);
      if (conversations.length > 0 && !selectedConversationId) {
        setSelectedConversationId(conversations[0]?.conversation_id);
      }
    } catch (err) {
      console.log(err);
    } finally {
      setLoading("conversations", false);
    }
  }, [
    user,
    setConversations,
    setLoading,
    selectedConversationId,
    setSelectedConversationId,
  ]);

  useEffect(() => {
    if (sourceMenu != "dashboard") {
      return;
    }
    fetchRequests();
    fetchPolicyUpdates();
  }, [sourceMenu]);

  useEffect(() => {
    fetchConversations();
  }, []);

  // Filtered requests
  const filteredRequests = requests.filter((r) => {
    let includeRequestbasedOnStatus = false;
    if (
      STATUS_LIST[r?.status]?.cardStatus == statusFilter &&
      statusFilter != "all"
    ) {
      includeRequestbasedOnStatus = true;
    } else if (statusFilter == "all") {
      includeRequestbasedOnStatus = true;
    }
    // Status filter
    // if (statusFilter !== "all") {
    //   if (
    //     statusFilter === "active" &&
    //     (r.status === "completed" ||
    //       r.status === "failed" ||
    //       r.status === "user-draft")
    //   )
    //     return false;
    //   if (statusFilter === "completed" && r.status !== "completed")
    //     return false;
    //   if (
    //     statusFilter === "pending" &&
    //     r.status !== "pending-approval" &&
    //     r.status !== "awaiting_human_review"
    //   )
    //     return false;
    //   if (statusFilter === "drafts" && r.status !== "user-draft") return false;
    // }
    // Text search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        (r.topic || "").toLowerCase().includes(q) ||
        (r.jurisdiction || "").toLowerCase().includes(q) ||
        (r.category || "").toLowerCase().includes(q) ||
        (r.document_type || "").toLowerCase().includes(q) ||
        (r.target_audience || "").toLowerCase().includes(q) ||
        (r.request_id || "").toLowerCase().includes(q)
      );
    }
    return includeRequestbasedOnStatus;
  });

  const filteredPolicies = policyUpdates.filter((policy) => {
    if (policySearchQuery.trim()) {
      const q = policySearchQuery.toLowerCase();
      return (policy.title || "").toLowerCase().includes(q);
    } else {
      return true;
    }
  });

  const getStatusBadge = (status, statusCode) => {
    const map = {
      Incomplete: {
        bg: "bg-gray-100",
        text: "text-gray-600",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Research: {
        bg: "bg-blue-100",
        text: "text-blue-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Draft: {
        bg: "bg-violet-100",
        text: "text-violet-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Review: {
        bg: "bg-orange-100",
        text: "text-orange-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Completed: {
        bg: "bg-emerald-100",
        text: "text-emerald-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      HITL: {
        bg: "bg-purple-100",
        text: "text-purple-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
    };
    const s = map[status] || {
      bg: "bg-gray-100",
      text: "text-gray-700",
      label: STATUS_LIST[statusCode]?.backendStatus || "NOT AVAILABLE",
    };
    return (
      <span
        className={`px-3 py-1 rounded-full text-xs font-medium ${s.bg} ${s.text}`}
      >
        {s.label}
      </span>
    );
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (fetchLatestStatus && sourceMenu == "dashboard") {
        fetchRequests();
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [fetchLatestStatus, sourceMenu]);

  return (
    <div
      className={
        sourceMenu === "askca"
          ? "flex-1 min-h-0 min-w-0 flex flex-col"
          : "px-6 lg:px-8 py-8"
      }
    >
      {/* Welcome + Stats — gradient header */}
      <div
        className={
          sourceMenu === "askca"
            ? "flex-1 flex flex-col min-h-0 min-w-0"
            : "rounded-xl overflow-hidden mb-4 shadow-sm"
        }
      >
        {sourceMenu == "dashboard" ? (
          <div className="bg-gradient-to-r from-pmi-navy via-pmi-blue to-blue-500 p-6 pb-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">
                  Welcome back, {user?.name?.split(" ")[0]}! 👋
                </h2>
                <p className="text-blue-200 text-sm mt-0.5">
                  Here's what's happening with your Corporate Affairs requests
                </p>
              </div>
              {sourceMenu == "dashboard" && (
                <button
                  onClick={fetchRequests}
                  disabled={loading.requests}
                  className="flex items-center gap-2 px-4 py-2 text-sm text-white/90 border border-white/30 rounded-lg hover:bg-white/10 disabled:opacity-50 transition-colors backdrop-blur-sm"
                >
                  <RefreshCw
                    className={`h-4 w-4 ${loading.requests ? "animate-spin" : ""}`}
                  />
                  Refresh
                </button>
              )}
            </div>
          </div>
        ) : (
          <AskCA />
        )}

        {sourceMenu === "dashboard" && (
          <div className="bg-white px-6 py-4">
            <div className="grid xs:grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-1">
              <button
                onClick={() => setStatusFilter("Incomplete")}
                className={`text-left rounded-xl p-2 transition-all duration-200 border ${statusFilter === "active" ? "bg-gray-50 ring-2 ring-gray-300 border-gray-200 shadow-md" : "bg-gray-50/60 border-gray-300/70 hover:bg-gray-50 hover:shadow-sm"}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Incomplete
                  </p>
                  <div className="p-1.5 rounded-lg bg-gray-100">
                    <Circle className="h-4 w-4 text-gray-600" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-gray-900">
                  {dashboardStats?.incompleteCount}
                </p>
              </button>

              <button
                onClick={() => setStatusFilter("Research")}
                className={`text-left rounded-xl p-2 transition-all duration-200 border ${statusFilter === "active" ? "bg-blue-50 ring-2 ring-blue-300 border-blue-200 shadow-md" : "bg-blue-50/60 border-blue-100 hover:bg-blue-50 hover:shadow-sm"}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-blue-700 uppercase tracking-wider">
                    Research
                  </p>
                  <div className="p-1.5 rounded-lg bg-blue-100">
                    <Search className="h-4 w-4 text-blue-600" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-blue-900">
                  {dashboardStats?.researchCount}
                </p>
              </button>

              <button
                onClick={() => setStatusFilter("Draft")}
                className={`text-left rounded-xl p-2 transition-all duration-200 border ${statusFilter === "active" ? "bg-violet-50 ring-2 ring-violet-300 border-violet-200 shadow-md" : "bg-violet-50/60 border-violet-100 hover:bg-violet-50 hover:shadow-sm"}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-violet-700 uppercase tracking-wider">
                    Draft
                  </p>
                  <div className="p-1.5 rounded-lg bg-violet-100">
                    <FileText className="h-4 w-4 text-violet-600" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-violet-900">
                  {dashboardStats?.draftCount}
                </p>
              </button>

              <button
                onClick={() => setStatusFilter("Review")}
                className={`text-left rounded-xl p-2 transition-all duration-200 border ${statusFilter === "drafts" ? "bg-orange-50 ring-2 ring-orange-300 border-orange-200 shadow-md" : "bg-orange-50/60 border-orange-100 hover:bg-orange-50 hover:shadow-sm"}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-orange-700 uppercase tracking-wider">
                    Review
                  </p>
                  <div className="p-1.5 rounded-lg bg-orange-100">
                    <Eye className="h-4 w-4 text-orange-600" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-orange-900">
                  {dashboardStats?.reviewCount}
                </p>
              </button>

              {/* <button
                onClick={() => setStatusFilter("HITL")}
                className={`text-left rounded-xl p-4 transition-all duration-200 border ${statusFilter === "pending" ? "bg-amber-50 ring-2 ring-purple-300 border-purple-200 shadow-md" : "bg-purple-50/60 border-purple-100 hover:bg-purple-50 hover:shadow-sm"}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-purple-700 uppercase tracking-wider">
                    HITL
                  </p>
                  <div className="p-1.5 rounded-lg bg-purple-100">
                    <UserCheck className="h-4 w-4 text-purple-600" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-purple-900">
                  {dashboardStats?.hitlCount}
                </p>
              </button> */}

              <button
                onClick={() => setStatusFilter("Completed")}
                className={`text-left rounded-xl p-2 transition-all duration-200 border ${statusFilter === "completed" ? "bg-emerald-50 ring-2 ring-emerald-300 border-emerald-200 shadow-md" : "bg-emerald-50/60 border-emerald-100 hover:bg-emerald-50 hover:shadow-sm"}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
                    Completed
                  </p>
                  <div className="p-1.5 rounded-lg bg-emerald-100">
                    <CheckCircle className="h-4 w-4 text-emerald-600" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-emerald-900">
                  {dashboardStats?.completedCount}
                </p>
              </button>
            </div>
          </div>
        )}
      </div>

      {sourceMenu == "dashboard" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          <div className="lg:col-span-2">
            <div
              className="bg-white rounded-xl shadow-sm border border-pmi-border flex flex-col"
              style={{ height: "600px" }}
            >
              <div className="p-5 border-b border-pmi-border bg-gradient-to-b from-white to-pmi-surface/50">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">
                    Requests
                  </h3>
                  <div className="p-1.5 rounded-lg bg-pmi-light">
                    <FileText className="h-4 w-4" />
                  </div>
                </div>
              </div>
              <div className="flex flex-col flex-1 min-h-0">
                {/* Filters + Search */}
                <div className="p-4 pb-3 space-y-3 border-b border-pmi-border/50">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-1 bg-pmi-surface rounded-lg p-1">
                      {[
                        { key: "all", label: "All" },
                        { key: "Research", label: "Research" },
                        { key: "Draft", label: "Draft" },
                        { key: "Review", label: "Review" },
                        // { key: "HITL", label: "HITL" },
                        { key: "Completed", label: "Completed" },
                      ].map((tab) => (
                        <button
                          key={tab.key}
                          onClick={() => setStatusFilter(tab.key)}
                          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                            statusFilter === tab.key
                              ? "bg-white text-gray-900 shadow-sm"
                              : "text-gray-500 hover:text-gray-700"
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search by topic, jurisdiction, category, audience..."
                      className="w-full pl-9 pr-9 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent placeholder:text-gray-400 transition-shadow focus:outline-none"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery("")}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Scrollable Request List */}
                <div className="flex-1 overflow-y-auto">
                  {loading.requests ? (
                    <div className="p-12">
                      <LoadingSpinner message="Loading requests..." />
                    </div>
                  ) : filteredRequests.length === 0 ? (
                    <div className="p-12 text-center">
                      <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500 font-medium">
                        No requests found
                      </p>
                      <p className="text-sm text-gray-400 mt-1 mb-3">
                        Create a new request to get started
                      </p>
                      <button
                        onClick={() => navigate("/new-request")}
                        className="px-6 py-2 items-center bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy"
                      >
                        Create Request
                      </button>
                    </div>
                  ) : (
                    <div className="divide-y divide-pmi-border/50">
                      {filteredRequests.map((request) => (
                        <Link
                          key={request.request_id || request.id}
                          to={
                            request?.status === "DRAFT"
                              ? `/new-request?draft=${request.request_id || request.id}`
                              : `/request/${request.request_id || request.id}`
                          }
                          className="block p-5 hover:bg-pmi-light/40 transition-all duration-150 border-l-3 border-l-transparent hover:border-l-pmi-blue"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1 mr-4">
                              <h4 className="text-sm font-semibold text-gray-900 mb-1">
                                {request.topic}
                              </h4>
                              <div className="flex items-center flex-wrap gap-x-3 gap-y-1 text-xs text-gray-500">
                                <span className="flex items-center">
                                  <Globe className="h-3.5 w-3.5 mr-1" />
                                  {request.jurisdiction}
                                </span>
                                {request.deadline && (
                                  <span>
                                    Due:{" "}
                                    {new Date(
                                      request.deadline,
                                    ).toLocaleDateString()}
                                  </span>
                                )}
                                {(request.category ||
                                  request.document_type) && (
                                  <span className="bg-gray-100 px-1.5 py-0.5 rounded">
                                    {request.category || request.document_type}
                                  </span>
                                )}
                              </div>
                            </div>
                            {getStatusBadge(
                              STATUS_LIST[request?.status]?.cardStatus,
                              request?.status,
                            )}
                          </div>

                          {/* Progress Bar */}
                          {/* {request.progress != null && (
                            <div className="mb-2">
                              <div className="flex justify-between text-xs text-gray-600 mb-1">
                                <span>Progress</span>
                                <span>
                                  {typeof request.progress === "object"
                                    ? request.progress.percentage
                                    : request.progress}
                                  %
                                </span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-1.5">
                                <div
                                  className={`h-1.5 rounded-full transition-all duration-500 ${(typeof request.progress === "object"
                                    ? request.progress.percentage
                                    : request.progress) === 100
                                    ? "bg-green-500"
                                    : "bg-blue-500"
                                    }`}
                                  style={{
                                    width: `${typeof request.progress === "object" ? request.progress.percentage : request.progress}%`,
                                  }}
                                ></div>
                              </div>
                            </div>
                          )} */}

                          {/* Progress Bar */}
                          {((STATUS_LIST[request.status]?.progress != null &&
                            STATUS_LIST[request.status]?.progress < 100) ||
                            progressVisibleMap[request.request_id]) && (
                            <div className="mb-4">
                              <div className="flex justify-between text-sm text-gray-600 mb-2">
                                <span className="font-medium">Progress</span>
                                <span className="font-semibold">
                                  {STATUS_LIST[request.status]?.progress}%
                                </span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-3">
                                <div
                                  className={`h-3 rounded-full transition-all duration-500 ${STATUS_LIST[request.status]?.progress === 100 ? "bg-green-500" : "bg-blue-500"}`}
                                  style={{
                                    width: `${STATUS_LIST[request.status]?.progress}%`,
                                  }}
                                ></div>
                              </div>
                            </div>
                          )}

                          {/* Agent Activity */}
                          {request.agentActivity && (
                            <div className="space-y-1">
                              {request.agentActivity
                                .slice(0, 2)
                                .map((activity, idx) => (
                                  <div
                                    key={idx}
                                    className="flex items-center text-xs"
                                  >
                                    <Activity
                                      className={`h-3 w-3 mr-1.5 ${
                                        activity.status === "completed"
                                          ? "text-green-500"
                                          : activity.status === "in-progress"
                                            ? "text-blue-500 animate-pulse"
                                            : "text-gray-400"
                                      }`}
                                    />
                                    <span className="text-gray-700">
                                      {activity.agent}
                                    </span>
                                    <span className="text-gray-400 ml-1.5">
                                      • {activity.time}
                                    </span>
                                  </div>
                                ))}
                            </div>
                          )}

                          {/* Created timestamp */}
                          {request?.updated_at && (
                            <p className="text-xs text-gray-400 mt-1.5">
                              Updated At:{" "}
                              {new Date(request?.updated_at).toLocaleString()}
                            </p>
                          )}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="lg:col-span-1">
            <div
              className="bg-white rounded-xl shadow-sm border border-pmi-border flex flex-col"
              style={{ height: "600px" }}
            >
              <div className="p-5 pb-2 bg-gradient-to-b from-white to-pmi-surface/50">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">
                    Policy Updates
                  </h3>
                  <div className="p-1.5 rounded-lg bg-pmi-light">
                    <TrendingUp className="h-4 w-4 text-pmi-blue" />
                  </div>
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  AI-monitored regulatory changes
                </p>
              </div>
              <div className="relative p-3 border-b border-pmi-border">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={policySearchQuery}
                  onChange={(e) => setPolicySearchQuery(e.target.value)}
                  placeholder="Search policy updates..."
                  className="w-full pl-9 pr-9 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent placeholder:text-gray-400 transition-shadow focus:outline-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => setPolicySearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <div className="flex-1 overflow-y-auto divide-y divide-pmi-border/50">
                {loading?.policies ? (
                  <div className="p-12">
                    <LoadingSpinner message="Loading policies..." />
                  </div>
                ) : filteredPolicies.length > 0 ? (
                  filteredPolicies.map((update, idx) => (
                    <div
                      key={update.id || idx}
                      className="p-4 hover:bg-pmi-light/40 transition-colors cursor-pointer"
                    >
                      <a
                        href={update?.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <p className="text-sm font-medium text-gray-900 mb-1 mr-1">
                          {update.title}
                        </p>
                        <div className="flex items-center justify-start">
                          <p className="text-xs text-gray-500">
                            {update?.date}
                          </p>
                          <span
                            className={`px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-700 ml-2`}
                          >
                            {update?.source_name}
                          </span>
                        </div>
                      </a>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center text-gray-400">
                    <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Policy updates will appear here</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
