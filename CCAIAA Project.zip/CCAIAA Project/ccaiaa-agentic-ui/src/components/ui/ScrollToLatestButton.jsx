import { memo } from "react";
import { ChevronDown } from "lucide-react";

/**
 * ScrollToLatestButton
 * ---------------------------------------------------------------------------
 * Floating circular "jump to latest message" button, styled after the
 * Copilot / ChatGPT / Teams / Slack pattern:
 *  - Circular, elevated with a soft shadow.
 *  - Anchored to the bottom-right of its positioning parent (the chat
 *    container should be `position: relative`).
 *  - Animates in/out with a scale + fade so it never just "pops" on screen.
 *  - A small pulsing dot indicates *new* content arrived while scrolled up
 *    (mirrors Slack/Teams' "new messages" indicator).
 *
 * Purely presentational — visibility and the scroll action are controlled
 * by the parent via `visible` / `onClick` (see useAutoScrollChat).
 */
function ScrollToLatestButton({ visible, onClick, hasNewContent = false }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="Scroll to latest message"
      title="Jump to latest"
      className={`absolute right-6 bottom-44 z-20 flex items-center justify-center h-10 w-10 rounded-full bg-white border border-gray-200 shadow-lg text-gray-600 transition-all duration-200 ease-out hover:bg-gray-50 hover:text-pmi-blue hover:shadow-xl hover:-translate-y-0.5 active:scale-95 ${
        visible
          ? "opacity-100 scale-100 pointer-events-auto"
          : "opacity-0 scale-75 pointer-events-none"
      }`}
    >
      <ChevronDown className="h-5 w-5" />
      {hasNewContent && (
        <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-pmi-blue">
          <span className="absolute inset-0 rounded-full bg-pmi-blue animate-ping" />
        </span>
      )}
    </button>
  );
}

// Memoized: this button re-renders only when its own props change, not on
// every streamed-token update in the parent chat component.
export default memo(ScrollToLatestButton);
