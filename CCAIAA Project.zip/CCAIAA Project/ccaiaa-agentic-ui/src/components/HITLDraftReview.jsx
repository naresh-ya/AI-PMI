import { useState, useEffect } from 'react'
import { BookOpen, Download, CheckCircle, XCircle, RotateCcw, FileText, Pencil, Eye, List, ChevronDown, ChevronUp, Loader2, AlertCircle, User, Clock, MessageSquare } from 'lucide-react'
import { submitResearchHITLDecision, fetchDocumentPreview, downloadGeneratedDocument } from '../services/api'
import { useApp } from '../context/AppContext'
import { getDocumentOutline } from '../utils/templates'
import { DISPLAY_TEXT } from "../utils/constants";
import DocumentVersionPreview from './DocumentVersionPreview';

// Review Types Configuration
const REVIEW_TYPES = {
  ca: {
    label: 'CA Review',
    description: 'Corporate Affairs review including Scientific, Regulatory, and Communications',
    subTypes: {
      scientific: { label: 'Scientific Review', description: 'Review scientific claims and evidence' },
      regulatory: { label: 'Regulatory Review', description: 'Review compliance with regulations' },
      communications: { label: 'Communications Review', description: 'Review messaging and tone' },
      fiscal: { label: 'Fiscal Review', description: 'Review compliance with financial policies' }
    }
  },
  legal: {
    label: 'Legal Review',
    description: 'Legal compliance and risk assessment review',
    subTypes: null
  }
}

/**
 * Human-in-the-Loop Review for the Master Drafter Agent
 * 
 * Displays document outline, key messages, draft content, and tone analysis.
 * Document outline is dynamic based on category and use case.
 * Allows human reviewer to approve, request revisions, or reject the draft.
 * Includes multi-reviewer workflow with CA and Legal reviews.
 */
function HITLDraftReview({ request, checkpoint, onDecisionComplete }) {
  const { addToast, state } = useApp()
  const [submitting, setSubmitting] = useState("")
  const [activeView, setActiveView] = useState('preview') // outline | preview | messages | reviews
  const [feedback, setFeedback] = useState('')
  const [sectionFeedback, setSectionFeedback] = useState({})
  const [expandedSections, setExpandedSections] = useState({})
  const [documentPreview, setDocumentPreview] = useState(null);
  // Which version the user has chosen (via the "Set as Final" button in
  // DocumentVersionPreview) to submit as final when they click Approve —
  // defaults to whatever the preview API reports as `current` once it
  // loads (see the fetch effect below), but the user can override it to
  // any other version shown in the preview.
  const [selectedFinalVersion, setSelectedFinalVersion] = useState(null);
  const [downloading, setDownloading] = useState(false)

  // Review selection state
  const [selectedReviews, setSelectedReviews] = useState({
    noReview: false,
    ca: false,
    legal: false
  })
  const [selectedCASubTypes, setSelectedCASubTypes] = useState({
    scientific: false,
    regulatory: false,
    communications: false,
    fiscal: false
  })

  // Review comments state (separate for each reviewer)
  const [reviewComments, setReviewComments] = useState({
    scientific: '',
    regulatory: '',
    communications: '',
    fiscal: '',
    legal: ''
  })

  // Simulated review status (in production, this would come from backend)
  const [reviewStatus, setReviewStatus] = useState({
    scientific: { completed: false, reviewer: null, timestamp: null, comments: '' },
    regulatory: { completed: false, reviewer: null, timestamp: null, comments: '' },
    communications: { completed: false, reviewer: null, timestamp: null, comments: '' },
    fiscal: { completed: false, reviewer: null, timestamp: null, comments: null },
    legal: { completed: false, reviewer: null, timestamp: null, comments: '' }
  })

  // Current user's role (in production, this would come from auth context)
  const currentUserRole = state.user?.role || 'scientific' // scientific, regulatory, communications, legal

  // Extract agent output
  const agentOutput = checkpoint?.agent_output || {}

  // Get document outline - ALWAYS derive from category/useCase (governed by Document Type)
  // This ensures the outline reflects the selected document type structure
  const outline = getDocumentOutline(request?.category, request?.useCase)

  const keyMessages = agentOutput.key_messages || []
  const wordCount = agentOutput.word_count || 0
  const sectionCount = outline.length || agentOutput.section_count || 0
  const toneAnalysis = agentOutput.tone_analysis || {}
  const citationsUsed = agentOutput.citations_used || 0

  const toggleSection = (key) => {
    setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const handleSectionFeedback = (sectionId, text) => {
    setSectionFeedback(prev => ({ ...prev, [sectionId]: text }))
  }

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadGeneratedDocument(request?.document_s3_key);
      setDownloading(false);
    } catch (error) {
      console.log(error);
      setDownloading(false);
    }
  }

  const handleReviewToggle = (reviewType) => {
    if (reviewType === 'noReview') {
      // If selecting "No Review", deselect all other options
      setSelectedReviews({
        noReview: !selectedReviews.noReview,
        ca: false,
        legal: false
      })
      setSelectedCASubTypes({ scientific: false, regulatory: false, communications: false, fiscal: false })
    } else {
      // If selecting other options, deselect "No Review"
      setSelectedReviews(prev => ({
        ...prev,
        noReview: false,
        [reviewType]: !prev[reviewType]
      }))
      // Reset CA sub-types if CA is unchecked
      if (reviewType === 'ca' && selectedReviews.ca) {
        setSelectedCASubTypes({ scientific: false, regulatory: false, communications: false, fiscal: false })
      }
    }
  }

  const handleCASubTypeToggle = (subType) => {
    setSelectedCASubTypes(prev => ({
      ...prev,
      [subType]: !prev[subType]
    }))
  }

  const handleReviewCommentChange = (reviewType, comment) => {
    setReviewComments(prev => ({
      ...prev,
      [reviewType]: comment
    }))
  }

  const submitReviewerFeedback = (reviewType) => {
    const comment = reviewComments[reviewType]
    if (!comment.trim()) {
      addToast({ type: 'warning', message: 'Please provide review comments before submitting.' })
      return
    }

    // Update review status
    setReviewStatus(prev => ({
      ...prev,
      [reviewType]: {
        completed: true,
        reviewer: state.user?.name || 'Reviewer',
        timestamp: new Date().toISOString(),
        comments: comment
      }
    }))

    addToast({
      type: 'success',
      message: `${REVIEW_TYPES.ca.subTypes?.[reviewType]?.label || REVIEW_TYPES.legal.label} feedback submitted.`
    })
  }

  // Check if all selected reviews are complete
  const areAllSelectedReviewsComplete = () => {
    if (selectedReviews.ca) {
      const selectedCATypes = Object.entries(selectedCASubTypes).filter(([_, selected]) => selected)
      if (selectedCATypes.length === 0) return false
      const allCAComplete = selectedCATypes.every(([type]) => reviewStatus[type].completed)
      if (!allCAComplete) return false
    }
    if (selectedReviews.legal && !reviewStatus.legal.completed) return false
    return selectedReviews.ca || selectedReviews.legal // At least one must be selected
  }

  // Check if any review is selected (including No Review)
  const isAnyReviewSelected = () => {
    if (selectedReviews.noReview) return true
    if (selectedReviews.ca) {
      return Object.values(selectedCASubTypes).some(v => v)
    }
    return selectedReviews.legal
  }

  const handleDecision = async (action) => {
    try {
      setSubmitting(action);
      const hitlResponseObject = {
        decision: action,
        feedback: feedback,
        reviewer_id: request?.user_id,
        // Only populated on approval — the version the user marked as
        // final via "Set as Final" in the document preview. Reject/revise
        // don't finalize a version, so this stays empty for those.
        version: action === "approve" ? selectedFinalVersion ?? "" : "",
      }
      const hitlDecisionResponse = await submitResearchHITLDecision(checkpoint?.hitl_id, hitlResponseObject);
      if (hitlDecisionResponse.message.toLowerCase() == "decision submitted successfully") {
        let type = "";
        let title = "";
        let message = "";
        switch (action) {
          case "approve":
            type = "success";
            title = "Draft Approved";
            message = "Document draft approved.";
            break;
          case "revise":
            type = "info";
            title = "Revision Rquested";
            message = "Draft revision has been requested.";
            break;
          case "reject":
            type = "warning";
            title = "Draft Rejected";
            message = "Draft has been rejected.";
            break;
        }
        addToast({ type: type, message: message, title: title });
      }
      onDecisionComplete();
      setSubmitting("");
    } catch (error) {
      addToast({ type: "error", message: "Failed to submit decision", title: "Error" });
      setSubmitting("");
    }
    // if (action === 'reject' && !feedback.trim()) {
    //   addToast({ type: 'warning', message: 'Please provide feedback for rejection.' })
    //   return
    // }
    // if (action === 'revise' && !feedback.trim() && Object.keys(sectionFeedback).length === 0) {
    //   addToast({ type: 'warning', message: 'Please provide revision feedback (general or section-specific).' })
    //   return
    // }
    // if (action === 'approve' && !isAnyReviewSelected()) {
    //   addToast({ type: 'warning', message: 'Please select at least one review type before approving.' })
    //   return
    // }

    // setSubmitting(true)
    // try {
    //   await submitHITLDecision(request.request_id, checkpoint.hitl_id, {
    //     action,
    //     feedback,
    //     comments: feedback,
    //     modifications: {
    //       section_feedback: sectionFeedback,
    //     },
    //     review_config: {
    //       ca_review: selectedReviews.ca,
    //       ca_sub_types: selectedCASubTypes,
    //       legal_review: selectedReviews.legal,
    //       review_comments: reviewComments,
    //       review_status: reviewStatus
    //     }
    //   })

    //   addToast({
    //     type: action === 'approve' ? 'success' : action === 'revise' ? 'info' : 'warning',
    //     title: action === 'approve' ? 'Draft Approved' : action === 'revise' ? 'Revision Requested' : 'Draft Rejected',
    //     message: action === 'approve'
    //       ? 'Document draft approved. Proceeding to selected reviews...'
    //       : action === 'revise'
    //       ? 'Revision request sent to Master Drafter.'
    //       : 'Draft has been rejected.',
    //   })

    //   onDecisionComplete?.(action)
    // } catch (err) {
    //   addToast({ type: 'error', title: 'Error', message: err.message || 'Failed to submit decision.' })
    // } finally {
    //   setSubmitting(false)
    // }
  }

  useEffect(() => {
    const fetchDocumentData = async () => {
      try {
        const response = await fetchDocumentPreview(request.request_id);
        setDocumentPreview(response);
        // Default the final-version selection to whatever the preview API
        // reports as the current/latest version — the user can still pick
        // a different one via "Set as Final" before approving.
        setSelectedFinalVersion(response?.current?.version ?? null);
      } catch (error) {
        console.log(error);
      }
    }
    fetchDocumentData();
  }, [request]);

  return (
    <div className="space-y-6">
      {/* Header */}
      {/* <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <FileText className="h-8 w-8 text-pmi-blue" />
            <div>
              <h3 className="text-xl font-semibold text-gray-900">{request?.topic}</h3>
              <p className="text-sm text-gray-500">{request?.processing_notes}</p>
            </div>
          </div>
          {(request.status == "DRAFT_REVIEW_PENDING") && (<button
            onClick={handleDownload}
            disabled={downloading}
            className="flex items-center px-6 py-3 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy transition-colors font-semibold disabled:opacity-50"
          >
            <Download className="h-5 w-5 mr-2" />
            {downloading ? 'Downloading...' : 'Download Document'}
          </button>)}
          {(request.status == "RESEARCH_COMPLETED" || request.status == "RESEARCH_REVIEW_PENDING") && (<button
            onClick={handleResearchDocDownload}
            disabled={downloading}
            className="flex items-center px-6 py-3 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy transition-colors font-semibold disabled:opacity-50"
          >
            <Download className="h-5 w-5 mr-2" />
            {downloading ? 'Downloading...' : 'Download Document'}
          </button>)}
        </div>

        <div className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Content Type</p>
            <p className="font-semibold text-gray-900">{`${request?.validation_result?.topic}`}</p>
          </div> */}
      {/* <div>
            <p className="text-gray-600">Turnaround Time</p>
            <p className="font-semibold text-green-600">22 min (Under 30-min SLA ✓)</p>
          </div>
          <div>
            <p className="text-gray-600">Word Count</p>
            <p className="font-semibold text-gray-900">~2,450 words</p>
          </div> */}
      {/* </div>
      </div> */}

      {/* View Tabs */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <div className="flex border-b border-gray-200">
          {[
            // { key: 'outline', label: 'Document Outline', icon: List },
            { key: 'preview', label: 'Content Preview', icon: Eye },
            { key: 'citations', label: 'Sources & Citations', icon: BookOpen },
            // { key: 'reviews', label: 'Review Configuration', icon: User },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveView(tab.key)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-colors ${activeView === tab.key
                ? 'border-pmi-blue text-pmi-blue bg-blue-50'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-5">
          {/* Outline View */}
          {activeView === 'outline' && (
            <div className="space-y-3">
              {outline.length > 0 ? outline.map((section, idx) => (
                <div key={idx} className="border border-gray-200 rounded-lg overflow-hidden">
                  <button
                    onClick={() => toggleSection(`section_${idx}`)}
                    className="w-full flex items-center justify-between p-3 hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-pmi-blue w-6">{idx + 1}.</span>
                      <span className="text-sm font-medium text-gray-900">{section.title || section}</span>
                    </div>
                    {typeof section === 'object' && (
                      expandedSections[`section_${idx}`] ? <ChevronUp className="h-4 w-4 text-gray-400" /> : <ChevronDown className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                  {expandedSections[`section_${idx}`] && typeof section === 'object' && (
                    <div className="px-4 pb-3 space-y-2 border-t border-gray-100">
                      {section.summary && (
                        <p className="text-sm text-gray-600 pt-2">{section.summary}</p>
                      )}
                      <div>
                        <label className="block text-xs font-medium text-gray-500 mb-1">Section Feedback (Optional)</label>
                        <textarea
                          value={sectionFeedback[`section_${idx}`] || ''}
                          onChange={(e) => handleSectionFeedback(`section_${idx}`, e.target.value)}
                          rows={2}
                          placeholder="Suggest changes for this section..."
                          className="w-full px-2 py-1.5 border border-gray-200 rounded text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )) : (
                <p className="text-sm text-gray-500 italic">Document outline will appear here when available.</p>
              )}
            </div>
          )}

          {/* Content Preview */}
          {activeView === 'preview' && (
            documentPreview?.current ? (
              <DocumentVersionPreview
                previewData={documentPreview}
                selectedFinalVersion={selectedFinalVersion}
                onSelectFinalVersion={setSelectedFinalVersion}
                allowVersionActions={request?.status === "DRAFT_REVIEW_PENDING"}
              />
            ) : (
              <div className="text-center py-12 text-gray-400">
                <Eye className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="text-sm">Content preview will appear here when the draft is ready.</p>
              </div>
            )
          )}

          {/* Key Messages */}
          {activeView === 'citations' && (
            <div className="space-y-3">
              {(request?.research_output?.citations && request?.research_output?.citations.length > 0) ? (<div className='bg-white-50'>
                <div className="mx-3 my-1 flex items-center justify-between">
                  <h4 className="font-semibold text-gray-900">Click on the references links below to open documents in new tab.</h4>
                </div>
                <div className='mx-2 my-4'>

                  {request?.research_output?.citations
                    .filter((ref) => !(ref?.title?.includes('.json') && ref?.title?.includes('metadata')))
                    .map((ref) => {
                      const Icon = DISPLAY_TEXT[ref?.source_type]?.icon || FileText;
                      const color = DISPLAY_TEXT[ref?.source_type]?.color || "Gray";
                      const sourceTitle = DISPLAY_TEXT[ref?.source_type]?.title || "Knowledge Base";

                      return (
                        <div
                          key={ref?.index}
                          className="flex items-center gap-2 p-1 transition" title={sourceTitle}
                        >
                          <Icon className={`h-5 w-5 shrink-0 ${color}`} />

                          <a
                            href={ref?.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline text-sm font-medium truncate"
                          >
                            {ref?.title}
                          </a>
                        </div>
                      );
                    })}

                </div>
              </div>) : (
                <p className="text-sm text-gray-500 italic">Key messages will be displayed here once the draft is ready.</p>
              )}
            </div>
          )}

          {/* Review Configuration */}
          {activeView === 'reviews' && (
            <div className="space-y-6">
              {/* Review Type Selection */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Select Review Types <span className="text-red-500">*</span></h4>
                <p className="text-sm text-gray-500 mb-4">Choose which reviews are required for this document. Legal review will start after CA review is complete.</p>

                <div className="space-y-4">
                  {/* No Review Option */}
                  <div className={`border-2 rounded-lg p-4 transition-all ${selectedReviews.noReview ? 'border-pmi-blue bg-blue-50' : 'border-gray-200'}`}>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedReviews.noReview}
                        onChange={() => handleReviewToggle('noReview')}
                        className="mt-1 h-4 w-4 text-pmi-blue rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">No Review</p>
                        <p className="text-sm text-gray-500">Skip review process and proceed directly</p>
                      </div>
                    </label>
                  </div>

                  {/* CA Review */}
                  <div className={`border-2 rounded-lg p-4 transition-all ${selectedReviews.ca ? 'border-pmi-blue bg-blue-50' : 'border-gray-200'}`}>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedReviews.ca}
                        onChange={() => handleReviewToggle('ca')}
                        className="mt-1 h-4 w-4 text-pmi-blue rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{REVIEW_TYPES.ca.label}</p>
                        <p className="text-sm text-gray-500">{REVIEW_TYPES.ca.description}</p>
                      </div>
                    </label>

                    {/* CA Sub-types */}
                    {selectedReviews.ca && (
                      <div className="mt-4 ml-7 space-y-3">
                        <p className="text-sm font-medium text-gray-700">Select CA Review Types (runs in parallel):</p>
                        <div className="grid grid-cols-3 gap-3">
                          {Object.entries(REVIEW_TYPES.ca.subTypes).map(([key, subType]) => (
                            <label
                              key={key}
                              className={`flex items-center gap-2 p-3 border-2 rounded-lg cursor-pointer transition-all ${selectedCASubTypes[key] ? 'border-pmi-blue bg-white' : 'border-gray-200 bg-white'
                                }`}
                            >
                              <input
                                type="checkbox"
                                checked={selectedCASubTypes[key]}
                                onChange={() => handleCASubTypeToggle(key)}
                                className="h-4 w-4 text-pmi-blue rounded"
                              />
                              <div>
                                <p className="text-sm font-medium text-gray-900">{subType.label}</p>
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Legal Review */}
                  <div className={`border-2 rounded-lg p-4 transition-all ${selectedReviews.legal ? 'border-pmi-blue bg-blue-50' : 'border-gray-200'}`}>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedReviews.legal}
                        onChange={() => handleReviewToggle('legal')}
                        className="mt-1 h-4 w-4 text-pmi-blue rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{REVIEW_TYPES.legal.label}</p>
                        <p className="text-sm text-gray-500">{REVIEW_TYPES.legal.description}</p>
                      </div>
                    </label>
                  </div>
                </div>

                {!isAnyReviewSelected() && (
                  <p className="mt-3 text-sm text-amber-600 flex items-center gap-1">
                    <AlertCircle className="h-4 w-4" />
                    Please select at least one review type
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Tone & Compliance Checks */}
      {/* <div className="grid grid-cols-2 gap-4">
        <div className="border border-gray-200 rounded-lg p-4">
          <h4 className="font-semibold text-gray-900 mb-3 text-sm">Tone Analysis</h4>
          <div className="space-y-2">
            {Object.entries(toneAnalysis.dimensions || { 'Formality': 'High', 'Neutrality': 'Maintained', 'Evidence-Based': 'Strong', 'Non-Promotional': 'Compliant' }).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between text-sm">
                <span className="text-gray-600">{key}</span>
                <span className="font-medium text-green-600">{value}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="border border-gray-200 rounded-lg p-4">
          <h4 className="font-semibold text-gray-900 mb-3 text-sm">Pre-Review Checks</h4>
          <div className="space-y-2">
            {[
              'Citations properly formatted',
              'Statutory warnings present',
              'No promotional language',
              'Audience-appropriate tone',
            ].map((check, idx) => (
              <div key={idx} className="flex items-center gap-2 text-sm text-green-700">
                <CheckCircle className="h-4 w-4 flex-shrink-0" />
                {check}
              </div>
            ))}
          </div>
        </div>
      </div> */}

      {/* Reviewer Input */}
      <div className="border border-gray-200 rounded-lg p-5">
        <h4 className="font-semibold text-gray-900 mb-3">Feedback</h4>
        <textarea
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          rows={3}
          placeholder="Provide overall feedback on the draft — structure, messaging, tone, missing content, etc."
          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
        />
      </div>

      {/* Decision Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
        <button
          onClick={() => handleDecision('reject')}
          disabled={submitting || feedback.length > 0}
          className="flex items-center gap-2 px-5 py-2.5 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 font-medium text-sm disabled:opacity-50"
        >
          {(submitting == "reject") ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />}
          Reject Draft
        </button>
        <div className="flex gap-3">
          <button
            onClick={() => handleDecision('revise')}
            disabled={submitting || feedback.length == 0}
            className="flex items-center gap-2 px-5 py-2.5 border border-amber-300 text-amber-700 rounded-lg hover:bg-amber-50 font-medium text-sm disabled:opacity-50"
          >
            {(submitting == "revise") ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
            Draft Revision
          </button>
          <button
            onClick={() => handleDecision('approve')}
            disabled={submitting || feedback.length > 0}
            className="flex items-center gap-2 px-5 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium text-sm disabled:opacity-50"
          >
            {(submitting == "approve") ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
            Approve Draft
          </button>
        </div>
      </div>
    </div>
  )
}

export default HITLDraftReview
