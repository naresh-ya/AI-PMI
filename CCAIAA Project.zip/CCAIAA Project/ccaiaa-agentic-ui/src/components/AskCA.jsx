import { useState, useEffect, useRef } from "react";
import {
  Send,
  Plus,
  Share,
  Mic,
  MicOff,
  FileText,
  X,
  Loader2,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import LoadingSpinner from "./ui/LoadingSpinner";
import ChatMessageBubble from "./ChatMessageBubble";
import ScrollToLatestButton from "./ui/ScrollToLatestButton";
import useAutoScrollChat from "../hooks/useAutoScrollChat";
import useSpeechRecognition from "../hooks/useSpeechRecognition";
import { getSuggestions } from "../utils/wordSuggestions";
import {
  createNewChat,
  sendUserMessage,
  pollAgentResponse,
  getAllMessages,
  getCategories,
  getCategoryMetaData,
} from "../services/api";

const HELP_ITEMS = [
  {
    icon: "📜",
    text: "Explain tobacco laws, regulations, and compliance obligations",
  },
  {
    icon: "🏛️",
    text: "Answer questions about government notifications and policies",
  },
  {
    icon: "🏭",
    text: "Guide manufacturing and operational compliance requirements",
  },
  {
    icon: "🚚",
    text: "Provide distribution, licensing, and supply chain guidance",
  },
  { icon: "📄", text: "Generate compliance documents and reports" },
  { icon: "🔍", text: "Research new tobacco product regulations" },
  { icon: "⚖️", text: "Summarize legal and regulatory updates" },
];

// Turns whatever getCategories() (the /draft/categories endpoint) returns
// into the shape the options row renders: { label, message }. The endpoint's
// exact response isn't pinned down in the codebase, so accept the common
// shapes — a bare array, or one wrapped under a `categories`/`data` key,
// whose items are either plain strings or objects with a name-ish field.
// `label` is shown on the chip; `message` is what gets sent to the agent
// when that chip is clicked.
function normalizeDraftCategories(response) {
  const rawList = Array.isArray(response)
    ? response
    : response?.categories || response?.data || [];
  return rawList
    .map((item) => {
      const label =
        typeof item === "string"
          ? item
          : item?.name ||
            item?.label ||
            item?.title ||
            item?.category ||
            item?.id;
      if (!label) return null;
      return {
        label,
        message: `Generate a ${label} draft based on our conversation so far.`,
      };
    })
    .filter(Boolean);
}

const DEFAULT_WELCOME_MESSAGE = [
  {
    role: "assistant",
    content:
      "Hello! I'm your AI assistant for PMI Corporate Affairs. I help you with requests, draft documents, internal updates and navigate corporate affairs workflows.",
    timestamp: new Date(),
    assistant_message_id: null,
    isStreaming: false,
  },
];

// Polling config for a still-in-progress assistant response (status
// "PENDING" + a job_id, per the backend's own message shape — see
// pollForPendingMessage below).
const POLL_INTERVAL_MS = 3000;
const POLL_TIMEOUT_MS = 2 * 60 * 1000; // 2 minutes
const TIMEOUT_MESSAGE =
  "Sorry, this is taking longer than expected. Please try again.";

// Converts the API's message shape into the shape ChatMessageBubble expects.
// Pure function (no state) so it can be reused by the initial-load effect
// without depending on component state.
//
// `status` and `job_id` are carried through as-is (rather than dropped)
// specifically so a conversation can be re-opened — even after a full page
// reload — and still know whether its last assistant message is actually
// done or still being generated on the backend, without any separate
// "pending" flag of our own to keep in sync. See the polling effect below,
// which scans for exactly these two fields.
function deriveMessagesFromApi(messages) {
  if (!messages || messages.length === 0) return DEFAULT_WELCOME_MESSAGE;
  const allMessages = [];
  messages.forEach((message) => {
    switch (message?.role) {
      case "assistant":
        allMessages.push({
          role: message?.role,
          content: message?.status === "PENDING" ? "loading" : message?.content,
          timestamp: new Date(message?.created_at),
          assistant_message_id: message?.message_id,
          status: message?.status,
          job_id: message?.job_id,
          // History is rendered instantly — only the live in-flight
          // answer gets the typing/reveal treatment.
          isStreaming: false,
        });
        break;
      case "user":
        allMessages.push({
          role: message?.role,
          content: message?.content,
          timestamp: new Date(message?.created_at),
          user_message_id: message?.message_id,
        });
        break;
    }
  });
  // API returns newest-first; render in normal chronological order
  // (oldest -> newest) so the message list can use a simple top-to-
  // bottom scroll container with a reliable bottom sentinel.
  return allMessages.reverse();
}

function deriveChatTitle(messageText) {
  const trimmed = (messageText || "").trim();
  const MAX_TITLE_LENGTH = 60;
  return trimmed.length > MAX_TITLE_LENGTH
    ? `${trimmed.slice(0, MAX_TITLE_LENGTH).trimEnd()}...`
    : trimmed;
}

function AskCA() {
  const {
    state,
    addConversation,
    setSelectedConversationId,
    updateConversation,
    setConversationMessages,
    updateConversationMessages,
    replaceConversationId,
  } = useApp();
  const {
    user,
    selectedConversationId,
    chatConversations,
    loading,
    // Message cache lives in AppContext (not local component state)
    // specifically so it survives AskCA unmounting — e.g. navigating to
    // another page and coming back within a session — instead of
    // resetting to empty every time this component remounts.
    messagesByConversationId,
  } = state;
  const [chatInput, setChatInput] = useState("");
  const [initialChatsLoading, setInitialChatsLoading] = useState(false);
  const [creatingChat, setCreatingChat] = useState(false);
  // Whether the "Generate Draft" options row is showing above the input.
  // Toggled on from a message's three-dots menu (see the onGenerateDraft
  // prop passed to ChatMessageBubble below), which also kicks off the
  // getCategories() fetch that populates it.
  const [showDraftOptions, setShowDraftOptions] = useState(false);
  const [draftCategories, setDraftCategories] = useState([]);
  const [draftCategoriesLoading, setDraftCategoriesLoading] = useState(false);
  const [draftCategoriesError, setDraftCategoriesError] = useState(false);
  const chatInputRef = useRef(null);
  // ─── Word autosuggestion (client-side, no backend/API involved) ────────
  // Suggests completions for the word currently being typed at the cursor
  // (not the whole sentence) — see src/utils/wordSuggestions.js. Purely a
  // client-side wordlist prefix match, so this adds no latency, cost, or
  // network dependency.
  const [wordSuggestions, setWordSuggestions] = useState([]);
  const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(0);
  // Whether the currently selected conversation is still a client-side-only
  // placeholder (see Layout.jsx's "Create New Chat" button) with no real
  // backend conversation behind it yet. Derived from chatConversations
  // (which lives in AppContext) rather than local component state, so this
  // correctly survives AskCA unmounting and remounting — e.g. navigating
  // away right after creating a new chat and coming back a few seconds
  // later still knows to create the real conversation on first send.
  const selectedConversation = chatConversations.find(
    (c) => c.conversation_id === selectedConversationId,
  );
  const isNewChat = Boolean(selectedConversation?.is_placeholder);
  // Tracks the most recently requested conversation id for the message-load
  // effect below, so a slow/older fetch resolving after the user has since
  // switched to a different chat doesn't stomp that newer chat's messages.
  const latestRequestedConversationIdRef = useRef(null);

  const chatMessages = messagesByConversationId[selectedConversationId] || [];
  // Whether *this* conversation has a response still in flight — derived
  // straight from its last message's own status/job_id (the same fields
  // the backend itself uses), rather than a separate "pending" flag kept
  // in sync by hand. This means the loading state is correct even right
  // after a page reload: whatever was actually pending on the backend
  // when the page went away is still reflected the moment messages are
  // (re)loaded, with no extra bookkeeping required.
  const lastMessage = chatMessages[chatMessages.length - 1];
  const responseLoading = Boolean(
    lastMessage?.role === "assistant" && lastMessage?.status === "PENDING",
  );
  // Mirrors pendingConversationIds' old job — lets the polling effect below
  // read which conversations currently have a poll running without
  // depending on that set directly (which would re-run the effect on every
  // tick instead of only when a new pending conversation shows up).
  const activePollsRef = useRef({});

  // ─── Auto-growing input (Copilot-style) ────────────────────────────────
  // Starts at a single line and grows with content up to MAX_INPUT_HEIGHT,
  // after which the textarea itself scrolls instead of growing further.
  const MAX_INPUT_HEIGHT = 160; // px (~7 lines)

  // ─── Full-height chat shell ─────────────────────────────────────────────
  // Sized directly off the viewport (rather than relying on every ancestor
  // in Layout/Dashboard to correctly propagate a flex height) so the chat
  // card always starts exactly below the fixed top bar and never overlaps
  // it, regardless of intermediate wrapper markup.
  const HEADER_HEIGHT_PX = 64; // Layout's top bar is h-16 (4rem)
  const BOTTOM_GAP_PX = 12; // small breathing room below the input/card
  useEffect(() => {
    const el = chatInputRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, MAX_INPUT_HEIGHT)}px`;
  }, [chatInput]);

  // Recomputes word-completion suggestions for the word currently being
  // typed at the cursor position — not the whole input, so suggestions
  // stay relevant when editing text in the middle of a longer message.
  // Cheap enough (small array filter) to run on every keystroke without
  // debouncing.
  const updateWordSuggestions = (value, cursorPosition) => {
    const textBeforeCursor = value.slice(0, cursorPosition);
    const currentWordMatch = textBeforeCursor.match(/[A-Za-z-]+$/);
    const currentWord = currentWordMatch ? currentWordMatch[0] : "";
    setWordSuggestions(currentWord ? getSuggestions(currentWord) : []);
    setActiveSuggestionIndex(0);
  };

  // Replaces the in-progress word at the cursor with the chosen suggestion
  // (keeping everything before/after it intact), then re-focuses the
  // textarea with the cursor placed right after the inserted word.
  const applySuggestion = (suggestion) => {
    const el = chatInputRef.current;
    const cursorPosition = el ? el.selectionStart : chatInput.length;
    const textBeforeCursor = chatInput.slice(0, cursorPosition);
    const textAfterCursor = chatInput.slice(cursorPosition);
    const currentWordMatch = textBeforeCursor.match(/[A-Za-z-]+$/);
    const wordStart = currentWordMatch
      ? cursorPosition - currentWordMatch[0].length
      : cursorPosition;
    const nextValue =
      chatInput.slice(0, wordStart) + suggestion + " " + textAfterCursor;
    setChatInput(nextValue);
    setWordSuggestions([]);
    // Move the cursor to just after the inserted word (+1 for the trailing
    // space) once React has applied the new value.
    requestAnimationFrame(() => {
      const newCursorPosition = wordStart + suggestion.length + 1;
      el?.focus();
      el?.setSelectionRange(newCursorPosition, newCursorPosition);
    });
  };

  // ─── Smart auto-scroll (Copilot/ChatGPT style) ─────────────────────────
  // containerRef -> attach to the scrollable message list.
  // bottomRef -> sentinel element rendered after the last message.
  // shouldAutoScroll -> true while the user is anchored to the bottom.
  // showJumpButton -> true once the user has scrolled away from the bottom.
  // scrollToBottomIfAllowed -> call after any content growth; respects lock.
  // jumpToBottom -> forces a scroll + re-enables auto-scroll (button click).
  const {
    containerRef,
    bottomRef,
    showJumpButton,
    scrollToBottomIfAllowed,
    jumpToBottom,
  } = useAutoScrollChat({ threshold: 100 });

  const handleCreateNewChat = async () => {
    try {
      setCreatingChat(true);
      const newChatResponse = await createNewChat(
        user?.email?.replace("@", "").replace(/\./g, "_"),
      );
      // Shows up in the sidebar right away with the backend's own title.
      addConversation(newChatResponse);
      setSelectedConversationId(newChatResponse?.conversation_id);
    } catch (error) {
      console.log(error);
    } finally {
      setCreatingChat(false);
    }
  };

  // Polls a single in-flight job to completion (or gives up after
  // POLL_TIMEOUT_MS) and writes the result back into the conversation's
  // last assistant message. Used both right after sending a message *and*
  // by the recovery effect below for a job that was already pending when
  // its conversation's messages loaded (e.g. after a page reload) — same
  // logic either way, since both cases boil down to "a job_id is pending,
  // keep checking until it's done."
  //
  // `activePollsRef` guards against starting a second poll loop for a
  // job_id that's already being polled (e.g. the recovery effect firing
  // again as the user switches chats back and forth).
  const pollForPendingMessage = async (conversationId, jobId) => {
    if (!jobId || activePollsRef.current[jobId]) return;
    activePollsRef.current[jobId] = true;
    const startedAt = Date.now();

    try {
      let pollAgent = true;
      while (pollAgent) {
        if (Date.now() - startedAt >= POLL_TIMEOUT_MS) {
          updateConversationMessages(conversationId, (prev) => {
            const updated = [...prev];
            const idx = updated.findIndex((m) => m.job_id === jobId);
            if (idx === -1) return prev;
            updated[idx] = {
              ...updated[idx],
              content: TIMEOUT_MESSAGE,
              status: "ERROR",
              isStreaming: false,
            };
            return updated;
          });
          return;
        }

        const agentResponseStatus = await pollAgentResponse(
          jobId,
          user?.email?.replace("@", "").replace(/\./g, "_"),
        );
        if (agentResponseStatus.status.toLowerCase() === "completed") {
          pollAgent = false;
          updateConversationMessages(conversationId, (prev) => {
            const updated = [...prev];
            const idx = updated.findIndex((m) => m.job_id === jobId);
            if (idx === -1) return prev;
            updated[idx] = {
              ...updated[idx],
              content: agentResponseStatus?.assistant_message?.content,
              status: "COMPLETED",
              timestamp:
                new Date(agentResponseStatus?.assistant_message?.updated_at) ||
                new Date(),
              // Flags this message to type out via useStreamingText
              // instead of rendering instantly — the actual Copilot/
              // ChatGPT-style "streaming" reveal happens inside
              // ChatMessageBubble.
              isStreaming: true,
            };
            return updated;
          });
          // No longer force-navigates back to conversationId — if the
          // user has since switched to another chat, they stay right
          // where they are. Whenever they do come back to this chat,
          // they'll see the completed response waiting for them (or the
          // loading bubble, if it's still in flight).
        } else {
          await delay(POLL_INTERVAL_MS);
        }
      }
    } catch (error) {
      console.log(error);
      updateConversationMessages(conversationId, (prev) => {
        const updated = [...prev];
        const idx = updated.findIndex((m) => m.job_id === jobId);
        if (idx === -1) return prev;
        updated[idx] = {
          ...updated[idx],
          content: TIMEOUT_MESSAGE,
          status: "ERROR",
          isStreaming: false,
        };
        return updated;
      });
    } finally {
      delete activePollsRef.current[jobId];
    }
  };

  const handleSendMessage = async (overrideText) => {
    // Capture the conversation + text this send belongs to up front. Every
    // update below targets `targetConversationId` explicitly (never "the
    // currently selected conversation") so switching chats mid-send/poll
    // has no effect on where the placeholder/response ends up — it always
    // lands back in the conversation that actually sent it, ready to view
    // whenever the user returns to it.
    //
    // `overrideText` lets callers send a message that isn't the currently
    // typed input — e.g. the "Generate Draft" quick options. When it's used
    // we deliberately leave whatever the user has typed in the input alone.
    const isOverride = typeof overrideText === "string";
    const messageText = isOverride ? overrideText : chatInput;
    if (!messageText.trim()) return;
    if (!isOverride) {
      setChatInput("");
    }
    setWordSuggestions([]);
    let targetConversationId = "";

    try {
      if (isNewChat) {
        // The sidebar's "New Chat" button (see Layout.jsx) creates a fake,
        // client-side-only conversation id before any backend conversation
        // exists. Sending the first message is what actually creates the
        // real backend conversation — replaceConversationId() swaps that
        // fake id out for the real one everywhere it's tracked (sidebar
        // list, selectedConversationId, any cached messages/pending state),
        // so the message we're about to send lands in a conversation the
        // UI is actually still pointed at, rather than a real conversation
        // the fake id never gets connected to.
        const placeholderConversationId = selectedConversationId;
        const newChatResponse = await createNewChat(
          user?.email?.replace("@", "").replace(/\./g, "_"),
        );
        replaceConversationId(placeholderConversationId, newChatResponse);
        targetConversationId = newChatResponse?.conversation_id;
        // The backend names a conversation after its first message, but
        // that title only becomes available once the send completes
        // server-side (and previously required a full page reload to pick
        // up). Since this send is what's actually creating the real
        // conversation, set the sidebar title right now from the message
        // being sent — mirrors the backend's own convention and updates
        // instantly instead of waiting on a reload.
        updateConversation({
          ...newChatResponse,
          title: deriveChatTitle(messageText),
        });
      } else {
        targetConversationId = selectedConversationId;
      }

      updateConversationMessages(targetConversationId, (prev) => [
        ...prev,
        {
          role: "user",
          content: messageText,
          timestamp: new Date(),
          user_message_id: null,
        },
      ]);
      // Sending a message is a deliberate user action — always jump to the
      // latest message and re-enable auto-scroll, even if the user had
      // scrolled up to read earlier history (matches ChatGPT/Copilot). Only
      // do this if we're still looking at the conversation being sent to.
      if (selectedConversationId === targetConversationId || isNewChat) {
        jumpToBottom("auto");
      }

      const chatResponse = await sendUserMessage(
        targetConversationId,
        messageText,
        user?.email?.replace("@", "").replace(/\./g, "_"),
      );
      // NOTE: object copies (not in-place mutation) below are important —
      // ChatMessageBubble is memoized on message identity, so mutating an
      // existing message object in place would prevent it from re-rendering
      // when its content/streaming state changes.
      updateConversationMessages(targetConversationId, (prev) => {
        const updated = prev.map((m, i) =>
          i === prev.length - 1
            ? { ...m, user_message_id: chatResponse?.user_message_id }
            : m,
        );
        return [
          ...updated,
          {
            role: "assistant",
            content: "loading",
            timestamp: new Date(),
            assistant_message_id: chatResponse?.assistant_message_id,
            status: "PENDING",
            job_id: chatResponse?.job_id,
          },
        ];
      });

      if (chatResponse?.job_id) {
        pollForPendingMessage(targetConversationId, chatResponse.job_id);
      }
    } catch (error) {
      if (targetConversationId) {
        // Mark the placeholder as errored rather than leaving it stuck on
        // "loading" forever, since there's no job_id to poll/recover it.
        updateConversationMessages(targetConversationId, (prev) => {
          const updated = [...prev];
          const lastIdx = updated.length - 1;
          if (updated[lastIdx]?.role === "assistant" && !updated[lastIdx]?.job_id) {
            updated[lastIdx] = {
              ...updated[lastIdx],
              content: TIMEOUT_MESSAGE,
              status: "ERROR",
            };
          }
          return updated;
        });
      }
      console.log(error);
    }
  };

  const delay = (duration) => {
    return new Promise((resolve) => {
      setTimeout(resolve, duration);
    });
  };

  // Opens the draft-options row (triggered from a message's three-dots
  // "Generate Draft" action) and loads the available draft categories from
  // the backend via getCategories(). Fetches fresh each time it's opened so
  // the list always reflects what the server currently offers.
  const openDraftOptions = async () => {
    setShowDraftOptions(true);
    // Bring the chat down to the latest message so the options row (and the
    // form that follows) is in view — even if "Generate Draft" was clicked on
    // a response higher up in the history. Deferred a frame so the options row
    // has rendered (which shifts the layout) before we scroll.
    requestAnimationFrame(() => jumpToBottom("smooth"));
    setDraftCategoriesError(false);
    setDraftCategoriesLoading(true);
    try {
      const response = await getCategories(
        user?.email?.replace("@", "").replace(/\./g, "_"),
      );
      setDraftCategories(normalizeDraftCategories(response));
    } catch (error) {
      console.log(error);
      setDraftCategoriesError(true);
    } finally {
      setDraftCategoriesLoading(false);
    }
  };

  // Handles a category chip click: adds the chosen category as a chat message
  // in the current conversation, then fetches that category's metadata via
  // getCategoryMetaData(). Guarded like the send button — ignored while a
  // response is still in flight, and only within a real conversation.
  const handleDraftOptionClick = async (option) => {
    if (responseLoading || !selectedConversationId) return;
    setShowDraftOptions(false);

    const targetConversationId = selectedConversationId;
    const category = option.label;
    // Unique id so the placeholder can be found and swapped for the finished
    // form (or an error message) once the metadata request resolves.
    const formMessageId = `draft-form-${Date.now()}`;

    // Add the selected category as a chat message, plus a loading placeholder
    // for the form that's being fetched.
    updateConversationMessages(targetConversationId, (prev) => [
      ...prev,
      {
        role: "user",
        content: category,
        timestamp: new Date(),
        user_message_id: null,
      },
      {
        role: "assistant",
        content: "loading",
        timestamp: new Date(),
        assistant_message_id: formMessageId,
        isStreaming: false,
      },
    ]);
    if (selectedConversationId === targetConversationId) {
      jumpToBottom("auto");
    }

    // Fetch the category's metadata and turn its schema into a dynamic form.
    try {
      const metadata = await getCategoryMetaData(
        category,
        user?.email?.replace("@", "").replace(/\./g, "_"),
      );
      if (!metadata?.schema) throw new Error("Missing form schema");
      updateConversationMessages(targetConversationId, (prev) =>
        prev.map((m) =>
          m.assistant_message_id === formMessageId
            ? {
                role: "assistant",
                type: "draft_form",
                category: metadata?.category || category,
                formSchema: metadata.schema,
                conversation_id: targetConversationId,
                content: "",
                timestamp: new Date(),
                assistant_message_id: formMessageId,
                isStreaming: false,
              }
            : m,
        ),
      );
    } catch (error) {
      console.log(error);
      updateConversationMessages(targetConversationId, (prev) =>
        prev.map((m) =>
          m.assistant_message_id === formMessageId
            ? {
                ...m,
                content:
                  "Sorry, I couldn't load the form for this category. Please try again.",
                status: "ERROR",
              }
            : m,
        ),
      );
    }
  };

  // Persists `isStreaming: false` onto the stored message once its typing
  // reveal actually finishes (see ChatMessageBubble's onStreamComplete).
  // Without this, the cached message keeps `isStreaming: true` forever —
  // useStreamingText reads that flag fresh every time the bubble mounts,
  // so switching away from this chat and back (or any other remount)
  // would otherwise replay the whole typing animation from scratch instead
  // of just rendering the finished text instantly, the same as any other
  // piece of history.
  const handleStreamComplete = (conversationId, targetMessage) => {
    if (!conversationId || !targetMessage?.isStreaming) return;
    const targetMessageId = targetMessage.assistant_message_id;
    updateConversationMessages(conversationId, (prev) =>
      prev.map((m) =>
        (targetMessageId && m.assistant_message_id === targetMessageId) ||
        m === targetMessage
          ? { ...m, isStreaming: false }
          : m,
      ),
    );
  };

  // ─── Voice input (Web Speech API — free, built into the browser) ───────
  // Appends each finalized spoken phrase onto whatever's already typed,
  // with a separating space so multiple phrases don't run together.
  const { isSupported: isVoiceInputSupported, isListening, toggleListening } =
    useSpeechRecognition({
      onResult: (transcript) => {
        setChatInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
      },
      onError: (error) => {
        console.log("Speech recognition error:", error);
      },
    });

  const handleVoiceInputClick = () => {
    if (!isVoiceInputSupported) {
      console.log("Voice input is not supported in this browser");
      return;
    }
    toggleListening();
  };

  // Re-run the "scroll to bottom if the user is anchored there" check on
  // every chatMessages change: new user message, new placeholder, content
  // filled in on completion. Streamed reveal ticks are handled separately
  // via ChatMessageBubble's onStreamTick (see below) so the view keeps
  // following along smoothly as text types out, not just on message boundaries.
  useEffect(() => {
    scrollToBottomIfAllowed("auto");
  }, [chatMessages, scrollToBottomIfAllowed]);

  // Switching to a different conversation dismisses the "Generate Draft"
  // options row so it doesn't linger across chats.
  useEffect(() => {
    setShowDraftOptions(false);
  }, [selectedConversationId]);

  // If a conversation's last message is still "PENDING" (a job that was in
  // flight when the tab was last closed/reloaded, or simply still
  // running), resume polling for it — pollForPendingMessage is a no-op if
  // that job_id is already being polled, so this is safe to call every
  // time a conversation's messages come into view.
  const checkAndResumePendingPoll = (conversationId, messages) => {
    const last = messages?.[messages.length - 1];
    if (last?.role === "assistant" && last?.status === "PENDING" && last?.job_id) {
      pollForPendingMessage(conversationId, last.job_id);
    }
  };

  // Fetch messages for the currently selected conversation whenever it
  // changes (covers both the initial load and any conversation picked from
  // the sidebar). Two things keep this from glitching when the user
  // switches chats mid-send:
  //  1. If the conversation's messages are already cached (because a
  //     send/poll is in flight, or it was simply opened before), the fetch
  //     is skipped entirely — re-fetching here would otherwise wipe out
  //     the locally-held "loading" placeholder with whatever the backend
  //     had saved *before* this send started.
  //  2. `requestedConversationId` is captured per-invocation and compared
  //     against the ref before applying the result, so if the user
  //     switches away and back (or to a third chat) before a slower fetch
  //     resolves, that stale response can't overwrite newer state.
  //
  // Either way — freshly fetched or already cached — once the messages for
  // this conversation are in view, checkAndResumePendingPoll looks at the
  // last message: if it's still "PENDING" (a job that was in flight when
  // the page was last reloaded, or one that's simply still running),
  // polling is kicked off/resumed for it right here. This is what replaces
  // the old separate pendingConversationIds flag — the pending state now
  // always comes from the message data itself.
  useEffect(() => {
    if (!selectedConversationId) return;

    const requestedConversationId = selectedConversationId;
    latestRequestedConversationIdRef.current = requestedConversationId;

    // Already have this conversation's messages cached in context — either
    // fetched earlier this session, or written to directly by
    // handleSendMessage. Because this cache lives in AppContext (not local
    // component state), it survives AskCA unmounting entirely — e.g.
    // navigating to another page and coming back — so this is what makes
    // "go away for 10 seconds and come back" show the exact same chat
    // instead of re-fetching (and briefly blanking/reloading) it.
    if (messagesByConversationId[requestedConversationId]) {
      jumpToBottom("auto");
      checkAndResumePendingPoll(
        requestedConversationId,
        messagesByConversationId[requestedConversationId],
      );
      return;
    }

    const loadConversationMessages = async () => {
      try {
        setInitialChatsLoading(true);
        const allMessagesResponse = await getAllMessages(
          requestedConversationId,
          user?.email?.replace("@", "").replace(/\./g, "_"),
        );
        if (latestRequestedConversationIdRef.current !== requestedConversationId) {
          return; // A newer conversation switch has already superseded this fetch.
        }
        const loadedMessages = deriveMessagesFromApi(
          allMessagesResponse?.messages,
        );
        setConversationMessages(requestedConversationId, loadedMessages);
        checkAndResumePendingPoll(requestedConversationId, loadedMessages);
        // Opening/switching a conversation should land on the latest
        // message instantly (no smooth animation) and re-enable follow mode.
        jumpToBottom("auto");
      } catch (error) {
        if (latestRequestedConversationIdRef.current !== requestedConversationId) {
          return;
        }
        if (error?.message?.toLowerCase() == "conversation not found") {
          // A brand new chat (client-side placeholder id, or a real
          // conversation that hasn't received its first message yet) has
          // nothing to fetch — show the welcome message and let the next
          // send create/populate it for real. (Whether this conversation
          // still needs a real backend id created on next send is tracked
          // via its `is_placeholder` flag, not here.)
          setConversationMessages(requestedConversationId, DEFAULT_WELCOME_MESSAGE);
        }
      } finally {
        if (latestRequestedConversationIdRef.current === requestedConversationId) {
          setInitialChatsLoading(false);
        }
      }
    };
    loadConversationMessages();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedConversationId]);

  return (
    <div
      className="flex flex-col min-h-0"
      style={{
        height: `calc(100vh - ${HEADER_HEIGHT_PX}px - ${BOTTOM_GAP_PX}px)`,
      }}
    >
      {/* Full-screen centered loader overlay while chats are loading */}
      {initialChatsLoading && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-white/70 backdrop-blur-sm">
          <LoadingSpinner message="Loading chats..." />
        </div>
      )}
      <div className="relative bg-white flex flex-col flex-1 min-h-0 min-w-0 overflow-hidden">
        {/* Tab Content */}
        <div className="flex flex-col flex-1 min-h-0 min-w-0">
          {chatConversations.length === 0 && !loading?.conversations ? (
            /* No conversations yet — welcome screen with Create New Chat */
            <div className="flex-1 overflow-y-auto p-4 flex items-center justify-center">
              <div className="max-w-xl text-center">
                <h1 className="text-4xl font-semibold text-gray-900 mb-2">
                  Welcome to CA Workbench
                </h1>
                <p className="text-sm text-gray-500 mb-6">
                  Get instant guidance on regulatory requirements, manufacturing
                  compliance, product approvals, taxation, licensing, and
                  distribution regulations.
                </p>
                <p className="text-sm font-semibold text-gray-700 mb-3 text-left">
                  How I can help
                </p>
                <ul className="space-y-2 text-left mb-6">
                  {HELP_ITEMS.map((item, idx) => (
                    <li
                      key={idx}
                      className="flex items-start gap-2 text-sm text-gray-700"
                    >
                      <span className="text-base">{item.icon}</span>
                      <span>{item.text}</span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={handleCreateNewChat}
                  disabled={creatingChat}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-pmi-blue to-pmi-navy text-white rounded-xl hover:shadow-md disabled:opacity-40 transition-all text-sm font-medium"
                >
                  <Plus className="h-4 w-4" />
                  {creatingChat ? "Creating..." : "Create New Chat"}
                </button>
              </div>
            </div>
          ) : (
            /* Chat Messages — scrollable, chronological (oldest -> newest) */
            <div
              ref={containerRef}
              className="flex flex-col flex-1 min-w-0 overflow-y-auto overflow-x-hidden p-5 space-y-4"
            >
              {chatMessages.map((msg, idx) => (
                <ChatMessageBubble
                  key={
                    msg.assistant_message_id ||
                    msg.user_message_id ||
                    `${msg.role}-${idx}`
                  }
                  msg={msg}
                  responseLoading={responseLoading}
                  userInitial={user?.name?.charAt(0)}
                  onStreamTick={scrollToBottomIfAllowed}
                  onStreamComplete={() =>
                    handleStreamComplete(selectedConversationId, msg)
                  }
                  onGenerateDraft={openDraftOptions}
                  conversationId={selectedConversationId}
                />
              ))}
              {/* Bottom sentinel — scrollIntoView target for auto-scroll */}
              <div ref={bottomRef} />
            </div>
          )}

          {/* Floating "jump to latest" button — bottom-right of the chat card */}
          {chatConversations.length > 0 && (
            <ScrollToLatestButton
              visible={showJumpButton}
              onClick={() => jumpToBottom("smooth")}
              hasNewContent={responseLoading}
            />
          )}

          {/* Chat Input */}
          {chatConversations.length > 0 && (
            <div className="sticky bottom-0 z-10 p-4 bg-white">
              {/* "Generate Draft" options — revealed from a message's
                  three-dots menu. The categories are fetched live from
                  getCategories() (the /draft/categories endpoint); clicking
                  one sends it to the agent as a normal chat message. */}
              {showDraftOptions && (
                <div className="mb-3 flex flex-wrap items-center gap-2">
                  <span className="text-xs font-medium text-gray-500">
                    Content type or categories
                  </span>
                  {draftCategoriesLoading ? (
                    <span className="inline-flex items-center gap-1.5 text-xs text-gray-500">
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Loading categories...
                    </span>
                  ) : draftCategoriesError ? (
                    <span className="inline-flex items-center gap-2 text-xs text-red-500">
                      Couldn't load categories.
                      <button
                        type="button"
                        onClick={openDraftOptions}
                        className="font-medium text-pmi-blue hover:text-pmi-navy underline"
                      >
                        Try again
                      </button>
                    </span>
                  ) : draftCategories.length === 0 ? (
                    <span className="text-xs text-gray-500">
                      No draft categories available.
                    </span>
                  ) : (
                    draftCategories.map((option) => (
                      <button
                        key={option.label}
                        type="button"
                        onClick={() => handleDraftOptionClick(option)}
                        disabled={responseLoading || !selectedConversationId}
                        className="inline-flex items-center gap-1.5 rounded-full border border-pmi-blue/30 bg-pmi-blue/5 px-3 py-1.5 text-xs font-medium text-pmi-blue hover:bg-pmi-blue/10 disabled:opacity-40 transition-colors"
                      >
                        <FileText className="h-3.5 w-3.5" />
                        {option.label}
                      </button>
                    ))
                  )}
                  <button
                    type="button"
                    onClick={() => setShowDraftOptions(false)}
                    title="Dismiss"
                    className="ml-auto inline-flex items-center justify-center rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
              <div className="flex items-center gap-3">
                <div className="relative flex-1 min-w-0">
                  <textarea
                    ref={chatInputRef}
                    rows={1}
                    value={chatInput}
                    onChange={(e) => {
                      setChatInput(e.target.value);
                      updateWordSuggestions(
                        e.target.value,
                        e.target.selectionStart,
                      );
                    }}
                    disabled={
                      responseLoading ||
                      initialChatsLoading ||
                      !selectedConversationId
                    }
                    // Native browser spellcheck (red squiggly underline +
                    // right-click suggestions) — free, no library, no API
                    // call. This is the "spelling checks" feature; it's
                    // fully handled by the browser/OS, we're just opting in
                    // explicitly rather than relying on the default.
                    spellCheck="true"
                    lang="en"
                    onKeyDown={(e) => {
                      // While word-completion suggestions are showing,
                      // arrow keys navigate them and Tab/Enter accepts the
                      // highlighted one instead of their normal behavior
                      // (moving focus / sending the message).
                      if (wordSuggestions.length > 0) {
                        if (e.key === "ArrowDown") {
                          e.preventDefault();
                          setActiveSuggestionIndex(
                            (prev) => (prev + 1) % wordSuggestions.length,
                          );
                          return;
                        }
                        if (e.key === "ArrowUp") {
                          e.preventDefault();
                          setActiveSuggestionIndex(
                            (prev) =>
                              (prev - 1 + wordSuggestions.length) %
                              wordSuggestions.length,
                          );
                          return;
                        }
                        if (e.key === "Tab" || e.key === "Enter") {
                          e.preventDefault();
                          applySuggestion(wordSuggestions[activeSuggestionIndex]);
                          return;
                        }
                        if (e.key === "Escape") {
                          setWordSuggestions([]);
                          return;
                        }
                      }
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    onBlur={() => setWordSuggestions([])}
                    placeholder={isListening ? "Listening..." : "Message CA Workbench..."}
                    // h-11 (44px) matches the mic/send buttons' own h-11
                    // below exactly, rather than relying on matching
                    // padding to happen to add up to the same height —
                    // that's what was still leaving them a couple pixels
                    // off center against each other. py-2.5 recentres the
                    // single line of text within that fixed height; the
                    // textarea still grows past it (up to
                    // MAX_INPUT_HEIGHT) as more text is typed, same as
                    // before.
                    className="no-scrollbar w-full h-11 px-3 py-2.5 border border-gray-300 rounded-lg text-sm resize-none overflow-y-auto leading-relaxed focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
                    style={{ maxHeight: `${MAX_INPUT_HEIGHT}px` }}
                  />
                  {/* Word-completion suggestions — click, or Tab/Enter the
                      highlighted item, to accept. Positioned above the
                      input so it never gets clipped by the input's own
                      max-height/scroll. */}
                  {wordSuggestions.length > 0 && (
                    <div className="absolute bottom-full left-0 mb-1 w-fit min-w-[8rem] max-w-xs rounded-lg border border-gray-200 bg-white shadow-lg overflow-hidden z-20">
                      {wordSuggestions.map((suggestion, idx) => (
                        <button
                          key={suggestion}
                          type="button"
                          // Prevents the textarea's onBlur from firing (and
                          // dismissing the list) before the click registers.
                          onMouseDown={(e) => e.preventDefault()}
                          onClick={() => applySuggestion(suggestion)}
                          className={`w-full text-left px-3 py-1.5 text-sm transition-colors ${
                            idx === activeSuggestionIndex
                              ? "bg-pmi-blue/10 text-pmi-blue"
                              : "text-gray-700 hover:bg-gray-100"
                          }`}
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={handleVoiceInputClick}
                  disabled={
                    !isVoiceInputSupported ||
                    responseLoading ||
                    initialChatsLoading ||
                    !selectedConversationId
                  }
                  title={
                    !isVoiceInputSupported
                      ? "Voice input isn't supported in this browser"
                      : isListening
                        ? "Listening... Click to stop speech-to-text conversion"
                        : "Use voice input (speech-to-text)"
                  }
                  // h-11 w-11 matches the textarea's own h-11 exactly (see
                  // above) and keeps this button square; flex/items-center/
                  // justify-center centers the icon within that fixed box
                  // instead of relying on padding to do it.
                  className={`h-11 w-11 flex items-center justify-center flex-shrink-0 border rounded-xl transition-all disabled:opacity-40 ${
                    isListening
                      ? "text-red-600 border-red-300 bg-red-50 hover:bg-red-100 animate-pulse"
                      : "text-gray-500 border-gray-300 hover:bg-gray-100 hover:text-gray-700"
                  }`}
                >
                  {isListening ? (
                    <MicOff className="h-4 w-4" />
                  ) : (
                    <Mic className="h-4 w-4" />
                  )}
                </button>
                {chatInput.trim() && (
                  <button
                    onClick={() => handleSendMessage()}
                    disabled={responseLoading || !selectedConversationId}
                    // Same h-11 w-11 + centering treatment as the mic
                    // button above, so all three controls sit on the exact
                    // same vertical center.
                    className="h-11 w-11 flex items-center justify-center flex-shrink-0 bg-gradient-to-r from-pmi-blue to-pmi-navy text-white rounded-xl hover:shadow-md disabled:opacity-40 transition-all"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                )}
              </div>
              <p className="text-xs text-gray-400 mt-2 text-center">
                AI-generated content may contain inaccuracies. Review important
                details before relying on it.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default AskCA;
