import { useEffect, useRef, useState } from "react";
import { json, useNavigate } from "react-router-dom";
import {
  Eye,
  EyeOff,
  LogIn,
  Loader2,
  Shield,
  Bot,
  FileText,
  CheckCircle,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import pmiLogo from "../assets/pmi-white.png";
import { DEMO_USERS } from "../utils/constants";
import { loginWithCognito } from "../services/cognitoService";

/**
 * Login Page for PMI Corporate Affairs – Agentic AI Platform
 *
 * Professional PMI-branded login with email/password authentication.
 * On success, navigates to the Dashboard.
 */

function Login() {
  const navigate = useNavigate();
  const { login } = useApp();
  const topRef = useRef();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const handleLogin = async () => {
    await loginWithCognito();
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError("");
      const result = await loginWithCognito(email, password);
      if (!result.success) {
        setError("Authentication failed");
        return;
      }
      const user = {
        username: result.user.username,
        email,
      };
      login(user);

      navigate("/", {
        replace: true,
      });
    } catch (error) {
      setError(error.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = (user) => {
    topRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
    setEmail(user.email.toLowerCase());
    setPassword(user.password);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel — Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-pmi-navy via-[#002a7a] to-pmi-blue relative overflow-hidden">
        {/* Decorative shapes */}
        <div className="absolute inset-0">
          <div className="absolute top-[-10%] right-[-15%] w-[500px] h-[500px] rounded-full bg-white/[0.03]" />
          <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] rounded-full bg-white/[0.02]" />
          <div className="absolute top-[40%] right-[20%] w-[200px] h-[200px] rounded-full bg-white/[0.04]" />
        </div>

        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          {/* Top: Logo + Headline grouped together */}
          <div className="space-y-8 pt-4">
            <div className="inline-block">
              <img src={pmiLogo} alt="PMI" className="h-40" />
            </div>

            {/* Headline */}
            <h1 className="text-4xl font-bold text-white leading-tight mb-4 max-w-lg !mt-0">
              AskSpidy
              <br />
              <span className="text-blue-200">Agentic AI Platform</span>
            </h1>
            <p className="text-blue-200/80 text-lg leading-relaxed mb-8 max-w-lg">
              AI-powered document generation for government advocacy, regulatory
              submissions, and policy communications — with human oversight at
              every step.
            </p>

            {/* Feature highlights */}
            <div className="space-y-4 max-w-lg">
              {[
                {
                  icon: Bot,
                  text: "Multi-agent workflow: Researcher → Drafter → Reviewer",
                },
                {
                  icon: Shield,
                  text: "Human-in-the-Loop approval at every critical gate",
                },
                {
                  icon: FileText,
                  text: "6 broad categories of document",
                },
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="h-4.5 w-4.5 text-blue-200" />
                  </div>
                  <span className="text-white/80 text-sm">{feature.text}</span>
                </div>
              ))}
            </div>
          </div>{" "}
          {/* end grouped logo+content */}
          {/* Bottom: Footer */}
          <div className="text-blue-300/50 text-xs">
            © {new Date().getFullYear()} Philip Morris International. Internal
            use only. Confidential.
          </div>
        </div>
      </div>

      {/* Right Panel — Login Form */}
      <div
        className="flex-1 flex items-center justify-center p-8 bg-gray-50"
        ref={topRef}
      >
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center justify-center mb-8">
            <img src={pmiLogo} alt="PMI Corporate Affairs" className="h-14" />
          </div>

          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Welcome!</h2>
              <p className="text-sm text-gray-500 mt-1">
                Sign in to your Corporate Affairs account
              </p>
            </div>
            <button
              type="submit"
              disabled={loading}
              onClick={handleLogin}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-pmi-blue text-white rounded-lg font-semibold text-sm hover:bg-pmi-navy transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                <>
                  <LogIn className="h-4 w-4" />
                  Sign In
                </>
              )}
            </button>
            {/* <form onSubmit={handleLogin} className="space-y-5">
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                    <span className="text-red-600 text-xs font-bold">!</span>
                  </div>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              )}

              <div>
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-700 mb-1.5"
                >
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  autoFocus
                  value={email}
                  // Lowercased as the user types — every other component
                  // reads the logged-in user's email straight off
                  // AppContext's state.user.email (see login() below), so
                  // normalizing case right here guarantees it's lowercase
                  // everywhere downstream (API calls, reviewer-email
                  // matching, etc.) with no changes needed anywhere else.
                  onChange={(e) => setEmail(e.target.value.toLowerCase())}
                  placeholder="name@pmi.com"
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent transition-shadow placeholder:text-gray-400 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-gray-700 mb-1.5"
                >
                  Password
                </label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent transition-shadow placeholder:text-gray-400 pr-11 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4.5 w-4.5" />
                    ) : (
                      <Eye className="h-4.5 w-4.5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300 text-pmi-blue focus:ring-pmi-blue"
                  />
                  <span className="text-sm text-gray-600">Remember me</span>
                </label>
                <button
                  type="button"
                  className="text-sm text-pmi-blue hover:text-pmi-navy font-medium"
                >
                  Forgot password?
                </button>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-pmi-blue text-white rounded-lg font-semibold text-sm hover:bg-pmi-navy transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  <>
                    <LogIn className="h-4 w-4" />
                    Sign In
                  </>
                )}
              </button>
            </form> */}

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200" />
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="px-3 bg-white text-gray-400">
                  or sign in with
                </span>
              </div>
            </div>

            {/* SSO */}
            <button
              type="button"
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <svg className="h-5 w-5" viewBox="0 0 21 21" fill="none">
                <path d="M10 0H0V10H10V0Z" fill="#F25022" />
                <path d="M21 0H11V10H21V0Z" fill="#7FBA00" />
                <path d="M10 11H0V21H10V11Z" fill="#00A4EF" />
                <path d="M21 11H11V21H21V11Z" fill="#FFB900" />
              </svg>
              Continue with Microsoft SSO
            </button>
          </div>

          {/* Demo Credentials */}
          {/* <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p className="text-xs font-semibold text-blue-800 mb-2.5 uppercase tracking-wide">
              Demo Credentials
            </p>
            <div className="space-y-2">
              {DEMO_USERS.filter((user) => user.isVisible).map((user, idx) => (
                <button
                  key={idx}
                  onClick={() => handleDemoLogin(user)}
                  className="w-full flex items-center justify-between px-3 py-2 bg-white rounded-lg border border-blue-100 hover:border-blue-300 hover:shadow-sm transition-all text-left group"
                >
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {user.name}
                    </p>
                    <p className="text-xs text-gray-500">{user.roleTitle}</p>
                  </div>
                  <span className="text-xs text-blue-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    Use →
                  </span>
                </button>
              ))}
            </div>
            <p className="text-xs text-blue-600/70 mt-2.5">
              Click a user above to auto-fill credentials, then press Sign In.
            </p>
          </div> */}
        </div>
      </div>
    </div>
  );
}

export default Login;
