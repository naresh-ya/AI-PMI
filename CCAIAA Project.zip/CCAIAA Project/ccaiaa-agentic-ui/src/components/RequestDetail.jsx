import { useState, useEffect, useCallback, useMemo } from "react";
import { useParams, Link, useNavigate, useLocation } from "react-router-dom";
import {
  ArrowLeft,
  FileText,
  Globe,
  Calendar,
  Clock,
  AlertCircle,
  RefreshCw,
  Shield,
  Ban,
} from "lucide-react";
import { getRequest, getHITLContent } from "../services/api";
import {
  getMockRequestById,
  getMockHITLCheckpoints,
  getReviewsByRequestId,
} from "../data/mockData";
import { useApp } from "../context/AppContext";
import LoadingSpinner from "./ui/LoadingSpinner";
import GeneratedDocument from "./GeneratedDocument";
import HITLResearchReview from "./HITLResearchReview";
import HITLDraftReview from "./HITLDraftReview";
import HITLFinalReview, { ROLES } from "./HITLFinalReview";
import { STATUS_LIST } from "../utils/constants";

// Infers which specialist reviewer role a request's current `status` (the
// STATUS_LIST keys in constants.js, e.g. "CA_SCIENTIFIC_PENDING",
// "LEGAL_REVIEW_IN_PROGRESS") corresponds to, by keyword. Used only when the
// viewer arrived via the Approval Queue (see cameFromApprovals below) — an
// assigned reviewer should never see HITLFinalReview as the "normal
// user"/requestor.
//
// Falls back to LEGAL_REVIEWER when the status has no reviewer-specific
// keyword in it (e.g. "REVIEW_NOT_STARTED", "CA_REVIEW_IN_PROGRESS" name a
// stage, not a specific sub-reviewer) — any reviewer role satisfies "not
// normal user"; Legal is the final gate so it's a reasonable default here.
function inferReviewerRoleFromStatus(status) {
  const s = (status || "").toUpperCase();
  if (s.includes("SCIENTIFIC")) return ROLES.SCIENTIFIC_REVIEWER;
  if (s.includes("REGULATORY")) return ROLES.REGULATORY_REVIEWER;
  if (s.includes("COMMUNICATION")) return ROLES.COMMUNICATION_REVIEWER;
  if (s.includes("FISCAL")) return ROLES.FISCAL_REVIEWER;
  if (s.includes("LEGAL")) return ROLES.LEGAL_REVIEWER;
  return ROLES.LEGAL_REVIEWER;
}

function RequestDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { state, setCurrentRequest, updateRequest, addToast } = useApp();

  const [loading, setLoading] = useState(true);
  const [request, setRequest] = useState(null);
  const [activeTab, setActiveTab] = useState(null);
  const [hitlCheckpoints, setHitlCheckpoints] = useState([]);
  const [pendingHITL, setPendingHITL] = useState(null);
  const [pendingReviews, setPendingReviews] = useState(null);

  const location = useLocation();
  const isDuplicate = location.state?.isDuplicate;
  // True only when navigated here from the Approval Queue (see the `state`
  // passed by its Link in ApprovalQueue.jsx). Arriving from anywhere else
  // (Dashboard, a direct link, etc.) is always treated as the normal
  // user/requestor.
  const cameFromApprovals = location.state?.from === "approvals";

  // Fetch request data
  const fetchRequest = useCallback(async () => {
    setLoading(true);
    // Load from local state / mock data immediately for instant display
    const localRequest = state.requests.find(
      (r) => (r.request_id || String(r.id)) === id,
    );
    const mockRequest = getMockRequestById(id);
    const immediate = localRequest || mockRequest;

    if (immediate) {
      setRequest(immediate);
      setCurrentRequest(immediate);
    }

    // Then try the live API — if it succeeds, update with fresh data
    try {
      const data = await getRequest(id);
      switch (data?.status) {
        case "DRAFTING_COMPLETED":
        case "REVIEW_CHANGES_REQUESTED":
        case "LEGAL_REVIEW_IN_PROGRESS":
        case "CA_REVIEW_IN_PROGRESS":
        case "REVIEW_NOT_STARTED":
          setActiveTab("reviewHITL");
          break;
        case "DRAFT_REVIEW_PENDING":
        case "RESEARCH_REVIEW_PENDING":
          setActiveTab("hitl");
          break;
        case "COMPLETED":
        case "DRAFT_APPROVED":
          setActiveTab("document");
          break;
        // Nothing to show while the Drafter Agent is (re-)generating —
        // explicitly reset activeTab to null rather than leaving it
        // unmatched, which would otherwise keep whatever tab was active
        // from BEFORE this status (e.g. still showing a stale
        // "under review" reviewer box after a redraft was kicked off from
        // the REVIEW_CHANGES_REQUESTED screen).
        case "DRAFTING_IN_PROGRESS":
        case "RE_DRAFT_IN_PROGRESS":
          setActiveTab(null);
          break;
      }
      setRequest(data);
      setCurrentRequest(data);
    } catch {
      // API unavailable — keep the already-loaded local/mock data
      if (!immediate) {
        addToast({ type: "error", message: "Failed to load request details." });
      }
    } finally {
      setLoading(false);
    }
  }, [id]);

  // Fetch HITL checkpoints
  const fetchHITLCheckpoints = useCallback(async () => {
    // Load mock checkpoints immediately
    if (
      (STATUS_LIST[request?.status]?.backendStatus ==
        "Research Review Pending" ||
        STATUS_LIST[request?.status]?.backendStatus ==
          "Draft Review Pending") &&
      request.current_hitl_id
    ) {
      const mockCheckpoints = getMockHITLCheckpoints(id);
      if (mockCheckpoints.length > 0) {
        setHitlCheckpoints(mockCheckpoints);
        const pending = mockCheckpoints.find((c) => c.status === "pending");
        setPendingHITL(pending || null);
      }

      // Then try the live API
      try {
        const data = await getHITLContent(
          request?.current_hitl_id,
          request?.status,
        );
        const checkpoints = [data];
        setHitlCheckpoints(checkpoints);

        const pending = checkpoints.find((c) => c.status === "pending");
        setPendingHITL(pending || null);
      } catch (error) {
        console.log("error in fetching hitl", error);
        // API unavailable — keep already-loaded mock checkpoints
      }
    }
  }, [id, request]);

  useEffect(() => {
    fetchRequest();
  }, [fetchRequest]);

  useEffect(() => {
    if (request) {
      fetchHITLCheckpoints();
    }
  }, [request, fetchHITLCheckpoints]);

  // Derives the reviewer-input state (pendingReviews) straight from the
  // request's own `review` sub-object — the backend embeds it directly on
  // the request (see getRequest()'s response), so no separate fetch is
  // needed. Its field names already line up exactly with what
  // HITLFinalReview.jsx reads/writes: scientificReview, regulatoryReview,
  // communicationReview, fiscalReview, legalReview, status, assigned_to.
  //
  // Copied via spread (not just re-assigned by reference) because
  // HITLFinalReview mutates its `pendingReviews` prop directly in its
  // submit_review handler (e.g. `pendingReviews.legalReview = feedback`) —
  // without the copy, that mutation would silently write straight into
  // `request.review`, which is meant to be treated as request state.
  //
  // Falls back to null when the request has no review yet (e.g. it hasn't
  // reached a review stage) — every consumer of pendingReviews (see
  // areReviewsPending below, and HITLFinalReview) is guarded for that.
  useEffect(() => {
    setPendingReviews(request?.review ? { ...request.review } : null);
  }, [request]);

  const handleHITLDecisionComplete = (action) => {
    // Refresh data after HITL decision
    setTimeout(() => {
      fetchRequest();
      fetchHITLCheckpoints();
    }, 1000);
    //setActiveTab("timeline");
  };

  // Moves an approved draft on to CA/Legal review. Updates local request
  // state, the shared app context, and switches the tab to the "Reviews
  // Pending" view so the new status is immediately reflected.
  const handleProceedToReview = () => {
    const updated = { ...request, status: "REVIEW_NOT_STARTED" };
    setRequest(updated);
    setCurrentRequest(updated);
    updateRequest(updated);
    setActiveTab("reviewHITL");
    addToast({
      type: "success",
      title: "Sent for Review",
      message: "Request has been moved to CA and Legal review.",
    });
  };

  // Status badge helper
  const getStatusBadge = (status, statusCode) => {
    const map = {
      Incomplete: {
        bg: "bg-gray-100",
        text: "text-gray-600",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Research: {
        bg: "bg-blue-100",
        text: "text-blue-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Draft: {
        bg: "bg-violet-100",
        text: "text-violet-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Review: {
        bg: "bg-orange-100",
        text: "text-orange-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      Completed: {
        bg: "bg-emerald-100",
        text: "text-emerald-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
      HITL: {
        bg: "bg-purple-100",
        text: "text-purple-700",
        label: STATUS_LIST[statusCode]?.backendStatus,
      },
    };
    const s = map[status] || {
      bg: "bg-gray-100",
      text: "text-gray-700",
      label: STATUS_LIST[statusCode]?.backendStatus || "NOT AVAILABLE",
    };
    return (
      <span
        className={`px-3 py-1 rounded-full text-xs font-medium ${s.bg} ${s.text}`}
      >
        {s.label}
      </span>
    );
  };

  // Determine which HITL component to show
  const getHITLComponent = () => {
    if (!pendingHITL) return null;

    const agentName = pendingHITL.agent_name || "";

    const status = STATUS_LIST[request?.status]?.backendStatus;

    if (status == "Research Review Pending") {
      return (
        <HITLResearchReview
          request={request}
          checkpoint={pendingHITL}
          onDecisionComplete={handleHITLDecisionComplete}
        />
      );
    }
    if (status == "Draft Review Pending") {
      return (
        <HITLDraftReview
          request={request}
          checkpoint={pendingHITL}
          onDecisionComplete={handleHITLDecisionComplete}
        />
      );
    }

    return <></>;
  };

  // Determine available tabs
  const getAvailableTabs = () => {
    const tabs = [];

    if (STATUS_LIST[request?.status]?.backendStatus == "Drafting Completed") {
      tabs.push({
        key: "document",
        label: "Document",
        icon: FileText,
        badge: "Ready",
      });
    }

    if (
      pendingHITL &&
      (request?.status == "RESEARCH_REVIEW_PENDING" ||
        request?.status == "DRAFT_REVIEW_PENDING")
    ) {
      tabs.push({
        key: "hitl",
        label: "Review Required",
        icon: Shield,
        badge: "!",
      });
    }

    if (STATUS_LIST[request?.status]?.cardStatus == "Review") {
      tabs.push({
        key: "reviewHITL",
        label: "Reviews Pending",
        icon: Shield,
        badge: "!",
      });
    }

    // tabs.push({ key: "timeline", label: "Timeline", icon: Clock });

    return tabs;
  };

  if (loading) {
    return <LoadingSpinner fullPage message="Loading request details..." />;
  }

  if (!request) {
    return (
      <div className="px-6 lg:px-8 py-16 text-center">
        <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          Request Not Found
        </h2>
        <p className="text-gray-600 mb-6">
          The request you're looking for doesn't exist or has been removed.
        </p>
        <Link to="/" className="text-pmi-blue hover:text-pmi-navy font-medium">
          ← Back to Dashboard
        </Link>
      </div>
    );
  }
  const progress = STATUS_LIST[request?.status]?.progress || 0;
  const agentWorkflow = request.agentWorkflow || request.agent_workflow || [];
  const timeline = request.timeline || [];

  return (
    <div className="px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <div className="mb-4">
        <Link
          to="/"
          className="flex items-center text-sm text-gray-500 hover:text-gray-700"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Dashboard
        </Link>
      </div>

      {isDuplicate && (
        <div class="flex items-start gap-3 text-yellow-800 p-4 rounded-md">
          <svg
            class="w-5 h-5 mt-0.5 text-yellow-500"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l6.518 11.59c.75 1.334-.213 2.99-1.742 2.99H3.48c-1.53 0-2.492-1.656-1.743-2.99l6.52-11.59zM11 13a1 1 0 10-2 0 1 1 0 002 0zm-1-6a1 1 0 00-.993.883L9 8v3a1 1 0 001.993.117L11 11V8a1 1 0 00-1-1z" />
          </svg>
          <p class="text-sm">
            If you go back or close this tab, your current request will be lost
            permanently.
          </p>
        </div>
      )}

      {/* Request Header Card */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <FileText className="h-6 w-6 text-pmi-blue" />
              <h1 className="text-2xl font-bold text-gray-900">
                {request?.topic}
              </h1>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
              <span className="flex items-center">
                <Globe className="h-4 w-4 mr-1" />
                {request?.jurisdiction}
              </span>
              {request?.deadline && (
                <span className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  Due: {new Date(request?.deadline).toLocaleDateString()}
                </span>
              )}
              {request?.topic && (
                <span className="bg-gray-100 px-2 py-0.5 rounded text-xs">
                  {`${request?.topic}`}
                </span>
              )}
              {request?.priority && (
                <span
                  className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                    request?.priority === "high"
                      ? "bg-red-100 text-red-700"
                      : request.priority === "medium"
                        ? "bg-amber-100 text-amber-700"
                        : "bg-gray-100 text-gray-700"
                  }`}
                >
                  {request?.priority} priority
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setLoading(true);
                fetchRequest();
                fetchHITLCheckpoints();
              }}
              className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
              title="Refresh"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
            {getStatusBadge(
              STATUS_LIST[request?.status]?.cardStatus,
              request?.status,
            )}
          </div>
        </div>

        {/* Progress Bar */}
        {STATUS_LIST[request.status]?.progress != null &&
          STATUS_LIST[request.status]?.progress < 100 && (
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span className="font-medium">Overall Progress</span>
                <span className="font-semibold">{progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-500 ${progress === 100 ? "bg-green-500" : "bg-blue-500"}`}
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>
          )}

        {/* Background */}
        {request?.validation_result?.background && (
          <div className="border-t border-gray-200 pt-4">
            <p className="text-sm font-medium text-gray-700 mb-1">Background</p>
            <p className="text-sm text-gray-600">
              {request?.validation_result?.background}
            </p>
          </div>
        )}
      </div>

      {/* Status Banner */}
      {request?.status == "VALIDATION_FAILED" ||
      request?.status == "CANCELLED" ? (
        <div className="text-center py-12 text-gray-400">
          <Ban className="h-12 w-12 mx-auto mb-3 opacity-50" />
          <p className="text-sm">
            This request is no longer active, so no further processing will take
            place.
          </p>
        </div>
      ) : /* Tabs — for active/processing requests */
      activeTab ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200">
            <nav
              className="flex space-x-1 px-4 overflow-x-auto"
              aria-label="Tabs"
            >
              {getAvailableTabs().map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-2 py-3 px-4 border-b-2 font-medium text-sm whitespace-nowrap transition-colors ${
                    activeTab === tab.key
                      ? "border-pmi-blue text-pmi-blue"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  {tab.label}
                  {tab.badge && (
                    <span
                      className={`ml-1 px-1.5 py-0.5 text-xs rounded-full font-bold ${
                        tab.badge === "!"
                          ? "bg-red-100 text-red-700 animate-pulse"
                          : "bg-green-100 text-green-700"
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {/* Timeline Tab */}
            {activeTab === "timeline" && (
              <div className="space-y-4">
                {timeline.length > 0 ? (
                  timeline.map((event, idx) => (
                    <div key={idx} className="flex items-start space-x-4">
                      <div className="flex flex-col items-center">
                        <div
                          className={`w-3 h-3 rounded-full ${
                            event.type === "user"
                              ? "bg-pmi-blue"
                              : event.type === "system"
                                ? "bg-gray-400"
                                : "bg-green-500"
                          }`}
                        ></div>
                        {idx < timeline.length - 1 && (
                          <div className="w-0.5 h-12 bg-gray-300"></div>
                        )}
                      </div>
                      <div className="flex-1 pb-4">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-900">
                            {event.event}
                          </p>
                          <span className="text-xs text-gray-500">
                            {event.time}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 text-gray-400">
                    <Clock className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">
                      Timeline events will appear here as the request is
                      processed.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* HITL Review Tab */}
            {activeTab === "hitl" &&
              (pendingHITL ? (
                getHITLComponent()
              ) : (
                <div className="text-center py-12 text-gray-400">
                  <Shield className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm font-medium text-gray-600">
                    No review action required at this time.
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    You'll be notified when an agent needs your input.
                  </p>
                </div>
              ))}

            {/* Document Tab */}
            {activeTab === "document" && (
              <GeneratedDocument
                request={request}
                onProceedToReview={handleProceedToReview}
              />
            )}

            {activeTab === "reviewHITL" && (
              <HITLFinalReview
                request={request}
                pendingReviews={pendingReviews}
                onDecisionComplete={handleHITLDecisionComplete}
                // Arriving from the Approval Queue means this viewer is an
                // assigned reviewer, not the requestor — infer which
                // reviewer role from the request's own status (see
                // inferReviewerRoleFromStatus above) rather than using the
                // logged-in user's own account role. Any other entry point
                // (Dashboard, direct link, etc.) keeps the account's real
                // role, i.e. the normal user/requestor.
                role={
                  cameFromApprovals
                    ? inferReviewerRoleFromStatus(request?.status)
                    : state.user?.role
                }
                email={state.user?.email}
              />
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export default RequestDetail;
