import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle, Globe, Calendar, FileText, RefreshCw, AlertCircle, User, ChevronRight } from 'lucide-react'
import { getAssignedReviews } from '../services/api'
import { useApp } from '../context/AppContext'
import LoadingSpinner from './ui/LoadingSpinner'

// "LEGAL_REVIEW_IN_PROGRESS" -> "Legal Review In Progress"
function formatLabel(value) {
  if (!value) return ''
  return value
    .toLowerCase()
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ')
}

function getStatusBadgeClasses(status) {
  const s = (status || '').toUpperCase()
  if (s.includes('APPROVED') || s.includes('COMPLETED')) return 'bg-green-100 text-green-700'
  if (s.includes('REJECTED') || s.includes('FAILED')) return 'bg-red-100 text-red-700'
  if (s.includes('PROGRESS') || s.includes('PENDING') || s.includes('NOT_STARTED')) return 'bg-amber-100 text-amber-700'
  return 'bg-gray-100 text-gray-700'
}

// Normalizes one entry from getAssignedReviews()'s `requests` array into the
// row shape this page renders. Confirmed response shape:
//   {
//     reviewer, reviewer_name, role, review_type, count,
//     requests: [{
//       request_id, topic, jurisdiction, category, deadline, requested_by,
//       review_type, review_id, assigned_to, status, updated_at, created_at
//     }]
//   }
function normalizeAssignedReview(item) {
  return {
    requestId: item?.request_id,
    reviewId: item?.review_id,
    topic: item?.topic || 'Untitled request',
    jurisdiction: item?.jurisdiction,
    category: item?.category,
    deadline: item?.deadline,
    requestedBy: item?.requested_by,
    reviewType: item?.review_type,
    status: item?.status,
  }
}

function ApprovalQueue() {
  const { state, addToast } = useApp()
  const [approvals, setApprovals] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState(false)

  // Loads the current reviewer's assigned-review queue —
  // GET https://y97ca45wk1.execute-api.eu-west-1.amazonaws.com/dev/reviews/assigned?reviewer=<email>
  const fetchApprovals = useCallback(async () => {
    if (!state.user?.email) {
      setLoading(false)
      return
    }
    setLoading(true)
    setLoadError(false)
    try {
      const response = await getAssignedReviews(state.user.email)
      const requests = Array.isArray(response?.requests) ? response.requests : []
      setApprovals(requests.map(normalizeAssignedReview))
    } catch (error) {
      console.log(error)
      setLoadError(true)
      addToast({ type: 'warning', message: 'Failed to load your review queue.' })
    } finally {
      setLoading(false)
    }
  }, [state.user?.email]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    fetchApprovals()
  }, [fetchApprovals])

  return (
    <div className="px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-1">Approval Queue</h1>
          <p className="text-gray-600">Requests assigned to you for review</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500">{approvals.length} pending</span>
          <button
            onClick={fetchApprovals}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {loading ? (
        <div className="p-12">
          <LoadingSpinner message="Loading pending approvals..." />
        </div>
      ) : loadError ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <AlertCircle className="h-12 w-12 text-red-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Couldn't load your review queue</h3>
          <button
            onClick={fetchApprovals}
            className="mt-2 text-sm text-pmi-blue hover:text-pmi-navy font-medium underline"
          >
            Try again
          </button>
        </div>
      ) : approvals.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">All caught up!</h3>
          <p className="text-gray-600">No pending approvals at this time.</p>
          <Link to="/" className="inline-block mt-4 text-pmi-blue hover:text-pmi-navy font-medium">← Back to Dashboard</Link>
        </div>
      ) : (
        <div className="space-y-4">
          {approvals.map((approval) => (
            <Link
              key={approval.requestId}
              to={`/request/${approval.requestId}`}
              // Tags this navigation so RequestDetail knows the viewer
              // arrived here as an assigned reviewer (not the requestor) —
              // see inferReviewerRoleFromStatus in RequestDetail.jsx, which
              // uses this to pick a specific reviewer role instead of
              // "normal user".
              state={{ from: "approvals" }}
              className="block bg-white rounded-lg shadow-sm border border-gray-200 hover:border-pmi-blue/40 hover:shadow-md transition-all p-5"
            >
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900 truncate">{approval.topic}</h3>
                    {approval.status && (
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap ${getStatusBadgeClasses(approval.status)}`}>
                        {formatLabel(approval.status)}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500">
                    {approval.jurisdiction && (
                      <span className="flex items-center gap-1">
                        <Globe className="h-3.5 w-3.5" />
                        {approval.jurisdiction}
                      </span>
                    )}
                    {approval.category && (
                      <span className="text-xs bg-gray-100 px-2 py-0.5 rounded">{approval.category}</span>
                    )}
                    {approval.reviewType && (
                      <span className="text-xs bg-pmi-light text-pmi-blue px-2 py-0.5 rounded font-medium">
                        {formatLabel(approval.reviewType)}
                      </span>
                    )}
                    {approval.deadline && (
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        Due: {new Date(approval.deadline).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      {approval.requestedBy && (
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          Requested by {approval.requestedBy}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <FileText className="h-3 w-3" />
                        {approval.requestId}
                      </span>
                    </div>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-300 flex-shrink-0" />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}

export default ApprovalQueue
