import { useEffect, useRef, useState } from "react";
import { Loader2, Send, AlertCircle, CheckCircle2 } from "lucide-react";
import { useApp } from "../context/AppContext";
import {
  draftFormCheck,
  generateDraft,
  pollDraftJobStatus,
  getDraftDownloadUrl,
} from "../services/api";
import LoadingSpinner from "./ui/LoadingSpinner";

// How often to poll /jobs/{job_id} for the draft-generation job's status.
const DRAFT_POLL_INTERVAL_MS = 3000;
// Safety cutoff so a stuck job doesn't poll forever (mirrors
// POLL_TIMEOUT_MS in AskCA's chat-message polling).
const DRAFT_POLL_TIMEOUT_MS = 2 * 60 * 1000; // 2 minutes

// Normalizes whatever getDraftDownloadUrl() returns into a plain URL string.
// Its exact response shape isn't pinned down in the codebase yet, so accept
// the common key names rather than assuming one.
function extractDownloadUrl(response) {
  if (typeof response === "string") return response;
  return (
    response?.download_url ||
    response?.downloadUrl ||
    response?.url ||
    response?.presigned_url ||
    ""
  );
}

// Triggers a real browser navigation to `url` via a throwaway <a> click,
// rather than fetch()-then-blob: `url` is a presigned S3 URL (a different
// origin), so fetch() would need the S3 bucket to return
// Access-Control-Allow-Origin for the browser to let this code read the
// response bytes. A real navigation isn't subject to CORS at all, and the
// presigned URL already carries `response-content-disposition: attachment;
// filename=...` in its query string, so the browser names + saves the file
// on its own — no blob handling needed.
function triggerBrowserDownload(url) {
  const link = document.createElement("a");
  link.href = url;
  link.rel = "noopener noreferrer";
  document.body.appendChild(link);
  link.click();
  link.remove();
}

/**
 * ChatDraftForm
 * ---------------------------------------------------------------------------
 * Renders a dynamic draft-request form from a category metadata schema (the
 * shape returned by getCategoryMetaData — see AskCA). It builds inputs from
 * `schema.mandatory_fields` and `schema.optional_fields`, then on submit runs
 * a multi-step backend flow with the same payload:
 *
 *   {
 *     category,
 *     form_fields: { <field id>: <value>, ... },
 *     conversation_id,
 *     user_id
 *   }
 *
 *   1. draftFormCheck() — validates the filled form. Returns e.g.
 *      { status: "success", category, missing_fields: [] }. Only when
 *      status is "success" AND missing_fields is empty do we proceed.
 *   2. generateDraft() — kicks off draft generation. It returns immediately
 *      with a job to poll rather than the finished draft:
 *      { job_id, conversation_id, assistant_message_id, status: "PENDING",
 *        message }.
 *   3. pollDraftJobStatus(job_id, user_id) — polled every
 *      DRAFT_POLL_INTERVAL_MS (2s) via pollDraftJob() below, while we show
 *      the app's loading spinner with a "being generated" message, until the
 *      job's status leaves "PENDING" (or a safety timeout elapses):
 *        - "COMPLETED" → proceed to step 4.
 *        - anything else terminal (e.g. "FAILED") → show an error instead of
 *          polling uselessly until the timeout.
 *   4. getDraftDownloadUrl(s3_key, user_id, conversation_id) — once
 *      COMPLETED, fetches a download link using
 *      result_summary.draft_s3_key (the actual generated .docx — NOT
 *      assistant_message.content_s3_key, which is just the chat message's
 *      own text stub) and the job's own conversation_id. The link is then
 *      used to trigger an automatic browser download — no button click
 *      needed.
 *
 * Field state lives locally in this component, so typing into the form never
 * has to round-trip through the parent message list (and the memoized
 * ChatMessageBubble that wraps it).
 */
function ChatDraftForm({ schema, category, conversationId }) {
  const { state } = useApp();
  const { user } = state;

  const mandatoryFields = schema?.mandatory_fields || [];
  const optionalFields = schema?.optional_fields || [];
  const allFields = [...mandatoryFields, ...optionalFields];

  const [values, setValues] = useState(() => {
    const initial = {};
    allFields.forEach((field) => {
      initial[field.id] = "";
    });
    return initial;
  });
  const [errors, setErrors] = useState({});
  // "form" -> filling (and validating), "generating" -> generateDraft POST
  // in flight, "polling" -> got a job_id back, polling /jobs/{job_id} every
  // DRAFT_POLL_INTERVAL_MS until it leaves "PENDING", "downloading" -> job
  // came back "COMPLETED", fetching the download link and triggering the
  // browser download, "error" -> generateDraft returned status "error", had
  // no job_id, the job finished with a non-"COMPLETED" status (e.g.
  // "FAILED"), the poll itself failed/timed out, or the download link
  // couldn't be retrieved.
  const [phase, setPhase] = useState("form");
  const [checking, setChecking] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [downloadDone, setDownloadDone] = useState(false);
  // Guards against updating state after this component has unmounted while
  // a poll is still in flight (e.g. the user navigates away from this chat
  // mid-generation).
  //
  // IMPORTANT: must set `current = true` in the effect body itself, not
  // just via the useRef(true) initializer. In development, React 18
  // StrictMode mounts every component twice (setup → cleanup → setup) to
  // surface unsafe side effects. Without the line below, that first
  // cleanup flips this to `false` and nothing ever flips it back — so the
  // *second* (real) mount starts with isMountedRef.current already false,
  // and every check below it (including the very first one in
  // pollDraftJob) bails out immediately, silently preventing the poll loop
  // from ever running. This is invisible in a production build, since
  // StrictMode's double-invoke is dev-only.
  const isMountedRef = useRef(true);
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const fieldLabel = (id) =>
    allFields.find((field) => field.id === id)?.label || id;

  const handleChange = (id, value) => {
    setValues((prev) => ({ ...prev, [id]: value }));
    // Clear a field's error as soon as the user edits it.
    setErrors((prev) => (prev[id] ? { ...prev, [id]: false } : prev));
    if (errorMessage) setErrorMessage("");
  };

  const validate = () => {
    const nextErrors = {};
    mandatoryFields.forEach((field) => {
      if (!String(values[field.id] ?? "").trim()) {
        nextErrors[field.id] = true;
      }
    });
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const buildPayload = (userId) => {
    // Include every field that actually has a value — mandatory fields are
    // guaranteed filled (validated); empty optional fields are omitted.
    const formFields = {};
    allFields.forEach((field) => {
      const value = values[field.id];
      if (value !== undefined && String(value).trim() !== "") {
        formFields[field.id] = value;
      }
    });
    return {
      category,
      form_fields: formFields,
      conversation_id: conversationId,
      user_id: userId,
    };
  };

  const handleSubmit = async () => {
    if (checking || phase !== "form") return;
    if (!validate()) return;

    setErrorMessage("");
    setChecking(true);
    const userId = user?.email?.replace("@", "").replace(/\./g, "_");
    const payload = buildPayload(userId);

    try {
      // Step 1 — validate the filled form on the backend.
      const checkResult = await draftFormCheck(payload, userId);
      const missing = checkResult?.missing_fields || [];
      const isValid =
        checkResult?.status === "success" && missing.length === 0;

      if (!isValid) {
        if (missing.length > 0) {
          const nextErrors = {};
          missing.forEach((id) => {
            nextErrors[id] = true;
          });
          setErrors((prev) => ({ ...prev, ...nextErrors }));
          setErrorMessage(
            `Please complete the required field(s): ${missing
              .map(fieldLabel)
              .join(", ")}.`,
          );
        } else {
          setErrorMessage(
            "The form couldn't be validated. Please review your entries and try again.",
          );
        }
        setChecking(false);
        return;
      }

      // Step 2 — form is valid, kick off draft generation. It responds
      // immediately with a job to poll rather than the finished draft.
      setChecking(false);
      setPhase("generating");
      const draftResult = await generateDraft(payload, userId);

      // On an error status, show a generic message (we intentionally don't
      // surface the backend's specific error text).
      if (draftResult?.status === "error") {
        setPhase("error");
        return;
      }

      const jobId = draftResult?.job_id;
      if (!jobId) {
        setPhase("error");
        return;
      }

      // Step 3 — poll /jobs/{job_id} every DRAFT_POLL_INTERVAL_MS until the
      // job leaves "PENDING" (or we time out). Keep showing the loading
      // spinner throughout — same UI as the "generating" phase.
      setPhase("polling");
      await pollDraftJob(jobId, userId);
    } catch (error) {
      console.log(error);
      setChecking(false);
      setPhase("form");
      setErrorMessage("Something went wrong. Please try again.");
    }
  };

  // Polls pollDraftJobStatus(job_id, user_id) every DRAFT_POLL_INTERVAL_MS
  // until its `status` is no longer "PENDING", or DRAFT_POLL_TIMEOUT_MS
  // elapses. Mirrors the chat-message polling loop in AskCA
  // (pollForPendingMessage) — same shape, separate function since draft-job
  // polling is a distinct concern (and may need to diverge later).
  const pollDraftJob = async (jobId, userId) => {
    const startedAt = Date.now();

    while (true) {
      if (!isMountedRef.current) return;

      try {
        const jobStatus = await pollDraftJobStatus(jobId, userId);
        if (!isMountedRef.current) return;

        if (jobStatus?.status === "COMPLETED") {
          await downloadCompletedDraft(jobStatus, userId);
          return;
        }

        if (jobStatus?.status && jobStatus.status !== "IN_PROGRESS") {
          // Any other terminal status (e.g. "FAILED") — stop polling
          // immediately rather than continuing to poll a job that's already
          // finished unsuccessfully.
          setPhase("error");
          return;
        }
      } catch (error) {
        console.log(error);
        if (!isMountedRef.current) return;
        setPhase("error");
        setErrorMessage("Something went wrong. Please try again.");
        return;
      }

      await new Promise((resolve) =>
        setTimeout(resolve, DRAFT_POLL_INTERVAL_MS),
      );
    }
  };

  // Job finished successfully — fetch the download link for the generated
  // document and trigger the browser download. Uses
  // result_summary.draft_s3_key (the actual generated .docx) and the job's
  // own conversation_id, per the completed-job payload shape — NOT
  // assistant_message.content_s3_key, which is just the chat message's own
  // text stub, not the document.
  const downloadCompletedDraft = async (jobStatus, userId) => {
    setPhase("downloading");
    const s3Key = jobStatus?.result_summary?.draft_s3_key;
    const jobConversationId = jobStatus?.conversation_id || conversationId;

    if (!s3Key) {
      setPhase("error");
      return;
    }

    try {
      const downloadResult = await getDraftDownloadUrl(
        s3Key,
        userId,
        jobConversationId,
      );
      if (!isMountedRef.current) return;

      const url = extractDownloadUrl(downloadResult);
      if (!url) {
        setPhase("error");
        return;
      }

      triggerBrowserDownload(url);
      setDownloadDone(true);
    } catch (error) {
      console.log(error);
      if (!isMountedRef.current) return;
      setPhase("error");
    }
  };

  // Download link fetched and the browser download was triggered — checked
  // ahead of the "downloading" spinner below, since downloadCompletedDraft
  // never moves `phase` off "downloading" on success (only `downloadDone`
  // flips), so this must win once it's true.
  if (downloadDone) {
    return (
      <div className="inline-flex items-center gap-1.5 text-sm font-medium text-green-600">
        <CheckCircle2 className="h-4 w-4" />
        Your draft has downloaded.
      </div>
    );
  }

  // ─── Generating / polling / downloading / error states ─────────────────
  // Once the form is validated, the form itself is replaced by the app's
  // loading spinner for the initial generateDraft() call ("generating"), the
  // subsequent job polling ("polling"), and fetching the download link
  // ("downloading") — same UI throughout, since from the user's perspective
  // it's all just "your draft is being generated". If that fails at any
  // point, the spinner is swapped for an error message.
  if (phase === "generating" || phase === "polling" || phase === "downloading") {
    return (
      <div className="py-2">
        <LoadingSpinner message="Your draft is being generated..." />
      </div>
    );
  }

  if (phase === "error") {
    return (
      <div className="flex items-start gap-2 text-sm text-red-600">
        <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0" />
        <div>
          {errorMessage ||
            "Sorry, something went wrong while generating your draft. Please try again."}
        </div>
      </div>
    );
  }

  const renderInput = (field) => {
    const value = values[field.id] ?? "";
    const hasError = errors[field.id];
    const baseClass = `w-full rounded-lg border px-3 py-2 text-sm text-gray-900 bg-white focus:outline-none focus:ring-2 focus:ring-pmi-blue focus:border-transparent disabled:bg-gray-100 disabled:text-gray-500 ${
      hasError ? "border-red-400" : "border-gray-300"
    }`;

    switch (field.type) {
      case "select":
        return (
          <select
            value={value}
            disabled={checking}
            onChange={(e) => handleChange(field.id, e.target.value)}
            className={baseClass}
          >
            <option value="">{field.placeholder || "Select..."}</option>
            {(field.options || []).map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        );
      case "textarea":
        return (
          <textarea
            value={value}
            rows={3}
            disabled={checking}
            placeholder={field.placeholder || ""}
            onChange={(e) => handleChange(field.id, e.target.value)}
            className={`${baseClass} resize-y`}
          />
        );
      default:
        return (
          <input
            type="text"
            value={value}
            disabled={checking}
            placeholder={field.placeholder || ""}
            onChange={(e) => handleChange(field.id, e.target.value)}
            className={baseClass}
          />
        );
    }
  };

  const renderFieldGroup = (field) => (
    <div key={field.id} className="mb-3">
      <label className="mb-1 block text-xs font-medium text-gray-700">
        {field.label || field.id}
        {field.required && <span className="ml-0.5 text-red-500">*</span>}
      </label>
      {renderInput(field)}
      {errors[field.id] && (
        <p className="mt-1 text-xs text-red-500">This field is required.</p>
      )}
    </div>
  );

  return (
    <div className="min-w-0">
      <h3 className="text-base font-semibold text-gray-900">
        {schema?.display_name || category}
      </h3>
      {schema?.description && (
        <p className="mt-0.5 mb-3 text-xs text-gray-500">{schema.description}</p>
      )}

      {mandatoryFields.map(renderFieldGroup)}

      {optionalFields.length > 0 && (
        <>
          <p className="mt-4 mb-2 text-[11px] font-semibold uppercase tracking-wide text-gray-400">
            Optional
          </p>
          {optionalFields.map(renderFieldGroup)}
        </>
      )}

      <div className="mt-2 flex items-center gap-3">
        <button
          type="button"
          onClick={handleSubmit}
          disabled={checking}
          className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-pmi-blue to-pmi-navy px-4 py-2 text-sm font-medium text-white hover:shadow-md disabled:opacity-50 transition-all"
        >
          {checking ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Checking...
            </>
          ) : (
            <>
              <Send className="h-4 w-4" />
              Submit
            </>
          )}
        </button>
        {errorMessage && (
          <span className="text-xs text-red-500">{errorMessage}</span>
        )}
      </div>
    </div>
  );
}

export default ChatDraftForm;
