import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

import { getAuthenticatedUser } from "../services/cognitoService";

import { useApp } from "../context/AppContext";

function AuthCallback() {
  const navigate = useNavigate();

  const { login } = useApp();

  useEffect(() => {
    const init = async () => {
      try {
        const user = await getAuthenticatedUser();

        if (!user) {
          navigate("/login", {
            replace: true,
          });

          return;
        }

        login({
          username: user.username,
        });

        navigate("/", {
          replace: true,
        });
      } catch {
        navigate("/login", {
          replace: true,
        });
      }
    };

    init();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white rounded-2xl shadow-lg px-10 py-8 flex flex-col items-center">
        <div className="w-12 h-12 border-4 border-pmi-blue border-t-transparent rounded-full animate-spin mb-4" />
        <h2 className="text-xl font-semibold text-gray-800">Signing in</h2>
        <p className="text-sm text-gray-500 mt-2">
          Please wait while we authenticate your account...
        </p>
      </div>
    </div>
  );
}

export default AuthCallback;
