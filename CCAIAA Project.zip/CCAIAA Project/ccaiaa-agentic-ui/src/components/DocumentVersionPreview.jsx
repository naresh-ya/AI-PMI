import { useEffect, useMemo, useState } from "react";
import { Columns, Eye, CheckCircle2 } from "lucide-react";

/**
 * DocumentVersionPreview
 * ---------------------------------------------------------------------------
 * Renders the response shape returned by fetchDocumentPreview
 * (`/documents/compare/:requestId`):
 *   {
 *     request_id: string,
 *     version_count: number,
 *     versions: [{ version, html_content, s3_key }, ...],   // all versions
 *     current:  { version, html_content, s3_key },
 *     previous: { version, html_content, s3_key } | null,
 *     is_first_draft: boolean
 *   }
 *
 * Two view modes (when more than one version exists), toggled by a single
 * header button:
 *  - "single" (default): one panel with its own version dropdown, no diff
 *    highlighting.
 *  - "compare": two panels side by side, each with its own version
 *    dropdown, with git-style diff highlighting on automatically — the
 *    panel showing the older of the two selected versions gets its removed
 *    text highlighted red, and the panel showing the newer of the two gets
 *    its added text highlighted green. This is based on comparing the
 *    versions' own version numbers, not which side of the screen they
 *    happen to be on, so swapping the dropdowns still highlights correctly.
 *    There's no separate way to turn the highlighting off within Compare —
 *    switching back to Single is what does that.
 *
 * When there's only one version (or `is_first_draft` is true), the toggle
 * button and dropdowns are hidden and that single version just renders.
 *
 * Props:
 *  - previewData: the API response described above.
 *  - selectedFinalVersion: version number currently marked "final" by the
 *    user (controlled by the parent), or null/undefined if none chosen yet.
 *  - onSelectFinalVersion(versionNumber): called when the user clicks
 *    "Select vN as Final" on a version. The parent owns this selection so
 *    it can be sent along whenever the user actually approves the draft.
 *  - allowVersionActions: when false, hides the Compare button, version
 *    dropdown, and "Select as Final" button entirely — just the current
 *    version's content renders, with no controls. Used to restrict version
 *    picking/finalizing to only the stage where that decision is actually
 *    actionable (e.g. while the draft is still pending review), while
 *    still letting the same component render a read-only preview
 *    elsewhere. Defaults to true.
 */

// ─── Word-level diff (git-style) ───────────────────────────────────────────
// Implemented locally (no new dependency) using an LCS-based diff, the same
// underlying technique `git diff` uses. To keep this fast even for large
// documents, it cascades through granularities: word-level first (best
// detail); if that comparison would be too large, line-level with each
// changed hunk refined back down to word-level; if even that's too large,
// a fixed-count block-level diff (always cheap) with hunks refined at word
// level. This means a diff is always produced, never a "too large" bailout.

function tokenizeWords(text) {
  return text.match(/\s+|\S+/g) || [];
}

// Splits into lines, keeping each line's trailing newline attached so the
// original text can be reconstructed exactly by concatenation.
function tokenizeLines(text) {
  return text.match(/[^\n]*\n|[^\n]+$/g) || [];
}

// Splits text into a fixed number of roughly-equal-size contiguous blocks.
// A fixed block count keeps the LCS table tiny (BLOCK_COUNT^2 cells) no
// matter how large the document is, so this tier always succeeds.
const BLOCK_COUNT = 80;

function tokenizeBlocks(text) {
  if (!text) return [];
  const blockSize = Math.max(1, Math.ceil(text.length / BLOCK_COUNT));
  const blocks = [];
  for (let i = 0; i < text.length; i += blockSize) {
    blocks.push(text.slice(i, i + blockSize));
  }
  return blocks;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Converts backend html_content (mostly plain text with a handful of inline
// tags like <br>/<strong>) into plain text, matching how the preview panels
// already treat this content (rendered in a monospace, pre-wrap block
// rather than as rich HTML).
function stripToPlainText(html) {
  if (!html) return "";
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<[^>]+>/g, "");
}

// Above this many array-element pairs, the O(n*m) LCS table gets too
// large/slow to compute synchronously — used to decide whether a given
// granularity (word/line/block) can be diffed directly.
const MAX_DIFF_CELLS = 9_000_000;

// Core LCS-based diff over an arbitrary pair of arrays (words, lines, or
// blocks). Returns null only when the comparison itself is too large for
// that granularity — callers fall back to a coarser granularity in that
// case.
function diffArraysRaw(oldArr, newArr) {
  const n = oldArr.length;
  const m = newArr.length;
  if (n * m > MAX_DIFF_CELLS) return null;

  // dp[i][j] = LCS length of oldArr[i:] and newArr[j:]
  const dp = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
  for (let i = n - 1; i >= 0; i--) {
    const dpRowNext = dp[i + 1];
    const dpRow = dp[i];
    for (let j = m - 1; j >= 0; j--) {
      dpRow[j] =
        oldArr[i] === newArr[j]
          ? dpRowNext[j + 1] + 1
          : Math.max(dpRowNext[j], dpRow[j + 1]);
    }
  }

  const ops = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (oldArr[i] === newArr[j]) {
      ops.push({ type: "equal", value: oldArr[i] });
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      ops.push({ type: "removed", value: oldArr[i] });
      i++;
    } else {
      ops.push({ type: "added", value: newArr[j] });
      j++;
    }
  }
  while (i < n) {
    ops.push({ type: "removed", value: oldArr[i] });
    i++;
  }
  while (j < m) {
    ops.push({ type: "added", value: newArr[j] });
    j++;
  }
  return ops;
}

function mergeOps(ops) {
  const merged = [];
  for (const op of ops) {
    const last = merged[merged.length - 1];
    if (last && last.type === op.type) {
      last.value += op.value;
    } else {
      merged.push({ ...op });
    }
  }
  return merged;
}

// Trims the common prefix/suffix off two arrays before diffing. Version-to-
// version document edits are almost always localized — most of the document
// is untouched — so this shrinks the O(n*m) middle region dramatically,
// letting much larger inputs still be diffed directly at a given
// granularity instead of falling back to a coarser one.
function diffArraysTrimmed(oldArr, newArr) {
  const minLen = Math.min(oldArr.length, newArr.length);

  let start = 0;
  while (start < minLen && oldArr[start] === newArr[start]) start++;

  let endOld = oldArr.length;
  let endNew = newArr.length;
  while (endOld > start && endNew > start && oldArr[endOld - 1] === newArr[endNew - 1]) {
    endOld--;
    endNew--;
  }

  const middleOps = diffArraysRaw(oldArr.slice(start, endOld), newArr.slice(start, endNew));
  if (middleOps === null) return null;

  const ops = [];
  if (start > 0) ops.push({ type: "equal", value: oldArr.slice(0, start).join("") });
  ops.push(...middleOps);
  if (endOld < oldArr.length) ops.push({ type: "equal", value: oldArr.slice(endOld).join("") });
  return mergeOps(ops);
}

// Walks a coarse (line or block granularity) diff and refines every
// removed-then-added change hunk down to word-level detail where the hunk
// is small enough, leaving larger hunks at their original coarse
// granularity (whole line/block colored, no per-word detail).
function refineOpsAtWordLevel(coarseOps) {
  const result = [];
  let i = 0;
  while (i < coarseOps.length) {
    const op = coarseOps[i];
    if (op.type !== "removed") {
      result.push(op);
      i++;
      continue;
    }
    let removedValue = op.value;
    let j = i + 1;
    while (j < coarseOps.length && coarseOps[j].type === "removed") {
      removedValue += coarseOps[j].value;
      j++;
    }
    let addedValue = "";
    let k = j;
    while (k < coarseOps.length && coarseOps[k].type === "added") {
      addedValue += coarseOps[k].value;
      k++;
    }
    if (addedValue) {
      const refined = diffArraysTrimmed(tokenizeWords(removedValue), tokenizeWords(addedValue));
      if (refined) {
        result.push(...refined);
      } else {
        result.push({ type: "removed", value: removedValue });
        result.push({ type: "added", value: addedValue });
      }
    } else {
      result.push({ type: "removed", value: removedValue });
    }
    i = k;
  }
  return mergeOps(result);
}

// Top-level diff: try word-level directly first (best granularity); if too
// large, fall back to line-level with per-hunk word refinement; if that's
// still too large, fall back to a fixed-block-count diff (always cheap)
// with per-hunk word refinement. A usable ops array is always returned.
function diffText(oldText, newText) {
  const wordOps = diffArraysTrimmed(tokenizeWords(oldText), tokenizeWords(newText));
  if (wordOps) return wordOps;

  const lineOps = diffArraysTrimmed(tokenizeLines(oldText), tokenizeLines(newText));
  if (lineOps) return refineOpsAtWordLevel(lineOps);

  const blockOps = diffArraysTrimmed(tokenizeBlocks(oldText), tokenizeBlocks(newText));
  if (blockOps) return refineOpsAtWordLevel(blockOps);

  // Defensive fallback — block-level is sized to always succeed above.
  return mergeOps([
    { type: "removed", value: oldText },
    { type: "added", value: newText },
  ]);
}

// Renders one side of a two-panel diff from a shared ops list: `side="old"`
// shows unchanged + removed (red/strikethrough) text and skips additions;
// `side="new"` shows unchanged + added (green) text and skips removals.
function renderDiffSideHtml(ops, side) {
  return ops
    .map((op) => {
      const safe = escapeHtml(op.value).replace(/\n/g, "<br/>");
      if (op.type === "equal") return safe;
      if (side === "old" && op.type === "removed") {
        return `<span class="bg-red-100 text-red-700">${safe}</span>`;
      }
      if (side === "new" && op.type === "added") {
        return `<span class="bg-green-100 text-green-800">${safe}</span>`;
      }
      return "";
    })
    .join("");
}

function DocumentVersionPreview({
  previewData,
  selectedFinalVersion,
  onSelectFinalVersion,
  allowVersionActions = true,
}) {
  const versions = useMemo(() => {
    if (previewData?.versions?.length) return previewData.versions;
    // Backward-compat fallback for the older API shape that only returned
    // `current`/`previous` (no `versions` array) — build a small versions
    // list out of whichever of those two are present.
    const fallback = [];
    if (previewData?.current) fallback.push(previewData.current);
    if (
      previewData?.previous &&
      previewData.previous.version !== previewData?.current?.version
    ) {
      fallback.push(previewData.previous);
    }
    return fallback;
  }, [previewData]);

  const hasMultipleVersions =
    allowVersionActions && versions.length > 1 && !previewData?.is_first_draft;

  const getVersionByNumber = (versionNumber) =>
    versions.find((v) => v.version === versionNumber) || null;

  const defaultLeftVersion = previewData?.current?.version ?? versions[0]?.version ?? null;
  const defaultRightVersion =
    previewData?.previous?.version ??
    versions.find((v) => v.version !== defaultLeftVersion)?.version ??
    null;

  const [viewMode, setViewMode] = useState("single");
  const [leftVersionNumber, setLeftVersionNumber] = useState(defaultLeftVersion);
  const [rightVersionNumber, setRightVersionNumber] = useState(defaultRightVersion);
  const [singleVersionNumber, setSingleVersionNumber] = useState(defaultLeftVersion);

  // Re-sync selected versions whenever a new preview payload comes in
  // (e.g. switching between requests, or a fresh draft being generated).
  useEffect(() => {
    setLeftVersionNumber(defaultLeftVersion);
    setRightVersionNumber(defaultRightVersion);
    setSingleVersionNumber(defaultLeftVersion);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [previewData?.request_id, defaultLeftVersion, defaultRightVersion]);

  const leftData = getVersionByNumber(leftVersionNumber);
  const rightData = getVersionByNumber(rightVersionNumber);

  // Which of the two currently-selected versions is older vs newer, by
  // version number — independent of which dropdown/side they're sitting in,
  // so swapping the two dropdowns still highlights the right side correctly.
  const olderData =
    leftData && rightData
      ? (leftData.version ?? 0) <= (rightData.version ?? 0)
        ? leftData
        : rightData
      : null;
  const newerData =
    leftData && rightData
      ? olderData === leftData
        ? rightData
        : leftData
      : null;

  const showCompare = hasMultipleVersions && viewMode === "compare";

  // Diff highlighting is always on while in Compare mode — there's no
  // separate toggle for it anymore (switching to Single is what turns it
  // off, by not showing the two panels at all).
  const diffOps = useMemo(() => {
    if (!showCompare || !olderData || !newerData) return null;
    return diffText(
      stripToPlainText(olderData.html_content),
      stripToPlainText(newerData.html_content),
    );
  }, [showCompare, olderData?.html_content, newerData?.html_content]);

  if (!versions.length) return null;

  const versionOptions = [...versions].sort((a, b) => (b.version ?? 0) - (a.version ?? 0));

  const renderVersionDropdown = (selectedVersionNumber, onChange) => (
    <select
      value={selectedVersionNumber ?? ""}
      onChange={(e) => onChange(Number(e.target.value))}
      onClick={(e) => e.stopPropagation()}
      className="text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded-md px-2 py-1 focus:outline-none focus:ring-1 focus:ring-pmi-blue focus:border-pmi-blue"
    >
      {versionOptions.map((v) => (
        <option key={v.version} value={v.version}>
          v{v.version}
          {v.version === previewData?.current?.version ? " (latest)" : ""}
        </option>
      ))}
    </select>
  );

  // "Select vN as Final" — lets the user mark whichever version they're
  // currently looking at (in either Single or Compare view) as the final
  // one, even if it isn't the actual latest version. Reports the choice up
  // to the parent via onSelectFinalVersion; the parent is responsible for
  // sending it along whenever the user actually approves the draft.
  const renderSetFinalButton = (versionData) => {
    const isSelected =
      versionData?.version != null && versionData.version === selectedFinalVersion;
    return (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onSelectFinalVersion?.(versionData?.version ?? null);
        }}
        title={
          isSelected
            ? "This version is marked as final"
            : "Mark this version as the final version"
        }
        className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md border transition-colors flex-shrink-0 ${
          isSelected
            ? "border-green-400 bg-green-50 text-green-700"
            : "border-gray-300 text-gray-600 hover:bg-gray-100 hover:text-gray-800"
        }`}
      >
        <CheckCircle2 className="h-3.5 w-3.5" />
        {isSelected
          ? `Final${versionData?.version != null ? ` (v${versionData.version})` : ""}`
          : `Select${versionData?.version != null ? ` v${versionData.version}` : ""} as Final`}
      </button>
    );
  };

  // Single border tier per panel: a subtle header/content divider only —
  // no separate outer box, since the panel already sits inside the parent
  // card's border (and, in side-by-side mode, inside a divide-x column).
  // `showHeader` is false for the single-view panel, since its version
  // dropdown now lives up in the toolbar next to the Compare button
  // instead of a separate row inside the panel.
  const renderPanel = (selectedVersionNumber, onChange, versionData, showHeader = true) => {
    let html = null;
    if (versionData) {
      if (diffOps && versionData === olderData) {
        html = renderDiffSideHtml(diffOps, "old");
      } else if (diffOps && versionData === newerData) {
        html = renderDiffSideHtml(diffOps, "new");
      } else {
        html = (versionData.html_content || "").replace(/\n/g, "<br/>");
      }
    }

    return (
      <div className="flex-1 min-w-0 flex flex-col">
        {showHeader && (
          <div className="flex items-center justify-end gap-2 px-4 py-2 bg-gray-50 border-b border-gray-200">
            {renderSetFinalButton(versionData)}
            {renderVersionDropdown(selectedVersionNumber, onChange)}
          </div>
        )}
        <div className="p-4 max-h-[600px] overflow-y-auto">
          {versionData ? (
            <div
              className="font-mono text-sm whitespace-pre-wrap text-gray-800 leading-relaxed"
              dangerouslySetInnerHTML={{ __html: html }}
            />
          ) : (
            <p className="text-sm text-gray-400 italic">Version not available.</p>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="bg-gray-50 px-6 py-3 border-b border-gray-200 flex items-center justify-between gap-3">
        <h4 className="font-semibold text-gray-900">Document Preview</h4>
        <div className="flex items-center gap-2">
          {/* In single view, the "Set as Final" action + version dropdown
              sit right next to the Compare button instead of on their own
              row inside the panel. Hidden entirely when allowVersionActions
              is false. */}
          {allowVersionActions &&
            !showCompare &&
            renderSetFinalButton(getVersionByNumber(singleVersionNumber))}
          {allowVersionActions &&
            !showCompare &&
            renderVersionDropdown(singleVersionNumber, setSingleVersionNumber)}
          {hasMultipleVersions && (
            <button
              type="button"
              onClick={() => setViewMode((prev) => (prev === "compare" ? "single" : "compare"))}
              title={
                showCompare
                  ? "Switch back to single version preview"
                  : "Compare two versions side by side with differences highlighted"
              }
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border transition-colors flex-shrink-0 ${
                showCompare
                  ? "border-pmi-blue bg-pmi-blue/10 text-pmi-blue"
                  : "border-gray-300 text-gray-600 hover:bg-gray-100 hover:text-gray-800"
              }`}
            >
              {showCompare ? (
                <Eye className="h-3.5 w-3.5" />
              ) : (
                <Columns className="h-3.5 w-3.5" />
              )}
              Compare
            </button>
          )}
        </div>
      </div>

      {showCompare ? (
        <div className="flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-gray-200">
          {renderPanel(leftVersionNumber, setLeftVersionNumber, leftData)}
          {renderPanel(rightVersionNumber, setRightVersionNumber, rightData)}
        </div>
      ) : (
        renderPanel(
          singleVersionNumber,
          setSingleVersionNumber,
          getVersionByNumber(singleVersionNumber),
          false,
        )
      )}
    </div>
  );
}

export default DocumentVersionPreview;
