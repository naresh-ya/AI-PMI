import { useState, useRef, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Bell,
  FileText,
  LayoutDashboard,
  Clock,
  X,
  CheckCircle,
  AlertTriangle,
  Info,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Users,
  Settings,
  FolderOpen,
  PlusCircle,
  Plus,
  Lock,
  MessageSquare,
  FileSignature,
  ChevronDown,
  ChevronUp,
  Search,
  Trash2,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import {
  createNewChat,
  deleteConversation,
  getConversationIds,
} from "../services/api";
import pmiLogo from "../assets/Philip-Morris-International.png";
import ConfirmDialog from "./ui/ConfirmDialog";

function Layout({ children }) {
  const location = useLocation();
  const navigate = useNavigate();
  const {
    state,
    markNotificationRead,
    dismissNotification,
    logout,
    setSelectedConversationId,
    addConversation,
    setConversations,
    removeConversation,
    addToast,
  } = useApp();
  const {
    user,
    requests,
    notifications,
    chatConversations,
    selectedConversationId,
    messagesByConversationId,
  } = state;
  const [creatingChat, setCreatingChat] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [caChatsExpanded, setCaChatsExpanded] = useState(false);
  const [chatSearchQuery, setChatSearchQuery] = useState("");
  const [conversationPendingDelete, setConversationPendingDelete] =
    useState(null);
  const [deletingConversation, setDeletingConversation] = useState(false);
  const notifRef = useRef(null);
  const userMenuRef = useRef(null);

  const pendingApprovals = requests.filter(
    (r) =>
      r?.status === "pending-approval" || r?.status === "awaiting_human_review",
  )?.length;

  const unreadCount = notifications.filter((n) => !n.read).length;

  // New chats show up in the sidebar immediately upon creation (see
  // handleCreateNewChat below) — no hiding/filtering needed here.
  const visibleChatConversations = chatConversations;

  const filteredChatConversations = chatSearchQuery.trim()
    ? visibleChatConversations.filter((conversation) => {
        const title = conversation.title || conversation.conversation_id || "";
        return title
          .toLowerCase()
          .includes(chatSearchQuery.trim().toLowerCase());
      })
    : visibleChatConversations;

  // Groups conversations into date-header buckets ("Today", "Yesterday",
  // then an actual formatted date for anything older) for the sidebar chat
  // list — same idea as ChatGPT/Copilot's own chat history grouping.
  // Buckets (and the conversations within each) stay sorted newest-first,
  // same ordering the flat list used before this change.
  const groupConversationsByDate = (conversations) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const sorted = [...conversations].sort(
      (conversationA, conversationB) =>
        new Date(conversationB?.created_at) -
        new Date(conversationA?.created_at),
    );

    const groups = [];
    const groupIndexByLabel = {};

    sorted.forEach((conversation) => {
      const createdAt = new Date(conversation?.created_at);
      const createdAtDay = new Date(createdAt);
      createdAtDay.setHours(0, 0, 0, 0);

      let label;
      if (Number.isNaN(createdAtDay.getTime())) {
        label = "Earlier";
      } else if (createdAtDay.getTime() === today.getTime()) {
        label = "Today";
      } else if (createdAtDay.getTime() === yesterday.getTime()) {
        label = "Yesterday";
      } else {
        label = createdAtDay.toLocaleDateString(undefined, {
          month: "short",
          day: "numeric",
          // Only show the year for a date that isn't in the current year —
          // matches how most chat apps format older history.
          year:
            createdAtDay.getFullYear() === today.getFullYear()
              ? undefined
              : "numeric",
        });
      }

      if (!(label in groupIndexByLabel)) {
        groupIndexByLabel[label] = groups.length;
        groups.push({ label, conversations: [] });
      }
      groups[groupIndexByLabel[label]].conversations.push(conversation);
    });

    return groups;
  };

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setShowNotifications(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setShowUserMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Collapses the CA Workbench conversation list (search box + chat list +
  // "Create New Chat" button, toggled via the chevron next to that nav
  // item) whenever the user navigates to any OTHER screen — same
  // "am I on CA Workbench" condition used for the header title and main
  // content styling above. Without this, caChatsExpanded stayed exactly as
  // the user left it (open or closed) no matter where they navigated,
  // which meant it could still be sitting open, taking up sidebar space,
  // on e.g. the Dashboard or Approvals screen.
  const isOnAskCA =
    location.pathname === "/" && location?.state?.from === "askca";
  useEffect(() => {
    if (!isOnAskCA) {
      setCaChatsExpanded(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOnAskCA]);

  const handleConversationSelect = (conversationId) => {
    setSelectedConversationId(conversationId);
    if (!(location.pathname === "/" && location?.state?.from === "askca")) {
      navigate("/", { state: { from: "askca" } });
    }
  };

  const handleAskCAClick = (e) => {
    e.preventDefault();
    const conversationIdToOpen =
      selectedConversationId || chatConversations[0]?.conversation_id || null;
    if (conversationIdToOpen) {
      setSelectedConversationId(conversationIdToOpen);
    }
    navigate("/", { state: { from: "askca" } });
  };

  const handleCreateNewChat = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      setCreatingChat(true);
      // const newChatResponse = await createNewChat(
      //   user?.email?.replace("@", "").replace(/\./g, "_"),
      // );
      const newConversationDetails = {
        created_at: new Date(Date.now()).toISOString(),
        is_deleted: false,
        last_message_at: new Date().toISOString(),
        message_count: Math.floor(Math.random() * 20) + 1,
        status: "ACTIVE",
        title: `New Chat`,
        updated_at: new Date().toISOString(),
        user_id: `user_${1}`,
        conversation_id: `conv-${crypto.randomUUID()}`,
        // Marks this as a client-side-only placeholder — no backend
        // conversation exists yet. AskCA checks this flag (persisted in
        // AppContext, so it survives navigating away and back) to know it
        // needs to create the real conversation on the first message send.
        is_placeholder: true,
      };
      addConversation(newConversationDetails);
      setSelectedConversationId(newConversationDetails?.conversation_id);
      navigate("/", { state: { from: "askca" } });
    } catch (error) {
      console.log(error);
    } finally {
      setCreatingChat(false);
    }
  };

  const handleDeleteChatClick = (e, conversation) => {
    e.preventDefault();
    e.stopPropagation();
    setConversationPendingDelete(conversation);
  };

  const handleCancelDeleteChat = () => {
    setConversationPendingDelete(null);
  };

  const handleConfirmDeleteChat = async () => {
    if (!conversationPendingDelete) return;
    const conversationIdToDelete = conversationPendingDelete.conversation_id;
    // Newly-created chats (via the sidebar's "Create New Chat" button) are
    // client-side-only placeholders until the first message is actually
    // sent (see is_placeholder, set in handleCreateNewChat below / consumed
    // in AskCA.jsx) — the backend has no record of them yet, so calling
    // DELETE against their fake id always 404s. Skip the API call entirely
    // for these and just remove the local placeholder.
    const isUnsentPlaceholder = Boolean(
      conversationPendingDelete.is_placeholder,
    );

    try {
      setDeletingConversation(true);

      if (isUnsentPlaceholder) {
        removeConversation(conversationIdToDelete);
        return;
      }

      try {
        await deleteConversation(
          conversationIdToDelete,
          user?.email?.replace("@", "").replace(/\./g, "_"),
        );

        const conversationIdsResponse = await getConversationIds(
          user?.email?.replace("@", "").replace(/\./g, "_"),
        );
        const refreshedConversations =
          conversationIdsResponse?.conversations || [];
        setConversations(refreshedConversations);

        if (selectedConversationId === conversationIdToDelete) {
          setSelectedConversationId(
            refreshedConversations[0]?.conversation_id || null,
          );
        }
      } catch (error) {
        // The delete (or the refresh that follows it) failed on the
        // backend — most likely because this conversation was created
        // very recently and the backend doesn't have a durable record of
        // it yet (or the delete endpoint is otherwise unavailable). Rather
        // than leaving a chat the user explicitly asked to delete still
        // sitting in the sidebar, remove it locally so the UI reflects
        // their action; it'll simply reappear on the next successful
        // getConversationIds refresh if the backend actually still has it.
        console.log(error);
        removeConversation(conversationIdToDelete);
        addToast?.({
          type: "warning",
          message:
            "Couldn't confirm deletion with the server, so this chat was removed locally.",
        });
      }
    } finally {
      setDeletingConversation(false);
      setConversationPendingDelete(null);
    }
  };

  const handleNotificationClick = (notif) => {
    markNotificationRead(notif.id);
    setShowNotifications(false);
    if (notif.requestId) {
      navigate(`/request/${notif.requestId}`);
    }
  };

  const getNotificationIcon = (type) => {
    if (type === "approval")
      return <CheckCircle className="h-5 w-5 text-amber-500 flex-shrink-0" />;
    if (type === "warning")
      return <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0" />;
    return <Info className="h-5 w-5 text-blue-500 flex-shrink-0" />;
  };

  const mainNavItems = [
    {
      to: "/",
      key: "dashboard",
      label: "Dashboard",
      icon: LayoutDashboard,
      state: { from: "dashboard" },
    },
    {
      to: "/new-request",
      key: "new-request",
      label: "New Request",
      icon: PlusCircle,
    },
    {
      to: "/approvals",
      key: "approvals",
      label: "Approvals",
      icon: Clock,
      badge: pendingApprovals,
    },
    {
      to: "/",
      key: "askca",
      label: "CA Workbench",
      icon: MessageSquare,
      state: { from: "askca" },
      expandable: true,
    },
    {
      to: "/signed-documents",
      key: "signedDocuments",
      label: "Signed Documents",
      icon: FileSignature,
    },
  ];

  const futureNavItems = [
    { label: "Role Assignment", icon: Users },
    { label: "Template Config", icon: Settings },
    { label: "Document Library", icon: FolderOpen },
  ];

  const sidebarWidth = sidebarCollapsed ? "w-[68px]" : "w-[240px]";

  return (
    <div className="min-h-screen bg-gray-50 flex overflow-x-hidden">
      {/* ── Left Sidebar ── */}
      <aside
        className={`${sidebarWidth} fixed inset-y-0 left-0 z-50 bg-gradient-to-b from-white to-pmi-surface border-r border-pmi-border flex flex-col transition-all duration-300 ease-in-out`}
      >
        {/* Logo Area */}
        <Link to="/">
          <div className="flex items-center justify-start h-16 px-4 border-b border-pmi-border bg-white flex-shrink-0">
            <div className="flex items-center">
              <img
                src={pmiLogo}
                alt="icon"
                className="h-[50px] w-auto object-contain overflow-hidden"
              />
            </div>
            {!sidebarCollapsed && (
              <div className="text-gray-800 font-medium text-xl ml-2">
                AskSpidy
              </div>
            )}
          </div>
        </Link>
        {/* <div className="flex items-center justify-center h-16 px-4 border-b border-pmi-border bg-white flex-shrink-0">
          <Link to="/" className="flex justify-center items-center gap-3 min-w-0">
            <div>
              <img
              src={pmiLogo}
              alt="PMI"
              className="h-14 w-14 object-contain flex-shrink-0"
            />
            </div>
            {!sidebarCollapsed && (
              <div className="min-w-0 transition-opacity duration-200">
                <h1 className="text-lg font-bold text-gray-900 leading-tight truncate">
                  AskSpidy
                </h1>
              </div>
            )}
          </Link>
        </div> */}

        {/* Collapse Toggle */}
        <button
          onClick={() => setSidebarCollapsed((prev) => !prev)}
          className="absolute -right-3 top-20 z-10 w-6 h-6 rounded-full bg-white border border-gray-200 shadow-sm flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-50 transition-colors"
        >
          {sidebarCollapsed ? (
            <ChevronRight className="h-3.5 w-3.5" />
          ) : (
            <ChevronLeft className="h-3.5 w-3.5" />
          )}
        </button>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden py-4 px-3 space-y-1">
          {/* Main Section */}
          {!sidebarCollapsed && (
            <p className="px-3 mb-2 text-[10px] font-semibold text-gray-400 uppercase tracking-wider">
              Main
            </p>
          )}
          {mainNavItems.map((item) => {
            const isActive =
              location.pathname === "/"
                ? location?.state?.from
                  ? item?.state?.from == location?.state?.from
                  : item?.state?.from == "dashboard"
                : location?.pathname == item.to;

            const Icon = item.icon;
            const isExpandable = item.expandable;

            return (
              <div
                key={item.state ? `${item?.state?.from}/${item.to}` : item.to}
              >
                <div
                  className={`group relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                    isActive
                      ? "bg-pmi-blue/10 text-pmi-blue"
                      : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                  }`}
                >
                  {isActive && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-pmi-blue rounded-r-full" />
                  )}
                  <Link
                    to={item.to}
                    state={item.state ? item.state : null}
                    onClick={isExpandable ? handleAskCAClick : undefined}
                    title={sidebarCollapsed ? item.label : undefined}
                    className="flex items-center gap-3 flex-1 min-w-0"
                  >
                    <Icon
                      className={`h-5 w-5 flex-shrink-0 ${isActive ? "text-pmi-blue" : "text-gray-400 group-hover:text-gray-600"}`}
                    />
                    {!sidebarCollapsed && (
                      <span className="truncate">{item.label}</span>
                    )}
                    {item.badge > 0 && (
                      <span
                        className={`${sidebarCollapsed ? "absolute -top-1 -right-1" : "ml-auto"} px-1.5 py-0.5 rounded-full bg-red-500 text-white text-[10px] font-bold leading-none`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </Link>

                  {isExpandable && !sidebarCollapsed && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setCaChatsExpanded((prev) => !prev);
                      }}
                      title={
                        caChatsExpanded
                          ? "Collapse conversations"
                          : "Expand conversations"
                      }
                      className="flex-shrink-0 w-5 h-5 rounded-full border border-gray-300 flex items-center justify-center text-gray-400 hover:text-pmi-blue hover:border-pmi-blue transition-colors"
                    >
                      {caChatsExpanded ? (
                        <ChevronUp className="h-3 w-3" />
                      ) : (
                        <ChevronDown className="h-3 w-3" />
                      )}
                    </button>
                  )}

                  {/* Tooltip for collapsed state */}
                  {sidebarCollapsed && (
                    <span className="hidden group-hover:block absolute left-full ml-2 px-2.5 py-1.5 bg-gray-900 text-white text-xs rounded-md whitespace-nowrap transition-all duration-150 z-50 shadow-lg">
                      {item.label}
                      {item.badge > 0 && (
                        <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-red-500 text-[10px] font-bold">
                          {item.badge}
                        </span>
                      )}
                    </span>
                  )}
                </div>

                {/* Create New Chat button */}
                {isExpandable && !sidebarCollapsed && caChatsExpanded && (
                  <button
                    type="button"
                    onClick={handleCreateNewChat}
                    disabled={creatingChat}
                    className="mt-1 w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-pmi-blue border border-pmi-blue/30 hover:bg-pmi-blue/10 disabled:opacity-50 transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                    {creatingChat ? "Creating..." : "Create New Chat"}
                  </button>
                )}

                {/* Sub items: conversation search + list */}
                {isExpandable && !sidebarCollapsed && caChatsExpanded && (
                  <div className="mt-1 space-y-0.5">
                    {visibleChatConversations.length > 0 && (
                      <div className="relative mb-1.5">
                        <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                        <input
                          type="text"
                          value={chatSearchQuery}
                          onChange={(e) => setChatSearchQuery(e.target.value)}
                          onClick={(e) => e.stopPropagation()}
                          placeholder="Search chats..."
                          className="w-full pl-7 pr-2 py-1.5 text-xs rounded-md border border-gray-200 focus:outline-none focus:ring-1 focus:ring-pmi-blue focus:border-pmi-blue placeholder:text-gray-400"
                        />
                      </div>
                    )}
                    {visibleChatConversations.length === 0 ? (
                      <p className="px-2 py-1.5 text-xs text-gray-400">
                        No conversations yet
                      </p>
                    ) : filteredChatConversations.length === 0 ? (
                      <p className="px-2 py-1.5 text-xs text-gray-400">
                        No chats match "{chatSearchQuery}"
                      </p>
                    ) : (
                      <div className="max-h-64 overflow-y-auto">
                        {groupConversationsByDate(
                          filteredChatConversations,
                        ).map((group) => (
                          <div key={group.label} className="mb-2">
                            <p className="px-2 pt-1 pb-1 text-[10px] font-semibold text-gray-400 uppercase tracking-wider">
                              {group.label}
                            </p>
                            {group.conversations.map((conversation) => {
                              const isSelected =
                                conversation.conversation_id ===
                                selectedConversationId;
                              const conversationTitle =
                                conversation.title ||
                                conversation.conversation_id;
                              return (
                                <div
                                  key={conversation.conversation_id}
                                  className="flex justify-center items-center gap-1"
                                >
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleConversationSelect(
                                        conversation.conversation_id,
                                      )
                                    }
                                    title={conversationTitle}
                                    className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-left truncate transition-colors ${
                                      isSelected
                                        ? "bg-pmi-blue/10 text-pmi-blue font-medium"
                                        : "text-gray-500 hover:bg-gray-100 hover:text-gray-800"
                                    }`}
                                  >
                                    <MessageSquare className="h-3 w-3 flex-shrink-0" />
                                    <span className="truncate">
                                      {conversationTitle}
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) =>
                                      handleDeleteChatClick(e, conversation)
                                    }
                                    title="Delete chat"
                                    className="flex-shrink-0 p-1 rounded-md text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                                  >
                                    <Trash2
                                      className="h-3.5 w-3.5"
                                      aria-hidden="true"
                                    />
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {/* Divider */}
          {/* <div className="my-4 border-t border-pmi-border" /> */}

          {/* Coming Soon Section */}
          {!sidebarCollapsed && (
            <p className="hidden px-3 mb-2 text-[10px] font-semibold text-gray-400 uppercase tracking-wider">
              Coming Soon
            </p>
          )}
          {futureNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.label}
                title={
                  sidebarCollapsed ? `${item.label} (Coming Soon)` : undefined
                }
                className="hidden group relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-gray-400 cursor-default"
              >
                <Icon className="h-5 w-5 flex-shrink-0 text-gray-300" />
                {!sidebarCollapsed && (
                  <>
                    <span className="truncate">{item.label}</span>
                    <Lock className="h-3 w-3 ml-auto text-gray-300" />
                  </>
                )}

                {/* Tooltip for collapsed state */}
                {sidebarCollapsed && (
                  <span className="hidden group-hover:block absolute left-full ml-2 px-2.5 py-1.5 bg-gray-900 text-white text-xs rounded-md whitespace-nowrap transition-all duration-150 z-50 shadow-lg">
                    {item.label}
                    <span className="ml-1.5 text-gray-400 text-[10px]">
                      Soon
                    </span>
                  </span>
                )}
              </div>
            );
          })}
        </nav>
      </aside>

      {/* ── Right Content Area ── */}
      <div
        className={`flex-1 min-w-0 flex flex-col h-screen overflow-hidden ${
          sidebarCollapsed ? "ml-[68px]" : "ml-[240px]"
        } transition-all duration-300 ease-in-out`}
      >
        {/* Top Bar (slim) */}
        <header className="h-16 bg-white/80 backdrop-blur-sm border-b border-pmi-border sticky top-0 z-40 flex items-center justify-between px-6 shadow-[0_1px_3px_rgba(0,61,165,0.04)]">
          {/* Page Title */}
          <div>
            <h2 className="text-gray-800 font-medium text-xl">
              {location.pathname === "/" &&
                location?.state?.from == "dashboard" &&
                "Dashboard"}
              {location.pathname === "/" &&
                location?.state?.from == "askca" &&
                "CA Workbench"}
              {location.pathname === "/" &&
                !location?.state?.from &&
                "Dashboard"}
              {location.pathname === "/new-request" && "New Request"}
              {location.pathname === "/approvals" && "Approvals"}
              {location.pathname === "/signed-documents" && "Signed Documents"}
              {location.pathname.startsWith("/request/") && "Request Details"}
            </h2>
          </div>

          {/* Notification Bell + Quick User */}
          <div className="flex items-center gap-3">
            {/* Notification Bell with Dropdown */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setShowNotifications((prev) => !prev)}
                className="relative p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 block h-4 w-4 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center font-bold">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notification Dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-xl border border-gray-200 z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b border-gray-200 flex items-center justify-between bg-gray-50">
                    <h3 className="text-sm font-semibold text-gray-900">
                      Notifications
                    </h3>
                    {unreadCount > 0 && (
                      <span className="text-xs text-pmi-blue font-medium">
                        {unreadCount} unread
                      </span>
                    )}
                  </div>

                  {notifications.length === 0 ? (
                    <div className="p-6 text-center">
                      <Bell className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                      <p className="text-sm text-gray-500">No notifications</p>
                    </div>
                  ) : (
                    <div className="max-h-64 overflow-y-auto divide-y divide-gray-100">
                      {notifications.map((notif) => (
                        <div
                          key={notif.id}
                          className={`flex items-start gap-3 p-4 cursor-pointer transition-colors hover:bg-gray-50 ${
                            !notif.read ? "bg-blue-50/40" : ""
                          }`}
                          onClick={() => handleNotificationClick(notif)}
                        >
                          <div className="mt-0.5">
                            {getNotificationIcon(notif.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <p
                                className={`text-sm font-medium ${!notif.read ? "text-gray-900" : "text-gray-700"}`}
                              >
                                {notif.title}
                              </p>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  dismissNotification(notif.id);
                                }}
                                className="ml-2 text-gray-400 hover:text-gray-600 flex-shrink-0"
                              >
                                <X className="h-3.5 w-3.5" />
                              </button>
                            </div>
                            <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">
                              {notif.message}
                            </p>
                            <p className="text-xs text-gray-400 mt-1">
                              {notif.time}
                            </p>
                          </div>
                          {!notif.read && (
                            <span className="block h-2 w-2 rounded-full bg-pmi-blue flex-shrink-0 mt-2"></span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {notifications.length > 0 && (
                    <div className="px-4 py-2.5 border-t border-gray-200 bg-gray-50">
                      <Link
                        to="/approvals"
                        onClick={() => setShowNotifications(false)}
                        className="text-xs text-pmi-blue hover:text-pmi-navy font-medium"
                      >
                        View all approvals →
                      </Link>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* User Profile Dropdown */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setShowUserMenu((prev) => !prev)}
                className="flex items-center gap-3 pl-3 border-l border-gray-200 hover:bg-gray-50 rounded-lg px-3 py-1.5 transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-pmi-blue text-white flex items-center justify-center text-sm font-semibold">
                  {user?.name?.charAt(0) || "U"}
                </div>
                <div className="hidden sm:block text-sm text-left">
                  <p className="font-medium text-gray-900 leading-tight">
                    {user?.name}
                  </p>
                  <p className="text-gray-500 text-xs">{user?.roleTitle}</p>
                </div>
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-gray-200 z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-medium text-gray-900">
                      {user?.name}
                    </p>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {user?.email}
                    </p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {user?.roleTitle}
                    </p>
                  </div>
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        handleLogout();
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <LogOut className="h-4 w-4" />
                      Sign out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Main Content */}
        {/* AskCA gets a non-scrolling, full-height shell so its own chat
            container (not this <main>) owns the scroll and can stretch
            edge-to-edge top-to-bottom; every other route keeps the normal
            scrollable page behavior. */}
        <main
          className={
            location.pathname === "/" && location?.state?.from === "askca"
              ? "flex-1 min-h-0 min-w-0 overflow-hidden flex flex-col"
              : "flex-1 min-h-0 min-w-0 overflow-y-auto overflow-x-hidden"
          }
        >
          {children}
        </main>
      </div>

      {/* Delete chat confirmation dialog */}
      <ConfirmDialog
        open={Boolean(conversationPendingDelete)}
        title="Delete chat?"
        message={`Are you sure you want to delete "${
          conversationPendingDelete?.title ||
          conversationPendingDelete?.conversation_id ||
          "this chat"
        }"? This action cannot be undone.`}
        confirmLabel={deletingConversation ? "Deleting..." : "Delete"}
        confirmDisabled={deletingConversation}
        cancelLabel="Cancel"
        variant="danger"
        onConfirm={handleConfirmDeleteChat}
        onCancel={handleCancelDeleteChat}
      />
    </div>
  );
}

export default Layout;
