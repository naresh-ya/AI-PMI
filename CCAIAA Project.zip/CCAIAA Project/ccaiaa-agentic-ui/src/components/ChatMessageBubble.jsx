import { memo, useEffect, useMemo, useRef, useState } from "react";
import {
  MessageSquare,
  MoreHorizontal,
  MoreVertical,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  Share,
  Loader2,
  FileText,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import useStreamingText from "../hooks/useStreamingText";
import { useApp } from "../context/AppContext";
import { exportChatMessage, downloadChat } from "../services/api";
import { fixMisplacedMarkdownHeadings } from "../utils/markdownHeadingFix";
import { fixCollapsedMarkdownLists } from "../utils/markdownListFix";
import ChatDraftForm from "./ChatDraftForm";

// Markdown renderer overrides shared by every assistant bubble. Defined once
// at module scope (not inside the component) so React Markdown doesn't see a
// brand-new `components` object identity on every re-render/streamed tick.
const markdownComponents = {
  p: ({ children }) => (
    <p className="mb-4 leading-7 text-gray-800 break-words">{children}</p>
  ),
  table: ({ children }) => (
    <table className="my-6 w-full border-collapse overflow-hidden rounded-lg border border-gray-200 text-sm">
      {children}
    </table>
  ),
  th: ({ children }) => (
    <th className="border border-gray-200 bg-gray-50 px-4 py-3 text-left font-semibold text-gray-900">
      {children}
    </th>
  ),
  td: ({ children }) => (
    <td className="border border-gray-200 px-4 py-3 text-left text-gray-700 align-top">
      {children}
    </td>
  ),
  h1: ({ children }) => (
    <h1 className="mt-8 mb-4 text-3xl font-bold tracking-tight text-gray-900">
      {children}
    </h1>
  ),
  h2: ({ children }) => (
    <h2 className="mt-8 mb-3 text-2xl font-semibold tracking-tight text-gray-900">
      {children}
    </h2>
  ),
  h3: ({ children }) => (
    <h3 className="mt-6 mb-3 text-xl font-semibold text-gray-900">
      {children}
    </h3>
  ),
  h4: ({ children }) => (
    <h4 className="mt-5 mb-2 text-lg font-semibold text-gray-900">
      {children}
    </h4>
  ),
  h5: ({ children }) => (
    <h5 className="mt-4 mb-2 text-base font-semibold text-gray-900">
      {children}
    </h5>
  ),
  h6: ({ children }) => (
    <h6 className="mt-4 mb-2 text-sm font-semibold uppercase tracking-wide text-gray-500">
      {children}
    </h6>
  ),
  a: ({ children, href }) => (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="font-medium text-blue-600 underline decoration-blue-300 underline-offset-2 hover:text-blue-700 hover:decoration-blue-500 break-words [overflow-wrap:anywhere]"
    >
      {children}
    </a>
  ),
  hr: () => <hr className="my-8 border-0 border-t border-gray-200" />,
  ul: ({ children }) => (
    <ul
      className="mb-4 ml-6 list-disc space-y-2 text-gray-800
                 [&_ul]:mt-2 [&_ul]:ml-6 [&_ul]:list-circle
                 [&_ul_ul]:list-square"
    >
      {children}
    </ul>
  ),
  ol: ({ children }) => (
    <ol
      className="mb-4 ml-6 list-decimal space-y-2 text-gray-800
                 [&_ol]:mt-2 [&_ol]:ml-6 [&_ol]:list-[lower-alpha]
                 [&_ol_ol]:list-[lower-roman]"
    >
      {children}
    </ol>
  ),
  li: ({ children }) => (
    <li
      className="leading-7 marker:text-gray-500 break-words
                 [&>p]:mb-1
                 [&>ul]:mt-2
                 [&>ol]:mt-2"
    >
      {children}
    </li>
  ),
};

// Markdown renderer overrides for USER messages only. The bubble background
// is the blue gradient (text-white), so these are intentionally lighter /
// more compact than the assistant's `markdownComponents` above, and every
// block keeps `whitespace-pre-wrap` so runs of spaces the user actually
// typed are preserved instead of being collapsed by normal HTML rules.
const userMarkdownComponents = {
  p: ({ children }) => (
    <p className="mb-2 last:mb-0 whitespace-pre-wrap leading-relaxed break-words">
      {children}
    </p>
  ),
  a: ({ children, href }) => (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="font-medium underline decoration-blue-200 underline-offset-2 hover:decoration-white break-words [overflow-wrap:anywhere]"
    >
      {children}
    </a>
  ),
  strong: ({ children }) => (
    <strong className="font-semibold">{children}</strong>
  ),
  em: ({ children }) => <em className="italic">{children}</em>,
  code: ({ children }) => (
    <code className="rounded bg-white/15 px-1 py-0.5 text-[13px] font-mono whitespace-pre-wrap">
      {children}
    </code>
  ),
  pre: ({ children }) => (
    <pre className="my-2 overflow-x-auto rounded-lg bg-white/10 p-3 text-[13px] font-mono">
      {children}
    </pre>
  ),
  ul: ({ children }) => (
    <ul className="mb-2 ml-5 list-disc space-y-1 last:mb-0">{children}</ul>
  ),
  ol: ({ children }) => (
    <ol className="mb-2 ml-5 list-decimal space-y-1 last:mb-0">{children}</ol>
  ),
  li: ({ children }) => (
    <li className="whitespace-pre-wrap leading-relaxed break-words">
      {children}
    </li>
  ),
  blockquote: ({ children }) => (
    <blockquote className="border-l-2 border-white/40 pl-3 italic text-blue-50">
      {children}
    </blockquote>
  ),
  hr: () => <hr className="my-3 border-white/20" />,
  h1: ({ children }) => (
    <h1 className="mb-2 mt-1 text-lg font-semibold">{children}</h1>
  ),
  h2: ({ children }) => (
    <h2 className="mb-2 mt-1 text-base font-semibold">{children}</h2>
  ),
  h3: ({ children }) => (
    <h3 className="mb-1 mt-1 text-sm font-semibold">{children}</h3>
  ),
};

// Height budget for a collapsed user bubble — roughly 3 lines at the
// text-sm/leading-relaxed sizing used below (~4.5rem). Anything taller gets
// a "Show more" toggle instead of growing the bubble indefinitely.
const USER_COLLAPSE_CLASS = "max-h-[4.5rem] overflow-hidden";

/**
 * Converts single newlines (soft breaks, which CommonMark otherwise
 * collapses into a single space) into hard breaks by appending the standard
 * two-trailing-spaces markdown syntax. Blank lines — i.e. real paragraph
 * breaks — are left untouched. This is what keeps a user's typed line
 * breaks intact when the text is run through ReactMarkdown, without
 * altering the raw value that gets stored/sent (that conversion only
 * happens here, at render time).
 */
function preserveLineBreaks(text) {
  if (!text) return "";
  return text.replace(/([^\n])\n(?!\n)/g, "$1  \n");
}

// Matches a "Sources" (or "Source"/"References"/"Citations") heading on its
// own line, in any of the common forms an LLM tends to emit it in plain
// markdown: a heading ("## Sources"), bolded ("**Sources:**"), or plain
// ("Sources" / "Sources:"). Everything from that line to the end of the
// message is treated as the sources block.
const SOURCES_HEADING_REGEX =
  /^#{0,6}\s*\*{0,2}\s*(sources?|references?|citations?)\s*\*{0,2}\s*:?\s*$/i;

/**
 * Splits an assistant message's rendered text into the "main answer" and a
 * trailing "Sources" section (if present), so the sources/links can be
 * rendered behind a collapsible toggle instead of always taking up space.
 * Returns `sourcesContent: null` when no such heading is found, in which
 * case the caller should render the text as-is.
 */
function splitSourcesSection(text) {
  if (!text) return { mainContent: text || "", sourcesContent: null };
  const lines = text.split("\n");
  const headingIdx = lines.findIndex((line) =>
    SOURCES_HEADING_REGEX.test(line.trim()),
  );
  if (headingIdx === -1) {
    return { mainContent: text, sourcesContent: null };
  }
  const mainContent = lines.slice(0, headingIdx).join("\n").trimEnd();
  const sourcesContent = lines
    .slice(headingIdx + 1)
    .join("\n")
    .trim();
  if (!sourcesContent) {
    return { mainContent: text, sourcesContent: null };
  }
  return { mainContent, sourcesContent };
}

/**
 * ChatMessageBubble
 * ---------------------------------------------------------------------------
 * Renders a single chat message. Assistant messages flagged with
 * `msg.isStreaming` reveal their text progressively via `useStreamingText`
 * (the Copilot/ChatGPT "typing" effect); all other messages (user messages,
 * and assistant messages restored from history) render instantly.
 *
 * Wrapped in React.memo with a custom comparator so that while one message
 * is streaming, sibling messages (which haven't changed) skip re-rendering
 * entirely — this is what keeps long conversations performant, since a
 * multi-thousand-word streaming answer only re-renders *itself*, not the
 * whole message list.
 *
 * @param {Object} props
 * @param {Object} props.msg - { role, content, timestamp, isStreaming? }
 * @param {boolean} props.responseLoading - true while waiting for the first
 *   token/content of the assistant's reply (shows the "..." indicator).
 * @param {string} props.userInitial - first letter of the user's name.
 * @param {() => void} [props.onStreamTick] - called on every reveal tick so
 *   the parent can run its "auto-scroll if near bottom" check.
 * @param {() => void} [props.onStreamComplete] - called exactly once, when
 *   this message's typing reveal actually finishes. The parent uses this to
 *   persist `isStreaming: false` on the stored message itself — otherwise
 *   the flag set on completion of the *first* reveal never gets cleared
 *   from the cached message data, so re-mounting this bubble later (e.g.
 *   switching chats and back) would read the stale `isStreaming: true` and
 *   replay the whole typing animation again.
 */
function ChatMessageBubble({
  msg,
  responseLoading,
  userInitial,
  onStreamTick,
  onStreamComplete,
  onGenerateDraft,
  conversationId,
}) {
  const { state } = useApp();
  const { user } = state;

  const isAssistant = msg.role === "assistant";
  const isPlaceholder = msg.content === "loading";
  // A "draft_form" message renders an interactive form (built from a category
  // metadata schema) instead of markdown text — see ChatDraftForm.
  const isDraftForm = msg.type === "draft_form";

  // Agent responses sometimes emit a heading marker (#, ##, ###, ...) or
  // list markers (-, *, 1., ...) glued onto the end of a previous line
  // instead of starting their own line, which CommonMark then renders as
  // literal "## text" / "- item" text instead of an actual heading/list.
  // Run headings first (it pulls a trailing heading off the end of a line),
  // then lists (splits any remaining collapsed bullet/numbered items onto
  // their own lines) before this reaches ReactMarkdown/the streaming
  // reveal. User messages are left as-is (that's the user's own typed
  // input, not agent output).
  const rawContent = isPlaceholder ? "" : msg.content || "";
  const normalizedContent = isAssistant
    ? fixCollapsedMarkdownLists(fixMisplacedMarkdownHeadings(rawContent))
    : rawContent;

  const { displayedText, isStreaming } = useStreamingText({
    fullText: normalizedContent,
    isActive: Boolean(isAssistant && msg.isStreaming && !isPlaceholder),
    streamKey:
      msg.assistant_message_id || msg.timestamp?.getTime?.() || msg.content,
    onTick: onStreamTick,
    onComplete: onStreamComplete,
  });

  // ─── Collapsible "Sources" section for assistant messages ─────────────
  // While the answer is still typing out, render the raw revealed text as-is
  // (splitting/toggling a still-growing string would just flicker). Once
  // streaming finishes — or for history messages, which never stream — pull
  // any trailing "Sources"/"References" section out so it can be tucked
  // behind a collapsed toggle by default.
  const { mainContent, sourcesContent } = useMemo(() => {
    if (!isAssistant || isPlaceholder || isStreaming) {
      return { mainContent: displayedText, sourcesContent: null };
    }
    return splitSourcesSection(displayedText);
  }, [isAssistant, isPlaceholder, isStreaming, displayedText]);

  const [sourcesExpanded, setSourcesExpanded] = useState(false);

  // ─── Copy message text ──────────────────────────────────────────────────
  // Copies the *rendered* content (the actual formatted output the user
  // sees — bold text, bullet points, clickable links) rather than the raw
  // markdown source (e.g. "**bold**", "[text](url)"). We read straight from
  // the DOM nodes ReactMarkdown already rendered:
  //  - text/html on the clipboard so pasting into rich targets (Word,
  //    Gmail, Google Docs) preserves formatting/links.
  //  - text/plain as a parallel fallback for plain-text targets, and for
  //    browsers that don't support writing multiple clipboard formats.
  // Assistant messages: pulls from the main-answer node, plus the sources
  // node too if that section is currently expanded (collapsed/hidden
  // content isn't part of what's "rendered" right now, so it's excluded).
  // User messages: reuses `userContentRef` below, which already wraps just
  // the rendered markdown (not the "Show more/less" toggle).
  const [copied, setCopied] = useState(false);
  const copyResetTimeoutRef = useRef(null);
  const assistantContentRef = useRef(null);
  const assistantSourcesRef = useRef(null);

  const getClipboardPayload = () => {
    if (msg.role === "user") {
      const el = userContentRef.current;
      if (!el) return null;
      return {
        html: el.innerHTML,
        text: el.innerText || el.textContent || "",
      };
    }

    const mainEl = assistantContentRef.current;
    if (!mainEl) return null;
    let html = mainEl.innerHTML;
    let text = mainEl.innerText || mainEl.textContent || "";

    if (sourcesExpanded && assistantSourcesRef.current) {
      const sourcesEl = assistantSourcesRef.current;
      html += `<br/><br/><strong>Sources</strong><br/>${sourcesEl.innerHTML}`;
      text += `\n\nSources\n${sourcesEl.innerText || sourcesEl.textContent || ""}`;
    }
    return { html, text };
  };

  const handleCopy = async () => {
    const payload = getClipboardPayload();
    if (!payload || (!payload.text && !payload.html)) return;
    try {
      if (navigator.clipboard?.write && window.ClipboardItem) {
        const item = new ClipboardItem({
          "text/html": new Blob([payload.html], { type: "text/html" }),
          "text/plain": new Blob([payload.text], { type: "text/plain" }),
        });
        await navigator.clipboard.write([item]);
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(payload.text);
      } else {
        // Fallback for browsers/contexts without any Clipboard API.
        const textarea = document.createElement("textarea");
        textarea.value = payload.text;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopied(true);
    } catch (error) {
      // Some browsers/permission policies reject the rich ClipboardItem
      // write — fall back to plain text rather than failing silently.
      try {
        await navigator.clipboard.writeText(payload.text);
        setCopied(true);
      } catch (fallbackError) {
        console.log(fallbackError);
        return;
      }
    }
    if (copyResetTimeoutRef.current) {
      clearTimeout(copyResetTimeoutRef.current);
    }
    copyResetTimeoutRef.current = setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    return () => {
      if (copyResetTimeoutRef.current) {
        clearTimeout(copyResetTimeoutRef.current);
      }
    };
  }, []);

  // ─── Export chat message ───────────────────────────────────────────────
  // Assistant messages only — triggers the backend export flow for this
  // specific message via exportChatMessage(messageId, userId).
  const [exporting, setExporting] = useState(false);
  const exportResetTimeoutRef = useRef(null);
  const [exportError, setExportError] = useState(false);

  const handleExport = async () => {
    if (exporting) return;
    const messageId = msg?.assistant_message_id;
    if (!messageId) return;
    setExportError(false);
    setExporting(true);
    try {
      console.log("message id is");
      console.log(messageId);
      const exportChatResponse = await exportChatMessage(
        messageId,
        conversationId,
        user?.email?.replace("@", "").replace(/\./g, "_"),
      );
      await downloadChat(
        exportChatResponse?.download_url,
        exportChatResponse?.export_id,
      );
    } catch (error) {
      console.log(error);
      setExportError(true);
      if (exportResetTimeoutRef.current) {
        clearTimeout(exportResetTimeoutRef.current);
      }
      exportResetTimeoutRef.current = setTimeout(
        () => setExportError(false),
        2000,
      );
    } finally {
      setExporting(false);
    }
  };

  useEffect(() => {
    return () => {
      if (exportResetTimeoutRef.current) {
        clearTimeout(exportResetTimeoutRef.current);
      }
    };
  }, []);

  // ─── "More actions" menu (three-dots) for assistant messages ────────────
  // Shown only once an assistant response is fully generated (not while the
  // placeholder/loading or streaming reveal is still going — see the render
  // guard below). Clicking the three-dots toggle reveals a small dropdown
  // whose first action is "Generate Draft".
  const [showActionsMenu, setShowActionsMenu] = useState(false);
  const actionsMenuRef = useRef(null);

  // Close the menu when clicking anywhere outside of it (standard dropdown
  // behavior), and only while it's actually open so we don't keep a global
  // listener attached needlessly.
  useEffect(() => {
    if (!showActionsMenu) return;
    const handleClickOutside = (event) => {
      if (
        actionsMenuRef.current &&
        !actionsMenuRef.current.contains(event.target)
      ) {
        setShowActionsMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showActionsMenu]);

  const handleGenerateDraft = () => {
    setShowActionsMenu(false);
    // Surfaces the draft-type options (Media Releases, White Papers, ...)
    // near the chat input at the bottom. The parent (AskCA) owns that row
    // and the send-message flow those options feed into.
    onGenerateDraft?.();
  };

  // ─── Collapse/expand for long user messages ────────────────────────────
  // Only user messages get this treatment (assistant messages already have
  // their own streaming/reveal behavior). Measures the rendered content's
  // natural height against a ~3-line budget and only shows the toggle when
  // content actually overflows it.
  const userContentRef = useRef(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isOverflowing, setIsOverflowing] = useState(false);

  useEffect(() => {
    if (msg.role !== "user") return;
    const el = userContentRef.current;
    if (!el) return;
    // 4.5rem collapse budget (see USER_COLLAPSE_CLASS) — compare against the
    // element's full scrollHeight to know whether collapsing actually hides
    // any content.
    const collapsedBudgetPx = 4.5 * 16;
    setIsOverflowing(el.scrollHeight > collapsedBudgetPx + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [msg.content, msg.role]);

  return (
    <div
      className={`flex min-w-0 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
    >
      {isAssistant && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-pmi-blue/20 to-blue-100 flex items-center justify-center mr-3 mt-0.5">
          <MessageSquare className="h-4 w-4 text-pmi-blue" />
        </div>
      )}
      <div
        className={`${isDraftForm ? "w-full max-w-[90%]" : "max-w-[75%]"} min-w-0 ${
          msg.role === "user"
            ? "bg-gradient-to-br from-pmi-blue to-pmi-navy text-white rounded-2xl rounded-br-md px-4 py-3"
            : "bg-pmi-surface text-gray-900 rounded-2xl rounded-bl-md px-4 py-3 border border-pmi-border/50"
        }`}
      >
        {isPlaceholder ? (
          <MoreHorizontal className="animate-pulse h-8 w-8" />
        ) : isDraftForm ? (
          <ChatDraftForm
            schema={msg.formSchema}
            category={msg.category}
            conversationId={msg.conversation_id || conversationId}
          />
        ) : msg.role === "user" ? (
          <div>
            <div
              ref={userContentRef}
              className={`text-sm ${
                !isExpanded && isOverflowing ? USER_COLLAPSE_CLASS : ""
              }`}
            >
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={userMarkdownComponents}
              >
                {preserveLineBreaks(msg?.content)}
              </ReactMarkdown>
            </div>
            {isOverflowing && (
              <button
                type="button"
                onClick={() => setIsExpanded((prev) => !prev)}
                className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-blue-100 hover:text-white"
              >
                {isExpanded ? (
                  <>
                    Show less <ChevronUp className="h-3 w-3" />
                  </>
                ) : (
                  <>
                    Show more <ChevronDown className="h-3 w-3" />
                  </>
                )}
              </button>
            )}
          </div>
        ) : (
          <div className="markdown-wrapper min-w-0">
            <div ref={assistantContentRef}>
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={markdownComponents}
              >
                {mainContent}
              </ReactMarkdown>
            </div>
            {/* Blinking caret while text is still being revealed — the
                classic Copilot/ChatGPT "still typing" cue. */}
            {isStreaming && (
              <span
                className="inline-block w-[2px] h-4 bg-pmi-blue align-middle ml-0.5 animate-pulse"
                aria-hidden="true"
              />
            )}
            {sourcesContent && (
              <div className="mt-2 border-t border-pmi-border/60 pt-2">
                <button
                  type="button"
                  onClick={() => setSourcesExpanded((prev) => !prev)}
                  aria-expanded={sourcesExpanded}
                  className="inline-flex items-center gap-1 text-xs font-medium text-pmi-blue hover:text-pmi-navy"
                >
                  Sources
                  {sourcesExpanded ? (
                    <ChevronUp className="h-3 w-3" />
                  ) : (
                    <ChevronDown className="h-3 w-3" />
                  )}
                </button>
                {sourcesExpanded && (
                  <div ref={assistantSourcesRef} className="mt-2 text-sm">
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      components={markdownComponents}
                    >
                      {sourcesContent}
                    </ReactMarkdown>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
        {!isPlaceholder && !isDraftForm && (
          <div className="flex items-center justify-between gap-2 mt-1.5">
            <p
              className={`text-xs ${
                msg.role === "user" ? "text-blue-200" : "text-gray-400"
              }`}
            >
              {!responseLoading &&
                !isStreaming &&
                msg.timestamp?.toLocaleString?.([], {
                  dateStyle: "medium",
                  timeStyle: "short",
                })}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopy}
                title={copied ? "Copied!" : "Copy message"}
                className={`inline-flex items-center gap-1 text-xs transition-colors ${
                  msg.role === "user"
                    ? "text-blue-200 hover:text-white"
                    : "text-gray-400 hover:text-gray-600"
                }`}
              >
                {copied ? (
                  <Check className="h-3 w-3" />
                ) : (
                  <Copy className="h-3 w-3" />
                )}
              </button>
              {/* Export — assistant messages only, to the right of copy. */}
              {isAssistant && !isStreaming && (
                <button
                  type="button"
                  onClick={handleExport}
                  disabled={exporting}
                  title={
                    exportError ? "Export failed — try again" : "Export message"
                  }
                  className={`inline-flex items-center gap-1 text-xs transition-colors disabled:opacity-50 ${
                    exportError
                      ? "text-red-500 hover:text-red-600"
                      : "text-gray-400 hover:text-gray-600"
                  }`}
                >
                  {exporting ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <Share className="h-3 w-3" />
                  )}
                </button>
              )}
              {/* Three-dots "more actions" menu — assistant messages only,
                  shown once the response is fully generated. Opens upward
                  and right-aligned so it isn't clipped by the chat scroll
                  container near the bottom of the list. */}
              {isAssistant && !isStreaming && (
                <div className="relative" ref={actionsMenuRef}>
                  <button
                    type="button"
                    onClick={() => setShowActionsMenu((prev) => !prev)}
                    title="More actions"
                    aria-haspopup="true"
                    aria-expanded={showActionsMenu}
                    className="inline-flex items-center gap-1 text-xs text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <MoreVertical className="h-3.5 w-3.5" />
                  </button>
                  {showActionsMenu && (
                    <div className="absolute right-0 bottom-full mb-1 z-30 min-w-[10rem] rounded-lg border border-gray-200 bg-white shadow-lg overflow-hidden">
                      <button
                        type="button"
                        onClick={handleGenerateDraft}
                        className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                      >
                        <FileText className="h-4 w-4 text-pmi-blue" />
                        Generate Draft
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      {msg.role === "user" && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-pmi-navy flex items-center justify-center ml-3 mt-0.5">
          <span className="text-white text-xs font-bold">
            {userInitial || "U"}
          </span>
        </div>
      )}
    </div>
  );
}

function areEqual(prevProps, nextProps) {
  const a = prevProps.msg;
  const b = nextProps.msg;
  return (
    a === b &&
    prevProps.responseLoading === nextProps.responseLoading &&
    prevProps.userInitial === nextProps.userInitial
  );
}

export default memo(ChatMessageBubble, areEqual);
