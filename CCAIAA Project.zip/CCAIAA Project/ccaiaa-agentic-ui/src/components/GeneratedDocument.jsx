import { useState, useEffect } from "react";
import {
  Download,
  FileText,
  CheckCircle,
  AlertCircle,
  FileUp,
  Database,
  Link,
  Link2,
  Search,
} from "lucide-react";
import { Document, Paragraph, TextRun, AlignmentType, Packer } from "docx";
import { saveAs } from "file-saver";
import {
  downloadGeneratedDocument,
  fetchDocumentPreview,
} from "../services/api";
import { DISPLAY_TEXT } from "../utils/constants";
import DocumentVersionPreview from "./DocumentVersionPreview";

function GeneratedDocument({ request, onProceedToReview }) {
  const [downloading, setDownloading] = useState(false);

  const data = {
    recipient: `Secretary\n${request.targetAudience || "Ministry of Health & Family Welfare"}\nGovernment of India\nNew Delhi - 110001`,
    subject: request.topic,
    date: new Date().toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    }),
    body: `
<strong>Subject: ${request.topic}</strong>

Respected Sir/Madam,

<strong>1. Introduction</strong>

Philip Morris International (PMI) respectfully submits this representation in response to the anticipated regulatory changes concerning ${request.regulationTopic || "tobacco products"} under the jurisdiction of ${request.targetAudience || "your esteemed office"}.

PMI India is committed to operating in full compliance with all applicable laws and regulations, including the Cigarettes and Other Tobacco Products Act (COTPA), 2003, and respecting India's obligations under the WHO Framework Convention on Tobacco Control (FCTC).

<strong>2. Reference to Relevant Gazette/Consultation</strong>

This submission refers to [Gazette notification number / Consultation document dated XX-XX-XXXX] concerning proposed amendments to [specific regulation/rule].

<strong>3. Background & Current Law</strong>

The current regulatory framework under COTPA 2003 and CBIC regulations provides for:
- Prohibition on advertisement and promotion (Section 5)
- Statutory health warnings on tobacco product packages (Section 7)  
- Prohibition on sale to and by minors (Section 6)
- Regulation of tar and nicotine content (Section 8)
- Excise duty structure as per CBIC notifications

<strong>4. Comparative & Evidence-Based Analysis</strong>

<em>4.1 International Regulatory Approaches</em>

Our research, drawing from WHO TobReg guidelines and peer-reviewed literature (PubMed: 67 studies; Scopus: 89 studies), indicates that:

a) <strong>Harm Reduction Framework:</strong> Multiple jurisdictions have adopted risk-proportionate regulation based on the continuum of risk principle. Countries such as the United Kingdom, New Zealand, and Japan have implemented differentiated regulatory frameworks for smoke-free products.

[Citation: Public Health England. "Evidence review of e-cigarettes and heated tobacco products 2018." Government of UK, 2018. Retrieved: January 19, 2026]

b) <strong>Excise Taxation:</strong> CBIC data from FY 2024-25 shows that [specific data point with citation]. International best practices suggest differential taxation that reflects relative risk profiles while maintaining public health objectives.

[Citation: CBIC Notification No. XX/2024, dated December 15, 2024. Retrieved from cbic.gov.in on January 18, 2026]

c) <strong>Scientific Evidence:</strong> The Lancet Public Health (2024) published findings indicating [relevant scientific consensus, properly cited].

[Citation: Author et al. "Title of Study." The Lancet Public Health, Vol. X, Issue Y, 2024, pp. XXX-XXX. DOI: XXXXX]

<em>4.2 Domestic Context</em>

India's National Tobacco Control Program (NTCP) under MoHFW has established objectives to reduce tobacco prevalence. PMI's position aligns with these public health goals while advocating for evidence-based, risk-proportionate regulation.

<strong>5. Regulatory Options & Impact Assessment</strong>

<em>5.1 Operational Impact</em>

The proposed regulatory changes may have the following operational implications:
- Manufacturing and supply chain adjustments
- Labeling and packaging compliance costs
- Distribution network modifications
- Retailer training and compliance monitoring

<em>5.2 Enforcement Considerations</em>

Effective enforcement requires:
- Clear definitions and classification criteria
- Adequate transition periods for industry compliance
- Stakeholder consultation mechanisms
- Capacity building for enforcement agencies

<em>5.3 Revenue Implications</em>

For regulations touching excise structure or taxation mechanics:
- Current excise revenue from [product category]: ₹ [Amount] (FY 2024-25)
- Projected impact of proposed changes: [Analysis]
- International comparisons on revenue optimization

[Citation: Department of Revenue, Annual Report FY 2024-25, Retrieved: January 18, 2026]

<strong>6. PMI's Point of View</strong>

PMI respectfully submits that:

a) <strong>Science-Based Approach:</strong> Regulatory frameworks should be grounded in the best available scientific evidence and public health research, consistent with India's FCTC obligations.

b) <strong>Risk-Proportionate Regulation:</strong> Differentiated regulation based on relative risk profiles can support public health objectives while providing adult smokers access to potentially less harmful alternatives.

c) <strong>Clear Legal Framework:</strong> Unambiguous definitions, classification criteria, and compliance requirements ensure effective implementation and enforcement.

d) <strong>Stakeholder Consultation:</strong> Meaningful industry consultation during rule-making enhances regulatory quality and achieves intended policy outcomes.

e) <strong>Adequate Transition Periods:</strong> Sufficient time for compliance (minimum 6-12 months) prevents market disruption and enables systematic implementation.

<strong>7. Requested Actions</strong>

PMI respectfully requests:

1. <strong>Clarification:</strong> Specific definitions and scope of application for [regulation topic]
2. <strong>Consultation:</strong> Opportunity for detailed technical submissions before finalization
3. <strong>Hearing:</strong> Participation in stakeholder consultations or Parliamentary Committee hearings
4. <strong>Impact Assessment:</strong> Publication of Regulatory Impact Assessment (RIA) as per government guidelines
5. <strong>Transition Period:</strong> Minimum 12-month implementation timeline post-notification

<strong>8. Conclusion</strong>

PMI remains committed to full compliance with all applicable laws and constructive engagement with regulatory authorities. We appreciate the opportunity to submit this representation and stand ready to provide additional technical information or participate in consultations.

We request your kind consideration of the points raised and look forward to further engagement on this important matter.

Thanking you for your attention.

<strong>Yours faithfully,</strong>

<em>[Signature]</em>

<strong>Arvind Yadav</strong>
Corporate Affairs Manager
Philip Morris India Private Limited
Registered Office: [Address]
CIN: [Company Identification Number]
Email: arvind.yadav@pmi.com
Phone: +91-XXX-XXXX-XXXX

<strong>CC:</strong>
- Joint Secretary (Tobacco Control), MoHFW
- Commissioner, CBIC
- [Other relevant authorities]

<strong>Enclosures:</strong>
1. Annexure A: Scientific Evidence Summary (67 peer-reviewed studies)
2. Annexure B: International Regulatory Comparison Matrix
3. Annexure C: Impact Assessment Data
4. Annexure D: PMI's Prior Submissions on Related Matters (2022-2025)

---

<strong>EXECUTIVE SUMMARY</strong>

<strong>Issue Statement:</strong> Anticipated regulatory changes concerning ${request.regulationTopic || "tobacco product regulations"} under ${request.jurisdiction}.

<strong>Objective:</strong> Ensure evidence-based, risk-proportionate regulation that supports public health goals while maintaining legal clarity and operational feasibility.

<strong>Issue at Hand:</strong> [Specific regulation/rule] proposes [brief description of proposed changes].

<strong>PMI's Requested Regulatory Consideration:</strong>
- Science-based approach grounded in WHO TobReg guidelines and peer-reviewed research
- Risk-proportionate regulatory framework consistent with FCTC obligations
- Clear definitions and adequate transition periods for industry compliance
- Stakeholder consultation mechanism before finalization

<strong>Evidence Base:</strong> 
- 67 peer-reviewed studies from PubMed, Scopus, The Lancet, BMJ
- 12 CBIC/MoHFW notifications and gazette references (2022-2026)
- 23 internal PMI documents on regulatory positions
- 8 WHO TobReg guidelines and FCTC implementation reports

<strong>Compliance Safeguards:</strong>
✓ All assertions supported by citations with snapshot dates
✓ No youth-targeted or misleading health claims
✓ Statutory warnings and mandatory disclaimers included
✓ Respects FCTC obligations and domestic legal framework
✓ Jurisdiction: ${request?.original_request?.jurisdiction} | Applicability: [National/State as specified]

---

<em>This document was generated with AI assistance and reviewed by Legal & Compliance teams. 
Generated on: ${new Date().toLocaleString("en-IN")}
Document ID: ${request.id}-${Date.now()}
Classification: Internal - For Government Submission</em>
    `.trim(),
  };

  const [documentPreview, setDocumentPreview] = useState(null);

  useEffect(() => {
    const fetchDocumentData = async () => {
      try {
        if (
          request?.status == "DRAFT_APPROVED" ||
          request?.status == "COMPLETED"
        ) {
          const response = await fetchDocumentPreview(request.request_id);
          setDocumentPreview(response);
        }
      } catch (error) {
        console.log(error);
      }
    };
    fetchDocumentData();
  }, [request]);

  const handleResearchDocDownload = async () => {
    setDownloading(true);
    try {
      await downloadGeneratedDocument(
        request?.research_output?.research_s3_key,
      );
      setDownloading(false);
    } catch (error) {
      console.log(error);
      setDownloading(false);
    }
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadGeneratedDocument(request?.document_s3_key);
      setDownloading(false);
    } catch (error) {
      console.log(error);
      setDownloading(false);
    }

    // try {
    //   // Helper function to strip HTML tags and convert to plain text with formatting hints
    //   const stripHtml = (html) => {
    //     return html
    //       .replace(/<strong>(.*?)<\/strong>/g, '$1') // Remove <strong> tags but keep text
    //       .replace(/<em>(.*?)<\/em>/g, '$1')         // Remove <em> tags but keep text
    //       .replace(/<br\s*\/?>/g, '\n')              // Convert <br> to newline
    //       .replace(/<\/p>/g, '\n\n')                 // Convert closing </p> to double newline
    //       .replace(/<[^>]+>/g, '')                   // Remove any remaining HTML tags
    //       .trim()
    //   }

    //   // Helper function to identify if text should be bold (section headers)
    //   const isBoldText = (text) => {
    //     // Make section headers bold: "1. Introduction", "Subject:", numbered sections, etc.
    //     return /^(\d+\.\s|\d+\.\d+\s|Subject:|Respected|Dear)/.test(text.trim())
    //   }

    //   // Clean the body text
    //   const cleanBody = stripHtml(documentData.body)

    //   // Split into paragraphs and filter empty ones
    //   const bodyParagraphs = cleanBody.split('\n\n').filter(p => p.trim())

    //   // Create document sections
    //   const children = [
    //     // Date
    //     new Paragraph({
    //       children: [new TextRun({ text: documentData.date, bold: false })],
    //       spacing: { after: 200 }
    //     }),

    //     // Empty line
    //     new Paragraph({ text: '' }),

    //     // Recipient
    //     new Paragraph({
    //       children: [new TextRun({ text: stripHtml(documentData.recipient), bold: true })],
    //       spacing: { after: 200 }
    //     }),

    //     // Empty line
    //     new Paragraph({ text: '' }),

    //     // Body paragraphs with smart formatting
    //     ...bodyParagraphs.map(para => {
    //       const trimmedPara = para.trim()
    //       const isBold = isBoldText(trimmedPara)

    //       return new Paragraph({
    //         children: [new TextRun({ text: trimmedPara, bold: isBold })],
    //         spacing: { after: 200 },
    //         alignment: isBold ? AlignmentType.LEFT : AlignmentType.JUSTIFIED
    //       })
    //     })
    //   ]

    //   // Create the document
    //   const doc = new Document({
    //     sections: [{
    //       properties: {
    //         page: {
    //           margin: {
    //             top: 1440,    // 1 inch
    //             right: 1440,
    //             bottom: 1440,
    //             left: 1440
    //           }
    //         }
    //       },
    //       children: children
    //     }]
    //   })

    //   // Generate and save the document
    //   const blob = await Packer.toBlob(doc)
    //   saveAs(blob, `PMI_Government_Submission_${request.id}_${new Date().toISOString().split('T')[0]}.docx`)

    //   setDownloading(false)
    // } catch (error) {
    //   console.error('Error generating document:', error)
    //   setDownloading(false)
    //   alert('Error generating document. Please try again.')
    // }
  };

  return (
    <div className="space-y-6">
      {/* Document Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <FileText className="h-8 w-8 text-pmi-blue" />
            <div>
              <h3 className="text-xl font-semibold text-gray-900">
                {request?.topic}
              </h3>
              <p className="text-sm text-gray-500">
                {request?.processing_notes}
              </p>
            </div>
          </div>
          {(request.status == "DRAFT_APPROVED" ||
            request?.status == "COMPLETED") && (
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="flex items-center px-6 py-3 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy transition-colors font-semibold disabled:opacity-50"
            >
              <Download className="h-5 w-5 mr-2" />
              {downloading ? "Downloading..." : "Download Document"}
            </button>
          )}
          {(request.status == "RESEARCH_COMPLETED" ||
            request.status == "RESEARCH_REVIEW_PENDING") && (
            <button
              onClick={handleResearchDocDownload}
              disabled={downloading}
              className="flex items-center px-6 py-3 bg-pmi-blue text-white rounded-lg hover:bg-pmi-navy transition-colors font-semibold disabled:opacity-50"
            >
              <Download className="h-5 w-5 mr-2" />
              {downloading ? "Downloading..." : "Download Document"}
            </button>
          )}
        </div>

        <div className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Content Type</p>
            <p className="font-semibold text-gray-900">{`${request?.validation_result?.topic}`}</p>
          </div>
          {/* <div>
            <p className="text-gray-600">Turnaround Time</p>
            <p className="font-semibold text-green-600">22 min (Under 30-min SLA ✓)</p>
          </div>
          <div>
            <p className="text-gray-600">Word Count</p>
            <p className="font-semibold text-gray-900">~2,450 words</p>
          </div> */}
        </div>
      </div>

      {/* Compliance Checks */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-6">
        <h4 className="text-lg font-semibold text-green-900 mb-4 flex items-center">
          <CheckCircle className="h-5 w-5 mr-2" />
          Compliance Checks Passed
        </h4>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center text-green-800">
            <CheckCircle className="h-4 w-4 mr-2" />
            No youth-targeted claims detected
          </div>
          <div className="flex items-center text-green-800">
            <CheckCircle className="h-4 w-4 mr-2" />
            Statutory warnings included
          </div>
          <div className="flex items-center text-green-800">
            <CheckCircle className="h-4 w-4 mr-2" />
            FCTC obligations respected
          </div>
          <div className="flex items-center text-green-800">
            <CheckCircle className="h-4 w-4 mr-2" />
            Formal, neutral tone maintained
          </div>
          <div className="flex items-center text-green-800">
            <CheckCircle className="h-4 w-4 mr-2" />
            Jurisdiction properly tagged
          </div>
        </div>
      </div>

      {request?.research_output?.citations &&
        request?.research_output?.citations.length > 0 && (
          <div className="bg-white-50 border border-gray-200 rounded-lg">
            <div className="bg-gray-50 px-6 py-3 border-b border-gray-200 flex items-center justify-between">
              <h4 className="font-semibold text-gray-900">
                Click on the references links below to open documents in new
                tab.
              </h4>
            </div>
            <div className="mx-2 my-4">
              {request?.research_output?.citations
                .filter(
                  (ref) =>
                    !(
                      ref?.title?.includes(".json") &&
                      ref?.title?.includes("metadata")
                    ),
                )
                .map((ref) => {
                  const Icon = DISPLAY_TEXT[ref?.source_type]?.icon || FileText;
                  const color = DISPLAY_TEXT[ref?.source_type]?.color || "Gray";
                  const sourceTitle =
                    DISPLAY_TEXT[ref?.source_type]?.title || "Knowledge Base";

                  return (
                    <div
                      key={ref?.index}
                      className="flex items-center gap-2 p-1 transition"
                      title={sourceTitle}
                    >
                      <Icon className={`h-5 w-5 shrink-0 ${color}`} />

                      <a
                        href={ref?.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline text-sm font-medium truncate"
                      >
                        {ref?.title}
                      </a>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

      {/* Document Preview */}
      {/* Compare/version-picking/"Set as Final" are only actionable while a
          draft is pending review (see HITLDraftReview) — once a document
          reaches this approved-document view, it's read-only. */}
      {documentPreview?.current && (
        <DocumentVersionPreview
          previewData={documentPreview}
          allowVersionActions={request?.status === "DRAFT_REVIEW_PENDING"}
        />
      )}

      {/* Action Required */}
      {/* <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
        <h4 className="text-lg font-semibold text-amber-900 mb-2 flex items-center">
          <AlertCircle className="h-5 w-5 mr-2" />
          Action Required
        </h4>
        <p className="text-sm text-amber-800 mb-4">
          This document requires Legal/Compliance approval before submission to government authorities.
        </p>
        <button className="px-6 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 font-medium">
          Submit for Legal Review →
        </button>
      </div> */}

      {request?.status === "DRAFT_APPROVED" && (
        <div className="flex items-center justify-end pt-4 border-t border-gray-200">
          <button
            onClick={onProceedToReview}
            className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold"
          >
            <CheckCircle className="h-5 w-5" />
            Proceed to further review
          </button>
        </div>
      )}
    </div>
  );
}

export default GeneratedDocument;
