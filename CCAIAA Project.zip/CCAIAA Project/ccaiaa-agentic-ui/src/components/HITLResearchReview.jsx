import { useState, useEffect } from 'react'
import { ThumbsDown, ThumbsUp, CheckCircle, XCircle, RotateCcw, AlertTriangle, BookOpen, Database, Globe, FileText, ChevronDown, ChevronUp, Loader2, Newspaper, Bell, User } from 'lucide-react'
import { submitResearchHITLDecision } from '../services/api'
import { useApp } from '../context/AppContext'
import { DISPLAY_TEXT } from "../utils/constants";

/**
 * Human-in-the-Loop Review for the Master Researcher Agent
 * 
 * Displays research strategy, sources found, knowledge gaps, and evidence quality.
 * Allows human reviewer to approve, request revisions, or reject research output.
 */
function HITLResearchReview({ request, checkpoint, onDecisionComplete }) {
  const { addToast } = useApp()
  const [submitting, setSubmitting] = useState("")
  const [feedback, setFeedback] = useState('')
  const [expandedSections, setExpandedSections] = useState({ policyIntel: true, strategy: true, sources: true, gaps: false, policyContext: false })
  const [additionalSources, setAdditionalSources] = useState('')
  const [revisionNotes, setRevisionNotes] = useState('')
  const [votes, setVotes] = useState(new Map());
  const [researchResults, setResearchResults] = useState({});

  // Extract agent output from checkpoint
  const agentOutput = checkpoint?.agent_output || {}
  const sourceSummary = checkpoint.source_summary;
  const sources = checkpoint?.sources || [];
  const totalCitations = sourceSummary.total;
  const uploadedFiles = sourceSummary.uploaded_file;
  const knowledgeBase = sourceSummary.knowledge_base;
  const externalUrl = sourceSummary.external_url;
  const internalUrl = sourceSummary.internal_url;
  const websearch = sourceSummary.web_search;
  const researchStrategy = agentOutput.research_strategy || {}
  const sourcesFound = agentOutput.sources_found || {}
  const knowledgeGaps = agentOutput.knowledge_gaps || []
  const evidenceQuality = agentOutput.evidence_quality_score || 0
  const citationCount = agentOutput.citation_count || 0
  const findings = request?.research_output?.key_findings || []
  const policyIntelligence = sources || null

  const relevanceColors = {
    high: 'bg-red-100 text-red-700',
    medium: 'bg-amber-100 text-amber-700',
    low: 'bg-gray-100 text-gray-600',
  }

  useEffect(() => {
    const updateReasearchResults = () => {
      const sourcesObj = researchResults;
      checkpoint.sources.forEach((source) => {
        sourcesObj[source.source_id] = {
          excludeSource: false,
        }
      });
      setResearchResults(sourcesObj);
    };
    updateReasearchResults();
  }, [checkpoint]);

  const toggleSection = (key) => {
    setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const handleDecision = async (action) => {
    let hitlResponseObject = null;
    switch (action) {
      case "approve":
        try {
          setSubmitting(action);
          const removedIds = Object.keys(researchResults).filter(key => researchResults[key]?.excludeSource);
          hitlResponseObject = {
            "decision": "approve",
            "removed_source_ids": removedIds,
            "feedback": additionalSources,
            "reviewer_id": request?.user_id
          }
        } catch (error) {
          setSubmitting("");
        }
        break;
      case "revise":
        setSubmitting(action);
        const removedIds = Object.keys(researchResults).filter(key => researchResults[key]?.excludeSource);
        hitlResponseObject = {
          "decision": "revise",
          "removed_source_ids": removedIds,
          "feedback": additionalSources,
          "reviewer_id": request?.user_id
        }
        break;
      case "reject":
        setSubmitting(action);
        hitlResponseObject = {
          "decision": "reject",
          "removed_source_ids": [],
          "feedback": "",
          "reviewer_id": request?.user_id
        }
        break;
    }
    try {
      const hitlDecisionResponse = await submitResearchHITLDecision(checkpoint?.hitl_id, hitlResponseObject);
      onDecisionComplete();
      if (hitlDecisionResponse.message.toLowerCase() == "decision submitted successfully") {
        let type = "";
        let title = "";
        let message = "";
        switch (action) {
          case "approve":
            type = "success";
            title = "Research Approved";
            message = "Research Findings approved";
            break;
          case "revise":
            type = "info";
            title = "Revision Rquested";
            message = "Research revision has been requested.";
            break;
          case "reject":
            type = "warning";
            title = "Research Rejected";
            message = "Research has been rejected.";
            break;
        }
        addToast({ type: type, message: message, title: title });
      }
      setSubmitting("");
    } catch (error) {
      addToast({ type: "error", message: "Failed to submit", title: "error" });
      setSubmitting("");
    }
    // if (action === 'reject' && !feedback.trim()) {
    //   addToast({ type: 'warning', message: 'Please provide feedback for rejection.' })
    //   return
    // }
    // if (action === 'revise' && !revisionNotes.trim()) {
    //   addToast({ type: 'warning', message: 'Please provide revision notes.' })
    //   return
    // }

    // setSubmitting(true)
    // try {
    //   await submitHITLDecision(request.request_id, checkpoint.hitl_id, {
    //     action,
    //     feedback: feedback || revisionNotes,
    //     comments: feedback,
    //     modifications: {
    //       additional_sources: additionalSources,
    //       revision_notes: revisionNotes,
    //     },
    //   })

    //   addToast({
    //     type: action === 'approve' ? 'success' : action === 'revise' ? 'info' : 'warning',
    //     title: action === 'approve' ? 'Research Approved' : action === 'revise' ? 'Revision Requested' : 'Research Rejected',
    //     message: action === 'approve'
    //       ? 'Research findings approved. Proceeding to Master Drafter...'
    //       : action === 'revise'
    //         ? 'Revision request sent to Master Researcher.'
    //         : 'Research has been rejected. The workflow will be halted.',
    //   })

    //   onDecisionComplete?.(action)
    // } catch (err) {
    //   addToast({ type: 'error', title: 'Error', message: err.message || 'Failed to submit decision.' })
    // } finally {
    //   setSubmitting(false)
    // }
  }

  function toggleThumbs(feedback, index) {
    const map = new Map(votes);
    switch (feedback) {
      case "relevant":
        if (map.has(index) && map.get(index)) {
          map.delete(index);
        } else {
          map.set(index, true);
        }
        break;
      case "irrelevant":
        if (map.has(index) && !map.get(index)) {
          map.delete(index);
        } else {
          map.set(index, false);
        }
        break;
    }
    setVotes(map);
  }


  const baseClasses =
    "px-3 py-1.5 rounded-md text-sm font-medium transition";


  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-blue-900">Research Review Required</h3>
              <p className="text-sm text-blue-700">Master Researcher has completed its analysis. Please review before proceeding to drafting.</p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-sm font-medium">
            Awaiting Review
          </span>
        </div>
        <div className="grid grid-cols-3 gap-4 text-sm mt-4">
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <p className="text-gray-500">{DISPLAY_TEXT["total"]?.title}</p>
            <p className="text-2xl font-bold text-blue-700">{totalCitations}</p>
          </div>
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <p className="text-gray-500">{DISPLAY_TEXT["uploaded_file"]?.title}</p>
            <p className="text-2xl font-bold text-blue-700">{uploadedFiles}</p>
          </div>
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <p className="text-gray-500">{DISPLAY_TEXT["knowledge_base"]?.title}</p>
            <p className="text-2xl font-bold text-blue-700">{knowledgeBase}</p>
          </div>
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <p className="text-gray-500">{DISPLAY_TEXT["internal_url"]?.title}</p>
            <p className="text-2xl font-bold text-blue-700">{internalUrl}</p>
          </div>
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <p className="text-gray-500">{DISPLAY_TEXT["external_url"]?.title}</p>
            <p className="text-2xl font-bold text-blue-700">{externalUrl}</p>
          </div>
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <p className="text-gray-500">{DISPLAY_TEXT["web_search"]?.title}</p>
            <p className="text-2xl font-bold text-blue-700">{websearch}</p>
          </div>
        </div>
      </div>

      {/* Policy Intelligence Inputs */}
      {policyIntelligence && policyIntelligence && policyIntelligence.length > 0 && (
        <div className="border border-indigo-200 rounded-lg overflow-hidden">
          <button
            onClick={() => toggleSection('policyIntel')}
            className="w-full flex items-center justify-between p-4 bg-indigo-50 hover:bg-indigo-100 transition-colors"
          >
            {/* LEFT CONTENT */}
            <div className="flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <Newspaper className="h-5 w-5 text-indigo-600" />
              </div>

              <div>
                <h3 className="text-lg font-semibold text-blue-900">
                  Research Results
                </h3>
                <p className="text-sm text-blue-700">
                  Review the research results below and click on "Exclude" to remove any result you find irrelevant for draft generation. Numbers in bracket represent relevance score of the source for the request
                </p>
              </div>
            </div>

            {/* RIGHT ICON */}
            {expandedSections.policyIntel ? (
              <ChevronUp className="h-5 w-5 text-indigo-400" />
            ) : (
              <ChevronDown className="h-5 w-5 text-indigo-400" />
            )}
          </button>
          {expandedSections.policyIntel && (
            <div className="p-5 space-y-3">
              {/* <p className="text-sm text-indigo-700 bg-indigo-50 p-3 rounded-lg border border-indigo-100">
                <Bell className="h-4 w-4 inline mr-1.5 -mt-0.5" />
                {policyIntelligence.description}
              </p> */}
              <div className="space-y-3">
                {policyIntelligence.map((alert, idx) => (
                  <div key={idx} className="relative border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-shadow">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center justify-start gap-2 mb-1">
                          {/* <label className="flex items-center gap-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked="true"
                              className="h-4 w-4 text-pmi-blue rounded"
                            />
                          </label> */}
                          <span className="max-w-[75%] text-xs font-medium text-gray-500 uppercase tracking-wide break-words whitespace-normal">{alert?.title}</span>
                          {/* <span className="text-xs text-gray-400">•</span> */}
                          {/* <span className="text-xs text-gray-500">{alert?.date}</span> */}
                          {request?.jurisdiction && (
                            <>
                              <span className="text-xs text-gray-400">•</span>
                              <span className="px-1.5 py-0.5 bg-blue-50 text-blue-700 text-xs rounded">{request?.jurisdiction}</span>
                            </>
                          )}
                        </div>
                        {
                          (alert?.url) ? (<a
                            href={alert?.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline text-sm font-medium"
                          >
                            {alert?.reason}
                          </a>) : (<p className="text-sm font-medium text-gray-900">{alert?.reason}</p>)
                        }
                      </div>
                      {/* <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize flex-shrink-0 ml-3 ${relevanceColors[alert.relevance] || relevanceColors.medium}`}>
                        {alert.relevance} relevance
                      </span> */}
                    </div>
                    <p className="text-sm text-gray-600">{alert?.summary}</p>
                    <div className="flex items-center gap-3 absolute right-2 top-2">

                      <span className="text-sm rounded-md bg-slate-50 px-2.5 py-1 font-medium text-slate-600 ring-1 ring-inset ring-slate-500/10">
                        {researchResults[alert?.source_id]?.excludeSource ? "Excluded" : "Included"}
                      </span>

                      <div className="flex gap-1">
                        {(researchResults[alert?.source_id]?.excludeSource) && (<button
                          onClick={() => {
                            console.log(true);
                            const researchResultsCopy = structuredClone(researchResults);
                            researchResultsCopy[alert?.source_id].excludeSource = false;
                            setResearchResults(researchResultsCopy);
                          }}
                          className={`${baseClasses} ${researchResults[alert?.source_id]?.excludeSource
                            ? "bg-green-400 text-white hover:bg-green-500"
                            : "border border-gray-300 text-gray-600 hover:bg-gray-100"
                            }`}
                        >
                          ✅ Include
                        </button>)}

                        {(!researchResults[alert?.source_id]?.excludeSource) && (<button
                          onClick={() => {
                            console.log("false");
                            console.log(researchResults[alert?.source_id]?.excludeSource);
                            const researchResultsCopy = structuredClone(researchResults);
                            researchResultsCopy[alert?.source_id].excludeSource = true;
                            setResearchResults(researchResultsCopy);
                          }}
                          className={`${baseClasses} ${!researchResults[alert?.source_id]?.excludeSource
                            ? "bg-red-400 text-white hover:bg-red-500"
                            : "border border-gray-300 text-gray-600 hover:bg-gray-100"
                            }`}
                        >
                          🚫 Exclude
                        </button>)}
                      </div>


                      {/* <span className="text-lg text-gray-700">
                        Hide this result
                      </span> */}
                    </div>
                    {/* <div className='flex items-center mt-2'>
                      <p className="text-lg text-gray-600">Is this research result relevant?</p>
                      <ThumbsUp onClick={() => { toggleThumbs("relevant", idx) }} className={`${((votes.has(idx)) && votes.get(idx)) ? "text-blue-500 fill-blue-500" : "text-gray-500"} cursor-pointer ml-2`} />
                      <ThumbsDown onClick={() => { toggleThumbs("irrelevant", idx) }} className={`${((votes.has(idx)) && !votes.get(idx)) ? "text-blue-500 fill-blue-500" : "text-gray-500"} cursor-pointer ml-3`} />
                    </div> */}
                    {/* {(votes.has(idx) && !votes.get(idx)) && (<div className='flex items-center justify-start mt-2'>
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          onChange={(event) => {
                            const researchResultsCopy = researchResults;
                            researchResultsCopy[alert?.source_id].includeSource = !event?.target?.checked;
                            setResearchResults(researchResultsCopy);
                          }}
                          className="h-4 w-4 text-pmi-blue rounded"
                        /> Exclude this result
                      </label>
                      <input onChange={() => {
                        const researchResultsCopy = researchResults;
                        researchResultsCopy[alert?.source_id].reviewerComments = event?.target?.value;
                        setResearchResults(researchResultsCopy);
                      }} className="ml-6 w-1/2 py-1 border-0 border-b border-black text-base focus:outline-none" placeholder='what should be improved in this result?' />
                    </div>)} */}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Research Strategy */}
      {/* <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button
          onClick={() => toggleSection('strategy')}
          className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
        >
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-gray-600" />
            <h4 className="font-semibold text-gray-900">Research Strategy & Methodology</h4>
          </div>
          {expandedSections.strategy ? <ChevronUp className="h-5 w-5 text-gray-400" /> : <ChevronDown className="h-5 w-5 text-gray-400" />}
        </button>
        {expandedSections.strategy && (
          <div className="p-5 space-y-4">
            {findings.length > 0 && (
              <div>
                <p className="text-sm font-medium text-gray-700 mb-2">
                  Key Findings
                </p>

                <ul className="space-y-2">
                  {findings.map((finding, idx) => (
                    <li
                      key={idx}
                      className="grid grid-cols-[auto_1fr] gap-2 text-sm text-gray-600 leading-5"
                    >
                      <CheckCircle className="h-4 w-4 text-green-500 mt-[4px]" />
                      <span>{finding}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

          </div>
        )}
      </div> */}

      {/* Reviewer Input */}
      <div className="border border-gray-200 rounded-lg p-5 space-y-4">
        <h4 className="font-semibold text-gray-900">Feedback</h4>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Additional Sources to Include (Optional)</label>
          <textarea
            value={additionalSources}
            onChange={(e) => setAdditionalSources(e.target.value)}
            rows={2}
            placeholder="Provide feedback or recommend additional sources, websites, documents, or URLs that should be considered during the re-research process."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent focus:outline-none"
          />
        </div>

        {/* <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Comments / Revision Notes</label>
          <textarea
            value={revisionNotes}
            onChange={(e) => { setRevisionNotes(e.target.value); setFeedback(e.target.value) }}
            rows={3}
            placeholder="Provide feedback on the research quality, suggest areas for deeper analysis, or note concerns..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-pmi-blue focus:border-transparent"
          />
        </div> */}
      </div>

      {/* Decision Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
        <button
          onClick={() => handleDecision('reject')}
          disabled={submitting || (additionalSources?.length > 0)}
          className="flex items-center gap-2 px-5 py-2.5 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 font-medium text-sm disabled:opacity-50"
        >
          {(submitting == "reject") ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />}
          Reject Research
        </button>
        <div className="flex gap-3">
          <button
            onClick={() => handleDecision('revise')}
            disabled={submitting || additionalSources.length == 0}
            className="flex items-center gap-2 px-5 py-2.5 border border-amber-300 text-amber-700 rounded-lg hover:bg-amber-50 font-medium text-sm disabled:opacity-50"
          >
            {(submitting == "revise") ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
            Research Revision
          </button>
          <button
            onClick={() => handleDecision('approve')}
            disabled={submitting || additionalSources.length > 0}
            className="flex items-center gap-2 px-5 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium text-sm disabled:opacity-50"
          >
            {(submitting == "approve") ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
            Approve & Proceed to Drafting
          </button>
        </div>
      </div>
    </div>
  )
}

export default HITLResearchReview
