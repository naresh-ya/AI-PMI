import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Activity, CheckCircle, Clock, Brain, Loader2 } from 'lucide-react'
import pmiLogo from '../assets/Philip-Morris-International.png'

function DemoRequest() {
  const navigate = useNavigate()
  const [currentAgentIndex, setCurrentAgentIndex] = useState(0)
  const [currentSubAgentIndex, setCurrentSubAgentIndex] = useState(0)
  const [progress, setProgress] = useState(0)
  const [isComplete, setIsComplete] = useState(false)

  // All 11 agents (4 master agents + 11 total sub-agents = 15 agents, orchestrated by AWS Step Functions)
  const agents = [
    {
      name: '1. Input Validator',
      duration: 10000, // 10 seconds
      findings: 'Request validated. All required fields present. Language: English. Output: Word document.',
      subAgents: []
    },
    {
      name: '2. Master Researcher Agent',
      duration: 10000,
      findings: 'Orchestrating 3 sub-agents to gather comprehensive research data.',
      subAgents: [
        { name: '2.1 Internal Knowledge Agent', duration: 10000, findings: 'Scanning PMI SharePoint - Found 23 documents' },
        { name: '2.2 Database Crawling Agent', duration: 10000, findings: 'Querying PubMed, Scopus - Retrieved 67 papers' },
        { name: '2.3 Web Crawling Agent', duration: 10000, findings: 'Crawling CBIC, MoHFW - Extracted 12 notifications + 8 WHO guidelines' }
      ]
    },
    {
      name: '3. Master Drafting Agent',
      duration: 10000,
      findings: 'Orchestrating content analysis and drafting sub-agents.',
      subAgents: [
        { name: '3.1 Content Analysis Agent', duration: 10000, findings: 'Analyzing 110 sources, identifying key themes' },
        { name: '3.2 Content Drafting Agent', duration: 10000, findings: 'Generating 2,450-word document with citations' }
      ]
    },
    {
      name: '4. Master Review Agent',
      duration: 10000,
      findings: 'Orchestrating debate among 3 review specialists.',
      subAgents: [
        { name: '4.1 Compliance & Risk Review Agent', duration: 10000, findings: 'Checking youth claims, warnings, disclaimers - All passed' },
        { name: '4.2 Regulatory Review Agent', duration: 10000, findings: 'Verifying COTPA, FCTC compliance - Confirmed' },
        { name: '4.3 Legal Review Agent', duration: 10000, findings: 'Legal review passed - Formal tone maintained' },
      ]
    }
  ]

  const [completedAgents, setCompletedAgents] = useState([])
  const [completedSubAgents, setCompletedSubAgents] = useState({})

  useEffect(() => {
    if (isComplete) return

    const currentAgent = agents[currentAgentIndex]
    
    if (!currentAgent) {
      // All agents complete
      setIsComplete(true)
      setTimeout(() => {
        navigate('/request/2') // Navigate to completed request
      }, 2000)
      return
    }

    // If agent has sub-agents, process them one by one
    if (currentAgent.subAgents.length > 0) {
      const currentSubAgent = currentAgent.subAgents[currentSubAgentIndex]
      
      if (currentSubAgent) {
        // Process sub-agent
        const timer = setTimeout(() => {
          setCompletedSubAgents(prev => ({
            ...prev,
            [currentAgentIndex]: [...(prev[currentAgentIndex] || []), currentSubAgentIndex]
          }))
          
          if (currentSubAgentIndex < currentAgent.subAgents.length - 1) {
            // Move to next sub-agent
            setCurrentSubAgentIndex(currentSubAgentIndex + 1)
          } else {
            // All sub-agents done, complete the master agent
            setCompletedAgents(prev => [...prev, currentAgentIndex])
            setCurrentAgentIndex(currentAgentIndex + 1)
            setCurrentSubAgentIndex(0)
          }
          
          setProgress(((currentAgentIndex * 100) + ((currentSubAgentIndex + 1) * 100 / currentAgent.subAgents.length)) / agents.length)
        }, currentSubAgent.duration)

        return () => clearTimeout(timer)
      }
    } else {
      // No sub-agents, just process the main agent
      const timer = setTimeout(() => {
        setCompletedAgents(prev => [...prev, currentAgentIndex])
        setCurrentAgentIndex(currentAgentIndex + 1)
        setProgress(((currentAgentIndex + 1) * 100) / agents.length)
      }, currentAgent.duration)

      return () => clearTimeout(timer)
    }
  }, [currentAgentIndex, currentSubAgentIndex, isComplete])

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              {/* <img src={pmiLogo} alt="PMI Corporate Affairs" className="h-16" /> */}
            <div className="flex items-center space-x-3">
                          {/* <Brain className="h-8 w-8 text-pmi-blue" /> */}
                           <img src={pmiLogo} alt="PMI Corporate Affairs" className="h-20" />
                          <div>
                            <h1 className="text-xl font-bold text-gray-900">PMI Corporate Affairs</h1>
                            <p className="text-sm text-gray-500">Agentic AI Platform</p>
                          </div>
                          </div>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              {isComplete ? '🎉 Document Generated Successfully!' : '⚡ AI Agents Processing Request'}
            </h1>
            <p className="text-gray-600">
              {isComplete 
                ? 'All agents completed their tasks. Redirecting to document...' 
                : 'Watch as our AI agents collaborate to generate your government submission'}
            </p>
            <p className="text-xs text-gray-500 mt-2">
              Orchestrated by AWS Step Functions
            </p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span className="font-medium">Overall Progress</span>
              <span className="font-semibold">{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className="h-4 rounded-full bg-green-500 transition-all duration-500"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>

          {/* Agent List */}
          <div className="space-y-4">
            {agents.map((agent, idx) => {
              const isCompleted = completedAgents.includes(idx)
              const isActive = idx === currentAgentIndex
              const isPending = idx > currentAgentIndex

              return (
                <div key={idx} className={`border rounded-lg p-4 ${
                  isCompleted ? 'border-green-300 bg-green-50' :
                  isActive ? 'border-blue-300 bg-blue-50' :
                  'border-gray-200 bg-gray-50'
                }`}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      {isCompleted && <CheckCircle className="h-5 w-5 text-green-600" />}
                      {isActive && <Loader2 className="h-5 w-5 text-blue-600 animate-spin" />}
                      {isPending && <Clock className="h-5 w-5 text-gray-400" />}
                      <h3 className="font-semibold text-gray-900">{agent.name}</h3>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      isCompleted ? 'bg-green-200 text-green-800' :
                      isActive ? 'bg-blue-200 text-blue-800' :
                      'bg-gray-200 text-gray-600'
                    }`}>
                      {isCompleted ? 'Completed' : isActive ? 'Processing...' : 'Pending'}
                    </span>
                  </div>
                  
                  {(isCompleted || isActive) && (
                    <p className="text-sm text-gray-700 mb-3">{agent.findings}</p>
                  )}

                  {/* Sub-agents - HIDDEN FOR NOW */}
                  {/* {agent.subAgents.length > 0 && (isActive || isCompleted) && (
                    <div className="mt-3 space-y-2 pl-4 border-l-2 border-gray-300">
                      {agent.subAgents.map((subAgent, subIdx) => {
                        const subCompleted = completedSubAgents[idx]?.includes(subIdx)
                        const subActive = isActive && currentSubAgentIndex === subIdx
                        const subPending = isActive ? currentSubAgentIndex < subIdx : !isCompleted

                        return (
                          <div key={subIdx} className="flex items-start space-x-2">
                            {subCompleted && <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />}
                            {subActive && <Activity className="h-4 w-4 text-blue-500 animate-pulse mt-0.5" />}
                            {subPending && <Clock className="h-4 w-4 text-gray-400 mt-0.5" />}
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-800">{subAgent.name}</p>
                              {(subCompleted || subActive) && (
                                <p className="text-xs text-gray-600">{subAgent.findings}</p>
                              )}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )} */}
                </div>
              )
            })}
          </div>

          {isComplete && (
            <div className="mt-8 text-center">
              <div className="inline-flex items-center px-6 py-3 bg-green-600 text-white rounded-lg">
                <CheckCircle className="h-5 w-5 mr-2" />
                Document Ready for Download - Redirecting...
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default DemoRequest
