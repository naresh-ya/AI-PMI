/**
 * wordSuggestions
 * ---------------------------------------------------------------------------
 * Lightweight, fully client-side word-completion for the AskCA chat input.
 * No backend call, no external API, no model download — just a static
 * wordlist with prefix matching. This is intentionally the "cheap" version
 * of autosuggestion (see the feasibility discussion): good enough for
 * completing a partially-typed word, not attempting sentence/phrase
 * prediction (which would need an LLM call).
 *
 * The list mixes common English words with terms specific to this app's
 * domain (tobacco/nicotine regulation, PMI corporate affairs) so that
 * suggestions surface domain vocabulary a generic dictionary wouldn't know
 * about.
 */

// General-purpose common words likely to appear in everyday chat questions.
const COMMON_WORDS = [
  "about",
  "above",
  "action",
  "additional",
  "advice",
  "after",
  "again",
  "against",
  "agreement",
  "all",
  "allow",
  "already",
  "also",
  "although",
  "always",
  "analysis",
  "answer",
  "any",
  "application",
  "apply",
  "approval",
  "approve",
  "approved",
  "area",
  "around",
  "assist",
  "available",
  "based",
  "because",
  "before",
  "begin",
  "between",
  "brief",
  "business",
  "but",
  "can",
  "cannot",
  "certain",
  "change",
  "check",
  "clarify",
  "clear",
  "compare",
  "complete",
  "concern",
  "consider",
  "content",
  "context",
  "continue",
  "correct",
  "could",
  "country",
  "create",
  "current",
  "customer",
  "date",
  "define",
  "department",
  "describe",
  "detail",
  "difference",
  "different",
  "difficult",
  "document",
  "does",
  "draft",
  "during",
  "each",
  "effect",
  "either",
  "employee",
  "example",
  "explain",
  "external",
  "feedback",
  "follow",
  "following",
  "format",
  "generate",
  "government",
  "guidance",
  "have",
  "help",
  "here",
  "however",
  "identify",
  "impact",
  "important",
  "include",
  "information",
  "instead",
  "internal",
  "issue",
  "know",
  "latest",
  "legal",
  "letter",
  "list",
  "market",
  "may",
  "meeting",
  "might",
  "more",
  "much",
  "need",
  "new",
  "next",
  "notification",
  "official",
  "only",
  "other",
  "over",
  "please",
  "policy",
  "possible",
  "present",
  "process",
  "product",
  "provide",
  "question",
  "quick",
  "recent",
  "regarding",
  "region",
  "regulation",
  "regulatory",
  "report",
  "request",
  "require",
  "required",
  "requirement",
  "research",
  "review",
  "same",
  "should",
  "since",
  "some",
  "specific",
  "status",
  "submit",
  "summarize",
  "summary",
  "support",
  "than",
  "that",
  "their",
  "there",
  "these",
  "they",
  "this",
  "those",
  "through",
  "under",
  "update",
  "upload",
  "using",
  "well",
  "what",
  "when",
  "where",
  "whether",
  "which",
  "while",
  "with",
  "within",
  "without",
  "would",
];

// Domain-specific terms (tobacco/nicotine regulation, corporate affairs).
// These are the words a generic English dictionary would either miss
// entirely or flag as "misspelled" — surfacing them as suggestions (and
// exempting them from spellcheck concerns) is the whole reason a custom
// list is worth maintaining here instead of just using a public wordlist.
const DOMAIN_WORDS = [
  "advertising",
  "authorization",
  "brand",
  "certification",
  "combustible",
  "compliance",
  "consumer",
  "distribution",
  "disclosure",
  "duty",
  "enforcement",
  "excise",
  "exportation",
  "harm-reduction",
  "heatstick",
  "importation",
  "inspection",
  "IQOS",
  "jurisdiction",
  "labeling",
  "licensing",
  "manufacturing",
  "marketing",
  "nicotine",
  "obligation",
  "packaging",
  "permit",
  "PMI",
  "pouch",
  "promotion",
  "regulator",
  "retail",
  "smoke-free",
  "statute",
  "supply-chain",
  "tariff",
  "taxation",
  "tobacco",
  "trafficking",
  "vapor",
  "violation",
  "wholesale",
];

// Sorted once at module load (not on every call) — case-insensitive so
// prefix matching below is a simple string comparison.
const WORD_LIST = [...COMMON_WORDS, ...DOMAIN_WORDS].sort((a, b) =>
  a.toLowerCase().localeCompare(b.toLowerCase()),
);

/**
 * Returns up to `limit` words from the list whose lowercase form starts
 * with `prefix` (case-insensitive), shortest matches first (closer
 * completions read as more relevant than long, distantly-related words).
 * The original word's casing is preserved (e.g. "PMI", "IQOS") so proper
 * nouns display correctly regardless of how the user capitalized their
 * partial input.
 *
 * @param {string} prefix - the partial word currently being typed.
 * @param {number} [limit=5]
 * @returns {string[]}
 */
export function getSuggestions(prefix, limit = 5) {
  if (!prefix || prefix.length < 2) return [];
  const lowerPrefix = prefix.toLowerCase();
  const matches = WORD_LIST.filter(
    (word) =>
      word.toLowerCase().startsWith(lowerPrefix) &&
      word.toLowerCase() !== lowerPrefix,
  );
  matches.sort((a, b) => a.length - b.length);
  return matches.slice(0, limit);
}

export default getSuggestions;
