/**
 * markdownHeadingFix.js
 * ---------------------------------------------------------------------------
 * Agent responses sometimes emit markdown where a heading marker (#, ##,
 * ### etc.) ends up glued onto the end of the previous line instead of
 * starting its own line — most commonly right after a list item, e.g.:
 *
 *   - Last bullet point in the list ## Next Section
 *
 * CommonMark (and therefore react-markdown/remark) only recognizes a "#"
 * as a heading when it's the first thing on its own line. When it's stuck
 * onto the end of a list item or paragraph like above, it just renders as
 * literal "## Next Section" text instead of an actual heading — which is
 * the "markdown looks distorted" symptom.
 *
 * fixMisplacedMarkdownHeadings() finds any heading marker that isn't
 * already at the start of a line and moves it down onto its own line
 * (with a blank line separator, so it also correctly closes out a list it
 * was glued to instead of becoming a "lazy continuation" of it).
 */

// Matches a heading marker (1-6 #'s) that:
//  - is preceded by a non-whitespace character possibly followed by
//    spaces/tabs (i.e. it's glued onto the end of existing content on the
//    same line, not sitting at the very start of a line — a real newline
//    breaks this match since [ \t]* does not include \n)
//  - is followed by a space/tab and then more content (the actual heading
//    text) — this is what distinguishes a real heading marker from
//    incidental "#" usage like a hashtag ("#launch") or issue reference
//    ("bug #1234"), neither of which has a space right after the "#"s.
const GLUED_HEADING_REGEX = /(\S)[ \t]*(#{1,6})(?=[ \t]+\S)/g;

/**
 * Moves any mid-line heading marker onto its own line. Safe to call on
 * partial/streaming text — it's a pure string transform with no
 * DOM/async dependency, and only ever touches "# " sequences that would
 * otherwise render as broken/literal text.
 */
export function fixMisplacedMarkdownHeadings(text) {
  if (!text) return "";

  // Leave fenced code blocks completely untouched — a "#" inside a code
  // sample (e.g. a Python comment) is real code, not a misplaced heading.
  const codeBlocks = [];
  let working = text.replace(/```[\s\S]*?```/g, (match) => {
    codeBlocks.push(match);
    return `\u0000CODEBLOCK${codeBlocks.length - 1}\u0000`;
  });

  working = working.replace(GLUED_HEADING_REGEX, "$1\n\n$2");

  // Collapse any 3+ blank-line runs the insertion above may have created.
  working = working.replace(/\n{3,}/g, "\n\n");

  working = working.replace(
    /\u0000CODEBLOCK(\d+)\u0000/g,
    (_, idx) => codeBlocks[Number(idx)],
  );

  return working;
}

export default fixMisplacedMarkdownHeadings;
