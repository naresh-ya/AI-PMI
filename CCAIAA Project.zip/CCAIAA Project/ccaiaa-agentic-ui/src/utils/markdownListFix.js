/**
 * markdownListFix.js
 * ---------------------------------------------------------------------------
 * Agent responses sometimes emit markdown where several list items (or a
 * heading) end up glued together on one physical line instead of each
 * starting its own line, e.g.:
 *
 *   Here is what changed: - Added new section - Removed old clause - Updated tone
 *
 * CommonMark only recognizes "-"/"*"/"+" or "1." as a list marker when it
 * starts its own line. Glued together like this, the whole thing renders as
 * one flat paragraph with literal dashes/numbers in the text instead of an
 * actual bulleted/numbered list — the "list isn't a separate line" symptom.
 *
 * fixCollapsedMarkdownLists() detects this pattern per line and rewrites it
 * so each list item starts its own line (with any leading prose on that
 * line broken out as its own paragraph first).
 *
 * Intended to run AFTER fixMisplacedMarkdownHeadings() (see
 * markdownHeadingFix.js) — that pass already pulls any glued-on heading off
 * the end of a line first, so by the time this runs, a line no longer has a
 * trailing heading marker mixed in with list items.
 */

// Requires the marker be preceded by start-of-line or whitespace, and
// followed by whitespace + non-whitespace (the item's actual text). This is
// what keeps "well-known" or "9am-5pm" from ever matching — there's no
// whitespace immediately around those hyphens — while still matching a
// real "- item" marker anywhere it appears, glued into running text or not.
const BULLET_MARKER_REGEX = /(?<=^|\s)([-*+\u2022])(?=[ \t]+\S)/g;
const ORDERED_MARKER_REGEX = /(?<=^|\s)(\d+)([.)])(?=[ \t]+\S)/g;

function findMatches(line, regex) {
  const matches = [];
  let match;
  regex.lastIndex = 0;
  while ((match = regex.exec(line)) !== null) {
    matches.push({ index: match.index, number: match[1] ? Number(match[1]) : null });
  }
  return matches;
}

// Ordered markers only count as "a list" if their numbers are strictly
// increasing — this is what tells "1. first 2. second 3. third" (a real
// list) apart from something like "call ext. 2. Or reply by. 4pm" landing
// on two "\d+." matches that aren't actually a sequence.
function isIncreasingSequence(matches) {
  for (let i = 1; i < matches.length; i++) {
    if (matches[i].number <= matches[i - 1].number) return false;
  }
  return true;
}

// Splits one line into an intro paragraph (if there's text before the first
// qualifying marker) plus one line per list item, given the sorted marker
// start-indices to split on.
function splitLineAtMarkers(line, markerIndices) {
  if (markerIndices.length === 0) return line;

  const segments = [];
  const introText = line.slice(0, markerIndices[0]).trim();
  if (introText) segments.push(introText);

  for (let i = 0; i < markerIndices.length; i++) {
    const start = markerIndices[i];
    const end = i + 1 < markerIndices.length ? markerIndices[i + 1] : line.length;
    const itemText = line.slice(start, end).trim();
    if (itemText) segments.push(itemText);
  }

  return segments.join("\n");
}

function fixLine(line) {
  const bulletMatches = findMatches(line, BULLET_MARKER_REGEX);
  const orderedMatchesRaw = findMatches(line, ORDERED_MARKER_REGEX);
  const orderedMatches =
    orderedMatchesRaw.length >= 2 && isIncreasingSequence(orderedMatchesRaw)
      ? orderedMatchesRaw
      : [];

  const bulletQualifies = bulletMatches.length >= 2;
  const orderedQualifies = orderedMatches.length >= 2;

  if (!bulletQualifies && !orderedQualifies) return line;

  const combined = [
    ...(bulletQualifies ? bulletMatches : []),
    ...(orderedQualifies ? orderedMatches : []),
  ]
    .map((m) => m.index)
    .sort((a, b) => a - b);

  return splitLineAtMarkers(line, combined);
}

/**
 * Detects list markers (bulleted or numbered) that have been collapsed onto
 * one line with the rest of a paragraph, and rewrites that line so each
 * item — and any leading intro text — gets its own line. Safe to call on
 * partial/streaming text; it's a pure string transform with no DOM/async
 * dependency, and only rewrites lines matching the collapsed-list pattern
 * (at least two same-family markers on one line) — normal prose containing
 * a single hyphen or "N." is left completely untouched.
 */
export function fixCollapsedMarkdownLists(text) {
  if (!text) return "";

  // Leave fenced code blocks untouched — list-marker-looking text inside a
  // code sample is real code, not a collapsed markdown list.
  const codeBlocks = [];
  let working = text.replace(/```[\s\S]*?```/g, (match) => {
    codeBlocks.push(match);
    return `\u0000CODEBLOCK${codeBlocks.length - 1}\u0000`;
  });

  working = working
    .split("\n")
    .map(fixLine)
    .join("\n");

  working = working.replace(/\n{3,}/g, "\n\n");

  working = working.replace(
    /\u0000CODEBLOCK(\d+)\u0000/g,
    (_, idx) => codeBlocks[Number(idx)],
  );

  return working;
}

export default fixCollapsedMarkdownLists;
