// Document templates for pre-population
export const documentTemplates = {
  'Government Advocacy Letter': {
    topic: 'Government Submission on [Regulation Topic]',
    targetAudience: 'CBIC (Department of Revenue)',
    targetLanguage: 'English (India/UK/US)',
    outputFileType: 'Microsoft Word (.docx)',
    regulationTopic: 'Excise duty and taxation policy',
    background: 'CBIC is considering amendments to the excise duty notification. PMI needs to submit a comprehensive position that addresses proposed changes while maintaining compliance with COTPA 2003 and FCTC obligations.',
    sources: 'CBIC website, Gazette notifications (past 24 months), PMI SharePoint legal folder, WHO TobReg guidelines, Department of Revenue circulars',
    stakeholders: 'CBIC Commissioner, Department of Revenue officials, MoHFW (for health aspects)',
    toneRequirements: 'Formal, neutral, compliance-first, fact-based and non-promotional. Respect FCTC obligations while focusing on lawful domestic regulatory considerations.',
    priority: 'high',
    expectedSections: [
      'Recipient and subject line',
      'Introduction of PMI and the writer',
      'Reference to relevant gazette/consultation',
      'Background & Current Law',
      'Comparative & Evidence-Based Analysis',
      'Regulatory Options & Impact Assessment',
      'PMI\'s point of view',
      'Requested Actions',
      'References & Annexures',
      'Executive Summary'
    ]
  },
  'Government Submission with Policy Brief': {
    topic: 'Policy Brief on [Regulation Topic] - [Jurisdiction]',
    targetAudience: 'Ministry of Health & Family Welfare (MoHFW)',
    regulationTopic: 'Tobacco control measures and public health policy',
    background: 'MoHFW is reviewing tobacco control measures under the National Tobacco Control Program (NTCP). PMI seeks to provide evidence-based policy recommendations that balance public health objectives with regulatory clarity.',
    sources: 'MoHFW notifications, NTCP program documents, WHO TobReg, ICMR research, PubMed, Scopus, PMI SharePoint policy briefs, International best practices',
    stakeholders: 'MoHFW Secretary, NTCP Director, State Tobacco Control Cells, WHO Country Office',
    toneRequirements: 'Formal, evidence-based, policy-oriented, neutral. Emphasize public health alignment while providing regulatory recommendations.',
    priority: 'high',
    expectedSections: [
      'Executive Summary',
      'Policy Context & Objectives',
      'Current Regulatory Framework',
      'International Evidence & Best Practices',
      'Policy Options Analysis',
      'Recommendations',
      'Implementation Considerations',
      'Impact Assessment',
      'Annexures with supporting data'
    ]
  },
  'Parliamentary Committee Submission': {
    topic: 'Submission to Parliamentary Standing Committee on [Topic]',
    targetAudience: 'Parliamentary Standing Committee',
    regulationTopic: 'Legislative proposals related to tobacco regulation',
    background: 'Parliamentary Standing Committee is reviewing proposed amendments to tobacco-related legislation. PMI seeks to provide technical input and industry perspective to support informed legislative decision-making.',
    sources: 'Bill texts, Parliamentary debates, Committee hearing transcripts, Legislative Department documents, PMI prior submissions, Constitutional provisions, Comparative legislative analysis',
    stakeholders: 'Committee Chairperson, Committee Members, Legislative Department, Parliamentary Research Service',
    toneRequirements: 'Respectful, technical, fact-based. Acknowledge Parliamentary supremacy while providing industry expertise and technical clarifications.',
    priority: 'high',
    expectedSections: [
      'Submission cover letter',
      'Executive Summary',
      'About PMI and our operations in India',
      'Analysis of proposed legislative provisions',
      'Technical considerations',
      'Comparative legislative approaches',
      'Industry impact assessment',
      'Recommendations and clarifications sought',
      'Conclusion',
      'Annexures'
    ]
  },
  'Consultation Response': {
    topic: 'Response to [Authority] Consultation on [Topic]',
    targetAudience: 'CBIC (Department of Revenue)',
    regulationTopic: 'Draft regulations under public consultation',
    background: 'Government authority has issued draft regulations for public consultation. PMI seeks to provide detailed technical response addressing specific consultation questions and regulatory implications.',
    sources: 'Draft consultation document, Previous consultations, Stakeholder comments, Technical studies, International regulatory approaches, PMI expert inputs',
    stakeholders: 'Consultation authority, Other stakeholders, Industry associations, Technical experts',
    toneRequirements: 'Constructive, solution-oriented, technical. Address consultation questions directly with supporting evidence.',
    priority: 'medium',
    expectedSections: [
      'Response cover letter',
      'Summary of key points',
      'Responses to specific consultation questions',
      'Technical analysis',
      'Alternative regulatory approaches',
      'Cost-benefit considerations',
      'Implementation recommendations',
      'Conclusion',
      'Supporting annexures'
    ]
  },
  'Regulatory Clarification Request': {
    topic: 'Request for Clarification on [Regulation/Notification]',
    targetAudience: 'CBIC (Department of Revenue)',
    regulationTopic: 'Interpretation of regulatory provisions',
    background: 'Recent regulatory notification requires clarification on specific provisions to ensure proper industry compliance. PMI seeks official guidance to avoid inadvertent non-compliance.',
    sources: 'Relevant notifications, CBIC circulars, Legal precedents, Industry practice, PMI compliance records',
    stakeholders: 'CBIC officials, Legal advisors, Compliance teams',
    toneRequirements: 'Respectful, clarity-seeking, compliance-focused. Emphasize good faith effort to comply.',
    priority: 'medium',
    expectedSections: [
      'Request letter',
      'Background on the regulatory provision',
      'Specific points requiring clarification',
      'Current understanding and potential interpretations',
      'Compliance implications',
      'Requested official guidance',
      'Supporting references'
    ]
  },
  'Technical Workshop Proposal': {
    topic: 'Proposal for Technical Workshop on [Topic]',
    targetAudience: 'Ministry of Health & Family Welfare (MoHFW)',
    regulationTopic: 'Technical and scientific aspects of tobacco regulation',
    background: 'Complex technical aspects of proposed regulations would benefit from multi-stakeholder technical workshop. PMI proposes to facilitate expert dialogue between regulators, scientists, and industry.',
    sources: 'Technical literature, Expert networks, Workshop methodologies, International workshop examples, Research institutions',
    stakeholders: 'Regulatory authorities, Research institutions, Technical experts, Industry representatives',
    toneRequirements: 'Collaborative, knowledge-sharing focused. Emphasize mutual learning and evidence-based dialogue.',
    priority: 'low',
    expectedSections: [
      'Proposal letter',
      'Workshop objectives',
      'Proposed agenda and themes',
      'Technical experts and speakers',
      'Workshop methodology',
      'Expected outcomes',
      'Logistics and support',
      'Follow-up plan'
    ]
  }
}

// Document outlines based on Category (Document Type) and Use Case
export const documentOutlines = {
  // ─── Letters ─────────────────────────────────────────────
  'Letters': {
    default: [
      { title: 'Recipient & Subject Line', summary: 'Formal addressing with clear subject matter identification.' },
      { title: 'Introduction', summary: 'Introduction of PMI and the sender\'s credentials.' },
      { title: 'Purpose & Context', summary: 'Clear statement of purpose and relevant regulatory/policy context.' },
      { title: 'Key Points & Analysis', summary: 'Main arguments supported by evidence and data.' },
      { title: 'Requested Actions', summary: 'Specific asks and expected outcomes.' },
      { title: 'Closing & Sign-off', summary: 'Professional closing with contact information.' },
      { title: 'Annexures', summary: 'Supporting documents and references.' }
    ],
    'Submission (Govt, Regulator, Industry body)': [
      { title: 'Recipient & Subject Line', summary: 'Formal addressing to the government authority with subject reference number.' },
      { title: 'Introduction & About PMI', summary: 'Introduction of PMI\'s presence and operations in the jurisdiction.' },
      { title: 'Reference to Notification/Consultation', summary: 'Citation of the specific gazette, notification, or consultation being addressed.' },
      { title: 'Background & Current Regulatory Framework', summary: 'Context on current laws, regulations, and their implications.' },
      { title: 'PMI Position & Evidence-Based Analysis', summary: 'Detailed analysis with scientific and economic evidence supporting PMI\'s view.' },
      { title: 'Comparative International Practices', summary: 'Reference to regulatory approaches in other jurisdictions.' },
      { title: 'Impact Assessment', summary: 'Analysis of economic, health, and stakeholder impacts.' },
      { title: 'Recommendations', summary: 'Specific, actionable policy recommendations.' },
      { title: 'Conclusion & Requested Actions', summary: 'Summary of key asks with clear call to action.' },
      { title: 'Annexures & References', summary: 'Supporting data, research papers, and official documents.' }
    ],
    'Follow-up/ representation': [
      { title: 'Recipient & Subject Line', summary: 'Reference to previous correspondence with date and reference number.' },
      { title: 'Context Recap', summary: 'Brief summary of previous submission/meeting and key points discussed.' },
      { title: 'Updates Since Last Communication', summary: 'Any new developments, data, or circumstances relevant to the matter.' },
      { title: 'Outstanding Items', summary: 'Pending actions or clarifications being sought.' },
      { title: 'Reiteration of Key Asks', summary: 'Reinforcement of primary requests with any additional justification.' },
      { title: 'Proposed Next Steps', summary: 'Suggested timeline and follow-up actions.' },
      { title: 'Closing', summary: 'Professional closing expressing readiness for further engagement.' }
    ]
  },

  // ─── Notes ─────────────────────────────────────────────
  'Notes': {
    default: [
      { title: 'Executive Summary', summary: 'High-level overview of the document\'s key points and recommendations.' },
      { title: 'Background & Context', summary: 'Setting the scene with relevant history and current situation.' },
      { title: 'Analysis & Findings', summary: 'Detailed examination of the topic with evidence.' },
      { title: 'Implications', summary: 'What the findings mean for stakeholders.' },
      { title: 'Recommendations', summary: 'Actionable suggestions based on the analysis.' },
      { title: 'Conclusion', summary: 'Summary and key takeaways.' }
    ],
    'Point of view': [
      { title: 'Executive Summary', summary: 'PMI\'s core position and rationale in brief.' },
      { title: 'Background & Context', summary: 'Regulatory, market, or policy background relevant to the topic.' },
      { title: 'Regional Regulatory Landscape', summary: 'Overview of relevant regulations across key jurisdictions.' },
      { title: 'Evidence & Analysis', summary: 'Scientific, economic, or policy evidence supporting the position.' },
      { title: 'PMI\'s Point of View', summary: 'Clear articulation of PMI\'s stance with supporting arguments.' },
      { title: 'Stakeholder Considerations', summary: 'Impact on various stakeholders and their interests.' },
      { title: 'Recommendations', summary: 'Actionable policy or regulatory recommendations.' },
      { title: 'Conclusion', summary: 'Summary of key messages and call to action.' }
    ],
    'White paper': [
      { title: 'Executive Summary', summary: 'Overview of the white paper\'s scope, findings, and recommendations.' },
      { title: 'Introduction & Objectives', summary: 'Purpose and scope of the white paper.' },
      { title: 'Methodology', summary: 'Research approach and data sources used.' },
      { title: 'Background & Literature Review', summary: 'Existing research and regulatory context.' },
      { title: 'Analysis & Findings', summary: 'Detailed analysis with data and evidence.' },
      { title: 'Discussion', summary: 'Interpretation of findings and their implications.' },
      { title: 'Policy Recommendations', summary: 'Evidence-based recommendations for policymakers.' },
      { title: 'Conclusion', summary: 'Summary of key insights and next steps.' },
      { title: 'References', summary: 'Bibliography and cited sources.' }
    ],
    // Alias for legacy use case names
    'White papers on a policy / product': [
      { title: 'Executive Summary', summary: 'Overview of the white paper\'s scope, findings, and recommendations.' },
      { title: 'Introduction & Objectives', summary: 'Purpose and scope of the white paper.' },
      { title: 'Methodology', summary: 'Research approach and data sources used.' },
      { title: 'Background & Literature Review', summary: 'Existing research and regulatory context.' },
      { title: 'Analysis & Findings', summary: 'Detailed analysis with data and evidence.' },
      { title: 'Discussion', summary: 'Interpretation of findings and their implications.' },
      { title: 'Policy Recommendations', summary: 'Evidence-based recommendations for policymakers.' },
      { title: 'Conclusion', summary: 'Summary of key insights and next steps.' },
      { title: 'References', summary: 'Bibliography and cited sources.' }
    ],
    'Leave-behind notes': [
      { title: 'Meeting Context', summary: 'Reference to the meeting/event and participants.' },
      { title: 'Key Discussion Points', summary: 'Summary of main topics discussed.' },
      { title: 'PMI Position Summary', summary: 'Concise statement of PMI\'s stance on discussed topics.' },
      { title: 'Supporting Evidence', summary: 'Key data points and references supporting PMI\'s position.' },
      { title: 'Next Steps & Action Items', summary: 'Agreed follow-up actions and timeline.' },
      { title: 'Contact Information', summary: 'PMI representatives for further engagement.' }
    ],
    'Product advocacy document': [
      { title: 'Executive Summary', summary: 'Overview of the product category and advocacy objectives.' },
      { title: 'Product Overview', summary: 'Description of the product category and its characteristics.' },
      { title: 'Scientific Evidence', summary: 'Research and studies on risk reduction and product attributes.' },
      { title: 'Regulatory Status', summary: 'Current regulatory classification across jurisdictions.' },
      { title: 'Public Health Alignment', summary: 'How the product category aligns with harm reduction goals.' },
      { title: 'Consumer Insights', summary: 'Data on consumer preferences and usage patterns.' },
      { title: 'Regulatory Framework Proposal', summary: 'Recommended regulatory approach for the product category.' },
      { title: 'Conclusion', summary: 'Summary of key advocacy messages.' }
    ]
  },

  // ─── External Engagements ─────────────────────────────────────────────
  'External Engagements': {
    default: [
      { title: 'Event/Meeting Context', summary: 'Background on the engagement and participants.' },
      { title: 'Key Messages', summary: 'Core talking points to be conveyed.' },
      { title: 'Supporting Evidence', summary: 'Data and facts supporting the key messages.' },
      { title: 'Anticipated Questions', summary: 'Likely questions and prepared responses.' },
      { title: 'Outcome Objectives', summary: 'Desired outcomes from the engagement.' }
    ],
    'Meeting prep': [
      { title: 'Meeting Overview', summary: 'Date, venue, participants, and agenda.' },
      { title: 'Participant Profiles', summary: 'Background on key attendees and their interests/concerns.' },
      { title: 'Objectives', summary: 'PMI\'s goals for the meeting.' },
      { title: 'Key Talking Points', summary: 'Main messages and positions to convey.' },
      { title: 'Supporting Materials', summary: 'Data, documents, and visual aids to reference.' },
      { title: 'Anticipated Questions & Responses', summary: 'Q&A preparation.' },
      { title: 'Red Lines', summary: 'Topics to avoid or handle with caution.' },
      { title: 'Desired Outcomes', summary: 'Specific outcomes and next steps sought.' }
    ],
    'Speeches': [
      { title: 'Opening & Greeting', summary: 'Appropriate salutation and acknowledgments.' },
      { title: 'Introduction & Context', summary: 'Setting the scene and establishing relevance.' },
      { title: 'Core Message 1', summary: 'First key theme with supporting points.' },
      { title: 'Core Message 2', summary: 'Second key theme with supporting points.' },
      { title: 'Core Message 3', summary: 'Third key theme with supporting points.' },
      { title: 'Call to Action', summary: 'What the audience should take away or do.' },
      { title: 'Conclusion', summary: 'Memorable closing statement.' }
    ],
    'Panel discussions': [
      { title: 'Panel Context', summary: 'Event details, moderator, and co-panelists.' },
      { title: 'Topic Overview', summary: 'Main discussion theme and sub-topics.' },
      { title: 'PMI Position', summary: 'Key stance on the discussion topic.' },
      { title: 'Key Talking Points', summary: 'Main messages to weave into discussion.' },
      { title: 'Supporting Data', summary: 'Statistics and evidence to cite.' },
      { title: 'Anticipated Questions', summary: 'Likely questions from moderator/audience.' },
      { title: 'Co-panelist Considerations', summary: 'Other panelists\' likely positions and how to respond.' },
      { title: 'Bridging Statements', summary: 'Phrases to redirect or transition topics.' }
    ],
    'Media interviews': [
      { title: 'Interview Context', summary: 'Media outlet, journalist profile, and interview format.' },
      { title: 'Key Messages', summary: 'Three core messages to convey regardless of questions.' },
      { title: 'Supporting Facts', summary: 'Data points and evidence to reinforce messages.' },
      { title: 'Anticipated Questions', summary: 'Expected questions with prepared responses.' },
      { title: 'Difficult Questions', summary: 'Challenging topics and mitigation strategies.' },
      { title: 'Bridging Techniques', summary: 'Methods to redirect to key messages.' },
      { title: 'Quotable Statements', summary: 'Sound bites designed for media pickup.' }
    ]
  },

  // ─── Press Releases ─────────────────────────────────────────────
  'Press Releases': {
    default: [
      { title: 'Headline', summary: 'Attention-grabbing, factual headline.' },
      { title: 'Dateline & Lead Paragraph', summary: 'Date, location, and the most important information.' },
      { title: 'Supporting Details', summary: 'Additional context and background.' },
      { title: 'Quote(s)', summary: 'Attributed statements from PMI spokesperson.' },
      { title: 'Company Background', summary: 'Standard boilerplate about PMI.' },
      { title: 'Media Contact', summary: 'Contact information for press inquiries.' }
    ]
  },

  // ─── Internal Communications ─────────────────────────────────────────────
  'Internal Communications': {
    default: [
      { title: 'Subject Line', summary: 'Clear, concise subject indicating the communication\'s purpose.' },
      { title: 'Opening', summary: 'Appropriate greeting and context.' },
      { title: 'Key Update/Information', summary: 'Main message or news being communicated.' },
      { title: 'Impact & Implications', summary: 'What this means for the recipients.' },
      { title: 'Action Required', summary: 'Any actions needed from recipients.' },
      { title: 'Closing', summary: 'Sign-off and contact for questions.' }
    ],
    'Business updates': [
      { title: 'Subject & Context', summary: 'Business area and update category.' },
      { title: 'Key Developments', summary: 'Main business news or changes.' },
      { title: 'Performance Highlights', summary: 'Relevant metrics and achievements.' },
      { title: 'Strategic Implications', summary: 'How this aligns with company strategy.' },
      { title: 'Next Steps', summary: 'Upcoming activities and milestones.' },
      { title: 'Closing', summary: 'Acknowledgments and call to action.' }
    ],
    'Communication on regulations': [
      { title: 'Regulatory Update Summary', summary: 'Overview of the regulatory change or development.' },
      { title: 'Background & Context', summary: 'History and circumstances leading to this development.' },
      { title: 'Key Provisions', summary: 'Main elements of the regulation and their requirements.' },
      { title: 'Business Impact', summary: 'How this affects PMI operations and teams.' },
      { title: 'Compliance Requirements', summary: 'Actions needed to ensure compliance.' },
      { title: 'Timeline', summary: 'Key dates and deadlines.' },
      { title: 'Resources & Support', summary: 'Where to get help and additional information.' }
    ],
    'Parliamentary updates': [
      { title: 'Update Summary', summary: 'Overview of parliamentary activity.' },
      { title: 'Legislative Development', summary: 'Details on bills, debates, or committee activities.' },
      { title: 'Key Stakeholders', summary: 'MPs, committees, or parties involved.' },
      { title: 'PMI Relevance', summary: 'How this affects PMI and the industry.' },
      { title: 'PMI Actions', summary: 'Steps PMI is taking in response.' },
      { title: 'Timeline & Next Steps', summary: 'Expected parliamentary calendar and milestones.' }
    ]
  }
}

// Category mapping for legacy category names to new pillar structure
const categoryMapping = {
  'Government Advocacy': 'Letters',
  'Industry Advocacy': 'Notes',
  'External Communications': 'External Engagements',
  'Internal Communications': 'Internal Communications',
  'Press Release': 'Press Releases',
}

// Get document outline based on category and use case
export const getDocumentOutline = (category, useCase) => {
  if (!category) {
    return documentOutlines['Notes']?.default || []
  }
  
  // Map legacy category names to new pillar structure
  const mappedCategory = categoryMapping[category] || category
  
  if (!documentOutlines[mappedCategory]) {
    return documentOutlines['Notes']?.default || []
  }
  
  // Try to get specific use case outline, fall back to default for the category
  return documentOutlines[mappedCategory][useCase] || documentOutlines[mappedCategory].default || []
}

export const getTemplate = (documentType) => {
  return documentTemplates[documentType] || null
}
