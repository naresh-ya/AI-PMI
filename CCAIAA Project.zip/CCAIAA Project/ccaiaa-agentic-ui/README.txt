================================================================================
PMI Corporate Affairs Agentic AI Platform - POC Demo
================================================================================

A React-based proof of concept demonstrating the key features of the PMI 
Corporate Affairs Agentic AI Platform.

================================================================================
DEVELOPER SETUP (FOR NEW TEAM MEMBERS)
================================================================================

PREREQUISITES
-------------
- Node.js 18+ installed
- npm or yarn package manager
- Git installed
- HTTP Access Token from Bitbucket

--------------------------------------------------------------------------------
STEP 1: GENERATE HTTP ACCESS TOKEN
--------------------------------------------------------------------------------

1. Go to Bitbucket: https://source.app.pconnect.biz
2. Click on your Profile icon (top right) -> Manage Account
3. Navigate to HTTP Access Tokens
4. Click "Create token"
5. Enter a token name (e.g., ccaiaa-dev-token)
6. Set permissions:
   - Project permissions: Project read (minimum)
   - Repository permissions: Repository write
7. Click "Create"
8. COPY THE TOKEN IMMEDIATELY - you won't be able to see it again!

--------------------------------------------------------------------------------
STEP 2: CLONE THE REPOSITORY
--------------------------------------------------------------------------------

Replace YOUR_EMAIL and YOUR_TOKEN with your Bitbucket email and the token.

IMPORTANT: Replace @ in your email with %40 and + in token with %2B

Command:
git clone "https://YOUR_EMAIL%40pmintl.net:YOUR_TOKEN@source.app.pconnect.biz/scm/ccaiaa/ccaiaa-agentic-ui.git"

Example:
git clone "https://jdoe%40pmintl.net:BBDC-xxxxxxxxxxxx@source.app.pconnect.biz/scm/ccaiaa/ccaiaa-agentic-ui.git"

--------------------------------------------------------------------------------
STEP 3: CONFIGURE GIT USER (FIRST TIME ONLY)
--------------------------------------------------------------------------------

cd ccaiaa-agentic-ui
git config user.email "your.email@pmintl.net"
git config user.name "Your Name"

--------------------------------------------------------------------------------
STEP 4: INSTALL DEPENDENCIES & RUN
--------------------------------------------------------------------------------

npm install
npm run dev

The application will be available at http://localhost:5173

================================================================================
TROUBLESHOOTING GIT AUTHENTICATION
================================================================================

AUTHENTICATION FAILED ERROR
---------------------------
If you see "fatal: Authentication failed":

1. Verify your HTTP Access Token is valid and not expired
2. Ensure the token has "Repository Write" permission
3. Check that your email is URL-encoded (@ becomes %40)
4. Update your remote URL with a new token:

   git remote set-url origin "https://YOUR_EMAIL%40pmintl.net:YOUR_NEW_TOKEN@source.app.pconnect.biz/scm/ccaiaa/ccaiaa-agentic-ui.git"

TOKEN EXPIRED
-------------
Generate a new token from Bitbucket (Step 1 above) and update your remote URL.

================================================================================
GIT WORKFLOW
================================================================================

DAILY DEVELOPMENT
-----------------

# Pull latest changes
git pull origin master

# Create a feature branch
git checkout -b feature/your-feature-name

# Make changes, then commit
git add .
git commit -m "Description of your changes"

# Push your branch
git push -u origin feature/your-feature-name

MERGING TO MASTER
-----------------
Create a Pull Request in Bitbucket for code review before merging.

================================================================================
FEATURES DEMONSTRATED
================================================================================

1. DASHBOARD (/)
   - Active requests overview with real-time status
   - Statistics cards (Active, Pending Approvals, Completed)
   - Policy Intelligence Feed (AI-monitored regulatory updates)
   - Agent Status monitoring
   - Quick actions for creating new requests

2. NEW REQUEST WIZARD (/new-request)
   - 4-step guided form
   - Real-time validation with AI confidence scoring
   - Estimated completion time and agent requirements

3. REQUEST DETAIL VIEW (/request/:id)
   - Real-time agent progress tracking
   - Sub-agent activity monitoring
   - Interactive timeline of events
   - AI Chat assistant for questions about the request

4. APPROVAL QUEUE (/approvals)
   - Human-in-the-loop (HITL) approval gates
   - Document preview before approval
   - Approve/Reject workflow with feedback

================================================================================
TECH STACK
================================================================================

- Frontend Framework: React 18
- Build Tool: Vite
- Styling: Tailwind CSS
- Routing: React Router v6
- Icons: Lucide React
- Date Handling: date-fns

================================================================================
PROJECT STRUCTURE
================================================================================

ccaiaa-agentic-ui/
├── src/
│   ├── components/
│   │   ├── Dashboard.jsx          # Main dashboard view
│   │   ├── NewRequest.jsx         # 4-step request wizard
│   │   ├── RequestDetail.jsx      # Agent progress tracking
│   │   └── ApprovalQueue.jsx      # HITL approval interface
│   ├── App.jsx                    # Main app with routing
│   ├── main.jsx                   # React entry point
│   └── index.css                  # Tailwind CSS imports
├── index.html                     # HTML template
├── vite.config.js                 # Vite configuration
├── tailwind.config.js             # Tailwind configuration
├── postcss.config.js              # PostCSS configuration
└── package.json                   # Project dependencies

================================================================================
BUILD FOR PRODUCTION
================================================================================

npm run build

This creates an optimized build in the dist/ folder.

================================================================================
LICENSE
================================================================================

Internal PMI Project - Confidential

================================================================================
SUPPORT
================================================================================

For questions or issues, contact the PMI Corporate Affairs AI Team.
