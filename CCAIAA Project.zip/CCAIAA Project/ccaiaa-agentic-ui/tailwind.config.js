import typography from '@tailwindcss/typography'

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],

  theme: {
    extend: {
      colors: {
        'pmi-blue': '#003DA5',
        'pmi-navy': '#001F5B',
        'pmi-gray': '#6B7280',
        'pmi-light': '#F0F4FF',
        'pmi-surface': '#F7F9FC',
        'pmi-border': '#E2E8F0',
      }
    },
  },

  plugins: [
    typography,
  ],
}