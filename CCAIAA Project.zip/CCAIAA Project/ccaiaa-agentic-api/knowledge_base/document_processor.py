"""
Knowledge Base Builder for PMI Agentic AI Platform

Handles document ingestion, chunking, embedding, and indexing for local documents.
Supports PDF, DOCX, and TXT files with metadata extraction and semantic search.

Future: Will be extended to support SharePoint integration.
"""

import json
import logging
from typing import Dict, Any, List, Optional, Tuple
import os
import boto3
from datetime import datetime
import hashlib
import mimetypes
from pathlib import Path

# Document processing libraries
import PyPDF2
import docx
from docx import Document
import fitz  # PyMuPDF for better PDF processing
import pandas as pd

# Text processing
import re
from nltk.tokenize import sent_tokenize, word_tokenize
import nltk
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

# AWS services
from boto3.dynamodb.types import TypeDeserializer, TypeSerializer

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
bedrock_client = boto3.client('bedrock-runtime')
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

# Configuration
BEDROCK_EMBEDDING_MODEL = 'amazon.titan-embed-text-v1'
CHUNK_SIZE = 1000  # Characters per chunk
CHUNK_OVERLAP = 200  # Overlap between chunks
DOCUMENTS_BUCKET = os.environ.get('DOCUMENTS_BUCKET', 'pmi-agentic-ai-documents')

class DocumentProcessor:
    """Handles document parsing and content extraction"""
    
    def __init__(self):
        self.supported_types = {
            '.pdf': self._process_pdf,
            '.docx': self._process_docx,
            '.doc': self._process_docx,  # Will try docx processing
            '.txt': self._process_txt,
            '.md': self._process_txt
        }
    
    def process_document(self, file_path: str) -> Dict[str, Any]:
        """
        Process a document and extract content, metadata, and structure
        
        Args:
            file_path: Path to the document file
            
        Returns:
            Document data with content, metadata, and structure
        """
        
        logger.info(f"Processing document: {file_path}")
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Document not found: {file_path}")
        
        # Get file info
        file_info = self._get_file_info(file_path)
        
        # Determine processor based on file extension
        file_ext = file_info['extension'].lower()
        
        if file_ext not in self.supported_types:
            raise ValueError(f"Unsupported file type: {file_ext}")
        
        # Process document content
        processor = self.supported_types[file_ext]
        content_data = processor(file_path)
        
        # Combine file info with content data
        document_data = {
            **file_info,
            **content_data,
            'processing_timestamp': datetime.now().isoformat(),
            'content_hash': self._calculate_content_hash(content_data.get('full_text', ''))
        }
        
        logger.info(f"Document processed successfully: {file_info['filename']}")
        
        return document_data
    
    def _get_file_info(self, file_path: str) -> Dict[str, Any]:
        """Extract basic file information and metadata"""
        
        path_obj = Path(file_path)
        stat = path_obj.stat()
        
        return {
            'filename': path_obj.name,
            'filepath': str(path_obj.absolute()),
            'extension': path_obj.suffix,
            'file_size': stat.st_size,
            'created_date': datetime.fromtimestamp(stat.st_ctime).isoformat(),
            'modified_date': datetime.fromtimestamp(stat.st_mtime).isoformat(),
            'mime_type': mimetypes.guess_type(file_path)[0]
        }
    
    def _process_pdf(self, file_path: str) -> Dict[str, Any]:
        """Process PDF document using PyMuPDF (fitz) for better extraction"""
        
        try:
            # Use PyMuPDF for better text extraction
            doc = fitz.open(file_path)
            
            full_text = ""
            pages = []
            
            for page_num in range(doc.page_count):
                page = doc[page_num]
                page_text = page.get_text()
                
                pages.append({
                    'page_number': page_num + 1,
                    'text': page_text,
                    'word_count': len(page_text.split())
                })
                
                full_text += f"\n--- Page {page_num + 1} ---\n{page_text}\n"
            
            doc.close()
            
            # Extract metadata
            doc_info = fitz.open(file_path)
            metadata = doc_info.metadata
            doc_info.close()
            
            return {
                'document_type': 'pdf',
                'full_text': full_text.strip(),
                'pages': pages,
                'page_count': len(pages),
                'total_words': len(full_text.split()),
                'pdf_metadata': metadata,
                'extraction_method': 'PyMuPDF'
            }
            
        except Exception as e:
            logger.warning(f"PyMuPDF extraction failed, falling back to PyPDF2: {str(e)}")
            
            # Fallback to PyPDF2
            try:
                with open(file_path, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    
                    full_text = ""
                    pages = []
                    
                    for page_num, page in enumerate(pdf_reader.pages):
                        page_text = page.extract_text()
                        
                        pages.append({
                            'page_number': page_num + 1,
                            'text': page_text,
                            'word_count': len(page_text.split())
                        })
                        
                        full_text += f"\n--- Page {page_num + 1} ---\n{page_text}\n"
                    
                    return {
                        'document_type': 'pdf',
                        'full_text': full_text.strip(),
                        'pages': pages,
                        'page_count': len(pages),
                        'total_words': len(full_text.split()),
                        'pdf_metadata': pdf_reader.metadata,
                        'extraction_method': 'PyPDF2'
                    }
                    
            except Exception as e2:
                logger.error(f"Both PDF extraction methods failed: {str(e2)}")
                raise Exception(f"PDF processing failed: {str(e2)}")
    
    def _process_docx(self, file_path: str) -> Dict[str, Any]:
        """Process DOCX document"""
        
        try:
            doc = Document(file_path)
            
            # Extract paragraphs
            paragraphs = []
            full_text = ""
            
            for i, para in enumerate(doc.paragraphs):
                if para.text.strip():
                    paragraphs.append({
                        'paragraph_number': i + 1,
                        'text': para.text,
                        'style': para.style.name if para.style else 'Normal',
                        'word_count': len(para.text.split())
                    })
                    
                    full_text += para.text + "\n"
            
            # Extract tables
            tables = []
            for i, table in enumerate(doc.tables):
                table_data = []
                for row in table.rows:
                    row_data = [cell.text for cell in row.cells]
                    table_data.append(row_data)
                
                tables.append({
                    'table_number': i + 1,
                    'data': table_data,
                    'row_count': len(table_data),
                    'column_count': len(table_data[0]) if table_data else 0
                })
            
            # Extract document properties
            core_props = doc.core_properties
            
            return {
                'document_type': 'docx',
                'full_text': full_text.strip(),
                'paragraphs': paragraphs,
                'tables': tables,
                'paragraph_count': len(paragraphs),
                'table_count': len(tables),
                'total_words': len(full_text.split()),
                'docx_metadata': {
                    'title': core_props.title,
                    'author': core_props.author,
                    'subject': core_props.subject,
                    'created': core_props.created.isoformat() if core_props.created else None,
                    'modified': core_props.modified.isoformat() if core_props.modified else None
                },
                'extraction_method': 'python-docx'
            }
            
        except Exception as e:
            logger.error(f"DOCX processing failed: {str(e)}")
            raise Exception(f"DOCX processing failed: {str(e)}")
    
    def _process_txt(self, file_path: str) -> Dict[str, Any]:
        """Process plain text document"""
        
        try:
            # Try different encodings
            encodings = ['utf-8', 'utf-16', 'latin-1', 'cp1252']
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as file:
                        full_text = file.read()
                    break
                except UnicodeDecodeError:
                    continue
            else:
                raise Exception("Could not decode text file with any supported encoding")
            
            # Simple paragraph detection (double newlines)
            paragraphs = []
            for i, para in enumerate(full_text.split('\n\n')):
                if para.strip():
                    paragraphs.append({
                        'paragraph_number': i + 1,
                        'text': para.strip(),
                        'word_count': len(para.split())
                    })
            
            return {
                'document_type': 'text',
                'full_text': full_text,
                'paragraphs': paragraphs,
                'paragraph_count': len(paragraphs),
                'total_words': len(full_text.split()),
                'encoding': encoding,
                'extraction_method': 'plain_text'
            }
            
        except Exception as e:
            logger.error(f"Text processing failed: {str(e)}")
            raise Exception(f"Text processing failed: {str(e)}")
    
    def _calculate_content_hash(self, content: str) -> str:
        """Calculate SHA-256 hash of content for deduplication"""
        return hashlib.sha256(content.encode('utf-8')).hexdigest()


class DocumentChunker:
    """Handles document chunking with smart splitting strategies"""
    
    def __init__(self, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP):
        self.chunk_size = chunk_size
        self.overlap = overlap
    
    def chunk_document(self, document_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Create semantic chunks from document content
        
        Args:
            document_data: Processed document data
            
        Returns:
            List of document chunks with metadata
        """
        
        logger.info(f"Chunking document: {document_data['filename']}")
        
        full_text = document_data.get('full_text', '')
        
        if not full_text:
            logger.warning(f"No text content found in document: {document_data['filename']}")
            return []
        
        # Choose chunking strategy based on document type
        doc_type = document_data.get('document_type', 'text')
        
        if doc_type == 'pdf' and 'pages' in document_data:
            chunks = self._chunk_by_pages(document_data)
        elif doc_type == 'docx' and 'paragraphs' in document_data:
            chunks = self._chunk_by_paragraphs(document_data)
        else:
            chunks = self._chunk_by_sentences(document_data)
        
        # Add chunk metadata
        for i, chunk in enumerate(chunks):
            chunk.update({
                'chunk_id': f"{document_data['content_hash']}_{i:04d}",
                'chunk_number': i + 1,
                'total_chunks': len(chunks),
                'source_document': document_data['filename'],
                'source_filepath': document_data['filepath'],
                'document_type': doc_type,
                'chunk_size': len(chunk['content']),
                'word_count': len(chunk['content'].split()),
                'created_timestamp': datetime.now().isoformat()
            })
        
        logger.info(f"Created {len(chunks)} chunks for document: {document_data['filename']}")
        
        return chunks
    
    def _chunk_by_pages(self, document_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Chunk PDF by pages with smart splitting if pages are too large"""
        
        chunks = []
        pages = document_data.get('pages', [])
        
        for page in pages:
            page_text = page['text']
            page_num = page['page_number']
            
            if len(page_text) <= self.chunk_size:
                # Page fits in one chunk
                chunks.append({
                    'content': page_text,
                    'metadata': {
                        'page_number': page_num,
                        'chunk_type': 'page',
                        'is_complete_page': True
                    }
                })
            else:
                # Split large page into sentences
                page_chunks = self._split_text_by_sentences(page_text)
                
                for i, chunk_text in enumerate(page_chunks):
                    chunks.append({
                        'content': chunk_text,
                        'metadata': {
                            'page_number': page_num,
                            'page_chunk': i + 1,
                            'chunk_type': 'page_section',
                            'is_complete_page': False
                        }
                    })
        
        return chunks
    
    def _chunk_by_paragraphs(self, document_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Chunk DOCX by paragraphs with smart grouping"""
        
        chunks = []
        paragraphs = document_data.get('paragraphs', [])
        
        current_chunk = ""
        current_metadata = []
        
        for para in paragraphs:
            para_text = para['text']
            para_num = para['paragraph_number']
            
            # Check if adding this paragraph would exceed chunk size
            if len(current_chunk + para_text) > self.chunk_size and current_chunk:
                # Save current chunk
                chunks.append({
                    'content': current_chunk.strip(),
                    'metadata': {
                        'paragraphs': current_metadata,
                        'chunk_type': 'paragraph_group',
                        'paragraph_count': len(current_metadata)
                    }
                })
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap_text(current_chunk)
                current_chunk = overlap_text + para_text + "\n"
                current_metadata = [para_num]
            else:
                # Add to current chunk
                current_chunk += para_text + "\n"
                current_metadata.append(para_num)
        
        # Add final chunk
        if current_chunk.strip():
            chunks.append({
                'content': current_chunk.strip(),
                'metadata': {
                    'paragraphs': current_metadata,
                    'chunk_type': 'paragraph_group',
                    'paragraph_count': len(current_metadata)
                }
            })
        
        return chunks
    
    def _chunk_by_sentences(self, document_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Chunk by sentences for generic text documents"""
        
        full_text = document_data['full_text']
        chunks = self._split_text_by_sentences(full_text)
        
        return [
            {
                'content': chunk_text,
                'metadata': {
                    'chunk_type': 'sentence_group',
                    'sentence_based': True
                }
            }
            for chunk_text in chunks
        ]
    
    def _split_text_by_sentences(self, text: str) -> List[str]:
        """Split text into chunks by sentences, respecting chunk size and overlap"""
        
        sentences = sent_tokenize(text)
        chunks = []
        current_chunk = ""
        
        for sentence in sentences:
            # Check if adding this sentence would exceed chunk size
            if len(current_chunk + sentence) > self.chunk_size and current_chunk:
                chunks.append(current_chunk.strip())
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap_text(current_chunk)
                current_chunk = overlap_text + sentence + " "
            else:
                current_chunk += sentence + " "
        
        # Add final chunk
        if current_chunk.strip():
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def _get_overlap_text(self, text: str) -> str:
        """Get overlap text from the end of current chunk"""
        
        if len(text) <= self.overlap:
            return text
        
        # Get last 'overlap' characters and try to end at sentence boundary
        overlap_text = text[-self.overlap:]
        
        # Find last sentence boundary in overlap
        sentences = sent_tokenize(overlap_text)
        if len(sentences) > 1:
            # Use complete sentences for overlap
            return " ".join(sentences[-2:]) + " "
        else:
            return overlap_text + " "


class KnowledgeBaseBuilder:
    """Main class for building and managing the knowledge base"""
    
    def __init__(self):
        self.processor = DocumentProcessor()
        self.chunker = DocumentChunker()
        self.kb_table = dynamodb.Table('pmi-agentic-ai-knowledge-base')
        
    def build_knowledge_base(self, documents_folder: str, force_rebuild: bool = False) -> Dict[str, Any]:
        """
        Build knowledge base from local documents folder
        
        Args:
            documents_folder: Path to folder containing documents
            force_rebuild: Whether to rebuild existing documents
            
        Returns:
            Summary of knowledge base building process
        """
        
        logger.info(f"Building knowledge base from: {documents_folder}")
        
        if not os.path.exists(documents_folder):
            raise FileNotFoundError(f"Documents folder not found: {documents_folder}")
        
        # Discover documents
        documents = self._discover_documents(documents_folder)
        
        build_summary = {
            'total_documents': len(documents),
            'processed_documents': 0,
            'failed_documents': 0,
            'total_chunks': 0,
            'errors': [],
            'processing_start': datetime.now().isoformat()
        }
        
        for doc_path in documents:
            try:
                # Check if document already exists (unless force rebuild)
                if not force_rebuild and self._document_exists(doc_path):
                    logger.info(f"Document already in KB, skipping: {os.path.basename(doc_path)}")
                    continue
                
                # Process document
                doc_data = self.processor.process_document(doc_path)
                
                # Create chunks
                chunks = self.chunker.chunk_document(doc_data)
                
                if not chunks:
                    logger.warning(f"No chunks created for document: {doc_path}")
                    continue
                
                # Generate embeddings and store chunks
                stored_chunks = self._store_document_chunks(chunks, doc_data)
                
                build_summary['processed_documents'] += 1
                build_summary['total_chunks'] += len(stored_chunks)
                
                logger.info(f"Stored {len(stored_chunks)} chunks for: {os.path.basename(doc_path)}")
                
            except Exception as e:
                logger.error(f"Failed to process document {doc_path}: {str(e)}")
                build_summary['failed_documents'] += 1
                build_summary['errors'].append({
                    'document': doc_path,
                    'error': str(e)
                })
        
        build_summary['processing_end'] = datetime.now().isoformat()
        
        logger.info(f"Knowledge base building completed: {build_summary}")
        
        return build_summary
    
    def _discover_documents(self, folder_path: str) -> List[str]:
        """Discover supported document files in folder and subfolders"""
        
        supported_extensions = {'.pdf', '.docx', '.doc', '.txt', '.md'}
        documents = []
        
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                if Path(file).suffix.lower() in supported_extensions:
                    documents.append(os.path.join(root, file))
        
        logger.info(f"Discovered {len(documents)} documents in {folder_path}")
        
        return documents
    
    def _document_exists(self, doc_path: str) -> bool:
        """Check if document already exists in knowledge base"""
        
        # Create a simple document ID based on path and modification time
        stat = os.stat(doc_path)
        doc_id = f"{doc_path}_{stat.st_mtime}"
        
        try:
            response = self.kb_table.get_item(Key={'document_id': doc_id})
            return 'Item' in response
        except Exception:
            return False
    
    def _store_document_chunks(self, chunks: List[Dict[str, Any]], doc_data: Dict[str, Any]) -> List[str]:
        """Generate embeddings and store chunks in knowledge base"""
        
        stored_chunks = []
        
        for chunk in chunks:
            try:
                # Generate embedding for chunk content
                embedding = self._generate_embedding(chunk['content'])
                
                # Prepare knowledge base item
                kb_item = {
                    'chunk_id': chunk['chunk_id'],
                    'document_id': f"{doc_data['filepath']}_{os.path.getmtime(doc_data['filepath'])}",
                    'content': chunk['content'],
                    'embedding': embedding,
                    'metadata': {
                        **chunk.get('metadata', {}),
                        'source_document': doc_data['filename'],
                        'document_type': doc_data['document_type'],
                        'file_path': doc_data['filepath'],
                        'chunk_number': chunk['chunk_number'],
                        'total_chunks': chunk['total_chunks'],
                        'word_count': chunk['word_count'],
                        'created_timestamp': chunk['created_timestamp']
                    },
                    'document_metadata': {
                        'filename': doc_data['filename'],
                        'file_size': doc_data['file_size'],
                        'created_date': doc_data['created_date'],
                        'modified_date': doc_data['modified_date'],
                        'total_words': doc_data['total_words'],
                        'content_hash': doc_data['content_hash']
                    }
                }
                
                # Store in DynamoDB
                self.kb_table.put_item(Item=kb_item)
                stored_chunks.append(chunk['chunk_id'])
                
            except Exception as e:
                logger.error(f"Failed to store chunk {chunk['chunk_id']}: {str(e)}")
        
        return stored_chunks
    
    def _generate_embedding(self, text: str) -> List[float]:
        """Generate embedding for text using AWS Bedrock"""
        
        try:
            response = bedrock_client.invoke_model(
                modelId=BEDROCK_EMBEDDING_MODEL,
                body=json.dumps({
                    "inputText": text[:8000]  # Titan embedding model limit
                })
            )
            
            response_body = json.loads(response['body'].read())
            embedding = response_body['embedding']
            
            return embedding
            
        except Exception as e:
            logger.error(f"Failed to generate embedding: {str(e)}")
            # Return zero vector as fallback
            return [0.0] * 1536  # Titan embedding dimension


# Lambda handler for knowledge base building
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for knowledge base operations
    
    Supports:
    - build_kb: Build knowledge base from documents folder
    - search_kb: Search knowledge base for relevant chunks
    """
    
    try:
        action = event.get('action', 'build_kb')
        
        kb_builder = KnowledgeBaseBuilder()
        
        if action == 'build_kb':
            documents_folder = event.get('documents_folder', '/tmp/documents')
            force_rebuild = event.get('force_rebuild', False)
            
            result = kb_builder.build_knowledge_base(documents_folder, force_rebuild)
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'action': 'build_kb',
                    'result': result
                })
            }
            
        elif action == 'search_kb':
            # This will be implemented in the next component
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'action': 'search_kb',
                    'message': 'Search functionality will be implemented next'
                })
            }
            
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': f'Unknown action: {action}'
                })
            }
            
    except Exception as e:
        logger.error(f"Knowledge base operation failed: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Knowledge base operation failed',
                'details': str(e)
            })
        }
