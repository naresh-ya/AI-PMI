"""
KB Sync Failure Handler — pmi-kb-sync-failure-handler
======================================================
Triggered by: EventBridge rule on Bedrock Knowledge Base ingestion job completion.

When a KB sync completes, this Lambda:
1. Reads the ingestion job failure reasons
2. Parses the S3 URIs of files that failed (unsupported format, etc.)
3. Moves those files + their .metadata.json to Exception_docs/ within the same folder

This is fully event-driven — zero polling, triggered automatically after every sync.
"""

import json
import logging
import os
import re
from typing import Any, Dict, List

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
bedrock_agent_client = boto3.client('bedrock-agent', region_name=os.environ.get('AWS_REGION', 'eu-west-1'))

KNOWLEDGE_BASE_ID = os.environ.get('BEDROCK_KB_ID', 'OSJDPJLTNC')
DATA_SOURCE_ID = os.environ.get('KB_DATA_SOURCE_ID', 'D4X2WEWFFU')


def _move_to_exception_docs(bucket: str, key: str, reason: str) -> bool:
    """Move a file to Exception_docs/ within the same team folder path."""
    parts = key.rsplit('/', 1)
    if len(parts) == 2:
        folder_path = parts[0]
        filename = parts[1]
    else:
        folder_path = ''
        filename = key

    # Skip if already in Exception_docs
    if '/Exception_docs/' in key:
        return False

    exception_key = f"{folder_path}/Exception_docs/{filename}"

    try:
        # Copy file to Exception_docs
        s3_client.copy_object(
            Bucket=bucket,
            Key=exception_key,
            CopySource={'Bucket': bucket, 'Key': key},
        )
        # Delete original
        s3_client.delete_object(Bucket=bucket, Key=key)

        # Also move companion .metadata.json if it exists
        metadata_key = f"{key}.metadata.json"
        metadata_exception_key = f"{folder_path}/Exception_docs/{filename}.metadata.json"
        try:
            s3_client.head_object(Bucket=bucket, Key=metadata_key)
            s3_client.copy_object(
                Bucket=bucket,
                Key=metadata_exception_key,
                CopySource={'Bucket': bucket, 'Key': metadata_key},
            )
            s3_client.delete_object(Bucket=bucket, Key=metadata_key)
        except s3_client.exceptions.ClientError:
            pass  # No metadata file — fine

        logger.info(f"MOVED | '{filename}' → Exception_docs/ | reason: {reason}")
        return True
    except Exception as e:
        logger.error(f"MOVE_FAILED | '{filename}': {e}")
        return False


def lambda_handler(event: Dict[str, Any], context: Any) -> dict:
    """
    Triggered by EventBridge when Bedrock KB ingestion job completes.

    Event detail contains:
      - knowledgeBaseId
      - dataSourceId
      - ingestionJobId
      - status (COMPLETE / FAILED)
    """
    logger.info(f"Sync failure handler triggered: {json.dumps(event, default=str)[:500]}")

    detail = event.get('detail', {})
    kb_id = detail.get('knowledgeBaseId', KNOWLEDGE_BASE_ID)
    ds_id = detail.get('dataSourceId', DATA_SOURCE_ID)
    job_id = detail.get('ingestionJobId', '')
    status = detail.get('status', '')

    # Only process completed jobs (failed jobs have no per-file breakdown)
    if status not in ('COMPLETE', 'COMPLETE_WITH_FAILURES'):
        # Also handle the case where event comes without status (manual invoke)
        if not job_id:
            # Manual invocation — get the latest completed job
            try:
                response = bedrock_agent_client.list_ingestion_jobs(
                    knowledgeBaseId=kb_id,
                    dataSourceId=ds_id,
                    maxResults=1,
                )
                jobs = response.get('ingestionJobSummaries', [])
                if jobs and jobs[0].get('status') == 'COMPLETE':
                    job_id = jobs[0]['ingestionJobId']
                else:
                    return {"status": "skipped", "message": "No completed job found"}
            except Exception as e:
                logger.error(f"Failed to list ingestion jobs: {e}")
                return {"status": "error", "message": str(e)}
        elif status == 'FAILED':
            logger.info(f"Job {job_id} FAILED entirely — no per-file details available")
            return {"status": "skipped", "message": "Job failed entirely"}

    if not job_id:
        return {"status": "skipped", "message": "No ingestion job ID in event"}

    # Get job details to find failure reasons
    try:
        job_detail = bedrock_agent_client.get_ingestion_job(
            knowledgeBaseId=kb_id,
            dataSourceId=ds_id,
            ingestionJobId=job_id,
        )
    except Exception as e:
        logger.error(f"Failed to get ingestion job {job_id}: {e}")
        return {"status": "error", "message": str(e)}

    ingestion_job = job_detail.get('ingestionJob', {})
    stats = ingestion_job.get('statistics', {})
    failed_count = stats.get('numberOfDocumentsFailed', 0)

    if failed_count == 0:
        logger.info(f"Job {job_id} completed with 0 failures — nothing to move")
        return {"status": "success", "moved": 0}

    failure_reasons = ingestion_job.get('failureReasons', [])
    logger.info(f"Job {job_id} | failed_docs={failed_count} | reasons={len(failure_reasons)}")

    # Parse S3 URIs from failure messages
    moved = 0
    for reason in failure_reasons:
        # S3 URIs in failure messages are comma-separated within brackets:
        # [Files: s3://bucket/key with spaces.msg, s3://bucket/another key.docx, ...]
        # Split by ", s3://" to handle spaces in filenames
        if 's3://' not in reason:
            continue
        
        # Extract the portion between [Files: ... ]
        files_match = re.search(r'\[Files?:\s*(.*?)\]', reason, re.DOTALL)
        if files_match:
            files_str = files_match.group(1)
        else:
            # Fallback: everything after first s3://
            files_str = reason[reason.index('s3://'):]
        
        # Split by ", s3://" — each segment is a full S3 URI
        parts = re.split(r',\s*s3://', files_str)
        for i, part in enumerate(parts):
            uri = part.strip().rstrip(',').rstrip(']')
            if i == 0:
                # First part includes "s3://"
                uri = uri.replace('s3://', '', 1)
            
            # Now uri = "bucket/path/to/file.ext"
            slash_idx = uri.find('/')
            if slash_idx > 0:
                bucket = uri[:slash_idx]
                key = uri[slash_idx + 1:]
                # Skip .metadata.json files
                if key.endswith('.metadata.json'):
                    continue
                if _move_to_exception_docs(bucket, key, 'Unsupported file format for KB ingestion'):
                    moved += 1

    logger.info(f"SUMMARY | job={job_id} | failed={failed_count} | moved={moved}")

    return {
        "status": "success",
        "job_id": job_id,
        "failed_count": failed_count,
        "moved": moved,
    }
