"""
Document Classifier Lambda — LLM-based document tagging + KB sync
==================================================================
Triggered by: S3 ObjectCreated event (prefix: sharepoint/)

Pipeline:
  S3 file uploaded → this Lambda triggered → extract text preview →
  classify via LiteLLM (Haiku) → write .metadata.json companion file →
  trigger Bedrock KB sync → move failed files to Exception_docs/

Metadata written:
  - theme-level-1, theme-level-2 (LLM classification)
  - jurisdiction (LLM-identified from content)
  - language (LLM-identified from content)
  - file-extension (extracted from filename)
  - source-filename (original filename)
  - Plus all existing S3 object metadata carried over

This Lambda runs IN VPC to access the private LiteLLM gateway.

After classification and metadata tagging, triggers a Bedrock KB sync
so the new .metadata.json files are picked up by OpenSearch Serverless.
"""

import io
import json
import logging
import os
import ssl
import urllib.parse
import urllib.request
import zipfile
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
bedrock_agent_client = boto3.client('bedrock-agent', region_name=os.environ.get('AWS_REGION', 'eu-west-1'))

# LLM configuration
LITELLM_KEY = os.environ.get('AWS_BEARER_TOKEN_BEDROCK', '')
LITELLM_URL = os.environ.get('AWS_LITELLM_ENDPOINT', 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions')
CLASSIFIER_MODEL = os.environ.get('CLASSIFIER_MODEL', 'bedrock/us.anthropic.claude-sonnet-4-6')

# KB configuration
KNOWLEDGE_BASE_ID = os.environ.get('BEDROCK_KB_ID', 'OSJDPJLTNC')
DATA_SOURCE_ID = os.environ.get('KB_DATA_SOURCE_ID', 'D4X2WEWFFU')

# Supported file types for text extraction
SUPPORTED_EXTENSIONS = {'.docx', '.pdf', '.pptx', '.ppt', '.txt', '.xlsx', '.msg', '.eml', '.doc'}

# Classification taxonomy
_CLASSIFICATION_TAXONOMY = """
LEVEL 1 — PRODUCT/BUSINESS AREA (What product category is this document about?):

1. "Smoke-free products (SFP)/ heated tobacco products (HTP)"
   Covers all content related to PMI's reduced-risk and smoke-free portfolio (e.g., IQOS, HTP, e-vapor).
   Includes: product science, benefits vs cigarettes, regulatory positioning, commercial narratives.

2. "Combustible cigarettes"
   Includes all materials related to traditional cigarette products, their market, regulation, taxation,
   pricing, and public positioning. Also covers harm discussions, transition narratives, and related business context.

3. "Corporate Equity"
   Content shaping PMI's corporate reputation, purpose, transformation story, and stakeholder perception.
   Includes: leadership messaging, ESG positioning, and overall company narrative beyond product categories.

4. "Others"
   Use for content that does not clearly fall into product-specific or corporate reputation categories.
   Includes: cross-cutting topics or emerging areas not yet formally categorized.

LEVEL 2 — TOPIC/THEME (What subject does this document address?):

1. "Regulatory"
   Covers laws, policies, compliance requirements, and government interactions impacting tobacco and
   smoke-free products. Includes: PMI and third-party submissions, policy advocacy, regulatory frameworks.

2. "Fiscal and Taxes"
   Includes taxation, pricing regulations, excise duties, and economic arguments linked to tobacco and
   smoke-free categories. Covers: impact on affordability, switching incentives, and illicit trade economics.

3. "Illicit Trade"
   Content related to illegal tobacco markets, counterfeit products, smuggling, and enforcement measures.
   Includes: economic, regulatory, and societal impact narratives.

4. "Scientific"
   Covers research, clinical evidence, and scientific validation of products, especially reduced-risk claims.
   Includes: studies, health impact comparisons, and toxicological assessments.

5. "Youth Access Prevention"
   Includes policies, programs, and messaging focused on preventing underage access and usage.
   Covers: compliance measures, enforcement, and responsible marketing.

6. "Sustainability"
   Covers environmental, social, and governance (ESG) initiatives, including supply chain, climate impact,
   and social responsibility. Includes: reporting and stakeholder commitments.

7. "Others"
   Use for niche or uncategorized content that doesn't fit any other header.
   Examples: partnerships, internal processes, or cross-functional initiatives.

CRITICAL RULES:
- Level 1 and Level 2 are INDEPENDENT dimensions. They must NOT have the same values.
- Level 1 answers: "What product/business area?"
- Level 2 answers: "What topic/theme?"
- Example: A regulatory submission about IQOS → Level 1: "Smoke-free products (SFP)/ heated tobacco products (HTP)", Level 2: "Regulatory"
- Example: A corporate ESG report → Level 1: "Corporate Equity", Level 2: "Sustainability"
- Example: A tax policy document about cigarettes → Level 1: "Combustible cigarettes", Level 2: "Fiscal and Taxes"
"""

# Known jurisdictions for validation
_KNOWN_JURISDICTIONS = [
    'India', 'Bangladesh', 'Thailand', 'Vietnam', 'Indonesia', 'Philippines',
    'Malaysia', 'Pakistan', 'Sri Lanka', 'Nepal', 'Myanmar', 'Cambodia',
    'Japan', 'South Korea', 'Australia', 'New Zealand', 'United Kingdom',
    'European Union', 'United States', 'Canada', 'Brazil', 'Mexico',
    'Egypt', 'Saudi Arabia', 'UAE', 'Turkey', 'South Africa', 'Nigeria',
    'Kenya', 'Global',
]


# ── Text extraction (lightweight — first 5000 chars for classification) ───────

def _extract_text_preview(file_bytes: bytes, file_ext: str) -> str:
    """Extract first ~10000 chars of text from a file for classification."""
    ext = file_ext.lower()
    try:
        if ext == '.docx':
            W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
            with zipfile.ZipFile(io.BytesIO(file_bytes)) as z:
                with z.open("word/document.xml") as f:
                    root = ET.parse(f).getroot()
            paragraphs = []
            for para in root.iter(f"{{{W}}}p"):
                text = "".join(t.text or "" for t in para.iter(f"{{{W}}}t")).strip()
                if text:
                    paragraphs.append(text)
            return "\n".join(paragraphs)[:10000]

        elif ext == '.pdf':
            import PyPDF2
            reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
            text = ""
            for page in reader.pages[:10]:
                text += (page.extract_text() or "") + "\n"
                if len(text) >= 10000:
                    break
            return text[:10000]

        elif ext == '.txt':
            return file_bytes.decode('utf-8', errors='ignore')[:10000]

        elif ext in ('.pptx', '.ppt'):
            A = "http://schemas.openxmlformats.org/drawingml/2006/main"
            with zipfile.ZipFile(io.BytesIO(file_bytes)) as z:
                slides = sorted(n for n in z.namelist() if n.startswith("ppt/slides/slide") and n.endswith(".xml"))
                texts = []
                for sf in slides[:5]:
                    with z.open(sf) as f:
                        root = ET.parse(f).getroot()
                    for t in root.iter(f"{{{A}}}t"):
                        if t.text and t.text.strip():
                            texts.append(t.text.strip())
            return " ".join(texts)[:10000]

        elif ext == '.xlsx':
            S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
            texts = []
            with zipfile.ZipFile(io.BytesIO(file_bytes)) as z:
                if "xl/sharedStrings.xml" in z.namelist():
                    with z.open("xl/sharedStrings.xml") as f:
                        root = ET.parse(f).getroot()
                    for t in root.iter(f"{{{S}}}t"):
                        if t.text and t.text.strip():
                            texts.append(t.text.strip())
            return " ".join(texts)[:10000]

        elif ext == '.msg':
            import extract_msg
            msg = extract_msg.Message(io.BytesIO(file_bytes))
            parts = []
            if msg.subject: parts.append(f"Subject: {msg.subject}")
            if msg.sender: parts.append(f"From: {msg.sender}")
            if msg.body: parts.append(msg.body)
            return "\n".join(parts)[:10000]

        elif ext == '.eml':
            import email
            from email.policy import default
            msg = email.message_from_bytes(file_bytes, policy=default)
            parts = []
            if msg['Subject']: parts.append(f"Subject: {msg['Subject']}")
            if msg['From']: parts.append(f"From: {msg['From']}")
            for part in msg.walk():
                if part.get_content_type() == "text/plain" and not part.is_multipart():
                    try:
                        text = part.get_content()
                        if text and text.strip():
                            parts.append(text.strip())
                    except Exception:
                        pass
            return "\n".join(parts)[:10000]

        else:
            return file_bytes.decode('utf-8', errors='ignore')[:10000]

    except Exception as e:
        logger.warning(f"Text preview extraction failed for {file_ext}: {e}")
        return ""


# ── LLM Classification (enhanced with jurisdiction, language, file_type) ──────

def _classify_document(text_preview: str, filename: str) -> Dict[str, Any]:
    """Classify a document using Sonnet via private LiteLLM gateway.

    Returns:
        {
            "level_1": [...],
            "level_2": [...],
            "jurisdiction": "India" | "Global" | ...,
            "language": ["English"] | ["English", "Thai"] | ...,
        }
    """
    if not LITELLM_KEY or not text_preview.strip():
        return {
            "level_1": ["Others"],
            "level_2": ["Others"],
            "jurisdiction": "Global",
            "language": ["English"],
        }

    jurisdictions_str = ", ".join(_KNOWN_JURISDICTIONS)

    prompt = (
        "You are a document classifier for Philip Morris International's knowledge base.\n\n"
        "Classify the following document into the taxonomy below AND identify its jurisdiction and language.\n\n"
        f"{_CLASSIFICATION_TAXONOMY}\n"
        f"DOCUMENT FILENAME: {filename}\n"
        f"DOCUMENT CONTENT (first 10000 chars):\n{text_preview[:10000]}\n\n"
        "RULES:\n"
        "- Select 1-3 values for Level 1 (usually 1, max 3)\n"
        "- Select 1-3 values for Level 2 (usually 1-2, max 3)\n"
        "- Use EXACT category names from the options above\n"
        "- If unsure about theme, include \"Others\" as one of the values\n"
        "- For JURISDICTION: identify which country/region this document is ABOUT based SOLELY on its CONTENT. "
        "Look for these signals IN THE TEXT:\n"
        "  * Country names explicitly mentioned (Thailand, India, Vietnam, Bangladesh, Nepal, Bhutan, etc.)\n"
        "  * Currency references: THB/Baht = Thailand, INR/Rupees/Crore/Lakh = India, VND/Dong = Vietnam, "
        "BDT/Taka = Bangladesh, NPR = Nepal\n"
        "  * Government bodies: Thai FDA/Excise Department/MOPH = Thailand, CBIC/MoHFW/COTPA = India, "
        "VINACOSH/MoH Vietnam = Vietnam, NBR Bangladesh = Bangladesh\n"
        "  * Legislation: Tobacco Products Control Act B.E. 2560 = Thailand, COTPA 2003 = India, "
        "Law 09/2012/QH13 = Vietnam, TPCRA 2011 = Nepal\n"
        "  * Addressees: 'Prime Minister of Thailand', 'Thai Excise Department', 'Ministry of Finance India'\n"
        "  * The filename may contain hints (e.g. 'PMTT' = PMI Thailand, 'DIA' = could be India) but "
        "ALWAYS verify against the document content — do not rely on filename alone.\n"
        f"Choose from: {jurisdictions_str}. "
        "If the document is not specific to any country or covers multiple regions broadly, use \"Global\".\n"
        "- For LANGUAGE: identify ALL languages present in the document content. "
        "Common values: English, Thai, Vietnamese, Bahasa Indonesia, Hindi, Bengali, Japanese, Korean, French, Spanish, Arabic. "
        "Return as a list (most documents will be single-language).\n"
        "- For LEVEL 2: if the document discusses taxation, excise, GST, fiscal policy, or revenue, "
        "ALWAYS include \"Fiscal and Taxes\". If it discusses illicit trade, smuggling, or enforcement, "
        "ALWAYS include \"Illicit Trade\".\n"
        "- Return ONLY a JSON object, no explanation\n\n"
        'OUTPUT FORMAT (example):\n'
        '{"level_1": ["Combustible cigarettes"], '
        '"level_2": ["Fiscal and Taxes"], '
        '"jurisdiction": "Thailand", "language": ["English"]}'
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = json.dumps({
            "model": CLASSIFIER_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300,
        }).encode('utf-8')

        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(LITELLM_URL, data=data, headers=headers, method='POST')

        with urllib.request.urlopen(req, context=ctx, timeout=25) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            result = json.loads(raw)

            level_1 = result.get('level_1', ['Others'])
            level_2 = result.get('level_2', ['Others'])
            jurisdiction = result.get('jurisdiction', 'Global')
            language = result.get('language', ['English'])

            if not isinstance(level_1, list): level_1 = [str(level_1)]
            if not isinstance(level_2, list): level_2 = [str(level_2)]
            if not isinstance(language, list): language = [str(language)]
            if not isinstance(jurisdiction, str): jurisdiction = str(jurisdiction)

            # Validate jurisdiction
            if jurisdiction not in _KNOWN_JURISDICTIONS:
                jurisdiction = 'Global'

            return {
                "level_1": level_1,
                "level_2": level_2,
                "jurisdiction": jurisdiction,
                "language": language,
            }

    except Exception as e:
        logger.warning(f"LLM classification failed for '{filename}': {e}")
        return {
            "level_1": ["Others"],
            "level_2": ["Others"],
            "jurisdiction": "Global",
            "language": ["English"],
        }


# ── Metadata JSON builder ─────────────────────────────────────────────────────

def _build_metadata_json(
    classification: Dict[str, Any],
    filename: str,
    file_ext: str,
    existing_s3_metadata: Dict[str, str],
) -> Dict[str, Any]:
    """Build the .metadata.json content compatible with Bedrock KB metadata ingestion.

    Carries over all existing S3 object metadata and adds classification fields.
    """
    metadata_attributes = {}

    # Carry over existing S3 metadata (from SharePoint sync or other sources)
    # Map common S3 user-metadata keys to the metadata.json format
    _KEY_MAP = {
        'sharepoint-owner': 'owner',
        'sharepoint-item-id': 'item-id',
        'sharepoint-language': 'language',
        'sharepoint-valid-till': 'valid-till',
        'sharepoint-source-filename': 'source-filename',
        'sharepoint-department': 'department',
        'sharepoint-last-modified': 'last-modified',
        'sharepoint-url': 'url',
        'sharepoint-jurisdiction': 'jurisdiction',
        'sharepoint-theme-level-1': 'theme-level-1',
        'sharepoint-theme-level-2': 'theme-level-2',
    }

    for s3_key, json_key in _KEY_MAP.items():
        value = existing_s3_metadata.get(s3_key, '').strip()
        if value:
            metadata_attributes[json_key] = value

    # Also carry over any metadata keys that are already in the target format
    for key, value in existing_s3_metadata.items():
        if key in ('owner', 'item-id', 'language', 'valid-till', 'source-filename',
                   'department', 'last-modified', 'url', 'jurisdiction',
                   'theme-level-1', 'theme-level-2'):
            if value and value.strip() and key not in metadata_attributes:
                metadata_attributes[key] = value.strip()

    # Override/add classification results (these take precedence over existing)
    metadata_attributes['source-filename'] = filename
    metadata_attributes['jurisdiction'] = classification['jurisdiction']
    metadata_attributes['language'] = ', '.join(classification['language'])
    metadata_attributes['file-extension'] = file_ext.lstrip('.').lower()
    metadata_attributes['theme-level-1'] = ', '.join(classification['level_1'])
    metadata_attributes['theme-level-2'] = ', '.join(classification['level_2'])

    return {"metadataAttributes": metadata_attributes}


# ── KB Sync trigger ───────────────────────────────────────────────────────────

def _trigger_kb_sync() -> Optional[str]:
    """Trigger a Bedrock KB ingestion job (sync) and return the ingestion job ID.
    
    Returns the job ID if a new job was started, or 'already_running' if a sync
    is already in progress (ConflictException — this is fine, means sync is happening).
    """
    try:
        response = bedrock_agent_client.start_ingestion_job(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            dataSourceId=DATA_SOURCE_ID,
        )
        job_id = response.get('ingestionJob', {}).get('ingestionJobId', '')
        logger.info(f"KB_SYNC | triggered ingestion job: {job_id}")
        return job_id
    except Exception as e:
        if 'ConflictException' in str(e) or 'already in use' in str(e):
            logger.info("KB_SYNC | sync already in progress — no action needed")
            return 'already_running'
        logger.error(f"KB_SYNC | failed to trigger sync: {e}")
        return None


# ── Move failed files to Exception_docs ───────────────────────────────────────

def _move_to_exception_docs(bucket: str, key: str, error_reason: str) -> None:
    """Move a failed file to Exception_docs/ within the same team folder path."""
    # Extract the team folder path: everything up to the filename
    parts = key.rsplit('/', 1)
    if len(parts) == 2:
        folder_path = parts[0]
        filename = parts[1]
    else:
        folder_path = ''
        filename = key

    exception_key = f"{folder_path}/Exception_docs/{filename}"

    try:
        # Copy to Exception_docs
        s3_client.copy_object(
            Bucket=bucket,
            Key=exception_key,
            CopySource={'Bucket': bucket, 'Key': key},
        )
        # Delete original
        s3_client.delete_object(Bucket=bucket, Key=key)
        logger.info(f"EXCEPTION | moved '{filename}' to '{exception_key}' | reason: {error_reason}")
    except Exception as e:
        logger.error(f"EXCEPTION | failed to move '{filename}': {e}")


# ── Lambda entry point ────────────────────────────────────────────────────────

def lambda_handler(event: Dict[str, Any], context: Any) -> dict:
    """
    Triggered by S3 ObjectCreated event on sharepoint/ prefix.

    For each new file:
      1. Extract text preview
      2. Classify via LLM (level_1, level_2, jurisdiction, language)
      3. Write .metadata.json companion file in same folder
      4. After all files processed, trigger KB sync
      5. Failed files are moved to Exception_docs/
    """
    logger.info("Document Classifier triggered")

    records = event.get("Records", [])
    if not records:
        return {"status": "skipped", "message": "No S3 records"}

    classified = 0
    skipped = 0
    failed = 0
    failed_files: List[Dict[str, str]] = []

    for record in records:
        bucket = record["s3"]["bucket"]["name"]
        raw_key = record["s3"]["object"]["key"]
        key = urllib.parse.unquote_plus(raw_key)
        filename = key.split("/")[-1]
        file_ext = os.path.splitext(filename)[1].lower()

        # Skip .metadata.json files (avoid recursive processing)
        if filename.endswith('.metadata.json'):
            logger.info(f"Skipping metadata file: {filename}")
            skipped += 1
            continue

        # Skip files in Exception_docs/ folder
        if '/Exception_docs/' in key:
            logger.info(f"Skipping file in Exception_docs: {filename}")
            skipped += 1
            continue

        # Skip unsupported file types
        if file_ext not in SUPPORTED_EXTENSIONS:
            logger.info(f"Skipping unsupported file type: {filename} ({file_ext})")
            skipped += 1
            continue

        try:
            # 1. Always classify and overwrite .metadata.json (ensures new fields are added)
            metadata_key = f"{key}.metadata.json"

            # 2. Get existing S3 metadata
            head = s3_client.head_object(Bucket=bucket, Key=key)
            existing_meta = head.get('Metadata', {})

            # 3. Download file
            response = s3_client.get_object(Bucket=bucket, Key=key)
            file_bytes = response['Body'].read()
            logger.info(f"Downloaded {len(file_bytes):,} bytes — {filename}")

            # 4. Extract text preview
            text_preview = _extract_text_preview(file_bytes, file_ext)
            if not text_preview.strip():
                logger.warning(f"No text extracted from {filename} — tagging as Others/Global")
                classification = {
                    "level_1": ["Others"],
                    "level_2": ["Others"],
                    "jurisdiction": "Global",
                    "language": ["English"],
                }
            else:
                # 5. Classify with LLM
                classification = _classify_document(text_preview, filename)

            # 6. Build and write .metadata.json companion file
            metadata_content = _build_metadata_json(
                classification=classification,
                filename=filename,
                file_ext=file_ext,
                existing_s3_metadata=existing_meta,
            )

            s3_client.put_object(
                Bucket=bucket,
                Key=metadata_key,
                Body=json.dumps(metadata_content, indent=2),
                ContentType='application/json',
            )

            classified += 1
            logger.info(
                f"CLASSIFIED | file={filename} "
                f"| L1={classification['level_1']} "
                f"| L2={classification['level_2']} "
                f"| jurisdiction={classification['jurisdiction']} "
                f"| language={classification['language']} "
                f"| ext={file_ext.lstrip('.')}"
            )

        except Exception as e:
            logger.error(f"Failed to classify {filename}: {e}")
            failed += 1
            failed_files.append({'bucket': bucket, 'key': key, 'error': str(e)})

    # 7. Move failed files to Exception_docs/
    for fail in failed_files:
        _move_to_exception_docs(fail['bucket'], fail['key'], fail['error'])

    # 8. Trigger KB sync if any files were classified
    # ConflictException is handled gracefully — means sync is already running (fine)
    ingestion_job_id = None
    if classified > 0:
        ingestion_job_id = _trigger_kb_sync()

    logger.info(
        f"SUMMARY | classified={classified} | skipped={skipped} | failed={failed} "
        f"| ingestion_job_id={ingestion_job_id or 'none'}"
    )

    return {
        "statusCode": 200,
        "body": json.dumps({
            "classified": classified,
            "skipped": skipped,
            "failed": failed,
            "failed_files": [f['key'] for f in failed_files],
            "ingestion_job_id": ingestion_job_id,
        }),
    }
