import json
d = json.load(open('infrastructure/step_functions_definition_client_demo2.json'))
states = list(d['States'].keys())
print(f"{len(states)} states:")
for s in states:
    print(f"  {s}")
