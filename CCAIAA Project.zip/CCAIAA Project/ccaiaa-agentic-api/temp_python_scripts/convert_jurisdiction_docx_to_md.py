"""
Convert jurisdiction .docx ground-truth files to .md.

Walks templates/jurisdiction/*.docx (in document order, including tables),
renders headings, bullet/numbered lists, and tables as Markdown, and writes a
lowercase <country>.md file next to the source (the loader looks up
'<jurisdiction>.lower().md').

Idempotent: rewrites the .md each run. Prints a UTF-8 report.
"""
import os
import sys

from docx import Document
from docx.document import Document as _Doc
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.oxml.ns import qn

JDIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "templates", "jurisdiction")


def iter_block_items(parent):
    """Yield Paragraph and Table objects in document order."""
    if isinstance(parent, _Doc):
        body = parent.element.body
    else:
        body = parent._element
    for child in body.iterchildren():
        if child.tag == qn('w:p'):
            yield Paragraph(child, parent)
        elif child.tag == qn('w:tbl'):
            yield Table(child, parent)


_SEP_CHARS = set("─—–-_=•·. \t")


def _strip_separators(text: str) -> str:
    """Remove Word box-drawing/divider runs (e.g. '────────') that are pure
    visual separators, including when glued to the end of a sentence."""
    # Drop trailing runs of 3+ box-drawing/dash chars
    import re
    text = re.sub(r"[─—–_=]{3,}\s*$", "", text).rstrip()
    return text


def para_to_md(p: Paragraph) -> str:
    text = p.text.strip()
    if not text:
        return ""
    # A line that is ONLY separator characters carries no content
    if text and all(ch in _SEP_CHARS for ch in text) and any(ch in "─—–=_" for ch in text):
        return ""
    text = _strip_separators(text)
    if not text:
        return ""
    style = (p.style.name or "").lower() if p.style else ""

    # Headings — but a long sentence styled as a heading is really body text
    if style.startswith("heading") or style == "title":
        words = text.split()
        looks_like_body = (len(words) > 12) or (text.endswith(('.', ':')) and len(words) > 8)
        if not looks_like_body:
            if style == "title":
                return f"# {text}"
            try:
                level = int(style.replace("heading", "").strip() or "1")
            except ValueError:
                level = 2
            level = max(1, min(level, 6))
            return f"{'#' * level} {text}"
        # fall through: render as normal paragraph

    # Lists
    numpr = p._p.find(qn('w:pPr'))
    is_list = "list" in style or "bullet" in style
    if is_list or (numpr is not None and numpr.find(qn('w:numPr')) is not None):
        if "number" in style:
            return f"1. {text}"
        return f"- {text}"

    return text


def table_to_md(tbl: Table) -> str:
    rows = []
    for row in tbl.rows:
        cells = [c.text.strip().replace("\n", " ").replace("|", "\\|") for c in row.cells]
        rows.append(cells)
    if not rows:
        return ""
    # Deduplicate horizontally-merged cells that repeat the same text
    ncols = max(len(r) for r in rows)
    rows = [r + [""] * (ncols - len(r)) for r in rows]
    header = rows[0]
    md = ["| " + " | ".join(header) + " |",
          "| " + " | ".join(["---"] * ncols) + " |"]
    for r in rows[1:]:
        md.append("| " + " | ".join(r) + " |")
    return "\n".join(md)


def convert(docx_path: str) -> str:
    doc = Document(docx_path)
    out_lines = []
    prev_blank = True
    for block in iter_block_items(doc):
        if isinstance(block, Paragraph):
            line = para_to_md(block)
            if line == "":
                if not prev_blank:
                    out_lines.append("")
                    prev_blank = True
                continue
            # blank line before headings for readability
            if line.startswith("#") and out_lines and not prev_blank:
                out_lines.append("")
            out_lines.append(line)
            prev_blank = False
        elif isinstance(block, Table):
            if not prev_blank:
                out_lines.append("")
            out_lines.append(table_to_md(block))
            out_lines.append("")
            prev_blank = True
    md = "\n".join(out_lines).strip() + "\n"
    return md


def main():
    report = []
    for fn in sorted(os.listdir(JDIR)):
        if not fn.lower().endswith(".docx"):
            continue
        src = os.path.join(JDIR, fn)
        stem = os.path.splitext(fn)[0].strip().lower()
        dst = os.path.join(JDIR, f"{stem}.md")
        try:
            md = convert(src)
            with open(dst, "w", encoding="utf-8") as f:
                f.write(md)
            report.append(f"OK   {fn} -> {stem}.md ({len(md)} chars)")
        except Exception as e:
            report.append(f"FAIL {fn}: {e}")

    out = "\n".join(report)
    print(out)
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "convert_jurisdiction_report.txt"), "w", encoding="utf-8") as f:
        f.write(out + "\n")


if __name__ == "__main__":
    main()
