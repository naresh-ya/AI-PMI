"""Generate LinkedIn article Word document on silent errors in serverless architectures."""
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
os.makedirs(OUT_DIR, exist_ok=True)

doc = Document()
style = doc.styles['Normal']
style.font.name = 'Calibri'
style.font.size = Pt(11)

# Title
title = doc.add_heading("Silent Errors in Serverless: The Failures Nobody Sees", level=0)
for run in title.runs:
    run.font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)

# Subtitle
p = doc.add_paragraph("How invisible failures in cloud-native architectures silently corrupt your data — and 5 practices to make them loud.")
p.runs[0].font.size = Pt(12)
p.runs[0].font.italic = True
p.runs[0].font.color.rgb = RGBColor(0x55, 0x55, 0x55)
doc.add_paragraph()

# Intro
doc.add_paragraph(
    "In serverless architectures — Lambda functions, DynamoDB, Step Functions, managed APIs — "
    "a dangerous class of bugs exists that doesn't crash your system, doesn't trigger alarms, "
    "and doesn't show up in dashboards. The system appears healthy. Requests succeed. Status "
    "codes return 200. But underneath, data isn't being written, updates aren't persisting, "
    "and critical state transitions silently fail."
)
doc.add_paragraph(
    "These are silent errors — and they're the hardest bugs to find because everything looks "
    "fine until a user reports that their data is wrong, days or weeks later."
)
doc.add_paragraph(
    "After debugging multiple production incidents involving silent failures in a serverless "
    "pipeline (Lambda + DynamoDB + Step Functions + API Gateway), I've identified the common "
    "patterns and the practices that prevent them."
)

# Section 1
doc.add_heading("What Makes an Error 'Silent'?", level=1)
doc.add_paragraph(
    "A silent error has three characteristics:"
)
doc.add_paragraph("1. The operation fails, but execution continues without interruption.", style='List Number')
doc.add_paragraph("2. No alarm, metric, or visible indicator surfaces the failure.", style='List Number')
doc.add_paragraph("3. The downstream consumer (UI, API, another service) receives stale or incorrect data.", style='List Number')
doc.add_paragraph()
doc.add_paragraph(
    "The root cause is almost always the same pattern: a broad exception handler catches an "
    "unexpected error, logs it at a low severity level (or not at all), and allows execution "
    "to continue as if nothing happened."
)

# Section 2
doc.add_heading("3 Real-World Silent Failures", level=1)

doc.add_heading("1. Reserved Words in Database Expressions", level=2)
doc.add_paragraph(
    "Many managed databases (DynamoDB, CosmosDB, etc.) have hundreds of reserved keywords. "
    "When you use a reserved word as a field name in an update expression without escaping it, "
    "the operation may fail — but if wrapped in a generic try/except, the failure is swallowed."
)
doc.add_paragraph(
    "Example: field names like 'status', 'sources', 'name', 'count', 'size' are all reserved "
    "in DynamoDB. Using them directly in an UpdateExpression silently fails unless escaped with "
    "ExpressionAttributeNames."
)
p = doc.add_paragraph()
p.add_run("Impact: ").bold = True
p.add_run("Data appears to update (no error returned to caller) but the database record is unchanged. "
          "Downstream services read stale values indefinitely.")

doc.add_heading("2. Type Mismatches in Serialization", level=2)
doc.add_paragraph(
    "Many database SDKs enforce strict type requirements that differ from your programming "
    "language's defaults. For example, DynamoDB's boto3 resource layer rejects Python float "
    "values — it requires Decimal objects. If your data passes through JSON parsing (which "
    "produces floats), the write silently fails when caught by a generic exception handler."
)
doc.add_paragraph(
    "Similarly, JSON serialization of database-native types (Decimal, DateTime, ObjectId) "
    "throws TypeError — but only at runtime, only with specific data patterns, and often "
    "only in production where real data has decimal values that test data didn't."
)
p = doc.add_paragraph()
p.add_run("Impact: ").bold = True
p.add_run("The write operation throws a type error, the except block catches it, execution "
          "continues, and the database is never updated. The API returns success to the user.")

doc.add_heading("3. Broad Exception Handlers Masking Failures", level=2)
doc.add_paragraph(
    "The most common enabler of all silent errors: the overly broad try/except (or try/catch) "
    "that wraps a critical operation. The developer intends it as a 'fail-safe' — if the write "
    "fails, don't crash the whole request. But in practice, it hides logic errors, type errors, "
    "permission errors, and configuration errors that should surface immediately."
)
code = doc.add_paragraph()
code.add_run("try:\n    db.update(key, data)\nexcept Exception:\n    logger.warning('update failed')  # Nobody sees this").font.name = 'Consolas'
doc.add_paragraph()
p = doc.add_paragraph()
p.add_run("Impact: ").bold = True
p.add_run("The system 'works' for weeks. CloudWatch shows no errors (only warnings). The user sees "
          "incorrect data. The team spends days tracing the data flow before finding the swallowed exception.")

# Section 3
doc.add_heading("5 Practices to Eliminate Silent Failures", level=1)

doc.add_heading("Practice 1: Always Escape Field Names", level=2)
doc.add_paragraph(
    "Never use raw field names in database expressions — even if you believe they aren't "
    "reserved today. Future SDK updates may add new reserved words. Use parameterized field "
    "references (ExpressionAttributeNames in DynamoDB, parameterized queries in SQL, etc.) "
    "as a universal default, not an exception."
)

doc.add_heading("Practice 2: Validate Writes — Read After Write", level=2)
doc.add_paragraph(
    "For critical state transitions (status changes, financial updates, permission grants), "
    "add a read-after-write verification step. If the value you just wrote doesn't match "
    "what you read back, raise an error immediately. This catches silent failures at the "
    "moment they happen, not days later."
)

doc.add_heading("Practice 3: Use Specific Exception Types", level=2)
doc.add_paragraph(
    "Replace every generic 'except Exception' with specific exception types for the operation "
    "you're performing. Catch ClientError, TypeError, ValidationError separately. Let unknown "
    "exceptions propagate and crash loudly. A crash you notice immediately is infinitely "
    "better than a silent corruption you notice next week."
)

doc.add_heading("Practice 4: Log Before AND After — With Counts", level=2)
doc.add_paragraph(
    "Don't log 'update successful' — log the before and after state with measurable values. "
    "If you're updating a list from 14 items to 11, log '14 → 11'. If you later see '14 → 14' "
    "in your logs, you immediately know the write didn't take effect. Observable state "
    "transitions catch silent failures in real-time."
)

doc.add_heading("Practice 5: Test Database Writes Locally Before Deploying", level=2)
doc.add_paragraph(
    "Before deploying any code that writes to a managed database, run the exact write operation "
    "locally against the real table with real data. Not a mock. Not a simulation. The actual "
    "SDK call with actual data shapes. Most silent failures (reserved words, type mismatches, "
    "missing permissions) surface immediately in a 5-second local test but hide for weeks in "
    "production behind generic error handlers."
)

# Section 4
doc.add_heading("The Pattern Behind All Silent Errors", level=1)
doc.add_paragraph(
    "Every silent error we encountered followed the same lifecycle:"
)
doc.add_paragraph("1. Developer adds a try/except around a database write 'just in case'.", style='List Number')
doc.add_paragraph("2. The write fails for an unexpected reason (reserved word, wrong type, missing field).", style='List Number')
doc.add_paragraph("3. The except block catches it, logs a warning, and continues.", style='List Number')
doc.add_paragraph("4. The function returns success to the caller.", style='List Number')
doc.add_paragraph("5. The user sees stale/incorrect data.", style='List Number')
doc.add_paragraph("6. Days later, someone reports the bug.", style='List Number')
doc.add_paragraph("7. Debugging takes hours because 'everything looks fine' in metrics.", style='List Number')
doc.add_paragraph()
doc.add_paragraph(
    "The fix is always the same: make failures loud, specific, and immediately verifiable. "
    "A system that crashes on bad writes is safer than one that silently continues with "
    "corrupted state."
)

# Closing
doc.add_heading("Key Takeaway", level=1)
doc.add_paragraph(
    "In serverless architectures, the most dangerous bug is not the one that crashes your "
    "system — it's the one that doesn't. Silent errors erode data integrity invisibly. The "
    "cost of a loud failure is a 5-minute fix. The cost of a silent failure is days of "
    "debugging, lost user trust, and data inconsistency that may never be fully recovered."
)
doc.add_paragraph()
p = doc.add_paragraph()
p.add_run("Build systems that fail loudly or succeed verifiably. There is no safe middle ground.").bold = True

# Save
output_path = os.path.join(OUT_DIR, "LinkedIn_Article_Silent_Errors_Serverless.docx")
doc.save(output_path)
print(f"Saved: {output_path}")
