"""
Generate Excel report of all KB metadata tagging for business review.

Scans all .metadata.json files in the KB S3 bucket, extracts classification
fields, and produces an Excel file with columns:
  - S.No
  - Filename
  - File Format (pdf, docx, pptx, xlsx, etc.)
  - Jurisdiction
  - Theme Level 1
  - Theme Level 2
  - Language
  - S3 Path
  - Has Metadata (Yes/No)

Output: metadata_report.xlsx (in repo root)

Usage:
    aws sso login
    python temp_python_scripts\generate_metadata_report.py
"""
import json
import os
import sys
from datetime import datetime

import boto3
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

REGION = os.environ.get("REPORT_REGION", "eu-west-1")
BUCKET = os.environ.get("REPORT_BUCKET", "pmi-agentic-ai-documents-sandbox-603433800649")
KB_PREFIX = os.environ.get("REPORT_PREFIX", "sharepoint/")
SKIP_PATTERNS = ["Exception_docs/", ".DS_Store", "Thumbs.db"]
OUTPUT_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "metadata_report.xlsx")


def list_all_files(s3):
    """List all document files and their metadata.json companions."""
    documents = {}  # key -> {has_metadata, metadata_key}
    metadata_files = {}  # base_key -> metadata content key

    paginator = s3.get_paginator('list_objects_v2')
    for page in paginator.paginate(Bucket=BUCKET, Prefix=KB_PREFIX):
        for obj in page.get('Contents', []):
            key = obj['Key']
            size = obj['Size']

            if any(skip in key for skip in SKIP_PATTERNS):
                continue
            if size < 50:
                continue

            if key.endswith('.metadata.json'):
                # This is a metadata sidecar — map it to its parent document
                base_key = key.replace('.metadata.json', '')
                metadata_files[base_key] = key
            else:
                documents[key] = {'size': size}

    return documents, metadata_files


def read_metadata(s3, metadata_key):
    """Read and parse a .metadata.json file from S3."""
    try:
        resp = s3.get_object(Bucket=BUCKET, Key=metadata_key)
        data = json.loads(resp['Body'].read())
        attrs = data.get('metadataAttributes', {})
        return {
            'jurisdiction': attrs.get('jurisdiction', ''),
            'theme_level_1': attrs.get('theme-level-1', ''),
            'theme_level_2': attrs.get('theme-level-2', ''),
            'language': attrs.get('language', ''),
        }
    except Exception as e:
        return {
            'jurisdiction': f'ERROR: {e}',
            'theme_level_1': '',
            'theme_level_2': '',
            'language': '',
        }


def get_file_format(filename):
    """Extract file extension/format from filename."""
    ext = os.path.splitext(filename)[1].lower()
    return ext.lstrip('.') if ext else 'unknown'


def generate_report():
    s3 = boto3.client('s3', region_name=REGION)

    print(f"Scanning s3://{BUCKET}/{KB_PREFIX} ...")
    documents, metadata_files = list_all_files(s3)
    total = len(documents)
    print(f"Found {total} documents, {len(metadata_files)} metadata files")

    # Build report rows
    rows = []
    for i, (doc_key, doc_info) in enumerate(sorted(documents.items()), 1):
        filename = doc_key.split('/')[-1]
        file_format = get_file_format(filename)
        has_metadata = doc_key in metadata_files

        meta = {'jurisdiction': '', 'theme_level_1': '', 'theme_level_2': '', 'language': ''}
        if has_metadata:
            meta = read_metadata(s3, metadata_files[doc_key])

        rows.append({
            'sno': i,
            'filename': filename,
            'file_format': file_format,
            'jurisdiction': meta['jurisdiction'],
            'theme_level_1': meta['theme_level_1'],
            'theme_level_2': meta['theme_level_2'],
            'language': meta['language'],
            's3_path': doc_key,
            'has_metadata': 'Yes' if has_metadata else 'No',
        })

        if i % 100 == 0:
            print(f"  Processed {i}/{total} ...")

    # Generate Excel
    print(f"\nGenerating Excel report ({len(rows)} rows)...")
    wb = Workbook()
    ws = wb.active
    ws.title = "KB Metadata Report"

    # Headers
    headers = ['S.No', 'Filename', 'File Format', 'Jurisdiction',
               'Theme Level 1', 'Theme Level 2', 'Language', 'S3 Path', 'Has Metadata']
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F3A5F", end_color="1F3A5F", fill_type="solid")
    thin_border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = thin_border

    # Data rows
    for row_idx, row_data in enumerate(rows, 2):
        ws.cell(row=row_idx, column=1, value=row_data['sno'])
        ws.cell(row=row_idx, column=2, value=row_data['filename'])
        ws.cell(row=row_idx, column=3, value=row_data['file_format'])
        ws.cell(row=row_idx, column=4, value=row_data['jurisdiction'])
        ws.cell(row=row_idx, column=5, value=row_data['theme_level_1'])
        ws.cell(row=row_idx, column=6, value=row_data['theme_level_2'])
        ws.cell(row=row_idx, column=7, value=row_data['language'])
        ws.cell(row=row_idx, column=8, value=row_data['s3_path'])
        ws.cell(row=row_idx, column=9, value=row_data['has_metadata'])

        # Highlight rows without metadata in light red
        if row_data['has_metadata'] == 'No':
            red_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
            for col in range(1, 10):
                ws.cell(row=row_idx, column=col).fill = red_fill

    # Auto-width columns
    for col in range(1, 10):
        max_len = max(len(str(ws.cell(row=r, column=col).value or '')) for r in range(1, min(len(rows) + 2, 100)))
        ws.column_dimensions[get_column_letter(col)].width = min(max_len + 3, 50)

    # Freeze header row
    ws.freeze_panes = 'A2'

    # Add summary sheet
    summary = wb.create_sheet("Summary")
    summary.cell(row=1, column=1, value="Metric").font = Font(bold=True)
    summary.cell(row=1, column=2, value="Value").font = Font(bold=True)

    total_docs = len(rows)
    with_meta = sum(1 for r in rows if r['has_metadata'] == 'Yes')
    without_meta = total_docs - with_meta

    summary_data = [
        ("Total Documents", total_docs),
        ("With Metadata", with_meta),
        ("Without Metadata", without_meta),
        ("Coverage %", f"{(with_meta/total_docs*100):.1f}%" if total_docs > 0 else "0%"),
        ("", ""),
        ("By Jurisdiction", ""),
    ]

    # Count by jurisdiction
    jur_counts = {}
    for r in rows:
        j = r['jurisdiction'] or '(empty)'
        jur_counts[j] = jur_counts.get(j, 0) + 1
    for j, count in sorted(jur_counts.items(), key=lambda x: -x[1]):
        summary_data.append((f"  {j}", count))

    summary_data.append(("", ""))
    summary_data.append(("By File Format", ""))
    fmt_counts = {}
    for r in rows:
        f = r['file_format'] or 'unknown'
        fmt_counts[f] = fmt_counts.get(f, 0) + 1
    for f, count in sorted(fmt_counts.items(), key=lambda x: -x[1]):
        summary_data.append((f"  .{f}", count))

    for row_idx, (metric, value) in enumerate(summary_data, 2):
        summary.cell(row=row_idx, column=1, value=metric)
        summary.cell(row=row_idx, column=2, value=value)

    summary.column_dimensions['A'].width = 25
    summary.column_dimensions['B'].width = 15

    # Save
    wb.save(OUTPUT_FILE)
    print(f"\n✅ Report saved: {OUTPUT_FILE}")
    print(f"   Total: {total_docs} | With metadata: {with_meta} | Without: {without_meta}")
    print(f"   Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == "__main__":
    generate_report()
