"""Generate sample test files (1 PDF + 1 DOCX) for file-upload testing."""
import os

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "docs", "test_upload_samples")
os.makedirs(OUT_DIR, exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════════
# 1. DOCX — White Papers / Official Submission style
# ═══════════════════════════════════════════════════════════════════════════════
from docx import Document
from docx.shared import Pt

doc = Document()
style = doc.styles['Normal']
style.font.name = 'Calibri'
style.font.size = Pt(11)

doc.add_heading("Illicit Cigarette Trade in Thailand: Economic Impact Assessment", level=1)
doc.add_paragraph(
    "Executive Summary\n\n"
    "Thailand's illicit cigarette market has grown significantly over the past decade, "
    "driven by high excise taxes, porous borders with neighbouring countries, and "
    "limited enforcement capacity. According to the Tobacco Institute of Southern Africa's "
    "methodology adapted for Southeast Asia, an estimated 8.2 billion illicit cigarettes "
    "entered Thailand in 2024, representing approximately 19.4% of total consumption.\n\n"
    "The fiscal impact is substantial: the Thai Excise Department estimates annual revenue "
    "loss of THB 28.7 billion (USD 820 million) from untaxed cigarettes, equivalent to "
    "0.16% of GDP. This figure has grown 34% since 2020 when excise rates were last increased.\n\n"
    "Key Findings:\n"
    "• Border seizures by Thai Customs increased 42% year-on-year in 2024, with 67% of "
    "intercepted product originating from Cambodia and Laos.\n"
    "• The price differential between legal duty-paid cigarettes (avg THB 120/pack) and "
    "illicit product (avg THB 35-45/pack) creates a strong consumer incentive.\n"
    "• Thailand's Tobacco Products Control Act B.E. 2560 (2017) imposes penalties of up to "
    "5 years imprisonment and THB 500,000 fine for illicit trade, but prosecution rates "
    "remain below 12% of detected cases.\n"
    "• WHO FCTC Protocol to Eliminate Illicit Trade in Tobacco Products (ratified by Thailand "
    "in 2019) requires implementation of a track-and-trace system by 2027.\n\n"
    "Recommendations:\n"
    "1. Implement digital tax stamps with unique serial identifiers aligned to FCTC Protocol standards.\n"
    "2. Increase border enforcement capacity through ASEAN Customs cooperation agreements.\n"
    "3. Establish a dedicated illicit trade intelligence unit within the Excise Department.\n"
    "4. Consider risk-proportionate taxation that reduces the price incentive for smuggling.\n"
    "5. Mandate retailer licensing with penalties for selling unmarked products.\n"
)

doc.add_heading("Section 1: Market Size Estimation", level=2)
doc.add_paragraph(
    "The Empty Pack Survey (EPS) methodology, conducted across 15 provinces in Q4 2024, "
    "collected 47,300 discarded cigarette packs from urban and rural sampling sites. "
    "Results indicate:\n"
    "• 19.4% of all packs lacked valid Thai tax stamps (up from 15.8% in 2022)\n"
    "• In border provinces (Chiang Rai, Sa Kaeo, Ubon Ratchathani), illicit share reaches 31-38%\n"
    "• Bangkok metropolitan area: 14.2% illicit share\n"
    "• Southern provinces bordering Malaysia: 22.7% illicit share\n\n"
    "Volume estimation: Based on total legal sales of 42.3 billion sticks (Excise Dept 2024 data) "
    "and an illicit market share of 19.4%, total illicit volume is estimated at approximately "
    "10.2 billion sticks (510 million packs).\n"
)

doc.add_heading("Section 2: Revenue Impact Analysis", level=2)
doc.add_paragraph(
    "Applying the current specific excise rate of THB 1.20/stick and ad valorem component "
    "at 40% of ex-factory price:\n"
    "• Specific excise loss: 10.2B sticks × THB 1.20 = THB 12.24 billion\n"
    "• Ad valorem loss (estimated): THB 9.8 billion\n"
    "• VAT loss (7%): THB 3.4 billion\n"
    "• Health surcharge loss: THB 3.26 billion\n"
    "• Total annual fiscal loss: THB 28.7 billion\n\n"
    "For context, this revenue loss exceeds Thailand's annual budget allocation for the "
    "National Anti-Drug Operations Center (THB 4.2 billion) by a factor of 6.8x.\n"
)

doc.add_heading("Section 3: Enforcement Data", level=2)
doc.add_paragraph(
    "Thai Customs Department seizure statistics (2024):\n"
    "• Total seizures: 847 cases (up from 596 in 2023, +42%)\n"
    "• Volume seized: 127.4 million sticks (up from 89.2 million, +43%)\n"
    "• Estimated street value of seizures: THB 1.91 billion\n"
    "• Primary origin countries: Cambodia (38%), Laos (29%), Vietnam (18%), Myanmar (11%), Other (4%)\n"
    "• Primary entry points: Aranyaprathet-Poipet (28%), Nong Khai-Vientiane (22%), "
    "Mae Sai-Tachileik (17%), Seaports (15%)\n\n"
    "Prosecution outcomes (2024):\n"
    "• Cases referred to prosecutors: 102 of 847 (12%)\n"
    "• Convictions: 67 (66% conviction rate of prosecuted cases)\n"
    "• Average fine imposed: THB 180,000 (well below the THB 500,000 maximum)\n"
    "• Imprisonment sentences: 12 cases (average 18 months)\n"
)

docx_path = os.path.join(OUT_DIR, "illicit_trade_thailand_assessment.docx")
doc.save(docx_path)
print(f"Created: {docx_path}")

# ═══════════════════════════════════════════════════════════════════════════════
# 2. PDF — Internal Communications / Regulatory briefing style
# ═══════════════════════════════════════════════════════════════════════════════
try:
    from fpdf import FPDF
except ImportError:
    import subprocess
    subprocess.check_call(["pip", "install", "fpdf2", "--quiet"])
    from fpdf import FPDF

pdf = FPDF()
pdf.add_page()
pdf.set_auto_page_break(auto=True, margin=15)

pdf.set_font("Helvetica", "B", 16)
pdf.cell(0, 10, "India GST Council: Proposed Tobacco Tax Restructuring 2026", ln=True)
pdf.ln(5)

pdf.set_font("Helvetica", "", 10)
pdf.cell(0, 6, "INTERNAL BRIEFING - PMI South Asia External Affairs | July 2026", ln=True)
pdf.cell(0, 6, "Classification: Internal Use Only", ln=True)
pdf.ln(8)

pdf.set_font("Helvetica", "B", 12)
pdf.cell(0, 8, "Background", ln=True)
pdf.set_font("Helvetica", "", 10)
pdf.multi_cell(0, 5,
    "The 54th GST Council meeting (scheduled 18 July 2026) will consider a proposal from the "
    "Group of Ministers (GoM) on tobacco taxation to restructure the compensation cess and "
    "introduce a differentiated framework for reduced-risk products.\n\n"
    "Current tax structure (cigarettes):\n"
    "- GST: 28% (highest slab)\n"
    "- Compensation Cess: 290% ad valorem + specific component (INR 4,170 per thousand for >75mm)\n"
    "- Effective tax incidence: 52-58% of retail price\n\n"
    "The GoM proposal includes three key elements:\n"
    "1. Increase compensation cess by 15% across all cigarette length categories\n"
    "2. Introduce a NEW product category: 'Heated Tobacco Products' at 40% cess (vs 290% for cigarettes)\n"
    "3. Create specific HS code classification for nicotine pouches under Chapter 24\n"
)

pdf.set_font("Helvetica", "B", 12)
pdf.cell(0, 8, "Key Data Points", ln=True)
pdf.set_font("Helvetica", "", 10)
pdf.multi_cell(0, 5,
    "- India's tobacco tax revenue (FY2025-26): INR 72,400 crore (USD 8.7 billion)\n"
    "- Cigarettes contribute 85% of tobacco tax revenue despite being only 11% of consumption volume\n"
    "- Illicit cigarette market share: estimated 25-27% (FICCI Cascade Report 2025)\n"
    "- Revenue loss from illicit trade: INR 18,000 crore annually\n"
    "- WHO-recommended tax share (75% of retail): India currently at 52-58%\n"
    "- IQOS is not yet commercially available in India; regulatory pathway under evaluation\n"
    "- 14 states have independently banned e-cigarettes under PECA 2019\n\n"
    "Competitive context:\n"
    "- ITC Ltd (market leader, 77% share) has publicly opposed differentiated taxation\n"
    "- VST Industries and Godfrey Phillips support status quo\n"
    "- No domestic HTP manufacturer currently exists in India\n"
)

pdf.set_font("Helvetica", "B", 12)
pdf.cell(0, 8, "PMI Implications & Recommended Position", ln=True)
pdf.set_font("Helvetica", "", 10)
pdf.multi_cell(0, 5,
    "1. SUPPORT the GoM proposal on differentiated HTP taxation as a positive signal for "
    "risk-proportionate regulation, even though IQOS is not yet commercially available.\n\n"
    "2. FLAG the 15% cess increase risk: further widening the price gap between legal and "
    "illicit cigarettes will likely increase smuggling volumes (cite: every 10% price increase "
    "historically correlates with 3-4% illicit share growth in India, per Euromonitor 2024).\n\n"
    "3. ADVOCATE for simultaneous enforcement enhancement: any tax increase should be paired "
    "with track-and-trace implementation (India ratified FCTC Protocol in 2018 but has not "
    "yet implemented a functioning system).\n\n"
    "4. ENGAGE industry associations (FICCI, CII) to submit joint representation to the "
    "GST Council on the illicit trade risk from excessive taxation.\n\n"
    "5. TIMELINE: PMI must submit written comments to the GoM secretariat by 12 July 2026. "
    "Draft submission attached separately.\n"
)

pdf.set_font("Helvetica", "B", 12)
pdf.cell(0, 8, "Regulatory References", ln=True)
pdf.set_font("Helvetica", "", 10)
pdf.multi_cell(0, 5,
    "- GST Act 2017, Section 8 (Compensation Cess)\n"
    "- Prohibition of Electronic Cigarettes Act (PECA) 2019\n"
    "- COTPA 2003 (Cigarettes and Other Tobacco Products Act)\n"
    "- WHO FCTC Articles 6 (Price and Tax) and 15 (Illicit Trade)\n"
    "- FCTC Protocol to Eliminate Illicit Trade (India ratified 2018)\n"
    "- CBIC Notification No. 1/2017-Compensation Cess (as amended)\n"
    "- GoM Report on Tobacco Taxation Reform (March 2026, unpublished)\n"
)

pdf_path = os.path.join(OUT_DIR, "india_gst_tobacco_briefing_july2026.pdf")
pdf.output(pdf_path)
print(f"Created: {pdf_path}")

print(f"\nBoth files in: {OUT_DIR}")
