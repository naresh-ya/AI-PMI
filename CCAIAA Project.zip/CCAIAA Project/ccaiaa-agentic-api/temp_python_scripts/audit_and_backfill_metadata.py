"""
Audit + backfill `.metadata.json` sidecars for documents in the SharePoint S3 folder.
=====================================================================================

What it does
------------
1. AUDIT: scans the SharePoint prefix and reports, for every supported document, whether
   it has a corresponding `<file>.metadata.json`. Lists what's missing.
2. BACKFILL: for each document missing its sidecar, it generates one EXACTLY like the
   `pmi-kb-builder` Lambda does — by importing and reusing the real functions from
   knowledge_base/build_kb_from_s3.py:
       _extract_text_preview()  → first ~5000 chars
       _classify_document()     → LLM (Haiku via private LiteLLM gateway) →
                                   theme-level-1, theme-level-2, jurisdiction, language
       _build_metadata_json()   → {"metadataAttributes": {...}}
   The sidecar is written to `<key>.metadata.json` (same key the KB expects).
3. Optionally triggers a Bedrock KB sync at the end (--trigger-sync).

This produces byte-for-byte the same metadata structure/classification as the live
ingestion Lambda, so backfilled files are indistinguishable from trigger-generated ones.

Requirements
------------
- AWS_BEARER_TOKEN_BEDROCK in .env (for the LLM classifier; same key the Lambda uses).
- Network access to the private LiteLLM gateway (VPN/VPC).
- PyPDF2 installed for PDF text extraction (PDFs without it fall back to Others/Global,
  same graceful behaviour as the Lambda).

USAGE
-----
  # 1) Audit only — fast, no LLM calls, no writes (recommended first):
  python audit_and_backfill_metadata.py --dry-run

  # 2) Backfill the missing sidecars (classifies + writes), 8 parallel workers:
  python audit_and_backfill_metadata.py

  # Limit while testing, then trigger KB sync when satisfied:
  python audit_and_backfill_metadata.py --limit 5
  python audit_and_backfill_metadata.py --trigger-sync

  # Force re-tag everything (overwrite existing sidecars too):
  python audit_and_backfill_metadata.py --overwrite
"""
import argparse
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

from dotenv import load_dotenv

# Load env BEFORE importing the KB builder (it reads LITELLM_KEY at import time)
load_dotenv(override=True)

import boto3
from botocore.exceptions import ClientError

# Import the REAL Lambda functions so output matches the pipeline exactly
_KB_DIR = os.path.join(os.path.dirname(__file__), "..", "knowledge_base")
sys.path.insert(0, _KB_DIR)
try:
    import build_kb_from_s3 as kb  # noqa: E402
except ImportError as e:
    print(f"\n❌ FATAL: Failed to import build_kb_from_s3: {e}")
    print(f"   Install missing module: pip install {e.name}")
    sys.exit(1)
except Exception as e:
    print(f"\n❌ FATAL: Error loading build_kb_from_s3: {type(e).__name__}: {e}")
    sys.exit(1)

BUCKET = "pmi-agentic-ai-documents-sandbox-603433800649"
REGION = "eu-west-1"
PREFIX = "sharepoint/pmicloud.sharepoint.com/teams/SAICDIAandCapgeminiTeam-DIA-India/"

s3 = boto3.client("s3", region_name=REGION)


def _list_all_keys(bucket, prefix):
    keys = []
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            keys.append(obj["Key"])
    return keys


def _classify_and_write(bucket, key, dry_run):
    """Download → extract preview → classify → build → write sidecar. Returns a result dict."""
    filename = key.split("/")[-1]
    file_ext = os.path.splitext(filename)[1].lower()
    metadata_key = f"{key}.metadata.json"
    try:
        head = s3.head_object(Bucket=bucket, Key=key)
        existing_meta = head.get("Metadata", {})

        body = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
        text_preview = kb._extract_text_preview(body, file_ext)

        if text_preview.strip():
            classification = kb._classify_document(text_preview, filename)
        else:
            classification = {"level_1": ["Others"], "level_2": ["Others"],
                              "jurisdiction": "Global", "language": ["English"]}

        metadata_content = kb._build_metadata_json(
            classification=classification, filename=filename,
            file_ext=file_ext, existing_s3_metadata=existing_meta,
        )

        if not dry_run:
            s3.put_object(
                Bucket=bucket, Key=metadata_key,
                Body=json.dumps(metadata_content, indent=2),
                ContentType="application/json",
            )
        return {
            "key": key, "ok": True,
            "l1": classification["level_1"], "l2": classification["level_2"],
            "jurisdiction": classification["jurisdiction"], "language": classification["language"],
        }
    except Exception as e:
        return {"key": key, "ok": False, "error": str(e)}


def main():
    ap = argparse.ArgumentParser(description="Audit + backfill .metadata.json sidecars for the SharePoint KB folder.")
    ap.add_argument("--bucket", default=BUCKET)
    ap.add_argument("--region", default=REGION)
    ap.add_argument("--prefix", default=PREFIX)
    ap.add_argument("--dry-run", action="store_true",
                    help="Audit only: report missing sidecars. No LLM calls, no writes.")
    ap.add_argument("--overwrite", action="store_true",
                    help="Re-classify and overwrite ALL sidecars, not just missing ones.")
    ap.add_argument("--limit", type=int, default=0, help="Process at most N documents (0 = all).")
    ap.add_argument("--workers", type=int, default=8, help="Parallel classification workers (default 8).")
    ap.add_argument("--trigger-sync", action="store_true",
                    help="Trigger a Bedrock KB ingestion job after backfilling.")
    args = ap.parse_args()

    print(f"Bucket : {args.bucket}")
    print(f"Prefix : {args.prefix}")
    print(f"Mode   : {'AUDIT (dry-run)' if args.dry_run else 'BACKFILL'}"
          f" | overwrite={args.overwrite} | workers={args.workers} | limit={args.limit or 'all'}")
    print("=" * 90)

    all_keys = _list_all_keys(args.bucket, args.prefix)
    meta_keys = {k for k in all_keys if k.endswith(".metadata.json")}

    docs, unsupported = [], []
    for k in all_keys:
        if k.endswith("/") or k.endswith(".metadata.json") or "/Exception_docs/" in k:
            continue
        ext = os.path.splitext(k)[1].lower()
        (docs if ext in kb.SUPPORTED_EXTENSIONS else unsupported).append(k)

    have = [d for d in docs if f"{d}.metadata.json" in meta_keys]
    missing = [d for d in docs if f"{d}.metadata.json" not in meta_keys]

    print(f"Documents (supported types) : {len(docs)}")
    print(f"  with .metadata.json       : {len(have)}")
    print(f"  MISSING .metadata.json    : {len(missing)}")
    if unsupported:
        print(f"Unsupported types (no metadata possible): {len(unsupported)}")
        for u in unsupported[:10]:
            print(f"    - {u.split('/')[-1]}")
        if len(unsupported) > 10:
            print(f"    ... +{len(unsupported) - 10} more")
    print("-" * 90)

    # Decide the work set
    targets = docs if args.overwrite else missing
    if args.limit:
        targets = targets[:args.limit]

    if not targets:
        print("Nothing to do — every supported document already has a sidecar.")
        return 0

    if args.dry_run:
        print(f"WOULD generate {len(targets)} sidecar(s):")
        for k in targets[:50]:
            print(f"    + {k}.metadata.json")
        if len(targets) > 50:
            print(f"    ... +{len(targets) - 50} more")
        print("\nDry run only — re-run without --dry-run to classify and write.")
        return 0

    # Backfill (parallel — classification is LLM/network-bound)
    print(f"Classifying + writing {len(targets)} sidecar(s) with {args.workers} workers...\n")
    done = failed = 0
    jur_tally, l1_tally = {}, {}
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futures = {ex.submit(_classify_and_write, args.bucket, k, False): k for k in targets}
        for fut in as_completed(futures):
            r = fut.result()
            if r["ok"]:
                done += 1
                jur_tally[r["jurisdiction"]] = jur_tally.get(r["jurisdiction"], 0) + 1
                for v in r["l1"]:
                    l1_tally[v] = l1_tally.get(v, 0) + 1
                print(f"  [{done}] {r['key'].split('/')[-1]} | {r['jurisdiction']} "
                      f"| L1={r['l1']} | L2={r['l2']} | {r['language']}")
            else:
                failed += 1
                print(f"  ERROR | {r['key'].split('/')[-1]} | {r['error']}")

    print("-" * 90)
    print(f"Backfilled: {done} | failed: {failed}")
    print(f"By jurisdiction : {dict(sorted(jur_tally.items(), key=lambda x: -x[1]))}")
    print(f"By theme-level-1: {dict(sorted(l1_tally.items(), key=lambda x: -x[1]))}")

    if args.trigger_sync and done > 0:
        print("-" * 90)
        job = kb._trigger_kb_sync()
        print(f"KB sync triggered: {job}")

    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
