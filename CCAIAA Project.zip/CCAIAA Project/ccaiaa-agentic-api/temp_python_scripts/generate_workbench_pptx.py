"""Generate Ask Spidy Workbench (AgentCore) architecture as a professional PowerPoint (.pptx).

Two-tier corporate diagram:
  TIER 1 — Chat Experience Layer  (NEW code, built on REUSED API + DynamoDB patterns)
      Chat UI -> API Gateway -> Conversation Service / Message Service -> Conversations / Messages tables
  TIER 2 — Agent & Reasoning Layer (Amazon Bedrock AgentCore, Backend Tools REUSED as-is)
      Proxy Lambda -> AgentCore Runtime -> Agentic Framework + Memory + Backend Tools

Reuse legend (3 levels):
  NEW build            -> Chat UI, Conversation Service, Message Service, Conversations/Messages tables
  Reuse code patterns  -> API GW + Lambda routing, DynamoDB repo, DecimalEncoder, user-isolation, CORS
  Reused as-is         -> KB Retrieval (researcher_kb), Web Search (researcher_web),
                          Curated Links Search (researcher_web), Drafter/Narrative (drafter_*),
                          Requests + HITL tables
"""
import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
os.makedirs(OUT_DIR, exist_ok=True)

# ── Palette ──
NAVY = RGBColor(0x1B, 0x2A, 0x4A)
BLUE = RGBColor(0x25, 0x63, 0xEB)
LIGHT_BLUE = RGBColor(0xDB, 0xEA, 0xFE)
GREEN = RGBColor(0x05, 0x96, 0x69)
GREEN_LIGHT = RGBColor(0xD1, 0xFA, 0xE5)
PURPLE = RGBColor(0x7C, 0x3A, 0xED)
AMBER = RGBColor(0xD9, 0x77, 0x06)
AMBER_LIGHT = RGBColor(0xFE, 0xF3, 0xC7)
LAMBDA_ORANGE = RGBColor(0xED, 0x7D, 0x31)
TEAL = RGBColor(0x0D, 0x94, 0x88)
GRAY = RGBColor(0x6B, 0x72, 0x80)
LIGHT_GRAY = RGBColor(0xF3, 0xF4, 0xF6)
BORDER_GRAY = RGBColor(0xB8, 0xBE, 0xC7)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
slide = prs.slides.add_slide(prs.slide_layouts[6])


def add_box(x, y, w, h, fill, text, title_size=12, text_color=WHITE,
            outline=None, subtitle=None, sub_size=8, bold=True,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE, sub_color=None, ol_w=1.25):
    box = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    box.fill.solid()
    box.fill.fore_color.rgb = fill
    box.shadow.inherit = False
    if outline:
        box.line.color.rgb = outline
        box.line.width = Pt(ol_w)
    else:
        box.line.fill.background()
    tf = box.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.size = Pt(title_size)
    run.font.bold = bold
    run.font.color.rgb = text_color
    if subtitle:
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        r2 = p2.add_run()
        r2.text = subtitle
        r2.font.size = Pt(sub_size)
        r2.font.color.rgb = sub_color if sub_color else text_color
    return box


def add_label(x, y, w, h, text, size=12, color=NAVY, bold=True, align=PP_ALIGN.LEFT):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    return tb


def add_arrow(x, y, w, h, color=GRAY, direction='right'):
    m = {'right': MSO_SHAPE.RIGHT_ARROW, 'left': MSO_SHAPE.LEFT_ARROW,
         'down': MSO_SHAPE.DOWN_ARROW, 'up': MSO_SHAPE.UP_ARROW}
    shp = slide.shapes.add_shape(m[direction], Inches(x), Inches(y), Inches(w), Inches(h))
    shp.fill.solid()
    shp.fill.fore_color.rgb = color
    shp.line.fill.background()
    shp.shadow.inherit = False
    return shp


def add_container(x, y, w, h, fill, outline, dashed=False, width=1.5):
    box = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill is None:
        box.fill.background()
    else:
        box.fill.solid()
        box.fill.fore_color.rgb = fill
    box.line.color.rgb = outline
    box.line.width = Pt(width)
    box.shadow.inherit = False
    if dashed:
        ln = box.line._get_or_add_ln()
        ln.append(ln.makeelement(qn('a:prstDash'), {'val': 'dash'}))
    return box


# ── TITLE ──
add_label(0.3, 0.10, 9.0, 0.42, "Ask Spidy — Workbench Architecture (Amazon Bedrock AgentCore)",
          size=22, color=NAVY)
add_label(0.3, 0.52, 12.7, 0.30,
          "Conversational agent — new chat layer built on reused API/DynamoDB patterns; intelligence tools reused as-is",
          size=11, color=GRAY, bold=False)

# ── LEGEND ──
ly = 0.86
add_box(6.55, ly, 0.26, 0.24, AMBER, "", 8, WHITE)
add_label(6.86, ly - 0.02, 1.5, 0.28, "NEW build", size=9, color=NAVY, bold=False)
add_box(8.05, ly, 0.26, 0.24, BLUE, "", 8, WHITE)
add_label(8.36, ly - 0.02, 2.1, 0.28, "Reuse code patterns", size=9, color=NAVY, bold=False)
add_box(10.35, ly, 0.26, 0.24, GREEN, "", 8, WHITE)
add_label(10.66, ly - 0.02, 2.3, 0.28, "Reused as-is", size=9, color=NAVY, bold=False)

# ── OUTER AWS CONTAINER ──
aws_x, aws_y, aws_w, aws_h = 0.25, 1.22, 12.85, 4.55
add_container(aws_x, aws_y, aws_w, aws_h, WHITE, NAVY, width=2.0)
add_label(aws_x + 0.12, aws_y + 0.03, 2.0, 0.30, "AWS", size=15, color=NAVY)

# ══════════════════ TIER 1 — CHAT EXPERIENCE LAYER ══════════════════
add_label(aws_x + 0.55, aws_y + 0.30, 6.0, 0.26,
          "TIER 1 — Chat Experience Layer", size=11, color=AMBER)

# Chat UI Application (NEW)
add_box(0.5, 1.85, 2.05, 1.30, AMBER_LIGHT, "Chat UI Application", 11, NAVY, AMBER,
        "• Multi-chat + history + scroll\n• New / delete chat\n• Starter examples\n• User isolation", 8,
        sub_color=GRAY, ol_w=1.5)
add_arrow(2.58, 2.36, 0.28, 0.24, GRAY, 'right')

# API Gateway (reuse pattern)
add_box(2.9, 2.05, 1.2, 0.85, LIGHT_BLUE, "API Gateway", 11, NAVY, BLUE,
        "Routing & Auth\nHTTPS / WSS", 8, sub_color=BLUE, ol_w=1.25)
add_arrow(4.12, 2.36, 0.24, 0.24, GRAY, 'right')

# Conversation + Message services (NEW code, reuse pattern → amber fill, blue outline)
add_box(4.4, 1.85, 1.95, 0.62, AMBER, "Conversation Service", 10, WHITE, BLUE,
        "POST / GET / DELETE  /conversations", 7.5, sub_color=WHITE, ol_w=1.75)
add_box(4.4, 2.53, 1.95, 0.62, AMBER, "Message Service", 10, WHITE, BLUE,
        "POST / GET  /messages · history", 7.5, sub_color=WHITE, ol_w=1.75)
add_arrow(6.37, 2.36, 0.22, 0.22, GRAY, 'right')

# Conversations + Messages tables (NEW)
add_box(6.62, 1.85, 1.75, 0.62, AMBER_LIGHT, "Conversations", 10, NAVY, AMBER,
        "PK UserId · SK ConvId", 7.5, sub_color=GRAY, shape=MSO_SHAPE.CAN, ol_w=1.25)
add_box(6.62, 2.53, 1.75, 0.62, AMBER_LIGHT, "Messages", 10, NAVY, AMBER,
        "PK ConvId · SK Ts#MsgId", 7.5, sub_color=GRAY, shape=MSO_SHAPE.CAN, ol_w=1.25)

# Frontend requirements callout (right)
add_container(8.62, 1.82, 4.35, 1.35, LIGHT_GRAY, BORDER_GRAY, dashed=True, width=1.0)
add_label(8.74, 1.86, 4.1, 0.24, "Frontend Requirements", size=10, color=NAVY)
add_label(8.74, 2.12, 2.05, 1.0,
          "• Multiple chats / conversations\n• Full message history + scroll\n• Differentiate by conversation_id",
          size=8.5, color=GRAY, bold=False)
add_label(10.85, 2.12, 2.05, 1.0,
          "• Add new chat\n• Delete chat\n• Conversation starter examples",
          size=8.5, color=GRAY, bold=False)

# divider
div = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(aws_x + 0.4), Inches(3.32), Inches(aws_w - 0.8), Pt(1))
div.fill.solid(); div.fill.fore_color.rgb = BORDER_GRAY; div.line.fill.background(); div.shadow.inherit = False

# ══════════════════ TIER 2 — AGENT & REASONING LAYER ══════════════════
add_label(aws_x + 0.55, 3.42, 8.0, 0.26,
          "TIER 2 — Agent & Reasoning Layer  (Amazon Bedrock AgentCore)", size=11, color=BLUE)

# message service -> proxy lambda (agent turn)
add_arrow(5.25, 3.15, 0.2, 0.72, GRAY, 'down')
add_label(5.5, 3.30, 1.6, 0.24, "agent turn", size=7.5, color=GRAY, bold=False)

# Proxy Lambda (reuse pattern)
add_box(4.4, 3.95, 1.9, 1.05, LAMBDA_ORANGE, "Proxy Lambda", 11, WHITE, None,
        "validate · create job_id\nstore status · invoke runtime", 8)

# Requests + HITL tables (reused as-is)
add_box(2.45, 3.95, 1.7, 0.46, GREEN_LIGHT, "Requests", 9, NAVY, GREEN,
        None, shape=MSO_SHAPE.CAN, ol_w=1.25)
add_box(2.45, 4.52, 1.7, 0.46, GREEN_LIGHT, "HITL / Status", 9, NAVY, GREEN,
        None, shape=MSO_SHAPE.CAN, ol_w=1.25)
add_arrow(4.18, 4.35, 0.2, 0.24, GREEN, 'left')

# Proxy -> AgentCore
add_arrow(6.32, 4.35, 0.5, 0.26, NAVY, 'right')
add_label(6.28, 4.10, 0.7, 0.22, "Trigger", size=8, color=NAVY, align=PP_ALIGN.CENTER)

# AgentCore container
ac_x, ac_y, ac_w, ac_h = 6.9, 3.55, 6.1, 2.0
add_container(ac_x, ac_y, ac_w, ac_h, RGBColor(0xF7, 0xF9, 0xFC), BLUE, dashed=True, width=1.5)
add_label(ac_x + 0.12, ac_y + 0.04, 3.5, 0.28, "Amazon Bedrock AgentCore", size=11, color=BLUE)

# Runtime
add_box(ac_x + 0.15, 4.15, 1.35, 1.05, NAVY, "AgentCore Runtime", 10, WHITE, None,
        "container · async\nsessions", 7.5)
add_arrow(ac_x + 1.52, 4.5, 0.32, 0.22, BLUE, 'right')
add_label(ac_x + 1.48, 4.26, 0.42, 0.2, "Run", size=7.5, color=BLUE, align=PP_ALIGN.CENTER)
# Framework
add_box(ac_x + 1.88, 4.1, 1.45, 1.15, BLUE, "Agentic Framework", 10, WHITE, None,
        "LangGraph / LangChain\ntool-calling agent", 7.5)
# Memory (top)
add_box(ac_x + 1.95, 3.62, 1.35, 0.4, PURPLE, "AgentCore Memory", 8.5, WHITE, None, None)
add_arrow(ac_x + 2.55, 4.02, 0.16, 0.12, PURPLE, 'up')
# framework -> tools
add_arrow(ac_x + 3.35, 4.5, 0.28, 0.22, GREEN, 'right')

# Backend tools (reused as-is)
bt_x, bt_y, bt_w, bt_h = ac_x + 3.68, 3.62, 2.28, 1.85
add_container(bt_x, bt_y, bt_w, bt_h, GREEN_LIGHT, GREEN, dashed=False, width=1.5)
add_label(bt_x + 0.1, bt_y + 0.03, bt_w - 0.15, 0.24, "Backend Tools — REUSED", size=9, color=GREEN)
tools = [
    "KB Retrieval · researcher_kb",
    "Full Web Search · researcher_web",
    "Curated Links · researcher_web",
    "Drafter / Narrative · drafter_*",
]
tyy = bt_y + 0.32
for t in tools:
    add_box(bt_x + 0.12, tyy, bt_w - 0.24, 0.32, WHITE, t, 8, NAVY, GREEN, None, ol_w=1.0)
    tyy += 0.37

# ── FOOTER ──
foot = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.25), Inches(5.95), Inches(12.85), Inches(0.42))
foot.fill.solid(); foot.fill.fore_color.rgb = NAVY; foot.line.fill.background(); foot.shadow.inherit = False
tf = foot.text_frame; tf.vertical_anchor = MSO_ANCHOR.MIDDLE
p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
run = p.add_run()
run.text = ("REUSE: Conversation & Message services built on existing Lambda + DynamoDB repo patterns "
            "(DecimalEncoder, user-isolation, CORS)  |  KB / Web / Curated / Drafter tools reused as-is")
run.font.size = Pt(10); run.font.bold = True; run.font.color.rgb = WHITE

# ── SECOND FOOTER LINE (reuse breakdown) ──
foot2 = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.25), Inches(6.45), Inches(12.85), Inches(0.42))
foot2.fill.solid(); foot2.fill.fore_color.rgb = GREEN; foot2.line.fill.background(); foot2.shadow.inherit = False
tf2 = foot2.text_frame; tf2.vertical_anchor = MSO_ANCHOR.MIDDLE
p2 = tf2.paragraphs[0]; p2.alignment = PP_ALIGN.CENTER
r = p2.add_run()
r.text = ("NEW: Chat UI, Conversation Service, Message Service, Conversations & Messages tables    "
          "•    REUSED AS-IS: KB Search, Web Search, Curated Links Search, Drafter, Requests & HITL tables")
r.font.size = Pt(10); r.font.bold = True; r.font.color.rgb = WHITE

out_path = os.path.join(OUT_DIR, "AskSpidy_Workbench_Architecture.pptx")
prs.save(out_path)
print(f"Saved: {out_path}")
