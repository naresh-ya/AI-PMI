"""Generate Ingestion Pipeline Architecture as a professional PowerPoint (.pptx).

Full flow: SharePoint → S3 → LLM Classification (Theme L1/L2, Jurisdiction, Language)
→ .metadata.json → Bedrock KB Sync → OpenSearch → KB Retrieval with metadata filtering.
"""
import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
os.makedirs(OUT_DIR, exist_ok=True)

# Palette
NAVY = RGBColor(0x1B, 0x2A, 0x4A)
BLUE = RGBColor(0x25, 0x63, 0xEB)
LIGHT_BLUE = RGBColor(0xDB, 0xEA, 0xFE)
GREEN = RGBColor(0x05, 0x96, 0x69)
GREEN_LIGHT = RGBColor(0xD1, 0xFA, 0xE5)
PURPLE = RGBColor(0x7C, 0x3A, 0xED)
PURPLE_LIGHT = RGBColor(0xED, 0xE9, 0xFE)
ORANGE = RGBColor(0xEA, 0x58, 0x0C)
AMBER = RGBColor(0xD9, 0x77, 0x06)
TEAL = RGBColor(0x0D, 0x94, 0x88)
GRAY = RGBColor(0x6B, 0x72, 0x80)
LIGHT_GRAY = RGBColor(0xF3, 0xF4, 0xF6)
BORDER_GRAY = RGBColor(0xB8, 0xBE, 0xC7)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
slide = prs.slides.add_slide(prs.slide_layouts[6])


def add_box(x, y, w, h, fill, text, title_size=11, text_color=WHITE,
            outline=None, subtitle=None, sub_size=8, bold=True,
            shape=MSO_SHAPE.ROUNDED_RECTANGLE, sub_color=None, ol_w=1.25):
    box = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    box.fill.solid()
    box.fill.fore_color.rgb = fill
    box.shadow.inherit = False
    if outline:
        box.line.color.rgb = outline
        box.line.width = Pt(ol_w)
    else:
        box.line.fill.background()
    tf = box.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.size = Pt(title_size)
    run.font.bold = bold
    run.font.color.rgb = text_color
    if subtitle:
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        r2 = p2.add_run()
        r2.text = subtitle
        r2.font.size = Pt(sub_size)
        r2.font.color.rgb = sub_color if sub_color else text_color
    return box


def add_label(x, y, w, h, text, size=12, color=NAVY, bold=True, align=PP_ALIGN.LEFT):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    return tb


def add_arrow(x, y, w, h, color=GRAY, direction='right'):
    m = {'right': MSO_SHAPE.RIGHT_ARROW, 'left': MSO_SHAPE.LEFT_ARROW,
         'down': MSO_SHAPE.DOWN_ARROW, 'up': MSO_SHAPE.UP_ARROW}
    shp = slide.shapes.add_shape(m[direction], Inches(x), Inches(y), Inches(w), Inches(h))
    shp.fill.solid()
    shp.fill.fore_color.rgb = color
    shp.line.fill.background()
    shp.shadow.inherit = False
    return shp


def add_container(x, y, w, h, fill, outline, dashed=False, width=1.5):
    box = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill is None:
        box.fill.background()
    else:
        box.fill.solid()
        box.fill.fore_color.rgb = fill
    box.line.color.rgb = outline
    box.line.width = Pt(width)
    box.shadow.inherit = False
    if dashed:
        ln = box.line._get_or_add_ln()
        ln.append(ln.makeelement(qn('a:prstDash'), {'val': 'dash'}))
    return box


# ══════════ TITLE ══════════
add_label(0.3, 0.12, 10.0, 0.42,
          "Knowledge Base Ingestion & Retrieval Pipeline",
          size=22, color=NAVY)
add_label(0.3, 0.54, 12.7, 0.28,
          "SharePoint → S3 → LLM Classification (Sonnet) → Metadata Tagging → Bedrock KB → Metadata-Filtered Retrieval",
          size=11, color=GRAY, bold=False)

# ══════════ ROW 1: INGESTION (left to right) ══════════
add_label(0.4, 1.0, 5.0, 0.26, "STAGE 1 — Ingestion (EventBridge / Manual Trigger)", size=11, color=ORANGE)

# SharePoint
add_box(0.4, 1.35, 1.7, 1.0, PURPLE, "SharePoint", 12, WHITE, None,
        "PMI Cloud\n• .docx .pdf .pptx\n• ~1566 docs\n• Folder: Consolidated Artifacts", 7.5)
add_arrow(2.15, 1.72, 0.35, 0.24, GRAY, 'right')

# Ingestion Lambda
add_box(2.55, 1.35, 2.0, 1.0, AMBER, "Ingestion Lambda", 11, WHITE, None,
        "handler.py\n• Graph API auth\n• Download files\n• Extract SP metadata\n• Upload to S3", 7.5)
add_arrow(4.6, 1.72, 0.35, 0.24, GRAY, 'right')

# S3 Bucket
add_box(5.0, 1.35, 1.8, 1.0, BLUE, "S3 Bucket", 12, WHITE, None,
        "pmi-agentic-ai-documents\nprefix: sharepoint/\n+ S3 object metadata", 7.5)

# SP metadata callout
add_container(7.0, 1.3, 3.0, 1.1, LIGHT_GRAY, BORDER_GRAY, dashed=True, width=1.0)
add_label(7.12, 1.34, 2.8, 0.22, "S3 Object Metadata (from SharePoint)", size=9, color=NAVY)
add_label(7.12, 1.58, 2.8, 0.8,
          "• sharepoint-jurisdiction\n• sharepoint-theme-level-1\n• sharepoint-theme-level-2\n• sharepoint-language\n• sharepoint-owner\n• source-filename",
          size=8, color=GRAY, bold=False)

# ══════════ ROW 2: CLASSIFICATION ══════════
add_label(0.4, 2.55, 6.0, 0.26, "STAGE 2 — LLM Classification & Metadata Tagging (S3 Event Trigger)", size=11, color=BLUE)

# S3 Event trigger arrow
add_arrow(5.8, 2.38, 0.2, 0.5, BLUE, 'down')
add_label(5.4, 2.4, 1.2, 0.22, "S3 Event", size=8, color=BLUE, align=PP_ALIGN.CENTER)

# Classifier Lambda
add_box(0.4, 2.9, 2.2, 1.3, NAVY, "Classifier Lambda", 12, WHITE, None,
        "build_kb_from_s3.py\n• Extract text (10K chars)\n• Filename context\n• Call LLM (Sonnet)", 7.5)
add_arrow(2.65, 3.4, 0.35, 0.24, GRAY, 'right')

# LLM Classification
add_box(3.05, 2.9, 2.5, 1.3, PURPLE, "LLM Classification", 11, WHITE, None,
        "Claude Sonnet via LiteLLM\n\nOutputs:\n• theme-level-1 (product area)\n• theme-level-2 (topic)\n• jurisdiction (country)\n• language", 7.5)
add_arrow(5.6, 3.4, 0.35, 0.24, GRAY, 'right')

# .metadata.json
add_box(6.0, 2.9, 2.0, 1.3, TEAL, ".metadata.json", 11, WHITE, None,
        "Written to S3\nsame prefix as file\n\nPicked up by\nBedrock KB sync", 7.5)
add_arrow(8.05, 3.4, 0.35, 0.24, GRAY, 'right')

# Bedrock KB Sync
add_box(8.45, 2.9, 2.0, 1.3, GREEN, "Bedrock KB Sync", 11, WHITE, None,
        "StartIngestionJob\n• Chunks documents\n• Embeds vectors\n• Stores in OpenSearch\n• Indexes metadata", 7.5)

# Classification taxonomy callout
add_container(10.6, 2.85, 2.5, 1.4, PURPLE_LIGHT, PURPLE, dashed=True, width=1.0)
add_label(10.72, 2.9, 2.3, 0.22, "Classification Taxonomy", size=9, color=PURPLE)
add_label(10.72, 3.14, 2.3, 0.5,
          "Level 1 (Product Area):\n• SFP / HTP\n• Combustible cigarettes\n• Corporate Equity\n• Others",
          size=7.5, color=GRAY, bold=False)
add_label(10.72, 3.72, 2.3, 0.5,
          "Level 2 (Topic):\n• Regulatory  • Fiscal & Taxes\n• Illicit Trade  • Scientific\n• Youth Prevention  • Sustainability",
          size=7.5, color=GRAY, bold=False)

# ══════════ ROW 3: RETRIEVAL ══════════
add_label(0.4, 4.45, 6.0, 0.26, "STAGE 3 — KB Retrieval with Metadata Filtering (Research Pipeline)", size=11, color=GREEN)

# Research request
add_box(0.4, 4.8, 1.8, 1.2, LIGHT_BLUE, "Research Request", 10, NAVY, BLUE,
        "topic + jurisdiction\n+ category\n+ background", 7.5, sub_color=NAVY, ol_w=1.25)
add_arrow(2.25, 5.28, 0.35, 0.24, GRAY, 'right')

# KB Researcher
add_box(2.65, 4.8, 2.3, 1.2, BLUE, "KB Researcher", 11, WHITE, None,
        "researcher_kb.py\n• Signal extraction (LLM)\n• Query enrichment (LLM)\n• Theme classification (LLM)\n• 8 query variants", 7.5)
add_arrow(5.0, 5.28, 0.35, 0.24, GRAY, 'right')

# Bedrock KB + OpenSearch
add_box(5.4, 4.8, 2.2, 1.2, GREEN, "Bedrock KB", 12, WHITE, None,
        "Vector Search\n+ Metadata Filters:\n• jurisdiction = X\n• theme-level-1 contains Y\n• theme-level-2 contains Z", 7.5)
add_arrow(7.65, 5.28, 0.35, 0.24, GRAY, 'right')

# Results
add_box(8.05, 4.8, 2.2, 1.2, NAVY, "Filtered Results", 11, WHITE, None,
        "Top-K sources\n• Relevance scored\n• Reranked (Cohere)\n• Deduped by URL\n→ Synthesis + Draft", 7.5)

# Metadata filter callout
add_container(10.5, 4.75, 2.6, 1.3, GREEN_LIGHT, GREEN, dashed=True, width=1.0)
add_label(10.62, 4.8, 2.4, 0.22, "Metadata Filters Applied", size=9, color=GREEN)
add_label(10.62, 5.04, 2.4, 0.9,
          "• jurisdiction (exact match)\n• theme-level-1 (contains)\n• theme-level-2 (contains)\n\nSoft filter: if 0 results,\nretry WITHOUT theme filters",
          size=7.5, color=GRAY, bold=False)

# ══════════ FOOTER ══════════
foot = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.25), Inches(6.25), Inches(12.85), Inches(0.55))
foot.fill.solid()
foot.fill.fore_color.rgb = NAVY
foot.line.fill.background()
foot.shadow.inherit = False
tf = foot.text_frame
tf.vertical_anchor = MSO_ANCHOR.MIDDLE
p = tf.paragraphs[0]
p.alignment = PP_ALIGN.CENTER
run = p.add_run()
run.text = ("FLOW: SharePoint (Graph API) → S3 upload → S3 Event triggers Classifier Lambda → "
            "Sonnet classifies (L1/L2/Jurisdiction/Language) → .metadata.json written → "
            "Bedrock KB syncs + indexes → Research uses metadata filters for precision retrieval")
run.font.size = Pt(9.5)
run.font.bold = True
run.font.color.rgb = WHITE

# Second footer — tools
foot2 = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.25), Inches(6.88), Inches(12.85), Inches(0.45))
foot2.fill.solid()
foot2.fill.fore_color.rgb = GREEN
foot2.line.fill.background()
foot2.shadow.inherit = False
tf2 = foot2.text_frame
tf2.vertical_anchor = MSO_ANCHOR.MIDDLE
p2 = tf2.paragraphs[0]
p2.alignment = PP_ALIGN.CENTER
r = p2.add_run()
r.text = ("FILES: ingestion/handler.py  •  knowledge_base/build_kb_from_s3.py  •  "
          "core/kb_integration_new.py  •  agents/master_researcher/researcher_kb.py  •  "
          "temp_python_scripts/retag_all_kb_sources.py (bulk re-tag)")
r.font.size = Pt(9)
r.font.bold = True
r.font.color.rgb = WHITE

out_path = os.path.join(OUT_DIR, "Ingestion_Pipeline_Architecture.pptx")
prs.save(out_path)
print(f"Saved: {out_path}")
