"""Generate Medium blog article as Word doc + architecture diagram as JPG."""
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
os.makedirs(OUT_DIR, exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════════
# 1. Generate Architecture Diagram (JPG)
# ═══════════════════════════════════════════════════════════════════════════════
try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    import subprocess
    subprocess.check_call(["pip", "install", "Pillow", "--quiet"])
    from PIL import Image, ImageDraw, ImageFont

# Create diagram
WIDTH, HEIGHT = 1200, 700
img = Image.new('RGB', (WIDTH, HEIGHT), '#FFFFFF')
draw = ImageDraw.Draw(img)

# Try to use a clean font, fall back to default
try:
    font_title = ImageFont.truetype("calibri.ttf", 24)
    font_body = ImageFont.truetype("calibri.ttf", 16)
    font_small = ImageFont.truetype("calibri.ttf", 13)
except:
    font_title = ImageFont.load_default()
    font_body = ImageFont.load_default()
    font_small = ImageFont.load_default()

# Colors
NAVY = '#1F3A5F'
BLUE = '#3B82F6'
RED = '#EF4444'
GREEN = '#10B981'
GRAY = '#6B7280'
LIGHT_GRAY = '#F3F4F6'
ORANGE = '#F59E0B'

def draw_box(x, y, w, h, fill, outline, text, font=font_body, text_color='#FFFFFF'):
    draw.rounded_rectangle([x, y, x+w, y+h], radius=8, fill=fill, outline=outline, width=2)
    # Center text
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text((x + (w - tw) // 2, y + (h - th) // 2), text, fill=text_color, font=font)

def draw_arrow(x1, y1, x2, y2, color=GRAY):
    draw.line([(x1, y1), (x2, y2)], fill=color, width=2)
    # Arrowhead
    if x2 > x1:  # right arrow
        draw.polygon([(x2, y2), (x2-8, y2-5), (x2-8, y2+5)], fill=color)
    elif y2 > y1:  # down arrow
        draw.polygon([(x2, y2), (x2-5, y2-8), (x2+5, y2-8)], fill=color)

# Title
draw.text((30, 20), "Silent Error Lifecycle in Serverless Architectures", fill=NAVY, font=font_title)
draw.text((30, 52), "How invisible failures propagate through a cloud-native pipeline", fill=GRAY, font=font_small)

# Row 1: The Happy Path
draw.text((30, 90), "HAPPY PATH (appears successful):", fill=GREEN, font=font_small)
draw_box(30, 110, 150, 50, BLUE, BLUE, "API Gateway")
draw_arrow(180, 135, 210, 135)
draw_box(210, 110, 150, 50, BLUE, BLUE, "Lambda")
draw_arrow(360, 135, 390, 135)
draw_box(390, 110, 150, 50, BLUE, BLUE, "DB Write")
draw_arrow(540, 135, 570, 135)
draw_box(570, 110, 150, 50, GREEN, GREEN, "200 OK ✓")
draw_arrow(720, 135, 750, 135)
draw_box(750, 110, 150, 50, GREEN, GREEN, "User Sees Data")

# Row 2: The Silent Failure Path
draw.text((30, 190), "SILENT FAILURE PATH (appears identical):", fill=RED, font=font_small)
draw_box(30, 210, 150, 50, BLUE, BLUE, "API Gateway")
draw_arrow(180, 235, 210, 235)
draw_box(210, 210, 150, 50, BLUE, BLUE, "Lambda")
draw_arrow(360, 235, 390, 235)
draw_box(390, 210, 150, 50, RED, RED, "DB Write FAILS")
draw_arrow(540, 235, 570, 235)
draw_box(570, 210, 150, 50, ORANGE, ORANGE, "except: pass", text_color='#000000')
draw_arrow(720, 235, 750, 235)
draw_box(750, 210, 150, 50, GREEN, GREEN, "200 OK ✓")
draw_arrow(900, 235, 930, 235)
draw_box(930, 210, 240, 50, RED, RED, "User Sees STALE Data")

# Row 3: Why it fails
draw.text((30, 300), "COMMON SILENT FAILURE CAUSES:", fill=NAVY, font=font_body)

# Cause boxes
draw_box(30, 330, 350, 60, LIGHT_GRAY, GRAY, "Reserved Keywords", text_color='#000000')
draw.text((40, 365), "field names like 'status', 'sources', 'name'", fill=GRAY, font=font_small)

draw_box(410, 330, 350, 60, LIGHT_GRAY, GRAY, "Type Mismatches", text_color='#000000')
draw.text((420, 365), "float vs Decimal, datetime vs string", fill=GRAY, font=font_small)

draw_box(790, 330, 350, 60, LIGHT_GRAY, GRAY, "Broad Exception Handlers", text_color='#000000')
draw.text((800, 365), "except Exception: log.warning(...)", fill=GRAY, font=font_small)

# Row 4: The Fix
draw.text((30, 420), "THE FIX — MAKE FAILURES LOUD:", fill=GREEN, font=font_body)

draw_box(30, 450, 220, 80, '#ECFDF5', GREEN, "Escape Field Names", text_color='#000000')
draw.text((40, 500), "Always use parameterized\nattribute names", fill=GRAY, font=font_small)

draw_box(270, 450, 220, 80, '#ECFDF5', GREEN, "Read-After-Write", text_color='#000000')
draw.text((280, 500), "Verify critical writes\nimmediately after", fill=GRAY, font=font_small)

draw_box(510, 450, 220, 80, '#ECFDF5', GREEN, "Specific Exceptions", text_color='#000000')
draw.text((520, 500), "Catch TypeError, ClientError\nseparately — never generic", fill=GRAY, font=font_small)

draw_box(750, 450, 220, 80, '#ECFDF5', GREEN, "Log State Changes", text_color='#000000')
draw.text((760, 500), "Log before AND after\nwith measurable counts", fill=GRAY, font=font_small)

draw_box(990, 450, 180, 80, '#ECFDF5', GREEN, "Test Locally", text_color='#000000')
draw.text((1000, 500), "Run real DB writes\nbefore deploying", fill=GRAY, font=font_small)

# Row 5: Key insight
draw.rounded_rectangle([30, 560, 1170, 640], radius=10, fill='#FEF3C7', outline=ORANGE, width=2)
draw.text((50, 575), "KEY INSIGHT:", fill=ORANGE, font=font_body)
draw.text((50, 600), "A system that crashes on bad writes is SAFER than one that silently continues with corrupted state.", fill='#000000', font=font_body)
draw.text((50, 625), "The cost of a loud failure: 5-minute fix. The cost of a silent failure: days of debugging + lost trust.", fill=GRAY, font=font_small)

# Footer
draw.text((30, 665), "© 2026 | Architecture patterns for serverless data integrity", fill=GRAY, font=font_small)

# Save diagram
diagram_path = os.path.join(OUT_DIR, "Silent_Errors_Architecture_Diagram.jpg")
img.save(diagram_path, "JPEG", quality=95)
print(f"Diagram saved: {diagram_path}")


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Generate Medium Article (Word Doc)
# ═══════════════════════════════════════════════════════════════════════════════
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Georgia'  # Medium uses serif fonts
style.font.size = Pt(11)

# Title
title = doc.add_heading("Silent Errors in Serverless: The Failures Nobody Sees", level=0)
for run in title.runs:
    run.font.size = Pt(28)

# Subtitle
p = doc.add_paragraph("How invisible failures in cloud-native architectures silently corrupt your data — and 5 practices to make them loud.")
p.runs[0].font.size = Pt(14)
p.runs[0].font.italic = True
p.runs[0].font.color.rgb = RGBColor(0x6B, 0x72, 0x80)
doc.add_paragraph()

# Image placeholder note
p = doc.add_paragraph()
p.add_run("[INSERT ARCHITECTURE DIAGRAM HERE: Silent_Errors_Architecture_Diagram.jpg]").bold = True
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.add_paragraph()

# --- Article Body ---

doc.add_paragraph(
    "Your Lambda function returns 200. Your Step Functions execution shows 'Succeeded'. "
    "Your CloudWatch dashboard is all green. But your user is looking at data from three days ago."
)
doc.add_paragraph(
    "Welcome to silent errors — the most insidious class of bugs in serverless architectures."
)

doc.add_heading("What is a Silent Error?", level=1)
doc.add_paragraph(
    "A silent error is a failure that doesn't crash your system, doesn't trigger an alarm, "
    "and doesn't return an error to the caller. The operation fails, but execution continues "
    "as if nothing happened. The database doesn't get updated. The state doesn't change. "
    "But everything downstream assumes it did."
)
doc.add_paragraph(
    "In traditional monolithic systems, these failures usually manifest as visible crashes. "
    "But in serverless — where every operation is wrapped in retry logic, error handlers, "
    "and fail-open patterns — they become invisible."
)

doc.add_heading("The Anatomy of a Silent Failure", level=1)
doc.add_paragraph(
    "Every silent error I've encountered in production follows the same five-step lifecycle:"
)
doc.add_paragraph("1. A developer adds a try/except around a database write as a 'safety net'.", style='List Number')
doc.add_paragraph("2. An unexpected failure occurs (wrong type, reserved word, missing permission).", style='List Number')
doc.add_paragraph("3. The generic exception handler catches it and logs a warning.", style='List Number')
doc.add_paragraph("4. The function returns success to the caller.", style='List Number')
doc.add_paragraph("5. The user sees stale data. Nobody knows for days.", style='List Number')
doc.add_paragraph()
doc.add_paragraph(
    "The tragedy is that the developer had good intentions. They didn't want a failed "
    "database update to crash the entire request. But by absorbing the failure, they "
    "created something worse: a system that lies about its own state."
)

doc.add_heading("Three Silent Failures I Found in Production", level=1)

doc.add_heading("1. The Reserved Word That Ate My Updates", level=2)
doc.add_paragraph(
    "Most managed databases have hundreds of reserved keywords. DynamoDB alone has 573. "
    "When you use one as a field name in an update expression — 'status', 'name', 'sources', "
    "'count' — the operation fails. But if it's inside a try/except, the failure vanishes."
)
doc.add_paragraph(
    "In our case, a field called 'sources' was a DynamoDB reserved word. Every update to that "
    "field silently failed. The API returned 200. The user saw the old data. It took three days "
    "to find because the error was logged as a WARNING — and nobody had a CloudWatch alarm on warnings."
)

doc.add_heading("2. The Float That Wasn't a Decimal", level=2)
doc.add_paragraph(
    "When you read JSON (from an API, from S3, from anywhere), numbers come back as floats. "
    "When you write to DynamoDB using the boto3 resource layer, it rejects floats — it wants "
    "Decimal objects. This type mismatch throws a TypeError, which gets caught by your "
    "generic exception handler, and your write never happens."
)
doc.add_paragraph(
    "The insidious part: this only fails on records that HAVE decimal numbers. If your test "
    "data uses whole numbers (integers), the tests pass. The bug only surfaces in production "
    "with real data that contains relevance scores like 0.85 or confidence values like 0.7."
)

doc.add_heading("3. The Exception Handler That Hid Everything", level=2)
doc.add_paragraph(
    "This is the enabler of all silent errors. The pattern looks innocent:"
)
p = doc.add_paragraph()
r = p.add_run("try:\n    db.update(key, data)\nexcept Exception as e:\n    logger.warning(f'update failed: {e}')")
r.font.name = 'Consolas'
r.font.size = Pt(10)
doc.add_paragraph()
doc.add_paragraph(
    "The developer's intent: 'if the update fails, don't crash — log it and move on.' "
    "The reality: every TypeError, every reserved word error, every permission denial is "
    "caught, whispered into a log file nobody reads, and forgotten. The system lies to "
    "every downstream consumer."
)

doc.add_heading("5 Practices That Eliminate Silent Failures", level=1)

doc.add_heading("1. Always Escape Field Names", level=2)
doc.add_paragraph(
    "Never use raw field names in database expressions. Period. Even if you believe "
    "the name isn't reserved today, future SDK updates may add new reserved words. "
    "Treat parameterized field references as a universal default, not an exception. "
    "The extra 2 lines of code save you 2 days of debugging."
)

doc.add_heading("2. Read After Write for Critical Operations", level=2)
doc.add_paragraph(
    "For state transitions that users depend on (status changes, permission grants, "
    "financial updates), add a verification read immediately after the write. "
    "If what you just wrote doesn't match what you read back, raise an error loudly. "
    "This catches silent failures at the moment they happen — not days later "
    "when a user reports wrong data."
)

doc.add_heading("3. Use Specific Exception Types", level=2)
doc.add_paragraph(
    "Replace every 'except Exception' with specific types: ClientError for database issues, "
    "TypeError for serialization problems, ValidationError for schema violations. "
    "Let unexpected exceptions propagate and crash. A crash you see immediately is "
    "infinitely better than a silent corruption you discover next week."
)

doc.add_heading("4. Log Observable State Transitions", level=2)
doc.add_paragraph(
    "Don't log 'update successful.' Log the measurable state change: "
    "'sources: 14 → 11' or 'status: PENDING → APPROVED.' If your logs show "
    "'14 → 14' (no change), you immediately know the write failed silently. "
    "Numbers don't lie. Generic success messages do."
)

doc.add_heading("5. Test Real Writes Locally Before Deploying", level=2)
doc.add_paragraph(
    "Before deploying any code that writes to a managed database, run the exact operation "
    "locally against the real table with real data. Not mocked. Not simulated. The actual "
    "SDK call with actual data shapes that exist in production. Most silent failures — "
    "reserved words, type mismatches, missing fields — surface instantly in a 5-second "
    "local test but hide for weeks behind generic error handlers in production."
)

doc.add_heading("The Core Principle", level=1)
doc.add_paragraph(
    "In serverless architectures, the most dangerous bug is not the one that crashes "
    "your system — it's the one that doesn't."
)
doc.add_paragraph(
    "Silent errors erode data integrity invisibly. They accumulate. They compound. "
    "By the time someone notices, the damage is spread across hundreds of records, "
    "multiple downstream services, and weeks of user interactions built on corrupted state."
)
doc.add_paragraph()
p = doc.add_paragraph()
p.add_run(
    "Build systems that fail loudly or succeed verifiably. There is no safe middle ground."
).bold = True
doc.add_paragraph()

# Closing
doc.add_heading("TL;DR", level=1)
doc.add_paragraph("• Reserved words in database expressions → always escape field names", style='List Bullet')
doc.add_paragraph("• Type mismatches (float vs Decimal) → convert explicitly before writes", style='List Bullet')
doc.add_paragraph("• Broad exception handlers → use specific types, let unknowns crash", style='List Bullet')
doc.add_paragraph("• No verification → read-after-write for critical operations", style='List Bullet')
doc.add_paragraph("• No local testing → run real writes against real tables before deploy", style='List Bullet')
doc.add_paragraph()
p = doc.add_paragraph()
p.add_run("The cost of a loud failure: a 5-minute fix.\n"
          "The cost of a silent failure: days of debugging, lost user trust, and data you can never fully recover.").italic = True

# Tags
doc.add_paragraph()
doc.add_paragraph("#Serverless #AWS #DynamoDB #Lambda #CloudArchitecture #DevOps #SilentErrors #BestPractices")

# Save
article_path = os.path.join(OUT_DIR, "Medium_Article_Silent_Errors_Serverless.docx")
doc.save(article_path)
print(f"Article saved: {article_path}")
print(f"\nBoth files in: {OUT_DIR}")
