"""
Generate 4 Job Description Word documents for the PMI Agentic AI platform
run-and-support team:
  1. Solution Architect (Agentic AI Platform)
  2. Agentic AI Developer
  3. UI Developer (Front-End)
  4. Cloud Architect (AWS Infrastructure)

Each JD is grounded in the actual tech stack of the repo (AWS Lambda, Step Functions,
Bedrock models/Knowledge Base/Prompt Management, LiteLLM gateway, Tavily/Gemini,
OpenSearch Serverless, DynamoDB, S3) and includes "Ask Spidy" — the new conversational
workbench chatbot to be built on Amazon Bedrock AgentCore Runtime.

Output: docs/job_descriptions/*.docx
"""
import os
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "docs", "job_descriptions")
os.makedirs(OUT_DIR, exist_ok=True)

PMI_BLUE = RGBColor(0x1F, 0x3A, 0x5F)
GREY = RGBColor(0x55, 0x55, 0x55)


def add_title_block(doc, title, subtitle):
    h = doc.add_heading(title, level=0)
    for run in h.runs:
        run.font.color.rgb = PMI_BLUE
    p = doc.add_paragraph(subtitle)
    p.runs[0].font.size = Pt(12)
    p.runs[0].font.color.rgb = GREY
    p.runs[0].italic = True
    doc.add_paragraph()


def add_meta_table(doc, rows):
    table = doc.add_table(rows=len(rows), cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.style = 'Light Grid Accent 1'
    for i, (label, value) in enumerate(rows):
        c0, c1 = table.rows[i].cells
        c0.text = label
        c0.paragraphs[0].runs[0].bold = True
        c1.text = value
    doc.add_paragraph()


def add_section(doc, heading):
    h = doc.add_heading(heading, level=1)
    for run in h.runs:
        run.font.color.rgb = PMI_BLUE


def add_bullets(doc, items):
    for item in items:
        doc.add_paragraph(item, style='List Bullet')


def add_para(doc, text):
    doc.add_paragraph(text)


def build_jd(filename, title, subtitle, meta, summary, responsibilities,
             ask_spidy_responsibilities, required_skills, ask_spidy_skills,
             nice_to_have, tools):
    doc = Document()

    # Base font
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(11)

    add_title_block(doc, title, subtitle)
    add_meta_table(doc, meta)

    add_section(doc, "Role Summary")
    add_para(doc, summary)

    add_section(doc, "Key Responsibilities")
    add_bullets(doc, responsibilities)

    add_section(doc, "Ask Spidy (AgentCore Runtime Chatbot) — Responsibilities")
    add_para(doc, "Ask Spidy is a new conversational workbench being built on Amazon Bedrock "
                  "AgentCore Runtime, allowing users to interact with the platform's researcher "
                  "and drafter capabilities through a chat interface rather than only the form-based "
                  "submission flow. This role contributes to it as follows:")
    add_bullets(doc, ask_spidy_responsibilities)

    add_section(doc, "Required Skills & Experience")
    add_bullets(doc, required_skills)

    add_section(doc, "Ask Spidy / AgentCore Runtime Skills")
    add_bullets(doc, ask_spidy_skills)

    add_section(doc, "Nice to Have")
    add_bullets(doc, nice_to_have)

    add_section(doc, "Core Tools & Technologies")
    add_para(doc, tools)

    path = os.path.join(OUT_DIR, filename)
    doc.save(path)
    print(f"Saved: {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# 1. SOLUTION ARCHITECT
# ═══════════════════════════════════════════════════════════════════════════════
build_jd(
    filename="JD_Solution_Architect_Agentic_AI_Platform.docx",
    title="Solution Architect — Agentic AI Platform",
    subtitle="PMI Agentic AI Document-Generation Platform | Run & Support",
    meta=[
        ("Team", "Corporate Affairs — Agentic AI Platform"),
        ("Type", "Full-time"),
        ("Level", "Senior / Lead"),
        ("Location", "Remote / Hybrid"),
    ],
    summary=(
        "The Solution Architect owns the end-to-end technical architecture of the PMI Agentic AI "
        "document-generation platform — the split Step Functions pipeline (7 researcher stages, "
        "3 drafter stages) that researches and drafts regulatory, advocacy, and communications "
        "documents across multiple categories and jurisdictions. This role is accountable for "
        "architectural decisions, technical governance, and extending the platform to a new "
        "conversational surface (Ask Spidy) while keeping the existing pipeline stable, secure, "
        "and cost-efficient during active demo and production use."
    ),
    responsibilities=[
        "Own the architecture of the split researcher (planner, file processor, KB search, web "
        "search, user sources, curated links, synthesis) and drafter (plan, generate, assemble) "
        "Step Functions pipelines.",
        "Define and enforce standards for prompt management: migrating category prompts, "
        "jurisdiction ground-truth files, and output templates into Amazon Bedrock Prompt "
        "Management with fail-open fallback to in-code prompts.",
        "Set model-tiering strategy across the pipeline (Opus for high-stakes reasoning, Sonnet "
        "as the workhorse, Haiku for cheap extraction) and own the LiteLLM gateway integration.",
        "Design the Retrieval-Augmented Generation (RAG) architecture: Bedrock Knowledge Base, "
        "OpenSearch Serverless, embeddings strategy (Titan v2, evaluating Cohere multilingual), "
        "web search (Tavily via private gateway, Gemini grounding), and reranking (Cohere Rerank).",
        "Lead architectural reviews for major refactors (e.g. splitting the researcher monolith "
        "into independent per-stage modules) ensuring zero regression to output quality.",
        "Define non-functional requirements: latency budgets, cost ceilings, guardrail behavior, "
        "fail-open/fail-safe patterns, and data residency for demo1 (legacy monolith) vs demo2 "
        "(active split architecture).",
        "Own security architecture in partnership with the Cloud Architect: least-privilege IAM, "
        "VPC/no-egress subnet design, Bedrock guardrails, and SCP navigation.",
        "Produce and maintain architecture decision records (ADRs), sequence diagrams, and the "
        "technical cheat sheet used for onboarding and stakeholder briefings.",
        "Mentor the Agentic AI Developer(s) and review pull requests for architectural consistency.",
    ],
    ask_spidy_responsibilities=[
        "Define the target architecture for Ask Spidy on Amazon Bedrock AgentCore Runtime, "
        "including how it invokes existing researcher/drafter capabilities as callable tools/actions "
        "rather than duplicating pipeline logic.",
        "Decide the session, memory, and identity model for AgentCore Runtime agents (e.g. per-user "
        "session continuity, tool-call auditing, and how draft-only requests are routed to the "
        "existing drafter stages).",
        "Establish the security boundary between the conversational surface and the underlying "
        "Step Functions pipeline (authentication, authorization, rate limiting, guardrail parity).",
        "Decide whether AgentCore orchestration should sit in front of, alongside, or partially "
        "replace parts of the current Step Functions state machine, and document the migration path.",
    ],
    required_skills=[
        "10+ years in solution/software architecture, including 3+ years designing production "
        "AI/ML or LLM-based systems.",
        "Deep hands-on knowledge of AWS: Lambda, Step Functions, API Gateway, DynamoDB, S3, IAM, "
        "VPC, CloudWatch.",
        "Practical experience with Amazon Bedrock: foundation models, Knowledge Base, Prompt "
        "Management, Guardrails.",
        "Experience designing agentic/multi-stage AI systems: orchestration, tool use, RAG, "
        "prompt engineering at scale.",
        "Strong Python fluency for reviewing and guiding implementation, not just diagramming.",
        "Experience with LLM gateways (e.g. LiteLLM), vector search, embeddings, and reranking.",
        "Comfort operating in a regulated, compliance-sensitive content domain.",
        "Excellent stakeholder communication — this platform runs under active demo and business "
        "pressure with frequent leadership visibility.",
    ],
    ask_spidy_skills=[
        "Working knowledge of Amazon Bedrock AgentCore Runtime concepts: agents, actions/tools, "
        "sessions, memory, and the AgentCore Gateway/Identity components.",
        "Ability to design tool/action schemas that wrap existing Lambda-based capabilities "
        "(researcher, drafter) for invocation by an AgentCore agent.",
        "Understanding of conversational AI architecture patterns: turn management, streaming "
        "responses, grounding citations in a chat context.",
    ],
    nice_to_have=[
        "Prior experience migrating a monolithic Lambda into modular, independently deployable "
        "stages.",
        "Experience with AWS Step Functions Parallel/Choice state design at scale.",
        "Familiarity with tobacco/pharma/financial regulatory content domains.",
        "AWS Solutions Architect Professional certification.",
    ],
    tools=(
        "AWS Lambda, Step Functions, Bedrock (Claude Opus/Sonnet/Haiku, Knowledge Base, Prompt "
        "Management, AgentCore Runtime), LiteLLM, OpenSearch Serverless, DynamoDB, S3, IAM, VPC, "
        "CloudWatch, Tavily, Gemini, Cohere Rerank, Python, Bitbucket."
    ),
)

# ═══════════════════════════════════════════════════════════════════════════════
# 2. AGENTIC AI DEVELOPER
# ═══════════════════════════════════════════════════════════════════════════════
build_jd(
    filename="JD_Agentic_AI_Developer.docx",
    title="Agentic AI Developer",
    subtitle="PMI Agentic AI Document-Generation Platform | Run & Support",
    meta=[
        ("Team", "Corporate Affairs — Agentic AI Platform"),
        ("Type", "Full-time"),
        ("Level", "Mid / Senior"),
        ("Location", "Remote / Hybrid"),
    ],
    summary=(
        "The Agentic AI Developer builds and maintains the Python/AWS Lambda codebase that powers "
        "the researcher and drafter pipelines — from query planning and multi-source retrieval "
        "through synthesis and document assembly. This is a hands-on implementation role: writing "
        "and refactoring agent code, tuning prompts, fixing production issues surfaced via "
        "CloudWatch, and extending the platform with new capabilities such as file-upload "
        "intelligence and the Ask Spidy chatbot."
    ),
    responsibilities=[
        "Develop and maintain the 7 researcher stage Lambdas (planner, file processor, KB search, "
        "web search, user sources, curated links, synthesis) and 3 drafter stage Lambdas "
        "(plan, generate, assemble).",
        "Implement and refine prompts across categories (Official PMI Submission, Third Party "
        "Submission, White Papers, Internal Communications, Media Releases, Narrative Builder) "
        "and jurisdictions, integrating with Amazon Bedrock Prompt Management.",
        "Build and tune retrieval logic: Bedrock Knowledge Base queries, Tavily web search "
        "(multi-query, reranked), Gemini URL/content extraction, and Cohere Rerank scoring.",
        "Own the relevance-driven retrieval loop, anti-duplication logic, citation integrity, and "
        "topic-relevance filtering that keep generated documents accurate and non-repetitive.",
        "Refactor shared logic out of monolithic handler files into independent, testable per-stage "
        "modules, with a shared common-utilities module for config and LiteLLM calling.",
        "Implement fail-open patterns throughout: prompt resolution fallback, guardrail-aware LLM "
        "calls, and graceful degradation when a source or model call fails.",
        "Debug production issues end-to-end using CloudWatch Logs Insights and Step Functions "
        "execution history; fix missing imports, cross-module dependencies, and logic errors "
        "introduced during refactors.",
        "Write local test scripts and lightweight test suites to validate stage behavior before "
        "deployment; run one-request-per-category smoke tests after every change.",
        "Collaborate with the Architect on design and the UI Developer on request/response "
        "contracts.",
    ],
    ask_spidy_responsibilities=[
        "Implement Ask Spidy's action/tool handlers on Amazon Bedrock AgentCore Runtime, wrapping "
        "existing drafter and researcher stage functions so they can be invoked conversationally.",
        "Build the request-shaping logic that turns a chat turn (e.g. 'draft a white paper on X for "
        "Thailand') into a valid pipeline request payload, reusing existing validation logic.",
        "Implement session/context handling so multi-turn conversations can refine a draft request "
        "before triggering the underlying Step Functions execution.",
        "Extend prompt-management and jurisdiction/template loading so Ask Spidy's tool calls "
        "resolve prompts the same way the existing pipeline does (single source of truth).",
    ],
    required_skills=[
        "5+ years professional Python development.",
        "2+ years building production systems with LLMs (Bedrock, OpenAI, Anthropic, or similar).",
        "Hands-on AWS Lambda and Step Functions experience, including boto3.",
        "Practical prompt engineering experience: system/user prompt design, guardrail-aware "
        "prompting, structured JSON output parsing.",
        "Experience with RAG pipelines: vector search, embeddings, reranking.",
        "Strong debugging skills across distributed serverless systems (multi-lambda, "
        "async/parallel state machines).",
        "Comfortable reading and refactoring large, previously-monolithic codebases without "
        "introducing regressions.",
        "Git/Bitbucket workflow discipline; comfortable working across dev/demo environments with "
        "strict no-regression requirements.",
    ],
    ask_spidy_skills=[
        "Familiarity with Amazon Bedrock AgentCore Runtime SDK/APIs, or strong general experience "
        "with agent/tool-calling frameworks (Bedrock Agents, LangChain/LangGraph, OpenAI function "
        "calling) that transfers directly.",
        "Experience designing clean tool/action interfaces (typed inputs/outputs) around existing "
        "backend functions.",
        "Understanding of streaming response patterns for conversational UIs.",
    ],
    nice_to_have=[
        "Experience with python-docx or similar libraries for programmatic document generation.",
        "Familiarity with OpenSearch Serverless and Titan/Cohere embedding models.",
        "Experience with multi-threading/concurrency in Python (ThreadPoolExecutor) for latency "
        "optimization.",
        "Prior experience in regulated/compliance content generation.",
    ],
    tools=(
        "Python, AWS Lambda, Step Functions, Bedrock (Claude models, Knowledge Base, Prompt "
        "Management, AgentCore Runtime), LiteLLM, Tavily, Gemini, Cohere Rerank, boto3, "
        "python-docx, DynamoDB, S3, CloudWatch, Bitbucket."
    ),
)

# ═══════════════════════════════════════════════════════════════════════════════
# 3. UI DEVELOPER
# ═══════════════════════════════════════════════════════════════════════════════
build_jd(
    filename="JD_UI_Developer.docx",
    title="UI Developer (Front-End)",
    subtitle="PMI Agentic AI Document-Generation Platform | Run & Support",
    meta=[
        ("Team", "Corporate Affairs — Agentic AI Platform"),
        ("Type", "Full-time"),
        ("Level", "Mid / Senior"),
        ("Location", "Remote / Hybrid"),
    ],
    summary=(
        "The UI Developer owns the front-end experience for the document-generation platform: the "
        "request-submission form (category/jurisdiction/tone selection, file upload), the "
        "request-tracking dashboard, and — newly — the Ask Spidy conversational chat interface. "
        "This role bridges user experience and backend API/streaming integration, ensuring the "
        "platform feels responsive and trustworthy for PMI Corporate Affairs users."
    ),
    responsibilities=[
        "Build and maintain the request-submission UI: content-type selection (6 categories), "
        "jurisdiction, tone, target audience, file upload, and submission flow.",
        "Build and maintain the request-tracking dashboard: latest-requests table, status, "
        "descending-order display, and filtering.",
        "Integrate with backend REST APIs (API Gateway/Lambda) for request creation, status "
        "polling, and document retrieval.",
        "Implement robust loading, error, and retry states for long-running document-generation "
        "requests (research + draft can take 60–90+ seconds).",
        "Ensure responsive, accessible UI (WCAG-aware) across desktop and common corporate browser "
        "environments.",
        "Collaborate with the Agentic AI Developer and Architect on API/payload contracts as the "
        "pipeline evolves (e.g. new fields like tone_requirements, uploaded file summaries).",
        "Support internal authentication/session handling for PMI users.",
    ],
    ask_spidy_responsibilities=[
        "Design and build the Ask Spidy chat interface: message thread, streaming response "
        "rendering, tool-call/action visibility (e.g. 'researching...', 'drafting section 3...'), "
        "and citation display.",
        "Integrate with the Amazon Bedrock AgentCore Runtime streaming endpoint (SSE/WebSocket) for "
        "real-time conversational responses.",
        "Build session/history UI so users can resume or reference prior chat-driven draft "
        "requests.",
        "Design the hand-off UX between chat-driven requests and the existing form-based submission "
        "flow, so both surfaces feel like one coherent product.",
        "Implement clear UI states for guardrail blocks, fallback behavior, and long-running "
        "tool calls initiated from chat (e.g. a full draft generation triggered mid-conversation).",
    ],
    required_skills=[
        "4+ years front-end development experience (React or Next.js preferred).",
        "Strong TypeScript proficiency.",
        "Experience integrating REST APIs and handling asynchronous/long-running backend processes.",
        "Experience with state management (React Query, Redux, Zustand, or similar).",
        "Familiarity with accessibility standards and responsive design practices.",
        "Comfortable working closely with backend/AI engineers to shape API contracts, not just "
        "consume fixed specs.",
    ],
    ask_spidy_skills=[
        "Direct experience building chat/conversational UI (streaming text rendering, typing "
        "indicators, message threading).",
        "Familiarity with SSE or WebSocket integration for real-time AI response streaming.",
        "Experience rendering structured AI output (citations, tool-call status, partial results) "
        "in a chat context.",
    ],
    nice_to_have=[
        "Experience with AWS-hosted front ends (Amplify, S3 + CloudFront).",
        "Prior experience building or integrating with an internal enterprise chatbot/copilot.",
        "Familiarity with design systems and component libraries (MUI, Chakra, shadcn/ui, etc.).",
    ],
    tools=(
        "React/Next.js, TypeScript, REST APIs, SSE/WebSocket streaming, API Gateway, S3/CloudFront, "
        "Git/Bitbucket."
    ),
)

# ═══════════════════════════════════════════════════════════════════════════════
# 4. CLOUD ARCHITECT
# ═══════════════════════════════════════════════════════════════════════════════
build_jd(
    filename="JD_Cloud_Architect_AWS_Infrastructure.docx",
    title="Cloud Architect — AWS Infrastructure",
    subtitle="PMI Agentic AI Document-Generation Platform | Run & Support",
    meta=[
        ("Team", "Corporate Affairs — Agentic AI Platform"),
        ("Type", "Full-time"),
        ("Level", "Senior"),
        ("Location", "Remote / Hybrid"),
    ],
    summary=(
        "The Cloud Architect owns the AWS infrastructure underpinning both the legacy demo1 "
        "monolith and the active demo2 split-pipeline deployment, plus the new Amazon Bedrock "
        "AgentCore Runtime environment for Ask Spidy. This role is accountable for secure "
        "networking, IAM governance, deployment automation, observability, and cost control across "
        "a serverless, LLM-heavy architecture running inside restricted (no-egress) VPC subnets."
    ),
    responsibilities=[
        "Own and evolve the AWS infrastructure for demo1 (untouched legacy monolith) and demo2 "
        "(active split researcher/drafter Lambdas orchestrated by Step Functions).",
        "Design and maintain VPC networking: subnets, security groups, and VPC endpoints ensuring "
        "Lambda functions in no-egress subnets can reach Bedrock, Bedrock Prompt Management, "
        "Bedrock Knowledge Base, and (going forward) AgentCore Runtime.",
        "Manage IAM roles and policies across Lambda execution roles, Step Functions state machine "
        "roles, and Bedrock resource policies — least privilege, reviewed and auditable.",
        "Own deployment automation and scripts (e.g. Python-based deployers that inherit "
        "role/env/VPC config from source Lambdas) and evolve them toward formal IaC "
        "(CloudFormation/CDK/Terraform) where it reduces operational risk.",
        "Build and maintain observability: CloudWatch Logs Insights queries, dashboards, alarms "
        "for Step Functions failures, Lambda errors, and Bedrock throttling/guardrail blocks.",
        "Monitor and optimize cost across Lambda invocations, Bedrock model usage (Opus/Sonnet/"
        "Haiku tiering), and OpenSearch Serverless.",
        "Own the Bedrock Knowledge Base infrastructure: OpenSearch Serverless collection "
        "configuration, embeddings model setup, and sync/ingestion pipeline health.",
        "Navigate and document AWS Organizations SCP constraints (e.g. current restrictions on "
        "direct Bedrock InvokeModel) and identify remediation paths (exceptions, gateway routing, "
        "VPC endpoints) for new capabilities.",
        "Run security reviews for every new AWS resource introduced (new Lambdas, new IAM policies, "
        "new endpoints), flagging risk before production rollout.",
    ],
    ask_spidy_responsibilities=[
        "Provision and secure the Amazon Bedrock AgentCore Runtime environment: runtime, gateway, "
        "and identity components required to host Ask Spidy.",
        "Design network connectivity so AgentCore Runtime can invoke existing researcher/drafter "
        "Lambdas (or Step Functions executions) securely, respecting the same no-egress VPC "
        "constraints as the rest of the platform.",
        "Define IAM roles/policies scoping exactly what AgentCore agents can invoke (least "
        "privilege tool access), separate from the broader pipeline's execution roles.",
        "Establish monitoring and cost tracking for AgentCore Runtime sessions/invocations "
        "alongside existing Lambda/Bedrock cost dashboards.",
        "Validate and document whether AgentCore Runtime is reachable from existing account/SCP "
        "configuration, and drive any required exception requests.",
    ],
    required_skills=[
        "7+ years AWS infrastructure/cloud architecture experience.",
        "Deep expertise: Lambda, Step Functions, VPC networking (subnets, security groups, VPC "
        "endpoints), IAM, S3, DynamoDB, CloudWatch.",
        "Hands-on experience with Amazon Bedrock: model access, Knowledge Base, Prompt Management, "
        "Guardrails.",
        "Experience with Infrastructure-as-Code (CDK, CloudFormation, or Terraform).",
        "Experience with CI/CD pipelines (Bitbucket Pipelines, CodePipeline, GitHub Actions, or "
        "similar).",
        "Strong understanding of enterprise security constructs: AWS Organizations SCPs, KMS, "
        "least-privilege IAM design.",
        "Proven ability to troubleshoot connectivity issues in restricted/no-egress VPC "
        "environments.",
        "AWS Solutions Architect Professional or Security Specialty certification preferred.",
    ],
    ask_spidy_skills=[
        "Familiarity with Amazon Bedrock AgentCore Runtime infrastructure components (runtime, "
        "gateway, identity) and their IAM/networking requirements.",
        "Ability to assess and document SCP/connectivity implications for a new managed AWS AI "
        "service before it is adopted.",
    ],
    nice_to_have=[
        "Experience with OpenSearch Serverless capacity/cost tuning.",
        "Experience operating dual-environment (legacy vs active) infrastructure with strict "
        "no-regression requirements on the legacy side.",
        "Familiarity with regulated-industry cloud security reviews.",
    ],
    tools=(
        "AWS Lambda, Step Functions, VPC, IAM, S3, DynamoDB, CloudWatch, Bedrock (models, Knowledge "
        "Base, Prompt Management, AgentCore Runtime), OpenSearch Serverless, CDK/CloudFormation/"
        "Terraform, Bitbucket Pipelines / CI-CD, AWS CLI."
    ),
)

print("\nAll 4 JDs generated successfully.")
