"""Generate Ask Spidy Workbench architecture diagram — showing reuse of existing pipeline."""
from PIL import Image, ImageDraw, ImageFont
import os

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
os.makedirs(OUT_DIR, exist_ok=True)

WIDTH, HEIGHT = 1920, 1080
img = Image.new('RGB', (WIDTH, HEIGHT), '#FFFFFF')
draw = ImageDraw.Draw(img)

# Colors
NAVY = '#1B2A4A'
BLUE = '#2563EB'
LIGHT_BLUE = '#DBEAFE'
DARK_GRAY = '#374151'
MID_GRAY = '#6B7280'
LIGHT_GRAY = '#F3F4F6'
BORDER_GRAY = '#D1D5DB'
GREEN = '#059669'
GREEN_LIGHT = '#D1FAE5'
PURPLE = '#7C3AED'
PURPLE_LIGHT = '#EDE9FE'
ORANGE = '#EA580C'
ORANGE_LIGHT = '#FFF7ED'
AMBER = '#D97706'
TEAL = '#0D9488'
TEAL_LIGHT = '#CCFBF1'
WHITE = '#FFFFFF'

# Fonts
try:
    font_title = ImageFont.truetype("calibrib.ttf", 40)
    font_subtitle = ImageFont.truetype("calibri.ttf", 22)
    font_heading = ImageFont.truetype("calibrib.ttf", 24)
    font_body = ImageFont.truetype("calibri.ttf", 20)
    font_box = ImageFont.truetype("calibrib.ttf", 19)
    font_small = ImageFont.truetype("calibri.ttf", 16)
    font_tag = ImageFont.truetype("calibrib.ttf", 15)
except:
    font_title = ImageFont.load_default()
    font_subtitle = font_title
    font_heading = font_title
    font_body = font_title
    font_box = font_title
    font_small = font_title
    font_tag = font_title


def rounded_rect(x, y, w, h, fill, outline=None, radius=10, width=2):
    draw.rounded_rectangle([x, y, x+w, y+h], radius=radius, fill=fill, outline=outline or fill, width=width)


def draw_box(x, y, w, h, fill, outline, text, font=font_box, text_color=WHITE, subtitle=None):
    rounded_rect(x, y, w, h, fill, outline)
    if subtitle:
        draw.text((x + 15, y + 12), text, fill=text_color, font=font)
        draw.text((x + 15, y + 38), subtitle, fill=text_color if text_color == WHITE else MID_GRAY, font=font_small)
    else:
        bbox = draw.textbbox((0, 0), text, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        draw.text((x + (w - tw) // 2, y + (h - th) // 2), text, fill=text_color, font=font)


def arrow_right(x1, y, x2, color=MID_GRAY, width=2):
    draw.line([(x1, y), (x2, y)], fill=color, width=width)
    draw.polygon([(x2, y), (x2-10, y-6), (x2-10, y+6)], fill=color)


def arrow_down(x, y1, y2, color=MID_GRAY, width=2):
    draw.line([(x, y1), (x, y2)], fill=color, width=width)
    draw.polygon([(x, y2), (x-6, y2-10), (x+6, y2-10)], fill=color)


def arrow_left(x1, y, x2, color=MID_GRAY, width=2):
    draw.line([(x1, y), (x2, y)], fill=color, width=width)
    draw.polygon([(x2, y), (x2+10, y-6), (x2+10, y+6)], fill=color)


# ═══════════════════════════════════════════════════════════════════════════════
# HEADER
# ═══════════════════════════════════════════════════════════════════════════════
rounded_rect(0, 0, WIDTH, 90, LIGHT_GRAY, LIGHT_GRAY, radius=0)
draw.text((50, 22), "Ask Spidy — Workbench Architecture", fill=NAVY, font=font_title)
draw.text((50, 65), "Conversational AI chatbot reusing existing Research + Draft pipeline as callable tools", fill=MID_GRAY, font=font_subtitle)

# ═══════════════════════════════════════════════════════════════════════════════
# LEFT COLUMN: Frontend + Chat Infrastructure (NEW)
# ═══════════════════════════════════════════════════════════════════════════════
col1_x = 40
col1_w = 380

# Section label
draw.text((col1_x, 105), "NEW — Chat Layer", fill=ORANGE, font=font_tag)
rounded_rect(col1_x, 125, col1_w, 920, ORANGE_LIGHT, ORANGE, width=1)

# Chat UI
draw_box(col1_x + 20, 145, col1_w - 40, 100, WHITE, BORDER_GRAY,
         "Chat UI (React)", font=font_box, text_color=NAVY,
         subtitle="Multi-chat, history, streaming,\nuser isolation, WSS connection")

# API Gateway
draw_box(col1_x + 20, 270, col1_w - 40, 70, AMBER, AMBER,
         "API Gateway + WebSocket", subtitle="Auth, routing, WSS upgrade")

# Conversation Service
draw_box(col1_x + 20, 365, col1_w - 40, 90, PURPLE, PURPLE,
         "Conversation Service", subtitle="POST/GET/DELETE /conversations\nCRUD + user isolation")

# Message Service
draw_box(col1_x + 20, 480, col1_w - 40, 90, PURPLE, PURPLE,
         "Message Service", subtitle="POST/GET /messages\nPush, pull, history, streaming")

# DynamoDB tables
draw_box(col1_x + 20, 600, col1_w - 40, 75, LIGHT_GRAY, BORDER_GRAY,
         "Conversations Table", font=font_box, text_color=NAVY,
         subtitle="PK: UserId | SK: ConversationId")

draw_box(col1_x + 20, 695, col1_w - 40, 75, LIGHT_GRAY, BORDER_GRAY,
         "Messages Table", font=font_box, text_color=NAVY,
         subtitle="PK: ConversationId | SK: Timestamp")

# Arrows within column
arrow_down(col1_x + col1_w // 2, 245, 270, DARK_GRAY)
arrow_down(col1_x + col1_w // 2, 340, 365, DARK_GRAY)
arrow_down(col1_x + col1_w // 2, 455, 480, DARK_GRAY)
arrow_down(col1_x + col1_w // 2 - 60, 570, 600, DARK_GRAY)
arrow_down(col1_x + col1_w // 2 + 60, 570, 695, DARK_GRAY)

# ═══════════════════════════════════════════════════════════════════════════════
# MIDDLE COLUMN: AI Agent Orchestrator (NEW — connects chat to existing tools)
# ═══════════════════════════════════════════════════════════════════════════════
col2_x = 460
col2_w = 440

draw.text((col2_x, 105), "NEW — Agent Orchestrator", fill=PURPLE, font=font_tag)
rounded_rect(col2_x, 125, col2_w, 470, PURPLE_LIGHT, PURPLE, width=1)

# Agent Runtime
draw_box(col2_x + 20, 145, col2_w - 40, 100, NAVY, NAVY,
         "Agent Runtime (Sonnet)", subtitle="Tool-calling LLM orchestrator\nSession memory, multi-turn context,\nstreaming responses")

# Tool Router
draw_box(col2_x + 20, 270, col2_w - 40, 70, BLUE, BLUE,
         "Tool Router", subtitle="Selects tools based on user intent")

# Available Tools
draw.text((col2_x + 20, 360), "AVAILABLE TOOLS:", fill=NAVY, font=font_tag)

tool_y = 385
tool_h = 50
tools = [
    ("kb_search", "Search PMI Knowledge Base"),
    ("web_search", "Tavily + Gemini web research"),
    ("quick_draft", "Single-section LLM draft"),
    ("full_pipeline", "Trigger Step Functions"),
    ("jurisdiction", "Load regulatory context"),
]
for i, (name, desc) in enumerate(tools):
    y = tool_y + i * (tool_h + 5)
    rounded_rect(col2_x + 20, y, col2_w - 40, tool_h, WHITE, BLUE, width=1)
    draw.text((col2_x + 35, y + 5), name, fill=BLUE, font=font_box)
    draw.text((col2_x + 35, y + 28), desc, fill=MID_GRAY, font=font_small)

# Arrows
arrow_down(col2_x + col2_w // 2, 245, 270, NAVY)
arrow_down(col2_x + col2_w // 2, 340, 360, NAVY)

# Arrow from Message Service to Agent
arrow_right(col1_x + col1_w - 20, 520, col2_x + 20, PURPLE, 3)
draw.text((col1_x + col1_w - 5, 500), "User message", fill=PURPLE, font=font_small)

# Arrow from Agent back to Message Service (response)
arrow_left(col2_x + 20, 550, col1_x + col1_w - 20, GREEN, 3)
draw.text((col1_x + col1_w - 5, 555), "AI response (streamed)", fill=GREEN, font=font_small)

# ═══════════════════════════════════════════════════════════════════════════════
# RIGHT COLUMN: Existing Pipeline (REUSED)
# ═══════════════════════════════════════════════════════════════════════════════
col3_x = 940
col3_w = 940

draw.text((col3_x, 105), "EXISTING — Reused As-Is (zero changes)", fill=GREEN, font=font_tag)
rounded_rect(col3_x, 125, col3_w, 920, GREEN_LIGHT, GREEN, width=1)

# Sub-sections
# KB Search
draw_box(col3_x + 20, 150, 280, 90, BLUE, BLUE,
         "researcher_kb.py", subtitle="Bedrock Knowledge Base\n+ OpenSearch Serverless")

# Web Search
draw_box(col3_x + 320, 150, 280, 90, BLUE, BLUE,
         "researcher_web.py", subtitle="Tavily + Gemini extraction\n+ domain blocklist")

# Jurisdiction
draw_box(col3_x + 620, 150, 280, 90, BLUE, BLUE,
         "drafter_common.py", subtitle="Jurisdiction context loader\n+ template loader")

# Drafter modules
draw_box(col3_x + 20, 270, 280, 90, TEAL, TEAL,
         "drafter_planner.py", subtitle="LLM document planner\n+ structure builder")

draw_box(col3_x + 320, 270, 280, 90, TEAL, TEAL,
         "drafter_generator.py", subtitle="Section-by-section generation\n+ dedup + review")

draw_box(col3_x + 620, 270, 280, 90, TEAL, TEAL,
         "drafter_assembler.py", subtitle="Format .docx + citations\n+ quality metrics")

# Step Functions
draw_box(col3_x + 20, 390, 580, 70, NAVY, NAVY,
         "Step Functions Pipeline (full research + draft)", subtitle="7 researcher stages + 3 drafter stages + HITL loops")

# Shared infra
draw.text((col3_x + 20, 485), "SHARED INFRASTRUCTURE:", fill=NAVY, font=font_tag)

infra_items = [
    ("Bedrock KB", "Vector search"),
    ("LiteLLM Gateway", "Claude Sonnet/Opus/Haiku"),
    ("Prompt Management", "Bedrock prompts + fallback"),
    ("DynamoDB", "Requests + HITL tables"),
    ("S3", "Documents + research data"),
]

for i, (name, desc) in enumerate(infra_items):
    x = col3_x + 20 + i * 185
    rounded_rect(x, 510, 175, 65, WHITE, BORDER_GRAY, width=1)
    draw.text((x + 10, 518), name, fill=NAVY, font=font_box)
    draw.text((x + 10, 543), desc, fill=MID_GRAY, font=font_small)

# Arrows from Tool Router to existing modules
arrow_right(col2_x + col2_w - 20, 200, col3_x + 20, BLUE, 2)
draw.text((col2_x + col2_w + 5, 185), "kb_search", fill=BLUE, font=font_small)

arrow_right(col2_x + col2_w - 20, 240, col3_x + 320, BLUE, 2)
draw.text((col2_x + col2_w + 5, 225), "web_search", fill=BLUE, font=font_small)

arrow_right(col2_x + col2_w - 20, 310, col3_x + 20, TEAL, 2)
draw.text((col2_x + col2_w + 5, 295), "quick_draft", fill=TEAL, font=font_small)

arrow_right(col2_x + col2_w - 20, 420, col3_x + 20, NAVY, 2)
draw.text((col2_x + col2_w + 5, 405), "full_pipeline", fill=NAVY, font=font_small)

# ═══════════════════════════════════════════════════════════════════════════════
# BOTTOM: Key Benefits
# ═══════════════════════════════════════════════════════════════════════════════
footer_y = 830

# Benefits bar
rounded_rect(40, footer_y, WIDTH - 80, 80, NAVY, NAVY, radius=10)
draw.text((70, footer_y + 10), "REUSE BENEFITS", fill=AMBER, font=font_tag)

benefits = [
    "KB Search: 0 lines changed",
    "Web Search: 0 lines changed",
    "Drafter: 0 lines changed",
    "Prompts: same Bedrock registry",
    "HITL: same review flow",
]
for i, b in enumerate(benefits):
    x = 70 + i * 360
    draw.text((x, footer_y + 40), f"✓  {b}", fill=WHITE, font=font_body)

# Legend
legend_y = footer_y + 100
draw.text((50, legend_y), "Legend:", fill=DARK_GRAY, font=font_small)
rounded_rect(120, legend_y - 2, 20, 20, ORANGE_LIGHT, ORANGE, radius=4)
draw.text((150, legend_y), "New (chat infrastructure)", fill=DARK_GRAY, font=font_small)
rounded_rect(370, legend_y - 2, 20, 20, PURPLE_LIGHT, PURPLE, radius=4)
draw.text((400, legend_y), "New (agent orchestrator)", fill=DARK_GRAY, font=font_small)
rounded_rect(630, legend_y - 2, 20, 20, GREEN_LIGHT, GREEN, radius=4)
draw.text((660, legend_y), "Existing (reused as-is, zero changes)", fill=DARK_GRAY, font=font_small)

# Save
output_path = os.path.join(OUT_DIR, "AskSpidy_Workbench_Architecture.jpg")
img.save(output_path, "JPEG", quality=95)
print(f"Saved: {output_path}")
print(f"Resolution: {WIDTH}x{HEIGHT} (16:9 HD)")
