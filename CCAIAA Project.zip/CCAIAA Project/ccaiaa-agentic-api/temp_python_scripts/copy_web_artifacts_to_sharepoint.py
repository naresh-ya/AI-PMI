"""
Copy documents from the `web_artifacts/` prefix into the SharePoint ingestion folder
of the same S3 bucket, so each copied object fires the existing S3 ObjectCreated event
that (a) generates the `<file>.metadata.json` sidecar and (b) triggers the AWS Bedrock
Knowledge Base sync.

Server-side copy (copy_object) is used — no download/upload round-trip.

Default behaviour:
  - Source prefix : web_artifacts/
  - Dest prefix   : sharepoint/pmicloud.sharepoint.com/teams/SAICDIAandCapgeminiTeam-DIA-India/
  - Skips folder placeholders (keys ending in '/').
  - Skips any *.metadata.json in the source (the trigger generates these; copying a stale
    one would suppress/!corrupt metadata generation). Override with --include-metadata.
  - Skips objects that already exist at the destination unless --overwrite is given.

USAGE
  # 1) Preview first (no writes) — strongly recommended:
  python copy_web_artifacts_to_sharepoint.py --dry-run

  # 2) Perform the copy:
  python copy_web_artifacts_to_sharepoint.py

  # Restrict to certain types / overwrite existing / custom prefixes:
  python copy_web_artifacts_to_sharepoint.py --extensions .pdf .docx
  python copy_web_artifacts_to_sharepoint.py --overwrite
  python copy_web_artifacts_to_sharepoint.py --dest-prefix "sharepoint/.../OtherTeam/"

NOTE: each copied object triggers downstream metadata generation + KB sync. Copying N files
      fires N events. Run --dry-run first to confirm the count and the exact destination keys.
"""
import argparse
import sys
import boto3
from botocore.exceptions import ClientError

BUCKET        = "pmi-agentic-ai-documents-sandbox-603433800649"
REGION        = "eu-west-1"
SOURCE_PREFIX = "web_artifacts/"
DEST_PREFIX   = "sharepoint/pmicloud.sharepoint.com/teams/SAICDIAandCapgeminiTeam-DIA-India/"


def _iter_source_objects(s3, bucket, prefix):
    """Yield every object key under `prefix` (handles pagination)."""
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            yield obj["Key"]


def _dest_key(src_key, source_prefix, dest_prefix):
    """Map a source key to its destination key, preserving any sub-path under the
    source prefix and joining it under the destination prefix."""
    rel = src_key[len(source_prefix):] if src_key.startswith(source_prefix) else src_key
    return dest_prefix.rstrip("/") + "/" + rel.lstrip("/")


def _exists(s3, bucket, key):
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] in ("404", "NoSuchKey", "NotFound"):
            return False
        raise


def _list_existing_keys(s3, bucket, prefix):
    """Pre-list every key under the destination prefix into a set (one paginated scan),
    so existence checks are in-memory instead of one HEAD request per source object."""
    keys = set()
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            keys.add(obj["Key"])
    return keys


def main():
    ap = argparse.ArgumentParser(description="Copy web_artifacts/ documents into the SharePoint ingestion folder.")
    ap.add_argument("--bucket", default=BUCKET)
    ap.add_argument("--region", default=REGION)
    ap.add_argument("--source-prefix", default=SOURCE_PREFIX)
    ap.add_argument("--dest-prefix", default=DEST_PREFIX)
    ap.add_argument("--extensions", nargs="*", default=None,
                    help="Optional whitelist of file extensions to copy (e.g. .pdf .docx .txt). "
                         "Default: copy all non-metadata files.")
    ap.add_argument("--include-metadata", action="store_true",
                    help="Also copy *.metadata.json from the source (default: skip — let the trigger generate them).")
    ap.add_argument("--overwrite", action="store_true",
                    help="Copy even if the destination object already exists (re-fires the event).")
    ap.add_argument("--dry-run", action="store_true",
                    help="List what WOULD be copied without writing anything.")
    args = ap.parse_args()

    exts = tuple(e.lower() if e.startswith(".") else "." + e.lower() for e in args.extensions) if args.extensions else None

    s3 = boto3.client("s3", region_name=args.region)

    print(f"Bucket        : {args.bucket}")
    print(f"Source prefix : {args.source_prefix}")
    print(f"Dest prefix   : {args.dest_prefix}")
    print(f"Mode          : {'DRY-RUN (no writes)' if args.dry_run else 'COPY'}"
          f" | overwrite={args.overwrite} | include_metadata={args.include_metadata}"
          f" | extensions={exts or 'ALL'}")
    print("-" * 80)

    # Pre-list destination keys once (fast in-memory existence checks)
    existing_dest = set() if args.overwrite else _list_existing_keys(s3, args.bucket, args.dest_prefix)

    copied = skipped_exists = skipped_filtered = errors = 0

    for src_key in _iter_source_objects(s3, args.bucket, args.source_prefix):
        # Skip folder placeholders
        if src_key.endswith("/"):
            continue
        lower = src_key.lower()
        # Skip metadata sidecars unless explicitly included
        if not args.include_metadata and lower.endswith(".metadata.json"):
            skipped_filtered += 1
            continue
        # Extension whitelist
        if exts and not lower.endswith(exts):
            skipped_filtered += 1
            continue

        dst_key = _dest_key(src_key, args.source_prefix, args.dest_prefix)

        if not args.overwrite and dst_key in existing_dest:
            print(f"SKIP (exists) : {dst_key}")
            skipped_exists += 1
            continue

        if args.dry_run:
            print(f"WOULD COPY    : {src_key}\n             -> {dst_key}")
            copied += 1
            continue

        try:
            s3.copy_object(
                Bucket=args.bucket,
                Key=dst_key,
                CopySource={"Bucket": args.bucket, "Key": src_key},
                MetadataDirective="COPY",   # preserve content-type / metadata from source
            )
            print(f"COPIED        : {dst_key}")
            copied += 1
        except ClientError as e:
            print(f"ERROR         : {src_key} -> {dst_key} | {e}")
            errors += 1

    print("-" * 80)
    label = "to copy" if args.dry_run else "copied"
    print(f"Summary: {copied} {label} | {skipped_exists} skipped (already exist) "
          f"| {skipped_filtered} filtered out | {errors} errors")
    if args.dry_run:
        print("Dry run only — re-run without --dry-run to perform the copy.")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
