"""
Re-tag ALL KB sources by invoking the pmi-kb-builder Lambda for each file.

Lists all files in the KB S3 bucket (excluding .metadata.json files),
constructs an S3 event payload for each, and invokes the builder Lambda.
Processes sequentially to avoid throttling. Logs progress.

Usage:
    aws sso login
    python temp_python_scripts\retag_all_kb_sources.py

Options:
    --dry-run     List files without invoking Lambda
    --limit N     Process only first N files
    --prefix P    Only process files under this S3 prefix
"""
import argparse
import json
import time
import boto3

REGION = "eu-west-1"
BUCKET = "pmi-agentic-ai-documents-sandbox-603433800649"
LAMBDA_NAME = "pmi-kb-builder"
# Only process files under these prefixes (the KB source folders)
KB_PREFIXES = [
    "sharepoint/",
]
# Skip these extensions/patterns
SKIP_PATTERNS = [".metadata.json", "Exception_docs/", ".DS_Store", "Thumbs.db"]


def list_all_kb_files(s3, prefix_filter=None):
    """List all files in the KB bucket, excluding metadata.json and exceptions."""
    all_files = []
    prefixes = [prefix_filter] if prefix_filter else KB_PREFIXES

    for prefix in prefixes:
        paginator = s3.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=BUCKET, Prefix=prefix):
            for obj in page.get('Contents', []):
                key = obj['Key']
                # Skip metadata files, exception docs, and tiny files
                if any(skip in key for skip in SKIP_PATTERNS):
                    continue
                if obj['Size'] < 100:  # skip empty/tiny files
                    continue
                all_files.append(key)

    return all_files


def invoke_kb_builder(lambda_client, s3_key):
    """Invoke the KB builder Lambda with an S3 event for a single file."""
    payload = {
        "Records": [
            {
                "s3": {
                    "bucket": {"name": BUCKET},
                    "object": {"key": s3_key}
                }
            }
        ]
    }
    response = lambda_client.invoke(
        FunctionName=LAMBDA_NAME,
        InvocationType='Event',  # Async — don't wait for completion
        Payload=json.dumps(payload).encode('utf-8'),
    )
    return response.get('StatusCode', 0)


def main():
    parser = argparse.ArgumentParser(description="Re-tag all KB sources via pmi-kb-builder Lambda")
    parser.add_argument("--dry-run", action="store_true", help="List files without invoking Lambda")
    parser.add_argument("--limit", type=int, default=0, help="Process only first N files (0 = all)")
    parser.add_argument("--prefix", type=str, default=None, help="Only process files under this prefix")
    parser.add_argument("--sync", action="store_true", help="Invoke synchronously (slower, shows errors)")
    args = parser.parse_args()

    s3 = boto3.client('s3', region_name=REGION)
    lambda_client = boto3.client('lambda', region_name=REGION)

    print(f"Listing files in s3://{BUCKET}/ ...")
    files = list_all_kb_files(s3, prefix_filter=args.prefix)
    total = len(files)
    print(f"Found {total} files to re-tag")

    if args.limit > 0:
        files = files[:args.limit]
        print(f"Limited to first {args.limit} files")

    if args.dry_run:
        print("\n--- DRY RUN (no Lambda invocations) ---")
        for i, f in enumerate(files, 1):
            print(f"  [{i}/{len(files)}] {f}")
        print(f"\nTotal: {len(files)} files would be re-tagged")
        return

    print(f"\nStarting re-tagging of {len(files)} files...")
    success = 0
    failed = 0
    start = time.time()

    for i, key in enumerate(files, 1):
        try:
            if args.sync:
                # Synchronous — wait for result (slower but shows errors)
                payload = {
                    "Records": [{"s3": {"bucket": {"name": BUCKET}, "object": {"key": key}}}]
                }
                resp = lambda_client.invoke(
                    FunctionName=LAMBDA_NAME,
                    InvocationType='RequestResponse',
                    Payload=json.dumps(payload).encode('utf-8'),
                )
                status = resp.get('StatusCode', 0)
                if resp.get('FunctionError'):
                    error_payload = json.loads(resp['Payload'].read())
                    print(f"  [{i}/{len(files)}] ERROR: {key[-60:]} | {error_payload.get('errorMessage', '')[:80]}")
                    failed += 1
                else:
                    print(f"  [{i}/{len(files)}] OK: {key[-60:]}")
                    success += 1
            else:
                # Async — fire and forget (fast)
                status = invoke_kb_builder(lambda_client, key)
                if status == 202:
                    success += 1
                else:
                    failed += 1

                if i % 50 == 0:
                    elapsed = time.time() - start
                    rate = i / elapsed
                    eta = (len(files) - i) / rate if rate > 0 else 0
                    print(f"  [{i}/{len(files)}] progress | success={success} | failed={failed} | rate={rate:.1f}/s | ETA={eta:.0f}s")

            # Small delay to avoid Lambda throttling (async mode)
            if not args.sync and i % 10 == 0:
                time.sleep(1)

        except Exception as e:
            print(f"  [{i}/{len(files)}] EXCEPTION: {key[-60:]} | {e}")
            failed += 1

    elapsed = time.time() - start
    print(f"\n{'='*60}")
    print(f"RE-TAGGING COMPLETE")
    print(f"{'='*60}")
    print(f"  Total files: {len(files)}")
    print(f"  Success:     {success}")
    print(f"  Failed:      {failed}")
    print(f"  Duration:    {elapsed:.1f}s")
    print(f"  Rate:        {len(files)/elapsed:.1f} files/sec")


if __name__ == "__main__":
    main()
