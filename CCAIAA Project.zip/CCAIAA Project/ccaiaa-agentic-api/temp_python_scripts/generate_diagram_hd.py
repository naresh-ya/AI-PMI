"""Generate a clean, corporate-style 16:9 HD architecture diagram for the Medium article."""
from PIL import Image, ImageDraw, ImageFont
import os

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
os.makedirs(OUT_DIR, exist_ok=True)

# 16:9 HD
WIDTH, HEIGHT = 1920, 1080
img = Image.new('RGB', (WIDTH, HEIGHT), '#FFFFFF')
draw = ImageDraw.Draw(img)

# Colors — corporate blue + grey palette
NAVY = '#1B2A4A'
BLUE = '#2563EB'
LIGHT_BLUE = '#DBEAFE'
DARK_GRAY = '#374151'
MID_GRAY = '#6B7280'
LIGHT_GRAY = '#F9FAFB'
BORDER_GRAY = '#D1D5DB'
GREEN = '#059669'
GREEN_LIGHT = '#D1FAE5'
RED = '#DC2626'
RED_LIGHT = '#FEE2E2'
AMBER = '#D97706'
AMBER_LIGHT = '#FEF3C7'
WHITE = '#FFFFFF'

# Fonts
try:
    font_title = ImageFont.truetype("calibrib.ttf", 44)
    font_subtitle = ImageFont.truetype("calibri.ttf", 24)
    font_heading = ImageFont.truetype("calibrib.ttf", 28)
    font_body = ImageFont.truetype("calibri.ttf", 22)
    font_box = ImageFont.truetype("calibrib.ttf", 21)
    font_small = ImageFont.truetype("calibri.ttf", 18)
    font_tag = ImageFont.truetype("calibrib.ttf", 17)
except:
    font_title = ImageFont.load_default()
    font_subtitle = font_title
    font_heading = font_title
    font_body = font_title
    font_box = font_title
    font_small = font_title
    font_tag = font_title


def rounded_rect(x, y, w, h, fill, outline=None, radius=12, outline_width=2):
    draw.rounded_rectangle([x, y, x+w, y+h], radius=radius, fill=fill,
                           outline=outline or fill, width=outline_width)


def draw_box(x, y, w, h, fill, outline, text, font=font_box, text_color=WHITE):
    rounded_rect(x, y, w, h, fill, outline)
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text((x + (w - tw) // 2, y + (h - th) // 2), text, fill=text_color, font=font)


def draw_arrow_right(x1, y, x2, color=MID_GRAY, width=2):
    draw.line([(x1, y), (x2, y)], fill=color, width=width)
    draw.polygon([(x2, y), (x2-10, y-6), (x2-10, y+6)], fill=color)


def draw_arrow_down(x, y1, y2, color=MID_GRAY, width=2):
    draw.line([(x, y1), (x, y2)], fill=color, width=width)
    draw.polygon([(x, y2), (x-6, y2-10), (x+6, y2-10)], fill=color)


# ═══════════════════════════════════════════════════════════════════════════════
# HEADER
# ═══════════════════════════════════════════════════════════════════════════════
# Subtle header background
rounded_rect(0, 0, WIDTH, 100, LIGHT_GRAY, LIGHT_GRAY, radius=0)
draw.text((60, 28), "Silent Errors in Serverless", fill=NAVY, font=font_title)
draw.text((60, 70), "The invisible failures that corrupt data without crashing your system", fill=MID_GRAY, font=font_subtitle)

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 1: Happy Path vs Silent Failure (top half)
# ═══════════════════════════════════════════════════════════════════════════════
section_y = 130

# Happy path label
draw.text((60, section_y), "NORMAL FLOW", fill=GREEN, font=font_tag)
draw.text((200, section_y), "— Operation succeeds, data is written correctly", fill=MID_GRAY, font=font_small)

# Happy path boxes
row1_y = section_y + 30
box_w, box_h = 200, 55
gap = 40

draw_box(60, row1_y, box_w, box_h, BLUE, BLUE, "API Request")
draw_arrow_right(260, row1_y + box_h//2, 300, BLUE)
draw_box(300, row1_y, box_w, box_h, BLUE, BLUE, "Lambda Function")
draw_arrow_right(500, row1_y + box_h//2, 540, BLUE)
draw_box(540, row1_y, box_w, box_h, BLUE, BLUE, "Database Write")
draw_arrow_right(740, row1_y + box_h//2, 780, GREEN)
draw_box(780, row1_y, 160, box_h, GREEN, GREEN, "200 OK  ✓")
draw_arrow_right(940, row1_y + box_h//2, 980, GREEN)
draw_box(980, row1_y, 250, box_h, GREEN, GREEN, "User Sees Correct Data")

# Silent failure label
sf_label_y = row1_y + box_h + 40
draw.text((60, sf_label_y), "SILENT FAILURE", fill=RED, font=font_tag)
draw.text((230, sf_label_y), "— Operation fails, but execution continues as if successful", fill=MID_GRAY, font=font_small)

# Silent failure boxes
row2_y = sf_label_y + 30

draw_box(60, row2_y, box_w, box_h, BLUE, BLUE, "API Request")
draw_arrow_right(260, row2_y + box_h//2, 300, BLUE)
draw_box(300, row2_y, box_w, box_h, BLUE, BLUE, "Lambda Function")
draw_arrow_right(500, row2_y + box_h//2, 540, RED)
draw_box(540, row2_y, box_w, box_h, RED, RED, "Write FAILS  ✗")
draw_arrow_right(740, row2_y + box_h//2, 780, AMBER)
draw_box(780, row2_y, 180, box_h, AMBER_LIGHT, AMBER, "except: pass", text_color=DARK_GRAY)
draw_arrow_right(960, row2_y + box_h//2, 1000, AMBER)
draw_box(1000, row2_y, 160, box_h, GREEN, GREEN, "200 OK  ✓")
draw_arrow_right(1160, row2_y + box_h//2, 1200, RED)
draw_box(1200, row2_y, 280, box_h, RED_LIGHT, RED, "User Sees STALE Data", text_color=RED)

# Annotation
ann_y = row2_y + box_h + 15
draw.text((780, ann_y), "↑ Error is caught and swallowed here — nobody is alerted", fill=RED, font=font_small)

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 2: Root Causes (middle)
# ═══════════════════════════════════════════════════════════════════════════════
causes_y = ann_y + 55

# Divider line
draw.line([(60, causes_y), (WIDTH - 60, causes_y)], fill=BORDER_GRAY, width=1)
causes_y += 20

draw.text((60, causes_y), "ROOT CAUSES", fill=NAVY, font=font_heading)
causes_y += 40

cause_w = 530
cause_h = 90

# Cause 1
rounded_rect(60, causes_y, cause_w, cause_h, WHITE, BORDER_GRAY)
draw.text((80, causes_y + 15), "Reserved Keywords", fill=NAVY, font=font_box)
draw.text((80, causes_y + 42), "Field names like 'status', 'sources', 'name', 'count'", fill=DARK_GRAY, font=font_body)
draw.text((80, causes_y + 65), "are reserved — update expressions fail without escaping", fill=MID_GRAY, font=font_small)

# Cause 2
rounded_rect(630, causes_y, cause_w, cause_h, WHITE, BORDER_GRAY)
draw.text((650, causes_y + 15), "Type Mismatches", fill=NAVY, font=font_box)
draw.text((650, causes_y + 42), "float vs Decimal, datetime vs string, None vs empty", fill=DARK_GRAY, font=font_body)
draw.text((650, causes_y + 65), "SDK rejects the type — caught by generic except handler", fill=MID_GRAY, font=font_small)

# Cause 3
rounded_rect(1200, causes_y, cause_w, cause_h, WHITE, BORDER_GRAY)
draw.text((1220, causes_y + 15), "Broad Exception Handlers", fill=NAVY, font=font_box)
draw.text((1220, causes_y + 42), "except Exception: logger.warning(...)", fill=DARK_GRAY, font=font_body)
draw.text((1220, causes_y + 65), "Absorbs every error — logic, type, permission, config", fill=MID_GRAY, font=font_small)

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 3: Solutions (bottom)
# ═══════════════════════════════════════════════════════════════════════════════
solutions_y = causes_y + cause_h + 40

# Divider line
draw.line([(60, solutions_y), (WIDTH - 60, solutions_y)], fill=BORDER_GRAY, width=1)
solutions_y += 20

draw.text((60, solutions_y), "BEST PRACTICES", fill=GREEN, font=font_heading)
solutions_y += 45

sol_w = 330
sol_h = 110

# Solution boxes
solutions = [
    ("Escape Field Names", "Always use parameterized\nattribute references —\nnever raw field names"),
    ("Read After Write", "Verify critical state\ntransitions immediately\nafter writing"),
    ("Specific Exceptions", "Catch TypeError, ClientError\nseparately — let unknowns\ncrash loudly"),
    ("Log State Changes", "Log before AND after\nwith measurable values\n(14 → 11, not 'success')"),
    ("Test Real Writes", "Run actual SDK calls with\nreal data locally before\nevery deployment"),
]

for i, (title, desc) in enumerate(solutions):
    x = 60 + i * (sol_w + 20)
    rounded_rect(x, solutions_y, sol_w, sol_h, GREEN_LIGHT, GREEN)
    draw.text((x + 15, solutions_y + 12), title, fill=GREEN, font=font_box)
    draw.text((x + 15, solutions_y + 40), desc, fill=DARK_GRAY, font=font_small)

# ═══════════════════════════════════════════════════════════════════════════════
# FOOTER — Key insight
# ═══════════════════════════════════════════════════════════════════════════════
footer_y = solutions_y + sol_h + 35

rounded_rect(60, footer_y, WIDTH - 120, 70, NAVY, NAVY, radius=10)
draw.text((90, footer_y + 12), "KEY PRINCIPLE", fill=AMBER, font=font_tag)
draw.text((90, footer_y + 35), "Build systems that fail loudly or succeed verifiably. There is no safe middle ground.", fill=WHITE, font=font_body)
draw.text((WIDTH - 400, footer_y + 35), "Loud failure = 5-min fix  |  Silent failure = days of debugging", fill=LIGHT_BLUE, font=font_small)

# Save
output_path = os.path.join(OUT_DIR, "Silent_Errors_Architecture_Diagram.jpg")
img.save(output_path, "JPEG", quality=95)
print(f"Saved: {output_path}")
print(f"Resolution: {WIDTH}x{HEIGHT} (16:9 HD)")
