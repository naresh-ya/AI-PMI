import os
import zipfile
import subprocess
import shutil
import tempfile
import glob
import argparse

LAMBDAS = [
    {
        "name": "pmi-input-validator-client-demo1",
        "folder": "agents/input_validator",
        "handler": "handler.py",
        "source_file": "handler_new_validator.py",
        "includes": ["core"]
    },
    {
        "name": "pmi-api-handler-client-demo1",
        "folder": "api",
        "handler": "handler_create_request_dynamodb.py",
        "source_file": "handler_create_request_dynamodb_new.py"
    },
    {
        "name": "pmi-master-researcher-client-demo1",
        "folder": "agents/master_researcher",
        "handler": "handler.py",
        "source_file": "handler_new_advanced.py",
        "includes": ["core", "knowledge_base", "templates"]
    },
    {
        "name": "pmi-master-drafter-client-demo1",
        "folder": "agents/master_drafter",
        "handler": "handler.py",
        "source_file": "handler_drafter_new.py",
        "includes": ["core", "knowledge_base", "templates"]
    },
    {
        "name": "pmi-kb-builder",
        "folder": "knowledge_base",
        "handler": "build_kb_from_s3.py",
        "source_file": "build_kb_from_s3.py",
        "includes": ["core"]
    },
    {
        "name": "pmi-sharepoint-ingestion",
        "folder": "ingestion",
        "handler": "handler.py",
        "source_file": "handler.py"
    },
    {
        "name": "pmi-kb-sync-failure-handler",
        "folder": "knowledge_base/sync_failure_handler",
        "handler": "handler.py",
        "source_file": "handler.py"
    },
    {
        "name": "pmi-hitl-gate-client-demo1",
        "folder": "agents/hitl_research_gate",
        "handler": "handler.py",
        "source_file": "handler.py"
    },
    {
        "name": "pmi-hitl-interface",
        "folder": "api",
        "handler": "handler_hitl_new.py",
        "source_file": "handler_hitl_new.py"
    },
    {
        "name": "pmi-signed-documents",
        "folder": "api",
        "handler": "handler_signed_documents.py",
        "source_file": "handler_signed_documents_new.py"
    }
]

def deploy(target=None):
    lambdas_to_deploy = LAMBDAS
    if target:
        lambdas_to_deploy = [l for l in LAMBDAS if l['name'] == target]
        if not lambdas_to_deploy:
            valid = [l['name'] for l in LAMBDAS]
            print(f"❌  Unknown function '{target}'. Valid options are:\n  " + "\n  ".join(valid))
            return
    for l in lambdas_to_deploy:
        zip_name = f"{l['name']}.zip"
        print(f"Packaging {l['name']}...")
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Copy handler
            handler_file = l.get('source_file', l['handler'])
            handler_path = os.path.join(l['folder'], handler_file)
            if os.path.exists(handler_path):
                shutil.copy2(handler_path, os.path.join(temp_dir, l['handler']))
                
            # Copy includes
            for inc in l.get("includes", []):
                if os.path.exists(inc):
                    shutil.copytree(inc, os.path.join(temp_dir, os.path.basename(inc)), dirs_exist_ok=True)
                    
            # Hot-swap the new prompt registry into place if core is included
            registry_new_path = os.path.join(temp_dir, "core", "prompt_registry_new.py")
            registry_target_path = os.path.join(temp_dir, "core", "prompt_registry.py")
            if os.path.exists(registry_new_path):
                shutil.copy2(registry_new_path, registry_target_path)
                    
            # Install dependencies if requirements.txt exists and it's not the KB searcher
            req_path = os.path.join(l['folder'], "requirements.txt")
            if os.path.exists(req_path) and l['name'] not in ("pmi-kb-builder",):
                print(f"Downloading dependencies for {l['name']}...")
                pkg_dir = os.path.join(temp_dir, "_pkg")
                os.makedirs(pkg_dir)
                subprocess.run([
                    "pip", "download", "-r", req_path, "-d", pkg_dir,
                    "--platform", "manylinux2014_x86_64",
                    "--python-version", "3.10",
                    "--only-binary=:all:"
                ], check=True, capture_output=True)
                
                print(f"Extracting wheels...")
                for wheel_file in glob.glob(os.path.join(pkg_dir, "*.whl")):
                    with zipfile.ZipFile(wheel_file, 'r') as w:
                        w.extractall(temp_dir)
                shutil.rmtree(pkg_dir)

            # KB builder: install only the lightweight deps it actually uses
            if l['name'] == "pmi-kb-builder":
                print(f"Installing lightweight dependencies for {l['name']}...")
                subprocess.run([
                    "pip", "install", "PyPDF2", "extract-msg", "-t", temp_dir,
                    "--upgrade", "--quiet"
                ], check=True, capture_output=True)
                
            # Create zip file
            with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zf:
                for root, _, files in os.walk(temp_dir):
                    if "__pycache__" in root:
                        continue
                    for file in files:
                        if file.endswith(".pyc"):
                            continue
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, temp_dir)
                        zf.write(file_path, arcname)
                        
        print(f"Deploying {l['name']} to AWS...")
        
        try:
            # Check if function exists
            check_cmd = ["aws", "lambda", "get-function", "--function-name", l['name']]
            result = subprocess.run(check_cmd, capture_output=True)
            
            if result.returncode == 0:
                # Update existing
                cmd = [
                    "aws", "lambda", "update-function-code",
                    "--function-name", l['name'],
                    "--zip-file", f"fileb://{zip_name}"
                ]
                subprocess.run(cmd, check=True, capture_output=True)
                print(f"Successfully updated {l['name']}\n")
            else:
                # Function does not exist, create it
                print(f"Function {l['name']} does not exist. Creating it...")
                
                # Fetch role from an existing lambda to use as default
                try:
                    role_cmd = ["aws", "lambda", "get-function-configuration", "--function-name", "pmi-input-validator", "--query", "Role", "--output", "text"]
                    role_result = subprocess.run(role_cmd, capture_output=True, text=True, check=True)
                    role_arn = role_result.stdout.strip()
                except subprocess.CalledProcessError:
                    import json
                    role_cmd = ["aws", "iam", "list-roles", "--output", "json"]
                    role_result = subprocess.run(role_cmd, capture_output=True, text=True, check=True)
                    roles = json.loads(role_result.stdout).get("Roles", [])
                    role_arn = None
                    for r in roles:
                        if "LambdaExecutionRole" in r.get("RoleName", "") or "PmiAgenticAi" in r.get("RoleName", ""):
                            # Prefer a role that looks like it's from our stack
                            role_arn = r["Arn"]
                            break
                    if not role_arn:
                        print("Failed to find a suitable IAM role for Lambda execution.")
                        raise Exception("IAM Role not found")
                
                # Determine handler entry point
                handler_entry = "handler_create_request_dynamodb.lambda_handler" if "api" in l['name'] else "handler.lambda_handler"
                if l['name'] == "pmi-kb-builder":
                    handler_entry = "build_kb_from_s3.lambda_handler"
                elif l['name'] == "pmi-hitl-interface":
                    handler_entry = "handler_hitl_new.lambda_handler"
                elif l['name'] == "pmi-signed-documents":
                    handler_entry = "handler_signed_documents.lambda_handler"
                
                # Determine environment variables
                env_vars = "Variables={"
                if l['name'] == "pmi-signed-documents":
                    env_vars += "SIGNED_DOCS_BUCKET=pmi-agentic-ai-documents-sandbox-603433800649,SIGNED_DOCS_PREFIX=signed_documents/,PRESIGNED_URL_EXPIRY=900,REGION=eu-west-1"
                elif "api" in l['name']:
                    env_vars += "STATE_MACHINE_ARN=arn:aws:states:eu-west-1:603433800649:stateMachine:pmi-agentic-ai-workflow-client-demo1,DYNAMODB_REQUESTS_TABLE=pmi-agentic-ai-requests"
                elif "gate" in l['name'] or "hitl" in l['name']:
                    env_vars += "REQUESTS_TABLE=pmi-agentic-ai-requests,HITL_TABLE=pmi-agentic-ai-hitl-dev,REGION=eu-west-1"
                else:
                    env_vars += "REGION=eu-west-1"
                env_vars += "}"

                create_cmd = [
                    "aws", "lambda", "create-function",
                    "--function-name", l['name'],
                    "--runtime", "python3.10",
                    "--role", role_arn,
                    "--handler", handler_entry,
                    "--zip-file", f"fileb://{zip_name}",
                    "--timeout", "30",
                    "--environment", env_vars,
                    "--region", "eu-west-1"
                ]
                
                # We need to print stderr if it fails
                try:
                    subprocess.run(create_cmd, check=True, capture_output=True)
                    print(f"Successfully created {l['name']}\n")
                except subprocess.CalledProcessError as e:
                    error_msg = e.stderr if isinstance(e.stderr, str) else (e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e))
                    print(f"Failed to create {l['name']}: {error_msg}\n")
                
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr if isinstance(e.stderr, str) else (e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e))
            print(f"Failed to update {l['name']}: {error_msg}\n")
            
        if os.path.exists(zip_name):
            os.remove(zip_name)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Deploy one or all PMI Lambda functions.")
    parser.add_argument(
        "--function", "-f",
        metavar="FUNCTION_NAME",
        help="Deploy a single Lambda by name (e.g. pmi-hitl-interface). Omit to deploy all.",
        default=None
    )
    args = parser.parse_args()
    deploy(target=args.function)
