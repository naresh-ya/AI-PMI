# White Papers Template

> Category: White Papers
> Output: Formal, evidence-based advocacy document.
> Total target: ~2600 words.

## Purpose
Present a structured, evidence-led case on the topic for an external policy audience.
Each section has a distinct job; content must not be repeated across sections.

## Structure (sections, in order)

1. **Executive Summary** (~300 words)
   - High-level synthesis of the argument and the 2–3 key recommendations.
   - This is the ONLY place a brief recap of the whole document belongs.
   - State headline statistics here; do not repeat the same numbers verbatim later.

2. **Introduction to PMI** (~250 words)
   - Standard organizational context only. Use the approved About-PMI boilerplate.
   - No topic arguments, no evidence — that belongs in later sections.

3. **Introduction to the Topic** (~300 words)
   - Define the topic, key terms, and why it matters in this jurisdiction.
   - Scene-setting only. Do NOT pre-empt the scientific detail or recommendations.

4. **Core Concepts** (~1200 words)
   - The substance: product descriptions, scientific evidence, and global precedents.
   - This is where detailed evidence lives. Introduce each study/precedent ONCE here.

5. **Conclusion** (~350 words)
   - Synthesize the argument and risks of inaction; restate recommendations briefly.
   - Reference earlier evidence by summary, do not re-state full data or citations.
   - No bibliography or numbered reference list in this section.

6. **Annexures** (optional, ~200 words)
   - Only if the user supplied annexure content.

## Anti-duplication rules
- The combustion-vs-nicotine risk continuum is explained ONCE (Core Concepts).
- Country precedents and switching statistics appear ONCE (Core Concepts), referenced
  elsewhere by one-line cross-reference.
- "About PMI" content appears ONLY in Introduction to PMI.
- Recommendations are detailed once; the Executive Summary and Conclusion may name them
  but must not duplicate the full rationale.

## Tone & citations
Formal, neutral, non-promotional, evidence-first. Use inline [N] citation markers only;
a single References section is appended automatically at the end of the document.
