# Media Releases Template

> Category: Media Releases (Press Releases, Public Statements, Announcements)
> Output: Formal press release. Total target: ~1500 words.

## Purpose
A public-facing press release announcing or responding to a development. Each section
has a distinct role; the core announcement is stated once and then expanded, never
repeated verbatim.

## Structure (sections, in order)

1. **Place and date** (~1 line)
   - Dateline only: location and date (e.g. "New Delhi, 18 June 2026").
   - Generated programmatically; no body content.

2. **Introduction of the topic** (~250 words)
   - The core announcement and its context, stated clearly and once.
   - This is the lede; do not repeat it later word-for-word.

3. **Expansion of the topic** (~900 words)
   - 5–6 factual paragraphs that develop the announcement: detail, evidence, quotes,
     and implications. Each fact or figure appears once here.
   - Build on the lede; do not restate it.

4. **Conclusion** (~200 words)
   - Concluding remarks and forward-looking statement. No new facts, no repetition.

5. **About PMI India** (~150 words)
   - Standard organizational boilerplate only. No other subheadings inside.
   - This is the ONLY place organizational "About" content appears.

## Anti-duplication rules
- The core announcement is stated once (Introduction) and expanded (Expansion), never
  duplicated verbatim.
- Each statistic, quote, or claim appears once.
- "About PMI India" content appears only in the final About section.

## Tone & citations
Formal, factual, news-style, non-promotional. Use inline [N] markers only; a single
References section is appended automatically.
