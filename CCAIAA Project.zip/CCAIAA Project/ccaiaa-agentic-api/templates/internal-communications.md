# Internal Communications Template

> Category: Internal Communications (Business Updates, Regulatory Comms, Parliamentary Updates)
> Output: Internal briefing. Total target: ~1000 words.

## Purpose
A concise internal briefing for PMI colleagues/leadership. Factual, scannable, and free
of repetition. The exact sections depend on the use case (below).

## Structure by use case

### Business Update
1. **Greetings** (~50 words) — brief internal salutation.
2. **Here are the key updates for the month** (~700 words)
   - Factual monthly updates as a single flowing block. No nested subheadings.
3. **Summary** (~250 words) — key takeaways only; do not repeat the detail above.

### Regulation Update
1. **Greetings** (~50 words)
2. **Introduction of the Topic** (~200 words) — what changed and why it matters.
3. **Please find below an analysis** (~500 words)
   - 4–5 bullet points analysing the regulation. No nested subheadings.
4. **Summary** (~250 words) — implications only; no repetition of the analysis.

### Parliamentary / Other Updates
1. **Greetings** (~50 words)
2. **Here are the key updates** (~600 words)
   - Factual bullets: key changes, dates, implications. No nested subheadings.
3. **Summary** (~150 words) — 2–3 sentence takeaway for leadership; no repetition.

## Anti-duplication rules
- Exactly ONE greeting, at the top. No salutations in later sections.
- Each update/fact appears once in the main block; the Summary only distils implications.
- Do not restate dates or figures in both the body and the summary.

## Tone & citations
Plain, factual, internal. Use inline [N] markers only; References appended automatically.
