# Official PMI Submission Template

> Category: Official PMI Submission (formal letter/submission to an authority)
> Output: Clean formal correspondence. Total target: ~800 words.

## Purpose
A formal letter from PMI to a government authority or stakeholder. It reads as flowing
correspondence, not a multi-section report. Keep it tight and purposeful.

## Structure (sections, in order)

1. **Address Block** (~100 words)
   - Addressed-To and CC lines only. No body content.

2. **Subject Line** (~1 line)
   - A single concise subject reflecting the letter's purpose.

3. **Letter Body** (~600 words)
   - 4–5 flowing paragraphs that address the query directly:
     - Opening: purpose of the letter and PMI's position in one or two sentences.
     - Middle: the rationale and supporting evidence, each point made once.
     - Close: the specific ask or recommendation to the recipient.
   - Do not use internal subheadings, metadata labels, or a reference list in the body.

4. **Greetings** (~50 words)
   - Closing salutation and signature block only.

## Anti-duplication rules
- The position is stated once and developed, not repeated paragraph to paragraph.
- Each fact or statistic appears once in the body.
- No greetings or salutations anywhere except the Address Block and Greetings sections.

## Tone & citations
Formal, respectful, concise, compliance-first. Use inline [N] markers only; the
References section is appended automatically.
