# Thailand — Regulatory Ground Truth

## 1. WHO REGULATES WHAT

### Tobacco and Nicotine Products (excluding NRT)
Regulatory authority: Department of Disease Control (DDC)
Under: Ministry of Public Health (MoPH)
Scope: Combustible cigarettes, heated tobacco products, e-cigarettes, smokeless tobacco, waterpipe tobacco, Nicotine pouch (includes all nicotine containing products, except NRT)

### Nicotine Replacement Therapy (NRT) ONLY
Regulatory authority: Thai Food and Drug Administration (Thai FDA)
Scope: Nicotine patches, nicotine gum, nicotine lozenges (cessation products only)

### CRITICAL — AI MUST NEVER STATE:
- "Thai FDA regulates tobacco products"
- "Thai FDA regulates heated tobacco products"
- "Thai FDA approved/banned [any tobacco product]"
- "Thailand's FDA oversees HTP regulation"

### AI MUST USE:
- "Department of Disease Control (DDC) under the Ministry of Public Health is the regulatory authority for tobacco and nicotine products in Thailand."
- "Thai FDA's nicotine authority is limited to Nicotine Replacement Therapy (NRT) only."

## 2. CURRENT PRODUCT STATUS

### Heated Tobacco Products (HTP / HNB)
Heated tobacco products (HTPs / HNB) remain banned in Thailand, with no legal commercial pathway. The latest accessible basis is the 2014 Ministry of Commerce import prohibition (notified internationally as covering heat-not-burn tobacco products), together with subsequent sale / service prohibitions and 2024 safety-products restrictions.

### Electronic Cigarettes / Vaping Devices
Electronic cigarettes / vaping devices are banned in Thailand. Current accessible legal bases include the Notification of the Ministry of Commerce (2014) on import prohibition, Consumer Protection Board Order No. 9/2015 on sale / service prohibition, Committee on Safety of Products and Services Decree No. 24/2024 on manufacture for sale / sale / service, and Customs Act 2017 for import and possession-related enforcement. For enforcement, official guidance distinguishes sale/service, import, and possession/receipt of unlawfully imported goods rather than using one single penalty figure.
For e-cigarettes, Thai official guidance states that possession / receipt / concealment of unlawfully imported goods may be prosecuted under Customs Act 2017 section 246. Enforcement still depends on facts and proof, but the official position is no longer well described as merely ‘ambiguous.

### Combustible Cigarettes
Status: Legal, heavily regulated
Minimum purchase age: 20 years
Plain packaging: Mandatory (implemented 2019)
Point of sale display: Prohibited
Graphic health warnings: Required (minimum 85% of pack face)

### Nicotine Pouches
Status: For tobacco-control purposes, the Department of Disease Control has publicly confirmed that nicotine pouches / SNUS are treated as tobacco products under the Tobacco Products Control Act B.E. 2560 (2017). Official communications in 2026 state that they are subject to the 20+ sales rule and to restrictions on online sale, display, promotion, and sales promotion.

## 3. KEY LEGISLATION

| Legislation | Year | Purpose |
| --- | --- | --- |
| Tobacco Products Control Act B.E. 2560 | 2017 | Primary tobacco control law (replaced 1992 act) |
| Hazardous Substances Act B.E. 2535 | 1992 | Does not directly ban e-cigarettes, but the regulation has been used in the enforcement and regulatory narrative |

## 4. GOVERNMENT POLICY POSITION
- Thailand is a Party to the WHO Framework Convention on Tobacco Control, having ratified it on 8 November 2004; it entered into force for Thailand on 27 February 2005
- Official position: No regulatory pathway for reduced-risk products under current legislation
- MoPH has consistently opposed legalisation of HTPs and e-cigarettes (2019–2024)
- In October 2025 the Cabinet officially tasked MoPH to amend the Tobacco Products Control Act B.E. 2560 (2017) to cover e-cigarettes and new tobacco products more explicitly. As of June 2026, this has not created any legal commercial pathway for HTPs or e-cigarettes

## 5. KEY DECISION MAKERS

| Body | Role |
| --- | --- |
| Department of Disease Control (DDC) | Primary tobacco regulator |
| Ministry of Public Health | Political authority |
| National Tobacco Products Control Committee | Policy advisory |
| Thai FDA | NRT regulation ONLY |
| Key stakeholders: ASH Thailand | Opposition NGO |

## 6. APPROVED TERMINOLOGY
- First reference: " Department of Disease Control (DDC)"
- Subsequent: "DCD"
- First reference: "Ministry of Public Health”
- Subsequent: "MoPH"

### AVOID in all Thai regulatory contexts:
- "Thai FDA" (unless specifically about NRT)
- "ASEAN harmonised tobacco standards" (no such standard exists)
- "ASEAN trade agreements" without naming a specific agreement and year
- "Thailand is reviewing legalisation" (unconfirmed)
