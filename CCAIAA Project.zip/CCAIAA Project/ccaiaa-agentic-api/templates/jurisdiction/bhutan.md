# Bhutan — Regulatory Ground Truth

## 1. WHO REGULATES WHAT

### Tobacco Products (all categories)
Regulatory authority: Ministry of Health (MoH) — Tobacco Control Board and coordinated administratively by the Bhutan Narcotics Control Agency (BNCA)
Operational tobacco-control regulator / implementing authority: Bhutan Food and Drug Authority (BFDA), especially its Controlled Substances and Medical Device Division
Enforcement: Royal Bhutan Police
Tax authority: Department of Revenue and Customs

### CRITICAL — AI MUST NEVER STATE:
- "Bhutan has banned tobacco"
- "Tobacco is illegal in Bhutan"
- "Bhutan is tobacco-free"

### AI MUST USE:
- Bhutan’s earlier commercial sales ban was lifted by the 2021 amendment. Tobacco products may be imported, sold, bought, possessed, distributed and transported subject to Bhutan’s tobacco-control restrictions and tax rules.
- The Tobacco Control Act 2010 is the primary legislation governing tobacco in Bhutan.

## 2. CURRENT PRODUCT STATUS

### ALL Tobacco Products (Cigarettes, Smokeless, HTPs)
Legal basis: Tobacco Control Act 2010 (TCA 2010)

### Heated Tobacco Products (HTP / HNB) and Electronic Cigarettes / Vaping
Status: Bhutan’s Ministry of Health said in late 2025 that the Tobacco Control Rules and Regulations are being revised to explicitly include e-cigarettes, vapes, and heated tobacco products, and that the Tobacco Control Act itself will be updated to be more relevant to current products. Bhutan is actively bringing them into a more explicit regulatory/tax framework
Not specifically addressed in TCA 2010 (predates HTPs)

## 3. KEY LEGISLATION

| Legislation | Year | Purpose |
| --- | --- | --- |
| Tobacco Control Act (TCA) | 2010 | Complete ban on commercial sale of tobacco products |
| Tobacco Control (Amendment) Act | 2014 | Increased penalties, clarified personal import provisions |
| Tobacco Control (Amendment) Act / Bill of Bhutan | 2021 | Lifted the old prohibitions on sale/buying/possession/transport/distribution |
| National Drug Policy | 2007 | Context for substance regulation |

## 4. GOVERNMENT POLICY POSITION
- Bhutan is a signatory to WHO FCTC since 9 December 2003 (ratified 12 August 2004)
- Bhutan historically had one of the world’s strictest tobacco-sales regimes, but since 2021 it has operated a legal sale-and-import framework with continued restrictions on public smoking, advertising/promotion and emerging products
- Government philosophy: Gross National Happiness includes health and well-being

## 5. KEY DECISION MAKERS

| Body | Role |
| --- | --- |
| Ministry of Health — Tobacco Control Board | Primary regulator |
| Royal Bhutan Police | Enforcement of sale ban |
| Bhutan Food and Drug Authority (BFDA) | Substance control |
| Department of Revenue and Customs | Import duty collection |
| National Assembly | Legislative authority |

## 6. APPROVED TERMINOLOGY
- First reference: "Tobacco Control Act 2010 (TCA 2010)"
- Subsequent: "TCA 2010"
- Use: "Ministry of Health" (NOT "Bhutan FDA" — no such body)

### AVOID:
- "Bhutan banned tobacco"
- "Tobacco is illegal in Bhutan”
- "Bhutan is the only tobacco-free country" (inaccurate — tobacco is consumed)

## 7. KEY STATISTICS
- Adult tobacco use prevalence: ~31.4% (National Health Survey 2023)
- Smokeless tobacco (Doma/betel with tobacco): very common culturally
- Cross-border smuggling remains a significant enforcement challenge

## 8. Taxation
- From January 2026, Bhutan moved to a revised framework in which:
- Cigarettes are taxed via 10% customs duty + 5% GST + Nu 10 excise per stick.
- Cigars carry 10% customs duty + 5% GST + Nu 40 excise per stick
- Chewing tobacco is taxed via 10% customs duty + 5% GST + Nu 1,500 excise per kg
- E-cigarettes / vapes / refills are taxed at 100% excise + 10% customs duty + 5% GST, and devices face 20% excise + 10% customs duty + 5% GST.

- Bhutan’s Tobacco Control Act 2010 remains the core law, but the 2021 amendment lifted the earlier blanket prohibition on selling, buying, possessing, transporting and distributing tobacco products. Tobacco is now legally imported and sold subject to tax, smoke-free, advertising and other tobacco-control restrictions. BFDA now plays the operational regulatory role previously associated with BNCA, while the Ministry of Health remains a key policy lead. Bhutan is also actively updating its framework for e-cigarettes, vapes and heated tobacco products, with further amendments under deliberation in 2026.
