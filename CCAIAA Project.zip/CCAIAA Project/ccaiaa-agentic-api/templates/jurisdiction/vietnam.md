# Vietnam — Regulatory Ground Truth

## 1. WHO REGULATES WHAT

### Tobacco Products (all categories)
Regulatory authority: The Ministry of Health is the primary tobacco control authority in Vietnam, working through tobacco-control institutions including VINACOSH (Vietnam Steering Committee on Smoking and Health)
Trade/commerce:  The Ministry of Industry and Trade (MoIT) oversees tobacco trade and commerce; Decree No. 67/2013/ND-CP, issued under MoIT’s mandate, governs tobacco trading conditions and regulatory controls.
Tax authority:  The Ministry of Finance is responsible for tobacco taxation; the National Assembly passed the Special Consumption Tax Law No. 66/2025/QH15 in June 2025.

### CRITICAL — AI MUST NEVER STATE:
- "Vietnam FDA" (no such body — use MoH or VINACOSH)

### AI MUST USE:
- "The Ministry of Health itself and through VINACOSH is the primary tobacco control authority in Vietnam."
- "The Law on Prevention and Control of Tobacco Harms 2012 serves as the primary legislative framework; however, it does not explicitly address heated tobacco products or electronic cigarettes."

## 2. CURRENT PRODUCT STATUS

### Combustible Cigarettes
Status: Legal, regulated
Minimum purchase age: Sale of tobacco products to persons under 18 is prohibited
Graphic health warnings: Required (50% of pack front and back)
Advertising: Tobacco advertising and promotion are prohibited. Recent proposals from the Ministry of Health indicate a move toward further restricting product display at retail level.
Public smoking: Smoke-free rules apply widely, but some designated smoking-room exceptions remain in specified venues and transport settings

### Heated Tobacco Products (HTP / HNB)
Heated tobacco products are banned in Vietnam. Resolution 173/2024/QH15 prohibited the production, trade, importation, harboring, transportation and use of HTPs from 2025, and the amended Investment Law 2025 further prohibited related investment/business activities from 2026. The National Assembly moved in November 2024 to ban these products from 2025.

### Electronic Cigarettes / Vaping
Similar to Heated tobacco products, e-cigarettes are banned in Vietnam from the Resolution 173/2024/QH15. The use of e-cigarettes or heated tobacco products is subject to a fine of VND 3–5 million, along with mandatory destruction of the infringing products. This provision is strictly enforced under Decree No. 90/2026/ND-CP (effective from 15 May 2026).

### Smokeless Tobacco
Status: This category is not yet regulated. Vietnam does not recognize it as a distinct category.

## 3. KEY LEGISLATION
- Law on Prevention and Control of Tobacco Harms, No. 09/2012/QH13 (primary framework)
- Decree No. 67/2013/ND-CP (tobacco trading/business implementation)
- Joint Circular No. 05/2013/TTLT-BYT-BCT (pack labeling/50% health warnings)
- Decree No. 77/2013/ND-CP (implementation of certain tobacco-harm measures)
- Decree No. 117/2020/ND-CP (administrative sanctions in the health sector; relevant to tobacco enforcement)
- Resolution No. 173/2024/QH15 (ban on e-cigarettes and heated tobacco products from 2025)
- Law on Special Consumption Tax No. 66/2025/QH15 (new excise framework, effective 1 January 2026)
- Amended Investment Law 2025 No. 143/2025 (prohibiting investment/business activities related to e-cigarettes and HTPs from 2026)
- Decree No. 371/2025/ND-CP (amending Decree 77 and Decree 117; definitions and sanctions framework for e-cigarettes/HTPs)

## 4. GOVERNMENT POLICY POSITION
- Vietnam is a signatory to WHO FCTC since 3 September 2003 (ratified 17 December 2004); became a Party / the treaty entered into force for Vietnam on 17 March 2005
- Vietnam has progressively strengthened tobacco control (2012 law)
- Vietnam’s 2023 National Strategy on Tobacco Harm Prevention and Control sets a target of reducing smoking among males aged 15+ to below 36% by 2030
- Since late 2024, Vietnam’s policy position on e-cigarettes and heated tobacco products has shifted from debate to prohibition.

## 5. KEY DECISION MAKERS/ STAKEHOLDERS

| Body | Role |
| --- | --- |
| Ministry of Health (MoH) | Health policy, tobacco harm prevention |
| VINACOSH | Implementation of tobacco control programs |
| Ministry of Industry and Trade (MoIT) | Product classification, trade regulation |
| National Assembly | Legislative authority |
| Ministry of Finance | Taxation |
| Vietnam Tobacco Association (VTA) | Industry association / stakeholder |
| Ministry of Public Security (MPS) | Law enforcement, anti-smuggling, market surveillance and criminal enforcement related to illicit tobacco products |
| Ministry of Science and Technology (MoST) | Technology (MoST)Product standards, technical regulations and conformity assessment. |
| Ministry of Justice (MoJ) | Legal review and appraisal of draft legislation and policy proposals |
| Ministry of Foreign Affairs (MoFA) | International engagement, treaty commitments (e.g. WHO FCTC), and coordination on external policy alignment. |
| Government Office (Office of the Government — OOG) | Coordination of inter-ministerial processes and support to the Prime Minister in policy review and decision-making. |

## 6. APPROVED TERMINOLOGY
- First reference: "Ministry of Health (MoH)" or "VINACOSH (Vietnam Steering Committee on Smoking and Health)"
- Subsequent: "MoH" or "VINACOSH"
- First reference: "Law on Prevention and Control of Tobacco Harms 2012"
- Subsequent: "the 2012 Law"
- For trade context: "Vietnam-EU Free Trade Agreement (EVFTA)"

### AVOID:
- "Vietnam FDA" (does not exist)
- "ASEAN tobacco regulations" without naming the specific agreement/framework

## 7. KEY STATISTICS
- WHO-modeled latest estimate (2024), as cited in a 2025 secondary compilation drawing on WHO’s 2025 trends report: 41.8% men, 0.8% women, 20.6% overall
- VND 108 trillion annually, equal to 1.14% of GDP (2024, WHO Vietnam and Vietnam Government)
- Tobacco taxes make up about 36–38% of retail price, recent public reporting cited VND 26 trillion in state-budget contributions from VTA members in 2023, and WHO projects the 2025 tax reforms could generate an additional VND 24 trillion annually by 2031
