# Bangladesh — Regulatory Ground Truth

## 1. WHO REGULATES WHAT

### Tobacco Products (all categories)
Regulatory authority: National Tobacco Control Cell (NTCC) under the Ministry of Health and Family Welfare
Enforcement: Bangladesh Standards and Testing Institutions (BSTI) for product standards; Enforcement under the tobacco-control law is carried out by ‘authorized officers’ designated in the law and related mechanisms
Tax authority: National Board of Revenue (NBR)

### CRITICAL — AI MUST NEVER STATE:
- "Bangladesh FDA" (no such body — use BSTI)
- "Bangladesh allows e-cigarettes or HTPs"

### AI MUST USE:
- "The National Tobacco Control Cell (NTCC) under the Ministry of Health and Family Welfare is the primary tobacco control authority in Bangladesh."
- "The Smoking and Tobacco Products Usage (Control) Act 2005 is the primary legislation but does not specifically address emerging tobacco products."

## 2. CURRENT PRODUCT STATUS

### Combustible Cigarettes
Status: Legal, regulated
Minimum purchase age: 18 years
Graphic health warnings: Required (75% of pack face on both sides)
Advertising: Restricted under the 2005 Act. All forms of tobacco advertising, promotion and publicity are banned across print, electronic, internet, social media and OTT / online channels; point-of-sale display is also prohibited
Public smoking: Restricted in designated public places; now all public places and public transport are smoke-free under the new regime, with stronger penalties.

### Heated Tobacco Products (HTP / HNB)
Status: Bangladesh  allows “emerging tobacco products.” as amended in “The Smoking and Tobacco Products Usage (Control) Act 2005” approved on April 10, 2026

### Electronic Cigarettes / Vaping
Status: E-cigarettes / ENDS are now  allowed.

### Smokeless Tobacco (Jorda, Zarda, Gul)
Status: Legal, widely consumed — Bangladesh has very high smokeless tobacco use
Prevalence: Smokeless tobacco is more prevalent than cigarette smoking in many demographics

## 3. KEY LEGISLATION

| Legislation | Year | Purpose |
| --- | --- | --- |
| Smoking and Tobacco Products Usage (Control) Act | 2005 | Primary tobacco control law |
| Amendment to the 2005 Act | 2013 | Strengthened advertising ban, added pictorial warnings |
| National Tobacco Control Policy | 2007 | Policy framework |
| VAT and Supplementary Duty Act | 2012 | Tobacco taxation framework |
| Smoking and Tobacco Products Usage (Control) Rules | 2015 |  |
| Smoking and Tobacco Products Usage (Control) (Amendment) Act, 2026 (Act No. 91 of 2026) | 2026 | Amendments to Smoking and Tobacco Products Usage (Control) Act, 2015 |
| Smoking and Tobacco Products Usage (Control) (Amendment) Ordinance, 2025 | 2025 | Amendments to Smoking and Tobacco Products Usage (Control) Act, 2015 |

## 4. GOVERNMENT POLICY POSITION
- Bangladesh is a signatory to WHO FCTC since 16 June 2003 (ratified 14 June 2004)
- Official position: Strong anti-tobacco, progressive control measures
- Government has incrementally strengthened tobacco control since 2005

## 5. KEY DECISION MAKERS

| Body | Role |
| --- | --- |
| National Tobacco Control Cell (NTCC) | Primary tobacco control authority |
| Ministry of Health and Family Welfare | Policy authority |
| National Board of Revenue (NBR) | Tobacco taxation |
| Ministry of Finance | Policy authority & Tobacco taxation |

## 6. APPROVED TERMINOLOGY
- First reference: "National Tobacco Control Cell (NTCC)"
- Subsequent: "NTCC"
- First reference: "Smoking and Tobacco Products Usage (Control) Act 2005"
- Subsequent: "the 2005 Act" or "STPU Act 2005"

### AVOID:
- "Bangladesh FDA" (does not exist — use DGDA)
- "Bangladesh has approved HTPs" (no approval pathway exists)

## 7. KEY STATISTICS
- Adult tobacco use prevalence: ~35.3% (GATS 2017)
- Smokeless tobacco prevalence: ~20.6% (higher than cigarette smoking in rural areas)
- Cigarette smoking prevalence: ~14.0% (GATS 2017)
- Economic burden: Estimated total annual economic costs at BDT 875.44 billion in 2024, including both health costs (BDT 730.63 billion) and environmental damages (BDT 144.81 billion).
