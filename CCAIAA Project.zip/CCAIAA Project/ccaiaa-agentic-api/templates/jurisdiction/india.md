# India — Regulatory Ground Truth

## 1. WHO REGULATES WHAT

### Tobacco Products (all categories)
Regulatory authority: Ministry of Health and Family Welfare (MoHFW); Enforcement of tobacco laws (COTPA, PECA) is primarily undertaken by State/UT authorities, with central coordination by MoHFW
Enforcement body: Central Board of Indirect Taxes and Customs (CBIC) — for taxation/excise
State Health Department and also the local municipality have health officials who undertake enforcement of COTPA
Advisory: National Tobacco Control Cell (NTCC) under MoHFW
ICMR

### Heated Tobacco Products (HTP)
Status:  Banned under PECA; nothing to do with COTPA currently as banned under PECA
E-cigarettes: BANNED under PECA 2019 (Prohibition of Electronic Cigarettes Act)
HTPs:  Specifically banned under PECA

### CRITICAL — AI MUST NEVER STATE:
- "India has approved HTPs" (no explicit approval either)
- "FSSAI regulates tobacco" (FSSAI is food safety only)

### AI MUST USE:

- "The Prohibition of Electronic Cigarettes Act 2019 (PECA) explicitly bans e-cigarettes and ENDS and HTPs.
- "MoHFW is the primary regulatory authority for tobacco control in India."

## 2. CURRENT PRODUCT STATUS

### Heated Tobacco Products (HTP / HNB)
Status: Banned under PECA
PECA 2019 scope: Bans e-cigs, vapes, HNB etc.
Debate: This is not legally contested. It is banned.
Commercial availability: Not officially marketed; grey market exists

### Electronic Cigarettes / Vaping Devices
Status: BANNED — manufacturing, import, sale, storage, distribution prohibited. Recent MoHFW advisories (2025) explicitly prohibit online sale of e-cigarettes/ENDS and reinforce monitoring of digital and e-commerce platforms for tobacco-related violations.
Legal basis: Prohibition of Electronic Cigarettes Act 2019 (PECA)
Penalty: First offence — imprisonment up to 1 year and/or fine up to INR 100,000. Repeat — up to 3 years and INR 500,000

### Combustible Cigarettes
Status: Legal, heavily regulated
Minimum purchase age: Minimum legal age remains 18 under COTPA; however, some states (e.g., Karnataka, 2025) have increased the age limit to 21 through state amendments
Graphic health warnings: Required (85% of pack face, both sides);
India continues to mandate 85% pictorial health warnings; however, updated warnings and compliance rules under the 2024 Amendment Rules came into force from 1 June 2025 - Updated warning images/text, Continuity provisions (no lapse between warning cycles), Revised messaging like“TOBACCO CAUSES PAINFUL DEATH”
Advertising: Complete ban (COTPA Section 5)
Public smoking: Banned in public places
Point of sale: Restricted (no sale within 100m of educational institutions)

## 3. KEY LEGISLATION

| Legislation | Year | Purpose |
| --- | --- | --- |
| Cigarettes and Other Tobacco Products Act (COTPA) | 2003 | Primary tobacco control framework |
| Prohibition of Electronic Cigarettes Act (PECA) | 2019 | Bans e-cigarettes/ENDS |
| GST Act | 2017 | 28% GST + compensation cess on tobacco |
| GST changes in Budget 2026 | 2026 | Most specified tobacco products, including cigarettes and gutkha, attract a uniform 40% GST. Beedis have been taxed at 18% GST. The previous GST Compensation Cess was replaced with an additional excise framework. Cigarettes are subject to an additional excise duty ranging from ₹2,050 to ₹8,500 per 1,000 sticks, depending on product length and type. The National Calamity Contingent Duty (NCCD) remains applicable. |
| Drugs and Cosmetics Act | 1940 | NRT regulation (under CDSCO) |
| Food Safety and Standards Act | 2006 | NOT for tobacco — food safety only |

## 4. GOVERNMENT POLICY POSITION
- India is a signatory to WHO FCTC since 10 September 2003
- India ratified FCTC on 4 February 2004
- Official position: Strongly anti-tobacco, harm reduction not recognized in policy
- MoHFW position: Opposes any form of alternative nicotine products or even smokeless products
- National Health Policy 2017: Targets tobacco prevalence reduction but does not acknowledge harm reduction

## 5. KEY DECISION MAKERS

| Body | Role |
| --- | --- |
| Ministry of Health and Family Welfare (MoHFW) | Primary tobacco policy authority |
| Central Board of Indirect Taxes and Customs (CBIC) | Excise/GST/customs enforcement |
| National Tobacco Control Cell (NTCC) | Programme implementation under MoHFW |
| Drug Controller General of India (DCGI) | NRT approvals only |
| GST Council | Taxation rates |
| Parliamentary Committee on Health | Legislative oversight |

## 6. APPROVED TERMINOLOGY
- First reference: "Ministry of Health and Family Welfare (MoHFW)"
- Subsequent: "MoHFW"
- First reference: "Central Board of Indirect Taxes and Customs (CBIC)"
- Subsequent: "CBIC"
- First reference: "Cigarettes and Other Tobacco Products Act 2003 (COTPA)"
- Subsequent: "COTPA"

### AVOID:
- "FSSAI" in tobacco context (food authority, not tobacco)
- "India's FDA" (India does not have an FDA — use CDSCO/DCGI for drugs)

## 7. TAXATION
Current framework (post-Feb 2026 reform):
- Tobacco products are subject to a 40% GST (sin rate) for most categories
- Bidis are taxed at a lower rate of 18% GST
- The earlier GST compensation cess has been removed
- Taxation now relies on a combination of:
- GST (primary)
- Additional excise duty (strengthened, especially for cigarettes)
- National Calamity Contingent Duty (NCCD)
Cigarettes:
- 40% GST - length-based specific excise duty, NCCD
Smokeless tobacco / pan masala:
- 40% GST - excise / capacity-based levy in some cases
Bidis:
- 18% GST (policy-sensitive category)
Tax base:
- Increasingly RSP-based rather than transaction value
HTPs / non-combustion products:
Banned
