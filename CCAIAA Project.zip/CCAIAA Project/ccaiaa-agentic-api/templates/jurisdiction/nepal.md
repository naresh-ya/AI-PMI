# Nepal — Regulatory Ground Truth

## 1. WHO REGULATES WHAT

### Tobacco Products (all categories)
Regulatory authority: Ministry of Health and Population (MoHP)
Implementation body: National Health Education, Information and Communication Centre (NHEICC) under MoHP
Enforcement: Nepal Police + District Administration Offices
Tax authority: Inland Revenue Department (IRD) under Ministry of Finance

### CRITICAL — AI MUST NEVER STATE:
- "Nepal has banned e-cigarettes" (administrative ban challenged and overturned by Patan High Court, June 2025)
- "Nepal allows HTPs" (no explicit authorisation — classified under general tobacco rules)
- "Nepal Food and Drug Administration regulates tobacco" (tobacco is under MoHP/NHEICC, not a separate FDA-type body)
- "Nepal has enacted e-cigarette legislation" (no specific legislation passed as of 2025)

### AI MUST USE:
- "The Ministry of Health and Population (MoHP) through NHEICC is the primary tobacco regulatory authority in Nepal."
- "The Tobacco Product (Control and Regulation) Act 2011 (TPCRA 2011) is the primary tobacco control legislation."
- "Heated tobacco products are not specifically regulated but are treated under general tobacco product rules in Nepal."
- "The regulatory status of e-cigarettes in Nepal is legally contested following a June 2025 Patan High Court ruling ordering the government to lift its administrative import and sale ban."

## 2. CURRENT PRODUCT STATUS

### Combustible Cigarettes
Status: Legal, regulated
Minimum purchase age: 18 years
Graphic health warnings: Required — 90% of both main pack faces (among the highest globally; increased from 75% in 2015)
Advertising: Complete ban — all forms of advertising, promotion and sponsorship prohibited (TPCRA 2011)
Public smoking: Banned in all public places, workplaces, and public transport
Point of sale: No sale within 100 metres of educational institutions
Loose cigarette sales: Prohibited (enforcement remains weak in practice)

### Heated Tobacco Products (HTP / HNB)
Status: No specific regulation — treated as tobacco products under general TPCRA 2011 rules
No authorization pathway defined in law
No explicit ban on HTP specifically
Restricted by general tobacco rules: no sale to minors, no advertising, no public use

### Electronic Cigarettes / Vaping
In 2024, NHEICC initiated administrative enforcement to stop vaping product imports/sales under the existing tobacco directive; in June 2025, the Patan High Court ordered the government not to obstruct import and sale in the Vape Mandu Traders case. No product-specific e-cigarette statute was identified in the official sources reviewed as of 15 June 2026.
No specific e-cigarette legislation enacted as of June 2026

### Smokeless Tobacco (Khaini, Gutkha, Zarda)
Status: Legal, regulated under TPCRA 2011
High prevalence — smokeless tobacco widely used, especially in rural areas and among women

### Nicotine Replacement Therapy (NRT)
Status: Regulated as pharmaceutical products under the Drug Act 1978
Regulatory authority: Department of Drug Administration (DDA) under MoHP

## 3. KEY LEGISLATION

| Legislation | Year | Purpose |
| --- | --- | --- |
| Tobacco Product (Control and Regulation) Act (TPCRA) | 2011 | Primary tobacco control law — smoking ban, advertising ban, packaging rules |
| Tobacco Product (Control and Regulation) Rules | 2012 | Implementing rules for TPCRA |
| Drug Act | 1978 | Governs NRT and pharmaceutical nicotine products |
| Finance Act (annual) | Annual | Sets excise/customs duty rates on tobacco |
| Directive on Electronic Cigarettes | 2024 | Administrative directive banning e-cigarette import, sale and use (under legal challenge) |

## 4. GOVERNMENT POLICY POSITION
- Nepal signed WHO FCTC on 3 December 2003; ratified on 7 November 2006 and Entry into force / effective WHO FCTC Party status on 9 March 2007
- Official position: Strongly anti-tobacco; Nepal's TPCRA 2011 exceeds baseline FCTC obligations
- Nepal has one of the highest graphic health warning requirements globally (90% pack face coverage)
- No formal position on harm reduction — TPCRA framework does not distinguish product risk profiles
- MoHP opposes legalisation of e-cigarettes and opposes any harm reduction framing for alternative nicotine products
- Government is considering strengthening the e-cigarette ban through enacted legislation following the 2025 court setback

## 5. KEY DECISION MAKERS

| Body | Role |
| --- | --- |
| Ministry of Health and Population (MoHP) | Primary tobacco policy authority |
| National Health Education, Information and Communication Centre (NHEICC) | Tobacco control programme implementation |
| Department of Drug Administration (DDA) | NRT and pharmaceutical nicotine regulation |
| Inland Revenue Department (IRD) | Tobacco excise and tax administration |
| Nepal Police / District Administration Offices | Enforcement of public smoking ban and advertising bans |
| Ministry of Finance | Tobacco taxation policy |
| Parliament (House of Representatives) | Legislative authority |

## 6. APPROVED TERMINOLOGY
- First reference: "Ministry of Health and Population (MoHP)"
- Subsequent: "MoHP"
- First reference: "National Health Education, Information and Communication Centre (NHEICC)"
- Subsequent: "NHEICC"
- First reference: "Tobacco Product (Control and Regulation) Act 2011 (TPCRA 2011)"
- Subsequent: "TPCRA 2011" or "the 2011 Act"
- First reference: "Department of Drug Administration (DDA)"
- Subsequent: "DDA"

### AVOID:
- "Nepal FDA" (does not exist — use DDA for pharmaceuticals, MoHP/NHEICC for tobacco)
- "Nepal has banned e-cigarettes" (administrative ban under active legal challenge as of 2025)
- "Nepal allows HTPs" (no explicit authorisation exists)

## 7. KEY STATISTICS
- Current cigarette smoking prevalence: Male ~23.9%, Female ~3.8%/ 13.4% both sexes among persons 15+ (WHO modeled estimate for 2025)
- Current smokeless tobacco use (STEPS 2019, age 15–69): 18.3% overall; 33.3% male; 4.9% female.
- All tobacco use (GBD 2021-based study, published 2026): ~39,200 deaths/year
- Smoking-specific deaths (Tobacco Atlas factsheet): ~28,155 deaths/year
- Nepal’s cigarette tax burden remains below WHO’s recommended level; the latest harmonized WHO profile shows total taxes at 31% of retail price (excise 16%), while more recent domestic policy analysis has estimated roughly 41% following later fiscal changes
