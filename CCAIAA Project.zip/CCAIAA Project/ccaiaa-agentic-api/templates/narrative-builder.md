# Narrative Builder Template

> Category: Narrative Builder
> Output: Internal preparation material — talking points, meeting narrative, anticipated Q&A.
> Format: Clean plain-text document with a single title at the top. NOT a formal submission.

## Purpose
Produce a focused, internal-facing narrative that prepares a PMI spokesperson or
executive for a specific engagement (e.g. a meeting, interview, panel, or briefing).
The document must directly serve the stated PURPOSE/USER QUERY of the request — it is
not a generic regulatory overview and must never be structured as a formal submission.

## Structure (adaptive — keep only what the request needs)
The Narrative Builder is free-form. Choose the smallest set of sections that fully
serve the request. A typical meeting/engagement narrative uses:

1. **Title Heading** (~1 line)
   - A single clean title reflecting the engagement and topic
     (e.g. "MEETING BRIEF: View on E-Cigarettes — Health Secretary, India").
   - No metadata table, no "Submission on… Consultation" phrasing.

2. **Context & Objective** (~150 words)
   - Why this engagement is happening and what PMI wants to achieve.
   - Anchor explicitly to the user's stated purpose. State it once here only.

3. **Key Messages / Talking Points** (~500 words)
   - 4–6 distinct, concise points the spokesperson should land.
   - Each point is unique — do NOT restate the same fact across multiple points.
   - Frame around the engagement, not as a literature review.

4. **Supporting Facts & Evidence** (~300 words)
   - The specific data, legislation, and citations behind the talking points.
   - Put each fact here ONCE; talking points reference them, they do not repeat them.

5. **Anticipated Questions & Suggested Responses** (~250 words)
   - 3–5 likely questions with brief, factual suggested responses.

## Anti-duplication rules
- Each fact, statistic, or argument appears in exactly ONE section.
- Talking points and Q&A reference supporting facts; they must not re-explain them.
- The engagement purpose is stated once (Context & Objective), never repeated.

## Tone
Formal, clear, factual, internal. Concise and scannable. No promotional language.
