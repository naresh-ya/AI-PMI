# Third Party Submission Template

> Category: Third Party Submission (submission prepared for/on behalf of a third party)
> Output: Clean formal correspondence. Total target: ~800 words.

## Purpose
A formal submission framed for a third-party voice (e.g. an association or stakeholder),
addressing the authority on the topic. Reads as flowing correspondence, not a report.

## Structure (sections, in order)

1. **Address Block** (~100 words)
   - Addressed-To and CC lines only. No body content.

2. **Subject Line** (~1 line)
   - A single concise subject reflecting the submission's purpose.

3. **Letter Body** (~600 words)
   - 4–5 flowing paragraphs:
     - Opening: who is submitting and the purpose.
     - Middle: rationale and supporting evidence, each point made once.
     - Close: the specific recommendation or request.
   - No internal subheadings, metadata labels, or embedded reference list in the body.

4. **Greetings** (~50 words)
   - Closing salutation and signature block only.

## Anti-duplication rules
- The position/argument is developed once, not restated across paragraphs.
- Each fact or statistic appears once.
- Keep third-party framing consistent; do not switch to first-person PMI voice.

## Tone & citations
Formal, measured, evidence-based. Use inline [N] markers only; References appended
automatically.
