"""
Build the standalone drafter modules from the monolith `handler_drafter_new.py`.

Generates:
  core/drafter_common.py           (shared config, clients, cross-stage helpers)
  agents/master_drafter/drafter_planner.py
  agents/master_drafter/drafter_generator.py
  agents/master_drafter/drafter_assembler.py

Strategy: extract exact function/constant source ranges via AST (verbatim, no manual
transcription), prepend a hand-written import header per module. Stage modules use
`from core.drafter_common import *` (common defines an auto __all__) so every shared
name resolves — eliminating the missing-import NameError class.

Idempotent: re-running regenerates all four files from the monolith.
"""
import ast
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MONO = os.path.join(ROOT, "agents", "master_drafter", "handler_drafter_new.py")
CORE_DIR = os.path.join(ROOT, "core")
DRAFTER_DIR = os.path.join(ROOT, "agents", "master_drafter")

src = open(MONO, encoding="utf-8").read()
lines = src.splitlines(keepends=True)
tree = ast.parse(src)

# ── Build name -> (start_idx, end_lineno) maps for funcs and top-level assignments ──
func_ranges = {}
const_ranges = {}
for node in ast.iter_child_nodes(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        func_ranges[node.name] = (node.lineno - 1, node.end_lineno)
    elif isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name):
                const_ranges[t.id] = (node.lineno - 1, node.end_lineno)
    elif isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name):
            const_ranges[node.target.id] = (node.lineno - 1, node.end_lineno)


def grab_func(name):
    if name not in func_ranges:
        raise SystemExit(f"FUNC NOT FOUND: {name}")
    s, e = func_ranges[name]
    return "".join(lines[s:e]).rstrip() + "\n"


def grab_const(name):
    if name not in const_ranges:
        raise SystemExit(f"CONST NOT FOUND: {name}")
    s, e = const_ranges[name]
    return "".join(lines[s:e]).rstrip() + "\n"


# ═══════════════════════════════════════════════════════════════════════════════
# Allocation
# ═══════════════════════════════════════════════════════════════════════════════
COMMON_CONSTS = [
    "LITELLM_URL", "LITELLM_MODEL", "LLM_MODEL_REASONING", "LLM_MODEL_FAST", "LITELLM_KEY",
    "s3", "dynamodb", "requests_table", "DOCUMENT_BUCKET",
    "PROMPT_SOFT_BUDGET_TOKENS", "DEFAULT_TONE", "_CITATION_GAP_MARKERS",
    "_TEMPLATE_CACHE", "_JURISDICTION_CACHE", "JURISDICTION_CTX_MAX",
    "_CATEGORY_TEMPLATE_MAP", "_PMI_ABOUT_US",
]
COMMON_FUNCS = [
    "_extract_data_gaps", "_strip_researcher_source_markers", "_build_data_gaps_block",
    "_estimate_tokens", "_preflight_prompt_budget", "_check_response_truncation",
    "_find_templates_dir", "_load_template", "_load_jurisdiction_file",
    "_unwrap_drafter_inputs", "_draft_artifact_key", "save_draft_artifact", "load_draft_artifact",
    "load_research_data", "update_request_status",
    "clean_citation_title", "_is_letter_submission", "_canonical_citations",
    "translate_text_with_llm",
]

PLANNER_FUNCS = [
    "plan_document", "create_document_structure", "build_document_structure_llm",
    "assess_research_sufficiency",
]

GENERATOR_CONSTS = ["_STRUCTURAL_SECTION_NAMES"]
GENERATOR_FUNCS = [
    "generate_document",
    "_build_web_search_context",
    "validate_section_draft", "_llm_check_vague_citations",
    "clean_section_header", "_extract_section_template_rule",
    "_dedup_repeated_sentences", "_reconcile_citations", "_flag_duplicate_sections",
    "generate_section_content_react", "draft_single_section_worker", "eliminate_document_duplicity",
    "_section_role", "_allocate_findings_to_sections",
    "generate_document_content", "_generate_full_letter", "_agentic_review_document",
    "_build_uploaded_files_context", "_build_kb_sources_context",
    "_build_citation_registry", "_build_structured_facts_context",
    "prepare_generation_context", "generate_section_content",
    "generate_executive_summary", "generate_background_section", "generate_position_section",
    "generate_evidence_section", "generate_recommendations_section",
    "generate_implementation_section", "generate_conclusion_section",
    "extract_key_recommendations", "create_fallback_content",
]

ASSEMBLER_CONSTS = ["_QM_PLACEHOLDER_MARKERS"]
ASSEMBLER_FUNCS = [
    "assemble_document",
    "add_hyperlink", "_add_runs_with_bold", "_set_cell_shading",
    "_render_md_table", "_render_callout", "_render_rich_text",
    "_count_syllables", "_compute_readability", "_compute_structure_completeness",
    "_compute_confidence", "compute_quality_metrics",
    "llm_judge_document", "create_formatted_document", "store_document", "calculate_word_count",
]

# ═══════════════════════════════════════════════════════════════════════════════
# 1. core/drafter_common.py
# ═══════════════════════════════════════════════════════════════════════════════
COMMON_HEADER = '''"""
Drafter Common Module (shared across the three drafter stages).

Holds configuration, AWS clients, LLM/token-budget helpers, template & jurisdiction
loading (Bedrock Prompt Management with fail-open to disk), inter-stage S3 artifact
plumbing, DynamoDB status updates, translation, and small cross-stage text/citation
helpers. Every stage module does `from core.drafter_common import *`.

Generated by prompt_testing/build_drafter_modules.py from handler_drafter_new.py —
do not edit by hand; edit the monolith + regenerate, or promote a function here.
"""
import json
import logging
import re
import os
import ssl
import urllib.request
import urllib3
from datetime import datetime
from typing import Dict, Any, List

import boto3

# Suppress insecure request warnings for the internal LiteLLM proxy
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Optional Bedrock Prompt Management client (fail-open); imported lazily inside loaders.

'''

parts = [COMMON_HEADER]
parts.append("# ── Configuration ─────────────────────────────────────────────────────────────\n")
for c in ["LITELLM_URL", "LITELLM_MODEL", "LLM_MODEL_REASONING", "LLM_MODEL_FAST", "LITELLM_KEY"]:
    parts.append(grab_const(c))
parts.append("\n# ── AWS clients ───────────────────────────────────────────────────────────────\n")
for c in ["s3", "dynamodb", "requests_table", "DOCUMENT_BUCKET"]:
    parts.append(grab_const(c))
parts.append("\n# ── Constants ─────────────────────────────────────────────────────────────────\n")
for c in ["PROMPT_SOFT_BUDGET_TOKENS", "DEFAULT_TONE", "_CITATION_GAP_MARKERS",
          "_TEMPLATE_CACHE", "_JURISDICTION_CACHE", "JURISDICTION_CTX_MAX",
          "_CATEGORY_TEMPLATE_MAP", "_PMI_ABOUT_US"]:
    parts.append(grab_const(c) + "\n")
parts.append("\n# ── Shared functions ──────────────────────────────────────────────────────────\n\n")
for fn in COMMON_FUNCS:
    parts.append(grab_func(fn) + "\n\n")
parts.append("\n# Auto-export everything (including underscore-prefixed helpers) for `import *`.\n")
parts.append("__all__ = [_n for _n in dir() if not _n.startswith('__')]\n")

with open(os.path.join(CORE_DIR, "drafter_common.py"), "w", encoding="utf-8") as f:
    f.write("".join(parts))
print("wrote core/drafter_common.py")


# ═══════════════════════════════════════════════════════════════════════════════
# Stage module writer
# ═══════════════════════════════════════════════════════════════════════════════
def stage_header(docstring, extra_imports=""):
    return f'''"""
{docstring}

Generated by prompt_testing/build_drafter_modules.py from handler_drafter_new.py.
Fully standalone: imports only from core.drafter_common (+ stdlib / third-party).
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, Any, List

import boto3
{extra_imports}
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.drafter_common import *  # noqa: F401,F403  (shared config, clients, helpers)

'''


def write_stage(filename, docstring, consts, funcs, extra_imports=""):
    body = [stage_header(docstring, extra_imports)]
    if consts:
        body.append("# ── Module-level constants ────────────────────────────────────────────────────\n")
        for c in consts:
            body.append(grab_const(c) + "\n")
        body.append("\n")
    for fn in funcs:
        body.append(grab_func(fn) + "\n\n")
    with open(os.path.join(DRAFTER_DIR, filename), "w", encoding="utf-8") as f:
        f.write("".join(body))
    print(f"wrote agents/master_drafter/{filename}")


write_stage(
    "drafter_planner.py",
    "Drafter Stage 1 — PLANNER. Loads research data + builds the document structure "
    "(LLM outline with deterministic fallback) + advisory sufficiency assessment.",
    [], PLANNER_FUNCS,
)

write_stage(
    "drafter_generator.py",
    "Drafter Stage 2 — GENERATOR. Sequential section generation (or single-call letter), "
    "internal review, dedup, citation registry, and grounding-context assembly.",
    GENERATOR_CONSTS, GENERATOR_FUNCS,
)

write_stage(
    "drafter_assembler.py",
    "Drafter Stage 3 — ASSEMBLER (terminal). Translation, .docx formatting, S3 store, "
    "quality metrics + LLM judge, DynamoDB DRAFTING_COMPLETED, canonical drafting_result.",
    ASSEMBLER_CONSTS, ASSEMBLER_FUNCS,
    extra_imports=(
        "from docx import Document\n"
        "from docx.shared import Inches, Pt, RGBColor\n"
        "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
        "import io\n"
        "import base64\n"
    ),
)

print("\nDone. Now run: python prompt_testing/check_drafter_names.py")
