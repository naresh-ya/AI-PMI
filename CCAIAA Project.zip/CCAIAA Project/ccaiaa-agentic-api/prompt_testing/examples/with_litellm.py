"""
Example: End-to-end integration with LiteLLM
"""
import sys
import io
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

from prompt_manager import PromptManager, PromptManagerConfig


def example_simple_execution():
    """Simple end-to-end execution"""
    print("=" * 80)
    print("EXAMPLE: Simple End-to-End Execution")
    print("=" * 80)

    # Initialize
    pm = PromptManager()

    # Define input
    test_text = """
    Philip Morris International is transforming the tobacco industry through innovative
    smoke-free products. The company's IQOS heat-not-burn technology represents a shift
    away from traditional cigarettes toward potentially reduced-risk alternatives. This
    transformation requires significant investment in research and development, manufacturing
    capabilities, and regulatory engagement across multiple markets worldwide.
    """

    print("\n📝 Input Text:")
    print(f"   {test_text.strip()[:100]}...")

    # Execute prompt
    print("\n🚀 Executing prompt 'test-prompt-01' with LiteLLM...")

    result = pm.execute_prompt(
        prompt_name='test-prompt-01',
        variables={'input_text': test_text.strip()},
        temperature=0.7,
        max_tokens=2000
    )

    if result:
        print("\n" + "=" * 80)
        print("✅ RESULT:")
        print("=" * 80)
        print(result)
        print("=" * 80)
    else:
        print("\n❌ Failed to execute prompt")


def example_manual_flow():
    """Manual step-by-step flow"""
    print("\n" + "=" * 80)
    print("EXAMPLE: Manual Step-by-Step Flow")
    print("=" * 80)

    pm = PromptManager()

    # Step 1: Fetch prompt
    print("\n📥 Step 1: Fetching prompt...")
    prompt_data = pm.get_prompt('test-prompt-01')

    if not prompt_data:
        print("❌ Failed to fetch prompt")
        return

    print(f"✅ Fetched: {prompt_data['name']}")

    # Step 2: Prepare variables
    print("\n📝 Step 2: Preparing variables...")
    variables = {
        'input_text': "Artificial Intelligence is revolutionizing business operations."
    }
    print(f"✅ Variables: {list(variables.keys())}")

    # Step 3: Substitute
    print("\n🔄 Step 3: Substituting variables...")
    final_prompt = pm.substitute_variables(prompt_data['template'], variables)
    print(f"✅ Substituted (length: {len(final_prompt)} chars)")

    # Step 4: Call LiteLLM manually
    print("\n🚀 Step 4: Calling LiteLLM...")
    result = pm._call_litellm(final_prompt, temperature=0.7, max_tokens=2000)

    if result:
        print("\n✅ SUCCESS!")
        print("\nResult:")
        print("-" * 80)
        print(result)
        print("-" * 80)
    else:
        print("❌ LiteLLM call failed")


def example_batch_processing():
    """Process multiple texts"""
    print("\n" + "=" * 80)
    print("EXAMPLE: Batch Processing Multiple Texts")
    print("=" * 80)

    pm = PromptManager()

    texts = [
        "Cloud computing has revolutionized how businesses store and process data.",
        "Blockchain technology provides secure and transparent transaction records.",
        "Quantum computing promises exponential increases in processing power."
    ]

    print(f"\n📦 Processing {len(texts)} texts...\n")

    for i, text in enumerate(texts, 1):
        print(f"Text {i}: {text[:50]}...")

        result = pm.execute_prompt(
            prompt_name='test-prompt-01',
            variables={'input_text': text},
            temperature=0.7
        )

        if result:
            print(f"✅ Summary: {result[:100]}...")
        else:
            print(f"❌ Failed")

        print()


def example_with_metrics():
    """Execute and view metrics"""
    print("\n" + "=" * 80)
    print("EXAMPLE: Execution with Metrics")
    print("=" * 80)

    # Config with metrics file
    config = PromptManagerConfig(
        metrics_output_file='./metrics/litellm_execution.jsonl'
    )

    pm = PromptManager(config)

    print("\n🚀 Executing prompt...")

    result = pm.execute_prompt(
        prompt_name='test-prompt-01',
        variables={
            'input_text': "Machine learning enables computers to learn from data."
        }
    )

    print(f"\n{'✅' if result else '❌'} Execution {'completed' if result else 'failed'}")

    # View metrics
    print("\n📊 Metrics Summary:")
    summary = pm.get_metrics_summary()

    if 'metrics' in summary:
        metrics = summary['metrics']
        print(f"   Executions: {metrics['total_executions']}")
        print(f"   Fetches: {metrics['total_fetches']}")
        print(f"   Cache hits: {metrics['cache_hits']}")
        print(f"   Average latency: {metrics['average_latency_ms']}ms")
        print(f"   Errors: {metrics['errors']}")

    if config.metrics_output_file:
        print(f"\n📄 Detailed metrics saved to: {config.metrics_output_file}")


def example_error_handling():
    """Demonstrate error handling"""
    print("\n" + "=" * 80)
    print("EXAMPLE: Error Handling")
    print("=" * 80)

    pm = PromptManager()

    # Try non-existent prompt
    print("\n🔍 Trying non-existent prompt...")
    result = pm.get_prompt('non-existent-prompt')

    if result:
        print("✅ Found")
    else:
        print("❌ Not found (expected)")

    # Try execution with missing variables
    print("\n🔍 Trying execution with missing variables...")
    prompt_data = pm.get_prompt('test-prompt-01')

    if prompt_data:
        try:
            # Not providing required variable
            final_prompt = pm.substitute_variables(
                prompt_data['template'],
                {},  # Empty variables
                strict=True  # Will raise error
            )
            print("✅ Substituted")
        except ValueError as e:
            print(f"❌ Error (expected): {e}")


if __name__ == "__main__":
    try:
        example_simple_execution()
        example_manual_flow()
        example_batch_processing()
        example_with_metrics()
        example_error_handling()

        print("\n" + "=" * 80)
        print("✅ ALL LITELLM EXAMPLES COMPLETED")
        print("=" * 80)

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
