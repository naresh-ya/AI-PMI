"""
Example: Basic usage of PromptManager
"""
import sys
import io
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

from prompt_manager import PromptManager, PromptManagerConfig


def example_basic_usage():
    """Basic usage: Fetch and display a prompt"""
    print("=" * 80)
    print("EXAMPLE 1: Basic Prompt Fetching")
    print("=" * 80)

    # Initialize with default config
    pm = PromptManager()

    # Fetch a prompt
    print("\n📥 Fetching prompt 'test-prompt-01'...")
    prompt_data = pm.get_prompt('test-prompt-01')

    if prompt_data:
        print("✅ Prompt fetched successfully!")
        print(f"\n   Name: {prompt_data['name']}")
        print(f"   Description: {prompt_data['description']}")
        print(f"   Variables: {', '.join(prompt_data['variables'])}")
        print(f"   Last Updated: {prompt_data['updated_at']}")
        print(f"\n   Template Preview (first 200 chars):")
        print(f"   {prompt_data['template'][:200]}...")
    else:
        print("❌ Failed to fetch prompt")


def example_with_custom_config():
    """Example with custom configuration"""
    print("\n" + "=" * 80)
    print("EXAMPLE 2: Custom Configuration")
    print("=" * 80)

    # Create custom config
    config = PromptManagerConfig(
        cache_ttl_seconds=120,  # 2 minutes cache
        log_level='DEBUG',
        metrics_output_file='./metrics/basic_usage.jsonl'
    )

    pm = PromptManager(config)

    print("\n✅ PromptManager initialized with custom config")
    print(f"   Cache TTL: {config.cache_ttl_seconds}s")
    print(f"   Log Level: {config.log_level}")
    print(f"   Metrics File: {config.metrics_output_file}")


def example_list_prompts():
    """Example: List all available prompts"""
    print("\n" + "=" * 80)
    print("EXAMPLE 3: List All Prompts")
    print("=" * 80)

    pm = PromptManager()

    print("\n📋 Listing all prompts...")
    prompts = pm.list_prompts()

    if prompts:
        print(f"✅ Found {len(prompts)} prompt(s):\n")
        for prompt in prompts:
            print(f"   • {prompt['name']}")
            print(f"     ID: {prompt['id']}")
            print(f"     Updated: {prompt['updated_at']}\n")
    else:
        print("❌ No prompts found")


def example_variable_substitution():
    """Example: Variable substitution"""
    print("\n" + "=" * 80)
    print("EXAMPLE 4: Variable Substitution")
    print("=" * 80)

    pm = PromptManager()

    # Fetch prompt
    prompt_data = pm.get_prompt('test-prompt-01')

    if not prompt_data:
        print("❌ Failed to fetch prompt")
        return

    print(f"\n📝 Template has variables: {', '.join(prompt_data['variables'])}")

    # Define variable values
    variables = {
        'input_text': "Machine learning is transforming industries worldwide."
    }

    print(f"\n🔄 Substituting variables...")
    final_prompt = pm.substitute_variables(prompt_data['template'], variables)

    print("✅ Variables substituted!")
    print(f"\n   Final prompt (first 300 chars):")
    print(f"   {final_prompt[:300]}...")


def example_cache_demonstration():
    """Example: Demonstrate caching"""
    print("\n" + "=" * 80)
    print("EXAMPLE 5: Cache Demonstration")
    print("=" * 80)

    pm = PromptManager()

    prompt_name = 'test-prompt-01'

    print(f"\n⏱️  First fetch (cold - from AWS)...")
    prompt1 = pm.get_prompt(prompt_name)
    print(f"   Fetched: {prompt1['name'] if prompt1 else 'Failed'}")

    print(f"\n⏱️  Second fetch (warm - from cache)...")
    prompt2 = pm.get_prompt(prompt_name)
    print(f"   Fetched: {prompt2['name'] if prompt2 else 'Failed'}")

    print(f"\n📊 Cache Statistics:")
    stats = pm.get_metrics_summary()
    if 'cache' in stats:
        cache_stats = stats['cache']
        print(f"   Cache hits: {cache_stats['hits']}")
        print(f"   Cache misses: {cache_stats['misses']}")
        print(f"   Hit rate: {cache_stats['hit_rate_percent']}%")
        print(f"   Cache size: {cache_stats['size']}/{cache_stats['max_size']}")


def example_metrics():
    """Example: View metrics"""
    print("\n" + "=" * 80)
    print("EXAMPLE 6: Metrics Summary")
    print("=" * 80)

    pm = PromptManager()

    # Perform some operations
    pm.get_prompt('test-prompt-01')
    pm.get_prompt('test-prompt-01')  # Cache hit
    pm.list_prompts()

    print("\n📊 Metrics Summary:")
    summary = pm.get_metrics_summary()

    if 'metrics' in summary:
        metrics = summary['metrics']
        print(f"   Total fetches: {metrics['total_fetches']}")
        print(f"   Cache hits: {metrics['cache_hits']}")
        print(f"   Cache misses: {metrics['cache_misses']}")
        print(f"   Cache hit rate: {metrics['cache_hit_rate_percent']}%")
        print(f"   Average latency: {metrics['average_latency_ms']}ms")
        print(f"   Errors: {metrics['errors']}")


if __name__ == "__main__":
    try:
        example_basic_usage()
        example_with_custom_config()
        example_list_prompts()
        example_variable_substitution()
        example_cache_demonstration()
        example_metrics()

        print("\n" + "=" * 80)
        print("✅ ALL EXAMPLES COMPLETED")
        print("=" * 80)

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
