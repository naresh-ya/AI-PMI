# Prompt Manager - Production Library

Production-grade library for managing prompts with AWS Bedrock Prompt Management and LiteLLM integration.

## Features

✅ **Centralized Prompt Management** - Store prompts in AWS Bedrock Prompt Management  
✅ **Smart Caching** - LRU cache with configurable TTL  
✅ **Metrics & Monitoring** - Track usage, latency, errors  
✅ **Fallback Support** - Local backup when AWS unavailable  
✅ **LiteLLM Integration** - Direct integration with your LiteLLM proxy  
✅ **Configuration Management** - Environment-based configs (dev/prod)  
✅ **Error Handling** - Graceful degradation and retry logic  

---

## Installation

```bash
# Install dependencies
pip install -r requirements.txt

# Verify AWS credentials
aws sts get-caller-identity
```

---

## Quick Start

### Basic Usage

```python
from prompt_manager import PromptManager

# Initialize
pm = PromptManager()

# Fetch a prompt
prompt_data = pm.get_prompt('test-prompt-01')

# Substitute variables
variables = {'input_text': 'Your text here'}
final_prompt = pm.substitute_variables(prompt_data['template'], variables)

# Execute with LiteLLM (one-liner)
result = pm.execute_prompt(
    prompt_name='test-prompt-01',
    variables={'input_text': 'Your text here'}
)
```

### With Custom Configuration

```python
from prompt_manager import PromptManager, PromptManagerConfig

# Development config (shorter cache, debug logging)
config = PromptManagerConfig.dev_config()
pm = PromptManager(config)

# Production config (longer cache, less logging)
config = PromptManagerConfig.prod_config()
pm = PromptManager(config)

# Custom config
config = PromptManagerConfig(
    cache_ttl_seconds=600,  # 10 minutes
    log_level='INFO',
    metrics_output_file='./metrics/app.jsonl',
    fallback_directory='./fallbacks'
)
pm = PromptManager(config)
```

---

## Configuration Options

### Environment Variables

```bash
# AWS Configuration
export AWS_REGION=eu-west-1
export AWS_PROFILE=pmi-dev-developer

# Cache Settings
export PROMPT_CACHE_ENABLED=true
export PROMPT_CACHE_TTL=300  # seconds

# Metrics
export PROMPT_METRICS_ENABLED=true
export PROMPT_METRICS_FILE=./metrics/prompts.jsonl

# Fallback
export PROMPT_FALLBACK_ENABLED=true
export PROMPT_FALLBACK_DIR=./fallbacks

# LiteLLM
export LITELLM_ENDPOINT=https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions
export LITELLM_MODEL=anthropic.claude-3-haiku-20240307-v1:0
export AWS_BEARER_TOKEN_BEDROCK=your-token-here

# Logging
export LOG_LEVEL=INFO
```

### Configuration Presets

```python
# Development (fast iteration)
config = PromptManagerConfig.dev_config()
# - Cache TTL: 60 seconds
# - Log level: DEBUG

# Production (performance optimized)
config = PromptManagerConfig.prod_config()
# - Cache TTL: 600 seconds
# - Log level: WARNING

# From environment variables
config = PromptManagerConfig.from_env()
```

---

## API Reference

### PromptManager

#### `get_prompt(prompt_name: str, use_cache: bool = True)`
Fetch prompt from AWS Bedrock Prompt Management.

**Returns:** Dictionary with prompt data or None

```python
prompt_data = pm.get_prompt('test-prompt-01')
# {
#   'id': '2F03RUK8GM',
#   'name': 'test-prompt-01',
#   'description': 'Test prompt...',
#   'template': 'You are a...',
#   'variables': ['input_text'],
#   'created_at': '2026-06-29...',
#   'updated_at': '2026-06-29...',
#   'version': '1'
# }
```

#### `execute_prompt(prompt_name: str, variables: Dict, temperature: float = 0.7, max_tokens: int = 2000)`
Execute prompt end-to-end: fetch, substitute, call LiteLLM.

**Returns:** Model response string or None

```python
result = pm.execute_prompt(
    prompt_name='test-prompt-01',
    variables={'input_text': 'Your text here'},
    temperature=0.7,
    max_tokens=2000
)
```

#### `substitute_variables(template: str, variables: Dict, strict: bool = False)`
Substitute {{variables}} in template.

**Args:**
- `strict`: If True, raises error on missing variables

```python
final_prompt = pm.substitute_variables(
    template='Hello {{name}}',
    variables={'name': 'World'}
)
# 'Hello World'
```

#### `list_prompts()`
List all available prompts from AWS.

```python
prompts = pm.list_prompts()
# [{'id': '...', 'name': 'test-prompt-01', ...}, ...]
```

#### `invalidate_cache(prompt_name: Optional[str] = None)`
Invalidate cache for specific prompt or clear all.

```python
pm.invalidate_cache('test-prompt-01')  # Specific prompt
pm.invalidate_cache()  # Clear all
```

#### `get_metrics_summary()`
Get cache and metrics summary.

```python
summary = pm.get_metrics_summary()
# {
#   'cache': {'hits': 10, 'misses': 2, 'hit_rate_percent': 83.33, ...},
#   'metrics': {'total_fetches': 12, 'average_latency_ms': 145.5, ...}
# }
```

---

## Examples

### Example 1: Simple Summarization

```python
from prompt_manager import PromptManager

pm = PromptManager()

text = "Your long text here..."

result = pm.execute_prompt(
    prompt_name='test-prompt-01',
    variables={'input_text': text}
)

print(result)  # Bullet point summary
```

### Example 2: Batch Processing

```python
pm = PromptManager()

texts = ["Text 1...", "Text 2...", "Text 3..."]

for text in texts:
    result = pm.execute_prompt(
        prompt_name='test-prompt-01',
        variables={'input_text': text}
    )
    print(result)
```

### Example 3: With Error Handling

```python
pm = PromptManager()

try:
    result = pm.execute_prompt(
        prompt_name='my-prompt',
        variables={'input': 'data'}
    )

    if result:
        print("Success:", result)
    else:
        print("Failed to execute")

except Exception as e:
    print(f"Error: {e}")
```

### Example 4: Monitoring & Metrics

```python
config = PromptManagerConfig(
    metrics_enabled=True,
    metrics_output_file='./metrics/app.jsonl'
)

pm = PromptManager(config)

# Perform operations...
pm.execute_prompt('test-prompt-01', {'input_text': '...'})

# View summary
summary = pm.get_metrics_summary()
print(f"Cache hit rate: {summary['cache']['hit_rate_percent']}%")
print(f"Average latency: {summary['metrics']['average_latency_ms']}ms")
```

---

## Integration with Existing Code

### Replace Hardcoded Prompts

**Before:**
```python
system_prompt = """You are an expert assistant..."""

messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": user_input}
]
```

**After:**
```python
from prompt_manager import PromptManager

pm = PromptManager()

# Fetch from AWS
prompt_data = pm.get_prompt('my-system-prompt')
system_prompt = pm.substitute_variables(
    prompt_data['template'],
    {'context': 'some context'}
)

messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": user_input}
]
```

### Integration with Your web_search_testing.py

```python
from prompt_manager import PromptManager

pm = PromptManager()

def run_agent(user_query: str):
    # Fetch system prompt from AWS instead of hardcoding
    prompt_data = pm.get_prompt('policy-research-agent-prompt')

    system_prompt = pm.substitute_variables(
        prompt_data['template'],
        {'date': '2026-06-29', 'domains': ', '.join(TARGET_DOMAINS)}
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_query}
    ]

    # Rest of your code...
```

---

## Testing

### Run Examples

```bash
# Basic usage examples
python examples/basic_usage.py

# LiteLLM integration examples
python examples/with_litellm.py
```

### Run Tests

```bash
# Install test dependencies
pip install pytest pytest-cov

# Run tests
pytest tests/ -v

# With coverage
pytest tests/ --cov=prompt_manager --cov-report=html
```

---

## Metrics & Monitoring

### Metrics Output Format

When `metrics_output_file` is configured, each operation is logged as JSON:

```json
{
  "timestamp": "2026-06-29T10:30:00.000Z",
  "prompt_name": "test-prompt-01",
  "operation": "execute",
  "latency_ms": 145.5,
  "error": null,
  "metadata": null
}
```

### Available Operations

- `fetch` - Fetch from AWS
- `execute` - End-to-end execution
- `cache_hit` - Served from cache
- `cache_miss` - Not in cache
- `error` - Operation failed

### Viewing Metrics

```python
# Get summary
summary = pm.get_metrics_summary()

# Cache statistics
print(summary['cache'])
# {
#   'hits': 10,
#   'misses': 2,
#   'evictions': 0,
#   'expirations': 1,
#   'size': 5,
#   'max_size': 100,
#   'hit_rate_percent': 83.33
# }

# Metrics summary
print(summary['metrics'])
# {
#   'total_fetches': 12,
#   'total_executions': 8,
#   'cache_hits': 10,
#   'cache_misses': 2,
#   'errors': 0,
#   'cache_hit_rate_percent': 83.33,
#   'average_latency_ms': 145.5,
#   'total_metrics': 32
# }
```

---

## Best Practices

### 1. Use Appropriate Cache TTL

```python
# Development: Short TTL for frequent prompt updates
config = PromptManagerConfig(cache_ttl_seconds=60)

# Production: Longer TTL for stability
config = PromptManagerConfig(cache_ttl_seconds=600)
```

### 2. Enable Fallback for Critical Applications

```python
config = PromptManagerConfig(
    fallback_enabled=True,
    fallback_directory='./prompt_fallbacks'
)
```

### 3. Monitor Metrics in Production

```python
config = PromptManagerConfig(
    metrics_enabled=True,
    metrics_output_file='/var/log/prompts/metrics.jsonl'
)

# Periodically check
summary = pm.get_metrics_summary()
if summary['metrics']['errors'] > 10:
    alert_team()
```

### 4. Use Environment-Based Configs

```python
# .env.development
PROMPT_CACHE_TTL=60
LOG_LEVEL=DEBUG

# .env.production
PROMPT_CACHE_TTL=600
LOG_LEVEL=WARNING

# In code
config = PromptManagerConfig.from_env()
```

---

## Troubleshooting

### Issue: "Prompt not found"

**Solution:** Check prompt exists in AWS
```bash
python -c "from prompt_manager import PromptManager; print(PromptManager().list_prompts())"
```

### Issue: "AWS credentials invalid"

**Solution:** Refresh AWS SSO session
```bash
aws sso login
aws sts get-caller-identity
```

### Issue: "LiteLLM call failed"

**Solution:** Verify endpoint and token
```bash
echo $AWS_BEARER_TOKEN_BEDROCK
echo $LITELLM_ENDPOINT
```

### Issue: "Cache not working"

**Solution:** Check cache is enabled
```python
pm = PromptManager()
print(pm.config.cache_enabled)  # Should be True
print(pm.cache.get_stats())  # View cache stats
```

---

## Architecture

```
┌─────────────────────────────────┐
│  Your Application               │
└────────────┬────────────────────┘
             │
             ↓
┌─────────────────────────────────┐
│  PromptManager                  │
│  - get_prompt()                 │
│  - execute_prompt()             │
│  - substitute_variables()       │
└─────┬──────┬──────┬─────────────┘
      │      │      │
      ↓      ↓      ↓
   ┌────┐ ┌─────┐ ┌────────┐
   │AWS │ │Cache│ │Metrics │
   └────┘ └─────┘ └────────┘
      │
      ↓
┌─────────────────────────────────┐
│  LiteLLM Proxy                  │
└─────────────────────────────────┘
      │
      ↓
┌─────────────────────────────────┐
│  Claude (Bedrock)               │
└─────────────────────────────────┘
```

---

## Support

For issues or questions:
1. Check this README
2. Review examples in `examples/`
3. Check configuration in `prompt_manager/config.py`
4. Contact: Your Team

---

## License

Internal PMI use only.
