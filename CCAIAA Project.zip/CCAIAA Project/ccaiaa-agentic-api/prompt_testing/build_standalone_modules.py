"""
Build fully standalone researcher modules from extracted functions.
Each module gets proper imports from core/researcher_common.py and is self-contained.
"""
import os

EXTRACTED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "extracted")
RESEARCHER_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                              "agents", "master_researcher")


def read_extracted(name):
    path = os.path.join(EXTRACTED, f"{name}_functions.py")
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()


# ══════════════════════════════════════════════════════════════════════════════
# FILE PROCESSOR
# ══════════════════════════════════════════════════════════════════════════════
file_proc_header = '''"""
Researcher File Processor Module (fully standalone).

Provides: read_uploaded_file(), summarize_uploaded_file_with_llm()
"""
import io
import json
import logging
import os
import re
import ssl
import urllib.request
from datetime import datetime
from typing import Dict, Any, List

import boto3

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    DOCUMENT_BUCKET, get_s3_client,
)

s3 = get_s3_client()

'''

with open(os.path.join(RESEARCHER_DIR, "researcher_file_processor.py"), 'w', encoding='utf-8') as f:
    f.write(file_proc_header)
    f.write(read_extracted("file_processor"))
print("researcher_file_processor.py: WRITTEN")


# ══════════════════════════════════════════════════════════════════════════════
# KB SEARCH
# ══════════════════════════════════════════════════════════════════════════════
kb_header = '''"""
Researcher KB Search Module (fully standalone).

Provides: search_internal_knowledge(), stage_kb()
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from typing import Dict, Any, List

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    LLM_MODEL_FAST, _llm_call_json, _tokenize_relevance,
)

try:
    from core.kb_integration_new import search_pmi_knowledge_base
except ImportError:
    logger.warning("Could not import search_pmi_knowledge_base")
    search_pmi_knowledge_base = None

'''

with open(os.path.join(RESEARCHER_DIR, "researcher_kb.py"), 'w', encoding='utf-8') as f:
    f.write(kb_header)
    f.write(read_extracted("kb"))
print("researcher_kb.py: WRITTEN")


# ══════════════════════════════════════════════════════════════════════════════
# WEB SEARCH
# ══════════════════════════════════════════════════════════════════════════════
web_header = '''"""
Researcher Web Search Module (fully standalone).

Provides: search_web_tavily(), stage_web(), run_web_search_stage(),
summarize_web_content_with_llm(), and Tavily/Gemini helpers.
"""
import json
import logging
import os
import re
import ssl
import urllib.request
import urllib.error
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, Any, List

import boto3

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    LITELLM_RERANK_URL, LITELLM_RERANK_MODEL,
    LLM_MODEL_FAST, TAVILY_API_KEY, GEMINI_MODEL,
    ENABLE_GEMINI_COMPARISON, DOCUMENT_BUCKET,
    _llm_call_json, _rerank_sources,
)

# Thread-safe Gemini comparison store (evaluation only)
_gemini_comparison_store: Dict[str, Any] = {}
_gemini_comparison_lock = threading.Lock()

'''

with open(os.path.join(RESEARCHER_DIR, "researcher_web.py"), 'w', encoding='utf-8') as f:
    f.write(web_header)
    f.write(read_extracted("web"))
print("researcher_web.py: WRITTEN")


# ══════════════════════════════════════════════════════════════════════════════
# CURATED LINKS
# ══════════════════════════════════════════════════════════════════════════════
curated_header = '''"""
Researcher Curated Links Module (fully standalone).

Provides: fetch_internal_weblinks(), stage_curated(), _llm_select_curated_links()
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from typing import Dict, Any, List

import boto3

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    LITELLM_RERANK_URL, LITELLM_RERANK_MODEL, TAVILY_API_KEY,
    _llm_call_json, get_dynamodb_resource,
)

dynamodb = get_dynamodb_resource()
curated_links_table = dynamodb.Table(os.environ.get('CURATED_LINKS_TABLE', 'pmi-agentic-ai-curated-links'))

'''

with open(os.path.join(RESEARCHER_DIR, "researcher_curated.py"), 'w', encoding='utf-8') as f:
    f.write(curated_header)
    f.write(read_extracted("curated"))
print("researcher_curated.py: WRITTEN")


# ══════════════════════════════════════════════════════════════════════════════
# USER SOURCES
# ══════════════════════════════════════════════════════════════════════════════
user_sources_header = '''"""
Researcher User Sources Module (fully standalone).

Provides: stage_user_sources(), fetch_user_external_links()
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, Any, List

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    GEMINI_MODEL, _llm_call_json,
)

# Import file processor for fallback file read
try:
    from researcher_file_processor import read_uploaded_file
except ImportError:
    from agents.master_researcher.researcher_file_processor import read_uploaded_file

'''

with open(os.path.join(RESEARCHER_DIR, "researcher_user_sources.py"), 'w', encoding='utf-8') as f:
    f.write(user_sources_header)
    f.write(read_extracted("user_sources"))
print("researcher_user_sources.py: WRITTEN")


# ══════════════════════════════════════════════════════════════════════════════
# SYNTHESIS
# ══════════════════════════════════════════════════════════════════════════════
synthesis_header = '''"""
Researcher Synthesis Module (fully standalone).

Provides: stage_synthesis(), stage_synthesis_from_parallel(), build_research_output(),
finalize_research_results(), synthesize_research_findings(), etc.
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, Any, List, Optional

import boto3

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    LLM_MODEL_REASONING, LLM_MODEL_FAST,
    LITELLM_RERANK_URL, LITELLM_RERANK_MODEL, RERANK_MIN_SCORE,
    DOCUMENT_BUCKET, JURISDICTION_CTX_MAX, DEFAULT_TONE,
    PROMPT_SOFT_BUDGET_TOKENS,
    _llm_call_json, _rerank_sources, _estimate_tokens,
    _preflight_prompt_budget, _check_response_truncation,
    _tokenize_relevance, get_s3_client, get_dynamodb_resource,
)

s3 = get_s3_client()
dynamodb = get_dynamodb_resource()
requests_table = dynamodb.Table(os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests'))

'''

with open(os.path.join(RESEARCHER_DIR, "researcher_synthesis.py"), 'w', encoding='utf-8') as f:
    f.write(synthesis_header)
    f.write(read_extracted("synthesis"))
print("researcher_synthesis.py: WRITTEN")

print("\nAll 6 standalone modules built.")
