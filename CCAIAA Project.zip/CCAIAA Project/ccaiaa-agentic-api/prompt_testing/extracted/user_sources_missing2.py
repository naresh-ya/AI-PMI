def _compute_description_score(topic: str, text: str) -> float:
    """
    Fallback relevance score (0.0–0.95) when Tavily domain search returns no result.
    Measures word overlap between request topic and a given text.

    Each matching meaningful word contributes 0.25, capped at 0.95.
    Returns a float on the same 0–1 scale as Tavily and KB scores.
    """
    _STOP = {
        'a', 'an', 'the', 'of', 'in', 'on', 'for', 'to', 'and', 'or',
        'with', 'is', 'are', 'at', 'by', 'its', 'this', 'that', 'as',
    }
    topic_words = {
        w for w in re.split(r'[\s,;.()\-]+', (topic or '').lower())
        if len(w) > 2 and w not in _STOP
    }
    text_words = {
        w for w in re.split(r'[\s,;.()\-]+', (text or '').lower())
        if len(w) > 2 and w not in _STOP
    }
    if not topic_words:
        return 0.0
    overlap = len(topic_words & text_words)
    return round(min(overlap * 0.25, 0.95), 3)


def _gemini_extract_urls(urls: List[str]) -> Dict[str, str]:
    """
    Extract content from URLs using Gemini url_context tool.
    
    This is the central Gemini extraction function used by:
    - External links (user-provided URLs)
    - Internal links (after Tavily ranking)
    - Web search (after Tavily URL discovery)
    
    Returns {url: content} dict.
    Runs extractions in parallel (max 5 workers).
    """
    if not urls or not LITELLM_KEY:
        return {}
    
    result: Dict[str, str] = {}
    
    def _extract_one(url: str) -> tuple:
        try:
            g = _gemini_url_context(url)
            if g.get('accessible') == 'yes' and g.get('content'):
                return url, g['content']
            else:
                logger.warning(
                    f"GEMINI_EXTRACT | url='{url[:60]}' | status={g['retrieval_status']} | error={g.get('error','')}"
                )
                return url, ''
        except Exception as e:
            logger.warning(f"GEMINI_EXTRACT | url='{url[:60]}' failed: {e}")
            return url, ''
    
    with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as executor:
        futures = {executor.submit(_extract_one, u): u for u in urls}
        for future in as_completed(futures):
            url, content = future.result()
            if content:
                result[url] = content
    
    logger.info(f"GEMINI_EXTRACT | requested={len(urls)} | succeeded={len(result)}")
    return result


def _tavily_search_domain(query: str, url: str) -> Dict[str, Any]:
    """
    Search Tavily within a specific domain and return the top result.
    Routes queries through the private VPC LiteLLM proxy if available.
    """
    if not query or not url:
        return {}
        
    try:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        # Detect private Bedrock / VPC gateway environment variables
        litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
        use_private_gateway = bool(litellm_key)

        if use_private_gateway:
            # Route through corporate VPC proxy. Search-tool name is team-scoped:
            # this key is only authorized for 'ccaiaa-dev-tavily' (plain 'tavily' -> 403).
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload_data = {
                "query": query,
                "max_results": 1,
                "search_depth": "advanced",
                "include_domains": [domain]
            }
        else:
            # Local developer laptop fallback to public API
            if not TAVILY_API_KEY:
                logger.warning("TAVILY_API_KEY not configured; skipping domain search.")
                return {}
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload_data = {
                "api_key": TAVILY_API_KEY,
                "query": query,
                "search_depth": "advanced",
                "include_domains": [domain],
                "max_results": 1,
            }

        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload_data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        results = data.get('results', [])
        if not results:
            logger.info(f"TAVILY_DOMAIN_SEARCH | no results | domain={domain}")
            return {}

        top = results[0]
        score = round(min(float(top.get('score', 0.0)), 1.0), 3)
        # Gateway returns 'snippet'; public Tavily returns 'content' — accept both.
        content = (top.get('content') or top.get('snippet') or '').strip()
        result = {
            'domain':  domain,
            'url':     top.get('url', url),
            'title':   (top.get('title') or '').strip(),
            'content': content,
            'score':   score,
        }
        logger.info(f"TAVILY_DOMAIN_SEARCH | domain={domain} | score={score} | content_chars={len(content)} | title='{result['title'][:60]}'")
        return result
        
    except Exception as e:
        logger.warning(f"Tavily domain search failed for '{url[:60]}': {e}")
        return {}


def summarize_web_content_with_llm(text: str, requirements: Dict[str, Any], source_url: str) -> str:
    """Uses Bedrock (via LiteLLM) to perform Query-Focused Summarization (QFS) on raw web content."""
    if not LITELLM_KEY or not text.strip():
        return text[:1500] # Safe fallback
        
    topic = requirements.get('topic', 'General Regulatory Topic')
    background = requirements.get('background', '')
    jurisdiction = requirements.get('jurisdiction', 'Global')
    target_audience = requirements.get('target_audience', 'General')
    target_lang = requirements.get('target_language', 'English')
    category = requirements.get('category', '')
    use_case = requirements.get('use_case', '')
    
    # Detect if this is a Letters scenario
    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()
    is_letter = 'letter' in cat_lower or 'letter' in uc_lower
    
    extra_context = ""
    if is_letter:
        subject = requirements.get('topic_of_letter') or requirements.get('topicOfLetter') or ''
        if subject:
            extra_context = f"\n- Subject of the Letter: {subject}"
            
    prompt = (
        "You are an expert corporate regulatory research assistant.\n"
        "Your task is to analyze raw text scraped from a webpage and produce a dense, highly focused summary "
        "tailored specifically to the following research query.\n\n"
        "RESEARCH REQUEST CONTEXT:\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Topic: {topic}\n"
        f"- Target Audience: {target_audience}\n"
        f"- Background Context: {background or 'N/A'}{extra_context}\n\n"
        f"SOURCE WEBPAGE URL: {source_url}\n\n"
        "RAW WEBPAGE CONTENT:\n"
        f"<webpage_content>\n{text}\n</webpage_content>\n\n"
        "INSTRUCTIONS:\n"
        "1. Identify and extract only key findings, statistics, official dates, and compliance mandates "
        "relevant to this specific research request.\n"
        "2. Strip out all noise (cookies notices, ads, irrelevant portal headers/footers).\n"
        "3. Keep the summary factual, dense, and objective. Do not invent details.\n"
        f"4. Write the summary directly in {target_lang} (approx 400-600 words).\n"
        "5. Output only the summary directly (no conversational prefix/suffix).\n"
        "6. Prioritize exact statistics, dollar amounts, dates, legislation names, and named authorities over narrative."
    )
    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 2000,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=45) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            summary = res['choices'][0]['message']['content'].strip()
            return summary
    except Exception as e:
        logger.warning(f"Web QFS failed for URL '{source_url}': {e}")
        return text[:1500]


