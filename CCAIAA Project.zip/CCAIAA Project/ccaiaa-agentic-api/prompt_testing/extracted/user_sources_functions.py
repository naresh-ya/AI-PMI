# ======================================================================
# stage_user_sources (lines 599-635)
# ======================================================================
def stage_user_sources(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """User-provided sources stage: uploaded file + user external links combined.

    If the file was already processed by the FileProcessor stage (runs before the planner),
    the pre-processed source is reused here instead of re-reading and re-summarizing the file.
    External-URL fetch always runs regardless.
    """
    merged = {'sources': [], 'citations': [], 'queries': []}

    # Uploaded file: use pre-processed source if available, otherwise read as before
    pre_processed = requirements.get('_uploaded_file_source')
    if pre_processed:
        merged['sources'].append(pre_processed)
        merged['citations'].append({
            'title': pre_processed.get('title', ''),
            'url': '', 'source_type': 'uploaded_file',
        })
        logger.info(f"[{request_id}] user_sources: using pre-processed file source from FileProcessor")
    else:
        try:
            out = read_uploaded_file(requirements) or {}
            merged['sources'].extend(out.get('sources', []))
            merged['citations'].extend(out.get('citations', []))
            merged['queries'].extend(out.get('queries', []))
        except Exception as e:
            logger.error(f"[{request_id}] user_sources file read failed: {e}")

    # External URLs: always processed here (unchanged)
    try:
        out = fetch_user_external_links(requirements) or {}
        merged['sources'].extend(out.get('sources', []))
        merged['citations'].extend(out.get('citations', []))
        merged['queries'].extend(out.get('queries', []))
    except Exception as e:
        logger.error(f"[{request_id}] user_sources ext links failed: {e}")

    return merged


# ======================================================================
# fetch_user_external_links (lines 3412-3477)
# ======================================================================
def fetch_user_external_links(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 3 — Fetch content from user-provided external URLs via Gemini.

    HYBRID APPROACH: User explicitly chose these URLs, so we extract directly with Gemini
    (no Tavily involvement). Gemini handles CAPTCHAs and JS-heavy pages better.
    
    Uses Tavily /search with domain filter for scoring only (0–1 scale compatibility).
    """
    external_links = [u for u in (requirements.get('external_links') or []) if u and str(u).startswith('http') and 'metadata.json' not in str(u).lower()]
    if not external_links:
        return {'sources': [], 'citations': [], 'queries': []}

    topic        = (requirements.get('topic') or '').strip()
    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    query        = ' '.join(filter(None, [topic, jurisdiction]))
    urls         = external_links[:5]

    # HYBRID CHANGE: Use Gemini extraction directly (no Tavily)
    extracted_contents = _gemini_extract_urls(urls)
    logger.info(f"EXTERNAL_LINKS | using Gemini extraction only (no Tavily) | extracted={len(extracted_contents)}/{len(urls)}")

    sources: List[Dict] = []
    citations: List[Dict] = []

    for url in urls:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        result = _tavily_search_domain(query, url)
        
        # Get raw content from Gemini extraction
        raw_content = extracted_contents.get(url, '').strip()
        extraction_engine = 'gemini' if raw_content else 'tavily'

        if result:
            page_title = result.get('title', '')
            score      = result.get('score', 0.0)
            title      = f"{domain} — {page_title}" if page_title else domain
            if not raw_content:
                raw_content = result.get('content', '')
                extraction_engine = 'tavily'
        else:
            # Fallback: compute score from word overlap
            if not raw_content:
                logger.warning(f"EXTERNAL_LINK | no content for '{url[:80]}'")
                continue
            score = _compute_description_score(topic, raw_content)
            title = domain

        # Run QFS engine to create a dense, context-focused summary
        summarized_content = summarize_web_content_with_llm(raw_content, requirements, url)

        sources.append({
            'title':           title,
            'source':          url,
            'type':            'external_url',
            'date':            datetime.now().strftime('%Y-%m-%d'),
            'relevance_score': score,
            'summary':         summarized_content,
            'url':             url,
            'extraction_engine': extraction_engine,
        })
        citations.append({'title': title, 'url': url, 'source_type': 'external_url'})
        logger.info(f"EXTERNAL_LINK | url='{url[:80]}' | score={score} | raw_chars={len(raw_content)} | summary_chars={len(summarized_content)}")

    return {'sources': sources, 'citations': citations, 'queries': []}


