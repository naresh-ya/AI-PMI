def _extract_semantic_signals(
    topic: str, background: str, use_case: str, category: str, jurisdiction: str = ''
) -> Dict[str, str]:
    """
    Use LLM to extract domain-meaningful signals from raw input fields.

    Returns:
        topic_core       — core subject terms, compound concepts preserved
        background_signal — domain-relevant facts stripped of drafting instructions

    Falls back silently to regex if the LLM call fails.
    """
    if LITELLM_KEY and (topic or background):
        prompt = (
            "You are a semantic signal extractor for a document vector retrieval system.\n\n"
            "Given the raw user input below, extract only the domain-relevant semantic content "
            "that would help retrieve matching documents from a knowledge base.\n\n"
            f"Topic: {topic or 'N/A'}\n"
            f"Background: {background or 'N/A'}\n"
            f"Jurisdiction: {jurisdiction or 'N/A'}\n"
            f"Use case: {use_case or 'N/A'}\n"
            f"Category: {category or 'N/A'}\n\n"
            "Extract:\n"
            "1. topic_core — 3 to 8 words capturing the core subject. "
            "Preserve compound domain concepts (e.g. 'heated tobacco products excise duty'). "
            "Strip generic words: submission, document, letter, regarding, about, a, an, the.\n"
            "2. background_signal — up to 100 characters of domain-relevant facts from the background. "
            "Ignore all drafting instructions (please draft, I need, write a, ensure, include, etc.). "
            "Return only factual content: regulation names, policy references, specific requirements.\n\n"
            "Output ONLY a JSON object with exactly two keys. No explanation.\n"
            'Example: {"topic_core": "heated tobacco products excise duty", '
            '"background_signal": "CBIC notification 2023 duty revision HTP"}'
        )
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            data = {
                "model": LITELLM_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 150,
            }
            headers = {
                "Authorization": f"Bearer {LITELLM_KEY}",
                "Content-Type": "application/json",
            }
            req = urllib.request.Request(
                LITELLM_URL,
                data=json.dumps(data).encode('utf-8'),
                headers=headers,
                method='POST',
            )
            with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['choices'][0]['message']['content'].strip()
                if raw.startswith('```'):
                    raw = '\n'.join(raw.split('\n')[1:-1]).strip()
                signals = json.loads(raw)
                if isinstance(signals, dict) and 'topic_core' in signals:
                    result = {
                        'topic_core': str(signals.get('topic_core', '')).strip(),
                        'background_signal': str(signals.get('background_signal', '')).strip(),
                    }
                    logger.info(
                        f"LLM_SIGNAL_EXTRACTION | "
                        f"topic_core='{result['topic_core']}' | "
                        f"background_signal='{result['background_signal']}'"
                    )
                    return result
        except Exception as e:
            logger.warning(f"LLM signal extraction failed, falling back to regex: {e}")

    # Regex fallback — used only when LLM is unavailable or fails
    _STOPWORDS = {
        'a', 'an', 'the', 'for', 'of', 'in', 'on', 'at', 'to', 'with',
        'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be', 'been',
        'about', 'regarding', 'related', 'concerning', 'submission', 'document',
    }
    tokens = re.split(r'[\s,;]+', (topic or '').lower())
    topic_core = ' '.join(t for t in tokens if t and t not in _STOPWORDS and len(t) > 2)

    bg_cleaned = re.sub(
        r'(?i)\b(please|kindly|draft|write|prepare|create|generate|i need|i want|'
        r'can you|could you|help me|assist|ensure|include|provide)\b[^.]*?(?=[A-Z]|\.|$)',
        ' ', background or ''
    )
    background_signal = re.sub(r'\s+', ' ', bg_cleaned).strip()[:150]

    return {'topic_core': topic_core, 'background_signal': background_signal}


def _derive_intent(use_case: str, category: str) -> str:
    """Map use_case/category to a semantic intent phrase for vector search."""
    _INTENT_MAP = {
        'submission': 'regulatory submission compliance',
        'report': 'policy analysis report',
        'communication': 'stakeholder communication',
        'response': 'regulatory response',
        'application': 'regulatory application',
        'representation': 'industry representation',
        'briefing': 'policy briefing',
        'comment': 'public comment regulatory',
        'appeal': 'regulatory appeal',
        'petition': 'regulatory petition',
    }
    combined = f"{use_case} {category}".lower()
    for key, intent in _INTENT_MAP.items():
        if key in combined:
            return intent
    return (use_case or category or '').strip()


def _derive_entity(target_audience: str) -> str:
    """Map target_audience to a semantic entity phrase for vector search."""
    _ENTITY_MAP = {
        'cbic': 'customs excise authority',
        'gst': 'goods services tax authority',
        'mohfw': 'health ministry regulator',
        'ministry of health': 'health ministry regulator',
        'who': 'world health organization international',
        'cpcb': 'environment pollution control authority',
        'fssai': 'food safety standards authority',
        'sebi': 'securities exchange board regulator',
        'rbi': 'reserve bank central authority',
        'parliament': 'legislative authority',
        'committee': 'parliamentary standing committee',
        'ministry': 'government ministry authority',
        'department': 'government department',
        'tribunal': 'judicial regulatory tribunal',
    }
    audience_lower = (target_audience or '').lower()
    for key, entity in _ENTITY_MAP.items():
        if key in audience_lower:
            return entity
    return (target_audience or '').strip()


def _llm_enrich_queries(
    topic_core: str, intent: str, entity: str,
    jurisdiction: str, background_signal: str
) -> List[str]:
    """Call LLM to generate up to 2 semantically enriched vector search queries."""
    if not LITELLM_KEY or not topic_core:
        return []

    prompt = (
        "Generate exactly 2 short semantic search queries for a vector database retrieval task.\n\n"
        "Structured input:\n"
        f"- Topic: {topic_core}\n"
        f"- Intent: {intent}\n"
        f"- Target entity: {entity}\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Domain context: {background_signal or 'N/A'}\n\n"
        "Rules:\n"
        "- Each query must be 5-12 words\n"
        "- Reflect domain document meaning, not user phrasing\n"
        "- Query 1 must be generic and NOT mention any country or jurisdiction.\n"
        "- Query 2 can optionally include the country or jurisdiction.\n"
        "- Queries should match what relevant source documents would contain\n"
        "- Output ONLY a JSON array of 2 strings, no explanation\n\n"
        'Example: ["tobacco excise policy regulatory compliance", '
        '"CBIC heated tobacco products duty submission"]'
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            enriched = json.loads(raw)
            if isinstance(enriched, list):
                return [q for q in enriched if isinstance(q, str) and q.strip()][:2]
    except Exception as e:
        logger.warning(f"LLM query enrichment failed (non-fatal): {e}")
    return []


