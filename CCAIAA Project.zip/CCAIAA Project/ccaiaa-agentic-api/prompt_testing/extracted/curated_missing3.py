def _gemini_url_context(url: str) -> Dict[str, Any]:
    """
    Fetch and summarize a URL using Gemini's native url_context grounding tool,
    routed through the private LiteLLM proxy.

    Returns a dict with keys:
        content            : str   — summary text from Gemini (empty on failure)
        retrieval_status   : str   — e.g. 'URL_RETRIEVAL_STATUS_SUCCESS'
        output_len         : int   — character count of content
        error              : str   — non-empty when the call failed
    """
    if not LITELLM_KEY:
        return {'content': '', 'retrieval_status': 'NO_CREDENTIALS', 'output_len': 0, 'error': 'no LITELLM_KEY'}

    prompt = (
        f"Use the url_context tool to fetch and read this URL:\n{url}\n\n"
        "Then return ALL of the following in your response:\n"
        "1. ACCESSIBLE: yes or no (was the full page content readable?)\n"
        "2. TITLE: the page title\n"
        "3. FULL_CONTENT: the complete extracted text from the page — do NOT summarise, "
        "return as much raw content as possible including tables, numbers, dates, legislation names.\n"
        "4. SUMMARY: a 5–8 sentence factual summary of the key points.\n\n"
        "Format your response exactly like this:\n"
        "ACCESSIBLE: yes\n"
        "TITLE: <page title>\n"
        "FULL_CONTENT:\n<full text here>\n"
        "SUMMARY:\n<summary here>\n\n"
        "If the page is behind a login, paywalled, or truly inaccessible, respond:\n"
        "ACCESSIBLE: no\n"
        "TITLE: unknown\n"
        "FULL_CONTENT: none\n"
        "SUMMARY: Page could not be accessed."
    )
    body = {
        "model": GEMINI_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 4096,
        "tools": [{"url_context": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        url_ctx_meta = data.get('vertex_ai_url_context_metadata', [])
        retrieval_status = 'UNKNOWN'
        try:
            retrieval_status = url_ctx_meta[0]['urlMetadata'][0]['urlRetrievalStatus']
        except (KeyError, IndexError, TypeError):
            if url_ctx_meta:
                retrieval_status = str(url_ctx_meta)

        # Parse structured fields from the response
        content_stripped = content.strip()
        accessible = 'yes' if 'ACCESSIBLE: yes' in content_stripped else (
                     'no'  if 'ACCESSIBLE: no'  in content_stripped else 'unknown')

        return {
            'content':          content_stripped,
            'retrieval_status': retrieval_status,
            'accessible':       accessible,
            'output_len':       len(content_stripped),
            'error':            '',
        }
    except Exception as e:
        return {'content': '', 'retrieval_status': 'ERROR', 'output_len': 0, 'error': str(e)}


