def _build_selection_reason(raw_type: str, relevance_score: 'float | None', source_origin: str) -> str:
    """
    Build a deterministic human-readable reason explaining why the agent picked this source.
    relevance_score is on a 0–1 scale (None for uploaded_file).
    """
    score = relevance_score or 0.0
    score_label = (
        'high'     if score >= 0.75 else
        'moderate' if score >= 0.50 else
        'low'
    )
    score_pct = f"{round(score * 100)}%"

    if raw_type == 'internal_knowledge':
        return (
            f"Retrieved from {source_origin or 'PMI Knowledge Base'} with {score_pct} semantic "
            f"relevance to the research query. Selected as a primary internal reference."
        )
    elif raw_type == 'uploaded_file':
        return (
            f"Extracted from a user-uploaded input document. Included because it was explicitly "
            f"provided as a reference for this request."
        )
    elif raw_type == 'internal_url':
        return (
            f"Retrieved from a curated internal portal. "
            f"Selected for internal policy context with {score_label} relevance ({score_pct})."
        )
    elif raw_type == 'web_search':
        return (
            f"Surfaced via external web search on the research topic. "
            f"Selected for {score_label} topical relevance ({score_pct})."
        )
    elif raw_type == 'external_url':
        return (
            f"Retrieved from an external link provided with the request. "
            f"Relevance to topic: {score_label} ({score_pct})."
        )
    else:
        return (
            f"Source selected based on {score_label} relevance ({score_pct}) "
            f"to the research topic."
        )


