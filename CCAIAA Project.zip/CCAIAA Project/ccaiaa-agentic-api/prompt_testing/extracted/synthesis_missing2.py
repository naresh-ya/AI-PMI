def _aggregate_stage_sources(stage_outputs: Dict[str, Dict[str, Any]], request_id: str) -> Dict[str, Any]:
    """Merge the parallel retrieval stage outputs into a single research_results envelope,
    replicating the monolith's Phase 1/2 merge + consolidated-score computation. Counts are
    provisional here; finalize_research_results recomputes them by source type.
    """
    research_results = _seed_research_results()
    _MERGE_ORDER = ('user_sources', 'kb', 'curated', 'web')
    for name in _MERGE_ORDER:
        out = stage_outputs.get(name, {}) or {}
        research_results['all_sources'].extend(out.get('sources', []))
        research_results['formatted_citations'].extend(out.get('citations', []))
        research_results['search_queries'].extend(out.get('queries', []))

    # Consolidated score (logging/metadata only) — same logic as the monolith Phase 1.
    _SCORED_TYPES = ('internal_knowledge', 'external_url', 'internal_url')
    scores_by_type: Dict[str, float] = {}
    for s in research_results['all_sources']:
        stype = s.get('type')
        score = s.get('relevance_score')
        if stype in _SCORED_TYPES and score is not None:
            if stype not in scores_by_type or score > scores_by_type[stype]:
                scores_by_type[stype] = round(float(score), 3)
    kb_best = scores_by_type.get('internal_knowledge')
    if kb_best is not None:
        research_results['consolidated_score'] = kb_best
    elif scores_by_type:
        research_results['consolidated_score'] = round(sum(scores_by_type.values()) / len(scores_by_type), 3)
    logger.info(f"[{request_id}] SPLIT_AGGREGATE | sources={len(research_results['all_sources'])} | consolidated={research_results['consolidated_score']}")
    return research_results


def _dedup_sources_by_url(sources: List[Dict]) -> List[Dict]:
    """Remove duplicate sources by URL, preserving first occurrence."""
    seen_urls: set = set()
    deduped = []
    for s in sources:
        url_key = (s.get('url') or s.get('source') or '').strip().lower()
        if url_key and url_key in seen_urls:
            continue
        if url_key:
            seen_urls.add(url_key)
        deduped.append(s)
    return deduped


def _entity_match(source: Dict[str, Any]) -> bool:
    """True if the source actually mentions PMI (the actor), by text or owned domain."""
    text = f"{source.get('title', '')} {source.get('summary', '')}".lower()
    url = (source.get('url') or source.get('source') or '').lower()
    if any(t in text for t in _PMI_ENTITY_TERMS):
        return True
    if any(d in url for d in _PMI_DOMAINS):
        return True
    return False


def _extract_structured_facts(all_sources: List[Dict], requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Extract structured facts from top sources for the drafter to use verbatim.
    
    Uses one Gemini call to extract precise statistics, legislation names, dates,
    and authority names from the highest-scoring sources.
    Returns a dict with: statistics, legislation, authorities, key_dates.
    """
    if not LITELLM_KEY:
        return {}
    
    # Pick top 5 by relevance score
    scored = sorted(
        [s for s in all_sources if s.get('relevance_score')],
        key=lambda x: x.get('relevance_score', 0), reverse=True
    )[:5]
    
    if not scored:
        return {}
    
    source_text = "\n".join(
        f"[{i+1}] {s.get('title','')}: {(s.get('summary',''))[:400]}"
        for i, s in enumerate(scored)
    )
    
    topic = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    
    prompt = (
        f"Extract specific factual data from these sources about: {topic} in {jurisdiction}\n\n"
        f"Sources:\n{source_text}\n\n"
        "Return ONLY a JSON object with these arrays:\n"
        '- "statistics": [{"metric":"...","value":"...","year":"...","source_index":N}]\n'
        '- "legislation": [{"name":"...","year":"...","status":"..."}]\n'
        '- "authorities": [{"name":"...","role":"..."}]\n'
        '- "key_dates": [{"event":"...","date":"..."}]\n\n'
        "Rules: Only include facts explicitly stated in sources. No inferences. Max 10 items total."
    )
    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        body = {
            "model": GEMINI_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0,
            "max_tokens": 1500,
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {LITELLM_KEY}",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        raw = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        raw = raw.strip()
        if raw.startswith('```'):
            raw = '\n'.join(raw.split('\n')[1:-1]).strip()
        
        result = json.loads(raw)
        logger.info(
            f"STRUCTURED_FACTS | stats={len(result.get('statistics',[]))} "
            f"| legislation={len(result.get('legislation',[]))} "
            f"| authorities={len(result.get('authorities',[]))} "
            f"| dates={len(result.get('key_dates',[]))}"
        )
        return result
    except Exception as e:
        logger.warning(f"Structured fact extraction failed (non-fatal): {e}")
        return {}


def _fill_research_gaps(gap_queries: List[str], research_results: Dict[str, Any], requirements: Dict[str, Any]) -> None:
    """
    Agentic Phase 3.5: Run targeted KB + web searches for identified gaps.
    Appends new sources directly to research_results. Runs in parallel.
    """
    if not gap_queries:
        return

    jurisdiction = requirements.get('jurisdiction', '')

    def _run_gap_query(gap_query: str) -> Dict[str, Any]:
        """Run one gap query against KB and web, return combined sources."""
        combined = {'sources': [], 'citations': [], 'queries': [gap_query]}

        # KB search for this specific gap
        try:
            gap_requirements = requirements.copy()
            gap_requirements['topic'] = gap_query  # Override topic with the gap query
            kb_result = search_internal_knowledge(gap_requirements)
            combined['sources'].extend(kb_result.get('sources', []))
            combined['citations'].extend(kb_result.get('citations', []))
        except Exception as e:
            logger.warning(f"Gap-fill KB search failed for '{gap_query[:40]}': {e}")

        # Web search for this specific gap
        try:
            gap_requirements_web = requirements.copy()
            gap_requirements_web['topic'] = gap_query
            web_result = search_web_tavily(gap_requirements_web)
            combined['sources'].extend(web_result.get('sources', []))
            combined['citations'].extend(web_result.get('citations', []))
        except Exception as e:
            logger.warning(f"Gap-fill web search failed for '{gap_query[:40]}': {e}")

        return combined

    # Run all gap queries in parallel
    with ThreadPoolExecutor(max_workers=min(len(gap_queries), 3)) as ex:
        futures = {ex.submit(_run_gap_query, q): q for q in gap_queries}
        for future in as_completed(futures):
            try:
                result = future.result()
                new_sources = result.get('sources', [])
                # Deduplicate against existing sources by URL
                existing_urls = {s.get('url', '').lower() for s in research_results['all_sources'] if s.get('url')}
                for s in new_sources:
                    s_url = (s.get('url') or '').lower()
                    if s_url and s_url not in existing_urls:
                        research_results['all_sources'].append(s)
                        existing_urls.add(s_url)
                research_results['formatted_citations'].extend(result.get('citations', []))
                research_results['search_queries'].extend(result.get('queries', []))
            except Exception as e:
                logger.warning(f"Gap-fill future failed: {e}")

    logger.info(
        f"AGENTIC_GAP_FILL | gap_queries={len(gap_queries)} "
        f"| total_sources_after={len(research_results['all_sources'])}"
    )


def _flag_numeric_inconsistencies(synthesis_result: Dict[str, Any]) -> Dict[str, Any]:
    """Flag internally inconsistent numeric claims in the synthesized findings.

    Catches the class of error seen in production where a figure is stated with the wrong
    magnitude/units — e.g. "INR 1,773.4 million ... more than 1% of GDP", which is
    impossible (millions cannot be ~1% of a multi-trillion economy; the real figure is in
    billions). We do NOT rewrite the number (the correct value must come from the source),
    we attach a `data_quality_flags` list and log a warning so the reviewer / HITL stage
    can verify before the figure reaches a final document.

    Non-destructive and category-agnostic — runs on every synthesis.
    """
    import re

    flags: List[str] = []
    items = (
        list(synthesis_result.get('key_findings', []) or [])
        + list(synthesis_result.get('policy_insights', []) or [])
    )

    # A magnitude word near a "% of GDP" claim is the high-confidence red flag.
    # Allow a few words between "of" and "gdp" (e.g. "1% of India's GDP",
    # "over 1% of the country's GDP").
    gdp_pattern = re.compile(r'%\s*of\b[^.\n]{0,30}?\bgdp', re.IGNORECASE)
    magnitude_pattern = re.compile(r'\b(thousand|million|billion|trillion|lakh|crore)\b', re.IGNORECASE)

    for item in items:
        text = str(item)
        low = text.lower()
        if gdp_pattern.search(low):
            mags = {m.lower() for m in magnitude_pattern.findall(low)}
            # "million"/"thousand"/"lakh" paired with a >=1% of GDP claim is almost
            # always a units error for any sizeable national economy.
            if mags & {'million', 'thousand', 'lakh'}:
                flags.append(
                    f"Possible units error: a '%-of-GDP' claim paired with a "
                    f"'{', '.join(sorted(mags & {'million', 'thousand', 'lakh'}))}' "
                    f"magnitude — verify against source. Claim: \"{text[:160]}\""
                )

    if flags:
        for f in flags:
            logger.warning(f"NUMERIC_INCONSISTENCY | {f}")
        synthesis_result['data_quality_flags'] = flags

    return synthesis_result


def _is_first_party(framing: Dict[str, Any]) -> bool:
    """True when the document is about PMI's OWN action/position (entity match required)."""
    return framing.get('perspective') == 'first_party_pmi' or bool(framing.get('entity_anchor'))


def _store_research_to_s3(request_id: Any, research_results: Dict[str, Any], synthesis_result: Dict[str, Any]) -> str:
    """Write research data (all_sources + synthesis) to S3 and return the object key.

    Also writes a separate gemini_comparison.json alongside the main file so
    you can open it in S3 and read the full Gemini content side-by-side with
    Tavily to decide which engine produces better results.
    """
    if not request_id:
        logger.warning("No request_id; skipping S3 research data write.")
        return ''
    try:
        payload = {
            'all_sources':         research_results.get('all_sources', []),
            'formatted_citations': research_results.get('formatted_citations', []),
            'synthesis':           synthesis_result,
            'structured_facts':    research_results.get('structured_facts', {}),
            'jurisdiction_context': research_results.get('_jurisdiction_context_for_drafter', ''),
            'research_framing':    research_results.get('_research_framing', {}),
        }
        key = f"research/{request_id}/research_data.json"
        s3.put_object(
            Bucket=DOCUMENT_BUCKET,
            Key=key,
            Body=json.dumps(payload, indent=2),
            ContentType='application/json',
        )
        logger.info(f"[{request_id}] Research data stored at s3://{DOCUMENT_BUCKET}/{key}")

        # The Gemini comparison file is an evaluation-only artifact (not used by the
        # drafter). Skip it entirely unless the comparison harness is enabled.
        if not ENABLE_GEMINI_COMPARISON:
            with _gemini_comparison_lock:
                _gemini_comparison_store.pop(str(request_id), None)
            return key

        # ── Write Gemini comparison file ──────────────────────────────────────
        # Collect all Tavily sources for side-by-side comparison
        tavily_web_sources = [
            {
                'url':     s.get('url', ''),
                'title':   s.get('title', ''),
                'summary': s.get('summary', ''),
                'score':   s.get('relevance_score'),
                'source':  s.get('source', ''),
            }
            for s in research_results.get('all_sources', [])
            if s.get('type') == 'web_search'
        ]
        tavily_url_sources = [
            {
                'url':     s.get('url', ''),
                'title':   s.get('title', ''),
                'summary': s.get('summary', ''),
                'score':   s.get('relevance_score'),
                'type':    s.get('type', ''),
            }
            for s in research_results.get('all_sources', [])
            if s.get('type') in ('external_url', 'internal_url')
        ]

        with _gemini_comparison_lock:
            gemini_data = _gemini_comparison_store.get(str(request_id), {})

        comparison_payload = {
            'request_id':   str(request_id),
            'generated_at': datetime.now().isoformat(),
            'model':        GEMINI_MODEL,
            'note': (
                'This file contains Gemini results run in parallel with Tavily for comparison. '
                'Tavily content is what the drafter used. '
                'Compare summaries and content here to decide which engine to use.'
            ),
            'url_extraction_comparison': [
                {
                    'url':                    g_entry.get('url', ''),
                    'gemini_retrieval_status': g_entry.get('retrieval_status', ''),
                    'gemini_accessible':       g_entry.get('accessible', 'unknown'),
                    'gemini_output_len':       g_entry.get('output_len', 0),
                    'gemini_content':          g_entry.get('content', ''),
                    'gemini_error':            g_entry.get('error', ''),
                    'tavily_output_len': len(next(
                        (t['summary'] for t in tavily_url_sources if t['url'] == g_entry.get('url', '')),
                        ''
                    )),
                    'tavily_summary': next(
                        (t['summary'] for t in tavily_url_sources if t['url'] == g_entry.get('url', '')),
                        '(not in tavily url sources)'
                    ),
                }
                for g_entry in gemini_data.get('url_extractions', [])
            ],
            'web_search_comparison': [
                {
                    'query':                  g_entry.get('query', ''),
                    'gemini_content':         g_entry.get('content', ''),
                    'gemini_sources':         g_entry.get('sources', []),
                    'gemini_output_len':      g_entry.get('output_len', 0),
                    'gemini_grounding_used':  g_entry.get('grounding_used', False),
                    'gemini_error':           g_entry.get('error', ''),
                    'tavily_sources': tavily_web_sources,
                }
                for g_entry in gemini_data.get('web_searches', [])
            ],
        }

        comparison_key = f"research/{request_id}/gemini_comparison.json"
        s3.put_object(
            Bucket=DOCUMENT_BUCKET,
            Key=comparison_key,
            Body=json.dumps(comparison_payload, indent=2),
            ContentType='application/json',
        )
        logger.info(f"[{request_id}] Gemini comparison stored at s3://{DOCUMENT_BUCKET}/{comparison_key}")

        # Clean up accumulator entry to free memory
        with _gemini_comparison_lock:
            _gemini_comparison_store.pop(str(request_id), None)

        return key
    except Exception as e:
        logger.error(f"Failed to store research data to S3: {e}")
        return ''


def build_structured_sources(research_results: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Build structured source list for HITL review from raw research results.
    Summaries and reasons are derived deterministically — no LLM calls.
    Each entry includes source_id so it can be referenced in future human feedback.
    Deduplicates by URL — keeps the highest-scoring chunk per URL.
    """
    all_sources = research_results.get('all_sources', [])
    citations = research_results.get('formatted_citations', [])

    url_by_title: Dict[str, str] = {c.get('title', ''): c.get('url', '') for c in citations}

    # Deduplicate by URL: keep highest-scoring entry per URL
    _seen_urls: Dict[str, Dict] = {}
    for source in all_sources:
        url_key = (source.get('url') or source.get('source') or '').strip().lower()
        if not url_key or source.get('type') == 'uploaded_file':
            # uploaded_file has no URL — always include
            _seen_urls[f"_uploaded_{id(source)}"] = source
            continue
        existing = _seen_urls.get(url_key)
        if existing is None:
            _seen_urls[url_key] = source
        else:
            # Keep the one with higher relevance_score
            existing_score = existing.get('relevance_score') or 0
            new_score = source.get('relevance_score') or 0
            if new_score > existing_score:
                _seen_urls[url_key] = source
    
    deduped_sources = list(_seen_urls.values())

    _TYPE_MAP = {
        'internal_knowledge': 'knowledge_base',
        'uploaded_file':      'uploaded_file',
        'internal_url':       'internal_url',
        'web_search':         'web_search',
        'external_url':       'external_url',
    }

    structured = []
    src_idx = 1
    for source in deduped_sources:
        title = source.get('title', f'Source {src_idx}')
        raw_summary = source.get('summary', '')
        raw_type = source.get('type', '')
        raw_score = source.get('relevance_score')
        relevance_score = round(float(raw_score), 3) if raw_score is not None else None
        source_origin = source.get('source', '')

        # Exclude metadata.json files from structured sources list
        if 'metadata.json' in str(title).lower() or 'metadata.json' in str(source_origin).lower():
            continue

        # Deterministic 2-3 line summary: trim at last sentence boundary within 200 chars
        short_summary = raw_summary[:200]
        last_period = short_summary.rfind('. ')
        if last_period > 80:
            short_summary = short_summary[:last_period + 1]
        short_summary = short_summary.strip() or 'No summary available.'

        source_type = _TYPE_MAP.get(raw_type, 'external')
        url = url_by_title.get(title, '') or source.get('url', '')

        structured.append({
            'source_id': f'src_{src_idx:03d}',
            'title': title,
            'source_type': source_type,
            'relevance_score': relevance_score,
            'url': url,
            'summary': short_summary,
            'reason': _build_selection_reason(raw_type, relevance_score, source_origin),
            'extraction_engine': source.get('extraction_engine', ''),
        })
        src_idx += 1

    return structured


def create_sources_summary(research_results: Dict[str, Any]) -> str:
    """
    Build a ranked source summary for the synthesis LLM prompt.

    Changes from original:
    - Sources sorted by relevance_score descending so synthesiser sees the
      most relevant content first (was positional — arrival order).
    - Sources with score below 0.30 are excluded — very low relevance sources
      dilute synthesis quality without adding signal.
    - Uploaded file (null score) is always included regardless of threshold
      since the user explicitly provided it.
    - Top 15 selected after ranking and filtering.
    - Score displayed as percentage (score × 100) for LLM readability.
    """
    sources = research_results.get('all_sources', [])

    # Sort: uploaded_file first, then by rerank_score (primary) → relevance_score (fallback)
    def _sort_key(s: Dict) -> float:
        if s.get('type') == 'uploaded_file':
            return 2.0   # uploaded_file always first
        rerank = s.get('rerank_score')
        if rerank is not None:
            return float(rerank)
        score = s.get('relevance_score')
        if score is None:
            return 2.0
        return float(score)

    ranked = sorted(sources, key=_sort_key, reverse=True)

    # Keep uploaded_file (always relevant) + any source that passed rerank, or scored >= 0.35
    filtered = [
        s for s in ranked
        if s.get('type') == 'uploaded_file'
        or s.get('rerank_score') is not None          # survived rerank floor upstream
        or (s.get('relevance_score') or 0) >= 0.35
    ]

    summary_parts = []
    SYNTH_SOURCE_CAP = 15  # number of ranked sources fed to the synthesis LLM
    for idx, source in enumerate(filtered[:SYNTH_SOURCE_CAP], 1):
        score      = source.get('relevance_score')
        score_disp = f"{round(score * 100)}%" if score is not None else "user-provided"
        url        = source.get('url', source.get('source', ''))
        summary_parts.append(
            f"[{idx}] {source.get('title', 'Unknown Title')} "
            f"({source.get('source', 'Unknown Source')}) "
            f"[Relevance: {score_disp}] [URL: {url}] - {source.get('summary', 'No summary available')}"
        )

    logger.info(
        f"SOURCES_SUMMARY | total={len(sources)} | after_filter={len(filtered)} "
        f"| sent_to_llm={min(len(filtered), SYNTH_SOURCE_CAP)}"
    )
    return '\n'.join(summary_parts)


