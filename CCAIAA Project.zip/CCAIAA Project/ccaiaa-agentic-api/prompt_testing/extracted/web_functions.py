# ======================================================================
# stage_web (lines 643-645)
# ======================================================================
def stage_web(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Web-search stage. existing_sources=[] — global URL dedup happens in synthesis."""
    return run_web_search_stage(requirements, [], request_id)


# ======================================================================
# run_web_search_stage (lines 1007-1096)
# ======================================================================
def run_web_search_stage(requirements: Dict[str, Any], existing_sources: List[Dict],
                         request_id: str) -> Dict[str, Any]:
    """Phase 2 web search stage shared by the monolith and the split web lambda.

    Runs the top 3-4 planned queries (planner_queries[:4], each hard-capped at 15 words)
    as PARALLEL Tavily web searches, merges + de-duplicates the results by URL, dedups
    against existing_sources, and caps the merged web pool at 8 (the final trust-weighted
    top_k still decides what reaches synthesis). Multi-query coverage matters for comparative
    documents (e.g. global precedents across UK / NZ / Canada / EU) where a single query would
    only surface one jurisdiction. In the split web lambda existing_sources is [] (the synthesis
    stage performs the global URL dedup). Non-fatal: per-query errors contribute fewer results
    and never break the stage; returns empties only on total failure.
    """
    logger.info(f"[{request_id}] Phase 2: web search always enabled (multi-query)")
    try:
        planned = requirements.get('_planned_queries', []) or []
        if planned:
            raw_queries = planned[:4]                      # top 3-4 planned queries
        else:
            topic = (requirements.get('topic') or '').strip()
            jurisdiction = (requirements.get('jurisdiction') or '').strip()
            raw_queries = [' '.join(filter(None, [topic, jurisdiction]))]

        # Normalise: cap each query to 15 words and de-duplicate (case-insensitive)
        narrow_queries, _seen_q = [], set()
        for rq in raw_queries:
            nq = ' '.join((rq or '').split()[:15]).strip()
            if nq and nq.lower() not in _seen_q:
                _seen_q.add(nq.lower())
                narrow_queries.append(nq)
        if not narrow_queries:
            return {'sources': [], 'citations': [], 'queries': []}

        # ── Run the queries as parallel Tavily searches ───────────────────────
        def _one_query(nq: str) -> Dict[str, Any]:
            wr = requirements.copy()
            wr['_web_narrow_query'] = nq
            try:
                return search_web_tavily(wr)
            except Exception as qe:
                logger.warning(f"[{request_id}] WEB_SEARCH | query='{nq[:60]}' failed (non-fatal): {qe}")
                return {'sources': [], 'citations': [], 'queries': [nq]}

        merged_sources: List[Dict] = []
        merged_citations: List[Dict] = []
        with ThreadPoolExecutor(max_workers=len(narrow_queries)) as ex:
            futures = {ex.submit(_one_query, nq): nq for nq in narrow_queries}
            for fut in as_completed(futures):
                res = fut.result() or {}
                merged_sources.extend(res.get('sources', []) or [])
                merged_citations.extend(res.get('citations', []) or [])

        # ── Merge-dedup by URL across queries (keep first / highest-ranked) ──
        raw_merged_count = len(merged_sources)
        seen_urls, deduped_merged = set(), []
        for s in merged_sources:
            u = (s.get('url') or '').strip().lower()
            if u and u in seen_urls:
                continue
            if u:
                seen_urls.add(u)
            deduped_merged.append(s)

        # Dedup against KB + curated sources, then cap the merged web pool at 8
        deduped_web = _dedup_web_against_existing(deduped_merged, existing_sources)
        deduped_web = deduped_web[:8]

        # Citations: dedup by URL, align count with the capped source pool
        seen_c, deduped_citations = set(), []
        for c in merged_citations:
            cu = (c.get('url') or c.get('title') or '').strip().lower()
            if cu and cu in seen_c:
                continue
            if cu:
                seen_c.add(cu)
            deduped_citations.append(c)

        logger.info(
            f"[{request_id}] WEB_SEARCH | queries={len(narrow_queries)} "
            f"| raw={raw_merged_count} | merged_dedup={len(deduped_merged)} "
            f"| after_existing_dedup={len(deduped_web)} | capped=8"
        )
        return {
            'sources': deduped_web,
            'citations': deduped_citations[:8],
            'queries': narrow_queries,
        }
    except Exception as e:
        logger.error(f"Phase 2 web search failed: {str(e)}")
        return {'sources': [], 'citations': [], 'queries': []}


# ======================================================================
# search_web_tavily (lines 4268-4476)
# ======================================================================
def search_web_tavily(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Search the web using Tavily API, routing via private LiteLLM gateway if inside VPC.

    Also fires a parallel Gemini google_search for the same query and logs
    side-by-side results so callers can compare coverage.
    Tavily results are used as the live source returned to downstream agents.
    """
    topic        = (requirements.get('topic')        or '').strip()
    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    background   = (requirements.get('background')   or '').strip()

    # Use up to 500 chars of background for web search context
    background_hint = background[:500] if background else ''
    query = ' '.join(filter(None, [topic, jurisdiction, background_hint]))[:300].strip()

    # Use narrow query from conductor if provided (max 15 words, from planner_queries[0])
    narrow_override = (requirements.get('_web_narrow_query') or '').strip()
    if narrow_override:
        query = narrow_override

    # Anchor to the framing entity so a generic topic (e.g. "Sustainability Initiative")
    # does not resolve to an unrelated organisation. Only prepended when the framing
    # decided this is a first-party PMI subject (entity_anchor is otherwise empty).
    framing = requirements.get('_research_framing', {}) or {}
    entity_anchor = framing.get('entity_anchor', '')
    if entity_anchor and entity_anchor.split()[0].lower() not in query.lower():
        query = f"{entity_anchor} {query}".strip()[:300]
        logger.info(f"TAVILY_SEARCH | using narrow query override: '{query}'")

    if not query:
        return {'sources': [], 'citations': [], 'queries': []}

    web_sources: List[Dict] = []
    citations: List[Dict] = []

    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)

    # ── Fire Gemini google_search in parallel (comparison-only; gated off by default) ──
    gemini_search_executor = None
    gemini_search_future = None
    if ENABLE_GEMINI_COMPARISON:
        gemini_search_executor = ThreadPoolExecutor(max_workers=1)
        gemini_search_future = gemini_search_executor.submit(_gemini_search_web, query)

    # ── Jurisdiction official domains — used ONLY as a soft ranking boost ─────
    # (NOT a hard search filter). These nudge authoritative local sources to the
    # top when Tavily naturally surfaces them; they never exclude other results.
    _JURISDICTION_DOMAINS: Dict[str, List[str]] = {
        'india': [
            'cbic.gov.in',
            'commerce.gov.in',
            'financialservices.gov.in',
            'tobaccoboard.in',
            'mohfw.gov.in',
        ],
        'in': [
            'cbic.gov.in',
            'commerce.gov.in',
            'financialservices.gov.in',
            'tobaccoboard.in',
            'mohfw.gov.in',
        ],
        'bangladesh': ['nbr.gov.bd', 'mohfw.gov.bd', 'commerce.gov.bd'],
        'bd':         ['nbr.gov.bd', 'mohfw.gov.bd', 'commerce.gov.bd'],
        'thailand':   ['rd.go.th', 'fda.moph.go.th', 'moc.go.th'],
        'th':         ['rd.go.th', 'fda.moph.go.th', 'moc.go.th'],
    }
    include_domains = _JURISDICTION_DOMAINS.get(jurisdiction.lower(), [])
    logger.info(
        f"TAVILY_SEARCH | jurisdiction='{jurisdiction}' "
        f"| soft_boost_domains={include_domains or 'none'} (no hard filter)"
    )

    try:
        if use_private_gateway:
            # Gateway search-tool name is team-scoped: this key is only authorized for
            # 'ccaiaa-dev-tavily' (the generic 'tavily' tool returns 403 key_model_access_denied).
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            base_payload: Dict[str, Any] = {
                "query": query,
                "max_results": 6,
                "search_depth": "advanced",
            }
        else:
            if not TAVILY_API_KEY:
                logger.warning("TAVILY_API_KEY not configured; skipping web search.")
                return {'sources': [], 'citations': [], 'queries': []}

            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            base_payload = {
                "api_key": TAVILY_API_KEY,
                "query": query,
                "search_depth": "advanced",
                "include_answer": False,
                "include_raw_content": True,
                "max_results": 6,
            }

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        def _tavily_fetch(domains: List[str]) -> List[Dict]:
            """Single Tavily call. When `domains` is non-empty it is a hard include-filter
            (Tavily returns ONLY results from those domains); when empty the search is broad
            and Tavily's own relevance engine selects the best sites for the topic."""
            payload = dict(base_payload)
            if domains:
                payload["include_domains"] = domains
            req = urllib.request.Request(
                search_url,
                data=json.dumps(payload).encode('utf-8'),
                headers=headers,
                method='POST',
            )
            with urllib.request.urlopen(req, context=ctx, timeout=45) as resp:
                data = json.loads(resp.read().decode('utf-8'))
            return data.get('results', []) or []

        # ── Broad, topic-driven search (document-agnostic) ────────────────────
        # No hard domain filter: Tavily's relevance engine intelligently selects
        # the best sites for the topic (global evidence, regulatory precedents,
        # scientific sources, AND official jurisdiction sites when relevant).
        # The jurisdiction allow-list is used ONLY as a soft ranking boost below
        # (a nudge, never an exclusion) so authoritative local sources rank first
        # when Tavily naturally surfaces them.
        results_list = _tavily_fetch([])[:6]
        logger.info(
            f"TAVILY_SEARCH | broad_unrestricted | results={len(results_list)} "
            f"| soft_boost_domains={include_domains or 'none'}"
        )

        urls = [r.get('url') for r in results_list if r.get('url')]
        
        # HYBRID APPROACH: Tavily finds URLs, Gemini extracts content
        gemini_extracted = _gemini_extract_urls(urls)
        logger.info(f"WEB_SEARCH | Tavily found {len(urls)} URLs, Gemini extracted {len(gemini_extracted)}")

        for result in results_list:
            title   = result.get('title', 'Web Result')
            url     = result.get('url', '')
            score   = float(result.get('score', 0.5))

            if 'metadata.json' in url.lower() or 'metadata.json' in title.lower():
                continue

            # Use Gemini-extracted content, fallback to Tavily snippet if Gemini failed
            raw_content = gemini_extracted.get(url, '').strip()
            extraction_engine = 'gemini'
            if not raw_content:
                raw_content = result.get('content') or result.get('snippet') or ''
                extraction_engine = 'tavily'
                logger.warning(f"WEB_SEARCH | Gemini extraction failed for '{url[:60]}', using Tavily snippet")

            summarized_content = summarize_web_content_with_llm(raw_content, requirements, url)

            web_sources.append({
                'title':           title,
                'source':          'Tavily Web Search',
                'type':            'web_search',
                'date':            datetime.now().strftime('%Y-%m-%d'),
                'relevance_score': round(min(score, 1.0), 3),
                'summary':         summarized_content,
                'url':             url,
                'extraction_engine': extraction_engine,
            })
            citations.append({'title': title, 'url': url, 'source_type': 'web_search'})
            logger.info(f"WEB_SEARCH_RESULT | title='{title}' | url='{url[:80]}' | score={score} | raw_chars={len(raw_content)} | QFS_chars={len(summarized_content)}")

        logger.info(f"WEB_SEARCH | query='{query[:80]}' | results={len(web_sources)}")

    except Exception as e:
        logger.warning(f"Tavily web search failed (non-fatal): {e}")

    # ── Collect and log Gemini google_search comparison (only when enabled) ───
    if ENABLE_GEMINI_COMPARISON and gemini_search_future is not None:
        try:
            g = gemini_search_future.result(timeout=65)
            tavily_urls = [s['url'] for s in web_sources]
            gemini_urls = [s['url'] for s in g.get('sources', [])]
            overlap = set(tavily_urls) & set(gemini_urls)
            logger.info(
                f"WEB_SEARCH_COMPARE | query='{query[:80]}' "
                f"| tavily_results={len(web_sources)} "
                f"| gemini_results={len(gemini_urls)} "
                f"| gemini_chars={g['output_len']} "
                f"| gemini_grounding_used={g['grounding_used']} "
                f"| url_overlap={len(overlap)} "
                f"| gemini_error={g['error'] or 'none'}"
            )
            if gemini_urls:
                logger.info(f"WEB_SEARCH_COMPARE | gemini_urls={gemini_urls}")
            # Write full content to accumulator for S3 comparison file
            _request_id = _gemini_comparison_store.get('_active_request_id', '')
            if _request_id:
                _gemini_log_search(_request_id, query, g)
        except Exception as e:
            logger.warning(f"WEB_SEARCH_COMPARE | gemini collection error: {e}")
        finally:
            if gemini_search_executor is not None:
                gemini_search_executor.shutdown(wait=False)

    return {'sources': web_sources, 'citations': citations, 'queries': [query]}


# ======================================================================
# summarize_web_content_with_llm (lines 2780-2852)
# ======================================================================
def summarize_web_content_with_llm(text: str, requirements: Dict[str, Any], source_url: str) -> str:
    """Uses Bedrock (via LiteLLM) to perform Query-Focused Summarization (QFS) on raw web content."""
    if not LITELLM_KEY or not text.strip():
        return text[:1500] # Safe fallback
        
    topic = requirements.get('topic', 'General Regulatory Topic')
    background = requirements.get('background', '')
    jurisdiction = requirements.get('jurisdiction', 'Global')
    target_audience = requirements.get('target_audience', 'General')
    target_lang = requirements.get('target_language', 'English')
    category = requirements.get('category', '')
    use_case = requirements.get('use_case', '')
    
    # Detect if this is a Letters scenario
    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()
    is_letter = 'letter' in cat_lower or 'letter' in uc_lower
    
    extra_context = ""
    if is_letter:
        subject = requirements.get('topic_of_letter') or requirements.get('topicOfLetter') or ''
        if subject:
            extra_context = f"\n- Subject of the Letter: {subject}"
            
    prompt = (
        "You are an expert corporate regulatory research assistant.\n"
        "Your task is to analyze raw text scraped from a webpage and produce a dense, highly focused summary "
        "tailored specifically to the following research query.\n\n"
        "RESEARCH REQUEST CONTEXT:\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Topic: {topic}\n"
        f"- Target Audience: {target_audience}\n"
        f"- Background Context: {background or 'N/A'}{extra_context}\n\n"
        f"SOURCE WEBPAGE URL: {source_url}\n\n"
        "RAW WEBPAGE CONTENT:\n"
        f"<webpage_content>\n{text}\n</webpage_content>\n\n"
        "INSTRUCTIONS:\n"
        "1. Identify and extract only key findings, statistics, official dates, and compliance mandates "
        "relevant to this specific research request.\n"
        "2. Strip out all noise (cookies notices, ads, irrelevant portal headers/footers).\n"
        "3. Keep the summary factual, dense, and objective. Do not invent details.\n"
        f"4. Write the summary directly in {target_lang} (approx 400-600 words).\n"
        "5. Output only the summary directly (no conversational prefix/suffix).\n"
        "6. Prioritize exact statistics, dollar amounts, dates, legislation names, and named authorities over narrative."
    )
    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 2000,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=45) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            summary = res['choices'][0]['message']['content'].strip()
            return summary
    except Exception as e:
        logger.warning(f"Web QFS failed for URL '{source_url}': {e}")
        return text[:1500]


# ======================================================================
# _dedup_web_against_existing (lines 803-822)
# ======================================================================
def _dedup_web_against_existing(
    web_sources: List[Dict], existing_sources: List[Dict]
) -> List[Dict]:
    """
    Remove web sources whose URL already appears in KB or curated sources.
    Uses exact URL match — fast, no LLM call needed.
    """
    existing_urls = {
        (s.get('url') or s.get('source') or '').strip().lower()
        for s in existing_sources
        if s.get('type') in ('internal_knowledge', 'internal_url', 'external_url')
    }
    filtered = []
    for s in web_sources:
        url_key = (s.get('url') or '').strip().lower()
        if url_key and url_key in existing_urls:
            logger.info(f"WEB_DEDUP | skipping url already in KB/curated: '{url_key[:80]}'")
            continue
        filtered.append(s)
    return filtered


# ======================================================================
# _gemini_url_context (lines 2945-3024)
# ======================================================================
def _gemini_url_context(url: str) -> Dict[str, Any]:
    """
    Fetch and summarize a URL using Gemini's native url_context grounding tool,
    routed through the private LiteLLM proxy.

    Returns a dict with keys:
        content            : str   — summary text from Gemini (empty on failure)
        retrieval_status   : str   — e.g. 'URL_RETRIEVAL_STATUS_SUCCESS'
        output_len         : int   — character count of content
        error              : str   — non-empty when the call failed
    """
    if not LITELLM_KEY:
        return {'content': '', 'retrieval_status': 'NO_CREDENTIALS', 'output_len': 0, 'error': 'no LITELLM_KEY'}

    prompt = (
        f"Use the url_context tool to fetch and read this URL:\n{url}\n\n"
        "Then return ALL of the following in your response:\n"
        "1. ACCESSIBLE: yes or no (was the full page content readable?)\n"
        "2. TITLE: the page title\n"
        "3. FULL_CONTENT: the complete extracted text from the page — do NOT summarise, "
        "return as much raw content as possible including tables, numbers, dates, legislation names.\n"
        "4. SUMMARY: a 5–8 sentence factual summary of the key points.\n\n"
        "Format your response exactly like this:\n"
        "ACCESSIBLE: yes\n"
        "TITLE: <page title>\n"
        "FULL_CONTENT:\n<full text here>\n"
        "SUMMARY:\n<summary here>\n\n"
        "If the page is behind a login, paywalled, or truly inaccessible, respond:\n"
        "ACCESSIBLE: no\n"
        "TITLE: unknown\n"
        "FULL_CONTENT: none\n"
        "SUMMARY: Page could not be accessed."
    )
    body = {
        "model": GEMINI_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 4096,
        "tools": [{"url_context": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        url_ctx_meta = data.get('vertex_ai_url_context_metadata', [])
        retrieval_status = 'UNKNOWN'
        try:
            retrieval_status = url_ctx_meta[0]['urlMetadata'][0]['urlRetrievalStatus']
        except (KeyError, IndexError, TypeError):
            if url_ctx_meta:
                retrieval_status = str(url_ctx_meta)

        # Parse structured fields from the response
        content_stripped = content.strip()
        accessible = 'yes' if 'ACCESSIBLE: yes' in content_stripped else (
                     'no'  if 'ACCESSIBLE: no'  in content_stripped else 'unknown')

        return {
            'content':          content_stripped,
            'retrieval_status': retrieval_status,
            'accessible':       accessible,
            'output_len':       len(content_stripped),
            'error':            '',
        }
    except Exception as e:
        return {'content': '', 'retrieval_status': 'ERROR', 'output_len': 0, 'error': str(e)}


# ======================================================================
# _gemini_search_web (lines 3027-3089)
# ======================================================================
def _gemini_search_web(query: str) -> Dict[str, Any]:
    """
    Run a web search via Gemini's native google_search grounding tool,
    routed through the private LiteLLM proxy.

    Returns a dict with keys:
        content        : str        — Gemini's synthesized answer
        sources        : List[dict] — [{title, url}] from grounding metadata
        output_len     : int
        grounding_used : bool
        error          : str
    """
    if not LITELLM_KEY:
        return {'content': '', 'sources': [], 'output_len': 0, 'grounding_used': False, 'error': 'no LITELLM_KEY'}

    body = {
        "model": GEMINI_MODEL,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0,
        "max_tokens": 2048,
        "tools": [{"google_search": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        grounding_meta = data.get('vertex_ai_grounding_metadata', [])
        grounding_used = any(bool(g) for g in grounding_meta)

        # Extract cited sources from grounding chunks if present
        sources = []
        try:
            for entry in grounding_meta:
                for chunk in (entry.get('groundingChunks') or []):
                    web = chunk.get('web') or {}
                    if web.get('uri'):
                        sources.append({'title': web.get('title', ''), 'url': web['uri']})
        except Exception:
            pass

        return {
            'content': content.strip(),
            'sources': sources,
            'output_len': len(content),
            'grounding_used': grounding_used,
            'error': '',
        }
    except Exception as e:
        return {'content': '', 'sources': [], 'output_len': 0, 'grounding_used': False, 'error': str(e)}


# ======================================================================
# _gemini_extract_urls (lines 3092-3131)
# ======================================================================
def _gemini_extract_urls(urls: List[str]) -> Dict[str, str]:
    """
    Extract content from URLs using Gemini url_context tool.
    
    This is the central Gemini extraction function used by:
    - External links (user-provided URLs)
    - Internal links (after Tavily ranking)
    - Web search (after Tavily URL discovery)
    
    Returns {url: content} dict.
    Runs extractions in parallel (max 5 workers).
    """
    if not urls or not LITELLM_KEY:
        return {}
    
    result: Dict[str, str] = {}
    
    def _extract_one(url: str) -> tuple:
        try:
            g = _gemini_url_context(url)
            if g.get('accessible') == 'yes' and g.get('content'):
                return url, g['content']
            else:
                logger.warning(
                    f"GEMINI_EXTRACT | url='{url[:60]}' | status={g['retrieval_status']} | error={g.get('error','')}"
                )
                return url, ''
        except Exception as e:
            logger.warning(f"GEMINI_EXTRACT | url='{url[:60]}' failed: {e}")
            return url, ''
    
    with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as executor:
        futures = {executor.submit(_extract_one, u): u for u in urls}
        for future in as_completed(futures):
            url, content = future.result()
            if content:
                result[url] = content
    
    logger.info(f"GEMINI_EXTRACT | requested={len(urls)} | succeeded={len(result)}")
    return result


# ======================================================================
# _gemini_log_url (lines 3134-3145)
# ======================================================================
def _gemini_log_url(request_id: str, url: str, result: Dict[str, Any]) -> None:
    """Append a Gemini url_context result to the per-request comparison store."""
    with _gemini_comparison_lock:
        store = _gemini_comparison_store.setdefault(request_id, {'url_extractions': [], 'web_searches': []})
        store['url_extractions'].append({
            'url':               url,
            'retrieval_status':  result.get('retrieval_status', ''),
            'accessible':        result.get('accessible', 'unknown'),
            'content':           result.get('content', ''),
            'output_len':        result.get('output_len', 0),
            'error':             result.get('error', ''),
        })


# ======================================================================
# _gemini_log_search (lines 3148-3159)
# ======================================================================
def _gemini_log_search(request_id: str, query: str, result: Dict[str, Any]) -> None:
    """Append a Gemini google_search result to the per-request comparison store."""
    with _gemini_comparison_lock:
        store = _gemini_comparison_store.setdefault(request_id, {'url_extractions': [], 'web_searches': []})
        store['web_searches'].append({
            'query':           query,
            'content':         result.get('content', ''),
            'sources':         result.get('sources', []),
            'output_len':      result.get('output_len', 0),
            'grounding_used':  result.get('grounding_used', False),
            'error':           result.get('error', ''),
        })


# ======================================================================
# _tavily_search_domain (lines 3162-3242)
# ======================================================================
def _tavily_search_domain(query: str, url: str) -> Dict[str, Any]:
    """
    Search Tavily within a specific domain and return the top result.
    Routes queries through the private VPC LiteLLM proxy if available.
    """
    if not query or not url:
        return {}
        
    try:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        # Detect private Bedrock / VPC gateway environment variables
        litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
        use_private_gateway = bool(litellm_key)

        if use_private_gateway:
            # Route through corporate VPC proxy. Search-tool name is team-scoped:
            # this key is only authorized for 'ccaiaa-dev-tavily' (plain 'tavily' -> 403).
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload_data = {
                "query": query,
                "max_results": 1,
                "search_depth": "advanced",
                "include_domains": [domain]
            }
        else:
            # Local developer laptop fallback to public API
            if not TAVILY_API_KEY:
                logger.warning("TAVILY_API_KEY not configured; skipping domain search.")
                return {}
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload_data = {
                "api_key": TAVILY_API_KEY,
                "query": query,
                "search_depth": "advanced",
                "include_domains": [domain],
                "max_results": 1,
            }

        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload_data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        results = data.get('results', [])
        if not results:
            logger.info(f"TAVILY_DOMAIN_SEARCH | no results | domain={domain}")
            return {}

        top = results[0]
        score = round(min(float(top.get('score', 0.0)), 1.0), 3)
        # Gateway returns 'snippet'; public Tavily returns 'content' — accept both.
        content = (top.get('content') or top.get('snippet') or '').strip()
        result = {
            'domain':  domain,
            'url':     top.get('url', url),
            'title':   (top.get('title') or '').strip(),
            'content': content,
            'score':   score,
        }
        logger.info(f"TAVILY_DOMAIN_SEARCH | domain={domain} | score={score} | content_chars={len(content)} | title='{result['title'][:60]}'")
        return result
        
    except Exception as e:
        logger.warning(f"Tavily domain search failed for '{url[:60]}': {e}")
        return {}


# ======================================================================
# _tavily_extract (lines 3271-3409)
# ======================================================================
def _tavily_extract(urls: List[str], query: str = '') -> Dict[str, str]:
    """Return {url: content} for each URL — full page text where available.

    Gateway / VPC path (AWS_BEARER_TOKEN_BEDROCK is set):
      The private LiteLLM gateway has no /extract endpoint and does not forward
      include_raw_content to Tavily (confirmed by probe_gateway_tavily.py).
      Instead, we run one _tavily_search_domain call per URL in parallel.
      Each call queries the specific domain using the caller's topic query,
      which is the most reliable way to surface indexed content for that domain.

    Local / public path (TAVILY_API_KEY is set, no gateway token):
      Uses the dedicated api.tavily.com/extract endpoint, which returns full
      raw_content for each URL.

    Gemini comparison (parallel, non-blocking):
      For every URL, a Gemini url_context call is fired concurrently.
      Results are logged side-by-side with Tavily for comparison purposes.
      Tavily content is still used as the live source returned to callers.

    Args:
        urls:  List of URLs to fetch content for.
        query: Topic query string from the caller (topic + jurisdiction etc.).
               Used by the gateway path to drive domain-scoped searches.
               Falls back to URL-path hint when empty.

    Returns {} when no credentials are available or all calls fail (non-fatal).
    """
    if not urls:
        return {}

    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)

    if not use_private_gateway and not TAVILY_API_KEY:
        logger.warning("TAVILY_EXTRACT | no credentials available; skipping extract.")
        return {}

    # ── Fire Gemini url_context calls in parallel for comparison ─────────────
    gemini_futures: Dict[Any, str] = {}
    gemini_executor = ThreadPoolExecutor(max_workers=min(len(urls), 5))
    for u in urls:
        gemini_futures[gemini_executor.submit(_gemini_url_context, u)] = u

    if use_private_gateway:
        # ── Gateway path: one domain-search per URL, run in parallel ─────────
        result: Dict[str, str] = {}

        def _fetch_one(url: str) -> tuple:
            from urllib.parse import urlparse, unquote
            if query:
                search_query = query
            else:
                path_hint = unquote(urlparse(url).path).replace('/', ' ').replace('-', ' ').strip()
                search_query = (path_hint or urlparse(url).netloc)[:120]
            domain_result = _tavily_search_domain(search_query, url)
            content  = (domain_result.get('content') or '').strip()
            canonical = domain_result.get('url') or url
            return canonical, url, content

        with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as ex:
            futures = {ex.submit(_fetch_one, u): u for u in urls}
            for future in as_completed(futures):
                try:
                    canonical, original, content = future.result()
                    if content:
                        result[original]  = content
                        result[canonical] = content
                except Exception as e:
                    logger.warning(f"TAVILY_EXTRACT | domain fetch failed for '{futures[future][:60]}': {e}")

        logger.info(
            f"TAVILY_EXTRACT | gateway=private (domain-search) "
            f"| requested={len(urls)} | succeeded={sum(1 for u in urls if u in result)}"
        )

    else:
        # ── Public path: dedicated /extract endpoint ──────────────────────────
        result = {}
        try:
            payload_data = {
                "api_key": TAVILY_API_KEY,
                "urls": urls,
            }
            req = urllib.request.Request(
                'https://api.tavily.com/extract',
                data=json.dumps(payload_data).encode('utf-8'),
                headers={"Content-Type": "application/json"},
                method='POST',
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
                data = json.loads(resp.read().decode('utf-8'))

            for item in data.get('results', []):
                url  = item.get('url', '')
                text = (item.get('raw_content') or item.get('content') or '').strip()
                if url and text:
                    result[url] = text

            for fail in data.get('failed_results', []):
                logger.warning(f"TAVILY_EXTRACT | failed url='{fail.get('url','')}' | {fail.get('error','')}")

            logger.info(
                f"TAVILY_EXTRACT | gateway=public "
                f"| requested={len(urls)} | succeeded={len(result)}"
            )
        except Exception as e:
            logger.warning(f"Tavily extract failed (non-fatal): {e}")

    # ── Collect Gemini comparison results and write to accumulator ───────────
    try:
        for future in as_completed(gemini_futures, timeout=65):
            url = gemini_futures[future]
            try:
                g = future.result()
                tavily_len = len(result.get(url, ''))
                logger.info(
                    f"EXTRACT_COMPARE | url='{url[:80]}' "
                    f"| tavily_chars={tavily_len} "
                    f"| gemini_chars={g['output_len']} "
                    f"| gemini_accessible={g.get('accessible','unknown')} "
                    f"| gemini_retrieval_status={g['retrieval_status']} "
                    f"| gemini_error={g['error'] or 'none'}"
                )
                # Write full content to accumulator for S3 comparison file
                _request_id = _gemini_comparison_store.get('_active_request_id', '')
                if _request_id:
                    _gemini_log_url(_request_id, url, g)
            except Exception as e:
                logger.warning(f"EXTRACT_COMPARE | gemini future failed for '{url[:60]}': {e}")
    except Exception as e:
        logger.warning(f"EXTRACT_COMPARE | gemini collection error: {e}")
    finally:
        gemini_executor.shutdown(wait=False)

    return result


# ======================================================================
# _tavily_rank_curated_urls (lines 3547-3619)
# ======================================================================
def _tavily_rank_curated_urls(urls: List[str], query: str, max_results: int = 5) -> List[Dict]:
    """
    Use Tavily domain search to rank curated URLs by relevance.
    
    This function takes a list of curated URLs from DynamoDB and uses Tavily's
    search API to rank them by relevance to the query. This acts as an intelligent
    filter to reduce 20-50 curated links down to the top 3-5 most relevant ones.
    
    Returns: List of dicts with keys: url, title, relevance_score
    """
    from urllib.parse import urlparse
    
    # Extract domains from URLs
    domains = list(set(urlparse(u).netloc for u in urls if u))
    if not domains:
        return []
    
    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)
    
    try:
        if use_private_gateway:
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        else:
            if not TAVILY_API_KEY:
                return []
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload = {
                "api_key": TAVILY_API_KEY,
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        
        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        ranked = []
        for result in data.get('results', []):
            ranked.append({
                'url': result.get('url', ''),
                'title': result.get('title', ''),
                'relevance_score': float(result.get('score', 0.7))
            })
        
        logger.info(f"TAVILY_RANK_CURATED | query='{query[:60]}' | input_urls={len(urls)} | ranked={len(ranked)}")
        return ranked[:max_results]
        
    except Exception as e:
        logger.warning(f"Tavily curated URL ranking failed: {e}")
        return []


# WARNING: _tavily_fetch NOT FOUND in monolith

