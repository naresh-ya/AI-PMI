def _tavily_rank_curated_urls(urls: List[str], query: str, max_results: int = 5) -> List[Dict]:
    """
    Use Tavily domain search to rank curated URLs by relevance.
    
    This function takes a list of curated URLs from DynamoDB and uses Tavily's
    search API to rank them by relevance to the query. This acts as an intelligent
    filter to reduce 20-50 curated links down to the top 3-5 most relevant ones.
    
    Returns: List of dicts with keys: url, title, relevance_score
    """
    from urllib.parse import urlparse
    
    # Extract domains from URLs
    domains = list(set(urlparse(u).netloc for u in urls if u))
    if not domains:
        return []
    
    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)
    
    try:
        if use_private_gateway:
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        else:
            if not TAVILY_API_KEY:
                return []
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload = {
                "api_key": TAVILY_API_KEY,
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        
        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        ranked = []
        for result in data.get('results', []):
            ranked.append({
                'url': result.get('url', ''),
                'title': result.get('title', ''),
                'relevance_score': float(result.get('score', 0.7))
            })
        
        logger.info(f"TAVILY_RANK_CURATED | query='{query[:60]}' | input_urls={len(urls)} | ranked={len(ranked)}")
        return ranked[:max_results]
        
    except Exception as e:
        logger.warning(f"Tavily curated URL ranking failed: {e}")
        return []


