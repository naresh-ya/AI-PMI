# ======================================================================
# search_internal_knowledge (lines 2429-2659)
# ======================================================================
def search_internal_knowledge(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Search PMI internal knowledge base using semantic query generation."""

    jurisdiction    = requirements.get('jurisdiction', '')
    topic           = requirements.get('topic', '')
    target_audience = requirements.get('target_audience', '')
    background      = requirements.get('background', '')
    category        = requirements.get('category', '')
    use_case        = requirements.get('use_case', '')

    # Step 1 — Extract semantic signals from raw input fields
    signals           = _extract_semantic_signals(topic, background, use_case, category, jurisdiction)
    topic_core        = signals['topic_core']
    background_signal = signals['background_signal']
    intent            = _derive_intent(use_case, category)
    entity            = _derive_entity(target_audience)

    # Step 2 — Base query: all signals combined including background
    base_query = ' '.join(filter(None, [jurisdiction, topic_core, background_signal, intent, entity])).strip()

    # Step 3 — Deterministic variants covering different signal combinations
    query_1 = ' '.join(filter(None, [jurisdiction, topic_core, background_signal, intent])).strip()
    query_2 = ' '.join(filter(None, [entity, jurisdiction, topic_core, background_signal])).strip()
    query_3 = ' '.join(filter(None, [category, intent, jurisdiction, topic_core, background_signal])).strip()

    # Generic variants without jurisdiction to allow cross-border matches
    query_generic_1 = ' '.join(filter(None, [topic_core, background_signal, intent])).strip()
    query_generic_2 = ' '.join(filter(None, [topic_core, intent, entity, background_signal])).strip()

    seen: set = set()
    deterministic = [
        q for q in [base_query, query_1, query_2, query_3, query_generic_1, query_generic_2]
        if q and not (q in seen or seen.add(q))
    ]

    # Step 4 — LLM enrichment: up to 2 additional semantically rich queries
    llm_queries = _llm_enrich_queries(topic_core, intent, entity, jurisdiction, background_signal)

    # Step 4b — Include agentic planned queries if available
    planned_queries = requirements.get('_planned_queries', [])

    # Step 5 — Combine deterministic + LLM + planned, cap at 8 (allow more due to planned)
    all_queries = (deterministic + llm_queries + planned_queries)
    # Deduplicate while preserving order
    seen_q: set = set()
    dedup_queries = []
    for q in all_queries:
        q_lower = q.lower().strip()
        if q_lower and q_lower not in seen_q:
            seen_q.add(q_lower)
            dedup_queries.append(q)
    all_queries = dedup_queries[:8]

    logger.info(
        f"KB_SEMANTIC_QUERIES | count={len(all_queries)} "
        f"| deterministic={len(deterministic)} | llm={len(llm_queries)} | planned={len(planned_queries)}"
    )

    # Step 6 — Execute vector search with score-gated waterfall
    internal_sources: List[Dict] = []
    citations: List[Dict] = []
    used_query = all_queries[0] if all_queries else base_query
    kb_results: List[Dict] = []

    # Step 6a — LLM-driven soft theme mapping for KB metadata filtering
    # The LLM identifies relevant theme-level-1 and theme-level-2 from the topic/background.
    # These are used as SOFT filters (if 0 results, retry without theme filters).
    kb_theme_1 = ''
    kb_theme_2 = ''
    try:
        if LITELLM_KEY and topic_core:
            theme_prompt = (
                "You are classifying a research query for a knowledge base filter.\n\n"
                f"Topic: {topic_core}\n"
                f"Background: {background_signal[:200]}\n"
                f"Jurisdiction: {jurisdiction}\n\n"
                "LEVEL 1 OPTIONS (pick the single BEST match):\n"
                "- Smoke-free products (SFP)/ heated tobacco products (HTP)\n"
                "- Combustible cigarettes\n"
                "- Corporate Equity\n"
                "- Others\n\n"
                "LEVEL 2 OPTIONS (pick the single BEST match):\n"
                "- Regulatory, Product standard system\n"
                "- Fiscal and Taxes\n"
                "- Illicit Trade\n"
                "- Scientific\n"
                "- Youth Access Prevention\n"
                "- Sustainability\n"
                "- Others\n\n"
                "Return ONLY a JSON: {\"level_1\": \"...\", \"level_2\": \"...\"}\n"
                "If the topic doesn't clearly fit one category, use \"Others\"."
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            data = json.dumps({
                "model": LITELLM_MODEL,
                "messages": [{"role": "user", "content": theme_prompt}],
                "max_tokens": 100,
            }).encode('utf-8')
            headers_req = {
                "Authorization": f"Bearer {LITELLM_KEY}",
                "Content-Type": "application/json",
            }
            req = urllib.request.Request(LITELLM_URL, data=data, headers=headers_req, method='POST')
            with urllib.request.urlopen(req, context=ctx, timeout=10) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['choices'][0]['message']['content'].strip()
                if raw.startswith('```'):
                    raw = '\n'.join(raw.split('\n')[1:-1]).strip()
                theme_result = json.loads(raw)
                kb_theme_1 = theme_result.get('level_1', '')
                kb_theme_2 = theme_result.get('level_2', '')
                # Don't filter on "Others" — it's too generic
                if kb_theme_1 == 'Others':
                    kb_theme_1 = ''
                if kb_theme_2 == 'Others':
                    kb_theme_2 = ''
                logger.info(f"KB_THEME_MAP | topic='{topic_core[:50]}' | L1='{kb_theme_1}' | L2='{kb_theme_2}'")
    except Exception as e:
        logger.warning(f"KB theme mapping failed (non-fatal, will search without theme filter): {e}")

    try:
        if search_pmi_knowledge_base:
            kb_filters = {}
            if jurisdiction:
                kb_filters['jurisdiction'] = jurisdiction

            # First attempt: with theme filters (soft)
            for candidate_query in all_queries:
                results = search_pmi_knowledge_base(
                    query=candidate_query, max_results=15, filters=kb_filters,
                    jurisdiction=jurisdiction, theme_level_1=kb_theme_1, theme_level_2=kb_theme_2
                )
                if results:
                    max_score = max((r.get('similarity_score', 0) for r in results), default=0)
                    logger.info(
                        f"KB_QUERY | query='{candidate_query[:80]}' "
                        f"| results={len(results)} | max_score={max_score:.3f}"
                    )
                    if max_score >= 0.50:
                        kb_results = results
                        used_query = candidate_query
                        logger.info(f"KB_HIT | query='{candidate_query[:80]}'")
                        break
                else:
                    logger.info(f"KB_QUERY | query='{candidate_query[:80]}' | results=0")

            # Fallback: if theme filters produced 0 results, retry without them
            if not kb_results and (kb_theme_1 or kb_theme_2):
                logger.info(f"KB_FALLBACK | theme filters produced 0 results, retrying without theme filters")
                for candidate_query in all_queries:
                    results = search_pmi_knowledge_base(
                        query=candidate_query, max_results=15, filters=kb_filters,
                        jurisdiction=jurisdiction
                    )
                    if results:
                        max_score = max((r.get('similarity_score', 0) for r in results), default=0)
                        if max_score >= 0.50:
                            kb_results = results
                            used_query = candidate_query
                            logger.info(f"KB_FALLBACK_HIT | query='{candidate_query[:80]}' | score={max_score:.3f}")
                            break

            # Category-aware KB result limit
            cat_lower = (category or '').lower()
            if 'white paper' in cat_lower or 'narrative' in cat_lower:
                kb_limit = 8  # More KB sources for comprehensive documents
            else:
                kb_limit = 5

            # Apply limit to kb_results before processing
            kb_results = kb_results[:kb_limit]
            logger.info(f"KB_RESULTS | category={category} | limit={kb_limit} | results={len(kb_results)}")

            seen_titles = set()
            for i, result in enumerate(kb_results):
                if result.get('similarity_score', 0) < 0.50:
                    continue

                doc_name = (
                    result.get('document_title')
                    or result.get('metadata', {}).get('file_name')
                    or f'Document_{i}'
                )
                
                # Extract URL properly from any possible metadata field
                meta = result.get('metadata', {})
                sp_url = (
                    result.get('sharepoint_url') or 
                    meta.get('sharepoint_url') or 
                    meta.get('sharepoint_link') or 
                    meta.get('source_url') or 
                    meta.get('url') or 
                    meta.get('s3_bucket_URL') or 
                    ""
                )
                
                # Exclude metadata.json files from sources and citations
                if 'metadata.json' in str(doc_name).lower() or 'metadata.json' in str(sp_url).lower():
                    continue
                
                internal_sources.append({
                    'title': doc_name,
                    'source': 'PMI Knowledge Base',
                    'type': 'internal_knowledge',
                    'date': datetime.now().strftime('%Y-%m-%d'),
                    'relevance_score': round(float(result.get('similarity_score', 0)), 3),
                    'summary': result.get('content', ''),
                })
                
                # Deduplicate citations and remove snippets
                if doc_name not in seen_titles:
                    seen_titles.add(doc_name)
                    
                    citations.append({
                        'title': f"{doc_name}",
                        'url': sp_url,
                        'source_type': 'knowledge_base'
                    })
    except Exception as e:
        logger.error(f"Error querying KB: {str(e)}")

    if not internal_sources:
        logger.warning("KB search returned no results.")

    return {
        'sources': internal_sources,
        'citations': citations,
        'queries': [used_query] + [q for q in all_queries if q != used_query],
    }


# ======================================================================
# stage_kb (lines 594-596)
# ======================================================================
def stage_kb(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """KB-search stage."""
    return search_internal_knowledge(requirements)


