# ======================================================================
# stage_synthesis (lines 679-699)
# ======================================================================
def stage_synthesis(requirements: Dict[str, Any], research_results: Dict[str, Any],
                    request_id: str, research_start: datetime) -> Dict[str, Any]:
    """Terminal synthesis stage: global dedup → finalize → synthesize/persist/return.

    This is the ONLY stage that writes research_data.json to S3, sets RESEARCH_COMPLETED
    in DynamoDB, and returns the canonical research_summary. Mirrors the monolith tail
    (the dedup that conduct_comprehensive_research did before finalize + build).
    """
    # Global URL dedup (the synthesis stage owns it, since retrieval ran in parallel)
    research_results['all_sources'] = _dedup_sources_by_url(research_results.get('all_sources', []))
    seen: set = set()
    out_cit = []
    for c in research_results.get('formatted_citations', []):
        key = (c.get('url', '') or '').strip().lower() or (c.get('title', '') or '').strip().lower()
        if key and key not in seen:
            seen.add(key)
            out_cit.append(c)
    research_results['formatted_citations'] = out_cit

    research_results = finalize_research_results(research_results, requirements, request_id)
    return build_research_output(research_results, requirements, request_id, research_start)


# ======================================================================
# stage_synthesis_from_parallel (lines 702-723)
# ======================================================================
def stage_synthesis_from_parallel(requirements: Dict[str, Any], parallel_outputs: List[Dict[str, Any]],
                                  request_id: str, research_start: datetime) -> Dict[str, Any]:
    """Terminal synthesis for the Step-Functions split (client-demo2).

    The SF Parallel state returns a LIST of branch outputs in a FIXED order that mirrors
    the branch definition in step_functions_definition_client_demo2.json:
        index 0 = KBSearch, 1 = WebSearch, 2 = UserSources, 3 = CuratedLinks
    Each element is a stage dict ({'sources','citations','queries'} or a Catch fallback
    {'sources':[], 'error':...}). We map them back to named stages, aggregate exactly like
    the monolith Phase 1/2 merge, then run the shared dedup + finalize + build tail.
    """
    parallel_outputs = parallel_outputs or []
    _BRANCH_ORDER = ['kb', 'web', 'user_sources', 'curated']
    stage_outputs: Dict[str, Dict[str, Any]] = {}
    for idx, name in enumerate(_BRANCH_ORDER):
        out = parallel_outputs[idx] if idx < len(parallel_outputs) else {}
        stage_outputs[name] = out if isinstance(out, dict) else {}
        if stage_outputs[name].get('error'):
            logger.warning(f"[{request_id}] SPLIT_SYNTH | branch '{name}' reported: {stage_outputs[name].get('error')}")

    research_results = _aggregate_stage_sources(stage_outputs, request_id)
    return stage_synthesis(requirements, research_results, request_id, research_start)


# ======================================================================
# _seed_research_results (lines 572-585)
# ======================================================================
def _seed_research_results() -> Dict[str, Any]:
    """Empty research_results envelope — identical shape to the monolith's Phase 1 seed."""
    return {
        'all_sources': [],
        'uploaded_file_count': 0,
        'kb_count': 0,
        'external_links_count': 0,
        'internal_links_count': 0,
        'web_search_count': 0,
        'consolidated_score': 0.0,
        'web_search_triggered': True,
        'formatted_citations': [],
        'search_queries': [],
    }


# ======================================================================
# finalize_research_results (lines 1300-1472)
# ======================================================================
def finalize_research_results(research_results: Dict[str, Any], requirements: Dict[str, Any],
                              request_id: str) -> Dict[str, Any]:
    """Phase 3 relevance loop + rerank + relevance floor + unified top-k + structured
    fact extraction + final source-count recalculation + citation filtering.

    Extracted from conduct_comprehensive_research so the split synthesis lambda and the
    monolith share the IDENTICAL finalization logic. Mutates and returns research_results.
    Expects requirements to already carry _research_framing, _planned_queries and
    _jurisdiction_context (set by the planning stage).
    """
    # ── Phase 3 — Relevance-driven retrieval loop (≤4 iterations, time-boxed) ──
    # Goal: keep retrieving (KB + web, with escalating agentic reformulation) until at
    # least MIN_RELEVANT genuinely on-topic sources are found. This prevents drafting a
    # document from scored-but-off-topic sources (the failure where a PMI sustainability
    # request collapsed into government foreign-trade results). Coverage is still used as
    # a secondary signal once relevance is satisfied. Hard-bounded by iterations and a
    # wall-clock budget so the Lambda always returns cleanly.
    import time as _time
    RESEARCH_BUDGET_S = int(os.environ.get('RESEARCH_BUDGET_SECONDS', '540'))  # ~9 min, margin under 15-min Lambda
    deadline = _time.time() + RESEARCH_BUDGET_S
    MIN_RELEVANT = 3
    MAX_RELEVANCE_ITERS = 4
    COVERAGE_TARGET = 0.7

    framing = requirements.get('_research_framing', {}) or {}
    tried_queries: List[str] = list(requirements.get('_planned_queries', []) or [])

    def _coverage_ratio(rr: Dict[str, Any]) -> float:
        """Cheap coverage signal: fraction toward a target of strong/diverse sources."""
        srcs = rr.get('all_sources', [])
        strong = [
            s for s in srcs
            if s.get('relevance_score') is None or (s.get('relevance_score') or 0) >= 0.5
        ]
        return min(1.0, len(strong) / 6.0)

    def _rededup_citations() -> None:
        seen = set()
        out = []
        for c in research_results.get('formatted_citations', []):
            key = (c.get('url', '') or '').strip().lower() or (c.get('title', '') or '').strip().lower()
            if key and key not in seen:
                seen.add(key)
                out.append(c)
        research_results['formatted_citations'] = out

    relevant_count = _annotate_relevance(research_results['all_sources'], framing, requirements)
    logger.info(f"[{request_id}] RELEVANCE | initial on-topic sources={relevant_count} (target={MIN_RELEVANT})")

    for rel_iter in range(MAX_RELEVANCE_ITERS):
        coverage = _coverage_ratio(research_results)
        if relevant_count >= MIN_RELEVANT and coverage >= COVERAGE_TARGET:
            logger.info(
                f"[{request_id}] RELEVANCE | satisfied at iter {rel_iter} "
                f"(relevant={relevant_count}, coverage={coverage:.2f}); stopping"
            )
            break
        if _time.time() >= deadline:
            logger.warning(f"[{request_id}] RELEVANCE | time budget exhausted at iter {rel_iter}; stopping")
            break

        # Choose reformulation strategy: prioritise relevance recovery when we lack
        # on-topic sources; otherwise fall back to coverage gap-fill.
        try:
            if relevant_count < MIN_RELEVANT:
                new_queries = _llm_reformulate_for_relevance(framing, requirements, tried_queries, rel_iter)
                reason = 'relevance'
            else:
                new_queries = _llm_identify_gaps(research_results, requirements)
                reason = 'coverage'
            if not new_queries:
                logger.info(f"[{request_id}] RELEVANCE | iter {rel_iter}: no new {reason} queries; stopping")
                break
            new_queries = new_queries[:3]
            tried_queries.extend(new_queries)
            logger.info(f"[{request_id}] RELEVANCE | iter {rel_iter} ({reason}) queries={new_queries}")
            _fill_research_gaps(new_queries, research_results, requirements)
            research_results['all_sources'] = _dedup_sources_by_url(research_results['all_sources'])
            _rededup_citations()
            relevant_count = _annotate_relevance(research_results['all_sources'], framing, requirements)
            logger.info(f"[{request_id}] RELEVANCE | after iter {rel_iter}: on-topic sources={relevant_count}")
        except Exception as e:
            logger.warning(f"[{request_id}] RELEVANCE | iter {rel_iter} failed (non-fatal): {e}")
            break

    # Record final relevance signal for the synthesis gate and downstream review.
    research_results['_relevant_count'] = relevant_count
    research_results['_low_relevance'] = relevant_count < MIN_RELEVANT
    research_results['_research_framing'] = framing
    if relevant_count == 0:
        logger.critical(
            f"[{request_id}] RELEVANCE | ZERO on-topic sources after {MAX_RELEVANCE_ITERS} iterations — "
            f"synthesis will short-circuit to no_data rather than draft off-topic content."
        )

    # ── Rerank: cross-encoder relevancy over the full pool (primary ranking signal) ──
    # Query is built from the understood intent + topic. Non-fatal: on failure the pool
    # is returned unchanged and _unified_top_k falls back to trust/relevance ranking.
    _rerank_query = ' '.join(filter(None, [
        framing.get('intent', '') if isinstance(framing, dict) else '',
        requirements.get('topic', ''),
    ])).strip() or requirements.get('topic', '')
    research_results['all_sources'] = _rerank_sources(_rerank_query, research_results['all_sources'])

    # Relevance floor: drop clearly off-topic sources (rerank_score < RERANK_MIN_SCORE),
    # but only if enough on-topic sources remain — never starve synthesis. uploaded_file exempt.
    _scored = [s for s in research_results['all_sources'] if s.get('rerank_score') is not None]
    if _scored:
        _kept = [
            s for s in research_results['all_sources']
            if s.get('type') == 'uploaded_file'
            or s.get('rerank_score') is None
            or s.get('rerank_score') >= RERANK_MIN_SCORE
        ]
        if len([s for s in _kept if s.get('type') != 'uploaded_file']) >= 3:
            dropped = len(research_results['all_sources']) - len(_kept)
            if dropped:
                logger.info(f"[{request_id}] RERANK_FLOOR | dropped {dropped} source(s) below {RERANK_MIN_SCORE}")
            research_results['all_sources'] = _kept

    # ── Final: unified trust-weighted ranking + dedup/diversity → top 15 ──────
    research_results['all_sources'] = _unified_top_k(research_results['all_sources'], k=15)

    # ── Structured fact extraction (1 Gemini call) ────────────────────────────
    try:
        research_results['structured_facts'] = _extract_structured_facts(
            research_results['all_sources'], requirements
        )
        logger.info(f"[{request_id}] Structured facts extracted: {len(research_results.get('structured_facts', {}).get('statistics', []))} stats")
    except Exception as e:
        logger.warning(f"[{request_id}] Structured fact extraction failed (non-fatal): {e}")
        research_results['structured_facts'] = {}

    # Recalculate source counts after dedup, gap fill, and top_k
    research_results['kb_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'internal_knowledge')
    research_results['web_search_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'web_search')
    research_results['external_links_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'external_url')
    research_results['internal_links_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'internal_url')
    research_results['uploaded_file_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'uploaded_file')

    # Filter citations to only include sources that survived top_k
    surviving_urls = {
        (s.get('url') or s.get('source') or '').strip().lower(): s.get('relevance_score')
        for s in research_results['all_sources']
    }
    surviving_titles = {
        (s.get('title') or '').strip().lower(): s.get('relevance_score')
        for s in research_results['all_sources']
    }
    filtered_citations = []
    for c in research_results.get('formatted_citations', []):
        c_url = (c.get('url') or '').strip().lower()
        c_title = (c.get('title') or '').strip().lower()
        if c_url and c_url in surviving_urls:
            c['relevance_score'] = surviving_urls[c_url]
            filtered_citations.append(c)
        elif c_title and c_title in surviving_titles:
            c['relevance_score'] = surviving_titles[c_title]
            filtered_citations.append(c)
    research_results['formatted_citations'] = filtered_citations

    # Store jurisdiction context for drafter consumption via S3
    research_results['_jurisdiction_context_for_drafter'] = requirements.get('_jurisdiction_context', '')

    logger.info(
        f"[{request_id}] Research complete | total_sources={len(research_results['all_sources'])} "
        f"| web={research_results['web_search_count']} "
        f"| kb={research_results['kb_count']} "
        f"| external={research_results['external_links_count']} "
        f"| internal={research_results['internal_links_count']}"
    )

    return research_results


# ======================================================================
# build_research_output (lines 331-465)
# ======================================================================
def build_research_output(research_results: Dict[str, Any], document_requirements: Dict[str, Any],
                          request_id: str, research_start: datetime) -> Dict[str, Any]:
    """Synthesize findings, persist to S3, assemble the canonical research_summary,
    mark RESEARCH_COMPLETED, and return it.

    Extracted from lambda_handler so BOTH the monolith and the split synthesis lambda
    produce the IDENTICAL output contract (return shape + S3 object + status). Do not
    change the shape here without updating the drafter/UI consumers.
    """
    # Synthesize research findings using Bedrock
    synthesis_result = synthesize_research_findings(research_results, document_requirements)

    # Persist full research data (all_sources + synthesis) to S3 so the drafter can load it
    research_s3_key = _store_research_to_s3(request_id, research_results, synthesis_result)

    # Build structured sources deterministically from research results
    structured_sources = build_structured_sources(research_results)

    # Derive FE-aligned fields from structured_sources — single source of truth
    citation_count = len(research_results.get('formatted_citations', []))
    jurisdiction   = document_requirements.get('jurisdiction', 'the target jurisdiction')

    # Group by source_type so sources_found always matches the sources array exactly
    _ALL_TYPES = ('knowledge_base', 'uploaded_file', 'internal_url', 'web_search', 'external_url')
    type_counts: Dict[str, int] = {t: 0 for t in _ALL_TYPES}
    for s in structured_sources:
        t = s.get('source_type', '')
        if t in type_counts:
            type_counts[t] += 1

    sources_found = {t: {'count': c} for t, c in type_counts.items() if c > 0}

    total_sources = len(structured_sources)
    research_strategy = {
        'approach': (
            f"Multi-source research across {total_sources} source(s) covering PMI internal "
            f"knowledge base and web search for {jurisdiction}."
        )
    }

    # ── Compute aggregate quality scores from real per-source relevance scores ─
    all_real_scores = [
        s['relevance_score']
        for s in structured_sources
        if s.get('relevance_score') is not None and s.get('relevance_score', 0) > 0
    ]
    kb_scores = [
        s['relevance_score']
        for s in structured_sources
        if s.get('source_type') == 'knowledge_base'
        and s.get('relevance_score') is not None
    ]

    if all_real_scores:
        confidence_score     = round(sum(all_real_scores) / len(all_real_scores), 1)
        source_quality_score = max(all_real_scores)
    else:
        confidence_score     = 0.0
        source_quality_score = 0

    if kb_scores:
        evidence_quality_score = round(sum(kb_scores) / len(kb_scores), 1)
    else:
        evidence_quality_score = confidence_score

    elapsed_seconds  = round((datetime.now() - research_start).total_seconds(), 1)
    research_duration = f"{elapsed_seconds}s"

    logger.info(
        f"[{request_id}] Scores | confidence={confidence_score} "
        f"| source_quality={source_quality_score} "
        f"| evidence_quality={evidence_quality_score} "
        f"| duration={research_duration}"
    )

    research_summary = {
        "status": "success",
        "request_id": request_id,
        "research_summary": {
            "total_sources": len(research_results.get('all_sources', [])),
            "uploaded_file_sources": research_results.get('uploaded_file_count', 0),
            "kb_sources": research_results.get('kb_count', 0),
            "external_link_sources": research_results.get('external_links_count', 0),
            "internal_link_sources": research_results.get('internal_links_count', 0),
            "web_search_sources": research_results.get('web_search_count', 0),
            "confidence_score":    confidence_score,
            "research_duration":   research_duration,
            "relevant_sources":    research_results.get('_relevant_count', 0),
            "low_relevance":       research_results.get('_low_relevance', False),
        },
        "key_findings": synthesis_result.get('key_findings', []),
        "policy_insights": synthesis_result.get('policy_insights', []),
        "recommendations": synthesis_result.get('recommendations', []),
        "research_s3_key": research_s3_key,
        "citations": research_results.get('formatted_citations', []),
        "next_agent": "master_drafter",
        "research_metadata": {
            "search_queries": research_results.get('search_queries', []),
            "source_quality_score": source_quality_score,
            "coverage_assessment": "Comprehensive - All required topics covered",
            "total_sources": len(research_results.get('all_sources', [])),
            "consolidated_score": research_results.get('consolidated_score', 0.0),
            "web_search_triggered": research_results.get('web_search_triggered', False),
            "research_framing": research_results.get('_research_framing', {}),
        },
        "citation_count": citation_count,
        "evidence_quality_score": evidence_quality_score,
        "knowledge_gaps": synthesis_result.get('knowledge_gaps', []),
        "data_quality_flags": synthesis_result.get('data_quality_flags', []),
        "relevant_source_count": research_results.get('_relevant_count', 0),
        "low_relevance": research_results.get('_low_relevance', False),
        "sources_found": sources_found,
        "research_strategy": research_strategy,
        "policy_intelligence": None,
        "sources": structured_sources,
    }

    uploaded_file_summary = ""
    for source in research_results.get('all_sources', []):
        if source.get('type') == 'uploaded_file':
            uploaded_file_summary = source.get('summary', '')
            break

    update_request_status(
        request_id,
        'RESEARCH_COMPLETED',
        'Research completed successfully',
        research_output=research_summary,
        uploaded_file_summary=uploaded_file_summary
    )
    logger.info(
        f"[{request_id}] Research completed: {len(structured_sources)} sources, "
        f"{citation_count} citations"
    )
    return research_summary


# ======================================================================
# update_request_status (lines 4727-4774)
# ======================================================================
def update_request_status(request_id: str, status: str, notes: str, research_output: Dict = None, uploaded_file_summary: str = None) -> None:
    """Update request status in DynamoDB"""
    
    def _convert_floats_to_decimals(obj):
        from decimal import Decimal
        if isinstance(obj, float):
            return Decimal(str(obj))
        elif isinstance(obj, dict):
            return {k: _convert_floats_to_decimals(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [_convert_floats_to_decimals(x) for x in obj]
        return obj

    try:
        from datetime import datetime
        timestamp = datetime.utcnow().isoformat() + 'Z'
        
        update_expr = 'SET #status = :status, #notes = :notes, #updated_at = :timestamp'
        expr_names = {
            '#status': 'status',
            '#notes': 'processing_notes',
            '#updated_at': 'updated_at'
        }
        expr_values = {
            ':status': status,
            ':notes': notes,
            ':timestamp': datetime.now().isoformat()
        }
        
        if research_output is not None:
            research_output = _convert_floats_to_decimals(research_output)
            update_expr += ', #research_output = :research_output'
            expr_names['#research_output'] = 'research_output'
            expr_values[':research_output'] = research_output
            
        if uploaded_file_summary:
            update_expr += ', #uploaded_file_summary = :uploaded_file_summary'
            expr_names['#uploaded_file_summary'] = 'uploaded_file_summary'
            expr_values[':uploaded_file_summary'] = uploaded_file_summary
            
        requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values
        )
    except Exception as e:
        logger.error(f"Error updating request status: {str(e)}")


# ======================================================================
# synthesize_research_findings (lines 3936-4174)
# ======================================================================
def synthesize_research_findings(research_results: Dict[str, Any], requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Use AWS Bedrock to synthesize research findings into key insights"""
    
    try:
        retrieved_docs = research_results.get('all_sources', [])
        query = research_results.get('search_queries', [''])[0] if research_results.get('search_queries') else 'No query'
        
        # All relevance_score values are now on 0–1 scale. uploaded_file has None — exclude it.
        real_scores = [doc['relevance_score'] for doc in retrieved_docs if doc.get('relevance_score') is not None]
        max_similarity_score = round(max(real_scores), 3) if real_scores else 0.0
        
        # Check if a user-uploaded file is present in the retrieved sources
        has_uploaded_file = any(doc.get('type') == 'uploaded_file' for doc in retrieved_docs)
        
        logger.info(f"query: {query}")
        logger.info(f"len(retrieved_docs): {len(retrieved_docs)}")
        logger.info(f"max similarity score: {max_similarity_score}")
        logger.info(f"has uploaded file: {has_uploaded_file}")

        # Prepare research summary for Bedrock
        sources_summary = create_sources_summary(research_results)
        
        if not retrieved_docs:
            return {
                "status": "no_data",
                "message": "No research sources found.",
                "key_findings": [],
                "policy_insights": [],
                "recommendations": [
                    "Refine your query",
                    "Upload relevant documents",
                    "Ensure correct domain/topic"
                ]
            }

        # Relevance gate: if the retrieval loop found ZERO genuinely on-topic sources,
        # do NOT synthesize from off-topic material — short-circuit to no_data so the
        # drafter shows a refine/upload message instead of a wrong document.
        if research_results.get('_relevant_count') == 0:
            logger.critical(
                "SYNTHESIS_GATE | zero on-topic sources — short-circuiting to no_data "
                "instead of drafting from off-topic research."
            )
            return {
                "status": "no_data",
                "message": "No sources relevant to the requested topic were found.",
                "key_findings": [],
                "policy_insights": [],
                "recommendations": [
                    "Refine the topic to be more specific",
                    "Upload relevant source documents",
                    "Verify the subject/entity and jurisdiction"
                ],
                "data_quality_flags": [
                    "Retrieval found no sources matching the requested topic after multiple "
                    "reformulation attempts; document generation was skipped."
                ],
            }
        
        sources_section = f"Research Sources Summary:\n        {sources_summary}" if sources_summary.strip() else "Note: No specific research sources were found in the knowledge base for this query. Exclude all external knowledge and inventions. Since no sources are available, strictly return empty lists for all required JSON keys."

        from core.prompt_registry_new import get_agent_prompt, get_jurisdiction_context
        category = requirements.get('category', '')
        jurisdiction = requirements.get('jurisdiction', '')
        system_prompt = get_agent_prompt(category, agent="researcher")
        jurisdiction_context = get_jurisdiction_context(jurisdiction)

        logger.info(f"PROMPT_ROUTING | category={category} | jurisdiction={jurisdiction} | agent=researcher | docs={len(retrieved_docs)} | max_score={max_similarity_score}")
        
        req_copy = requirements.copy()

        # Include human reviewer feedback when this is a re-research run
        re_research_feedback = (req_copy.get('re_research_feedback') or '').strip()
        feedback_block = (
            f"\n        HUMAN REVIEWER FEEDBACK (must be addressed in your synthesis):\n"
            f"        {re_research_feedback}\n"
            if re_research_feedback else ''
        )

        user_prompt = f"""
        Jurisdiction context: {jurisdiction_context}
        {feedback_block}
"""
        # Inject jurisdiction file context (authoritative regulatory reference)
        jur_file_context = requirements.get('_jurisdiction_context', '')
        if jur_file_context:
            user_prompt += f"""
        JURISDICTION REGULATORY CONTEXT (use as primary reference, do not contradict):
        {jur_file_context[:JURISDICTION_CTX_MAX]}
"""

        user_prompt += f"""
        DOCUMENT PURPOSE — this is the primary lens for your synthesis:
        - Topic: {req_copy.get('topic', 'N/A')}
        - User Query / Purpose: {req_copy.get('user_query', '') or req_copy.get('background', 'N/A')}
        - Document type: {req_copy.get('document_type', 'submission')}
        - Target audience: {req_copy.get('target_audience', 'officials')}
        - Jurisdiction: {req_copy.get('jurisdiction', 'N/A')}

        Synthesize the research below so that it directly serves the User Query / Purpose for
        this audience. Prioritise information that helps achieve that purpose; do not produce a
        generic jurisdiction overview.

        <documents>
        {sources_section}
        </documents>

        Output a valid JSON object with exactly three keys, each a list of strings. The three
        lists must play DISTINCT roles and must NOT overlap — the same fact must appear in only
        one list, phrased once:
        - 'key_findings': concrete factual evidence (data, study results, product/scientific facts,
          specific events). These support the evidence/body sections of the document.
        - 'policy_insights': the regulatory/policy landscape and contextual analysis (current
          status, authorities, frameworks, positions). These support background/context sections.
        - 'recommendations': specific, actionable recommendations or principles. These support the
          recommendations section.

        Quality rules:
        - Make each item self-contained and distinct. Do NOT restate the same point across items
          or across the three lists.
        - Aim for enough distinct items to cover the document (roughly 6-10 key_findings,
          3-6 policy_insights, 3-6 recommendations) where the sources support it.
        - Anchor every item to the Topic/Purpose above; omit material irrelevant to the purpose.

        CRITICAL CITATION RULE:
        - Each finding MUST end with a source attribution in the format [Source: N] where N is the source number from the documents above.
        - Example: "India enacted COTPA 2003 as the key tobacco control legislation. [Source: 2]"
        - If a finding draws from multiple sources, cite all: [Source: 1, 3]
        - NEVER invent a source number. Only use numbers that appear in the documents above.
        
        CRITICAL JSON RULES:
        1. All double quotes inside your string values MUST be escaped (e.g., \"quote\").
        2. Do not include any conversational text before or after the JSON.
        3. Do not use unescaped newlines inside strings.

        Focus on: {req_copy.get('jurisdiction', 'India')} jurisdiction and ensure compliance with local regulations.
        """
        
        # Dump prompt to file for debugging (Disabled for AWS Lambda read-only filesystem)
        # with open('prompt_dump.txt', 'w', encoding='utf-8') as f:
        #     f.write(prompt)
            
        # Bypass SSL verification like verify=False
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": LLM_MODEL_REASONING,
            "system": system_prompt.strip(),
            "messages": [
                {"role": "user", "content": user_prompt.strip()}
            ],
            "temperature": 0.2,
            "max_tokens": 4096
        }
        
        req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')

        import re
        import time as _time
        _rid = requirements.get('request_id', 'unknown') if isinstance(requirements, dict) else 'unknown'
        _preflight_prompt_budget(system_prompt, user_prompt, "research_synthesis", _rid)
        # Retry transient gateway failures (502/503/504/429, connection errors) with backoff
        # before giving up — the synthesis call is fatal to the stage, so self-heal blips.
        ai_response = None
        for _attempt in range(3):
            try:
                with urllib.request.urlopen(req, context=ctx, timeout=180) as response:
                    res = json.loads(response.read().decode('utf-8'))
                    _check_response_truncation(res, "research_synthesis", _rid)
                    ai_response = res['choices'][0]['message']['content'].strip()
                break
            except urllib.error.HTTPError as _he:
                if _he.code in (429, 500, 502, 503, 504) and _attempt < 2:
                    _wait = 2 ** _attempt
                    logger.warning(f"SYNTHESIS_LLM | transient HTTP {_he.code}; retry {_attempt + 1}/3 after {_wait}s")
                    _time.sleep(_wait)
                    continue
                raise
            except urllib.error.URLError as _ue:
                if _attempt < 2:
                    _wait = 2 ** _attempt
                    logger.warning(f"SYNTHESIS_LLM | transient URLError ({_ue}); retry {_attempt + 1}/3 after {_wait}s")
                    _time.sleep(_wait)
                    continue
                raise

        # Robust JSON extraction
        match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', ai_response)
        if match:
            ai_response = match.group(1).strip()
        else:
            # Fallback to finding the outermost curly braces
            start_idx = ai_response.find('{')
            end_idx = ai_response.rfind('}')
            if start_idx != -1 and end_idx != -1:
                ai_response = ai_response[start_idx:end_idx+1]
                    
        try:
            synthesis_result = json.loads(ai_response)
        except json.JSONDecodeError as e:
            logger.warning(f"Synthesis JSON parse failed ({e}); attempting light repair.")
            # Light repair: strip trailing commas before } or ]
            repaired = re.sub(r',\s*([}\]])', r'\1', ai_response)
            try:
                synthesis_result = json.loads(repaired)
                logger.info("Synthesis JSON recovered after repair.")
            except json.JSONDecodeError:
                logger.error(f"Failed to parse LLM JSON after repair. Raw Output: {ai_response[:1000]}")
                # Neutral fallback — never inject error strings into the document.
                synthesis_result = {
                    "key_findings": [],
                    "policy_insights": [],
                    "recommendations": [],
                }
        # Guarantee the expected shape with list values
        for _k in ('key_findings', 'policy_insights', 'recommendations'):
            if not isinstance(synthesis_result.get(_k), list):
                synthesis_result[_k] = []
        # Flag internally inconsistent numeric claims (e.g. wrong magnitude/units) for review
        synthesis_result = _flag_numeric_inconsistencies(synthesis_result)
        return synthesis_result
        
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        logger.error(f"HTTP Error {e.code}: {error_body}")
        
        # Inject the full sources section into the error to see what triggered the guardrail
        preview = sources_section[:8000]
        raise Exception(f"HTTP {e.code}: {error_body} | Context Preview: {preview}")
    except Exception as e:
        logger.error(f"Error in research synthesis: {str(e)}")
        raise e


# ======================================================================
# _unified_top_k (lines 895-1004)
# ======================================================================
def _unified_top_k(sources: List[Dict], k: int = 8) -> List[Dict]:
    """
    Select top-k sources using a unified trust-weighted score.

    Trust weights per source type:
      internal_knowledge  → 1.00  (highest — internal verified content)
      uploaded_file       → 1.00  (user-provided, always trusted)
      internal_url        → 0.85  (curated portals)
      external_url        → 0.80  (user-provided URLs)
      web_search          → 0.65  (lowest — freshness but unverified)

    Final score = relevance_score × trust_weight
    uploaded_file (relevance_score=None) always placed first.
    """
    _TRUST: Dict[str, float] = {
        'internal_knowledge': 1.00,
        'uploaded_file':      1.00,
        'internal_url':       0.85,
        'external_url':       0.80,
        'web_search':         0.65,
    }

    def _weighted(s: Dict) -> float:
        if s.get('type') == 'uploaded_file':
            return 2.0   # user-provided — always first
        score = s.get('relevance_score')
        rerank = s.get('rerank_score')
        if score is None and rerank is None:
            return 2.0   # no signal (e.g. uploaded_file without score) — keep first
        trust = _TRUST.get(s.get('type', ''), 0.70)
        # Rerank (cross-encoder) is the primary relevancy signal when present; the
        # prior relevance_score acts as a secondary signal. Falls back to relevance
        # alone when rerank is unavailable (rerank call failed → safe degradation).
        if rerank is not None:
            rel = float(score) if score is not None else rerank
            core = 0.75 * rerank + 0.25 * rel
        else:
            core = float(score)
        base_score = core * trust

        # Recency bonus: sources from current year get +0.05
        date_str = s.get('date', '')
        if date_str:
            try:
                source_year = int(date_str[:4])
                current_year = datetime.now().year
                if source_year == current_year:
                    base_score += 0.05
                elif source_year == current_year - 1:
                    base_score += 0.02
            except (ValueError, IndexError):
                pass

        return round(base_score, 4)

    ranked = sorted(sources, key=_weighted, reverse=True)

    # M3: diversity-aware selection.
    #  (a) Allow up to MAX_PER_DOC chunks from the same document so one document can't
    #      monopolise the slots, while still preserving depth from a key source.
    #  (b) Apply a SOFT per-type cap (type-capped items are deferred, not dropped, and
    #      backfill when the pool is thin) so a single type can't crowd out diversity
    #      yet we never starve synthesis of the best (usually internal KB) content.
    MAX_PER_DOC = 2
    type_cap = max(2, int(k * 0.6))
    title_counts: Dict[str, int] = {}
    type_counts: Dict[str, int] = {}
    selected: List[Dict] = []
    deferred: List[Dict] = []

    def _title_key(s: Dict) -> str:
        return (s.get('title') or s.get('document_title') or '').strip().lower()

    for s in ranked:
        if len(selected) >= k:
            break
        # uploaded_file is always included, exempt from caps
        if s.get('type') == 'uploaded_file':
            selected.append(s)
            continue
        tkey = _title_key(s)
        if tkey and title_counts.get(tkey, 0) >= MAX_PER_DOC:
            continue  # already have enough chunks from this document
        stype = s.get('type', '?')
        if type_counts.get(stype, 0) >= type_cap:
            deferred.append(s)
            continue
        selected.append(s)
        type_counts[stype] = type_counts.get(stype, 0) + 1
        if tkey:
            title_counts[tkey] = title_counts.get(tkey, 0) + 1

    # Backfill remaining slots from deferred (type-capped) items, still honouring
    # the per-document limit.
    if len(selected) < k:
        for s in deferred:
            if len(selected) >= k:
                break
            tkey = _title_key(s)
            if tkey and title_counts.get(tkey, 0) >= MAX_PER_DOC:
                continue
            selected.append(s)
            if tkey:
                title_counts[tkey] = title_counts.get(tkey, 0) + 1

    logger.info(
        f"UNIFIED_RANK | total_pool={len(sources)} | k={k} | selected={len(selected)} "
        f"| types={[s.get('type','?') for s in selected]}"
    )
    return selected


# ======================================================================
# _rerank_sources (lines 825-892)
# ======================================================================
def _rerank_sources(query: str, sources: List[Dict], top_n: int = None) -> List[Dict]:
    """Cross-encoder rerank (Cohere Rerank v3.5 via LiteLLM /rerank).

    Attaches a normalized 0-1 'rerank_score' to each source (in place) and returns the
    sources ordered by that score. Non-fatal: on ANY error (or missing token/sources) the
    original list is returned unchanged, so the pipeline falls back to the prior
    trust/relevance ranking.

    - query: built from the understood intent + topic.
    - documents: each source's title + summary.
    - uploaded_file sources are kept but exempt from any rerank-based drop downstream.
    """
    if not sources or not query or not LITELLM_KEY:
        return sources

    # Build the document texts; track index → source mapping.
    docs = []
    for s in sources:
        text = f"{s.get('title', '')}\n{s.get('summary', '')}".strip()
        docs.append(text or (s.get('title') or s.get('url') or 'source'))

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        payload = {
            "model": LITELLM_RERANK_MODEL,
            "query": query[:2000],
            "documents": docs,
            "top_n": top_n or len(docs),
        }
        req = urllib.request.Request(
            LITELLM_RERANK_URL,
            data=json.dumps(payload).encode('utf-8'),
            headers={"Authorization": f"Bearer {LITELLM_KEY}", "Content-Type": "application/json"},
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            res = json.loads(resp.read().decode('utf-8'))
        results = res.get('results', []) or []
        if not results:
            logger.warning("RERANK | empty results; keeping original order")
            return sources

        # Map rerank scores back onto sources by index.
        for item in results:
            idx = item.get('index')
            score = item.get('relevance_score', item.get('relevanceScore'))
            if idx is not None and 0 <= idx < len(sources) and score is not None:
                sources[idx]['rerank_score'] = round(float(score), 4)

        # Order: reranked sources by score desc; any source the API didn't score
        # (shouldn't happen with top_n=all) keeps a None score and sinks to the end.
        ordered = sorted(
            sources,
            key=lambda s: s.get('rerank_score') if s.get('rerank_score') is not None else -1.0,
            reverse=True,
        )
        top = [s.get('rerank_score') for s in ordered[:3]]
        logger.info(f"RERANK | scored={len(results)} sources | top3_scores={top}")
        return ordered
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='ignore')[:200]
        logger.warning(f"RERANK | HTTP {e.code}: {body} — falling back to original ranking")
        return sources
    except Exception as e:
        logger.warning(f"RERANK | failed ({type(e).__name__}: {str(e)[:150]}) — falling back")
        return sources


# ======================================================================
# _llm_judge_relevance (lines 1730-1763)
# ======================================================================
def _llm_judge_relevance(borderline: List[Dict[str, Any]], framing: Dict[str, Any],
                         requirements: Dict[str, Any]) -> set:
    """Batched LLM judge for borderline sources. Returns the set of relevant indices."""
    if not borderline:
        return set()
    topic = requirements.get('topic', '')
    entity = framing.get('subject_entity') or framing.get('entity_anchor') or 'the subject'
    first_party = _is_first_party(framing)
    listing = '\n'.join(
        f"[{i}] {s.get('title', '?')} — {(s.get('summary') or '')[:200]}"
        for i, s in enumerate(borderline)
    )
    actor_rule = (
        f"CRITICAL: A source is relevant ONLY if it is about '{entity}' AND the topic. "
        f"A source about the SAME topic but a DIFFERENT organisation or a government body "
        f"(e.g. a ministry's own programme of the same name) is NOT relevant — reject it.\n\n"
        if first_party else ""
    )
    prompt = (
        "You are a source relevance judge.\n\n"
        f"DOCUMENT TOPIC: {topic}\n"
        f"INTENDED SUBJECT/ACTOR: {entity}\n"
        f"MUST RELATE TO: {', '.join(framing.get('core_topic_tokens', [])) or topic}\n\n"
        f"{actor_rule}"
        "Decide which of the sources below are genuinely about this topic/subject "
        "(not just sharing a generic word).\n\n"
        f"SOURCES:\n{listing}\n\n"
        'Output ONLY a JSON object: {"relevant_indices": [list of integer indices that ARE relevant]}'
    )
    data = _llm_call_json(prompt, max_tokens=200, model=LLM_MODEL_REASONING)
    if isinstance(data, dict):
        idxs = data.get('relevant_indices', [])
        return {int(i) for i in idxs if isinstance(i, (int, float)) or str(i).isdigit()}
    return set()


# ======================================================================
# _annotate_relevance (lines 1766-1820)
# ======================================================================
def _annotate_relevance(sources: List[Dict[str, Any]], framing: Dict[str, Any],
                        requirements: Dict[str, Any]) -> int:
    """Mark each source['_topic_relevant'] (True/False) and return the relevant count.

    Two-factor relevance:
      - TOPIC match  : token overlap against core_topic_tokens (fast path).
      - ACTOR match  : for first-party PMI documents, the source must actually be about PMI
                       (entity mention or PMI-owned domain). This is what separates
                       "PMI sustainability" from a government's identically-named programme —
                       both share the topic vocabulary, only the actor differs.
    Borderline cases are batched into a single LLM judge call (token-overlap + LLM judge).
    """
    tokens = framing.get('core_topic_tokens') or _tokenize_relevance(requirements.get('topic', ''))
    exclude = framing.get('must_exclude_terms') or []
    require_entity = _is_first_party(framing)
    HIGH = 0.34  # ≥ ~1/3 of core tokens present → clearly on-topic

    borderline_idx = []
    for i, s in enumerate(sources):
        if s.get('type') == 'uploaded_file':
            s['_topic_relevant'] = True  # user explicitly provided it
            continue
        text = f"{s.get('title', '')} {s.get('summary', '')}"
        low = text.lower()
        overlap = _topic_overlap_score(text, tokens)
        excluded = any(e in low for e in exclude) if exclude else False

        if require_entity:
            # First-party PMI: actor match is mandatory. Right-topic/wrong-actor → reject.
            if not _entity_match(s):
                s['_topic_relevant'] = False
            elif overlap >= HIGH and not excluded:
                s['_topic_relevant'] = True
            elif excluded and overlap < HIGH:
                s['_topic_relevant'] = False
            else:
                # About PMI but topic match unclear → let the judge confirm topic fit.
                s['_topic_relevant'] = None
                borderline_idx.append(i)
        else:
            # External/regulatory/comparative: topic-token logic only (no PMI anchor).
            if overlap >= HIGH and not excluded:
                s['_topic_relevant'] = True
            elif overlap == 0.0 or (excluded and overlap < HIGH):
                s['_topic_relevant'] = False
            else:
                s['_topic_relevant'] = None
                borderline_idx.append(i)

    if borderline_idx:
        judged = _llm_judge_relevance([sources[i] for i in borderline_idx], framing, requirements)
        for k, i in enumerate(borderline_idx):
            sources[i]['_topic_relevant'] = (k in judged)

    return sum(1 for s in sources if s.get('_topic_relevant') is True)


# ======================================================================
# _llm_reformulate_for_relevance (lines 1823-1864)
# ======================================================================
def _llm_reformulate_for_relevance(framing: Dict[str, Any], requirements: Dict[str, Any],
                                   tried_queries: List[str], iteration: int) -> List[str]:
    """Escalating query reformulation when not enough on-topic sources were found.

    Strategy escalates by iteration so retries don't repeat the same failing search:
      0: tight  (entity + topic + jurisdiction)
      1: broaden (drop jurisdiction)
      2: entity synonyms / parent framing
      3: topic-only but apply exclusions
    """
    topic = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    anchor = framing.get('entity_anchor', '')
    strategies = [
        f"Tight: anchor to '{anchor or topic}', include jurisdiction '{jurisdiction}'.",
        "Broaden: drop the jurisdiction; keep the entity and core topic.",
        f"Reframe: use synonyms / parent terms for the subject '{framing.get('subject_entity') or anchor or topic}'.",
        "Topic-only: focus purely on the core topic tokens, but avoid the excluded terms.",
    ]
    strategy = strategies[min(iteration, len(strategies) - 1)]
    prompt = (
        "You are a retrieval recovery agent. Previous searches did not return enough sources "
        "that are genuinely about the intended subject.\n\n"
        f"TOPIC: {topic}\n"
        f"INTENDED SUBJECT: {framing.get('subject_entity') or anchor or 'N/A'}\n"
        f"CORE TOPIC TOKENS: {', '.join(framing.get('core_topic_tokens', [])) or topic}\n"
        f"AVOID (off-topic) TERMS: {', '.join(framing.get('must_exclude_terms', [])) or 'none'}\n"
        f"ALREADY TRIED (do NOT repeat): {tried_queries[-8:]}\n\n"
        f"THIS ROUND'S STRATEGY: {strategy}\n\n"
        "Generate up to 3 NEW search queries (5-15 words each) following this round's strategy.\n"
        "Output ONLY a JSON array of strings, no explanation."
    )
    data = _llm_call_json(prompt, max_tokens=250)
    if not isinstance(data, list):
        return []
    tried_lower = {q.strip().lower() for q in tried_queries}
    out = []
    for q in data:
        v = str(q).strip()
        if v and v.lower() not in tried_lower and v.lower() not in {o.lower() for o in out}:
            out.append(v)
    return out[:3]


# ======================================================================
# _llm_identify_gaps (lines 2007-2087)
# ======================================================================
def _llm_identify_gaps(research_results: Dict[str, Any], requirements: Dict[str, Any]) -> List[str]:
    """
    Agentic Phase 3: LLM reviews all collected sources and identifies specific
    missing facts that need a second round of targeted retrieval.
    Returns 0-3 targeted gap-fill queries. Empty list = no gaps.
    """
    if not LITELLM_KEY:
        return []

    topic        = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    background   = requirements.get('background', '')

    # Build a compact summary of what was found
    sources = research_results.get('all_sources', [])
    if not sources:
        return []

    found_summaries = []
    for i, s in enumerate(sources[:10]):
        summary_preview = (s.get('summary') or '')[:200]
        found_summaries.append(f"[{i+1}] {s.get('type','?')}: {s.get('title','?')} — {summary_preview}")

    found_text = '\n'.join(found_summaries)

    prompt = (
        "You are a research completeness reviewer.\n\n"
        f"RESEARCH TOPIC: {topic}\n"
        f"JURISDICTION: {jurisdiction}\n"
        f"BACKGROUND: {background if background else 'N/A'}\n\n"
        f"SOURCES FOUND SO FAR:\n{found_text}\n\n"
        "Review the sources above. Identify what SPECIFIC facts are MISSING that would be "
        "critical for a comprehensive regulatory submission on this topic.\n\n"
        "Focus only on major gaps:\n"
        "- Missing specific statistics or figures mentioned in background but not found\n"
        "- Missing regulatory authority or legislation details for the jurisdiction\n"
        "- Missing comparative market data from key reference countries\n"
        "- Missing scientific evidence that would strengthen the document\n\n"
        "For each gap, generate ONE targeted search query (5-12 words) that would find it.\n\n"
        "Rules:\n"
        "- Maximum 3 gap queries (only the most critical gaps)\n"
        "- If research is already sufficient, return an empty array []\n"
        "- Output ONLY a JSON array of strings, no explanation\n\n"
        'Example: ["PMI R&D investment USD 16 billion smoke-free", "Japan MHLW smoking rate decline 2022"]'
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300,
            "temperature": 0.2,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            gaps = json.loads(raw)
            if isinstance(gaps, list):
                result = [str(q).strip() for q in gaps if q and str(q).strip()][:3]
                logger.info(f"AGENTIC_GAP_REVIEW | gaps_found={len(result)} | queries={result}")
                return result
    except Exception as e:
        logger.warning(f"Agentic gap review LLM call failed (non-fatal): {e}")

    return []


# ======================================================================
# _topic_overlap_score (lines 1697-1705)
# ======================================================================
def _topic_overlap_score(text: str, tokens: List[str]) -> float:
    """Fraction of core topic tokens present in the source text (0.0–1.0)."""
    if not tokens:
        return 0.0
    src = set(_tokenize_relevance(text))
    if not src:
        return 0.0
    hits = sum(1 for t in tokens if t in src)
    return hits / len(tokens)


# WARNING: _apply_topic_relevance NOT FOUND in monolith

