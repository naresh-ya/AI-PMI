# ======================================================================
# stage_curated (lines 638-640)
# ======================================================================
def stage_curated(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Curated internal weblinks stage."""
    return fetch_internal_weblinks(requirements)


# ======================================================================
# fetch_internal_weblinks (lines 3622-3885)
# ======================================================================
def fetch_internal_weblinks(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 4 — Fetch content from curated links stored in pmi-agentic-ai-curated-links.

    Schema observed: id(PK), country, description, domain, is_active, language,
                     link (URL), requires_login, source_type, title, topics (StringSet), updated_at

    Steps:
      1. Scan with is_active=True, requires_login=False, country=jurisdiction
      2. Score each row by keyword overlap with request context (topics + description)
      3. Fetch page content from 'link' for the top-scoring rows (up to 5)
    """
    from boto3.dynamodb.conditions import Attr

    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    topic        = (requirements.get('topic') or '').strip()
    category     = (requirements.get('category') or '').strip()
    use_case     = (requirements.get('use_case') or '').strip()
    background   = (requirements.get('background') or '').strip()

    # Build a flat keyword set from all request context fields for scoring
    _STOPWORDS = {'', 'a', 'an', 'the', 'of', 'in', 'on', 'for', 'to', 'and', 'or', 'with', 'is', 'are', 'at'}
    context_text = f"{topic} {category} {use_case} {background}".lower()
    context_words = {w for w in re.split(r'[\s,;.()\-]+', context_text) if w and w not in _STOPWORDS and len(w) > 2}

    all_items: List[Dict] = []
    try:
        import functools
        import operator
        
        # Build country conditions to handle case-insensitivity and common abbreviations (e.g. IN for India)
        country_queries = [jurisdiction, jurisdiction.lower(), jurisdiction.upper(), jurisdiction.title()]
        if jurisdiction.lower() in ('india', 'in'):
            country_queries.extend(['in', 'IN', 'india', 'India'])
        elif jurisdiction.lower() in ('bangladesh', 'bd'):
            country_queries.extend(['bd', 'BD', 'bangladesh', 'Bangladesh'])
        elif jurisdiction.lower() in ('thailand', 'th'):
            country_queries.extend(['th', 'TH', 'thailand', 'Thailand'])
            
        country_set = {c.strip() for c in country_queries if c and c.strip()}
        
        # Fetch rows for the request's jurisdiction AND rows marked "global"
        # (global = curated links that apply regardless of country)
        # is_active + requires_login are always hard gates
        # Note: DynamoDB stores these as strings "TRUE"/"FALSE", not booleans
        base = Attr('is_active').eq('TRUE') & Attr('requires_login').eq('FALSE')
        
        if jurisdiction and country_set:
            # Dynamically build OR conditions for country list
            country_conditions = [Attr('country').eq(c) for c in country_set]
            country_filter = functools.reduce(operator.or_, country_conditions)
            filter_expr = base & (Attr('country').eq('global') | country_filter)
        else:
            filter_expr = base & Attr('country').eq('global')

        resp = curated_links_table.scan(FilterExpression=filter_expr)
        all_items = resp.get('Items', [])

        # Handle DynamoDB 1 MB pagination
        while 'LastEvaluatedKey' in resp:
            resp = curated_links_table.scan(
                FilterExpression=filter_expr,
                ExclusiveStartKey=resp['LastEvaluatedKey']
            )
            all_items.extend(resp.get('Items', []))

        logger.info(f"CURATED_LINKS_DDB | jurisdiction={jurisdiction} | fetched={len(all_items)}")

    except Exception as e:
        logger.warning(f"Failed to query curated links from DynamoDB: {e}")

    if not all_items:
        return {'sources': [], 'citations': [], 'queries': []}

    # ── LLM-based selection ────────────────────────────────────────────────────
    # Pass all portal descriptions to the LLM; let it decide relevance based on
    # semantic understanding of the request topic (handles synonyms, abbreviations,
    # domain concepts that keyword overlap misses).
    def run_hybrid_fallback(all_items: List[Dict], jurisdiction: str, context_words: set, context_text: str, requirements: Dict[str, Any]) -> List[Dict]:
        """Fallback using hybrid (semantic + keyword/topic/country) search over curated links."""
        import math
        scored_items = []
        
        # 1. Generate Query embedding using Bedrock
        query_embedding = None
        try:
            bedrock_runtime = boto3.client('bedrock-runtime', region_name=os.environ.get('AWS_REGION', 'eu-west-1'))
            response = bedrock_runtime.invoke_model(
                modelId='amazon.titan-embed-text-v2:0',
                body=json.dumps({"inputText": context_text[:8000]})
            )
            response_body = json.loads(response['body'].read())
            query_embedding = response_body.get('embedding')
        except Exception as e:
            logger.warning(f"Failed to generate query embedding for fallback: {e}")

        for item in all_items:
            # --- Component A: Country Weight ---
            country_score = 0.0
            row_country = (item.get('country') or '').strip().lower()
            if jurisdiction and row_country == jurisdiction.lower():
                country_score = 1.0
            elif row_country == 'global':
                country_score = 0.8
            
            # --- Component B: Semantic Score ---
            semantic_score = 0.0
            desc = (item.get('description') or '').strip()
            if query_embedding and desc:
                try:
                    # Generate candidate embedding on the fly (small payload, low latency)
                    response = bedrock_runtime.invoke_model(
                        modelId='amazon.titan-embed-text-v2:0',
                        body=json.dumps({"inputText": desc[:8000]})
                    )
                    response_body = json.loads(response['body'].read())
                    desc_embedding = response_body.get('embedding')
                    
                    if desc_embedding:
                        dot_product = sum(a * b for a, b in zip(query_embedding, desc_embedding))
                        norm1 = math.sqrt(sum(a * a for a in query_embedding))
                        norm2 = math.sqrt(sum(b * b for b in desc_embedding))
                        if norm1 > 0 and norm2 > 0:
                            semantic_score = dot_product / (norm1 * norm2)
                except Exception as e:
                    logger.warning(f"Failed to generate embedding for curated description: {e}")

            # --- Component C: Keyword Overlap Score ---
            desc_words = set(re.split(r'[\s,;.()\-]+', desc.lower()))
            overlap_count = len(context_words & desc_words)
            keyword_score = min(overlap_count / 5.0, 1.0) # Normalized up to 5 word overlaps
            
            # --- Component D: Topic Overlap Score ---
            topic_words = set()
            for t in (item.get('topics') or []):
                topic_words.update(re.split(r'[\s,;.()\-]+', str(t).lower()))
            topic_overlap = len(context_words & topic_words)
            topic_score = min(topic_overlap / 3.0, 1.0) # Normalized up to 3 topic overlaps
            
            # --- Combine into a Hybrid Score ---
            # Formula: 40% Semantic + 30% Keywords + 20% Topics + 10% Country
            combined_score = (
                (semantic_score * 0.40) + 
                (keyword_score * 0.30) + 
                (topic_score * 0.20) + 
                (country_score * 0.10)
            )
            
            scored_items.append((item, combined_score))
            
        # Sort and select top items
        scored_items.sort(key=lambda x: x[1], reverse=True)
        # Select items with non-zero hybrid score
        selected = [item for item, score in scored_items if score > 0.15][:3]
        if not selected:
            selected = [item for item, _ in scored_items[:3]]
        return selected

    selected: List[Dict] = []
    try:
        selected_ids = _llm_select_curated_links(all_items, topic)
        if not selected_ids:
            logger.info("LLM selected no curated links. Falling back to hybrid scoring.")
            selected = run_hybrid_fallback(all_items, jurisdiction, context_words, context_text, requirements)
        else:
            selected = [
                item for sid in selected_ids
                for item in all_items
                if str(item.get('id', '')) == sid
            ]
            logger.info(f"CURATED_LINKS_LLM | matched={len(selected)} | ids={selected_ids}")
    except Exception as e:
        logger.warning(f"LLM curated link selection failed, using hybrid fallback: {e}")
        selected = run_hybrid_fallback(all_items, jurisdiction, context_words, context_text, requirements)
        logger.info(f"CURATED_LINKS_FALLBACK | selected={len(selected)} links via hybrid scoring")

    if not selected:
        return {'sources': [], 'citations': [], 'queries': []}

    logger.info(f"CURATED_LINKS_DDB | final_selected={len(selected)}")

    # Build (url, title, description) tuples from selected DynamoDB items
    url_meta = [
        ((item.get('link') or '').strip(), (item.get('title') or '').strip(), (item.get('description') or '').strip())
        for item in selected
        if (item.get('link') or '').strip().startswith('http') and 'metadata.json' not in (item.get('link') or '').strip().lower()
    ]

    if not url_meta:
        return {'sources': [], 'citations': [], 'queries': []}

    # HYBRID APPROACH: Tavily ranks DynamoDB URLs, Gemini extracts top 3-5
    curated_urls = [u for u, _, _ in url_meta]
    logger.info(f"CURATED_LINKS | selected={len(curated_urls)} from DynamoDB, now ranking with Tavily")

    # Step 1: Tavily ranks the URLs
    ranked_urls = _tavily_rank_curated_urls(
        urls=curated_urls,
        query=topic,
        max_results=5
    )

    if not ranked_urls:
        # Fallback: use all URLs if Tavily ranking fails
        logger.warning("CURATED_LINKS | Tavily ranking failed, using all URLs with default scores")
        ranked_urls = [{'url': u, 'title': t, 'relevance_score': 0.7} for u, t, _ in url_meta[:5]]

    # Step 2: Gemini extracts from ranked URLs only
    extracted = _gemini_extract_urls([r['url'] for r in ranked_urls])
    logger.info(f"CURATED_LINKS | Gemini extracted {len(extracted)} of {len(ranked_urls)} ranked URLs")

    sources: List[Dict] = []
    citations: List[Dict] = []

    query = ' '.join(filter(None, [topic, jurisdiction]))

    # Build a lookup map for DDB metadata
    ddb_meta = {u: (t, d) for u, t, d in url_meta}

    for ranked in ranked_urls:
        url = ranked['url']
        tavily_title = ranked.get('title', '')
        tavily_score = ranked.get('relevance_score', 0.7)
        
        # Get DDB metadata
        ddb_title, ddb_desc = ddb_meta.get(url, ('', ''))
        
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        # Get raw content from Gemini extraction
        raw_content = extracted.get(url, '').strip()

        if not raw_content:
            logger.warning(f"INTERNAL_LINK | no Gemini content for '{url[:80]}'")
            continue

        # Combined title: DDB title + Tavily page title
        if ddb_title and tavily_title and ddb_title.lower() != tavily_title.lower():
            title = f"{ddb_title} — {tavily_title}"
        else:
            title = ddb_title or tavily_title or domain

        # Run QFS engine to create a dense, context-focused summary
        summarized_content = summarize_web_content_with_llm(raw_content, requirements, url)

        # Always prepend DDB description as authoritative context label
        summary = (f"{ddb_desc} | " if ddb_desc else '') + summarized_content
        if not summary.strip():
            continue

        sources.append({
            'title':           title,
            'source':          url,
            'type':            'internal_url',
            'date':            datetime.now().strftime('%Y-%m-%d'),
            'relevance_score': tavily_score,  # Use Tavily's ranking score
            'summary':         summary,
            'url':             url,
            'extraction_engine': 'gemini',
        })
        citations.append({'title': title, 'url': url, 'source_type': 'internal_url'})
        logger.info(f"INTERNAL_LINK | title='{title}' | tavily_score={tavily_score} | raw_chars={len(raw_content)} | QFS_chars={len(summarized_content)} | url='{url[:80]}'")

    return {'sources': sources, 'citations': citations, 'queries': []}


# ======================================================================
# _llm_select_curated_links (lines 3480-3544)
# ======================================================================
def _llm_select_curated_links(all_items: List[Dict], topic: str) -> List[str]:
    """
    Pass all curated portal descriptions to the LLM and ask it to pick
    the most relevant ones for the given request topic.

    Returns a list of selected item IDs (the DynamoDB 'id' field).
    Raises on any failure so the caller can fall back to keyword scoring.
    """
    if not LITELLM_KEY or not all_items:
        raise ValueError("LLM key not set or no items to evaluate")

    # Build a numbered portal list — only id + description used for matching
    portal_lines = []
    for i, item in enumerate(all_items, 1):
        row_id = item.get('id', f'row_{i}')
        desc   = (item.get('description') or '').strip()
        portal_lines.append(f"[{i}] ID: {row_id}\n    Description: {desc}")

    prompt = (
        "You are a research assistant selecting the most relevant government and regulatory "
        "portals for a document research task.\n\n"
        f"Request topic: {topic}\n\n"
        "Available portals (match based on description only):\n"
        + '\n'.join(portal_lines)
        + "\n\nSelect the portals whose description is most relevant to the request topic. "
        "A portal is relevant if its description indicates its content would help research "
        "or support the topic.\n"
        "Rules:\n"
        "- Return ONLY a valid JSON array of ID strings from the list above\n"
        "- Maximum 5 IDs, ordered by relevance (most relevant first)\n"
        "- If none are relevant, return an empty array []\n"
        "- No explanation, no markdown — only the JSON array\n\n"
        'Example: ["cbic.gov.in", "tobaccoboard.in"]'
    )

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    req = urllib.request.Request(
        LITELLM_URL,
        data=json.dumps({
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
        }).encode('utf-8'),
        headers={
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        },
        method='POST',
    )
    with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
        res = json.loads(resp.read().decode('utf-8'))
        raw = res['choices'][0]['message']['content'].strip()

    if raw.startswith('```'):
        raw = '\n'.join(raw.split('\n')[1:-1]).strip()

    selected_ids = json.loads(raw)
    if not isinstance(selected_ids, list):
        raise ValueError(f"LLM returned unexpected type: {raw}")

    logger.info(f"CURATED_LINKS_LLM | topic='{topic[:60]}' | selected_ids={selected_ids}")
    return [str(i) for i in selected_ids]


