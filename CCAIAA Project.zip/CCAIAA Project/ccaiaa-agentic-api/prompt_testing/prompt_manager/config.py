"""
Configuration Management for Prompt Manager
"""
import os
from typing import Optional
from dataclasses import dataclass


@dataclass
class PromptManagerConfig:
    """Configuration for PromptManager"""

    # AWS Configuration
    aws_region: str = 'eu-west-1'
    aws_profile: Optional[str] = None

    # Cache Configuration
    cache_enabled: bool = True
    cache_ttl_seconds: int = 300  # 5 minutes default
    cache_max_size: int = 100     # Max number of prompts to cache

    # Metrics Configuration
    metrics_enabled: bool = True
    metrics_output_file: Optional[str] = None  # If None, logs to console

    # Fallback Configuration
    fallback_enabled: bool = True
    fallback_directory: Optional[str] = None  # Local backup directory

    # LiteLLM Configuration
    litellm_endpoint: str = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions'
    litellm_model: str = 'anthropic.claude-3-haiku-20240307-v1:0'
    litellm_api_key: Optional[str] = None
    litellm_verify_ssl: bool = False  # For corporate networks

    # Logging
    log_level: str = 'INFO'  # DEBUG, INFO, WARNING, ERROR

    @classmethod
    def from_env(cls) -> 'PromptManagerConfig':
        """Create config from environment variables"""
        return cls(
            aws_region=os.getenv('AWS_REGION', 'eu-west-1'),
            aws_profile=os.getenv('AWS_PROFILE'),
            cache_enabled=os.getenv('PROMPT_CACHE_ENABLED', 'true').lower() == 'true',
            cache_ttl_seconds=int(os.getenv('PROMPT_CACHE_TTL', '300')),
            metrics_enabled=os.getenv('PROMPT_METRICS_ENABLED', 'true').lower() == 'true',
            metrics_output_file=os.getenv('PROMPT_METRICS_FILE'),
            fallback_enabled=os.getenv('PROMPT_FALLBACK_ENABLED', 'true').lower() == 'true',
            fallback_directory=os.getenv('PROMPT_FALLBACK_DIR'),
            litellm_endpoint=os.getenv('LITELLM_ENDPOINT',
                'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions'),
            litellm_model=os.getenv('LITELLM_MODEL', 'anthropic.claude-3-haiku-20240307-v1:0'),
            litellm_api_key=os.getenv('AWS_BEARER_TOKEN_BEDROCK'),
            litellm_verify_ssl=os.getenv('LITELLM_VERIFY_SSL', 'false').lower() == 'true',
            log_level=os.getenv('LOG_LEVEL', 'INFO')
        )

    @classmethod
    def dev_config(cls) -> 'PromptManagerConfig':
        """Development configuration with shorter cache"""
        return cls(
            cache_ttl_seconds=60,  # 1 minute for faster testing
            log_level='DEBUG'
        )

    @classmethod
    def prod_config(cls) -> 'PromptManagerConfig':
        """Production configuration with longer cache"""
        return cls(
            cache_ttl_seconds=600,  # 10 minutes
            log_level='WARNING'
        )
