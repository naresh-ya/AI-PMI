"""
Caching Layer for Prompt Manager with TTL support
"""
import time
import json
from typing import Optional, Dict, Any
from dataclasses import dataclass
from collections import OrderedDict


@dataclass
class CacheEntry:
    """Cache entry with TTL"""
    data: Dict[str, Any]
    timestamp: float
    ttl: int

    def is_expired(self) -> bool:
        """Check if cache entry has expired"""
        return (time.time() - self.timestamp) > self.ttl


class PromptCache:
    """LRU Cache with TTL for prompts"""

    def __init__(self, max_size: int = 100, default_ttl: int = 300):
        """
        Initialize cache

        Args:
            max_size: Maximum number of entries (LRU eviction)
            default_ttl: Default time-to-live in seconds
        """
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._stats = {
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'expirations': 0
        }

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Get item from cache

        Args:
            key: Cache key (typically prompt name)

        Returns:
            Cached data or None if not found/expired
        """
        if key not in self._cache:
            self._stats['misses'] += 1
            return None

        entry = self._cache[key]

        # Check if expired
        if entry.is_expired():
            self._stats['expirations'] += 1
            del self._cache[key]
            return None

        # Move to end (LRU)
        self._cache.move_to_end(key)
        self._stats['hits'] += 1

        return entry.data

    def set(self, key: str, data: Dict[str, Any], ttl: Optional[int] = None):
        """
        Set item in cache

        Args:
            key: Cache key
            data: Data to cache
            ttl: Time-to-live (uses default if None)
        """
        # Check size limit and evict oldest if needed
        if len(self._cache) >= self.max_size and key not in self._cache:
            self._cache.popitem(last=False)  # Remove oldest
            self._stats['evictions'] += 1

        entry = CacheEntry(
            data=data,
            timestamp=time.time(),
            ttl=ttl if ttl is not None else self.default_ttl
        )

        self._cache[key] = entry
        self._cache.move_to_end(key)

    def invalidate(self, key: str):
        """Remove specific key from cache"""
        if key in self._cache:
            del self._cache[key]

    def clear(self):
        """Clear entire cache"""
        self._cache.clear()
        self._stats = {k: 0 for k in self._stats}

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self._stats['hits'] + self._stats['misses']
        hit_rate = (self._stats['hits'] / total_requests * 100) if total_requests > 0 else 0

        return {
            **self._stats,
            'size': len(self._cache),
            'max_size': self.max_size,
            'hit_rate_percent': round(hit_rate, 2)
        }

    def cleanup_expired(self):
        """Remove all expired entries"""
        expired_keys = [
            key for key, entry in self._cache.items()
            if entry.is_expired()
        ]

        for key in expired_keys:
            del self._cache[key]
            self._stats['expirations'] += 1

        return len(expired_keys)
