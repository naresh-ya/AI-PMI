"""
Core PromptManager - Main interface for prompt management
"""
import re
import json
import logging
import requests
from pathlib import Path
from typing import Dict, Any, Optional, List
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from dotenv import load_dotenv

from .config import PromptManagerConfig
from .cache import PromptCache
from .metrics import MetricsCollector, MetricsTimer

# Load environment variables
load_dotenv()


class PromptManager:
    """
    Production-grade prompt manager with caching, metrics, and fallback
    """

    def __init__(self, config: Optional[PromptManagerConfig] = None):
        """
        Initialize PromptManager

        Args:
            config: Configuration (uses defaults if None)
        """
        self.config = config or PromptManagerConfig.from_env()

        # Setup logging
        logging.basicConfig(
            level=getattr(logging, self.config.log_level),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

        # Initialize components
        self.cache = PromptCache(
            max_size=self.config.cache_max_size,
            default_ttl=self.config.cache_ttl_seconds
        ) if self.config.cache_enabled else None

        self.metrics = MetricsCollector(
            output_file=self.config.metrics_output_file
        ) if self.config.metrics_enabled else None

        # Initialize AWS client
        self._bedrock_client = None

        self.logger.info(f"PromptManager initialized (cache={self.config.cache_enabled}, "
                        f"metrics={self.config.metrics_enabled})")

    @property
    def bedrock_client(self):
        """Lazy initialization of Bedrock client"""
        if self._bedrock_client is None:
            session_kwargs = {'region_name': self.config.aws_region}
            if self.config.aws_profile:
                session_kwargs['profile_name'] = self.config.aws_profile

            session = boto3.Session(**session_kwargs)
            self._bedrock_client = session.client('bedrock-agent')

        return self._bedrock_client

    def get_prompt(self, prompt_name: str, use_cache: bool = True) -> Optional[Dict[str, Any]]:
        """
        Get prompt from AWS Bedrock Prompt Management

        Args:
            prompt_name: Name of the prompt
            use_cache: Whether to use cache (default: True)

        Returns:
            Prompt data dictionary or None if not found
        """
        # Check cache first
        if use_cache and self.cache:
            cached = self.cache.get(prompt_name)
            if cached:
                self.logger.debug(f"Cache HIT: {prompt_name}")
                if self.metrics:
                    self.metrics.record(prompt_name, 'cache_hit')
                return cached
            else:
                self.logger.debug(f"Cache MISS: {prompt_name}")
                if self.metrics:
                    self.metrics.record(prompt_name, 'cache_miss')

        # Fetch from AWS
        with MetricsTimer(self.metrics, prompt_name, 'fetch') if self.metrics else self._null_context():
            try:
                prompt_data = self._fetch_from_aws(prompt_name)

                if prompt_data and self.cache:
                    self.cache.set(prompt_name, prompt_data)

                # Save fallback if enabled
                if prompt_data and self.config.fallback_enabled and self.config.fallback_directory:
                    self._save_fallback(prompt_name, prompt_data)

                return prompt_data

            except Exception as e:
                self.logger.error(f"Failed to fetch prompt '{prompt_name}': {e}")

                # Try fallback
                if self.config.fallback_enabled and self.config.fallback_directory:
                    return self._load_fallback(prompt_name)

                return None

    def _fetch_from_aws(self, prompt_name: str) -> Optional[Dict[str, Any]]:
        """Fetch prompt from AWS Bedrock"""
        try:
            # List prompts to find ID
            response = self.bedrock_client.list_prompts(maxResults=100)

            prompt_id = None
            for prompt in response.get('promptSummaries', []):
                if prompt['name'] == prompt_name:
                    prompt_id = prompt['id']
                    break

            if not prompt_id:
                self.logger.warning(f"Prompt '{prompt_name}' not found in AWS")
                return None

            # Get full prompt details
            prompt_detail = self.bedrock_client.get_prompt(promptIdentifier=prompt_id)

            # Extract template and variables
            variants = prompt_detail.get('variants', [])
            if not variants:
                self.logger.warning(f"No variants found for prompt '{prompt_name}'")
                return None

            template_config = variants[0].get('templateConfiguration', {})
            template_text = template_config.get('text', {}).get('text', '')

            # Extract variables
            variables = list(set(re.findall(r'\{\{(\w+)\}\}', template_text)))

            return {
                'id': prompt_id,
                'name': prompt_detail['name'],
                'description': prompt_detail.get('description', ''),
                'template': template_text,
                'variables': variables,
                'created_at': str(prompt_detail.get('createdAt', '')),
                'updated_at': str(prompt_detail.get('updatedAt', '')),
                'version': prompt_detail.get('version', '1')
            }

        except ClientError as e:
            self.logger.error(f"AWS API error: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error fetching prompt: {e}")
            raise

    def substitute_variables(
        self,
        template: str,
        variables: Dict[str, str],
        strict: bool = False
    ) -> str:
        """
        Substitute variables in template

        Args:
            template: Template string with {{variable}} placeholders
            variables: Variable name -> value mapping
            strict: If True, raises error on missing variables

        Returns:
            Template with substituted values
        """
        result = template

        for var_name, var_value in variables.items():
            placeholder = f"{{{{{var_name}}}}}"
            result = result.replace(placeholder, str(var_value))

        # Check for unsubstituted variables
        remaining = re.findall(r'\{\{(\w+)\}\}', result)

        if remaining:
            msg = f"Unsubstituted variables: {', '.join(remaining)}"
            if strict:
                raise ValueError(msg)
            else:
                self.logger.warning(msg)

        return result

    def execute_prompt(
        self,
        prompt_name: str,
        variables: Dict[str, str],
        temperature: float = 0.7,
        max_tokens: int = 2000
    ) -> Optional[str]:
        """
        Execute a prompt end-to-end: fetch, substitute, call LiteLLM

        Args:
            prompt_name: Name of the prompt
            variables: Variables to substitute
            temperature: Model temperature
            max_tokens: Max tokens to generate

        Returns:
            Model response or None if failed
        """
        with MetricsTimer(self.metrics, prompt_name, 'execute') if self.metrics else self._null_context():
            # Get prompt
            prompt_data = self.get_prompt(prompt_name)
            if not prompt_data:
                return None

            # Substitute variables
            final_prompt = self.substitute_variables(prompt_data['template'], variables)

            # Call LiteLLM
            return self._call_litellm(final_prompt, temperature, max_tokens)

    def _call_litellm(
        self,
        prompt: str,
        temperature: float,
        max_tokens: int
    ) -> Optional[str]:
        """Call LiteLLM endpoint"""
        try:
            headers = {
                "Authorization": f"Bearer {self.config.litellm_api_key}",
                "Content-Type": "application/json"
            }

            payload = {
                "model": self.config.litellm_model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": temperature,
                "max_tokens": max_tokens
            }

            response = requests.post(
                self.config.litellm_endpoint,
                headers=headers,
                json=payload,
                verify=self.config.litellm_verify_ssl,
                timeout=60
            )

            response.raise_for_status()
            result = response.json()

            return result['choices'][0]['message']['content']

        except Exception as e:
            self.logger.error(f"LiteLLM call failed: {e}")
            return None

    def list_prompts(self) -> List[Dict[str, Any]]:
        """List all available prompts from AWS"""
        try:
            response = self.bedrock_client.list_prompts(maxResults=100)

            return [
                {
                    'id': p['id'],
                    'name': p['name'],
                    'created_at': str(p.get('createdAt', '')),
                    'updated_at': str(p.get('updatedAt', ''))
                }
                for p in response.get('promptSummaries', [])
            ]

        except Exception as e:
            self.logger.error(f"Failed to list prompts: {e}")
            return []

    def invalidate_cache(self, prompt_name: Optional[str] = None):
        """
        Invalidate cache

        Args:
            prompt_name: Specific prompt to invalidate (None = clear all)
        """
        if not self.cache:
            return

        if prompt_name:
            self.cache.invalidate(prompt_name)
            self.logger.info(f"Cache invalidated for: {prompt_name}")
        else:
            self.cache.clear()
            self.logger.info("Cache cleared")

    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary"""
        summary = {}

        if self.cache:
            summary['cache'] = self.cache.get_stats()

        if self.metrics:
            summary['metrics'] = self.metrics.get_summary()

        return summary

    def _save_fallback(self, prompt_name: str, prompt_data: Dict[str, Any]):
        """Save prompt to local fallback directory"""
        try:
            fallback_dir = Path(self.config.fallback_directory)
            fallback_dir.mkdir(parents=True, exist_ok=True)

            filepath = fallback_dir / f"{prompt_name}.json"
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(prompt_data, f, indent=2)

        except Exception as e:
            self.logger.warning(f"Failed to save fallback: {e}")

    def _load_fallback(self, prompt_name: str) -> Optional[Dict[str, Any]]:
        """Load prompt from local fallback"""
        try:
            fallback_dir = Path(self.config.fallback_directory)
            filepath = fallback_dir / f"{prompt_name}.json"

            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    self.logger.info(f"Loaded from fallback: {prompt_name}")
                    return json.load(f)

        except Exception as e:
            self.logger.warning(f"Failed to load fallback: {e}")

        return None

    @staticmethod
    def _null_context():
        """Null context manager for when metrics disabled"""
        from contextlib import nullcontext
        return nullcontext()
