"""
Metrics Collection and Monitoring for Prompt Manager
"""
import time
import json
from datetime import datetime
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass
class PromptMetric:
    """Single prompt usage metric"""
    timestamp: str
    prompt_name: str
    operation: str  # fetch, execute, cache_hit, cache_miss, error
    latency_ms: Optional[float] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class MetricsCollector:
    """Collect and export metrics"""

    def __init__(self, output_file: Optional[str] = None):
        """
        Initialize metrics collector

        Args:
            output_file: Path to write metrics (None = memory only)
        """
        self.output_file = output_file
        self.metrics: List[PromptMetric] = []

        self._summary = {
            'total_fetches': 0,
            'total_executions': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'errors': 0,
            'total_latency_ms': 0.0
        }

    def record(
        self,
        prompt_name: str,
        operation: str,
        latency_ms: Optional[float] = None,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """
        Record a metric

        Args:
            prompt_name: Name of the prompt
            operation: Type of operation
            latency_ms: Operation latency in milliseconds
            error: Error message if any
            metadata: Additional metadata
        """
        metric = PromptMetric(
            timestamp=datetime.utcnow().isoformat(),
            prompt_name=prompt_name,
            operation=operation,
            latency_ms=latency_ms,
            error=error,
            metadata=metadata
        )

        self.metrics.append(metric)

        # Update summary
        if operation == 'fetch':
            self._summary['total_fetches'] += 1
        elif operation == 'execute':
            self._summary['total_executions'] += 1
        elif operation == 'cache_hit':
            self._summary['cache_hits'] += 1
        elif operation == 'cache_miss':
            self._summary['cache_misses'] += 1
        elif operation == 'error':
            self._summary['errors'] += 1

        if latency_ms:
            self._summary['total_latency_ms'] += latency_ms

        # Write to file if configured
        if self.output_file:
            self._append_to_file(metric)

    def _append_to_file(self, metric: PromptMetric):
        """Append metric to output file"""
        try:
            Path(self.output_file).parent.mkdir(parents=True, exist_ok=True)

            with open(self.output_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(asdict(metric)) + '\n')
        except Exception as e:
            # Don't let metrics failures break the application
            print(f"Warning: Failed to write metric: {e}")

    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics"""
        total_requests = self._summary['cache_hits'] + self._summary['cache_misses']
        cache_hit_rate = (
            self._summary['cache_hits'] / total_requests * 100
            if total_requests > 0 else 0
        )

        avg_latency = (
            self._summary['total_latency_ms'] / max(self._summary['total_fetches'], 1)
        )

        return {
            **self._summary,
            'cache_hit_rate_percent': round(cache_hit_rate, 2),
            'average_latency_ms': round(avg_latency, 2),
            'total_metrics': len(self.metrics)
        }

    def get_metrics(
        self,
        prompt_name: Optional[str] = None,
        operation: Optional[str] = None,
        limit: Optional[int] = None
    ) -> List[PromptMetric]:
        """
        Get filtered metrics

        Args:
            prompt_name: Filter by prompt name
            operation: Filter by operation type
            limit: Limit number of results

        Returns:
            List of matching metrics
        """
        results = self.metrics

        if prompt_name:
            results = [m for m in results if m.prompt_name == prompt_name]

        if operation:
            results = [m for m in results if m.operation == operation]

        if limit:
            results = results[-limit:]

        return results

    def export_to_file(self, filepath: str):
        """Export all metrics to a file"""
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump([asdict(m) for m in self.metrics], f, indent=2)

    def clear(self):
        """Clear all metrics"""
        self.metrics.clear()
        self._summary = {k: 0 if isinstance(v, int) else 0.0 for k, v in self._summary.items()}


class MetricsTimer:
    """Context manager for timing operations"""

    def __init__(self, collector: MetricsCollector, prompt_name: str, operation: str):
        self.collector = collector
        self.prompt_name = prompt_name
        self.operation = operation
        self.start_time = None
        self.error = None

    def __enter__(self):
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        latency_ms = (time.time() - self.start_time) * 1000

        if exc_type:
            self.collector.record(
                self.prompt_name,
                'error',
                latency_ms=latency_ms,
                error=str(exc_val)
            )
        else:
            self.collector.record(
                self.prompt_name,
                self.operation,
                latency_ms=latency_ms
            )

        return False  # Don't suppress exceptions
