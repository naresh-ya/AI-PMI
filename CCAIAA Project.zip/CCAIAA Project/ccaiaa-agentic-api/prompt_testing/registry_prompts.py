"""
Single source of truth for mapping prompts, jurisdiction files, and output templates
to Amazon Bedrock Prompt Management artifacts.

Phase 1: 6 categories x {researcher, drafter} + 2 defaults + shared rules = 15 prompts.
Phase 2: 6 jurisdiction ground-truth files + 6 output-section templates = 12 more = 27 total.

IMPORTANT: we seed the BASE prompt text only (the raw registry constants / file contents).
The runtime keeps appending _SHARED_QUALITY_RULES in code via get_agent_prompt(),
so equivalence checks compare Bedrock text against the base constant, NOT the
combined output.
"""
import os
import re
import sys

# Make the repo root importable so we can pull the canonical constants.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from core.prompt_registry_new import (  # noqa: E402
    PROMPT_REGISTRY,
    DEFAULT_RESEARCHER,
    DEFAULT_DRAFTER,
    _SHARED_QUALITY_RULES,
)

PREFIX = "ccaiaa"

# ── Jurisdiction and template file paths ──────────────────────────────────────
_TEMPLATES_DIR = os.path.join(_REPO_ROOT, "templates")
_JURISDICTION_DIR = os.path.join(_TEMPLATES_DIR, "jurisdiction")

JURISDICTION_FILES = {
    "india": "india.md",
    "thailand": "thailand.md",
    "vietnam": "vietnam.md",
    "bangladesh": "bangladesh.md",
    "bhutan": "bhutan.md",
    "nepal": "nepal.md",
}

TEMPLATE_FILES = {
    "Official PMI Submission": "official-pmi-submission.md",
    "Third Party Submission": "third-party-submission.md",
    "White Papers": "white-papers.md",
    "Internal Communications": "internal-communications.md",
    "Media Releases": "media-releases.md",
    "Narrative Builder": "narrative-builder.md",
}


def _slug(text: str) -> str:
    """'Official PMI Submission' -> 'official-pmi-submission'."""
    s = re.sub(r"[^a-zA-Z0-9]+", "-", (text or "").strip().lower())
    return s.strip("-")


def bedrock_name(category: str, agent: str) -> str:
    """Resolve a (category, agent) pair to its Bedrock prompt name."""
    cat = category if category in PROMPT_REGISTRY else None
    if not cat:
        cat_lower = (category or "").strip().lower()
        for k in PROMPT_REGISTRY:
            if k.lower() == cat_lower:
                cat = k
                break
    if not cat:
        cat = category  # will slug as-is
    return f"{PREFIX}-{_slug(cat)}-{agent}"


def default_name(agent: str) -> str:
    return f"{PREFIX}-default-{agent}"


SHARED_RULES_NAME = f"{PREFIX}-shared-quality-rules"


def build_manifest() -> dict:
    """Return {bedrock_prompt_name: text} for all Phase-1 + Phase-2 prompts."""
    manifest = {}

    # ═══════════════════════════════════════════════════════════════════════════
    # PHASE 1: category system prompts (12) + defaults (2) + shared rules (1)
    # ═══════════════════════════════════════════════════════════════════════════
    for category, agents in PROMPT_REGISTRY.items():
        for agent in ("researcher", "drafter"):
            name = f"{PREFIX}-{_slug(category)}-{agent}"
            manifest[name] = agents[agent]
    manifest[default_name("researcher")] = DEFAULT_RESEARCHER
    manifest[default_name("drafter")] = DEFAULT_DRAFTER
    manifest[SHARED_RULES_NAME] = _SHARED_QUALITY_RULES

    # Phase 1b: jurisdiction ground-truth files (6)
    for jur_key, filename in JURISDICTION_FILES.items():
        filepath = os.path.join(_JURISDICTION_DIR, filename)
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                manifest[f"{PREFIX}-jurisdiction-{jur_key}"] = f.read()

    # Phase 1c: output-section templates (6)
    for category, filename in TEMPLATE_FILES.items():
        filepath = os.path.join(_TEMPLATES_DIR, filename)
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                manifest[f"{PREFIX}-template-{_slug(category)}"] = f.read()

    # ═══════════════════════════════════════════════════════════════════════════
    # PHASE 2: Inline prompts from all pipeline stages
    # ═══════════════════════════════════════════════════════════════════════════
    manifest.update(_build_phase2_manifest())

    return manifest


def _build_phase2_manifest() -> dict:
    """Phase 2: inline prompts from all pipeline stages (validator through assembler)."""
    p2 = {}

    # ── Input Validator: topic relevance check ────────────────────────────────
    p2[f"{PREFIX}-validator-topic-relevance"] = (
        "You are an expert input validation assistant for the PMI Corporate Affairs Agentic Platform.\n"
        "Your job is to determine whether the user's submitted topic and background description are relevant to the corporate affairs, public policy, trade, or tobacco/nicotine regulatory domain.\n\n"
        "Relevant topics/backgrounds include:\n"
        "- Tobacco or nicotine regulations (FCTC, COTPA, FDA, excise duties, tax policies, plain packaging, product classifications, tobacco harm reduction).\n"
        "- Corporate Social Responsibility (CSR) and Environmental, Social, and Governance (ESG) policies relevant to corporate operations.\n"
        "- Government advocacy strategies, public consultations, policy updates, media relation drafts, and internal briefing documents regarding regulatory affairs or commercial updates.\n\n"
        "Irrelevant topics include:\n"
        "- General weather, sports updates (IPL, cricket matches, football scores), movies, pop culture, entertainment reviews.\n"
        "- Writing code, solving general math equations, writing general emails/letters unrelated to corporate/policy affairs.\n"
        "- Conversational chitchat (e.g. \"how are you today?\").\n\n"
        "You must reply with a valid JSON object only. The JSON must contain exactly two keys:\n"
        "1. \"is_relevant\": true or false.\n"
        "2. \"reason\": a short explanation of why the input is relevant or irrelevant."
    )

    # ── File Processor: uploaded file summarizer ──────────────────────────────
    p2[f"{PREFIX}-file-processor-summarizer"] = (
        "You are an expert corporate research assistant supporting a regulatory affairs team.\n"
        "Your task is to analyze the uploaded file and extract both its CONTENT and its STRUCTURE in the context of the user's request.\n\n"
        "Extract:\n"
        "1. KEY FACTS & EVIDENCE: specific statistics, dates, named authorities, legislation references, monetary figures, percentages.\n"
        "2. DOCUMENT STRUCTURE: how the source is organized (sections, arguments flow, hierarchy).\n"
        "3. AUTHOR INTENT: what position/argument does the source document advance?\n\n"
        "Output a structured summary (800-1200 words) that a downstream planner and researcher can use to:\n"
        "- Understand what facts are already available (no need to re-research them)\n"
        "- Understand the structural model to follow or contrast\n"
        "- Understand the positioning and stance of the source"
    )

    # ── KB Researcher: semantic signal extractor ──────────────────────────────
    p2[f"{PREFIX}-kb-semantic-signal-extractor"] = (
        "You are a semantic signal extractor for a document vector retrieval system.\n\n"
        "Given the raw user input below, extract only the domain-relevant semantic content "
        "that would help retrieve matching documents from a knowledge base.\n\n"
        "Extract:\n"
        "1. topic_core — 3 to 8 words capturing the core subject. "
        "Preserve compound domain concepts (e.g. 'heated tobacco products excise duty'). "
        "Strip generic words: submission, document, letter, regarding, about, a, an, the.\n"
        "2. background_signal — up to 100 characters of domain-relevant facts from the background. "
        "Ignore all drafting instructions (please draft, I need, write a, ensure, include, etc.). "
        "Return only factual content: regulation names, policy references, specific requirements.\n\n"
        "Output ONLY a JSON object with exactly two keys. No explanation.\n"
        "Example: {\"topic_core\": \"heated tobacco products excise duty\", "
        "\"background_signal\": \"CBIC notification 2023 duty revision HTP\"}"
    )

    # ── KB Researcher: query generator ────────────────────────────────────────
    p2[f"{PREFIX}-kb-query-generator"] = (
        "Generate exactly 2 short semantic search queries for a vector database retrieval task.\n\n"
        "Rules:\n"
        "- Each query must be 5-12 words\n"
        "- Reflect domain document meaning, not user phrasing\n"
        "- Query 1 must be generic and NOT mention any country or jurisdiction.\n"
        "- Query 2 can optionally include the country or jurisdiction.\n"
        "- Queries should match what relevant source documents would contain\n"
        "- Output ONLY a JSON array of 2 strings, no explanation\n\n"
        "Example: [\"tobacco excise policy regulatory compliance\", "
        "\"CBIC heated tobacco products duty submission\"]"
    )

    # ── KB Researcher: theme classifier ───────────────────────────────────────
    p2[f"{PREFIX}-kb-theme-classifier"] = (
        "You are classifying a research query for a knowledge base filter.\n\n"
        "Given a topic, classify it into one of these themes:\n"
        "regulatory, fiscal, scientific, communication, general\n\n"
        "Return ONLY the theme word, nothing else."
    )

    # ── Web Researcher: QFS summarizer ────────────────────────────────────────
    p2[f"{PREFIX}-web-qfs-summarizer"] = (
        "You are an expert corporate regulatory research assistant.\n"
        "Your task is to analyze raw text scraped from a webpage and produce a dense, highly focused summary "
        "that a downstream document drafter can directly use as evidence.\n\n"
        "Rules:\n"
        "- Extract specific facts: statistics, dates, legislation names, named authorities, monetary figures.\n"
        "- Maintain factual accuracy — do not infer or extrapolate.\n"
        "- Focus on relevance to the stated topic and jurisdiction.\n"
        "- Output 400-600 words.\n"
        "- Do not include any conversational prefix/suffix.\n"
        "- Prioritize exact statistics, dollar amounts, dates, legislation names, and named authorities over narrative."
    )

    # ── Web Researcher: Gemini URL context ────────────────────────────────────
    p2[f"{PREFIX}-web-gemini-url-context"] = (
        "Use the url_context tool to fetch and read this URL.\n\n"
        "Then return ALL of the following in your response:\n"
        "1. The full accessible text content of the page (legislation text, article body, report findings).\n"
        "2. Key factual data: statistics, dates, named authorities, specific provisions.\n"
        "3. Any tables, lists, or structured data present on the page.\n\n"
        "Rules:\n"
        "- Be comprehensive — capture as much factual content as possible.\n"
        "- Do NOT summarize prematurely — the downstream system needs raw facts.\n"
        "- If the page is inaccessible, return 'INACCESSIBLE' and nothing else."
    )

    # ── Re-Research: intent classifier ────────────────────────────────────────
    p2[f"{PREFIX}-reresearch-intent-classifier"] = (
        "You are a research-stage routing classifier for a document generation system.\n\n"
        "Given human feedback from a research review, determine which research stages need to be re-executed.\n\n"
        "Available stages:\n"
        "- kb_search: Search PMI's internal Knowledge Base (documents, reports, presentations). Use when feedback asks for internal/PMI-specific data, product safety info, or corporate documents.\n"
        "- web_search: Search the public web via Tavily + Gemini extraction. Use when feedback asks for recent news, regulatory updates, external studies, WHO/government sources, or academic papers.\n"
        "- user_sources: Process user-provided external URLs. Use when feedback mentions specific URLs or external links to fetch.\n"
        "- curated_links: Fetch from internal curated link database. Use when feedback asks for pre-approved internal web resources.\n\n"
        "Rules:\n"
        "- If feedback is about quality/formatting of existing sources (dedup, remove, reorder), return empty required_stages (synthesis-only).\n"
        "- If feedback asks for MORE of a specific type, select only that stage.\n"
        "- If feedback is ambiguous or asks for \"more sources\" generically, include both kb_search and web_search.\n"
        "- Set confidence HIGH (0.8-0.95) when the intent is clear and maps to specific stages.\n"
        "- Set confidence LOW (0.3-0.6) when the feedback is vague, contradictory, or you're unsure.\n\n"
        "Return ONLY a JSON object with these keys:\n"
        "{\"required_stages\": [\"stage1\", \"stage2\"], \"reasoning\": \"brief explanation\", \"new_queries\": [\"optional refined search query\"], \"confidence\": 0.85}"
    )

    # ── Draft Planner: document architect ─────────────────────────────────────
    p2[f"{PREFIX}-planner-document-architect"] = (
        "You are a senior PMI corporate-affairs document architect. Given a category template "
        "outline and the available research, design the clearest, most persuasive and well-ordered "
        "section outline for THIS specific document — comparable in quality to a top management "
        "consultant's deliverable. Favour a logical narrative arc (context → evidence → "
        "implications → recommendations), self-descriptive section names, and a structure the "
        "target audience can scan. Only include sections the available evidence can actually "
        "support. Return ONLY a JSON object."
    )

    # ── Draft Generator: dedup refinement ─────────────────────────────────────
    p2[f"{PREFIX}-generator-dedup-refinement"] = (
        "You are an elite editorial refinement agent for regulatory and product advocacy submissions.\n"
        "Your core task is to critique, refine, and deduplicate a stitched draft of a long report.\n\n"
        "YOUR EDITING INSTRUCTIONS:\n"
        "- Identify all instances of semantic duplication (both category-specific and universal patterns).\n"
        "- Consolidate: Keep the detailed explanation in the most appropriate section and replace subsequent repetitions with short, clean transition sentences.\n"
        "- Typo/Spacing Clean Up: Actively scan for and correct formatting typos.\n"
        "- Strict Constraints:\n"
        "  * Do NOT delete unique factual details, clinical data, or policy principles. Only eliminate duplicate conceptual paragraphs/phrases.\n"
        "  * The structure, keys, and titles of the sections MUST remain exactly identical to the input.\n"
        "  * You MUST output ONLY a valid, parseable JSON object matching the input structure, with no markdown wrappers or introductory conversational text."
    )

    # ── Draft Assembler: grounding audit ──────────────────────────────────────
    p2[f"{PREFIX}-assembler-grounding-audit"] = (
        "You are a senior reviewer for PMI corporate-affairs documents. Judge the draft for "
        "validity, coherence, stance, and — most importantly — GROUNDEDNESS against the supplied "
        "evidence. Return ONLY a JSON object."
    )

    # ── Re-Draft: intent classifier ──────────────────────────────────────────
    p2[f"{PREFIX}-redraft-intent-classifier"] = (
        "You are a document revision router for a draft generation system.\n\n"
        "Given user feedback on a generated document, determine which drafter stages need to be re-executed.\n\n"
        "Available stages (each depends on the previous):\n"
        "- planner: Re-creates the document structure/outline. Use when feedback asks to ADD/REMOVE/REORDER sections.\n"
        "- generator: Re-generates section content. Use when feedback asks to change TONE, EXPAND/SHORTEN content, REWRITE sections, add more detail, change style, or FIX CITATION MISMATCHES.\n"
        "- assembler: Re-formats and re-assembles the .docx. Use when feedback asks to fix FORMATTING (fonts, page breaks, bold/italic), TRANSLATION, or superficial layout issues.\n\n"
        "Dependency rules:\n"
        "- If planner is needed → generator + assembler also run (downstream dependency)\n"
        "- If generator is needed → assembler also runs\n"
        "- If only assembler is needed → just assembler runs\n\n"
        "Return ONLY a JSON object:\n"
        "{\"required_stages\": [\"generator\", \"assembler\"], \"reasoning\": \"User wants tone change which requires content regeneration\", \"confidence\": 0.88}"
    )

    # ── Translation: system prompt ────────────────────────────────────────────
    p2[f"{PREFIX}-translator-system"] = (
        "You are an expert, highly accurate corporate translator.\n"
        "Your ONLY task is to translate the user's text into the specified target language.\n"
        "CRITICAL RULES:\n"
        "- Translate ALL content completely and faithfully — do NOT summarize or omit.\n"
        "- Preserve all formatting: bullet points, numbered lists, headings, paragraphs.\n"
        "- Preserve all proper nouns, acronyms, and technical terms in their original form where conventional.\n"
        "- Do NOT add any introduction, commentary, or meta-text.\n"
        "- Output ONLY the translated text."
    )

    return p2


def incode_base_prompt(category: str, agent: str) -> str:
    """The base prompt the runtime would use for (category, agent), WITHOUT the
    shared quality rules appended. Mirrors get_agent_prompt()'s selection."""
    cat = category if category in PROMPT_REGISTRY else None
    if not cat:
        cat_lower = (category or "").strip().lower()
        for k in PROMPT_REGISTRY:
            if k.lower() == cat_lower:
                cat = k
                break
    try:
        return PROMPT_REGISTRY[cat][agent]
    except (KeyError, TypeError):
        return DEFAULT_RESEARCHER if agent == "researcher" else DEFAULT_DRAFTER


if __name__ == "__main__":
    man = build_manifest()
    print(f"{len(man)} prompts in manifest:")
    for n, t in man.items():
        print(f"  {n:48} {len(t):6} chars")
