r"""
Seed the core/prompt_registry_new.py prompts into Amazon Bedrock Prompt Management.

Idempotent:
  - creates a prompt if its name does not exist,
  - updates it (new content) if the stored text differs from the code constant,
  - skips it if unchanged,
  - optionally cuts an immutable version snapshot (--version).

Local, read/write to Bedrock only (no pipeline impact). Writes a UTF-8 report.

Usage (PowerShell):
    aws sso login
    python prompt_testing\seed_registry_prompts.py            # create/update DRAFT
    python prompt_testing\seed_registry_prompts.py --version  # also snapshot a version
    python prompt_testing\seed_registry_prompts.py --dry-run  # show plan, no writes
"""
import argparse
import io
import os
import sys

import boto3

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from registry_prompts import build_manifest  # noqa: E402

AWS_REGION = os.environ.get("PROMPT_MGMT_REGION", "eu-west-1")
VARIANT_NAME = "v1"
REPORT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "seed_registry_report.txt")


def _list_existing(client) -> dict:
    """Return {name: id} for all existing prompts (handles pagination)."""
    out, token = {}, None
    while True:
        resp = client.list_prompts(maxResults=100, **({"nextToken": token} if token else {}))
        for p in resp.get("promptSummaries", []):
            out[p["name"]] = p["id"]
        token = resp.get("nextToken")
        if not token:
            break
    return out


def _current_text(client, prompt_id: str) -> str:
    detail = client.get_prompt(promptIdentifier=prompt_id)
    variants = detail.get("variants", []) or []
    if not variants:
        return ""
    return (variants[0].get("templateConfiguration", {})
                       .get("text", {})
                       .get("text", "")) or ""


def _variant(text: str) -> dict:
    return {
        "name": VARIANT_NAME,
        "templateType": "TEXT",
        "templateConfiguration": {"text": {"text": text}},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", action="store_true", help="cut an immutable version after upsert")
    ap.add_argument("--dry-run", action="store_true", help="show planned actions, write nothing")
    args = ap.parse_args()

    client = boto3.client("bedrock-agent", region_name=AWS_REGION)
    manifest = build_manifest()
    existing = _list_existing(client)

    report = [f"SEED REPORT | region={AWS_REGION} | dry_run={args.dry_run} | prompts={len(manifest)}", ""]

    for name, text in manifest.items():
        try:
            if name not in existing:
                if args.dry_run:
                    report.append(f"CREATE  {name} ({len(text)} chars)")
                    continue
                resp = client.create_prompt(
                    name=name,
                    description=f"CCAIAA registry prompt: {name}",
                    variants=[_variant(text)],
                    defaultVariant=VARIANT_NAME,
                )
                pid = resp["id"]
                action = "CREATED"
            else:
                pid = existing[name]
                cur = _current_text(client, pid)
                if cur == text:
                    report.append(f"SKIP    {name} (unchanged)")
                    continue
                if args.dry_run:
                    report.append(f"UPDATE  {name} ({len(cur)}->{len(text)} chars)")
                    continue
                client.update_prompt(
                    promptIdentifier=pid,
                    name=name,
                    description=f"CCAIAA registry prompt: {name}",
                    variants=[_variant(text)],
                    defaultVariant=VARIANT_NAME,
                )
                action = "UPDATED"

            if args.version and not args.dry_run:
                ver = client.create_prompt_version(promptIdentifier=pid)
                report.append(f"{action} {name} | id={pid} | version={ver.get('version')}")
            else:
                report.append(f"{action} {name} | id={pid}")

        except Exception as e:
            report.append(f"FAIL    {name}: {e}")

    out = "\n".join(report)
    print(out)
    with open(REPORT, "w", encoding="utf-8") as f:
        f.write(out + "\n")
    print(f"\nReport written to {REPORT}")


if __name__ == "__main__":
    main()
