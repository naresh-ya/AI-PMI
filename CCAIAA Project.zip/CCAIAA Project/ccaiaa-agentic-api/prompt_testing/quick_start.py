"""
Quick Start - Test the production library immediately
"""
import sys
import io

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

from prompt_manager import PromptManager


def main():
    print("=" * 80)
    print("PROMPT MANAGER - QUICK START TEST")
    print("=" * 80)

    # Initialize
    print("\n🚀 Initializing PromptManager...")
    pm = PromptManager()
    print("✅ Initialized!")

    # Test 1: List prompts
    print("\n" + "=" * 80)
    print("TEST 1: List Available Prompts")
    print("=" * 80)

    prompts = pm.list_prompts()
    print(f"\n✅ Found {len(prompts)} prompt(s):")
    for p in prompts:
        print(f"   • {p['name']}")

    # Test 2: Fetch and use a prompt
    print("\n" + "=" * 80)
    print("TEST 2: Fetch and Execute Prompt")
    print("=" * 80)

    test_text = """
    Philip Morris International is accelerating the transformation of the tobacco
    industry through innovative smoke-free products. The company's IQOS system uses
    heat-not-burn technology as an alternative to traditional cigarettes.
    """

    print(f"\n📝 Input: {test_text.strip()[:80]}...")

    print("\n⏳ Executing prompt 'test-prompt-01'...")

    result = pm.execute_prompt(
        prompt_name='test-prompt-01',
        variables={'input_text': test_text.strip()},
        temperature=0.7
    )

    if result:
        print("\n✅ SUCCESS! Result:")
        print("=" * 80)
        print(result)
        print("=" * 80)
    else:
        print("\n❌ Failed to execute prompt")

    # Test 3: View metrics
    print("\n" + "=" * 80)
    print("TEST 3: Metrics Summary")
    print("=" * 80)

    summary = pm.get_metrics_summary()

    if 'cache' in summary:
        cache = summary['cache']
        print(f"\n📊 Cache Statistics:")
        print(f"   Hits: {cache['hits']}")
        print(f"   Misses: {cache['misses']}")
        print(f"   Hit Rate: {cache['hit_rate_percent']}%")
        print(f"   Size: {cache['size']}/{cache['max_size']}")

    if 'metrics' in summary:
        metrics = summary['metrics']
        print(f"\n📊 Performance Metrics:")
        print(f"   Total Fetches: {metrics['total_fetches']}")
        print(f"   Total Executions: {metrics['total_executions']}")
        print(f"   Average Latency: {metrics['average_latency_ms']}ms")
        print(f"   Errors: {metrics['errors']}")

    print("\n" + "=" * 80)
    print("✅ QUICK START TEST COMPLETED!")
    print("=" * 80)

    print("\n💡 Next Steps:")
    print("   1. Review README.md for full documentation")
    print("   2. Run: python examples/basic_usage.py")
    print("   3. Run: python examples/with_litellm.py")
    print("   4. Integrate into your own code")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
