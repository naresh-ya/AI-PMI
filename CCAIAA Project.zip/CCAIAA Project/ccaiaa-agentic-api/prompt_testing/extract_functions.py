"""
Extract specific function source code from handler_new_advanced.py.
Outputs each function's source to a file for use in building standalone modules.
"""
import ast
import os
import sys

MONOLITH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "agents", "master_researcher", "handler_new_advanced.py")

with open(MONOLITH, 'r', encoding='utf-8') as f:
    source = f.read()
lines = source.splitlines(keepends=True)

tree = ast.parse(source)

# Groups of functions to extract per module
GROUPS = {
    "file_processor": [
        "read_uploaded_file", "summarize_uploaded_file_with_llm",
    ],
    "kb": [
        "search_internal_knowledge", "stage_kb",
    ],
    "web": [
        "stage_web", "run_web_search_stage", "search_web_tavily",
        "summarize_web_content_with_llm",
        "_dedup_web_against_existing",
        "_gemini_url_context", "_gemini_search_web", "_gemini_extract_urls",
        "_gemini_log_url", "_gemini_log_search",
        "_tavily_search_domain", "_tavily_extract", "_tavily_rank_curated_urls",
        "_tavily_fetch",
    ],
    "curated": [
        "stage_curated", "fetch_internal_weblinks", "_llm_select_curated_links",
    ],
    "user_sources": [
        "stage_user_sources", "fetch_user_external_links",
    ],
    "synthesis": [
        "stage_synthesis", "stage_synthesis_from_parallel",
        "_seed_research_results",
        "finalize_research_results",
        "build_research_output", "update_request_status",
        "synthesize_research_findings",
        "_unified_top_k", "_rerank_sources",
        "_llm_judge_relevance", "_annotate_relevance",
        "_llm_reformulate_for_relevance", "_llm_identify_gaps",
        "_topic_overlap_score", "_apply_topic_relevance",
    ],
}

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "extracted")
os.makedirs(OUT_DIR, exist_ok=True)

# Get line ranges for all top-level functions
func_ranges = {}
for node in ast.iter_child_nodes(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        func_ranges[node.name] = (node.lineno - 1, node.end_lineno)

for group_name, func_names in GROUPS.items():
    out_path = os.path.join(OUT_DIR, f"{group_name}_functions.py")
    with open(out_path, 'w', encoding='utf-8') as f:
        for fn in func_names:
            if fn in func_ranges:
                start, end = func_ranges[fn]
                f.write(f"# {'='*70}\n# {fn} (lines {start+1}-{end})\n# {'='*70}\n")
                f.write(''.join(lines[start:end]))
                f.write('\n\n')
            else:
                f.write(f"# WARNING: {fn} NOT FOUND in monolith\n\n")
    print(f"{group_name}: {len([fn for fn in func_names if fn in func_ranges])}/{len(func_names)} functions extracted -> {out_path}")

print(f"\nExtracted to: {OUT_DIR}")
