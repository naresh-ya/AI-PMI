"""
Lambda Handler for Policy Updates Intelligence
Fetches and processes policy update articles from various jurisdictions.

Production-ready implementation with:
- Comprehensive error handling
- Structured logging
- Input validation
- Environment variable management
- Timeout protection
- Monitoring and metrics
- Type hints and documentation
"""

import json
import os
import logging
import traceback
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime
import time

import boto3
import requests
import concurrent.futures
import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, parse_qs, unquote
from boto3.dynamodb.conditions import Attr
from botocore.exceptions import ClientError

# Optional dependency for date parsing
try:
    from dateutil import parser as date_parser
    DATEUTIL_AVAILABLE = True
except ImportError:
    DATEUTIL_AVAILABLE = False
    logging.warning("python-dateutil not available, date formatting will be limited")

# =====================================================
# LOGGING CONFIGURATION
# =====================================================

# Configure structured logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Remove default handler and add custom formatter
if logger.handlers:
    for handler in logger.handlers:
        logger.removeHandler(handler)

handler = logging.StreamHandler()
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
handler.setFormatter(formatter)
logger.addHandler(handler)

# =====================================================
# CONFIGURATION - ENVIRONMENT VARIABLES
# =====================================================

# DynamoDB Tables
USERS_TABLE = os.environ.get("USERS_TABLE", "pmi-agentic-ai-users")
POLICIES_TABLE = os.environ.get("POLICIES_TABLE", "pmi-agentic-ai-policy-updates")

# Processing limits
MAX_ARTICLES = int(os.environ.get("MAX_ARTICLES", "20"))
MAX_WORKERS = int(os.environ.get("MAX_WORKERS", "3"))
REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", "20"))
API_GATEWAY_TIMEOUT_BUFFER = int(os.environ.get("API_GATEWAY_TIMEOUT_BUFFER", "25"))

# How many months of policy updates to return to the frontend (default: 6 months)
POLICY_UPDATES_MONTHS_LIMIT = int(os.environ.get("POLICY_UPDATES_MONTHS_LIMIT", "6"))

# HTTP Configuration
USER_AGENT = os.environ.get(
    "USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/137.0.0.0 Safari/537.36"
)

# AWS Region
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

# Initialize AWS clients with error handling
try:
    dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
    logger.info(f"DynamoDB client initialized for region: {AWS_REGION}")
except Exception as e:
    logger.error(f"Failed to initialize DynamoDB client: {e}")
    dynamodb = None

# =====================================================
# CUSTOM EXCEPTIONS
# =====================================================

class PolicyUpdateException(Exception):
    """Base exception for policy update operations"""
    pass

class UserNotFoundException(PolicyUpdateException):
    """Raised when user is not found in database"""
    pass

class CountryNotFoundException(PolicyUpdateException):
    """Raised when country is not found for user"""
    pass

class NoURLsFoundException(PolicyUpdateException):
    """Raised when no URLs found for jurisdiction"""
    pass

class TimeoutException(PolicyUpdateException):
    """Raised when operation times out"""
    pass

# =====================================================
# INPUT VALIDATION
# =====================================================

def validate_email(email: str) -> bool:
    """
    Validate email format.
    
    Args:
        email: Email address to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not email or not isinstance(email, str):
        return False
    
    # Basic email validation
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(email_pattern, email.strip()))

def sanitize_input(value: str, max_length: int = 255) -> str:
    """
    Sanitize input string.
    
    Args:
        value: Input string to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized string
    """
    if not value:
        return ""
    
    # Remove control characters and limit length
    sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', str(value))
    return sanitized[:max_length].strip()

# =====================================================
# DATE FORMATTING
# =====================================================

def format_date_standard(date_str: str) -> str:
    """
    Convert any date format to 'Jan 24th 2026' format.
    
    Args:
        date_str: Date string in any format
        
    Returns:
        Formatted date string or "Date not found"
    """
    if not date_str or date_str == "Date not found":
        return "Date not found"
    
    if not DATEUTIL_AVAILABLE:
        return date_str
    
    try:
        # Parse the date
        parsed_date = date_parser.parse(date_str, fuzzy=True)
        
        # Get day with suffix (1st, 2nd, 3rd, 4th, etc.)
        day = parsed_date.day
        if 10 <= day % 100 <= 20:
            suffix = 'th'
        else:
            suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(day % 10, 'th')
        
        # Format as "Jan 24th 2026"
        formatted = parsed_date.strftime(f"%b {day}{suffix} %Y")
        return formatted
    
    except Exception as e:
        logger.warning(f"Could not format date '{date_str}': {e}")
        return date_str  # Return original if parsing fails

def parse_date_for_sorting(date_str: str) -> datetime:
    """
    Parse date for sorting purposes.
    
    Args:
        date_str: Date string to parse
        
    Returns:
        Parsed datetime object or datetime.min
    """
    if not date_str or date_str == "Date not found":
        return datetime.min
    
    if not DATEUTIL_AVAILABLE:
        return datetime.min
    
    try:
        parsed = date_parser.parse(date_str, fuzzy=True)
        # Remove timezone info to avoid comparison issues
        if parsed.tzinfo is not None:
            parsed = parsed.replace(tzinfo=None)
        return parsed
    except Exception as e:
        logger.debug(f"Could not parse date for sorting '{date_str}': {e}")
        return datetime.min

# =====================================================
# HTTP UTILITIES
# =====================================================

def fetch_page(url: str) -> Optional[str]:
    """
    Fetch page with proper headers, timeout, and error handling.
    
    Args:
        url: URL to fetch
        
    Returns:
        Page HTML content or None if failed
    """
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.google.com/"
    }

    try:
        response = requests.get(
            url,
            headers=headers,
            timeout=REQUEST_TIMEOUT,
            verify=True,  # Changed to True for production
            allow_redirects=True
        )
        
        if response.status_code == 200:
            return response.text
        elif response.status_code in (301, 302):
            logger.warning(f"Redirect encountered for {url}")
            return None
        else:
            logger.warning(f"HTTP {response.status_code} for {url}")
            return response.text if response.text else None

    except requests.exceptions.Timeout:
        logger.warning(f"Timeout fetching {url}")
        return None
    except requests.exceptions.ConnectionError:
        logger.warning(f"Connection error fetching {url}")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error fetching {url}: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error fetching {url}: {e}")
        return None

# =====================================================
# URL UTILITIES
# =====================================================

def clean_redirect_url(url: str) -> str:
    """
    Extract actual URL from redirect/tracking URLs.
    
    Args:
        url: URL that may contain redirect parameters
        
    Returns:
        Cleaned URL
    """
    try:
        # Check if it's a redirect URL
        if 'redirect' in url.lower() or 'track' in url.lower():
            # Parse the URL
            parsed = urlparse(url)
            
            # Get query parameters
            params = parse_qs(parsed.query)
            
            # Common redirect parameter names
            redirect_params = ['href', 'url', 'redirect', 'link', 'target', 'destination']
            
            for param in redirect_params:
                if param in params:
                    # Get the first value
                    redirect_url = params[param][0]
                    # URL decode it
                    actual_url = unquote(redirect_url)
                    logger.debug(f"Cleaned redirect URL: {actual_url}")
                    return actual_url
        
        return url
    
    except Exception as e:
        logger.warning(f"Error cleaning redirect URL: {e}")
        return url

def extract_domain(url: str) -> str:
    """
    Extract domain name from URL.
    
    Args:
        url: URL to extract domain from
        
    Returns:
        Domain name
    """
    try:
        hostname = urlparse(url).netloc.lower()
        hostname = hostname.replace("www.", "")
        parts = hostname.split(".")

        if len(parts) >= 2:
            return parts[-2]

        return hostname

    except Exception as e:
        logger.warning(f"Error extracting domain from {url}: {e}")
        return ""

# =====================================================
# ARTICLE EXTRACTION - DATE UTILITIES
# =====================================================

def extract_date_from_listing(tag) -> Optional[str]:
    """
    Extract date from listing page near the article link.
    
    Args:
        tag: BeautifulSoup tag element
        
    Returns:
        Date string or None
    """
    try:
        container = tag.find_parent(["article", "div", "li"]) or tag.parent

        if not container:
            return None

        # Standard time tag
        time_tag = container.find("time")

        if time_tag:
            if time_tag.get("datetime"):
                return time_tag["datetime"].strip()

            text = time_tag.get_text(strip=True)
            if text:
                return text

        # Common date-related classes
        elements = container.find_all(True, class_=True)

        for element in elements:
            classes = " ".join(element.get("class", [])).lower()

            if any(keyword in classes for keyword in ["date", "publish", "posted", "time", "updated"]):
                text = element.get_text(strip=True)
                if text and len(text) < 100:
                    return text

        return None

    except Exception as e:
        logger.debug(f"Error extracting date from listing: {e}")
        return None

def extract_date_from_text(soup) -> Optional[str]:
    """
    Extract date from article text near 'published', 'updated', etc. keywords.
    
    Args:
        soup: BeautifulSoup object
        
    Returns:
        Date string or None
    """
    if not DATEUTIL_AVAILABLE:
        return None
    
    try:
        # Get all text content
        full_text = soup.get_text(separator=' ', strip=True)
        
        # Keywords to look for
        keywords = [
            r'published[:\s]+([A-Za-z]+\s+\d{1,2},?\s+\d{4})',
            r'updated[:\s]+([A-Za-z]+\s+\d{1,2},?\s+\d{4})',
            r'posted[:\s]+([A-Za-z]+\s+\d{1,2},?\s+\d{4})',
        ]
        
        # Try each pattern
        for pattern in keywords:
            matches = re.finditer(pattern, full_text, re.IGNORECASE)
            for match in matches:
                date_str = match.group(1).strip()
                if date_str and len(date_str) < 50:
                    try:
                        date_parser.parse(date_str, fuzzy=False)
                        return date_str
                    except:
                        continue
        
        return None
    
    except Exception as e:
        logger.debug(f"Text-based date extraction failed: {e}")
        return None

def get_article_date(article_url: str) -> str:
    """
    Extract date from article page with multi-level logic.
    
    Args:
        article_url: URL of the article
        
    Returns:
        Date string or "Date not found"
    """
    try:
        html = fetch_page(article_url)

        if not html:
            return "Date not found"

        soup = BeautifulSoup(html, "html.parser")

        # Method 1: Common meta tags
        meta_fields = [
            ("property", "article:published_time"),
            ("property", "article:modified_time"),
            ("property", "og:updated_time"),
            ("name", "publish-date"),
            ("name", "publication_date"),
            ("name", "pubdate"),
            ("name", "date"),
            ("name", "DC.date"),
            ("itemprop", "datePublished"),
            ("itemprop", "dateModified")
        ]

        for attr_name, attr_value in meta_fields:
            tag = soup.find("meta", attrs={attr_name: attr_value})
            if tag and tag.get("content"):
                date_value = tag["content"].strip()
                if date_value:
                    return date_value

        # Method 2: Time tags
        for time_tag in soup.find_all("time"):
            if time_tag.get("datetime"):
                date_value = time_tag["datetime"].strip()
                if date_value:
                    return date_value

            text = time_tag.get_text(strip=True)
            if text:
                return text

        # Method 3: JSON-LD structured data
        json_ld_scripts = soup.find_all("script", type="application/ld+json")

        for script in json_ld_scripts[:3]:
            try:
                if not script.string:
                    continue

                data = json.loads(script.string)
                candidates = [data] if isinstance(data, dict) else data if isinstance(data, list) else []

                for item in candidates[:5]:
                    if not isinstance(item, dict):
                        continue

                    for field in ["datePublished", "dateModified", "dateCreated"]:
                        value = item.get(field)
                        if value:
                            return str(value).strip()

            except json.JSONDecodeError:
                continue
            except Exception as e:
                logger.debug(f"Error parsing JSON-LD: {e}")
                continue

        # Method 4: Text-based extraction
        text_date = extract_date_from_text(soup)
        if text_date and text_date != "Date not found":
            logger.debug(f"Text extraction found date: {text_date}")
            return text_date

        return "Date not found"

    except Exception as e:
        logger.error(f"Error getting article date for {article_url}: {e}")
        return "Date not found"

# =====================================================
# ARTICLE EXTRACTION - SPECIALIZED EXTRACTORS
# =====================================================

def extract_vnexpress_search_results(soup, url: str) -> List[Tuple[str, str, Optional[str]]]:
    """
    Special extraction for VNExpress search results.
    
    Args:
        soup: BeautifulSoup object
        url: Source URL
        
    Returns:
        List of tuples (title, article_url, date)
    """
    articles = []
    
    try:
        # VNExpress search results are typically in specific containers
        result_containers = soup.find_all(['article', 'div'], class_=re.compile(r'(item-news|search-result|article-item)', re.I))
        
        if not result_containers:
            # Fallback: look for links that contain /news/ in the path
            for a_tag in soup.find_all('a', href=True):
                href = a_tag.get('href')
                
                # Filter: must contain /news/ and not be navigation
                if '/news/' in href and not any(x in href.lower() for x in ['/category/', '/tag/', '/search/', 'javascript:', 'mailto:']):
                    title = a_tag.get_text(strip=True)
                    
                    if title and len(title) > 15:
                        article_url = urljoin(url, href)
                        
                        # Try to find date
                        parent = a_tag.find_parent(['article', 'div', 'li'])
                        listing_date = None
                        if parent:
                            time_elem = parent.find(['time', 'span'], class_=re.compile(r'(date|time)', re.I))
                            if time_elem:
                                listing_date = time_elem.get('datetime') or time_elem.get_text(strip=True)
                        
                        articles.append((title, article_url, listing_date))
        else:
            # Extract from result containers
            for container in result_containers:
                title_link = container.find('a', href=True)
                if not title_link:
                    continue
                
                href = title_link.get('href')
                if not href or '/news/' not in href:
                    continue
                
                title = title_link.get_text(strip=True)
                if not title or len(title) < 15:
                    continue
                
                article_url = urljoin(url, href)
                
                # Extract date
                time_elem = container.find(['time', 'span'], class_=re.compile(r'(date|time)', re.I))
                listing_date = None
                if time_elem:
                    listing_date = time_elem.get('datetime') or time_elem.get_text(strip=True)
                
                articles.append((title, article_url, listing_date))
        
        logger.info(f"VNExpress search extraction found {len(articles)} articles")
        
    except Exception as e:
        logger.error(f"VNExpress search extraction failed: {e}")
    
    return articles

def extract_articles_h_tags(soup, url: str) -> List[Tuple[str, str, Optional[str]]]:
    """
    Method 1: Extract articles from H1/H2/H3 tags.
    
    Args:
        soup: BeautifulSoup object
        url: Source URL
        
    Returns:
        List of tuples (title, article_url, date)
    """
    articles = []
    
    # Special handling for VNExpress search results
    if 'vnexpress.net/search' in url.lower():
        return extract_vnexpress_search_results(soup, url)
    
    for tag in soup.find_all(["h1", "h2", "h3"]):
        title = tag.get_text(strip=True)
        
        if not title or len(title) < 10:
            continue
        
        link_tag = tag.find("a") or tag.find_parent("a")
        
        if not link_tag:
            continue
        
        article_url = link_tag.get("href")
        
        if not article_url:
            continue
        
        article_url = urljoin(url, article_url)
        
        # Clean redirect URLs
        article_url = clean_redirect_url(article_url)
        
        # Extract date from listing page
        listing_date = extract_date_from_listing(tag)
        
        articles.append((title, article_url, listing_date))
    
    return articles

def extract_articles_a_tags(soup, url: str) -> List[Tuple[str, str, Optional[str]]]:
    """
    Method 2: Extract articles from <a> tags.
    
    Args:
        soup: BeautifulSoup object
        url: Source URL
        
    Returns:
        List of tuples (title, article_url, date)
    """
    articles = []
    
    for a_tag in soup.find_all("a", href=True):
        href = a_tag.get("href")
        title = a_tag.get_text(strip=True)
        
        if not title or len(title) < 10:
            continue
        
        if any(x in href.lower() for x in ['javascript:', 'mailto:', '#', 'login', 'signup']):
            continue
        
        article_url = urljoin(url, href)
        
        # Try to find date near the link
        parent = a_tag.find_parent(['article', 'div', 'li'])
        listing_date = None
        if parent:
            time_tag = parent.find('time')
            if time_tag:
                listing_date = time_tag.get('datetime') or time_tag.get_text(strip=True)
        
        articles.append((title, article_url, listing_date))
    
    return articles

def extract_articles_json_script(soup, url: str) -> List[Tuple[str, str, Optional[str]]]:
    """
    Method 3: Extract articles from __NEXT_DATA__ JSON script.
    
    Args:
        soup: BeautifulSoup object
        url: Source URL
        
    Returns:
        List of tuples (title, article_url, date)
    """
    articles = []
    
    try:
        next_data_script = soup.find('script', {'id': '__NEXT_DATA__'})
        
        if next_data_script and next_data_script.string:
            data = json.loads(next_data_script.string)
            
            def find_articles_in_json(obj, depth=0):
                if depth > 10:
                    return
                
                if isinstance(obj, dict):
                    if 'title' in obj and 'url' in obj:
                        title = obj.get('title', '')
                        article_url = obj.get('url', '')
                        date = obj.get('publishedDate') or obj.get('date') or obj.get('createdAt')
                        
                        if title and article_url:
                            full_url = urljoin(url, article_url)
                            articles.append((title, full_url, date))
                    
                    for value in obj.values():
                        find_articles_in_json(value, depth + 1)
                
                elif isinstance(obj, list):
                    for item in obj:
                        find_articles_in_json(item, depth + 1)
            
            find_articles_in_json(data)
    
    except json.JSONDecodeError as e:
        logger.warning(f"JSON script extraction failed - invalid JSON: {e}")
    except Exception as e:
        logger.error(f"JSON script extraction failed: {e}")
    
    return articles

# =====================================================
# ARTICLE EXTRACTION - MAIN FUNCTION
# =====================================================

def get_articles(url: str, max_articles: int = MAX_ARTICLES) -> List[Tuple[str, str, Optional[str]]]:
    """
    Extract articles using multi-level logic.
    
    Args:
        url: Source URL to extract articles from
        max_articles: Maximum number of articles to return
        
    Returns:
        List of tuples (title, article_url, date)
    """
    logger.info(f"Fetching articles from: {url}")
    
    html = fetch_page(url)

    if not html:
        logger.warning(f"Failed to fetch {url}")
        return []

    soup = BeautifulSoup(html, "html.parser")
    articles = []

    # Level 1: Try H-tags method (works for most sites)
    articles = extract_articles_h_tags(soup, url)
    logger.info(f"H-tags method found {len(articles)} articles")

    # Level 2: If no articles, try JSON script method
    if not articles:
        articles = extract_articles_json_script(soup, url)
        logger.info(f"JSON script method found {len(articles)} articles")

    # Level 3: If still no articles, try A-tags method
    if not articles:
        articles = extract_articles_a_tags(soup, url)
        logger.info(f"A-tags method found {len(articles)} articles")

    # Remove duplicates
    seen_titles = set()
    unique_articles = []

    for title, article_url, listing_date in articles:
        if title not in seen_titles:
            seen_titles.add(title)
            unique_articles.append((title, article_url, listing_date))

    # Limit to max articles
    unique_articles = unique_articles[:max_articles]

    logger.info(f"Total unique articles: {len(unique_articles)}")

    return unique_articles

# =====================================================
# ARTICLE PROCESSING
# =====================================================

def process_single_article(
    title: str, 
    article_url: str, 
    listing_date: Optional[str], 
    source_url: str
) -> Optional[Dict[str, Any]]:
    """
    Process a single article - fetch date if not available from listing.
    
    Args:
        title: Article title
        article_url: Article URL
        listing_date: Date from listing page (if available)
        source_url: Source URL where article was found
        
    Returns:
        Article record dictionary or None if processing failed
    """
    try:
        # Prefer listing page date
        if listing_date:
            date = listing_date
        else:
            logger.debug(f"Fetching date for: {title[:50]}...")
            date = get_article_date(article_url)
        
        # Format date to standard format
        formatted_date = format_date_standard(date)
        
        return {
            "article": title,
            "date": formatted_date,
            "url": article_url,
            "domain": extract_domain(article_url),
            "source_site": source_url,
            "_sort_date": parse_date_for_sorting(date)  # For sorting
        }
    
    except Exception as e:
        logger.error(f"Error processing article {article_url}: {e}")
        return None

# =====================================================
# URL PROCESSING - PARALLEL WITH TIMEOUT
# =====================================================

def process_single_url(source_url: str, start_time: float) -> List[Dict[str, Any]]:
    """
    Process a single URL with timeout check.
    
    Args:
        source_url: URL to process
        start_time: Start time of the overall operation
        
    Returns:
        List of article records
    """
    # Check if we're approaching timeout
    elapsed = time.time() - start_time
    if elapsed > API_GATEWAY_TIMEOUT_BUFFER:
        logger.warning(f"Skipping {source_url} - approaching timeout")
        return []
    
    try:
        logger.info(f"\n{'='*80}")
        logger.info(f"Processing: {source_url}")
        logger.info(f"{'='*80}")
        
        articles = get_articles(source_url)
        
        if not articles:
            logger.warning(f"No articles found for {source_url}")
            return []
        
        results = []
        
        # Process articles with date fetching
        for title, article_url, listing_date in articles:
            # Check timeout before processing each article
            elapsed = time.time() - start_time
            if elapsed > API_GATEWAY_TIMEOUT_BUFFER:
                logger.warning("Timeout reached - returning partial results")
                break
            
            result = process_single_article(title, article_url, listing_date, source_url)
            if result:
                results.append(result)
        
        logger.info(f"✓ Collected {len(results)} articles from {source_url}")
        return results
        
    except Exception as e:
        logger.error(f"Failed for {source_url}: {e}")
        return []

def process_jurisdiction_urls(urls: List[str], start_time: float) -> List[Dict[str, Any]]:
    """
    Process URLs in parallel with timeout protection.
    
    Args:
        urls: List of URLs to process
        start_time: Start time of the overall operation
        
    Returns:
        List of all article records
    """
    all_records = []
    seen_urls = set()
    
    # Use ThreadPoolExecutor for parallel processing
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        
        # Submit all URL processing tasks
        future_to_url = {
            executor.submit(process_single_url, url, start_time): url 
            for url in urls
        }
        
        # Collect results as they complete
        for future in concurrent.futures.as_completed(future_to_url, timeout=API_GATEWAY_TIMEOUT_BUFFER):
            
            # Check timeout before processing result
            elapsed = time.time() - start_time
            if elapsed > API_GATEWAY_TIMEOUT_BUFFER:
                logger.warning("Timeout reached - returning partial results")
                break
            
            try:
                records = future.result(timeout=5)
                
                for record in records:
                    article_url = record.get("url")
                    if article_url not in seen_urls:
                        seen_urls.add(article_url)
                        all_records.append(record)
                        
            except concurrent.futures.TimeoutError:
                url = future_to_url[future]
                logger.warning(f"Timeout processing {url}")
            except Exception as e:
                url = future_to_url[future]
                logger.error(f"Error processing {url}: {e}")
    
    # Filter out articles without dates
    total_before_filter = len(all_records)
    all_records = [r for r in all_records if r.get('date') != 'Date not found']
    filtered_count = total_before_filter - len(all_records)
    
    if filtered_count > 0:
        logger.info(f"Filtered out {filtered_count} articles without dates")
    
    # Sort by date (latest to oldest)
    all_records.sort(key=lambda x: x.get('_sort_date', datetime.min), reverse=True)
    
    # Remove the sorting helper field
    for record in all_records:
        record.pop('_sort_date', None)
    
    return all_records

# =====================================================
# DYNAMODB OPERATIONS
# =====================================================

def get_user_country(email: str) -> str:
    """
    Get user's country from DynamoDB.
    
    Args:
        email: User email address
        
    Returns:
        Country name (lowercase)
        
    Raises:
        UserNotFoundException: If user not found
        CountryNotFoundException: If country not found for user
    """
    if not dynamodb:
        raise PolicyUpdateException("DynamoDB client not initialized")
    
    try:
        table = dynamodb.Table(USERS_TABLE)
        
        response = table.get_item(Key={"email": email})
        
        item = response.get("Item")
        
        if not item:
            raise UserNotFoundException(f"User not found: {email}")
        
        country = item.get("country")
        
        if not country:
            raise CountryNotFoundException(f"No country found for {email}")
        
        return country.lower().strip()
    
    except ClientError as e:
        error_code = e.response['Error']['Code']
        logger.error(f"DynamoDB error getting user country: {error_code}")
        raise PolicyUpdateException(f"Database error: {error_code}")
    except (UserNotFoundException, CountryNotFoundException):
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting user country: {e}")
        raise PolicyUpdateException(f"Error retrieving user data: {str(e)}")

def get_urls_for_jurisdiction(country: str) -> List[str]:
    """
    Get URLs for a jurisdiction from DynamoDB.
    
    Args:
        country: Country/jurisdiction name
        
    Returns:
        List of URLs
        
    Raises:
        NoURLsFoundException: If no URLs found for jurisdiction
    """
    if not dynamodb:
        raise PolicyUpdateException("DynamoDB client not initialized")
    
    try:
        table = dynamodb.Table(POLICIES_TABLE)
        
        items = []
        
        response = table.scan(
            FilterExpression=Attr("jurisdiction").eq(country)
        )
        
        items.extend(response.get("Items", []))
        
        # Handle pagination
        while "LastEvaluatedKey" in response:
            response = table.scan(
                FilterExpression=Attr("jurisdiction").eq(country),
                ExclusiveStartKey=response["LastEvaluatedKey"]
            )
            items.extend(response.get("Items", []))
        
        urls = []
        
        for item in items:
            url = item.get("web_url")
            if url:
                urls.append(url)
        
        # Remove duplicates
        urls = list(set(urls))
        
        if not urls:
            raise NoURLsFoundException(f"No URLs found for jurisdiction: {country}")
        
        return urls
    
    except ClientError as e:
        error_code = e.response['Error']['Code']
        logger.error(f"DynamoDB error getting URLs: {error_code}")
        raise PolicyUpdateException(f"Database error: {error_code}")
    except NoURLsFoundException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting URLs: {e}")
        raise PolicyUpdateException(f"Error retrieving URLs: {str(e)}")

# =====================================================
# RESPONSE UTILITIES
# =====================================================

def create_response(
    status_code: int, 
    body: Dict[str, Any], 
    additional_headers: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Create standardized API Gateway response.
    
    Args:
        status_code: HTTP status code
        body: Response body dictionary
        additional_headers: Additional headers to include
        
    Returns:
        API Gateway response dictionary
    """
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
    }
    
    if additional_headers:
        headers.update(additional_headers)
    
    return {
        "statusCode": status_code,
        "headers": headers,
        "body": json.dumps(body, ensure_ascii=False)
    }

def create_error_response(
    status_code: int, 
    error_message: str, 
    error_type: Optional[str] = None
) -> Dict[str, Any]:
    """
    Create standardized error response.
    
    Args:
        status_code: HTTP status code
        error_message: Error message
        error_type: Type of error (optional)
        
    Returns:
        API Gateway error response dictionary
    """
    body = {
        "error": error_message,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    
    if error_type:
        body["error_type"] = error_type
    
    return create_response(status_code, body)

# =====================================================
# CONFIGURATION - OUTPUT TABLE
# =====================================================
OUTPUT_TABLE = os.environ.get("OUTPUT_TABLE", "pmi-agentic-ai-policy-updates-output")

# =====================================================
# LAMBDA HANDLER (DUAL PATH: EventBridge scheduled + API Gateway GET)
# =====================================================

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Dual-path Lambda handler:
      1. EventBridge Scheduled Trigger → batch scrape ALL jurisdictions, write to output table
      2. API Gateway GET → read cached results from output table for user's jurisdiction

    Detection: EventBridge events have 'source'='aws.events' or 'detail-type'='Scheduled Event'.
    """
    # Detect EventBridge scheduled trigger
    if event.get('source') == 'aws.events' or event.get('detail-type') == 'Scheduled Event':
        return scheduled_batch_handler(event, context)

    # Otherwise: API Gateway GET request (serve cached results)
    return api_get_handler(event, context)


def scheduled_batch_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    EventBridge scheduled path: scrape ALL jurisdictions and write results to output table.
    Runs on Mon/Thu at 5AM IST. No user context — processes all countries.
    """
    global API_GATEWAY_TIMEOUT_BUFFER
    # Override timeout for batch mode — use full Lambda timeout (900s) minus 30s buffer
    API_GATEWAY_TIMEOUT_BUFFER = 870

    start_time = time.time()
    request_id = getattr(context, 'aws_request_id', 'scheduled') if context else "scheduled"
    logger.info(f"SCHEDULED_BATCH | request_id={request_id} | start")

    # Get all distinct jurisdictions from the input table
    jurisdictions = _get_all_jurisdictions()
    logger.info(f"SCHEDULED_BATCH | jurisdictions={jurisdictions}")

    total_written = 0
    results_summary = {}

    for country in jurisdictions:
        try:
            urls = get_urls_for_jurisdiction(country)
            logger.info(f"SCHEDULED_BATCH | country={country} | urls={len(urls)}")

            # Process URLs (scrape + extract articles)
            articles = process_jurisdiction_urls(urls, start_time)
            logger.info(f"SCHEDULED_BATCH | country={country} | articles={len(articles)}")

            # Write to output table
            written = _write_articles_to_output(country, articles)
            total_written += written
            results_summary[country] = {'articles': len(articles), 'written': written}

        except Exception as e:
            logger.error(f"SCHEDULED_BATCH | country={country} | error: {e}")
            results_summary[country] = {'articles': 0, 'written': 0, 'error': str(e)}

    elapsed = time.time() - start_time
    logger.info(
        f"SCHEDULED_BATCH | COMPLETE | total_written={total_written} "
        f"| elapsed={elapsed:.1f}s | summary={json.dumps(results_summary)}"
    )

    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Scheduled batch complete',
            'total_articles_written': total_written,
            'processing_time_seconds': round(elapsed, 2),
            'summary': results_summary,
        })
    }


def api_get_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    API Gateway GET path: read cached results from output table for user's jurisdiction.
    Resolves user email → country → reads from pmi-agentic-ai-policy-updates-output.
    Instant response (no scraping).
    """
    start_time = time.time()
    request_id = getattr(context, 'aws_request_id', 'api') if context else "api"
    logger.info(f"API_GET | request_id={request_id}")

    try:
        # Extract email from query params or body
        email = ''
        if event.get('queryStringParameters'):
            email = (event['queryStringParameters'].get('email') or '').strip()
        if not email and isinstance(event.get('body'), str):
            try:
                body = json.loads(event['body'])
                email = (body.get('email') or '').strip()
            except (json.JSONDecodeError, AttributeError):
                pass
        if not email and isinstance(event.get('body'), dict):
            email = (event['body'].get('email') or '').strip()
        # Also support direct event (non-proxy)
        if not email:
            email = (event.get('email') or '').strip()

        if not email:
            return create_error_response(400, "email parameter is required", "ValidationError")

        if not validate_email(email):
            return create_error_response(400, "Invalid email format", "ValidationError")

        email = sanitize_input(email)
        logger.info(f"API_GET | email={email}")

        # Resolve user → country
        try:
            country = get_user_country(email)
        except UserNotFoundException as e:
            return create_error_response(404, str(e), "UserNotFound")
        except CountryNotFoundException as e:
            return create_error_response(404, str(e), "CountryNotFound")

        # Read cached results from output table
        articles = _read_articles_from_output(country)

        elapsed = time.time() - start_time
        logger.info(f"API_GET | country={country} | articles={len(articles)} | elapsed={elapsed:.3f}s")

        return create_response(200, {
            'records': articles,
            'count': len(articles),
            'jurisdiction': country,
            'source': 'cached',
            'processing_time_seconds': round(elapsed, 3),
            'timestamp': datetime.utcnow().isoformat() + "Z"
        })

    except Exception as e:
        logger.error(f"API_GET | error: {e}\n{traceback.format_exc()}")
        return create_error_response(500, "An internal error occurred. Please try again later.", "InternalServerError")


# =====================================================
# OUTPUT TABLE OPERATIONS
# =====================================================

def _get_all_jurisdictions() -> List[str]:
    """Get all distinct jurisdictions from the input URL table."""
    try:
        table = dynamodb.Table(POLICIES_TABLE)
        response = table.scan(ProjectionExpression="jurisdiction")
        items = response.get('Items', [])
        while 'LastEvaluatedKey' in response:
            response = table.scan(
                ProjectionExpression="jurisdiction",
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))
        jurisdictions = list(set(item['jurisdiction'] for item in items if item.get('jurisdiction')))
        return sorted(jurisdictions)
    except Exception as e:
        logger.error(f"Error getting jurisdictions: {e}")
        return ['india', 'vietnam', 'thailand']  # fallback


def _write_articles_to_output(country: str, articles: List[Dict[str, Any]]) -> int:
    """Write scraped articles to the output DynamoDB table. Returns count written."""
    if not articles:
        return 0

    try:
        table = dynamodb.Table(OUTPUT_TABLE)
        written = 0
        fetch_timestamp = datetime.utcnow().isoformat() + "Z"

        with table.batch_writer() as batch:
            for i, article in enumerate(articles):
                article_url = article.get('url', f'article_{i}')
                item = {
                    'id': f"{country}#{article_url}",
                    'country': country,
                    'title': article.get('article', ''),
                    'url': article_url,
                    'date': article.get('date', ''),
                    'source_url': article.get('source_site', ''),
                    'source_name': article.get('domain', ''),
                    'fetched_at': fetch_timestamp,
                }

                batch.put_item(Item=item)
                written += 1

        logger.info(f"OUTPUT_WRITE | country={country} | written={written}")
        return written

    except Exception as e:
        logger.error(f"Error writing to output table for {country}: {e}")
        return 0


def _read_articles_from_output(country: str) -> List[Dict[str, Any]]:
    """Read cached articles from output table for a given country."""
    try:
        table = dynamodb.Table(OUTPUT_TABLE)

        items = []
        response = table.scan(
            FilterExpression=Attr('country').eq(country)
        )
        items.extend(response.get('Items', []))

        while 'LastEvaluatedKey' in response:
            response = table.scan(
                FilterExpression=Attr('country').eq(country),
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))

        # Sort by date descending (latest first) using proper date parsing
        items.sort(key=lambda x: parse_date_for_sorting(x.get('date', '')), reverse=True)

        # Filter to only return articles within the configured months limit
        from dateutil.relativedelta import relativedelta
        cutoff_date = datetime.now() - relativedelta(months=POLICY_UPDATES_MONTHS_LIMIT)
        items = [item for item in items if parse_date_for_sorting(item.get('date', '')) >= cutoff_date]

        # Clean up internal fields before returning
        cleaned = []
        for item in items:
            cleaned.append({
                'title': item.get('title', ''),
                'url': item.get('url', ''),
                'date': item.get('date', ''),
                'source_url': item.get('source_url', ''),
                'source_name': item.get('source_name', ''),
                'fetched_at': item.get('fetched_at', ''),
                'summary': item.get('summary', ''),
            })

        return cleaned

    except Exception as e:
        logger.error(f"Error reading from output table for {country}: {e}")
        return []

# =====================================================
# HEALTH CHECK HANDLER (Optional)
# =====================================================

def health_check_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Health check endpoint for monitoring.
    
    Args:
        event: Lambda event object
        context: Lambda context object
        
    Returns:
        Health check response
    """
    try:
        # Check DynamoDB connectivity
        if dynamodb:
            table = dynamodb.Table(USERS_TABLE)
            table.table_status  # This will raise an exception if table doesn't exist
            db_status = "healthy"
        else:
            db_status = "unhealthy"
        
        health_data = {
            "status": "healthy" if db_status == "healthy" else "degraded",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "version": "1.0.0",
            "components": {
                "dynamodb": db_status,
                "dateutil": "available" if DATEUTIL_AVAILABLE else "unavailable"
            }
        }
        
        status_code = 200 if health_data["status"] == "healthy" else 503
        
        return create_response(status_code, health_data)
    
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return create_response(503, {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat() + "Z"
        })
