"""
Fetch all 18 URLs and save readable text using Scrapling's built-in get_all_text()
"""

import os
from scrapling.fetchers import Fetcher
from datetime import datetime
import re

# Configure
Fetcher.configure(adaptive=True)

# All 18 URLs
ALL_URLS = {
    "India": [
        "https://ntcp.mohfw.gov.in/",
        "https://www.ndtv.com/topic/tobacco-regulation-india",
        "https://www.thehindu.com/tag/911-903-684/",
        "https://economictimes.indiatimes.com/industry/cons-products/tobacco",
        "https://www.moneycontrol.com/news/tags/tobacco.html",
        "https://www.tiionline.org/",
        "https://www.who.int/india",
    ],
    "Vietnam": [
        "https://vietnamnews.vn/search.html?s=tobacco",
        "https://news.tuoitre.vn/tim-kiem.htm?keyword=tobacco",
        "https://www.who.int/vietnam/",
        "https://english.luatvietnam.vn/search.html?Keywords=tobacco",
        "https://moh.gov.vn/",
        "https://e.vnexpress.net/search/q/tobacco/csrf/753aba2d09f74665c2766a34b9b2b15e",
    ],
    "Thailand": [
        "https://search.bangkokpost.com/search/result?category=all&q=tobacco",
        "https://www.nationthailand.com/search?q=tobacco",
        "https://www.straitstimes.com/search?searchkey=tobacco+thailand",
        "https://www.trc.or.th/en/trc-english-site/",
        "https://www.who.int/thailand/",
    ]
}

def extract_dates(text: str) -> list:
    """Extract dates from text"""
    dates = []
    dates.extend(re.findall(r'\b(20\d{2}[-/](0[1-9]|1[0-2])[-/](0[1-9]|[12]\d|3[01]))\b', text)[:5])
    dates.extend(re.findall(r'\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+20\d{2}\b', text, re.IGNORECASE)[:5])
    return list(set(dates))[:10]

# Create output folder
output_dir = "output_readable"
os.makedirs(output_dir, exist_ok=True)

print(f"Fetching {sum(len(urls) for urls in ALL_URLS.values())} URLs with readable text extraction...")

counter = 1
for country, url_list in ALL_URLS.items():
    for url in url_list:
        print(f"[{counter}/18] {url}")
        
        try:
            fetcher = Fetcher()
            response = fetcher.get(url, timeout=120)
            
            if response.status == 200:
                # Use Scrapling's BUILT-IN method to get readable text
                readable_text = str(response.get_all_text())
                
                # Extract dates
                dates_found = extract_dates(readable_text)
                
                # Create filename
                filename = f"{counter:02d}_{country}_{url.split('/')[2].replace('.', '_')}.md"
                filepath = os.path.join(output_dir, filename)
                
                # Write to .md file
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(f"# {url}\n\n")
                    f.write(f"**Country:** {country}\n\n")
                    f.write(f"**Fetched:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                    f.write(f"**Status:** ✅ Success\n\n")
                    f.write(f"**Content Length:** {len(readable_text):,} characters\n\n")
                    
                    if dates_found:
                        f.write(f"**Dates Found:** {', '.join(str(d) for d in dates_found[:5])}\n\n")
                    
                    f.write("---\n\n")
                    f.write(readable_text)
                
                print(f"  ✅ Saved: {filename} ({len(readable_text):,} chars)")
            else:
                filename = f"{counter:02d}_{country}_FAILED.md"
                filepath = os.path.join(output_dir, filename)
                
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(f"# {url}\n\n")
                    f.write(f"**Country:** {country}\n\n")
                    f.write(f"**Fetched:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                    f.write(f"**Status:** ❌ Failed - HTTP {response.status}\n\n")
                
                print(f"  ❌ Failed: HTTP {response.status}")
                
        except Exception as e:
            filename = f"{counter:02d}_{country}_ERROR.md"
            filepath = os.path.join(output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(f"# {url}\n\n")
                f.write(f"**Country:** {country}\n\n")
                f.write(f"**Fetched:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write(f"**Status:** ❌ Error\n\n")
                f.write(f"**Error:** {str(e)}\n\n")
            
            print(f"  ❌ Error: {str(e)}")
        
        counter += 1

print(f"\n✅ Complete! All readable files saved to '{output_dir}/' folder")
