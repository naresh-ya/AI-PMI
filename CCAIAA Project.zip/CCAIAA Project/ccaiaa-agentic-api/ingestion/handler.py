"""
PMI SharePoint → S3 Ingestion Lambda
=====================================
Triggered by:
  A) EventBridge Rule — daily at 06:00 UTC (11:30 AM IST)
  B) POST /ingest via API Gateway (manual on-demand)

Responsibility:
  Download files from SharePoint and upload them to S3.
  The KB Builder Lambda (pmi-kb-builder) is triggered automatically by the
  S3 ObjectCreated event and handles chunking + embedding + DynamoDB storage.

SharePoint target (PMI tenant):
  Host:    pmicloud.sharepoint.com
  Site:    /teams/SAICDIAandCapgeminiTeam-DIA-India
  Library: PMI Test Artifacts CA
  Folder:  Artifacts from PMI_New Grouping/Notes/Leave-behind notes

Secret format in Secrets Manager (pmi/sharepoint/credentials):
  Dev mode  — static token from Graph Explorer (~1hr validity):
    {"access_token": "eyJ..."}
  Prod mode — OAuth2 client credentials (auto-refresh, no expiry):
    {"tenant_id": "...", "client_id": "...", "client_secret": "..."}
"""

import json
import logging
import os
import traceback
from typing import Any, Dict, List

import boto3
import requests

logger = logging.getLogger()
logger.setLevel(logging.INFO)

secrets_client = boto3.client("secretsmanager")
s3_client      = boto3.client("s3")

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


# ── Token retrieval ───────────────────────────────────────────────────────────

def get_access_token(secret_id: str) -> str:
    """
    Retrieve a Microsoft Graph API access token from Secrets Manager.

    Supports two modes:
    1. Dev  — {"access_token": "eyJ..."}              → returned as-is
    2. Prod — {"tenant_id":"..","client_id":"..","client_secret":".."}
              → OAuth2 client-credentials flow (auto-refresh)
    """
    resp  = secrets_client.get_secret_value(SecretId=secret_id)
    creds = json.loads(resp["SecretString"])

    # Dev mode: static token stored directly
    if "access_token" in creds and "client_secret" not in creds:
        logger.info("Using static access_token (dev mode — expires in ~1hr)")
        return creds["access_token"]

    # Prod mode: OAuth2 client credentials flow
    token_url = (
        f"https://login.microsoftonline.com/"
        f"{creds['tenant_id']}/oauth2/v2.0/token"
    )
    r = requests.post(token_url, data={
        "grant_type":    "client_credentials",
        "client_id":     creds["client_id"],
        "client_secret": creds["client_secret"],
        "scope":         "https://graph.microsoft.com/.default",
    })
    r.raise_for_status()
    logger.info("OAuth2 token obtained successfully")
    return r.json()["access_token"]


# ── Graph API helpers ─────────────────────────────────────────────────────────

def graph_get(url: str, token: str) -> dict:
    """Authenticated GET to Microsoft Graph."""
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"})
    if r.status_code == 401:
        raise ValueError(
            "Graph API returned 401 Unauthorized — "
            "token may be expired. Refresh it in Graph Explorer and update Secrets Manager."
        )
    r.raise_for_status()
    return r.json()


def get_site_id(hostname: str, site_path: str, token: str) -> str:
    """Resolve SharePoint site to its Graph API site ID."""
    url     = f"{GRAPH_BASE}/sites/{hostname}:{site_path}"
    data    = graph_get(url, token)
    site_id = data["id"]
    logger.info(f"Resolved site ID: {site_id}")
    return site_id


def get_drive_id(site_id: str, library_name: str, token: str) -> str:
    """Find the document library drive ID by display name."""
    url  = f"{GRAPH_BASE}/sites/{site_id}/drives"
    data = graph_get(url, token)
    for drive in data.get("value", []):
        if drive.get("name") == library_name:
            logger.info(f"Found drive '{library_name}': {drive['id']}")
            return drive["id"]
    # Fallback: return first available drive
    drives = data.get("value", [])
    if drives:
        logger.warning(
            f"Library '{library_name}' not found — using first drive: {drives[0]['name']}"
        )
        return drives[0]["id"]
    raise ValueError(f"No drives found on site {site_id}")


def list_folder_items(
    site_id: str, drive_id: str, folder_path: str, token: str
) -> List[dict]:
    """List all items in a SharePoint folder via Graph API, fully paginated."""
    encoded_path = folder_path.replace(" ", "%20")
    url  = (
        f"{GRAPH_BASE}/sites/{site_id}/drives/{drive_id}"
        f"/root:/{encoded_path}:/children?$expand=listItem"
    )
    
    items = []
    
    while url:
        data = graph_get(url, token)
        items.extend(data.get("value", []))
        
        # Graph API uses @odata.nextLink for pagination if more items exist
        url = data.get("@odata.nextLink")
        
    logger.info(f"Found {len(items)} total items in folder '{folder_path}' after pagination.")
    return items


def download_and_upload(
    site_id:   str,
    drive_id:  str,
    item:      dict,
    token:     str,
    bucket:    str,
    s3_prefix: str,
) -> str:
    """Download a single file from SharePoint and upload it to S3."""
    item_id   = item["id"]
    file_name = item["name"]

    download_url = (
        f"{GRAPH_BASE}/sites/{site_id}/drives/{drive_id}"
        f"/items/{item_id}/content"
    )
    r = requests.get(
        download_url,
        headers={"Authorization": f"Bearer {token}"},
        allow_redirects=True,
    )
    if r.status_code == 401:
        raise ValueError(
            f"401 Unauthorized downloading '{file_name}' — token may be expired."
        )
    r.raise_for_status()

    s3_key = f"{s3_prefix}/{file_name}"
    
    meta = {
        "sharepoint-item-id":       item_id,
        "sharepoint-last-modified": str(item.get("lastModifiedDateTime", "")),
        "source-filename":          file_name.encode("ascii", "ignore").decode("ascii"),
    }
    
    web_url = item.get("webUrl", "")
    if web_url:
        meta["sharepoint-url"] = str(web_url).encode("ascii", "ignore").decode("ascii")

    list_item = item.get("listItem", {})
    fields = list_item.get("fields", {})
    
    # Debug: log field keys for the first file to verify SharePoint column names
    if not hasattr(lambda_handler, "_logged_keys"):
        logger.info(f"DEBUG SharePoint fields keys for '{file_name}': {list(fields.keys())}")
        lambda_handler._logged_keys = True

    def parse_sp_field(val):
        if not val: return ""
        if isinstance(val, list):
            parsed = []
            for v in val:
                if isinstance(v, dict) and "Label" in v:
                    parsed.append(str(v["Label"]))
                else:
                    parsed.append(str(v))
            return ", ".join(parsed)
        return str(val).strip()

    def get_field_val(target_names):
        """Find field by matching any of the target names (case-insensitive, ignoring _x0020_)."""
        targets = [t.lower().replace(" ", "") for t in target_names]
        for k, v in fields.items():
            clean_k = k.lower().replace("_x0020_", "").replace("_", "")
            if clean_k in targets:
                return v
        return None

    # ── 1. Country (Jurisdiction) ──
    country = parse_sp_field(get_field_val(["Country"]))
    if not country: country = "India"
    meta["sharepoint-jurisdiction"] = country.encode("ascii", "ignore").decode("ascii")

    # ── 2. Owner ──
    owner = parse_sp_field(get_field_val(["Owner"]))
    if owner: meta["sharepoint-owner"] = owner.encode("ascii", "ignore").decode("ascii")

    # ── 3. Language ──
    language = parse_sp_field(get_field_val(["Language", "Language0"]))
    if not language: language = "English"
    meta["sharepoint-language"] = language.encode("ascii", "ignore").decode("ascii")

    # ── 4. Document Theme Level 1 (replaces old category/document_theme) ──
    theme_level_1 = parse_sp_field(get_field_val([
        "DocumentTheme", "Document Theme Level 1", "DocumentThemeLevel1",
        "Document_x0020_Theme_x0020_Level_x0020_1", "Document Theme"
    ]))
    if theme_level_1:
        meta["sharepoint-theme-level-1"] = theme_level_1.encode("ascii", "ignore").decode("ascii")

    # ── 5. Document Theme Level 2 (replaces old use_case) ──
    theme_level_2 = parse_sp_field(get_field_val([
        "Document Theme Level 2", "DocumentThemeLevel2",
        "Document_x0020_Theme_x0020_Level_x0020_2"
    ]))
    if theme_level_2:
        meta["sharepoint-theme-level-2"] = theme_level_2.encode("ascii", "ignore").decode("ascii")

    # ── 6. Department ──
    department = parse_sp_field(get_field_val(["Department"]))
    if department: meta["sharepoint-department"] = department.encode("ascii", "ignore").decode("ascii")

    # ── 7. Valid Till Date ──
    valid_till = parse_sp_field(get_field_val(["Valid Till", "ValidTill", "Validtill"]))
    if valid_till: meta["sharepoint-valid-till"] = valid_till.encode("ascii", "ignore").decode("ascii")

    # ── Topic (if present) ──
    topic = parse_sp_field(get_field_val(["Topic"]))
    if topic: meta["sharepoint-topic"] = topic.encode("ascii", "ignore").decode("ascii")

    s3_client.put_object(
        Bucket=bucket,
        Key=s3_key,
        Body=r.content,
        ContentType=item.get("file", {}).get("mimeType", "application/octet-stream"),
        Metadata=meta,
    )
    logger.info(f"Uploaded '{file_name}' → s3://{bucket}/{s3_key} | L1={theme_level_1} | L2={theme_level_2} | country={country}")
    return s3_key


# ── Lambda entry point ────────────────────────────────────────────────────────

def lambda_handler(event: Dict[str, Any], context: Any) -> dict:
    """
    Lambda entry point — triggered by EventBridge schedule or POST /ingest.

    Optional POST body keys (all have defaults pointing to the PMI SharePoint):
        hostname    — SharePoint hostname      (default: pmicloud.sharepoint.com)
        site_path   — Site path               (default: /teams/SAICDIAandCapgeminiTeam-DIA-India)
        library     — Document library name   (default: PMI Test Artifacts CA)
        folder_path — Folder path in library  (default: Artifacts from PMI_New Grouping/Notes/Leave-behind notes)
        file_types  — List of extensions      (default: [".docx", ".pptx", ".pdf", ".xlsx", ".msg", ".eml"])
    """
    logger.info("Starting SharePoint → S3 ingestion...")

    try:
        # Parse optional overrides from POST body
        body = {}
        if event.get("body"):
            body = (
                json.loads(event["body"])
                if isinstance(event["body"], str)
                else event["body"]
            )

        # Strip protocol prefix — Graph API requires a bare hostname
        raw_hostname = body.get("hostname", "pmicloud.sharepoint.com")
        hostname    = raw_hostname.replace("https://", "").replace("http://", "")
        site_path   = body.get("site_path",   "/teams/SAICDIAandCapgeminiTeam-DIA-India")
        library     = body.get("library",     "PMI Test Artifacts CA")
        folder_path = body.get(
            "folder_path",
            "Consolidated Artifacts",
        )
        file_types  = body.get("file_types",  [".docx", ".pptx", ".pdf", ".xlsx", ".msg", ".eml"])

        secret_id = os.environ["SHAREPOINT_SECRET_ID"]
        bucket    = os.environ["DOCUMENTS_BUCKET"]
        s3_prefix = f"sharepoint/{hostname}{site_path}"

        # 1. Authenticate
        token = get_access_token(secret_id)

        # 2. Resolve site and drive
        site_id  = get_site_id(hostname, site_path, token)
        drive_id = get_drive_id(site_id, library, token)

        # 3. List files
        items = list_folder_items(site_id, drive_id, folder_path, token)

        # 4. Download + upload matching file types only
        uploaded: List[dict] = []
        skipped:  List[str]  = []

        for item in items:
            if "folder" in item:
                continue  # skip sub-folders
            ext = os.path.splitext(item["name"])[1].lower()
            if ext not in file_types:
                skipped.append(item["name"])
                continue
            s3_key = download_and_upload(
                site_id, drive_id, item, token, bucket, s3_prefix
            )
            uploaded.append({"file": item["name"], "s3_key": s3_key})

        logger.info(f"Done. Uploaded: {len(uploaded)}, Skipped: {len(skipped)}")

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
            },
            "body": json.dumps({
                "message":          "SharePoint ingestion successful",
                "uploaded_count":   len(uploaded),
                "downloaded_files": [u["file"] for u in uploaded],
                "s3_keys":          [u["s3_key"] for u in uploaded],
                "skipped_files":    skipped,
            }, default=str),
        }

    except Exception as e:
        logger.error(f"Ingestion failed: {e}")
        traceback.print_exc()
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
            },
            "body": json.dumps({"error": str(e)}),
        }
