# PMI Agentic AI Backend

A serverless backend for the PMI Agentic AI application built on AWS infrastructure.

## Architecture

- **AWS Bedrock**: AI/LLM services for intelligent agents
- **AWS Step Functions**: Orchestration of the 4-agent workflow
- **AWS Lambda**: Serverless compute for each agent
- **AWS API Gateway**: REST API endpoints
- **AWS S3**: Document storage
- **AWS DynamoDB**: Request tracking and metadata

## Agents

### 1. Input Validator Agent
- Validates incoming requests
- Extracts and categorizes requirements
- Assigns priority scores

### 2. Master Researcher Agent
- Orchestrates research across multiple sources
- Synthesizes information using AI
- Stores research results in S3

### 3. Master Drafter Agent
- Generates comprehensive documents
- Creates Word documents with proper formatting
- Integrates research findings and citations

### 4. Master Reviewer Agent
- Conducts compliance and quality reviews
- Performs regulatory analysis
- Generates policy intelligence reports

## Prerequisites

- Python 3.10 or higher
- Node.js (for AWS CDK)
- AWS CLI configured with appropriate credentials
- AWS account with Bedrock access

## Quick Start

1. **Clone and Setup**
   ```powershell
   cd pmi-agentic-ai-backend
   ```

2. **Deploy to AWS**
   ```powershell
   .\deploy.ps1
   ```

3. **Manual Setup (Alternative)**
   ```powershell
   # Create virtual environment
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1

   # Install dependencies
   pip install -r requirements.txt

   # Bootstrap CDK
   cdk bootstrap

   # Deploy
   cdk deploy
   ```

## Configuration

### Environment Variables
The following environment variables are set automatically by CDK:
- `REQUESTS_TABLE`: DynamoDB table for request tracking
- `DOCUMENTS_BUCKET`: S3 bucket for document storage
- `BEDROCK_MODEL_ID`: Bedrock model identifier

### AWS Bedrock Models
Configure access to these models in AWS Console:
- `anthropic.claude-3-5-sonnet-20241022-v2:0` (Primary)
- `anthropic.claude-3-haiku-20240307-v1:0` (Fallback)

## API Endpoints

### POST /requests
Create a new request
```json
{
  "description": "Request description",
  "priority": "high|medium|low",
  "deadline": "2025-02-15",
  "requirements": ["req1", "req2"]
}
```

### GET /requests/{id}
Get request status and results

### GET /health
Health check endpoint

## Development

### Project Structure
```
pmi_agentic_ai/
├── infrastructure/        # CDK infrastructure code
├── agents/               # Lambda function handlers
│   ├── input_validator/
│   ├── master_researcher/
│   ├── master_drafter/
│   └── master_reviewer/
└── api/                 # API Gateway handler
```

### Local Testing
```powershell
# Run unit tests
python -m pytest tests/

# Validate CDK templates
cdk synth

# Run security checks
cdk diff
```

### Adding Sub-Agents
Future sub-agents can be added under each master agent:
```
agents/
├── master_researcher/
│   ├── sub_agents/
│   │   ├── academic_researcher/
│   │   ├── market_researcher/
│   │   └── regulatory_researcher/
```

## Monitoring

- **CloudWatch Logs**: Monitor Lambda function execution
- **X-Ray Tracing**: Distributed tracing for debugging
- **Step Functions Console**: Workflow execution monitoring
- **API Gateway Logs**: API request/response logging

## Security

- IAM roles with least privilege access
- API Gateway with CORS configuration
- S3 bucket encryption at rest
- DynamoDB encryption at rest
- VPC endpoints for internal communication

## Cost Optimization

- Pay-per-use Lambda pricing
- S3 Intelligent Tiering for document storage
- DynamoDB on-demand billing
- Bedrock usage-based pricing

## Troubleshooting

### Common Issues

1. **CDK Bootstrap Failed**
   - Ensure AWS credentials are configured: `aws configure`
   - Check account permissions for CloudFormation

2. **Bedrock Access Denied**
   - Enable Bedrock models in AWS Console
   - Check IAM permissions for Bedrock access

3. **Lambda Timeout**
   - Increase timeout in `main_stack.py`
   - Check CloudWatch logs for detailed errors

4. **Step Functions Execution Failed**
   - Check individual Lambda function logs
   - Verify IAM role permissions

### Support
For issues and support, check:
- AWS CloudWatch Logs
- AWS X-Ray traces
- CDK deployment logs
- Individual Lambda function metrics

## Future Enhancements

- [ ] Sub-agent implementation
- [ ] Multi-language support
- [ ] Advanced caching strategies
- [ ] Real-time notifications
- [ ] Batch processing capabilities
- [ ] Integration with external APIs
