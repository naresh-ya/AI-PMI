"""
Discovery probe: enumerate what Tavily-related endpoints the private LiteLLM
gateway actually exposes, and verify the extract endpoint returns real content.
Read-only. Run this FIRST before probe_gateway_search.py.

Covers:
  - Step 1 prerequisite: confirm /v1/extract/tavily exists and returns content
"""
import json, ssl, os, urllib.request, urllib.error

KEY = os.environ["AWS_BEARER_TOKEN_BEDROCK"]
BASE = "https://litellm.aiplat-dev.aws.private-pmideep.biz"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def get(path):
    url = BASE.rstrip("/") + path
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {KEY}"}, method="GET")
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=30) as r:
            return r.status, r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8")[:300]
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"


# 1) Pull the OpenAPI spec and list every path that mentions tavily/search/extract
print("=" * 70)
print("OpenAPI route discovery")
print("=" * 70)
status, body = get("/openapi.json")
print(f"GET /openapi.json -> {status}")
if status == 200:
    try:
        spec = json.loads(body)
        paths = spec.get("paths", {})
        hits = sorted(p for p in paths if any(k in p.lower() for k in ("tavily", "search", "extract", "scrape", "crawl")))
        print(f"  total paths: {len(paths)}")
        print("  tavily/search/extract-related paths:")
        for p in hits:
            methods = ",".join(m.upper() for m in paths[p].keys())
            print(f"    {methods:10} {p}")
        if not hits:
            print("    (none found)")
    except Exception as e:
        print(f"  could not parse spec: {e}")
else:
    print(f"  body: {body[:200]}")

# 2) Probe candidate extract endpoints directly (HEAD-ish: send empty POST, read status/error)
print("\n" + "=" * 70)
print("Candidate extract-endpoint probes (POST with a test URL)")
print("=" * 70)
candidates = [
    "/v1/extract/tavily",
    "/v1/tavily/extract",
    "/v1/search/tavily/extract",
    "/tavily/extract",
    "/v1/extract",
]
test_payload = json.dumps({"urls": ["https://www.cbic.gov.in/"], "max_results": 1}).encode()
for path in candidates:
    url = BASE.rstrip("/") + path
    req = urllib.request.Request(
        url, data=test_payload,
        headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=30) as r:
            print(f"  POST {path} -> {r.status}  (EXISTS)  body[:160]={r.read().decode('utf-8')[:160]}")
    except urllib.error.HTTPError as e:
        # 404 = route doesn't exist; 4xx other = route exists but payload/validation differs
        tag = "route NOT found" if e.code == 404 else "route exists (non-404)"
        print(f"  POST {path} -> {e.code} [{tag}]  {e.read().decode('utf-8')[:160]}")
    except Exception as e:
        print(f"  POST {path} -> ERROR {type(e).__name__}: {e}")

# 3) Step 1 — verify winning extract endpoint actually returns content
print("\n" + "=" * 70)
print("Step 1 verification: /v1/extract/tavily returns real page content")
print("=" * 70)
extract_payload = json.dumps({"urls": ["https://www.cbic.gov.in/"]}).encode()
req = urllib.request.Request(
    BASE + "/v1/extract/tavily",
    data=extract_payload,
    headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"},
    method="POST",
)
try:
    with urllib.request.urlopen(req, context=ctx, timeout=30) as r:
        data = json.loads(r.read().decode("utf-8"))
    results = data.get("results", [])
    failed  = data.get("failed_results", [])
    print(f"  results={len(results)}  failed={len(failed)}")
    for item in results:
        content = (item.get("raw_content") or item.get("content") or "").strip()
        print(f"  url={item.get('url','')[:70]}")
        print(f"  content_chars={len(content)}  preview={content[:120]!r}")
    for item in failed:
        print(f"  FAILED url={item.get('url','')}  error={item.get('error','')}")
    if results:
        print("\n  ✅ PASS — extract endpoint returns content via private gateway")
    else:
        print("\n  ❌ FAIL — no content returned; check endpoint path or gateway config")
except urllib.error.HTTPError as e:
    print(f"  HTTP {e.code}: {e.read().decode('utf-8')[:300]}")
    print("  ❌ FAIL — update _tavily_extract gateway URL to the correct path from section 2 above")
except Exception as e:
    print(f"  ERROR {type(e).__name__}: {e}")
