"""
Standalone deployer for the client-demo2 split-research pipeline.

This script is SEPARATE from deploy_lambdas.py (which deploys the live client-demo1
fleet and must stay untouched). It creates/updates the 8 client-demo2 functions that
back infrastructure/step_functions_definition_client_demo2.json:

    validator -> planner -> [kb || web || user_sources || curated] -> synthesis -> drafter

Key behaviour:
  - Each function INHERITS its IAM role + env vars + timeout + memory + VPC config from a
    demo1 source function (see INHERIT_* below). That is what gives the new lambdas the
    LiteLLM key, Tavily key, KB id, curated-links table and the private-gateway VPC — i.e.
    the reason web/curated/KB return real results instead of empty.
  - The 6 research stages bundle handler_new_advanced.py at the package root so their thin
    handlers can `import handler_new_advanced`.
  - On update, config is re-synced from the source so it never drifts (idempotent).
  - Orchestration is done by Step Functions (the Parallel state), so there is NO in-lambda
    router, NO USE_SPLIT_RESEARCH flag and NO lambda:InvokeFunction wiring here.

Usage:
    python deploy_lambdas_demo2.py                 # deploy all 8 demo2 functions
    python deploy_lambdas_demo2.py -f pmi-research-web-search-client-demo2
    python deploy_lambdas_demo2.py --inherit-research pmi-master-researcher-client-demo1
"""

import os
import sys
import zipfile
import subprocess
import shutil
import tempfile
import glob
import json
import argparse

REGION = "eu-west-1"
ACCOUNT_ID = "603433800649"

# ── Sources to inherit role + env + timeout + memory + VPC from (demo1, never modified) ──
# The 6 research stages need the researcher's env (LiteLLM/Tavily/KB/curated table/VPC).
INHERIT_RESEARCH = os.environ.get("DEMO2_INHERIT_RESEARCH", "pmi-master-researcher-client-demo1")
INHERIT_VALIDATOR = os.environ.get("DEMO2_INHERIT_VALIDATOR", "pmi-input-validator-client-demo1")
INHERIT_DRAFTER = os.environ.get("DEMO2_INHERIT_DRAFTER", "pmi-master-drafter-client-demo1")

# ── demo2-only env overlay ────────────────────────────────────────────────────
# Extra environment variables applied to EVERY demo2 function on top of the env
# inherited from the demo1 source. Because _sync_config re-applies the inherited
# env on every deploy, anything not in this overlay (or on the demo1 source) is
# wiped. Keeping the flag here means it survives every redeploy WITHOUT touching
# demo1. Set these in the deploy shell to control them, e.g.:
#     $env:PROMPT_MGMT_ENABLED="true"; python deploy_lambdas_demo2.py
# PROMPT_MGMT_ENABLED defaults to "false" so a plain deploy changes nothing.
DEMO2_ENV_OVERLAY = {
    k: v for k, v in {
        "PROMPT_MGMT_ENABLED": os.environ.get("PROMPT_MGMT_ENABLED", "true"),
        "PROMPT_MGMT_REGION": os.environ.get("PROMPT_MGMT_REGION", REGION),
        "PROMPT_MGMT_VERSION": os.environ.get("PROMPT_MGMT_VERSION", ""),
        "PROMPT_MGMT_TIMEOUT_S": os.environ.get("PROMPT_MGMT_TIMEOUT_S", ""),
        # ── KB retrieval via LiteLLM Gateway (us-east-1 KB in Deep account) ──
        # These override the KB id inherited from the demo1 source (OSJDPJLTNC,
        # old eu-west-1 KB) so KB search hits the migrated us-east-1 KB through
        # the LiteLLM gateway. They survive the config re-sync on every deploy.
        "BEDROCK_KB_ID": os.environ.get("BEDROCK_KB_ID", "WQURRONWPQ"),
        "KB_USE_LITELLM_GATEWAY": os.environ.get("KB_USE_LITELLM_GATEWAY", "true"),
        "LITELLM_KB_RETRIEVE_URL": os.environ.get(
            "LITELLM_KB_RETRIEVE_URL",
            "https://litellm.aiplat-dev.aws.private-pmideep.biz/bedrock/knowledgebases/{kb_id}/retrieve",
        ),
        # ── Dual-KB (English Titan + Multilingual Cohere) + inline rerank ───
        # KB search queries BOTH KBs in parallel via the gateway and merges
        # candidates; Cohere rerank (also via the gateway) puts both KBs'
        # chunks on one comparable relevance scale before truncating results.
        # Flip either flag to "false" to instantly revert to English-KB-only,
        # unreranked behavior without a code redeploy.
        "BEDROCK_KB_ID_MULTILINGUAL": os.environ.get("BEDROCK_KB_ID_MULTILINGUAL", "LPMWAHDZS8"),
        "KB_MULTILINGUAL_ENABLED": os.environ.get("KB_MULTILINGUAL_ENABLED", "true"),
        "KB_RERANKER_ENABLED": os.environ.get("KB_RERANKER_ENABLED", "true"),
        "KB_RERANK_TOP_N": os.environ.get("KB_RERANK_TOP_N", "10"),
        # NOT present on the demo1 source (verified) — set explicitly so the
        # KB-stage rerank and researcher_common.py's downstream rerank always
        # agree on which gateway endpoint/model to use.
        "AWS_LITELLM_RERANK_ENDPOINT": os.environ.get(
            "AWS_LITELLM_RERANK_ENDPOINT",
            "https://litellm.aiplat-dev.aws.private-pmideep.biz/rerank",
        ),
        "AWS_LITELLM_RERANK_MODEL": os.environ.get(
            "AWS_LITELLM_RERANK_MODEL",
            "bedrock/arn:aws:bedrock:us-east-1::foundation-model/cohere.rerank-v3-5:0",
        ),
        # Drafter section-generation concurrency. "1" = strict sequential (unchanged
        # behavior, default). Set >1 (e.g. "4") to draft that many sections per wave in
        # parallel, cutting drafting latency on multi-section reports. Validate output
        # parity (dedup / groundedness) before raising it in production:
        #     $env:DRAFT_WAVE_SIZE="4"; python deploy_lambdas_demo2.py
        "DRAFT_WAVE_SIZE": os.environ.get("DRAFT_WAVE_SIZE", "1"),
    }.items() if v != ""
}

_RESEARCH_INCLUDES = ["core", "knowledge_base", "templates"]
_RESEARCH_EXTRA = [
    "agents/master_researcher/researcher_planner.py",
    "agents/master_researcher/researcher_file_processor.py",
    "agents/master_researcher/researcher_kb.py",
    "agents/master_researcher/researcher_web.py",
    "agents/master_researcher/researcher_user_sources.py",
    "agents/master_researcher/researcher_curated.py",
    "agents/master_researcher/researcher_synthesis.py",
    "agents/master_researcher/researcher_reresearch.py",
]


def _research_stage(name, source_file):
    return {
        "name": name,
        "folder": "agents/master_researcher",
        "handler": "handler.py",
        "source_file": source_file,
        "includes": _RESEARCH_INCLUDES,
        "extra_modules": _RESEARCH_EXTRA,
        "inherit_from": INHERIT_RESEARCH,
    }


_DRAFT_INCLUDES = ["core", "knowledge_base", "templates"]
# The three drafter stage handlers import their standalone stage module + core.drafter_common.
# No stage depends on handler_drafter_new.py (the monolith) anymore.
_DRAFT_EXTRA = [
    "agents/master_drafter/drafter_planner.py",
    "agents/master_drafter/drafter_generator.py",
    "agents/master_drafter/drafter_assembler.py",
    "agents/master_drafter/drafter_redraft.py",
]


def _draft_stage(name, source_file):
    return {
        "name": name,
        "folder": "agents/master_drafter",
        "handler": "handler.py",
        "source_file": source_file,
        "includes": _DRAFT_INCLUDES,
        "extra_modules": _DRAFT_EXTRA,
        "inherit_from": INHERIT_DRAFTER,
    }


# Names MUST match infrastructure/step_functions_definition_client_demo2.json
LAMBDAS = [
    {
        "name": "pmi-input-validator-client-demo2",
        "folder": "agents/input_validator",
        "handler": "handler.py",
        "source_file": "handler_new_validator.py",
        "inherit_from": INHERIT_VALIDATOR,
        "includes": ["core"],
    },
    _research_stage("pmi-research-planner-client-demo2",       "handler_planner.py"),
    _research_stage("pmi-research-file-processor-client-demo2", "handler_file_processor.py"),
    _research_stage("pmi-research-kb-search-client-demo2",     "handler_kb_search.py"),
    _research_stage("pmi-research-web-search-client-demo2",    "handler_web_search.py"),
    _research_stage("pmi-research-user-sources-client-demo2",  "handler_user_sources.py"),
    _research_stage("pmi-research-curated-links-client-demo2", "handler_curated_links.py"),
    _research_stage("pmi-research-synthesis-client-demo2",     "handler_synthesis.py"),
    _research_stage("pmi-research-reresearch-client-demo2",    "handler_reresearch.py"),
    # ── HITL Research Gate (creates checkpoint, pauses SF until user decision) ──
    {
        "name": "pmi-hitl-gate-client-demo2",
        "folder": "agents/hitl_research_gate",
        "handler": "handler.py",
        "source_file": "handler.py",
        "inherit_from": INHERIT_RESEARCH,
    },
    # NOTE: the monolith drafter (handler_drafter_new.py / pmi-master-drafter-client-demo2)
    # is intentionally NOT deployed. The demo2 pipeline uses only the three split stages
    # below. handler_drafter_new.py is kept in the repo purely as a reference/fallback and
    # is never bundled into any Lambda.
    # ── Drafter split stages (plan -> generate -> assemble) ──────────────────
    # Thin handlers that import their standalone stage module (drafter_planner /
    # drafter_generator / drafter_assembler) + core.drafter_common. No dependency on the
    # monolith handler_drafter_new.py. Sequential generation is preserved inside the
    # generator. Only the assembler writes the .docx + DRAFTING_COMPLETED.
    _draft_stage("pmi-draft-planner-client-demo2",   "handler_draft_planner.py"),
    _draft_stage("pmi-draft-generator-client-demo2", "handler_draft_generator.py"),
    _draft_stage("pmi-draft-assembler-client-demo2", "handler_draft_assembler.py"),
    _draft_stage("pmi-draft-redraft-client-demo2",   "handler_redraft.py"),
]


def _fetch_source_config(source_fn):
    """Fetch role + timeout + memory + env + VpcConfig from a demo1 source Lambda so the
    demo2 function can mirror it (incl. VPC so LiteLLM/Tavily calls reach the private
    gateway). Returns a dict or None on failure."""
    try:
        cfg_raw = subprocess.run(
            ["aws", "lambda", "get-function-configuration",
             "--function-name", source_fn, "--output", "json", "--region", REGION],
            capture_output=True, text=True, check=True
        ).stdout
        cfg = json.loads(cfg_raw)
    except (subprocess.CalledProcessError, ValueError) as e:
        print(f"WARN: could not read config from {source_fn}: {e}")
        return None
    env = dict(cfg.get("Environment", {}).get("Variables", {}))
    env.pop("USE_SPLIT_RESEARCH", None)  # demo2 stages are orchestrated by Step Functions
    env.update(DEMO2_ENV_OVERLAY)        # demo2-only flags (e.g. PROMPT_MGMT_ENABLED); survives re-sync
    vpc = cfg.get("VpcConfig") or {}
    vpc_json = None
    if vpc.get("SubnetIds") and vpc.get("SecurityGroupIds"):
        vpc_json = json.dumps({
            "SubnetIds": vpc["SubnetIds"],
            "SecurityGroupIds": vpc["SecurityGroupIds"],
        })
    return {
        "role": cfg.get("Role"),
        "timeout": str(cfg.get("Timeout", 900)),
        "memory": str(cfg.get("MemorySize", 1024)),
        "env_json": json.dumps({"Variables": env}),
        "vpc_json": vpc_json,
    }


def _wait_updated(fn):
    """Block until a Lambda finishes its in-progress update (so chained config calls don't 409)."""
    subprocess.run(
        ["aws", "lambda", "wait", "function-updated", "--function-name", fn, "--region", REGION],
        capture_output=True
    )


def _sync_config(fn, source_fn):
    """After a code update, re-sync env + timeout + memory + VPC from the demo1 source
    so config never drifts (idempotent)."""
    src = _fetch_source_config(source_fn)
    if not src:
        return
    _wait_updated(fn)
    cmd = [
        "aws", "lambda", "update-function-configuration",
        "--function-name", fn,
        "--handler", "handler.lambda_handler",
        "--timeout", src["timeout"],
        "--memory-size", src["memory"],
        "--environment", src["env_json"],
        "--region", REGION,
    ]
    if src["vpc_json"]:
        cmd += ["--vpc-config", src["vpc_json"]]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"  synced config from {source_fn} (timeout={src['timeout']}s, vpc={'yes' if src['vpc_json'] else 'no'})")
    except subprocess.CalledProcessError as e:
        msg = e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e)
        print(f"WARN: config sync for {fn} failed: {msg}")


def _package(l, zip_name):
    """Build the deployment zip for a single lambda entry."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Copy handler (source_file -> handler.py)
        handler_file = l.get('source_file', l['handler'])
        handler_path = os.path.join(l['folder'], handler_file)
        if os.path.exists(handler_path):
            shutil.copy2(handler_path, os.path.join(temp_dir, l['handler']))

        # Copy include dirs (core / knowledge_base / templates)
        for inc in l.get("includes", []):
            if os.path.exists(inc):
                shutil.copytree(inc, os.path.join(temp_dir, os.path.basename(inc)), dirs_exist_ok=True)

        # Copy extra sibling modules to the package root (shared handler_new_advanced.py)
        for mod in l.get("extra_modules", []):
            if os.path.exists(mod):
                shutil.copy2(mod, os.path.join(temp_dir, os.path.basename(mod)))
            else:
                print(f"WARN: extra_module not found, skipping: {mod}")

        # Hot-swap the new prompt registry into place if core is included
        registry_new_path = os.path.join(temp_dir, "core", "prompt_registry_new.py")
        registry_target_path = os.path.join(temp_dir, "core", "prompt_registry.py")
        if os.path.exists(registry_new_path):
            shutil.copy2(registry_new_path, registry_target_path)

        # Install dependencies if requirements.txt exists (e.g. pydantic for the validator)
        req_path = os.path.join(l['folder'], "requirements.txt")
        if os.path.exists(req_path):
            print(f"Downloading dependencies for {l['name']}...")
            pkg_dir = os.path.join(temp_dir, "_pkg")
            os.makedirs(pkg_dir)
            subprocess.run([
                "pip", "download", "-r", req_path, "-d", pkg_dir,
                "--platform", "manylinux2014_x86_64",
                "--python-version", "3.10",
                "--only-binary=:all:"
            ], check=True, capture_output=True)
            for wheel_file in glob.glob(os.path.join(pkg_dir, "*.whl")):
                with zipfile.ZipFile(wheel_file, 'r') as w:
                    w.extractall(temp_dir)
            shutil.rmtree(pkg_dir)

        # Create zip
        with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(temp_dir):
                if "__pycache__" in root:
                    continue
                for file in files:
                    if file.endswith(".pyc"):
                        continue
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, temp_dir)
                    zf.write(file_path, arcname)


def deploy(target=None):
    lambdas_to_deploy = LAMBDAS
    if target:
        lambdas_to_deploy = [l for l in LAMBDAS if l['name'] == target]
        if not lambdas_to_deploy:
            valid = [l['name'] for l in LAMBDAS]
            print(f"Unknown function '{target}'. Valid options are:\n  " + "\n  ".join(valid))
            return

    for l in lambdas_to_deploy:
        zip_name = f"{l['name']}.zip"
        print(f"Packaging {l['name']}...")
        _package(l, zip_name)
        print(f"Deploying {l['name']} to AWS...")

        try:
            result = subprocess.run(
                ["aws", "lambda", "get-function", "--function-name", l['name'], "--region", REGION],
                capture_output=True
            )

            if result.returncode == 0:
                # Update existing code, then re-sync config from the demo1 source
                subprocess.run(
                    ["aws", "lambda", "update-function-code",
                     "--function-name", l['name'],
                     "--zip-file", f"fileb://{zip_name}",
                     "--region", REGION],
                    check=True, capture_output=True
                )
                print(f"Successfully updated {l['name']}")
                if l.get("inherit_from"):
                    _sync_config(l['name'], l["inherit_from"])
                print()
            else:
                # Create new function, inheriting full config from the demo1 source
                print(f"Function {l['name']} does not exist. Creating it...")
                src = _fetch_source_config(l.get("inherit_from", ""))
                if not src or not src.get("role"):
                    print(f"ERROR: cannot create {l['name']} without inheritable config from "
                          f"{l.get('inherit_from')}. Skipping.\n")
                    if os.path.exists(zip_name):
                        os.remove(zip_name)
                    continue
                create_cmd = [
                    "aws", "lambda", "create-function",
                    "--function-name", l['name'],
                    "--runtime", "python3.10",
                    "--role", src["role"],
                    "--handler", "handler.lambda_handler",
                    "--zip-file", f"fileb://{zip_name}",
                    "--timeout", src["timeout"],
                    "--memory-size", src["memory"],
                    "--environment", src["env_json"],
                    "--region", REGION,
                ]
                if src["vpc_json"]:
                    create_cmd += ["--vpc-config", src["vpc_json"]]
                print(f"  inheriting config from {l['inherit_from']}: timeout={src['timeout']}s "
                      f"memory={src['memory']}MB vpc={'yes' if src['vpc_json'] else 'no'}")
                try:
                    subprocess.run(create_cmd, check=True, capture_output=True)
                    print(f"Successfully created {l['name']}\n")
                except subprocess.CalledProcessError as e:
                    msg = e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e)
                    print(f"Failed to create {l['name']}: {msg}\n")

        except subprocess.CalledProcessError as e:
            msg = e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e)
            print(f"Failed to deploy {l['name']}: {msg}\n")

        if os.path.exists(zip_name):
            os.remove(zip_name)


def _demo2_function_arns():
    """ARNs (and :* qualified variants) of all 8 demo2 functions for the SFN invoke policy."""
    arns = []
    for l in LAMBDAS:
        base = f"arn:aws:lambda:{REGION}:{ACCOUNT_ID}:function:{l['name']}"
        arns.append(base)
        arns.append(base + ":*")
    return arns


def setup_sfn_role(state_machine):
    """Ensure the demo2 Step Functions execution role can invoke the 8 demo2 lambdas.

    Looks up the state machine's execution role, checks for the inline policy
    'pmi-demo2-sfn-invoke', and creates/updates it with lambda:InvokeFunction on the 8
    demo2 functions if missing. Idempotent. `state_machine` may be a name or a full ARN.
    """
    sm_arn = state_machine
    if not state_machine.startswith("arn:aws:states:"):
        sm_arn = f"arn:aws:states:{REGION}:{ACCOUNT_ID}:stateMachine:{state_machine}"

    # 1. Resolve the execution role from the state machine
    try:
        desc = json.loads(subprocess.run(
            ["aws", "stepfunctions", "describe-state-machine",
             "--state-machine-arn", sm_arn, "--output", "json", "--region", REGION],
            capture_output=True, text=True, check=True
        ).stdout)
    except subprocess.CalledProcessError as e:
        msg = e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e)
        print(f"ERROR: could not describe state machine '{sm_arn}': {msg}")
        print("  Create/deploy the demo2 state machine first, then re-run --setup-sfn-role.")
        return

    role_arn = desc.get("roleArn", "")
    role_name = role_arn.split("/")[-1]
    if not role_name:
        print(f"ERROR: state machine has no roleArn: {sm_arn}")
        return
    print(f"State machine role: {role_name}")

    policy_name = "pmi-demo2-sfn-invoke"

    # 2. Check whether the inline policy already exists
    existing = subprocess.run(
        ["aws", "iam", "get-role-policy",
         "--role-name", role_name, "--policy-name", policy_name, "--output", "json"],
        capture_output=True, text=True
    )
    if existing.returncode == 0:
        print(f"  inline policy '{policy_name}' already exists — refreshing it to cover all 8 demo2 functions.")
    else:
        print(f"  inline policy '{policy_name}' not found — creating it.")

    # 3. Put (create or refresh) the policy — idempotent
    policy_doc = json.dumps({
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": "lambda:InvokeFunction",
            "Resource": _demo2_function_arns(),
        }],
    })
    try:
        subprocess.run(
            ["aws", "iam", "put-role-policy",
             "--role-name", role_name,
             "--policy-name", policy_name,
             "--policy-document", policy_doc],
            check=True, capture_output=True
        )
        print(f"  OK: '{policy_name}' attached to {role_name} (lambda:InvokeFunction on 8 demo2 functions)")
    except subprocess.CalledProcessError as e:
        msg = e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e)
        print(f"ERROR: failed to put invoke policy: {msg}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Deploy the client-demo2 split-research pipeline.")
    parser.add_argument(
        "--function", "-f",
        metavar="FUNCTION_NAME",
        help="Deploy a single demo2 Lambda by name. Omit to deploy all 8.",
        default=None
    )
    parser.add_argument(
        "--setup-sfn-role",
        metavar="STATE_MACHINE",
        help="Ensure the demo2 Step Functions execution role can invoke the 8 demo2 lambdas. "
             "Pass the state machine name or full ARN. Does not deploy lambdas.",
        default=None
    )
    parser.add_argument(
        "--inherit-research",
        metavar="SOURCE_FN",
        help=f"Override the demo1 source the research stages inherit env/VPC from "
             f"(default: {INHERIT_RESEARCH}).",
        default=None
    )
    args = parser.parse_args()

    if args.setup_sfn_role:
        setup_sfn_role(args.setup_sfn_role)
        sys.exit(0)

    if args.inherit_research:
        for _l in LAMBDAS:
            if _l["folder"] == "agents/master_researcher":
                _l["inherit_from"] = args.inherit_research
        print(f"Research stages will inherit from: {args.inherit_research}")

    deploy(target=args.function)
