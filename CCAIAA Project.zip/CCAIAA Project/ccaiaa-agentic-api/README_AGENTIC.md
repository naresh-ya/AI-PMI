# PMI Agentic AI Platform - Enhanced Architecture

A **true Agentic AI system** with **Human-in-the-Loop (HITL)** capabilities for generating compliant government submissions.

## 🤖 Agentic Architecture Overview

### **What Makes This "Agentic"**
- Each AI agent has **system prompts** that define its role, expertise, and decision-making capabilities
- **Human-in-the-Loop** integration at every critical decision point (except Input Validator)
- Agents make **intelligent decisions** using AI reasoning, not just rule-based logic
- **Collaborative workflow** where humans and AI work together seamlessly

### **Agent Hierarchy & System Prompts**

#### 1. **Input Validator Agent** (AI Only)
- **System Prompt**: Regulatory compliance expert and gatekeeper
- **AI Capabilities**: Uses Claude 3.5 Sonnet for intelligent validation
- **Role**: Validates completeness, assesses feasibility, identifies compliance risks
- **No HITL**: Fully automated for efficiency

#### 2. **Master Researcher Agent** (AI + Human Collaboration)
- **System Prompt**: Expert research strategist and information analyst
- **AI Capabilities**: Designs comprehensive research strategies
- **HITL Integration**: 
  - Creates research strategy → Human approval required
  - Executes research → AI synthesis with human oversight
- **Human Touchpoints**: Research strategy approval, sensitive source access

#### 3. **Master Drafter Agent** (AI + Human Collaboration)  
- **System Prompt**: Government relations writer and policy communication specialist
- **AI Capabilities**: Transforms research into compliant documents
- **HITL Integration**:
  - Document outline → Human approval
  - Draft sections → Human review checkpoints
  - Final document → Human approval before review
- **Human Touchpoints**: Content strategy, sensitive messaging, final approval

#### 4. **Master Reviewer Agent** (AI + Human Collaboration)
- **System Prompt**: Senior compliance officer and quality assurance specialist
- **AI Capabilities**: Comprehensive compliance and quality review
- **HITL Integration**:
  - Risk assessment → Human validation
  - Final approval → Human sign-off required
- **Human Touchpoints**: High-risk content approval, final authorization

## 🔄 Human-in-the-Loop Workflow

### **HITL Trigger Points**
```
Input Validator → Master Researcher (Strategy Approval) → 
Master Drafter (Content Approval) → Master Reviewer (Final Sign-off)
```

### **Human Intervention Types**
- **Approval Required**: Strategy/content needs human approval before proceeding
- **Review Requested**: AI requests human expertise on specific issues
- **Expert Consultation**: Complex topics requiring human subject matter expert
- **Escalation**: High-risk or time-critical decisions
- **Quality Gate**: Mandatory checkpoints for compliance/quality

### **HITL Dashboard Features**
- Real-time pending reviews by priority (Urgent/High/Medium/Low)
- Agent-specific review guidelines and criteria
- Time tracking with escalation alerts
- Historical decision audit trail
- Expert recommendation system

## 🧠 System Prompt Architecture

### **Input Validator System Prompt**
```
Role: Gatekeeper for all document generation requests
Expertise: Regulatory compliance, document requirements, feasibility assessment
Domain: Tobacco/nicotine product regulations (FCTC, COTPA, FDA)
Constraints: Never approve non-compliant requests, prioritize quality over speed
```

### **Master Researcher System Prompt**
```
Role: Expert research strategist and information analyst  
Expertise: Tobacco/nicotine regulation, policy analysis, government relations
Methodology: Multi-source triangulation, evidence quality assessment
Human Collaboration: Present strategies for approval, flag sensitive areas
```

### **Master Drafter System Prompt**
```
Role: Government relations writer and policy communication specialist
Expertise: Compliant, persuasive government submissions
Compliance: No promotional language, FCTC-compliant messaging
Human Collaboration: Outline approval, sensitive content review
```

### **Master Reviewer System Prompt**
```
Role: Senior compliance officer and quality assurance specialist
Expertise: Regulatory compliance, risk assessment, document quality
Standards: Executive-level presentation, zero compliance violations
Human Collaboration: Risk validation, final authorization
```

## 🔧 Technical Implementation

### **Enhanced Agent Architecture**
```python
# Each agent follows this pattern:
1. System prompt defines role and expertise
2. AI reasoning for decision-making
3. HITL checkpoints for human collaboration
4. Structured feedback integration
5. Workflow continuation based on human decisions
```

### **HITL Manager Features**
- **Checkpoint Creation**: Creates review points with priority and timeout
- **Notification System**: SNS/Email alerts for pending reviews
- **Decision Processing**: Handles approve/reject/revise decisions
- **Workflow Integration**: Continues or redirects based on human input
- **Audit Trail**: Complete history of human-AI collaboration

### **Infrastructure Updates**
- **New DynamoDB Table**: `pmi-agentic-ai-hitl` for human interactions
- **Enhanced IAM Roles**: Permissions for SNS notifications and SES emails
- **API Gateway Endpoints**: HITL web interface for human reviewers
- **Step Functions**: Orchestrates human-AI workflow transitions

## 🚀 Deployment & Usage

### **1. Deploy Enhanced Backend**
```powershell
cd pmi-agentic-ai-backend
.\deploy.ps1
```

### **2. Configure Human Reviewers**
```json
{
  "master_researcher": ["research.lead@pmi.com", "regulatory.expert@pmi.com"],
  "master_drafter": ["content.lead@pmi.com", "legal.counsel@pmi.com"], 
  "master_reviewer": ["compliance.head@pmi.com", "senior.director@pmi.com"]
}
```

### **3. Access HITL Dashboard**
- **URL**: `https://api-gateway-url/hitl/dashboard`
- **Authentication**: IAM/Cognito integration
- **Features**: Pending reviews, priority filtering, decision submission

## 🎯 Agentic Benefits

### **1. Intelligent Decision Making**
- AI agents use reasoning, not just rules
- Context-aware recommendations
- Adaptive strategies based on content complexity

### **2. Human-AI Collaboration**
- Humans provide expertise where AI needs guidance
- AI handles routine tasks, humans focus on critical decisions
- Seamless handoffs between human and AI work

### **3. Quality Assurance**
- Multiple review checkpoints with human oversight
- AI-powered compliance checking with human validation
- Audit trail for all decisions and modifications

### **4. Scalability with Control**
- AI handles high-volume processing
- Human oversight ensures quality and compliance
- Configurable approval thresholds

## 📊 HITL Metrics & Monitoring

### **Dashboard KPIs**
- Pending reviews by agent and priority
- Average human review time
- Approval/rejection rates
- Quality scores post-human review
- Escalation frequency

### **Quality Metrics**
- Human satisfaction with AI recommendations
- Accuracy of AI risk assessments
- Compliance violation prevention
- Time savings vs manual process

## 🔒 Security & Compliance

### **Access Control**
- Role-based access to HITL dashboard
- Audit logging of all human decisions
- Encrypted storage of sensitive feedback

### **Compliance Features**
- Mandatory human approval for high-risk content
- Regulatory compliance checkpoints
- Evidence trail for all document approvals

This enhanced agentic architecture ensures that AI capabilities are augmented with human expertise, creating a collaborative system that maintains quality while scaling efficiently.

## 🔄 Future Enhancements

- **Sub-Agent Implementation**: Domain-specific agents under each master agent
- **Learning Feedback Loop**: AI learns from human decisions to improve recommendations
- **Advanced Analytics**: Predictive compliance risk scoring
- **Multi-Language Support**: Expand to non-English regulatory environments
