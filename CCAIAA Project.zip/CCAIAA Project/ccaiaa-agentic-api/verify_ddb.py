import boto3
dynamodb = boto3.resource('dynamodb', region_name='eu-west-1')
table = dynamodb.Table('pmi-agentic-ai-requests')
item = table.get_item(Key={'request_id': 'req_20260710072721_a0e604d1'}).get('Item', {})
ro = item.get('research_output', {})
citations = ro.get('citations', [])
sources = ro.get('sources', [])
print(f"citations count: {len(citations)}")
print(f"sources count: {len(sources)}")
if citations:
    print(f"first citation title: {citations[0].get('title', '')}")
