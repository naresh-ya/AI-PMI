"""
HITL Research Gate Lambda — PMI Agentic AI Platform

Invoked by Step Functions with .waitForTaskToken after ResearchTask.
Responsibilities:
  1. Persist the Step Functions task token to DynamoDB (needed by callback to resume)
  2. Create a HITL checkpoint record in pmi-agentic-ai-hitl
  3. Notify the request owner that sources are ready for review
  4. Return immediately — Step Function stays paused until callback calls send_task_success

No auto-approval or timeout escalation — the pipeline waits until the user
explicitly submits a decision via the callback API.
"""

from decimal import Decimal
import json
import logging
import os
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb      = boto3.resource('dynamodb')
sns_client    = boto3.client('sns')

requests_table = dynamodb.Table(os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests'))
hitl_table     = dynamodb.Table(os.environ.get('HITL_TABLE',     'pmi-agentic-ai-hitl'))
SNS_TOPIC_ARN  = os.environ.get('HITL_SNS_TOPIC_ARN', '')

_NOW = lambda: datetime.now(timezone.utc).isoformat()


# ── Entry point ────────────────────────────────────────────────────────────────

def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    """Store task token, create HITL checkpoint, and notify the request owner.
    The Step Function waits indefinitely until the user submits a decision
    via the callback API — no auto-approval or timeout escalation.
    Supports both research mode and draft mode (detected by 'draft_result' in event).
    """
    task_token        = str(event.get('task_token') or '')
    request_id        = str(event.get('request_id') or 'unknown')

    # ── Mode detection: draft HITL vs research HITL ──────────────────────────
    is_draft_mode = 'draft_result' in event

    if is_draft_mode:
        # Draft HITL: user reviews the generated document
        agent_name = 'master_drafter'
        status_pending = 'DRAFT_REVIEW_PENDING'
        hitl_retry_count = int(event.get('hitl_draft_retry_count') or 0)
        _validation_raw = event.get('validation_result', {})
        validation_output = _validation_raw.get('output', _validation_raw) if isinstance(_validation_raw, dict) else {}
        doc_requirements = validation_output.get('document_requirements', {})
        topic = doc_requirements.get('topic', '')
        user_id = doc_requirements.get('user_id', 'anonymous')
        # For draft mode, store document metadata as "sources" for the checkpoint
        draft_result = event.get('draft_result', {})
        sources = _extract_draft_sections_for_review(draft_result)
    else:
        # Research HITL: user reviews research sources
        agent_name = 'master_researcher'
        status_pending = 'RESEARCH_REVIEW_PENDING'
        hitl_retry_count = int(event.get('hitl_retry_count') or 0)
        _research_raw = event.get('research_result', {})
        research_output = _research_raw.get('output', _research_raw) if isinstance(_research_raw, dict) else {}
        _validation_raw = event.get('validation_result', {})
        validation_output = _validation_raw.get('output', _validation_raw) if isinstance(_validation_raw, dict) else {}
        doc_requirements = validation_output.get('document_requirements', {})
        topic = doc_requirements.get('topic', '')
        user_id = doc_requirements.get('user_id', 'anonymous')
        sources = research_output.get('sources', [])

    # 1. Store task token so the callback Lambda can resume the Step Function
    _store_task_token(request_id, task_token, hitl_retry_count)

    # 2. Create HITL checkpoint record
    langsmith_headers = event.get('langsmith_headers', {})
    hitl_id = _create_hitl_checkpoint(
        request_id, user_id, topic, sources, hitl_retry_count, task_token,
        agent_name=agent_name, langsmith_headers=langsmith_headers
    )

    # 3. Set request status
    _update_request_status(request_id, status_pending, hitl_id)

    # 4. Notify the request owner (skip for draft mode for now)
    if not is_draft_mode:
        _notify_user(user_id, request_id, hitl_id, topic, len(sources))

    logger.info(
        f"HITL_GATE | mode={'draft' if is_draft_mode else 'research'} "
        f"| request_id={request_id} | hitl_id={hitl_id} "
        f"| sources={len(sources)} | retry={hitl_retry_count}"
    )

    # Lambda returns here. Step Function remains paused — it resumes only when
    # the callback Lambda calls sfn.send_task_success with the stored token.
    return {
        'hitl_id':      hitl_id,
        'request_id':   request_id,
        'status':       'RESEARCH_REVIEW_PENDING',
        'source_count': len(sources),
        # Passthrough relay only — this gate is intentionally NOT instrumented
        # with LangSmith tracing (no LLM calls here to measure), but the
        # research <-> draft trace still routes through it in the state
        # machine, so the propagated header must be relayed unchanged or the
        # trace breaks into two disconnected halves at this hop. See
        # core/langsmith_tracing/tracing_helpers.py for the convention.
        'langsmith_headers': event.get('langsmith_headers', {}),
    }


# ── Helpers ────────────────────────────────────────────────────────────────────

def _store_task_token(request_id: str, task_token: str, retry_count: int) -> None:
    """Persist the Step Functions task token — callback Lambda reads this to resume."""
    requests_table.update_item(
        Key={'request_id': request_id},
        UpdateExpression='SET hitl_task_token = :token, hitl_retry_count = :rc, updated_at = :ts',
        ExpressionAttributeValues={
            ':token': task_token,
            ':rc':    retry_count,
            ':ts':    _NOW(),
        },
    )


def _float_to_decimal(obj: Any) -> Any:
    """Recursively convert float values to Decimal for DynamoDB compatibility."""
    if isinstance(obj, float):
        return Decimal(str(obj))
    if isinstance(obj, dict):
        return {k: _float_to_decimal(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_float_to_decimal(i) for i in obj]
    return obj


def _create_hitl_checkpoint(
    request_id: str,
    user_id: str,
    topic: str,
    sources: List[Dict],
    retry_count: int,
    task_token: str = '',
    agent_name: str = 'master_researcher',
    langsmith_headers: Dict = None,
) -> str:
    """Write a HITL record to pmi-agentic-ai-hitl and return its ID."""
    if langsmith_headers is None:
        langsmith_headers = {}
    
    now     = datetime.now(timezone.utc)
    prefix  = 'hitl_draft' if agent_name == 'master_drafter' else 'hitl'
    hitl_id = f"{prefix}_{request_id}_{agent_name}_{int(now.timestamp())}"

    hitl_table.put_item(Item={
        'hitl_id':        hitl_id,
        'request_id':     request_id,
        'agent_name':     agent_name,
        'status':         'pending',
        'created_at':     now.isoformat(),
        'topic':          topic,
        'user_id':        user_id,
        'retry_count':    retry_count,
        'task_token':     task_token,
        # Full structured source list — each entry has source_id, title, source_type,
        # relevance_score, url, summary, reason (built by build_structured_sources)
        'sources':        _float_to_decimal(sources),
        # Lightweight counts surfaced in the review UI
        'source_summary': {
            'total':          len(sources),
            'knowledge_base': sum(1 for s in sources if s.get('source_type') == 'knowledge_base'),
            'web_search':     sum(1 for s in sources if s.get('source_type') == 'web_search'),
            'external_url':   sum(1 for s in sources if s.get('source_type') == 'external_url'),
            'internal_url':   sum(1 for s in sources if s.get('source_type') == 'internal_url'),
            'uploaded_file':  sum(1 for s in sources if s.get('source_type') == 'uploaded_file'),
        },
        'human_decision':    None,
        'human_feedback':    None,
        'removed_source_ids': [],
        'completed_at':      None,
        'completed_by':      None,
        'langsmith_headers': langsmith_headers,  # Store for tracing continuity
    })
    return hitl_id


def _update_request_status(
    request_id: str, status: str, hitl_id: Optional[str]
) -> None:
    expr   = 'SET #s = :s, updated_at = :ts'
    names  = {'#s': 'status'}
    values: Dict[str, Any] = {':s': status, ':ts': _NOW()}

    if hitl_id:
        expr        += ', current_hitl_id = :hid'
        values[':hid'] = hitl_id

    requests_table.update_item(
        Key={'request_id': request_id},
        UpdateExpression=expr,
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=values,
    )


def _notify_user(
    user_id: str, request_id: str, hitl_id: str, topic: str, source_count: int
) -> None:
    """Publish an SNS notification so the frontend/email can alert the user."""
    if not SNS_TOPIC_ARN:
        logger.warning("HITL_SNS_TOPIC_ARN not set — skipping notification")
        return

    message = {
        'event':        'RESEARCH_REVIEW_PENDING',
        'request_id':   request_id,
        'hitl_id':      hitl_id,
        'user_id':      user_id,
        'topic':        topic,
        'source_count': source_count,
        'message': (
            f"Your research for '{topic}' is ready for review. "
            f"{source_count} sources were found. "
            f"Please review and approve or revise them to proceed to drafting."
        ),
        'review_url': f"/requests/{request_id}/hitl/{hitl_id}",
        'timestamp':  _NOW(),
    }

    try:
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps(message),
            Subject='PMI Agentic AI — Research Review Required',
            MessageAttributes={
                'user_id': {'DataType': 'String', 'StringValue': user_id},
                'event':   {'DataType': 'String', 'StringValue': 'RESEARCH_REVIEW_PENDING'},
            },
        )
        logger.info(f"HITL_NOTIFY | user_id={user_id} | hitl_id={hitl_id}")
    except Exception as e:
        logger.error(f"SNS notification failed (non-fatal): {e}")


def _extract_draft_sections_for_review(draft_result: Dict[str, Any]) -> List[Dict]:
    """Convert draft_result into a reviewable section list for the Draft HITL UI.
    Extracts section titles, word counts, and content previews from the draft output."""
    sections = []
    doc_meta = draft_result.get('document_metadata', {})
    doc_summary = draft_result.get('document_summary', {})

    # The draft_result contains document_s3_key, quality_metrics, etc.
    # Build a lightweight section summary for the review UI
    sections.append({
        'source_id': 'draft_001',
        'title': doc_summary.get('title', 'Generated Document'),
        'source_type': 'document',
        'relevance_score': 1.0,
        'url': '',
        'summary': (
            f"Word count: {doc_meta.get('word_count', 'N/A')} | "
            f"Sections: {doc_meta.get('sections', 'N/A')} | "
            f"Citations: {doc_meta.get('citations', 'N/A')} | "
            f"Confidence: {doc_meta.get('confidence_score', 'N/A')}"
        ),
    })

    return sections
