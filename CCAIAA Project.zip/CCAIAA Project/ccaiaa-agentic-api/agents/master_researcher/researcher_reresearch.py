"""
Intelligent Re-Research Module (fully standalone).

Provides: handle_reresearch(), analyze_reresearch_intent(), conduct_selective_research()

Uses Option C architecture: imports stage modules directly (stage_kb, stage_web,
stage_user_sources, stage_curated) and calls them in-process. This avoids
Lambda-to-Lambda invocation overhead and mirrors how stages are bundled.

Uses Haiku for intent classification (cheap, fast, sufficient for JSON classification).
Falls back to full pipeline if confidence < threshold or on any failure.
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from datetime import datetime
from typing import Dict, Any, List

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    LLM_MODEL_FAST, DOCUMENT_BUCKET,
    _llm_call_json, _estimate_tokens,
    get_s3_client, get_dynamodb_resource,
)

# Import stage modules directly (Option C — all bundled via _RESEARCH_EXTRA)
try:
    import researcher_kb as kb_mod
    import researcher_web as web_mod
    import researcher_user_sources as user_sources_mod
    import researcher_curated as curated_mod
    import researcher_synthesis as synthesis_mod
except ImportError:
    from agents.master_researcher import researcher_kb as kb_mod
    from agents.master_researcher import researcher_web as web_mod
    from agents.master_researcher import researcher_user_sources as user_sources_mod
    from agents.master_researcher import researcher_curated as curated_mod
    from agents.master_researcher import researcher_synthesis as synthesis_mod


# ── Configuration ─────────────────────────────────────────────────────────────
ENABLE_SELECTIVE_RERESEARCH = os.environ.get('ENABLE_SELECTIVE_RERESEARCH', 'true').lower() == 'true'
RERESEARCH_INTENT_CONFIDENCE_THRESHOLD = float(os.environ.get('RERESEARCH_INTENT_CONFIDENCE_THRESHOLD', '0.7'))
RERESEARCH_MAX_RETRIES = int(os.environ.get('RERESEARCH_MAX_RETRIES', '3'))

VALID_STAGES = {'kb_search', 'web_search', 'user_sources', 'curated_links'}


# ═══════════════════════════════════════════════════════════════════════════════
# Public Entry Point
# ═══════════════════════════════════════════════════════════════════════════════

def handle_reresearch(event: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Main entry point for intelligent re-research.

    Called by the handler when HITL decision is 'revise'. Analyzes feedback,
    selectively re-runs required stages, merges with approved sources, and
    returns a research_summary in the same shape as the initial synthesis output.

    Args:
        event: Contains human_feedback, approved_sources, removed_source_ids,
               requirements (document_requirements), hitl_retry_count
        request_id: Request identifier

    Returns:
        research_summary (same shape as synthesis_output — compatible with DraftPlanner)
    """
    human_feedback = (event.get('human_feedback') or '').strip()
    approved_sources = event.get('approved_sources') or []
    removed_source_ids = event.get('removed_source_ids') or []
    hitl_retry_count = int(event.get('hitl_retry_count') or 0)
    requirements = event.get('requirements') or {}

    logger.info(
        f"[{request_id}] RE_RESEARCH | feedback='{human_feedback[:100]}' "
        f"| approved={len(approved_sources)} | removed={len(removed_source_ids)} "
        f"| retry={hitl_retry_count}"
    )

    # Safety: max retries
    if hitl_retry_count >= RERESEARCH_MAX_RETRIES:
        logger.warning(f"[{request_id}] Max re-research retries ({RERESEARCH_MAX_RETRIES}) reached, using full pipeline")
        return _full_pipeline(requirements, request_id, approved_sources, removed_source_ids)

    # Feature flag check
    if not ENABLE_SELECTIVE_RERESEARCH:
        logger.info(f"[{request_id}] Selective re-research disabled, using full pipeline")
        return _full_pipeline(requirements, request_id, approved_sources, removed_source_ids)

    # Inject feedback into requirements for downstream context
    requirements['re_research_feedback'] = human_feedback

    # Fix 4: Parse URLs from feedback and inject as external_links
    feedback_urls = _extract_urls_from_feedback(human_feedback)
    if feedback_urls:
        logger.info(f"[{request_id}] RE_RESEARCH | parsed {len(feedback_urls)} URLs from feedback: {feedback_urls}")
        existing_links = requirements.get('external_links', []) or []
        requirements['external_links'] = existing_links + feedback_urls

    # Analyze intent
    intent = analyze_reresearch_intent(
        human_feedback=human_feedback,
        approved_sources=approved_sources,
        removed_source_ids=removed_source_ids,
        document_requirements=requirements,
        request_id=request_id,
    )

    # Fix 4 continued: force user_sources stage if URLs were found in feedback
    if feedback_urls and 'user_sources' not in intent['required_stages']:
        intent['required_stages'].append('user_sources')
        logger.info(f"[{request_id}] RE_RESEARCH | forcing user_sources stage for feedback URLs")

    logger.info(
        f"[{request_id}] INTENT | required={intent['required_stages']} "
        f"| confidence={intent['confidence']:.2f} "
        f"| reasoning='{intent['reasoning'][:100]}'"
    )

    # Decision: selective vs full pipeline
    if intent['confidence'] >= RERESEARCH_INTENT_CONFIDENCE_THRESHOLD:
        # Inject LLM-refined queries if available
        if intent.get('new_queries'):
            requirements['_planned_queries'] = intent['new_queries']

        research_results = conduct_selective_research(
            document_requirements=requirements,
            request_id=request_id,
            required_stages=intent['required_stages'],
            approved_sources=approved_sources,
            removed_source_ids=removed_source_ids,
        )
        logger.info(f"[{request_id}] Selective re-research completed, stages={intent['required_stages']}")
    else:
        logger.warning(
            f"[{request_id}] Intent confidence {intent['confidence']:.2f} "
            f"< threshold {RERESEARCH_INTENT_CONFIDENCE_THRESHOLD}, using full pipeline"
        )
        research_results = _full_pipeline(requirements, request_id, approved_sources, removed_source_ids)

    return research_results


# ═══════════════════════════════════════════════════════════════════════════════
# Intent Analysis
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_reresearch_intent(
    human_feedback: str,
    approved_sources: List[Dict[str, Any]],
    removed_source_ids: List[str],
    document_requirements: Dict[str, Any],
    request_id: str = 'unknown',
) -> Dict[str, Any]:
    """LLM-based intent analysis for selective stage execution.

    Uses Haiku for fast, cheap classification. Returns required_stages + confidence.
    On any failure, returns confidence=0.0 (triggers full pipeline fallback).
    """
    # Build source statistics for context
    source_stats = _compute_source_statistics(approved_sources, removed_source_ids)

    system_prompt = _build_intent_system_prompt()
    user_prompt = _build_intent_user_prompt(human_feedback, source_stats, document_requirements)

    try:
        # _llm_call_json accepts: (prompt, max_tokens, timeout, model, temperature)
        # Merge system + user into a single prompt string
        combined_prompt = f"{system_prompt}\n\n{user_prompt}"
        response = _llm_call_json(
            combined_prompt,
            max_tokens=800,
            timeout=30,
            model=LLM_MODEL_FAST,  # Haiku — cheap, fast, sufficient for classification
            name='reresearch_classify_intent',
        )

        # Parse and validate
        intent = response if isinstance(response, dict) else {}

        # Validate stage names
        raw_stages = intent.get('required_stages', [])
        if isinstance(raw_stages, str):
            raw_stages = [s.strip() for s in raw_stages.split(',')]
        intent['required_stages'] = [s for s in raw_stages if s in VALID_STAGES]

        # Compute skip_stages
        intent['skip_stages'] = list(VALID_STAGES - set(intent['required_stages']))

        # Clamp confidence
        confidence = float(intent.get('confidence', 0.0))
        intent['confidence'] = max(0.0, min(1.0, confidence))

        # Ensure reasoning exists
        intent['reasoning'] = str(intent.get('reasoning', 'No reasoning provided'))

        # Ensure new_queries is a list
        nq = intent.get('new_queries', [])
        intent['new_queries'] = nq if isinstance(nq, list) else []

        # Safety: if no valid stages and confidence is high, it means "synthesis only"
        # That's valid (user just wants dedup/rerank of approved sources)

        return intent

    except Exception as e:
        logger.error(f"[{request_id}] Intent analysis failed: {e}", exc_info=True)
        return {
            'required_stages': list(VALID_STAGES),
            'skip_stages': [],
            'reasoning': f'Intent analysis failed ({str(e)}), falling back to full pipeline',
            'new_queries': [],
            'confidence': 0.0,
        }


def _build_intent_system_prompt() -> str:
    return """You are a research-stage routing classifier for a document generation system.

Given human feedback from a research review, determine which research stages need to be re-executed.

Available stages:
- kb_search: Search PMI's internal Knowledge Base (documents, reports, presentations). Use when feedback asks for internal/PMI-specific data, product safety info, or corporate documents.
- web_search: Search the public web via Tavily + Gemini extraction. Use when feedback asks for recent news, regulatory updates, external studies, WHO/government sources, or academic papers.
- user_sources: Process user-provided external URLs. Use when feedback mentions specific URLs or external links to fetch.
- curated_links: Fetch from internal curated link database. Use when feedback asks for pre-approved internal web resources.

Rules:
- If feedback is about quality/formatting of existing sources (dedup, remove, reorder), return empty required_stages (synthesis-only).
- If feedback asks for MORE of a specific type, select only that stage.
- If feedback is ambiguous or asks for "more sources" generically, include both kb_search and web_search.
- Set confidence HIGH (0.8-0.95) when the intent is clear and maps to specific stages.
- Set confidence LOW (0.3-0.6) when the feedback is vague, contradictory, or you're unsure.

Return ONLY a JSON object with these keys:
{"required_stages": ["stage1", "stage2"], "reasoning": "brief explanation", "new_queries": ["optional refined search query"], "confidence": 0.85}"""


def _build_intent_user_prompt(
    human_feedback: str,
    source_stats: Dict[str, Any],
    document_requirements: Dict[str, Any],
) -> str:
    topic = document_requirements.get('topic', '')
    jurisdiction = document_requirements.get('jurisdiction', '')

    return f"""HUMAN FEEDBACK: "{human_feedback}"

CURRENT SOURCE COMPOSITION:
- Approved sources: {source_stats['approved_count']} total
  - Knowledge Base: {source_stats['approved_by_type'].get('knowledge_base', 0)}
  - Web Search: {source_stats['approved_by_type'].get('web_search', 0)}
  - External URL: {source_stats['approved_by_type'].get('external_url', 0)}
  - Internal URL: {source_stats['approved_by_type'].get('internal_url', 0)}
  - Uploaded File: {source_stats['approved_by_type'].get('uploaded_file', 0)}
- Removed sources: {source_stats['removed_count']}

RESEARCH CONTEXT:
- Topic: {topic}
- Jurisdiction: {jurisdiction}

Based on the feedback and source composition, which stages should be re-executed?
Return ONLY the JSON object."""


def _compute_source_statistics(
    approved_sources: List[Dict[str, Any]],
    removed_source_ids: List[str],
) -> Dict[str, Any]:
    approved_by_type: Dict[str, int] = {}
    for src in approved_sources:
        stype = src.get('source_type', 'unknown')
        approved_by_type[stype] = approved_by_type.get(stype, 0) + 1

    return {
        'approved_count': len(approved_sources),
        'removed_count': len(removed_source_ids),
        'approved_by_type': approved_by_type,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Selective Research Execution
# ═══════════════════════════════════════════════════════════════════════════════

def conduct_selective_research(
    document_requirements: Dict[str, Any],
    request_id: str,
    required_stages: List[str],
    approved_sources: List[Dict[str, Any]],
    removed_source_ids: List[str] = None,
) -> Dict[str, Any]:
    """Execute only required research stages, merge with approved, finalize, and
    return a research_summary in the same shape as the full synthesis output."""

    removed_source_ids = removed_source_ids or []

    # Fix 2: Convert structured HITL format → raw research format
    raw_approved = _convert_structured_to_raw(approved_sources)

    # Fix 3: Build excluded URL/title set from removed sources
    excluded_urls, excluded_titles = _build_exclusion_sets(approved_sources, removed_source_ids)

    # Seed the research_results envelope
    research_results = {
        'all_sources': list(raw_approved),
        'formatted_citations': [],
        'search_queries': [],
        'consolidated_score': 0.0,
        'web_search_triggered': 'web_search' in required_stages,
    }

    # Extract citations from approved sources
    for src in raw_approved:
        if src.get('url'):
            research_results['formatted_citations'].append({
                'title': src.get('title', ''),
                'url': src.get('url', ''),
                'source_type': src.get('type', ''),
            })

    # Stage execution map
    stage_functions = {
        'kb_search': lambda: kb_mod.stage_kb(document_requirements, request_id),
        'web_search': lambda: web_mod.stage_web(document_requirements, request_id),
        'user_sources': lambda: user_sources_mod.stage_user_sources(document_requirements, request_id),
        'curated_links': lambda: curated_mod.stage_curated(document_requirements, request_id),
    }

    # Execute required stages
    for stage_name in required_stages:
        if stage_name in stage_functions:
            logger.info(f"[{request_id}] RE_RESEARCH executing stage: {stage_name}")
            try:
                stage_output = stage_functions[stage_name]()
                new_sources = stage_output.get('sources', [])

                # Fix 3: Filter out any re-fetched sources that match excluded URLs/titles
                if excluded_urls or excluded_titles:
                    filtered_new = []
                    for s in new_sources:
                        s_url = (s.get('url') or '').strip().lower()
                        s_title = (s.get('title') or '').strip().lower()
                        if s_url and s_url in excluded_urls:
                            logger.info(f"[{request_id}] RE_RESEARCH | blocked re-fetch of excluded URL: {s_url[:60]}")
                            continue
                        if s_title and s_title in excluded_titles:
                            logger.info(f"[{request_id}] RE_RESEARCH | blocked re-fetch of excluded title: {s_title[:60]}")
                            continue
                        filtered_new.append(s)
                    new_sources = filtered_new

                research_results['all_sources'].extend(new_sources)
                research_results['formatted_citations'].extend(stage_output.get('citations', []))
                research_results['search_queries'].extend(stage_output.get('queries', []))
            except Exception as e:
                logger.error(f"[{request_id}] RE_RESEARCH stage {stage_name} failed (non-fatal): {e}", exc_info=True)

    # Finalize: dedup, rerank, top-k, synthesis, build output
    research_start = datetime.now()
    research_results = synthesis_mod.finalize_research_results(
        research_results, document_requirements, request_id
    )

    # Build the canonical research_summary output (same shape as initial synthesis)
    return synthesis_mod.build_research_output(
        research_results, document_requirements, request_id, research_start
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Full Pipeline Fallback
# ═══════════════════════════════════════════════════════════════════════════════

def _full_pipeline(
    requirements: Dict[str, Any],
    request_id: str,
    approved_sources: List[Dict[str, Any]],
    removed_source_ids: List[str] = None,
) -> Dict[str, Any]:
    """Fallback: run all 4 stages + synthesis (same as initial research, but preserves approved)."""
    return conduct_selective_research(
        document_requirements=requirements,
        request_id=request_id,
        required_stages=list(VALID_STAGES),
        approved_sources=approved_sources,
        removed_source_ids=removed_source_ids,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Helper Functions (Fix 2, 3, 4)
# ═══════════════════════════════════════════════════════════════════════════════

def _convert_structured_to_raw(structured_sources: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Fix 2: Convert HITL structured format back to raw research format.

    HITL checkpoint stores sources as: {source_id, title, source_type, relevance_score, url, summary, reason}
    The pipeline expects: {title, source, type, date, relevance_score, summary, url}
    """
    raw = []
    for src in structured_sources:
        raw.append({
            'title': src.get('title', ''),
            'source': src.get('source_type', 'approved_source'),
            'type': src.get('source_type', 'web_search'),
            'date': datetime.now().strftime('%Y-%m-%d'),
            'relevance_score': float(src.get('relevance_score') or 0.5),
            'summary': src.get('summary', ''),
            'url': src.get('url', ''),
            '_approved': True,  # marker so dedup gives priority to approved sources
        })
    return raw


def _build_exclusion_sets(
    all_hitl_sources: List[Dict[str, Any]],
    removed_source_ids: List[str],
) -> tuple:
    """Fix 3: Build sets of URLs and titles from removed sources for blocking re-fetch."""
    removed_set = set(removed_source_ids)
    excluded_urls = set()
    excluded_titles = set()
    for src in all_hitl_sources:
        if src.get('source_id') in removed_set:
            if src.get('url'):
                excluded_urls.add(src['url'].strip().lower())
            if src.get('title'):
                excluded_titles.add(src['title'].strip().lower())
    return excluded_urls, excluded_titles


def _extract_urls_from_feedback(feedback: str) -> List[str]:
    """Fix 4: Extract URLs from human feedback text."""
    if not feedback:
        return []
    url_pattern = re.compile(r'https?://[^\s,)}\]]+')
    urls = url_pattern.findall(feedback)
    # Clean trailing punctuation
    cleaned = []
    for url in urls:
        url = url.rstrip('.,;:!?')
        if len(url) > 10:  # skip tiny fragments
            cleaned.append(url)
    return cleaned
