"""Split-research stage lambda: SYNTHESIS (terminal).

This is the ONLY stage that:
  - aggregates the retrieval outputs, finalizes (relevance loop + rerank + top-k),
  - synthesizes findings and writes research_data.json to S3,
  - sets the RESEARCH_COMPLETED status in DynamoDB,
  - returns the canonical research_summary consumed by the drafter / UI.

Event payload (Step Functions split):
    {
      "request_id": str,
      "requirements": {...enriched by planner...},
      "parallel_outputs": [ <KB>, <Web>, <UserSources>, <Curated> ],
      "research_start": ISO-8601 timestamp,
      "langsmith_headers": {...}
    }

Returns:
    {"research_summary": {...}, "langsmith_headers": {...}}
    ^ langsmith_headers MUST be in output for HITLResearchGate to read.

LangSmith tracing: middle-of-pipeline stage — receives + re-attaches
propagated trace context. See handler_planner.py for the canonical pattern.
"""
import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (MUST import before langsmith)

from datetime import datetime

try:
    import researcher_synthesis as synth
except ImportError:
    from agents.master_researcher import researcher_synthesis as synth

from core.researcher_common import logger

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers,
        attach_outgoing_langsmith_headers,
    )
    _LANGSMITH_TRACING_AVAILABLE = True
except Exception:
    _LANGSMITH_TRACING_AVAILABLE = False

    def traceable(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator if not args else _decorator(args[0])

    def get_incoming_langsmith_headers(event):
        return {}

    def attach_outgoing_langsmith_headers(result, run_tree):
        return result


def _parse_start(value):
    """Parse ISO research_start to naive datetime (Lambda is UTC)."""
    if isinstance(value, str) and value:
        v = value.strip()
        if v.endswith('Z'):
            v = v[:-1] + '+00:00'
        try:
            dt = datetime.fromisoformat(v)
            if dt.tzinfo is not None:
                dt = dt.replace(tzinfo=None)
            return dt
        except ValueError:
            pass
    return datetime.now()


@traceable(name="research_synthesis", run_type="chain")
def _traced_synthesis(requirements, parallel_outputs, request_id, research_start, run_tree=None):
    result = synth.stage_synthesis_from_parallel(
        requirements, parallel_outputs, request_id, research_start
    )
    result = attach_outgoing_langsmith_headers(result, run_tree)
    # Ensure langsmith_headers is always present, even if empty
    if 'langsmith_headers' not in result:
        result['langsmith_headers'] = {}
    return result


def lambda_handler(event, context):
    request_id = str(event.get('request_id') or 'unknown')
    requirements = event.get('requirements', {}) or {}
    research_start = _parse_start(event.get('research_start'))

    # Step Functions split — aggregate the parallel branch array
    if 'parallel_outputs' in event:
        parallel_outputs = event.get('parallel_outputs') or []
        logger.info(
            f"[{request_id}] STAGE synthesis start (SF parallel_outputs, "
            f"branches={len(parallel_outputs)})"
        )

        if not _LANGSMITH_TRACING_AVAILABLE:
            return _traced_synthesis(requirements, parallel_outputs, request_id, research_start)

        from langsmith.run_helpers import tracing_context
        incoming_headers = get_incoming_langsmith_headers(event)
        with tracing_context(parent=incoming_headers):
            return _traced_synthesis(requirements, parallel_outputs, request_id, research_start)

    # Fallback: pre-aggregated research_results envelope (monolith path, no tracing wiring needed)
    research_results = event.get('research_results', {}) or {}
    logger.info(f"[{request_id}] STAGE synthesis start (router research_results)")
    return synth.stage_synthesis(requirements, research_results, request_id, research_start)
