import json
import os
import ssl
import urllib.request
import urllib.error
from pathlib import Path
from dotenv import load_dotenv

# -----------------------------------------------------------------------------
# Load .env
# -----------------------------------------------------------------------------
ENV_PATH = Path.cwd() / ".env"
print(f"Looking for .env at: {ENV_PATH}")
print(f".env exists?: {ENV_PATH.exists()}")

load_dotenv(dotenv_path=ENV_PATH, override=True)

# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------
LITELLM_RERANK_URL = os.environ.get(
    "AWS_LITELLM_RERANK_ENDPOINT",
    "https://litellm.aiplat-dev.aws.private-pmideep.biz/rerank"
)

# IMPORTANT: for rerank, use full ARN format with "bedrock/" prefix
LITELLM_RERANK_MODEL = "bedrock/arn:aws:bedrock:us-east-1::foundation-model/cohere.rerank-v3-5:0"

LITELLM_KEY = (
    os.environ.get("AWS_BEARER_TOKEN_BEDROCK")
    or os.environ.get("BEDROCK_BEARER_TOKEN")
)

def print_env_diagnostics():
    print("\n" + "=" * 80)
    print("LOCAL RERANK TEST DIAGNOSTICS")
    print("=" * 80)
    print(f"AWS_LITELLM_RERANK_ENDPOINT : {LITELLM_RERANK_URL}")
    print(f"AWS_LITELLM_RERANK_MODEL    : {LITELLM_RERANK_MODEL}")
    print(f"AWS_BEARER_TOKEN_BEDROCK    : {'SET' if os.environ.get('AWS_BEARER_TOKEN_BEDROCK') else 'NOT SET'}")
    print(f"BEDROCK_BEARER_TOKEN        : {'SET' if os.environ.get('BEDROCK_BEARER_TOKEN') else 'NOT SET'}")
    print(f"Resolved token available    : {'YES' if LITELLM_KEY else 'NO'}")
    if LITELLM_KEY:
        print(f"Resolved token length       : {len(LITELLM_KEY)}")
        print(f"Resolved token preview      : {LITELLM_KEY[:5]}...{LITELLM_KEY[-3:]}")

def build_ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

def call_litellm_rerank(query: str, documents: list[str], top_n: int = 3):
    if not LITELLM_KEY:
        raise ValueError(
            "No LiteLLM bearer token found. Set one of these in .env:\n"
            "  - AWS_BEARER_TOKEN_BEDROCK\n"
            "  - BEDROCK_BEARER_TOKEN"
        )

    headers = {
        "Authorization": f"Bearer {LITELLM_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": LITELLM_RERANK_MODEL,
        "query": query,
        "documents": documents,
        "top_n": top_n
    }

    print("\n" + "-" * 80)
    print(f"Calling LiteLLM rerank endpoint: {LITELLM_RERANK_URL}")
    print(f"Query: {query}")
    print(f"Documents count: {len(documents)}")
    print("-" * 80)

    req = urllib.request.Request(
        LITELLM_RERANK_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST"
    )

    ctx = build_ssl_context()

    try:
        with urllib.request.urlopen(req, context=ctx, timeout=300) as response:
            raw = response.read().decode("utf-8", errors="replace")
            print(f"HTTP Status: {response.status}")
            print("\nRAW RESPONSE:")
            print(raw)

            res = json.loads(raw)

            print("\n" + "=" * 80)
            print("PARSED RERANK RESULTS")
            print("=" * 80)

            results = res.get("results", [])
            if not results:
                print("[No rerank results found]")
            else:
                for rank, item in enumerate(results, start=1):
                    idx = item.get("index")
                    score = item.get("relevance_score", item.get("relevanceScore"))

                    print(f"\nRank #{rank}")
                    print(f"Index          : {idx}")
                    print(f"Relevance Score: {score}")
                    if idx is not None and idx < len(documents):
                        print(f"Document       : {documents[idx]}")
                    else:
                        print("Document       : [Unavailable]")

            return res

    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")
        print(f"\nHTTP ERROR CODE: {e.code}")
        print(f"HTTP ERROR REASON: {e.reason}")
        print("\nERROR RESPONSE BODY:")
        print(error_body)
        raise

    except Exception as e:
        print("\nUNEXPECTED ERROR:")
        print(str(e))
        raise



print_env_diagnostics()

test_query = "What should I do if I click a phishing link?"
test_documents = [
    "Vietnam Business Travel and Visa Guide. A passport should remain valid for at least six months from the intended date of entry. Supporting documents may include invitation letter, itinerary, hotel reservation, and return travel proof.",
    "Internal Security Awareness Notes. Never click suspicious links in email, chat, or SMS messages. If a phishing link was clicked, disconnect from the network, notify the security team, and document the event.",
    "General company travel policy. Employees should keep digital and printed copies of documents while traveling and review local customs rules."
]

call_litellm_rerank(
    query=test_query,
    documents=test_documents,
    top_n=2
)