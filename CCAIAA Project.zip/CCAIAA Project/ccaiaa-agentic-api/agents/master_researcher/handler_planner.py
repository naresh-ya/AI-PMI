"""Split-research stage lambda: PLANNER.

Loads jurisdiction context + output template, runs the agentic framing decision
and Phase 0 query planning, and returns requirements enriched with
_research_framing / _planned_queries / context.

Event payload:
    {"request_id": str, "requirements": {...document_requirements...}, "langsmith_headers": {...}}
Returns:
    {"requirements": {...enriched...}, "langsmith_headers": {...}}

Writes nothing to S3/DynamoDB — only the terminal synthesis stage does that.

LangSmith tracing: this is a middle-of-pipeline stage, not the trace root
(that's input_validator). It receives the propagated trace context via
event['langsmith_headers'], continues the SAME trace, and re-attaches the
(possibly updated) headers onto its own output so the next Step Functions
state can continue the chain. See core/langsmith_tracing/ for the shared
helpers and agents/input_validator/handler_new_validator.py for the
canonical pattern this mirrors.
"""

import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (MUST import before langsmith)

try:
    import researcher_planner as planner               # Lambda package root
except ImportError:                                     # local / dev
    from agents.master_researcher import researcher_planner as planner

from core.researcher_common import logger

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers,
        attach_outgoing_langsmith_headers,
    )
    _LANGSMITH_TRACING_AVAILABLE = True
except Exception:
    _LANGSMITH_TRACING_AVAILABLE = False

    def traceable(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator if not args else _decorator(args[0])

    def get_incoming_langsmith_headers(event):
        return {}

    def attach_outgoing_langsmith_headers(result, run_tree):
        return result


@traceable(name="research_planner", run_type="chain")
def _traced_stage_plan(requirements, request_id, run_tree=None):
    result = planner.stage_plan(requirements, request_id)
    result = attach_outgoing_langsmith_headers(result, run_tree)
    # Ensure langsmith_headers is always present, even if empty
    if 'langsmith_headers' not in result:
        result['langsmith_headers'] = {}
    return result


def lambda_handler(event, context):
    request_id = str(event.get('request_id') or 'unknown')
    requirements = event.get('requirements', {}) or {}
    logger.info(f"[{request_id}] STAGE planner start")

    if not _LANGSMITH_TRACING_AVAILABLE:
        return _traced_stage_plan(requirements, request_id)

    from langsmith.run_helpers import tracing_context
    incoming_headers = get_incoming_langsmith_headers(event)
    with tracing_context(parent=incoming_headers):
        return _traced_stage_plan(requirements, request_id)
