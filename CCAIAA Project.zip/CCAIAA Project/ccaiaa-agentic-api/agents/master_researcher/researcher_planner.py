"""
Researcher Planner Module — extracted from handler_new_advanced.py (Phase B).

Provides: plan_research(), stage_plan()
Loads jurisdiction context + output template, runs agentic framing and query planning.

Performance notes:
  - Module-level SSL context avoids repeated TLS setup.
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from typing import Dict, Any, List

# Import shared utilities from core
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL, LLM_MODEL_REASONING,
    JURISDICTION_CTX_MAX, DEFAULT_TONE,
    _llm_call_json, _tokenize_relevance, _estimate_tokens,
)

# ── Module-level shared SSL context ──────────────────────────────────────────
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

# ── Template mapping (same as handler_new_advanced.py) ────────────────────────
_CATEGORY_TEMPLATE_MAP = {
    "Official PMI Submission": "official-pmi-submission.md",
    "Third Party Submission":  "third-party-submission.md",
    "White Papers":            "white-papers.md",
    "Internal Communications": "internal-communications.md",
    "Media Releases":          "media-releases.md",
    "Narrative Builder":       "narrative-builder.md",
}

# ── Caches ────────────────────────────────────────────────────────────────────
_JURISDICTION_CONTEXT_CACHE: Dict[str, str] = {}
_TEMPLATE_CONTEXT_CACHE: Dict[str, str] = {}


# ═══════════════════════════════════════════════════════════════════════════════
# Jurisdiction loader (Bedrock-first, disk fallback)
# ═══════════════════════════════════════════════════════════════════════════════

def _load_jurisdiction_context(jurisdiction: str) -> str:
    """Load jurisdiction ground-truth. Bedrock first, disk fallback. Cached."""
    if not jurisdiction:
        return ''
    key = jurisdiction.strip().lower()
    if key in _JURISDICTION_CONTEXT_CACHE:
        return _JURISDICTION_CONTEXT_CACHE[key]

    # Try Bedrock Prompt Management
    try:
        try:
            from core import bedrock_prompt_client as _bpc
        except ImportError:
            import bedrock_prompt_client as _bpc
        if _bpc.is_enabled():
            bedrock_name = f"ccaiaa-jurisdiction-{key}"
            text = _bpc.get_prompt_text(bedrock_name)
            if text:
                logger.info(f"JURISDICTION_CONTEXT | source=bedrock | name={bedrock_name} ({len(text)} chars)")
                _JURISDICTION_CONTEXT_CACHE[key] = text
                return text
            else:
                logger.info(f"JURISDICTION_CONTEXT | bedrock miss for '{bedrock_name}', falling back to disk")
    except Exception as e:
        logger.warning(f"JURISDICTION_CONTEXT | bedrock error ({e}), falling back to disk")

    # Disk fallback
    here = os.path.dirname(os.path.abspath(__file__))
    candidate_dirs = [
        os.path.join(here, 'templates', 'jurisdiction'),
        os.path.join(here, os.pardir, 'templates', 'jurisdiction'),
        os.path.join(here, os.pardir, os.pardir, 'templates', 'jurisdiction'),
    ]
    filenames = [f'{key}.md', f'{jurisdiction.strip()}.md']
    content = ''
    for d in candidate_dirs:
        for fn in filenames:
            fp = os.path.normpath(os.path.join(d, fn))
            if os.path.exists(fp):
                try:
                    with open(fp, 'r', encoding='utf-8') as f:
                        content = f.read()
                    logger.info(f"JURISDICTION_CONTEXT | source=disk | loaded '{fn}' ({len(content)} chars)")
                except Exception as e:
                    logger.warning(f"JURISDICTION_CONTEXT | failed to load '{fn}': {e}")
                break
        if content:
            break
    if not content:
        logger.info(f"JURISDICTION_CONTEXT | no file found for '{key}'")
    _JURISDICTION_CONTEXT_CACHE[key] = content
    return content


# ═══════════════════════════════════════════════════════════════════════════════
# Output template loader (Bedrock-first, disk fallback)
# ═══════════════════════════════════════════════════════════════════════════════

def _load_output_template(category: str) -> str:
    """Load output-section template. Bedrock first, disk fallback. Cached."""
    if not category:
        return ''
    key = category.strip()
    if key in _TEMPLATE_CONTEXT_CACHE:
        return _TEMPLATE_CONTEXT_CACHE[key]

    filename = _CATEGORY_TEMPLATE_MAP.get(key, '')
    if not filename:
        logger.info(f"OUTPUT_TEMPLATE | no template mapping for category '{category}'")
        _TEMPLATE_CONTEXT_CACHE[key] = ''
        return ''

    # Try Bedrock Prompt Management
    try:
        try:
            from core import bedrock_prompt_client as _bpc
        except ImportError:
            import bedrock_prompt_client as _bpc
        if _bpc.is_enabled():
            slug = re.sub(r"[^a-zA-Z0-9]+", "-", key.lower()).strip("-")
            bedrock_name = f"ccaiaa-template-{slug}"
            text = _bpc.get_prompt_text(bedrock_name)
            if text:
                logger.info(f"OUTPUT_TEMPLATE | source=bedrock | name={bedrock_name} ({len(text)} chars)")
                _TEMPLATE_CONTEXT_CACHE[key] = text
                return text
            else:
                logger.info(f"OUTPUT_TEMPLATE | bedrock miss for '{bedrock_name}', falling back to disk")
    except Exception as e:
        logger.warning(f"OUTPUT_TEMPLATE | bedrock error ({e}), falling back to disk")

    # Disk fallback
    here = os.path.dirname(os.path.abspath(__file__))
    candidate_dirs = [
        os.path.join(here, 'templates'),
        os.path.join(here, os.pardir, 'templates'),
        os.path.join(here, os.pardir, os.pardir, 'templates'),
    ]
    content = ''
    for d in candidate_dirs:
        fp = os.path.normpath(os.path.join(d, filename))
        if os.path.exists(fp):
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    content = f.read()
                logger.info(f"OUTPUT_TEMPLATE | source=disk | loaded '{filename}' ({len(content)} chars)")
            except Exception as e:
                logger.warning(f"OUTPUT_TEMPLATE | failed to load '{filename}': {e}")
            break
    if not content:
        logger.info(f"OUTPUT_TEMPLATE | no file found for category '{category}' (file={filename})")
    _TEMPLATE_CONTEXT_CACHE[key] = content
    return content


# ═══════════════════════════════════════════════════════════════════════════════
# Agentic framing
# ═══════════════════════════════════════════════════════════════════════════════

def _llm_research_framing(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Agentic REQUEST UNDERSTANDING + FRAMING. Returns {} on failure."""
    topic = (requirements.get('topic') or '').strip()
    if not topic:
        return {}

    _METADATA_FIELDS = {
        'request_id', 'user_id', 'created_at', 'updated_at', 'completed_at', 'isSubmit',
        'bypass_duplicate_check', 'progress', 'enable_hitl', 'enable_topic_relevance_check',
        'uploadedFileKeys', 'uploaded_files', 'uploaded_file_s3_key', 'urls', 'reference_urls',
        'external_links', 'output_file_type', 'deadline', 'priority',
        '_jurisdiction_context', '_output_template', '_research_framing', '_planned_queries',
        '_web_narrow_query', 're_research_feedback', '_uploaded_file_source',
    }
    clean_request = {}
    for k, v in (requirements or {}).items():
        if k in _METADATA_FIELDS:
            continue
        if v in (None, '', [], {}):
            continue
        if isinstance(v, str) and len(v) > 30000:
            v = v[:30000]
        clean_request[k] = v

    request_json = json.dumps(clean_request, ensure_ascii=False, default=str)

    prompt = (
        "You are a REQUEST UNDERSTANDING agent for PMI (Philip Morris International) "
        "Corporate Affairs. You receive a document-generation request as JSON. The set of "
        "fields varies by document category (e.g. some requests include a recipient / "
        "addressed_to / cc_to, others include stakeholders or background). DYNAMICALLY decide "
        "which fields are meaningful for THIS request and ignore empty or system/metadata "
        "fields.\n\n"
        "From the request, determine:\n"
        "1. The user's INTENT and OBJECTIVE (what they actually want the document to achieve).\n"
        "2. The AUTHOR identity (this is PMI) and the STANCE PMI should take. The named "
        "recipient/ministry/audience is who the document is FOR — never adopt the audience's "
        "voice or argue against PMI's own interest.\n"
        "3. The AUDIENCE (recipient/stakeholders) the document addresses.\n"
        "4. The retrieval FRAMING so source search matches the ACTUAL subject, not superficial "
        "keyword matches.\n\n"
        f"REQUEST JSON:\n{request_json}\n\n"
        "Decide the perspective:\n"
        "- 'first_party_pmi'     : about PMI's OWN action/initiative/position/announcement. "
        "Anchor queries to PMI so results are about PMI, not a government with a similarly named programme.\n"
        "- 'external_regulatory' : about external law/regulation/policy or a government "
        "consultation. Do NOT anchor to PMI — you want the regulatory sources themselves.\n"
        "- 'comparative_market'  : needs data from other markets/countries.\n\n"
        "Rules:\n"
        "- Set 'entity_anchor' to 'PMI Philip Morris International' ONLY for first_party_pmi; otherwise empty string.\n"
        "- 'must_exclude_terms': terms that would pull OFF-topic results (e.g. for a PMI "
        "sustainability release, exclude government trade bodies like 'Department of Commerce', 'foreign trade').\n"
        "- 'core_topic_tokens': 5-12 lowercase keywords a genuinely relevant source MUST relate to.\n"
        "- 'stance': if the request is purely informational/neutral, say 'neutral/informational'.\n\n"
        "Output ONLY a JSON object with keys: intent (string), objective (string), "
        "author_identity (string), stance (string), audience (string), subject_entity (string), "
        "perspective (string), entity_anchor (string), must_include_terms (array), "
        "must_exclude_terms (array), core_topic_tokens (array), key_constraints (array). "
        "No explanation, no markdown."
    )

    data = _llm_call_json(prompt, max_tokens=900, model=LLM_MODEL_REASONING, name='planner_request_framing')
    if not isinstance(data, dict):
        return {
            'intent': topic,
            'objective': (requirements.get('background') or topic),
            'author_identity': 'PMI',
            'stance': '',
            'audience': requirements.get('addressed_to') or requirements.get('stakeholders') or '',
            'subject_entity': '',
            'perspective': '',
            'entity_anchor': '',
            'must_include_terms': [],
            'must_exclude_terms': [],
            'core_topic_tokens': _tokenize_relevance(f"{topic} {requirements.get('background', '')}")[:15],
            'key_constraints': [],
            'tone': (str(requirements.get('tone_requirements') or '').strip() or DEFAULT_TONE),
        }

    def _strlist(key: str, lower: bool = False, cap: int = 12) -> List[str]:
        out = []
        for t in (data.get(key) or []):
            v = str(t).strip()
            if v:
                out.append(v.lower() if lower else v)
        return out[:cap]

    framing = {
        'intent': str(data.get('intent') or '').strip(),
        'objective': str(data.get('objective') or '').strip(),
        'author_identity': str(data.get('author_identity') or 'PMI').strip(),
        'stance': str(data.get('stance') or '').strip(),
        'audience': str(data.get('audience') or '').strip(),
        'key_constraints': _strlist('key_constraints', cap=10),
        'tone': (str(requirements.get('tone_requirements') or '').strip() or DEFAULT_TONE),
        'subject_entity': str(data.get('subject_entity') or '').strip(),
        'perspective': str(data.get('perspective') or '').strip().lower(),
        'entity_anchor': str(data.get('entity_anchor') or '').strip(),
        'must_include_terms': _strlist('must_include_terms'),
        'must_exclude_terms': _strlist('must_exclude_terms', lower=True),
        'core_topic_tokens': _strlist('core_topic_tokens', lower=True, cap=15),
    }
    if not framing['core_topic_tokens']:
        framing['core_topic_tokens'] = _tokenize_relevance(
            f"{topic} {requirements.get('background', '')}"
        )[:15]

    logger.info(
        f"REQUEST_UNDERSTANDING | perspective='{framing['perspective']}' "
        f"| stance='{framing['stance']}' | audience='{framing['audience'][:60]}' "
        f"| tone='{framing['tone'][:60]}' "
        f"| entity_anchor='{framing['entity_anchor']}' | tokens={framing['core_topic_tokens']}"
    )
    return framing


# ═══════════════════════════════════════════════════════════════════════════════
# Query sanitization
# ═══════════════════════════════════════════════════════════════════════════════

def _sanitize_queries(queries: List[str], requirements: Dict[str, Any]) -> List[str]:
    """Clean planner queries: remove leaked labels, collapse repeats, cap length, dedup."""
    try:
        phrases = []
        for k in ('category', 'use_case'):
            v = (requirements.get(k) or '').strip()
            if v:
                phrases.append(v)
        phrases += ['relevant stakeholders', 'not applicable', 'n/a']
        out, seen = [], set()
        for q in queries or []:
            if not isinstance(q, str) or not q.strip():
                continue
            cq = q
            for p in phrases:
                if p:
                    cq = re.sub(r'\b' + re.escape(p) + r'\b', ' ', cq, flags=re.IGNORECASE)
            words, wseen, kept = re.split(r'\s+', cq.strip()), set(), []
            for w in words:
                lw = w.lower().strip(',.;:')
                if not lw or lw in wseen:
                    continue
                wseen.add(lw)
                kept.append(w)
            cq = ' '.join(kept[:14]).strip()
            key = cq.lower()
            if cq and key not in seen:
                seen.add(key)
                out.append(cq)
        return out or queries
    except Exception:
        return queries


# ═══════════════════════════════════════════════════════════════════════════════
# Query planning (Phase 0)
# ═══════════════════════════════════════════════════════════════════════════════

def _llm_plan_research(requirements: Dict[str, Any]) -> List[str]:
    """Agentic Phase 0: plan 5-7 targeted retrieval queries. Returns [] on failure."""
    if not LITELLM_KEY:
        return []

    topic        = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    category     = requirements.get('category', '')
    use_case     = requirements.get('use_case', '')
    background   = requirements.get('background', '')

    if not topic:
        return []

    prompt = (
        "You are a research planning agent for regulatory document preparation.\n\n"
        f"Topic: {topic}\n"
        f"Jurisdiction: {jurisdiction}\n"
        f"Category: {category}\n"
        f"Use case: {use_case}\n"
        f"Background: {background if background else 'N/A'}\n\n"
    )

    framing = requirements.get('_research_framing', {}) or {}
    if framing.get('intent') or framing.get('objective'):
        prompt += (
            "USER INTENT & OBJECTIVE (plan queries that serve THIS goal):\n"
            f"- Intent: {framing.get('intent', 'N/A')}\n"
            f"- Objective: {framing.get('objective', 'N/A')}\n"
            f"- Author: {framing.get('author_identity', 'PMI')} | Stance: {framing.get('stance', 'N/A')}\n"
            f"- Audience: {framing.get('audience', 'N/A')}\n\n"
        )

    jur_context = requirements.get('_jurisdiction_context', '')
    if jur_context:
        prompt += f"JURISDICTION CONTEXT (use this to inform your queries):\n{jur_context[:JURISDICTION_CTX_MAX]}\n\n"

    file_summary = requirements.get('_uploaded_file_summary', '')
    if file_summary:
        prompt += (
            "UPLOADED FILE SUMMARY (the user provided this file as reference — use its content "
            "to inform your queries so they target the file's actual subject matter):\n"
            f"{file_summary[:5000]}\n\n"
        )

    tone = requirements.get('tone_requirements', '')
    if tone:
        prompt += f"TONE REQUIREMENTS for the final document: {tone}\n\n"

    output_template = requirements.get('_output_template', '')
    if output_template:
        prompt += (
            "TARGET DOCUMENT STRUCTURE (the final document will have these sections — "
            "generate queries that gather the specific evidence each section needs):\n"
            f"{output_template[:2500]}\n\n"
        )

    framing = requirements.get('_research_framing', {}) or {}
    if framing:
        anchor = framing.get('entity_anchor', '')
        exclude = framing.get('must_exclude_terms', [])
        if anchor:
            prompt += (
                f"SUBJECT ANCHOR: Every query MUST be anchored to '{anchor}' so results are about "
                f"this entity and not a different organisation with a similarly named programme.\n"
            )
        if framing.get('perspective'):
            prompt += f"RESEARCH PERSPECTIVE: {framing['perspective']}\n"
        if exclude:
            prompt += f"AVOID these off-topic terms in queries: {', '.join(exclude)}\n"
        prompt += "\n"

    prompt += (
        "Generate 5-7 specific, targeted retrieval queries that together cover all the "
        "evidence needed to write a comprehensive document on this topic.\n\n"
        "Each query should target ONE specific fact family:\n"
        "- Jurisdiction-specific regulatory authority and current product/policy status\n"
        "- Scientific evidence with specific percentages, study names, dates\n"
        "- Regulatory authorizations in comparable markets (with dates)\n"
        "- Market/economic data (market share, revenue, investment figures)\n"
        "- Comparative country case studies with specific statistics\n"
        "- Opposition/stakeholder positions (WHO, health ministry stance)\n"
        "- Policy precedents or legislation with names and years\n\n"
        "Rules:\n"
        "- Each query: 5-15 words, specific enough to find one fact\n"
        "- Include numbers, dates, or named entities where possible\n"
        "- Output ONLY a JSON array of strings, no explanation\n\n"
        'Example: ["FDA MRTP authorization IQOS July 2020", '
        '"Japan HTP market share adult smoking decline 2022", '
        '"Thailand Disease Control Department tobacco regulatory authority"]'
    )

    try:
        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 400,
            "temperature": 0.2,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL, data=json.dumps(data).encode('utf-8'),
            headers=headers, method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=15) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(res, name='planner_query_planning', response=resp)
            except Exception:
                pass
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            queries = json.loads(raw)
            if isinstance(queries, list):
                result = [str(q).strip() for q in queries if q and str(q).strip()][:7]
                logger.info(f"AGENTIC_PLAN | planned_queries={len(result)}")
                return result
    except Exception as e:
        logger.warning(f"Agentic research planning failed (non-fatal): {e}")

    return []


# ═══════════════════════════════════════════════════════════════════════════════
# Main orchestrator
# ═══════════════════════════════════════════════════════════════════════════════

def plan_research(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Planning prelude: load jurisdiction + template, framing, query planning.

    Returns a NEW requirements dict enriched with:
    _jurisdiction_context, _output_template, _research_framing, _planned_queries.
    Pure (no S3/DDB writes) — safe to run as an isolated stage.
    """
    requirements = requirements.copy()

    # Load jurisdiction context
    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    jurisdiction_context = _load_jurisdiction_context(jurisdiction)
    if jurisdiction_context:
        requirements['_jurisdiction_context'] = jurisdiction_context
        logger.info(f"[{request_id}] Jurisdiction context loaded for '{jurisdiction}' ({len(jurisdiction_context)} chars)")

    # Load output-section template
    output_template = _load_output_template((requirements.get('category') or '').strip())
    if output_template:
        requirements['_output_template'] = output_template
        logger.info(f"[{request_id}] Output template loaded for category '{requirements.get('category')}' ({len(output_template)} chars)")

    # Agentic framing
    framing = _llm_research_framing(requirements)
    requirements['_research_framing'] = framing

    # Phase 0: query planning
    planned_queries = _llm_plan_research(requirements)
    planned_queries = _sanitize_queries(planned_queries, requirements)
    if planned_queries:
        requirements['_planned_queries'] = planned_queries[:5]
        logger.info(f"[{request_id}] Agentic planning: {len(planned_queries)} queries, capped to {len(requirements['_planned_queries'])}")

    return requirements


def stage_plan(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Planner stage entry point: returns requirements enriched with framing + planned queries."""
    enriched = plan_research(requirements, request_id)
    return {'requirements': enriched}
