"""Researcher split stage: FILE PROCESSOR (client-demo2).

Thin wrapper that runs BEFORE the planner ONLY when an uploaded file exists.
Reads the uploaded file from S3, produces an enhanced summary (facts + structure +
form + intent cues), and returns enriched requirements so the planner can use the
file context for framing and query planning.

Event payload (from the Choice state):
  {
    "request_id": "req_...",
    "requirements": { ... document_requirements ... }
  }

Returns:
  {
    "requirements": { ...original + _uploaded_file_summary + _uploaded_file_source... }
  }

Fail-open: if anything goes wrong the SF Catch sends to Planner anyway (no file context,
same as today's behavior).
"""
import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (MUST import before langsmith)

try:
    import researcher_file_processor as fp              # Lambda package root
except ImportError:
    from agents.master_researcher import researcher_file_processor as fp

from core.researcher_common import logger

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers,
        attach_outgoing_langsmith_headers,
    )
    _LANGSMITH_TRACING_AVAILABLE = True
except Exception:
    _LANGSMITH_TRACING_AVAILABLE = False

    def traceable(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator if not args else _decorator(args[0])

    def get_incoming_langsmith_headers(event):
        return {}

    def attach_outgoing_langsmith_headers(result, run_tree):
        return result


@traceable(name="research_file_processor", run_type="chain")
def _traced_process(requirements, request_id, run_tree=None):
    try:
        file_result = fp.read_uploaded_file(requirements)
        sources = file_result.get('sources', [])
        if sources and sources[0].get('summary'):
            requirements['_uploaded_file_summary'] = sources[0]['summary']
            requirements['_uploaded_file_source'] = sources[0]
            logger.info(
                f"[{request_id}] File processed: {len(requirements['_uploaded_file_summary'])} chars summary"
            )
        else:
            logger.info(f"[{request_id}] File processor: no summary produced (empty file or extraction failed)")
    except Exception as e:
        logger.error(f"[{request_id}] File processor failed (non-fatal): {e}")

    result = {'requirements': requirements}
    result = attach_outgoing_langsmith_headers(result, run_tree)
    # Ensure langsmith_headers is always present, even if empty
    if 'langsmith_headers' not in result:
        result['langsmith_headers'] = {}
    return result


def lambda_handler(event, context):
    request_id = str(event.get('request_id', 'unknown'))
    requirements = dict(event.get('requirements', {}))
    logger.info(f"[{request_id}] STAGE file_processor start")

    if not _LANGSMITH_TRACING_AVAILABLE:
        return _traced_process(requirements, request_id)

    from langsmith.run_helpers import tracing_context
    incoming_headers = get_incoming_langsmith_headers(event)
    with tracing_context(parent=incoming_headers):
        return _traced_process(requirements, request_id)
