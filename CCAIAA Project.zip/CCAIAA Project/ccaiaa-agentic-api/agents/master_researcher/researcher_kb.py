"""
Researcher KB Search Module (fully standalone).

Provides: search_internal_knowledge(), stage_kb()

Performance notes:
  - Module-level SSL context avoids repeated TLS setup.
  - LLM enrichment queries and theme mapping run in parallel (independent of each other).
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, Any, List

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    LLM_MODEL_FAST, _llm_call_json, _tokenize_relevance,
)

# ── Module-level shared SSL context ──────────────────────────────────────────
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

try:
    from core.kb_integration_new import search_pmi_knowledge_base
except ImportError:
    logger.warning("Could not import search_pmi_knowledge_base")
    search_pmi_knowledge_base = None

# ── KB helper functions ────────────────────────────────────────────────────

def _extract_semantic_signals(
    topic: str, background: str, use_case: str, category: str, jurisdiction: str = ''
) -> Dict[str, str]:
    """
    Use LLM to extract domain-meaningful signals from raw input fields.

    Returns:
        topic_core       — core subject terms, compound concepts preserved
        background_signal — domain-relevant facts stripped of drafting instructions

    Falls back silently to regex if the LLM call fails.
    """
    if LITELLM_KEY and (topic or background):
        prompt = (
            "You are a semantic signal extractor for a document vector retrieval system.\n\n"
            "Given the raw user input below, extract only the domain-relevant semantic content "
            "that would help retrieve matching documents from a knowledge base.\n\n"
            f"Topic: {topic or 'N/A'}\n"
            f"Background: {background or 'N/A'}\n"
            f"Jurisdiction: {jurisdiction or 'N/A'}\n"
            f"Use case: {use_case or 'N/A'}\n"
            f"Category: {category or 'N/A'}\n\n"
            "Extract:\n"
            "1. topic_core — 3 to 8 words capturing the core subject. "
            "Preserve compound domain concepts (e.g. 'heated tobacco products excise duty'). "
            "Strip generic words: submission, document, letter, regarding, about, a, an, the.\n"
            "2. background_signal — up to 100 characters of domain-relevant facts from the background. "
            "Ignore all drafting instructions (please draft, I need, write a, ensure, include, etc.). "
            "Return only factual content: regulation names, policy references, specific requirements.\n\n"
            "Output ONLY a JSON object with exactly two keys. No explanation.\n"
            'Example: {"topic_core": "heated tobacco products excise duty", '
            '"background_signal": "CBIC notification 2023 duty revision HTP"}'
        )
        try:
            data = {
                "model": LITELLM_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 150,
            }
            headers = {
                "Authorization": f"Bearer {LITELLM_KEY}",
                "Content-Type": "application/json",
            }
            req = urllib.request.Request(
                LITELLM_URL,
                data=json.dumps(data).encode('utf-8'),
                headers=headers,
                method='POST',
            )
            with urllib.request.urlopen(req, context=_SSL_CTX, timeout=15) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                try:
                    from core.langsmith_tracing.llm_usage import record_llm_usage
                    record_llm_usage(res, name='kb_semantic_signal_extraction', response=resp)
                except Exception:
                    pass
                raw = res['choices'][0]['message']['content'].strip()
                if raw.startswith('```'):
                    raw = '\n'.join(raw.split('\n')[1:-1]).strip()
                signals = json.loads(raw)
                if isinstance(signals, dict) and 'topic_core' in signals:
                    result = {
                        'topic_core': str(signals.get('topic_core', '')).strip(),
                        'background_signal': str(signals.get('background_signal', '')).strip(),
                    }
                    logger.info(
                        f"LLM_SIGNAL_EXTRACTION | "
                        f"topic_core='{result['topic_core']}' | "
                        f"background_signal='{result['background_signal']}'"
                    )
                    return result
        except Exception as e:
            logger.warning(f"LLM signal extraction failed, falling back to regex: {e}")

    # Regex fallback — used only when LLM is unavailable or fails
    _STOPWORDS = {
        'a', 'an', 'the', 'for', 'of', 'in', 'on', 'at', 'to', 'with',
        'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be', 'been',
        'about', 'regarding', 'related', 'concerning', 'submission', 'document',
    }
    tokens = re.split(r'[\s,;]+', (topic or '').lower())
    topic_core = ' '.join(t for t in tokens if t and t not in _STOPWORDS and len(t) > 2)

    bg_cleaned = re.sub(
        r'(?i)\b(please|kindly|draft|write|prepare|create|generate|i need|i want|'
        r'can you|could you|help me|assist|ensure|include|provide)\b[^.]*?(?=[A-Z]|\.|$)',
        ' ', background or ''
    )
    background_signal = re.sub(r'\s+', ' ', bg_cleaned).strip()[:150]

    return {'topic_core': topic_core, 'background_signal': background_signal}


def _derive_intent(use_case: str, category: str) -> str:
    """Map use_case/category to a semantic intent phrase for vector search."""
    _INTENT_MAP = {
        'submission': 'regulatory submission compliance',
        'report': 'policy analysis report',
        'communication': 'stakeholder communication',
        'response': 'regulatory response',
        'application': 'regulatory application',
        'representation': 'industry representation',
        'briefing': 'policy briefing',
        'comment': 'public comment regulatory',
        'appeal': 'regulatory appeal',
        'petition': 'regulatory petition',
    }
    combined = f"{use_case} {category}".lower()
    for key, intent in _INTENT_MAP.items():
        if key in combined:
            return intent
    return (use_case or category or '').strip()


def _derive_entity(target_audience: str) -> str:
    """Map target_audience to a semantic entity phrase for vector search."""
    _ENTITY_MAP = {
        'cbic': 'customs excise authority',
        'gst': 'goods services tax authority',
        'mohfw': 'health ministry regulator',
        'ministry of health': 'health ministry regulator',
        'who': 'world health organization international',
        'cpcb': 'environment pollution control authority',
        'fssai': 'food safety standards authority',
        'sebi': 'securities exchange board regulator',
        'rbi': 'reserve bank central authority',
        'parliament': 'legislative authority',
        'committee': 'parliamentary standing committee',
        'ministry': 'government ministry authority',
        'department': 'government department',
        'tribunal': 'judicial regulatory tribunal',
    }
    audience_lower = (target_audience or '').lower()
    for key, entity in _ENTITY_MAP.items():
        if key in audience_lower:
            return entity
    return (target_audience or '').strip()


def _llm_enrich_queries(
    topic_core: str, intent: str, entity: str,
    jurisdiction: str, background_signal: str
) -> List[str]:
    """Call LLM to generate up to 2 semantically enriched vector search queries."""
    if not LITELLM_KEY or not topic_core:
        return []

    prompt = (
        "Generate exactly 2 short semantic search queries for a vector database retrieval task.\n\n"
        "Structured input:\n"
        f"- Topic: {topic_core}\n"
        f"- Intent: {intent}\n"
        f"- Target entity: {entity}\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Domain context: {background_signal or 'N/A'}\n\n"
        "Rules:\n"
        "- Each query must be 5-12 words\n"
        "- Reflect domain document meaning, not user phrasing\n"
        "- Query 1 must be generic and NOT mention any country or jurisdiction.\n"
        "- Query 2 can optionally include the country or jurisdiction.\n"
        "- Queries should match what relevant source documents would contain\n"
        "- Output ONLY a JSON array of 2 strings, no explanation\n\n"
        'Example: ["tobacco excise policy regulatory compliance", '
        '"CBIC heated tobacco products duty submission"]'
    )

    try:
        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=15) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(res, name='kb_query_enrichment', response=resp)
            except Exception:
                pass
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            enriched = json.loads(raw)
            if isinstance(enriched, list):
                return [q for q in enriched if isinstance(q, str) and q.strip()][:2]
    except Exception as e:
        logger.warning(f"LLM query enrichment failed (non-fatal): {e}")
    return []



# ── Main KB search functions ──────────────────────────────────────────────

# ======================================================================
# search_internal_knowledge (lines 2429-2659)
# ======================================================================
def search_internal_knowledge(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Search PMI internal knowledge base using semantic query generation."""

    jurisdiction    = requirements.get('jurisdiction', '')
    topic           = requirements.get('topic', '')
    target_audience = requirements.get('target_audience', '')
    background      = requirements.get('background', '')
    category        = requirements.get('category', '')
    use_case        = requirements.get('use_case', '')

    # Step 1 — Extract semantic signals from raw input fields
    signals           = _extract_semantic_signals(topic, background, use_case, category, jurisdiction)
    topic_core        = signals['topic_core']
    background_signal = signals['background_signal']
    intent            = _derive_intent(use_case, category)
    entity            = _derive_entity(target_audience)

    # Step 2 — Base query: all signals combined including background
    base_query = ' '.join(filter(None, [jurisdiction, topic_core, background_signal, intent, entity])).strip()

    # Step 3 — Deterministic variants covering different signal combinations
    query_1 = ' '.join(filter(None, [jurisdiction, topic_core, background_signal, intent])).strip()
    query_2 = ' '.join(filter(None, [entity, jurisdiction, topic_core, background_signal])).strip()
    query_3 = ' '.join(filter(None, [category, intent, jurisdiction, topic_core, background_signal])).strip()

    # Generic variants without jurisdiction to allow cross-border matches
    query_generic_1 = ' '.join(filter(None, [topic_core, background_signal, intent])).strip()
    query_generic_2 = ' '.join(filter(None, [topic_core, intent, entity, background_signal])).strip()

    seen: set = set()
    deterministic = [
        q for q in [base_query, query_1, query_2, query_3, query_generic_1, query_generic_2]
        if q and not (q in seen or seen.add(q))
    ]

    # Step 4 — LLM enrichment + theme classification IN PARALLEL (both depend only on topic_core)
    # These two LLM calls are independent of each other — overlap them to save ~10-15s.
    from concurrent.futures import ThreadPoolExecutor, as_completed as _as_completed
    _enrich_future = None
    _theme_future = None

    def _get_theme(tc, bg, jur):
        """Theme classification (moved from Step 6a to run in parallel with enrichment)."""
        if not LITELLM_KEY or not tc:
            return ('', '')
        try:
            theme_prompt = (
                "You are classifying a research query for a knowledge base filter.\n\n"
                f"Topic: {tc}\n"
                f"Background: {bg[:200]}\n"
                f"Jurisdiction: {jur}\n\n"
                "LEVEL 1 OPTIONS (pick the single BEST match):\n"
                "- Smoke-free products (SFP)/ heated tobacco products (HTP)\n"
                "- Combustible cigarettes\n"
                "- Corporate Equity\n"
                "- Others\n\n"
                "LEVEL 2 OPTIONS (pick the single BEST match):\n"
                "- Regulatory, Product standard system\n"
                "- Fiscal and Taxes\n"
                "- Illicit Trade\n"
                "- Scientific\n"
                "- Youth Access Prevention\n"
                "- Sustainability\n"
                "- Others\n\n"
                "Return ONLY a JSON: {\"level_1\": \"...\", \"level_2\": \"...\"}\n"
                "If the topic doesn't clearly fit one category, use \"Others\"."
            )
            data = json.dumps({
                "model": LITELLM_MODEL,
                "messages": [{"role": "user", "content": theme_prompt}],
                "max_tokens": 100,
            }).encode('utf-8')
            headers_req = {
                "Authorization": f"Bearer {LITELLM_KEY}",
                "Content-Type": "application/json",
            }
            req = urllib.request.Request(LITELLM_URL, data=data, headers=headers_req, method='POST')
            with urllib.request.urlopen(req, context=_SSL_CTX, timeout=10) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                try:
                    from core.langsmith_tracing.llm_usage import record_llm_usage
                    record_llm_usage(res, name='kb_theme_classification', response=resp)
                except Exception:
                    pass
                raw = res['choices'][0]['message']['content'].strip()
                if raw.startswith('```'):
                    raw = '\n'.join(raw.split('\n')[1:-1]).strip()
                theme_result = json.loads(raw)
                t1 = theme_result.get('level_1', '')
                t2 = theme_result.get('level_2', '')
                if t1 == 'Others':
                    t1 = ''
                if t2 == 'Others':
                    t2 = ''
                logger.info(f"KB_THEME_MAP | topic='{tc[:50]}' | L1='{t1}' | L2='{t2}'")
                return (t1, t2)
        except Exception as e:
            logger.warning(f"KB theme mapping failed (non-fatal): {e}")
            return ('', '')

    with ThreadPoolExecutor(max_workers=2) as _kb_ex:
        _enrich_future = _kb_ex.submit(_llm_enrich_queries, topic_core, intent, entity, jurisdiction, background_signal)
        _theme_future = _kb_ex.submit(_get_theme, topic_core, background_signal, jurisdiction)

    llm_queries = _enrich_future.result() or []
    kb_theme_1, kb_theme_2 = _theme_future.result()

    # Step 4b — Include agentic planned queries if available
    planned_queries = requirements.get('_planned_queries', [])

    # Step 5 — Combine deterministic + LLM + planned, cap at 8 (allow more due to planned)
    all_queries = (deterministic + llm_queries + planned_queries)
    # Deduplicate while preserving order
    seen_q: set = set()
    dedup_queries = []
    for q in all_queries:
        q_lower = q.lower().strip()
        if q_lower and q_lower not in seen_q:
            seen_q.add(q_lower)
            dedup_queries.append(q)
    all_queries = dedup_queries[:8]

    logger.info(
        f"KB_SEMANTIC_QUERIES | count={len(all_queries)} "
        f"| deterministic={len(deterministic)} | llm={len(llm_queries)} | planned={len(planned_queries)}"
    )

    # Step 6 — Execute vector search with score-gated waterfall
    internal_sources: List[Dict] = []
    citations: List[Dict] = []
    used_query = all_queries[0] if all_queries else base_query
    kb_results: List[Dict] = []

    # Theme mapping already done in parallel (Step 4) — kb_theme_1, kb_theme_2 are set

    try:
        if search_pmi_knowledge_base:
            kb_filters = {}
            if jurisdiction:
                kb_filters['jurisdiction'] = jurisdiction

            # First attempt: with theme filters (soft)
            for candidate_query in all_queries:
                results = search_pmi_knowledge_base(
                    query=candidate_query, max_results=15, filters=kb_filters,
                    jurisdiction=jurisdiction, theme_level_1=kb_theme_1, theme_level_2=kb_theme_2
                )
                if results:
                    max_score = max((r.get('similarity_score', 0) for r in results), default=0)
                    logger.info(
                        f"KB_QUERY | query='{candidate_query[:80]}' "
                        f"| results={len(results)} | max_score={max_score:.3f}"
                    )
                    if max_score >= 0.50:
                        kb_results = results
                        used_query = candidate_query
                        logger.info(f"KB_HIT | query='{candidate_query[:80]}'")
                        break
                else:
                    logger.info(f"KB_QUERY | query='{candidate_query[:80]}' | results=0")

            # Fallback: if theme filters produced 0 results, retry without them
            if not kb_results and (kb_theme_1 or kb_theme_2):
                logger.info(f"KB_FALLBACK | theme filters produced 0 results, retrying without theme filters")
                for candidate_query in all_queries:
                    results = search_pmi_knowledge_base(
                        query=candidate_query, max_results=15, filters=kb_filters,
                        jurisdiction=jurisdiction
                    )
                    if results:
                        max_score = max((r.get('similarity_score', 0) for r in results), default=0)
                        if max_score >= 0.50:
                            kb_results = results
                            used_query = candidate_query
                            logger.info(f"KB_FALLBACK_HIT | query='{candidate_query[:80]}' | score={max_score:.3f}")
                            break

            # Category-aware KB result limit
            cat_lower = (category or '').lower()
            if 'white paper' in cat_lower or 'narrative' in cat_lower:
                kb_limit = 8  # More KB sources for comprehensive documents
            else:
                kb_limit = 5

            # Apply limit to kb_results before processing
            kb_results = kb_results[:kb_limit]
            logger.info(f"KB_RESULTS | category={category} | limit={kb_limit} | results={len(kb_results)}")

            seen_titles = set()
            for i, result in enumerate(kb_results):
                if result.get('similarity_score', 0) < 0.50:
                    continue

                doc_name = (
                    result.get('document_title')
                    or result.get('metadata', {}).get('file_name')
                    or f'Document_{i}'
                )
                
                # Extract URL properly from any possible metadata field
                meta = result.get('metadata', {})
                sp_url = (
                    result.get('sharepoint_url') or 
                    meta.get('sharepoint_url') or 
                    meta.get('sharepoint_link') or 
                    meta.get('source_url') or 
                    meta.get('url') or 
                    meta.get('s3_bucket_URL') or 
                    ""
                )
                
                # Exclude metadata.json files from sources and citations
                if 'metadata.json' in str(doc_name).lower() or 'metadata.json' in str(sp_url).lower():
                    continue
                
                internal_sources.append({
                    'title': doc_name,
                    'source': 'PMI Knowledge Base',
                    'type': 'internal_knowledge',
                    'date': datetime.now().strftime('%Y-%m-%d'),
                    'relevance_score': round(float(result.get('similarity_score', 0)), 3),
                    'summary': result.get('content', ''),
                })
                
                # Deduplicate citations and remove snippets
                if doc_name not in seen_titles:
                    seen_titles.add(doc_name)
                    
                    citations.append({
                        'title': f"{doc_name}",
                        'url': sp_url,
                        'source_type': 'knowledge_base'
                    })
    except Exception as e:
        logger.error(f"Error querying KB: {str(e)}")

    if not internal_sources:
        logger.warning("KB search returned no results.")

    return {
        'sources': internal_sources,
        'citations': citations,
        'queries': [used_query] + [q for q in all_queries if q != used_query],
    }


# ======================================================================
# stage_kb (lines 594-596)
# ======================================================================
def stage_kb(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """KB-search stage."""
    return search_internal_knowledge(requirements)


