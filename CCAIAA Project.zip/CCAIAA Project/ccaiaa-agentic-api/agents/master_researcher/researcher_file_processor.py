"""
Researcher File Processor Module (fully standalone).

Provides: read_uploaded_file(), summarize_uploaded_file_with_llm()
"""
import io
import json
import logging
import os
import re
import ssl
import urllib.request
from datetime import datetime
from typing import Dict, Any, List

import boto3

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    DOCUMENT_BUCKET, get_s3_client,
)

s3 = get_s3_client()

# ======================================================================
# read_uploaded_file (lines 2855-2942)
# ======================================================================
def read_uploaded_file(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 1 — Read and extract text from the user-uploaded file stored in S3."""
    s3_key = (requirements.get('uploaded_file_s3_key') or '').strip()
    if not s3_key or 'metadata.json' in s3_key.lower():
        return {'sources': [], 'citations': [], 'queries': []}

    try:
        import io as _io
        response = s3.get_object(Bucket=DOCUMENT_BUCKET, Key=s3_key)
        file_bytes = response['Body'].read()
        file_name = s3_key.split('/')[-1]
        ext = file_name.rsplit('.', 1)[-1].lower() if '.' in file_name else ''

        # Base64 Auto-Decoding Check
        # Zip archives (.docx) always start with the magic bytes b'PK\x03\x04'
        if ext == 'docx' and not file_bytes.startswith(b'PK\x03\x04'):
            try:
                import base64 as _base64
                decoded_bytes = _base64.b64decode(file_bytes)
                if decoded_bytes.startswith(b'PK\x03\x04'):
                    file_bytes = decoded_bytes
                    logger.info("Successfully decoded Base64 encoded docx file from S3.")
            except Exception as b64_err:
                logger.warning(f"Failed to check/decode Base64 docx file: {b64_err}")

        text = ''
        if ext == 'txt':
            text = file_bytes.decode('utf-8', errors='ignore')
        elif ext == 'docx':
            try:
                from docx import Document as _DocxDoc  # type: ignore[import]
                doc = _DocxDoc(_io.BytesIO(file_bytes))
                paragraphs_text = '\n'.join(p.text for p in doc.paragraphs if p.text.strip())
                
                # Extract text from tables as well
                tables_text = []
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            for paragraph in cell.paragraphs:
                                if paragraph.text.strip():
                                    tables_text.append(paragraph.text.strip())
                
                # Combine paragraphs and table texts
                all_text_parts = []
                if paragraphs_text:
                    all_text_parts.append(paragraphs_text)
                if tables_text:
                    all_text_parts.append('\n'.join(tables_text))
                
                text = '\n'.join(all_text_parts)
            except Exception as docx_err:
                logger.warning(f"python-docx extraction failed, falling back to decode: {docx_err}", exc_info=True)
                text = file_bytes.decode('utf-8', errors='ignore')
        elif ext == 'pdf':
            try:
                import PyPDF2 as _PyPDF2
                reader = _PyPDF2.PdfReader(_io.BytesIO(file_bytes))
                text = '\n'.join(page.extract_text() for page in reader.pages if page.extract_text())
            except Exception as pdf_err:
                logger.warning(f"PyPDF2 extraction failed, falling back: {pdf_err}", exc_info=True)
                raw = file_bytes.decode('latin-1', errors='ignore')
                text = re.sub(r'[^\x20-\x7E\n]', ' ', raw)
                text = re.sub(r'\s+', ' ', text).strip()
        else:
            text = file_bytes.decode('utf-8', errors='ignore')

        # Read up to 100,000 characters to capture more of large documents
        text = text[:100000]
        
        # Summarize contextually with Bedrock LLM
        summarized_text = summarize_uploaded_file_with_llm(text, requirements)
        
        logger.info(f"UPLOADED_FILE_READ | key='{s3_key}' | ext={ext} | raw_chars={len(text)} | summary_chars={len(summarized_text)}")
        return {
            'sources': [{
                'title': file_name,
                'source': f's3://{DOCUMENT_BUCKET}/{s3_key}',
                'type': 'uploaded_file',
                'date': datetime.now().strftime('%Y-%m-%d'),
                'summary': summarized_text,
            }],
            'citations': [{'title': file_name, 'url': '', 'source_type': 'uploaded_file'}],
            'queries': [],
        }
    except Exception as e:
        logger.warning(f"Failed to read uploaded file '{s3_key}': {e}")
        return {'sources': [], 'citations': [], 'queries': []}


# ======================================================================
# summarize_uploaded_file_with_llm (lines 2661-2778)
# ======================================================================
def summarize_uploaded_file_with_llm(text: str, requirements: Dict[str, Any]) -> str:
    """Enhanced file summarizer: extracts BOTH facts/evidence AND structure/form/intent.

    Captures three dimensions:
      A. FACTS & EVIDENCE — statistics, laws, citations, dates (tagged with source jurisdiction)
      B. STRUCTURE & FORM — section sequence, argument flow, format style, tone, the asks
      C. INTENT SUMMARY — purpose and outcome of the document

    Also receives tone_requirements (previously missing) and detects exemplar/similar intent
    from the background field so it can prioritize form extraction for "make a similar doc" requests.
    """
    if not LITELLM_KEY or not text.strip():
        return text[:3000]  # Raised fallback from 2000

    topic = requirements.get('topic', 'General Topic')
    background = requirements.get('background', '')
    jurisdiction = requirements.get('jurisdiction', 'Global')
    target_audience = requirements.get('target_audience', 'General')
    target_lang = requirements.get('target_language', 'English')
    category = requirements.get('category', '')
    use_case = requirements.get('use_case', '')
    tone_requirements = requirements.get('tone_requirements', '')  # NEW: was missing

    # Detect if this is a Letters scenario
    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()
    is_letter = 'letter' in cat_lower or 'letter' in uc_lower

    extra_context = ""
    if is_letter:
        subject = requirements.get('topic_of_letter') or requirements.get('topicOfLetter') or ''
        if subject:
            extra_context = f"\n- Subject of the Letter: {subject}"

    # Detect "exemplar/similar" intent from background
    _bg_lower = (background or '').lower()
    is_exemplar = any(cue in _bg_lower for cue in [
        'similar submission', 'similar document', 'similar letter', 'similar draft',
        'refer to attached', 'based on the attached', 'along the lines',
        'replicate', 'mirror this', 'same format', 'use as template',
        'create a similar', 'prepare a similar',
    ])

    exemplar_instruction = ""
    if is_exemplar:
        exemplar_instruction = (
            "\n⚠️ IMPORTANT: This file is an EXEMPLAR/TEMPLATE — the user wants to CREATE A "
            f"SIMILAR DOCUMENT for a DIFFERENT context (target: {jurisdiction}). Focus HEAVILY "
            "on extracting the STRUCTURE, ARGUMENT FLOW, and FORMAT in section B below. "
            f"Tag all facts with their SOURCE jurisdiction — do NOT assert them as facts about {jurisdiction}.\n"
        )

    prompt = f"""You are an expert corporate research assistant supporting a regulatory affairs team.
Your task is to analyze the uploaded file and extract both its CONTENT and its STRUCTURE in the context of the user's request.

RESEARCH CONTEXT:
- Category: {category}
- Target Country/Jurisdiction: {jurisdiction}
- Research Topic: {topic}
- Background: {background or 'N/A'}
- Target Audience: {target_audience or 'N/A'}
- Tone Requirements: {tone_requirements or 'N/A'}{extra_context}
{exemplar_instruction}
Uploaded File Content:
<file_content>
{text}
</file_content>

EXTRACT THE FOLLOWING (be exhaustive, do NOT invent facts not in the file):

## A. FACTS & EVIDENCE
- Key statistics, percentages, dollar amounts, specific dates
- Named legislation, regulatory bodies, authorities cited
- Scientific studies, clinical data, regulatory decisions referenced
- Named organizations, individuals, or specific policy positions
- TAG each fact with its source jurisdiction in brackets (e.g., [Vietnam], [Global]) when it differs from the target jurisdiction "{jurisdiction}"

## B. STRUCTURE & FORM
- Document type and format (letter, briefing note, white paper, submission, etc.)
- Section/argument sequence (numbered list of how the document flows from start to end)
- Opening framing and closing approach
- Tone and register (formal/informal, advocacy/neutral, balanced, etc.)
- Who it is addressed to, who it is from, what it explicitly asks/requests
- Any distinctive stylistic patterns (paragraph length, use of headings, citations style)

## C. INTENT SUMMARY
- In 2-3 sentences: what is the PURPOSE of this document and what outcome does it seek?

Write the output directly in {target_lang}. Prioritize completeness — capture the full gist."""

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 3500,  # Raised from 2000 for structure+facts+intent
            "temperature": 0.2,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(res, name='file_processor_summarize', response=resp)
            except Exception:
                pass
            summary = res['choices'][0]['message']['content'].strip()
            return summary
    except Exception as e:
        logger.warning(f"LLM uploaded file summarization failed, falling back: {e}")
        return text[:3000]


