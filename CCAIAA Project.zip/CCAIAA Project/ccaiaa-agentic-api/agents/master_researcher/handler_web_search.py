"""Split-research stage lambda: WEB SEARCH.

Multi-query Tavily web search via the private gateway.

Event payload:
    {"request_id": str, "requirements": {...enriched by planner...}, "langsmith_headers": {...}}
Returns:
    {"sources": [...], "citations": [...], "queries": [...], "langsmith_headers": {...}}

LangSmith tracing: one of 4 parallel ParallelResearch branches — receives
the propagated trace context from the state machine's Parameters block
(langsmith_headers.$ sourced from $.planner_output.langsmith_headers, same
upstream all 4 branches read `requirements` from) and nests its own child
span under it. See handler_planner.py for the canonical pattern.
"""
import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (MUST import before langsmith)

try:
    import researcher_web as web
except ImportError:
    from agents.master_researcher import researcher_web as web

from core.researcher_common import logger

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers,
        attach_outgoing_langsmith_headers,
    )
    _LANGSMITH_TRACING_AVAILABLE = True
except Exception:
    _LANGSMITH_TRACING_AVAILABLE = False

    def traceable(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator if not args else _decorator(args[0])

    def get_incoming_langsmith_headers(event):
        return {}

    def attach_outgoing_langsmith_headers(result, run_tree):
        return result


@traceable(name="research_web_search", run_type="chain")
def _traced_search(requirements, request_id, run_tree=None):
    result = web.stage_web(requirements, request_id)
    result = attach_outgoing_langsmith_headers(result, run_tree)
    # Ensure langsmith_headers is always present, even if empty
    if 'langsmith_headers' not in result:
        result['langsmith_headers'] = {}
    return result


def lambda_handler(event, context):
    request_id = str(event.get('request_id') or 'unknown')
    requirements = event.get('requirements', {}) or {}
    logger.info(f"[{request_id}] STAGE web_search start")

    if not _LANGSMITH_TRACING_AVAILABLE:
        return _traced_search(requirements, request_id)

    from langsmith.run_helpers import tracing_context
    incoming_headers = get_incoming_langsmith_headers(event)
    with tracing_context(parent=incoming_headers):
        return _traced_search(requirements, request_id)
