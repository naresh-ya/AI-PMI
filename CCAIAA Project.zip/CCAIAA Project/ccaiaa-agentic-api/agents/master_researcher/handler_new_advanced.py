"""
Master Researcher Agent for PMI Agentic AI Platform

This agent orchestrates comprehensive research across multiple sources to gather
all necessary information for government submission generation.

Responsibilities:
- Coordinate research across PMI internal sources
- Query academic databases (PubMed, Scopus)
- Crawl government websites (CBIC, MoHFW, WHO)
- Compile and synthesize research findings
- Generate comprehensive research report with citations

LangSmith tracing: This is the monolith researcher used by demo1 (not the split
pipeline). If demo1 still exists in production, this handler needs trace
propagation + record_llm_usage on all LLM calls just like the split handlers.
See agents/input_validator/handler_new_validator.py for the canonical pattern
this mirrors (root of trace if no incoming header, middle-of-pipeline if
invoked after input_validator).
"""

import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (MUST import before langsmith)

import json
import logging
from typing import Dict, Any, List
from datetime import datetime
import boto3
from concurrent.futures import ThreadPoolExecutor, as_completed
import re
import ssl
import base64
# Prompt is now loaded dynamically from core.prompt_registry

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

import os
import sys

# Add root directory to path to allow imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
try:
    from core.kb_integration_new import search_pmi_knowledge_base
except ImportError:
    logger.warning("Could not import search_pmi_knowledge_base")
    search_pmi_knowledge_base = None

import urllib.request
import ssl
import json
import os

# Set LiteLLM API key — aligns with client-demo1 Lambda env var name
LITELLM_KEY = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
LITELLM_URL = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions'
# Model override via env var — use claude-3-haiku locally (no guardrail, on-demand supported)
# Lambda sets this to the Sonnet 4 inference profile via LITELLM_MODEL env var
#
# Per-task model tiering:
#   LLM_MODEL_REASONING -> Opus (critical decisions + critic loops: understanding, relevance judge, synthesis)
#   LITELLM_MODEL/DEFAULT -> Sonnet (the workhorse for everything else)
#   LLM_MODEL_FAST -> Haiku (reserved for cheap extraction/formatting)
LITELLM_MODEL = (
    os.environ.get('LLM_MODEL_DEFAULT')
    or os.environ.get('LITELLM_MODEL')
    or 'bedrock/us.anthropic.claude-sonnet-4-6'
)
LLM_MODEL_REASONING = os.environ.get('LLM_MODEL_REASONING', 'bedrock/us.anthropic.claude-opus-4-8')
LLM_MODEL_FAST = os.environ.get('LLM_MODEL_FAST', 'bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0')

# Reranker (Cohere Rerank v3.5 via LiteLLM /rerank). Confirmed working endpoint.
# Cross-encoder reranking is the primary relevancy signal applied before final top-k.
LITELLM_RERANK_URL = os.environ.get(
    'AWS_LITELLM_RERANK_ENDPOINT', 'https://litellm.aiplat-dev.aws.private-pmideep.biz/rerank'
)
LITELLM_RERANK_MODEL = os.environ.get(
    'AWS_LITELLM_RERANK_MODEL',
    'bedrock/arn:aws:bedrock:us-east-1::foundation-model/cohere.rerank-v3-5:0'
)
# Sources scoring below this rerank score are dropped — but only if enough on-topic
# sources remain (we never starve synthesis). Tunable via env.
RERANK_MIN_SCORE = float(os.environ.get('RERANK_MIN_SCORE', '0.02'))

# Gemini model used for parallel URL extraction and web search comparison.
# Overridable via env var — defaults to gemini-2.5-pro (same as test_websearch_tool.py).
GEMINI_MODEL = os.environ.get('GEMINI_MODEL', 'gemini-2.5-pro')

# Gemini-vs-Tavily comparison harness toggle. This is an EVALUATION-ONLY feature:
# it fires extra Gemini calls in parallel with Tavily and writes a gemini_comparison.json
# to S3 for humans to compare engines. It does NOT affect the document the drafter
# produces. OFF by default to avoid the added latency (blocking waits) and API cost.
# Set ENABLE_GEMINI_COMPARISON=true to turn it back on for benchmarking.
ENABLE_GEMINI_COMPARISON = os.environ.get('ENABLE_GEMINI_COMPARISON', 'false').strip().lower() in ('1', 'true', 'yes', 'on')

# Thread-safe accumulator for Gemini comparison data collected during a research run.
# Keyed by request_id so concurrent Lambda invocations don't cross-contaminate.
# Cleared at the start of each research run in conduct_comprehensive_research.
import threading
_gemini_comparison_store: Dict[str, Any] = {}
_gemini_comparison_lock = threading.Lock()

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
requests_table = dynamodb.Table(os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests'))
DOCUMENT_BUCKET = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')
TAVILY_API_KEY = os.environ.get('TAVILY_API_KEY', '')
curated_links_table = dynamodb.Table(os.environ.get('CURATED_LINKS_TABLE', 'pmi-agentic-ai-curated-links'))

# ── Token-budget observability (heuristic, NOT tiktoken) ──────────────────────
# Preflight: warn when the input prompt approaches a soft budget (chars/4 estimate;
# Claude/Bedrock tokenizers are not OpenAI BPE). Postflight: detect OUTPUT truncation
# (the real silent-failure mode) — for the synthesis call a truncated response means
# invalid/incomplete JSON, which silently degrades to empty findings downstream.
PROMPT_SOFT_BUDGET_TOKENS = int(os.environ.get('PROMPT_SOFT_BUDGET_TOKENS', '150000'))

# Default document tone when the request omits tone_requirements. Single source of truth
# so the researcher framing and the drafter never regress to divergent hardcoded literals.
DEFAULT_TONE = "formal, neutral, compliance-first, fact-based and non-promotional"


def _estimate_tokens(text: str) -> int:
    """Rough, model-agnostic token estimate (~4 chars/token). For logging only."""
    return (len(text) // 4) if text else 0


def _preflight_prompt_budget(system_prompt: str, user_prompt: str, label: str,
                             request_id: str = 'unknown') -> int:
    est = _estimate_tokens(system_prompt) + _estimate_tokens(user_prompt)
    if est >= PROMPT_SOFT_BUDGET_TOKENS:
        logger.warning(
            f"[{request_id}] TOKEN_PREFLIGHT | label='{label}' | est_input_tokens=~{est} "
            f">= soft_budget={PROMPT_SOFT_BUDGET_TOKENS} | consider trimming injected sources."
        )
    else:
        logger.info(f"[{request_id}] TOKEN_PREFLIGHT | label='{label}' | est_input_tokens=~{est}")
    return est


def _check_response_truncation(res: Dict[str, Any], label: str, request_id: str = 'unknown') -> bool:
    """Detect OUTPUT truncation (hit max_tokens) from the OpenAI-compatible response."""
    try:
        finish_reason = None
        choices = res.get('choices') or []
        if choices and isinstance(choices[0], dict):
            finish_reason = choices[0].get('finish_reason')
        native_stop = res.get('stop_reason')
        truncated = (finish_reason == 'length') or (native_stop in ('max_tokens', 'length'))
        if truncated:
            logger.warning(
                f"[{request_id}] TOKEN_POSTFLIGHT | label='{label}' | OUTPUT TRUNCATED "
                f"(finish_reason={finish_reason!r}, stop_reason={native_stop!r}) — response is "
                f"incomplete (hit max_tokens). Raise max_tokens or reduce input."
            )
        return truncated
    except Exception as e:
        logger.warning(f"[{request_id}] TOKEN_POSTFLIGHT | label='{label}' | truncation check failed: {e}")
        return False


# ── Split-research orchestration (Option A) ──────────────────────────────────
# When USE_SPLIT_RESEARCH is ON, this Lambda acts as a ROUTER: it invokes the six
# stage Lambdas (planner → kb/user_sources/curated/web in parallel → synthesis) via
# in-memory RequestResponse invokes and relays the synthesis result. When OFF (default)
# the monolith path (conduct_comprehensive_research + build_research_output) runs inline.
# The Step Functions definition, the S3 research_data.json contract, and the
# RESEARCH_COMPLETED DynamoDB status are IDENTICAL in both paths.
USE_SPLIT_RESEARCH = os.environ.get('USE_SPLIT_RESEARCH', 'false').strip().lower() in ('1', 'true', 'yes', 'on')
SPLIT_LAMBDA_NAMES = {
    'planner':      os.environ.get('RESEARCH_PLANNER_FUNCTION',  'pmi-research-planner-client-demo1'),
    'kb':           os.environ.get('RESEARCH_KB_FUNCTION',       'pmi-research-kb-client-demo1'),
    'user_sources': os.environ.get('RESEARCH_USERSRC_FUNCTION',  'pmi-research-usersrc-client-demo1'),
    'web':          os.environ.get('RESEARCH_WEB_FUNCTION',      'pmi-research-web-client-demo1'),
    'curated':      os.environ.get('RESEARCH_CURATED_FUNCTION',  'pmi-research-curated-client-demo1'),
    'synthesis':    os.environ.get('RESEARCH_SYNTHESIS_FUNCTION','pmi-research-synthesis-client-demo1'),
}
_lambda_client = boto3.client('lambda')

# ── Jurisdiction context file loader ─────────────────────────────────────────
_JURISDICTION_CONTEXT_CACHE: Dict[str, str] = {}

# Max characters of jurisdiction ground-truth injected into any LLM prompt.
# Sized to fit the largest jurisdiction file in full (~6.5k chars) so the
# compliance-critical tail sections (APPROVED TERMINOLOGY / AVOID / statistics)
# are never truncated. Shared by the researcher and drafter for consistency.
JURISDICTION_CTX_MAX = 8000

def _load_jurisdiction_context(jurisdiction: str) -> str:
    """Load jurisdiction context markdown file from templates/jurisdiction/.
    Returns the full file content or empty string if not found.
    Cached after first load to avoid repeated file I/O.

    With PROMPT_MGMT_ENABLED=true, resolves from Bedrock Prompt Management first
    (fail-open to local disk if Bedrock is unreachable or missing).
    """
    if not jurisdiction:
        return ''
    key = jurisdiction.strip().lower()
    if key in _JURISDICTION_CONTEXT_CACHE:
        return _JURISDICTION_CONTEXT_CACHE[key]

    # ── Phase 2: Try Bedrock Prompt Management first ─────────────────────────
    try:
        try:
            from core import bedrock_prompt_client as _bpc
        except ImportError:
            import bedrock_prompt_client as _bpc
        if _bpc.is_enabled():
            bedrock_name = f"ccaiaa-jurisdiction-{key}"
            text = _bpc.get_prompt_text(bedrock_name)
            if text:
                logger.info(f"JURISDICTION_CONTEXT | source=bedrock | name={bedrock_name} ({len(text)} chars)")
                _JURISDICTION_CONTEXT_CACHE[key] = text
                return text
            else:
                logger.info(f"JURISDICTION_CONTEXT | bedrock miss for '{bedrock_name}', falling back to disk")
    except Exception as e:
        logger.warning(f"JURISDICTION_CONTEXT | bedrock error ({e}), falling back to disk")

    # ── Fallback: local disk read (original behavior) ────────────────────────
    # Resolve templates/jurisdiction across environments:
    #   - AWS Lambda: handler.py at package root, templates/ copied alongside
    #   - Local dev:  handler at agents/master_researcher/, templates at repo root
    here = os.path.dirname(os.path.abspath(__file__))
    candidate_dirs = [
        os.path.join(here, 'templates', 'jurisdiction'),
        os.path.join(here, os.pardir, 'templates', 'jurisdiction'),
        os.path.join(here, os.pardir, os.pardir, 'templates', 'jurisdiction'),
    ]
    filenames = [f'{key}.md', f'{jurisdiction.strip()}.md']

    content = ''
    for d in candidate_dirs:
        for fn in filenames:
            fp = os.path.normpath(os.path.join(d, fn))
            if os.path.exists(fp):
                try:
                    with open(fp, 'r', encoding='utf-8') as f:
                        content = f.read()
                    logger.info(f"JURISDICTION_CONTEXT | source=disk | loaded '{fn}' ({len(content)} chars)")
                except Exception as e:
                    logger.warning(f"JURISDICTION_CONTEXT | failed to load '{fn}': {e}")
                break
        if content:
            break

    if not content:
        logger.info(f"JURISDICTION_CONTEXT | no file found for '{key}'")

    _JURISDICTION_CONTEXT_CACHE[key] = content
    return content


# ── Output-template (section structure) file loader ──────────────────────────
# Mirrors the drafter's category→template mapping so the RESEARCHER knows the
# document's section structure up front and can target evidence per section.
_TEMPLATE_CONTEXT_CACHE: Dict[str, str] = {}

_CATEGORY_TEMPLATE_MAP = {
    "Official PMI Submission": "official-pmi-submission.md",
    "Third Party Submission":  "third-party-submission.md",
    "White Papers":            "white-papers.md",
    "Internal Communications": "internal-communications.md",
    "Media Releases":          "media-releases.md",
    "Narrative Builder":       "narrative-builder.md",
}


def _load_output_template(category: str) -> str:
    """Load the category output-section template markdown from templates/.

    Returns the file content (section structure + anti-duplication/tone rules) or ''
    if no mapping/file is found. Cached after first load.

    With PROMPT_MGMT_ENABLED=true, resolves from Bedrock Prompt Management first
    (fail-open to local disk if Bedrock is unreachable or missing).
    """
    if not category:
        return ''
    key = category.strip()
    if key in _TEMPLATE_CONTEXT_CACHE:
        return _TEMPLATE_CONTEXT_CACHE[key]

    filename = _CATEGORY_TEMPLATE_MAP.get(key, '')
    if not filename:
        logger.info(f"OUTPUT_TEMPLATE | no template mapping for category '{category}'")
        _TEMPLATE_CONTEXT_CACHE[key] = ''
        return ''

    # ── Phase 2: Try Bedrock Prompt Management first ─────────────────────────
    try:
        try:
            from core import bedrock_prompt_client as _bpc
        except ImportError:
            import bedrock_prompt_client as _bpc
        if _bpc.is_enabled():
            import re as _re
            slug = _re.sub(r"[^a-zA-Z0-9]+", "-", key.lower()).strip("-")
            bedrock_name = f"ccaiaa-template-{slug}"
            text = _bpc.get_prompt_text(bedrock_name)
            if text:
                logger.info(f"OUTPUT_TEMPLATE | source=bedrock | name={bedrock_name} ({len(text)} chars)")
                _TEMPLATE_CONTEXT_CACHE[key] = text
                return text
            else:
                logger.info(f"OUTPUT_TEMPLATE | bedrock miss for '{bedrock_name}', falling back to disk")
    except Exception as e:
        logger.warning(f"OUTPUT_TEMPLATE | bedrock error ({e}), falling back to disk")

    # ── Fallback: local disk read (original behavior) ────────────────────────
    here = os.path.dirname(os.path.abspath(__file__))
    candidate_dirs = [
        os.path.join(here, 'templates'),
        os.path.join(here, os.pardir, 'templates'),
        os.path.join(here, os.pardir, os.pardir, 'templates'),
    ]

    content = ''
    for d in candidate_dirs:
        fp = os.path.normpath(os.path.join(d, filename))
        if os.path.exists(fp):
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    content = f.read()
                logger.info(f"OUTPUT_TEMPLATE | source=disk | loaded '{filename}' ({len(content)} chars)")
            except Exception as e:
                logger.warning(f"OUTPUT_TEMPLATE | failed to load '{filename}': {e}")
            break

    if not content:
        logger.info(f"OUTPUT_TEMPLATE | no file found for category '{category}' (file={filename})")

    _TEMPLATE_CONTEXT_CACHE[key] = content
    return content


def build_research_output(research_results: Dict[str, Any], document_requirements: Dict[str, Any],
                          request_id: str, research_start: datetime) -> Dict[str, Any]:
    """Synthesize findings, persist to S3, assemble the canonical research_summary,
    mark RESEARCH_COMPLETED, and return it.

    Extracted from lambda_handler so BOTH the monolith and the split synthesis lambda
    produce the IDENTICAL output contract (return shape + S3 object + status). Do not
    change the shape here without updating the drafter/UI consumers.
    """
    # Synthesize research findings using Bedrock
    synthesis_result = synthesize_research_findings(research_results, document_requirements)

    # Persist full research data (all_sources + synthesis) to S3 so the drafter can load it
    research_s3_key = _store_research_to_s3(request_id, research_results, synthesis_result)

    # Build structured sources deterministically from research results
    structured_sources = build_structured_sources(research_results)

    # Derive FE-aligned fields from structured_sources — single source of truth
    citation_count = len(research_results.get('formatted_citations', []))
    jurisdiction   = document_requirements.get('jurisdiction', 'the target jurisdiction')

    # Group by source_type so sources_found always matches the sources array exactly
    _ALL_TYPES = ('knowledge_base', 'uploaded_file', 'internal_url', 'web_search', 'external_url')
    type_counts: Dict[str, int] = {t: 0 for t in _ALL_TYPES}
    for s in structured_sources:
        t = s.get('source_type', '')
        if t in type_counts:
            type_counts[t] += 1

    sources_found = {t: {'count': c} for t, c in type_counts.items() if c > 0}

    total_sources = len(structured_sources)
    research_strategy = {
        'approach': (
            f"Multi-source research across {total_sources} source(s) covering PMI internal "
            f"knowledge base and web search for {jurisdiction}."
        )
    }

    # ── Compute aggregate quality scores from real per-source relevance scores ─
    all_real_scores = [
        s['relevance_score']
        for s in structured_sources
        if s.get('relevance_score') is not None and s.get('relevance_score', 0) > 0
    ]
    kb_scores = [
        s['relevance_score']
        for s in structured_sources
        if s.get('source_type') == 'knowledge_base'
        and s.get('relevance_score') is not None
    ]

    if all_real_scores:
        confidence_score     = round(sum(all_real_scores) / len(all_real_scores), 1)
        source_quality_score = max(all_real_scores)
    else:
        confidence_score     = 0.0
        source_quality_score = 0

    if kb_scores:
        evidence_quality_score = round(sum(kb_scores) / len(kb_scores), 1)
    else:
        evidence_quality_score = confidence_score

    elapsed_seconds  = round((datetime.now() - research_start).total_seconds(), 1)
    research_duration = f"{elapsed_seconds}s"

    logger.info(
        f"[{request_id}] Scores | confidence={confidence_score} "
        f"| source_quality={source_quality_score} "
        f"| evidence_quality={evidence_quality_score} "
        f"| duration={research_duration}"
    )

    research_summary = {
        "status": "success",
        "request_id": request_id,
        "research_summary": {
            "total_sources": len(research_results.get('all_sources', [])),
            "uploaded_file_sources": research_results.get('uploaded_file_count', 0),
            "kb_sources": research_results.get('kb_count', 0),
            "external_link_sources": research_results.get('external_links_count', 0),
            "internal_link_sources": research_results.get('internal_links_count', 0),
            "web_search_sources": research_results.get('web_search_count', 0),
            "confidence_score":    confidence_score,
            "research_duration":   research_duration,
            "relevant_sources":    research_results.get('_relevant_count', 0),
            "low_relevance":       research_results.get('_low_relevance', False),
        },
        "key_findings": synthesis_result.get('key_findings', []),
        "policy_insights": synthesis_result.get('policy_insights', []),
        "recommendations": synthesis_result.get('recommendations', []),
        "research_s3_key": research_s3_key,
        "citations": research_results.get('formatted_citations', []),
        "next_agent": "master_drafter",
        "research_metadata": {
            "search_queries": research_results.get('search_queries', []),
            "source_quality_score": source_quality_score,
            "coverage_assessment": "Comprehensive - All required topics covered",
            "total_sources": len(research_results.get('all_sources', [])),
            "consolidated_score": research_results.get('consolidated_score', 0.0),
            "web_search_triggered": research_results.get('web_search_triggered', False),
            "research_framing": research_results.get('_research_framing', {}),
        },
        "citation_count": citation_count,
        "evidence_quality_score": evidence_quality_score,
        "knowledge_gaps": synthesis_result.get('knowledge_gaps', []),
        "data_quality_flags": synthesis_result.get('data_quality_flags', []),
        "relevant_source_count": research_results.get('_relevant_count', 0),
        "low_relevance": research_results.get('_low_relevance', False),
        "sources_found": sources_found,
        "research_strategy": research_strategy,
        "policy_intelligence": None,
        "sources": structured_sources,
    }

    uploaded_file_summary = ""
    for source in research_results.get('all_sources', []):
        if source.get('type') == 'uploaded_file':
            uploaded_file_summary = source.get('summary', '')
            break

    update_request_status(
        request_id,
        'RESEARCH_COMPLETED',
        'Research completed successfully',
        research_output=research_summary,
        uploaded_file_summary=uploaded_file_summary
    )
    logger.info(
        f"[{request_id}] Research completed: {len(structured_sources)} sources, "
        f"{citation_count} citations"
    )
    return research_summary


try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers,
        attach_outgoing_langsmith_headers,
    )
    _LANGSMITH_TRACING_AVAILABLE = True
except Exception:
    _LANGSMITH_TRACING_AVAILABLE = False

    def traceable(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator if not args else _decorator(args[0])

    def get_incoming_langsmith_headers(event):
        return {}

    def attach_outgoing_langsmith_headers(result, run_tree):
        return result


@traceable(name="monolith_researcher", run_type="chain")
def _traced_research(event, context, run_tree=None):
    """
    Lambda handler for Master Researcher Agent
    
    Args:
        event: Contains validation result and request data
        context: Lambda context object
        
    Returns:
        Research result with compiled findings and citations
    """
    
    try:
        research_start = datetime.now()   # total Lambda execution timer starts here
        logger.info(f"Starting research phase for request: {event.get('request_id')}")

        request_id = event.get('request_id')
        validation_result = event.get('validation_result', {})
        
        # Unwrap Step Function ResultSelector if present
        if 'output' in validation_result:
            validation_result = validation_result['output']
            
        # Unwrap API Gateway string body
        if isinstance(validation_result, dict) and 'body' in validation_result:
            body = validation_result['body']
            if isinstance(body, str):
                import json
                try:
                    body = json.loads(body)
                except Exception:
                    pass
            validation_result = body
            
        if not request_id and isinstance(validation_result, dict):
            request_id = validation_result.get('request_id')
        request_id = str(request_id or 'unknown')

        document_requirements = validation_result.get('document_requirements', {})

        # ── Re-research path (triggered after human review via HITL) ──────────
        # Step Function injects is_re_research=True, human_feedback, approved_sources
        # when the reviewer chose "revise" in the HITL checkpoint.
        is_re_research   = bool(event.get('is_re_research', False))
        human_feedback   = (event.get('human_feedback') or '').strip()
        approved_sources = event.get('approved_sources') or []   # sources human kept
        hitl_retry_count = int(event.get('hitl_retry_count', 0))

        if is_re_research:
            # Inject feedback so KB query enrichment (_llm_enrich_queries) and
            # synthesis can use it as additional context
            document_requirements['re_research_feedback'] = human_feedback
            update_request_status(
                request_id, 'RE_RESEARCH_IN_PROGRESS',
                f'Re-research initiated based on human feedback (attempt {hitl_retry_count})'
            )
            logger.info(
                f"[{request_id}] Re-research | retry={hitl_retry_count} "
                f"| approved_sources={len(approved_sources)} "
                f"| feedback='{human_feedback[:80]}'"
            )
        else:
            # Update request status
            update_request_status(request_id, 'RESEARCH_IN_PROGRESS', 'Research phase initiated')

        # Execute research across multiple sources
        if USE_SPLIT_RESEARCH:
            logger.info(f"[{request_id}] USE_SPLIT_RESEARCH=ON — routing to split stage lambdas")
            result = _run_split_research(
                document_requirements, request_id, research_start,
                approved_sources=(approved_sources if is_re_research else None),
            )
            return attach_outgoing_langsmith_headers(result, run_tree)

        research_results = conduct_comprehensive_research(document_requirements, request_id)

        # On re-research: prepend the human-approved sources from the previous round
        # so the synthesiser sees them as high-quality, pre-validated context
        if is_re_research and approved_sources:
            research_results['all_sources'] = approved_sources + research_results['all_sources']
            logger.info(
                f"[{request_id}] Merged {len(approved_sources)} approved sources "
                f"with {len(research_results['all_sources']) - len(approved_sources)} new sources"
            )

        # Synthesize + persist + assemble the canonical research_summary (shared with split)
        result = build_research_output(research_results, document_requirements, request_id, research_start)
        return attach_outgoing_langsmith_headers(result, run_tree)

    except Exception as e:
        logger.error(f"Error in research phase: {str(e)}")
        request_id = event.get('request_id', 'unknown')
        update_request_status(request_id, 'RESEARCH_FAILED', f'Research failed: {str(e)}')
        
        raise e


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Real Lambda entry point — establishes tracing context, delegates to _traced_research."""
    if not _LANGSMITH_TRACING_AVAILABLE:
        return _traced_research(event, context)

    from langsmith.run_helpers import tracing_context
    incoming_headers = get_incoming_langsmith_headers(event)
    with tracing_context(parent=incoming_headers):
        return _traced_research(event, context)


# ═══════════════════════════════════════════════════════════════════════════════
# Split-research stage entry points + router (Option A)
# ───────────────────────────────────────────────────────────────────────────────
# Each stage_* function is a thin, JSON-clean wrapper around the SAME shared functions
# the monolith uses. The six sub-lambda handler files import this module and delegate
# to these. The router (_run_split_research) is only reached when USE_SPLIT_RESEARCH is
# ON; otherwise lambda_handler runs the monolith path unchanged.
# ═══════════════════════════════════════════════════════════════════════════════

def _seed_research_results() -> Dict[str, Any]:
    """Empty research_results envelope — identical shape to the monolith's Phase 1 seed."""
    return {
        'all_sources': [],
        'uploaded_file_count': 0,
        'kb_count': 0,
        'external_links_count': 0,
        'internal_links_count': 0,
        'web_search_count': 0,
        'consolidated_score': 0.0,
        'web_search_triggered': True,
        'formatted_citations': [],
        'search_queries': [],
    }


def stage_plan(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Planner stage: returns requirements enriched with framing + planned queries."""
    enriched = plan_research(requirements, request_id)
    return {'requirements': enriched}


def stage_kb(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """KB-search stage."""
    return search_internal_knowledge(requirements)


def stage_user_sources(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """User-provided sources stage: uploaded file + user external links combined.

    If the file was already processed by the FileProcessor stage (runs before the planner),
    the pre-processed source is reused here instead of re-reading and re-summarizing the file.
    External-URL fetch always runs regardless.
    """
    merged = {'sources': [], 'citations': [], 'queries': []}

    # Uploaded file: use pre-processed source if available, otherwise read as before
    pre_processed = requirements.get('_uploaded_file_source')
    if pre_processed:
        merged['sources'].append(pre_processed)
        merged['citations'].append({
            'title': pre_processed.get('title', ''),
            'url': '', 'source_type': 'uploaded_file',
        })
        logger.info(f"[{request_id}] user_sources: using pre-processed file source from FileProcessor")
    else:
        try:
            out = read_uploaded_file(requirements) or {}
            merged['sources'].extend(out.get('sources', []))
            merged['citations'].extend(out.get('citations', []))
            merged['queries'].extend(out.get('queries', []))
        except Exception as e:
            logger.error(f"[{request_id}] user_sources file read failed: {e}")

    # External URLs: always processed here (unchanged)
    try:
        out = fetch_user_external_links(requirements) or {}
        merged['sources'].extend(out.get('sources', []))
        merged['citations'].extend(out.get('citations', []))
        merged['queries'].extend(out.get('queries', []))
    except Exception as e:
        logger.error(f"[{request_id}] user_sources ext links failed: {e}")

    return merged


def stage_curated(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Curated internal weblinks stage."""
    return fetch_internal_weblinks(requirements)


def stage_web(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Web-search stage. existing_sources=[] — global URL dedup happens in synthesis."""
    return run_web_search_stage(requirements, [], request_id)


def _aggregate_stage_sources(stage_outputs: Dict[str, Dict[str, Any]], request_id: str) -> Dict[str, Any]:
    """Merge the parallel retrieval stage outputs into a single research_results envelope,
    replicating the monolith's Phase 1/2 merge + consolidated-score computation. Counts are
    provisional here; finalize_research_results recomputes them by source type.
    """
    research_results = _seed_research_results()
    _MERGE_ORDER = ('user_sources', 'kb', 'curated', 'web')
    for name in _MERGE_ORDER:
        out = stage_outputs.get(name, {}) or {}
        research_results['all_sources'].extend(out.get('sources', []))
        research_results['formatted_citations'].extend(out.get('citations', []))
        research_results['search_queries'].extend(out.get('queries', []))

    # Consolidated score (logging/metadata only) — same logic as the monolith Phase 1.
    _SCORED_TYPES = ('internal_knowledge', 'external_url', 'internal_url')
    scores_by_type: Dict[str, float] = {}
    for s in research_results['all_sources']:
        stype = s.get('type')
        score = s.get('relevance_score')
        if stype in _SCORED_TYPES and score is not None:
            if stype not in scores_by_type or score > scores_by_type[stype]:
                scores_by_type[stype] = round(float(score), 3)
    kb_best = scores_by_type.get('internal_knowledge')
    if kb_best is not None:
        research_results['consolidated_score'] = kb_best
    elif scores_by_type:
        research_results['consolidated_score'] = round(sum(scores_by_type.values()) / len(scores_by_type), 3)
    logger.info(f"[{request_id}] SPLIT_AGGREGATE | sources={len(research_results['all_sources'])} | consolidated={research_results['consolidated_score']}")
    return research_results


def stage_synthesis(requirements: Dict[str, Any], research_results: Dict[str, Any],
                    request_id: str, research_start: datetime) -> Dict[str, Any]:
    """Terminal synthesis stage: global dedup → finalize → synthesize/persist/return.

    This is the ONLY stage that writes research_data.json to S3, sets RESEARCH_COMPLETED
    in DynamoDB, and returns the canonical research_summary. Mirrors the monolith tail
    (the dedup that conduct_comprehensive_research did before finalize + build).
    """
    # Global URL dedup (the synthesis stage owns it, since retrieval ran in parallel)
    research_results['all_sources'] = _dedup_sources_by_url(research_results.get('all_sources', []))
    seen: set = set()
    out_cit = []
    for c in research_results.get('formatted_citations', []):
        key = (c.get('url', '') or '').strip().lower() or (c.get('title', '') or '').strip().lower()
        if key and key not in seen:
            seen.add(key)
            out_cit.append(c)
    research_results['formatted_citations'] = out_cit

    research_results = finalize_research_results(research_results, requirements, request_id)
    return build_research_output(research_results, requirements, request_id, research_start)


def stage_synthesis_from_parallel(requirements: Dict[str, Any], parallel_outputs: List[Dict[str, Any]],
                                  request_id: str, research_start: datetime) -> Dict[str, Any]:
    """Terminal synthesis for the Step-Functions split (client-demo2).

    The SF Parallel state returns a LIST of branch outputs in a FIXED order that mirrors
    the branch definition in step_functions_definition_client_demo2.json:
        index 0 = KBSearch, 1 = WebSearch, 2 = UserSources, 3 = CuratedLinks
    Each element is a stage dict ({'sources','citations','queries'} or a Catch fallback
    {'sources':[], 'error':...}). We map them back to named stages, aggregate exactly like
    the monolith Phase 1/2 merge, then run the shared dedup + finalize + build tail.
    """
    parallel_outputs = parallel_outputs or []
    _BRANCH_ORDER = ['kb', 'web', 'user_sources', 'curated']
    stage_outputs: Dict[str, Dict[str, Any]] = {}
    for idx, name in enumerate(_BRANCH_ORDER):
        out = parallel_outputs[idx] if idx < len(parallel_outputs) else {}
        stage_outputs[name] = out if isinstance(out, dict) else {}
        if stage_outputs[name].get('error'):
            logger.warning(f"[{request_id}] SPLIT_SYNTH | branch '{name}' reported: {stage_outputs[name].get('error')}")

    research_results = _aggregate_stage_sources(stage_outputs, request_id)
    return stage_synthesis(requirements, research_results, request_id, research_start)


def _invoke_sub_lambda(stage: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Synchronous (RequestResponse) invoke of a stage sub-lambda; returns its parsed body.
    Raises on FunctionError so the router fails loudly rather than drafting from empties.
    """
    fn = SPLIT_LAMBDA_NAMES[stage]
    resp = _lambda_client.invoke(
        FunctionName=fn,
        InvocationType='RequestResponse',
        Payload=json.dumps(payload).encode('utf-8'),
    )
    raw = resp['Payload'].read()
    if resp.get('FunctionError'):
        raise RuntimeError(f"sub-lambda {fn} error: {raw[:500]!r}")
    parsed = json.loads(raw) if raw else {}
    # Sub-lambdas return their stage dict directly (no API Gateway wrapping).
    return parsed if isinstance(parsed, dict) else {}


def _run_split_research(requirements: Dict[str, Any], request_id: str,
                        research_start: datetime, approved_sources: List[Dict] = None) -> Dict[str, Any]:
    """ROUTER: orchestrate the six stage sub-lambdas and relay the synthesis result.

    planner → (kb || user_sources || curated || web) → synthesis. Contract-preserving:
    the synthesis stage performs the single S3 write + RESEARCH_COMPLETED status + return.
    """
    logger.info(f"[{request_id}] SPLIT_RESEARCH | router start")

    # 1. Planner
    planner_out = _invoke_sub_lambda('planner', {'request_id': request_id, 'requirements': requirements})
    requirements = planner_out.get('requirements', requirements)

    # 2. Parallel retrieval
    payload = {'request_id': request_id, 'requirements': requirements}
    stage_outputs: Dict[str, Dict[str, Any]] = {}
    with ThreadPoolExecutor(max_workers=4) as executor:
        future_to_stage = {
            executor.submit(_invoke_sub_lambda, stage, payload): stage
            for stage in ('kb', 'user_sources', 'curated', 'web')
        }
        for future in as_completed(future_to_stage):
            stage = future_to_stage[future]
            try:
                stage_outputs[stage] = future.result()
                logger.info(f"[{request_id}] SPLIT_RESEARCH | stage '{stage}' completed")
            except Exception as e:
                logger.error(f"[{request_id}] SPLIT_RESEARCH | stage '{stage}' failed (non-fatal): {e}")
                stage_outputs[stage] = {'sources': [], 'citations': [], 'queries': []}

    # 3. Aggregate
    research_results = _aggregate_stage_sources(stage_outputs, request_id)
    if approved_sources:
        research_results['all_sources'] = approved_sources + research_results['all_sources']
        logger.info(f"[{request_id}] SPLIT_RESEARCH | merged {len(approved_sources)} approved sources")

    # 4. Synthesis (terminal — writes S3 + status + returns research_summary)
    return _invoke_sub_lambda('synthesis', {
        'request_id': request_id,
        'requirements': requirements,
        'research_results': research_results,
        'research_start': research_start.isoformat(),
    })


def _dedup_sources_by_url(sources: List[Dict]) -> List[Dict]:
    """Remove duplicate sources by URL, preserving first occurrence."""
    seen_urls: set = set()
    deduped = []
    for s in sources:
        url_key = (s.get('url') or s.get('source') or '').strip().lower()
        if url_key and url_key in seen_urls:
            continue
        if url_key:
            seen_urls.add(url_key)
        deduped.append(s)
    return deduped


def _dedup_web_against_existing(
    web_sources: List[Dict], existing_sources: List[Dict]
) -> List[Dict]:
    """
    Remove web sources whose URL already appears in KB or curated sources.
    Uses exact URL match — fast, no LLM call needed.
    """
    existing_urls = {
        (s.get('url') or s.get('source') or '').strip().lower()
        for s in existing_sources
        if s.get('type') in ('internal_knowledge', 'internal_url', 'external_url')
    }
    filtered = []
    for s in web_sources:
        url_key = (s.get('url') or '').strip().lower()
        if url_key and url_key in existing_urls:
            logger.info(f"WEB_DEDUP | skipping url already in KB/curated: '{url_key[:80]}'")
            continue
        filtered.append(s)
    return filtered


def _rerank_sources(query: str, sources: List[Dict], top_n: int = None) -> List[Dict]:
    """Cross-encoder rerank (Cohere Rerank v3.5 via LiteLLM /rerank).

    Attaches a normalized 0-1 'rerank_score' to each source (in place) and returns the
    sources ordered by that score. Non-fatal: on ANY error (or missing token/sources) the
    original list is returned unchanged, so the pipeline falls back to the prior
    trust/relevance ranking.

    - query: built from the understood intent + topic.
    - documents: each source's title + summary.
    - uploaded_file sources are kept but exempt from any rerank-based drop downstream.
    """
    if not sources or not query or not LITELLM_KEY:
        return sources

    # Build the document texts; track index → source mapping.
    docs = []
    for s in sources:
        text = f"{s.get('title', '')}\n{s.get('summary', '')}".strip()
        docs.append(text or (s.get('title') or s.get('url') or 'source'))

    # Lightweight rerank span (no token usage to record, rerank is not a chat completion)
    try:
        from langsmith import get_current_run_tree
        run_tree = get_current_run_tree()
        if run_tree:
            rerank_child = run_tree.create_child(
                name='monolith_rerank',
                run_type='tool',
                inputs={'query': query[:100], 'num_docs': len(docs)},
            )
            rerank_child.end(outputs={'reranked': True})
            rerank_child.post()
    except Exception:
        pass

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        payload = {
            "model": LITELLM_RERANK_MODEL,
            "query": query[:2000],
            "documents": docs,
            "top_n": top_n or len(docs),
        }
        req = urllib.request.Request(
            LITELLM_RERANK_URL,
            data=json.dumps(payload).encode('utf-8'),
            headers={"Authorization": f"Bearer {LITELLM_KEY}", "Content-Type": "application/json"},
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            res = json.loads(resp.read().decode('utf-8'))
        results = res.get('results', []) or []
        if not results:
            logger.warning("RERANK | empty results; keeping original order")
            return sources

        # Map rerank scores back onto sources by index.
        for item in results:
            idx = item.get('index')
            score = item.get('relevance_score', item.get('relevanceScore'))
            if idx is not None and 0 <= idx < len(sources) and score is not None:
                sources[idx]['rerank_score'] = round(float(score), 4)

        # Order: reranked sources by score desc; any source the API didn't score
        # (shouldn't happen with top_n=all) keeps a None score and sinks to the end.
        ordered = sorted(
            sources,
            key=lambda s: s.get('rerank_score') if s.get('rerank_score') is not None else -1.0,
            reverse=True,
        )
        top = [s.get('rerank_score') for s in ordered[:3]]
        logger.info(f"RERANK | scored={len(results)} sources | top3_scores={top}")
        return ordered
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='ignore')[:200]
        logger.warning(f"RERANK | HTTP {e.code}: {body} — falling back to original ranking")
        return sources
    except Exception as e:
        logger.warning(f"RERANK | failed ({type(e).__name__}: {str(e)[:150]}) — falling back")
        return sources


def _unified_top_k(sources: List[Dict], k: int = 8) -> List[Dict]:
    """
    Select top-k sources using a unified trust-weighted score.

    Trust weights per source type:
      internal_knowledge  → 1.00  (highest — internal verified content)
      uploaded_file       → 1.00  (user-provided, always trusted)
      internal_url        → 0.85  (curated portals)
      external_url        → 0.80  (user-provided URLs)
      web_search          → 0.65  (lowest — freshness but unverified)

    Final score = relevance_score × trust_weight
    uploaded_file (relevance_score=None) always placed first.
    """
    _TRUST: Dict[str, float] = {
        'internal_knowledge': 1.00,
        'uploaded_file':      1.00,
        'internal_url':       0.85,
        'external_url':       0.80,
        'web_search':         0.65,
    }

    def _weighted(s: Dict) -> float:
        if s.get('type') == 'uploaded_file':
            return 2.0   # user-provided — always first
        score = s.get('relevance_score')
        rerank = s.get('rerank_score')
        if score is None and rerank is None:
            return 2.0   # no signal (e.g. uploaded_file without score) — keep first
        trust = _TRUST.get(s.get('type', ''), 0.70)
        # Rerank (cross-encoder) is the primary relevancy signal when present; the
        # prior relevance_score acts as a secondary signal. Falls back to relevance
        # alone when rerank is unavailable (rerank call failed → safe degradation).
        if rerank is not None:
            rel = float(score) if score is not None else rerank
            core = 0.75 * rerank + 0.25 * rel
        else:
            core = float(score)
        base_score = core * trust

        # Recency bonus: sources from current year get +0.05
        date_str = s.get('date', '')
        if date_str:
            try:
                source_year = int(date_str[:4])
                current_year = datetime.now().year
                if source_year == current_year:
                    base_score += 0.05
                elif source_year == current_year - 1:
                    base_score += 0.02
            except (ValueError, IndexError):
                pass

        return round(base_score, 4)

    ranked = sorted(sources, key=_weighted, reverse=True)

    # M3: diversity-aware selection.
    #  (a) Allow up to MAX_PER_DOC chunks from the same document so one document can't
    #      monopolise the slots, while still preserving depth from a key source.
    #  (b) Apply a SOFT per-type cap (type-capped items are deferred, not dropped, and
    #      backfill when the pool is thin) so a single type can't crowd out diversity
    #      yet we never starve synthesis of the best (usually internal KB) content.
    MAX_PER_DOC = 2
    type_cap = max(2, int(k * 0.6))
    title_counts: Dict[str, int] = {}
    type_counts: Dict[str, int] = {}
    selected: List[Dict] = []
    deferred: List[Dict] = []

    def _title_key(s: Dict) -> str:
        return (s.get('title') or s.get('document_title') or '').strip().lower()

    for s in ranked:
        if len(selected) >= k:
            break
        # uploaded_file is always included, exempt from caps
        if s.get('type') == 'uploaded_file':
            selected.append(s)
            continue
        tkey = _title_key(s)
        if tkey and title_counts.get(tkey, 0) >= MAX_PER_DOC:
            continue  # already have enough chunks from this document
        stype = s.get('type', '?')
        if type_counts.get(stype, 0) >= type_cap:
            deferred.append(s)
            continue
        selected.append(s)
        type_counts[stype] = type_counts.get(stype, 0) + 1
        if tkey:
            title_counts[tkey] = title_counts.get(tkey, 0) + 1

    # Backfill remaining slots from deferred (type-capped) items, still honouring
    # the per-document limit.
    if len(selected) < k:
        for s in deferred:
            if len(selected) >= k:
                break
            tkey = _title_key(s)
            if tkey and title_counts.get(tkey, 0) >= MAX_PER_DOC:
                continue
            selected.append(s)
            if tkey:
                title_counts[tkey] = title_counts.get(tkey, 0) + 1

    logger.info(
        f"UNIFIED_RANK | total_pool={len(sources)} | k={k} | selected={len(selected)} "
        f"| types={[s.get('type','?') for s in selected]}"
    )
    return selected


def run_web_search_stage(requirements: Dict[str, Any], existing_sources: List[Dict],
                         request_id: str) -> Dict[str, Any]:
    """Phase 2 web search stage shared by the monolith and the split web lambda.

    Runs the top 3-4 planned queries (planner_queries[:4], each hard-capped at 15 words)
    as PARALLEL Tavily web searches, merges + de-duplicates the results by URL, dedups
    against existing_sources, and caps the merged web pool at 8 (the final trust-weighted
    top_k still decides what reaches synthesis). Multi-query coverage matters for comparative
    documents (e.g. global precedents across UK / NZ / Canada / EU) where a single query would
    only surface one jurisdiction. In the split web lambda existing_sources is [] (the synthesis
    stage performs the global URL dedup). Non-fatal: per-query errors contribute fewer results
    and never break the stage; returns empties only on total failure.
    """
    logger.info(f"[{request_id}] Phase 2: web search always enabled (multi-query)")
    try:
        planned = requirements.get('_planned_queries', []) or []
        if planned:
            raw_queries = planned[:4]                      # top 3-4 planned queries
        else:
            topic = (requirements.get('topic') or '').strip()
            jurisdiction = (requirements.get('jurisdiction') or '').strip()
            raw_queries = [' '.join(filter(None, [topic, jurisdiction]))]

        # Normalise: cap each query to 15 words and de-duplicate (case-insensitive)
        narrow_queries, _seen_q = [], set()
        for rq in raw_queries:
            nq = ' '.join((rq or '').split()[:15]).strip()
            if nq and nq.lower() not in _seen_q:
                _seen_q.add(nq.lower())
                narrow_queries.append(nq)
        if not narrow_queries:
            return {'sources': [], 'citations': [], 'queries': []}

        # ── Run the queries as parallel Tavily searches ───────────────────────
        def _one_query(nq: str) -> Dict[str, Any]:
            wr = requirements.copy()
            wr['_web_narrow_query'] = nq
            try:
                return search_web_tavily(wr)
            except Exception as qe:
                logger.warning(f"[{request_id}] WEB_SEARCH | query='{nq[:60]}' failed (non-fatal): {qe}")
                return {'sources': [], 'citations': [], 'queries': [nq]}

        merged_sources: List[Dict] = []
        merged_citations: List[Dict] = []
        with ThreadPoolExecutor(max_workers=len(narrow_queries)) as ex:
            futures = {ex.submit(_one_query, nq): nq for nq in narrow_queries}
            for fut in as_completed(futures):
                res = fut.result() or {}
                merged_sources.extend(res.get('sources', []) or [])
                merged_citations.extend(res.get('citations', []) or [])

        # ── Merge-dedup by URL across queries (keep first / highest-ranked) ──
        raw_merged_count = len(merged_sources)
        seen_urls, deduped_merged = set(), []
        for s in merged_sources:
            u = (s.get('url') or '').strip().lower()
            if u and u in seen_urls:
                continue
            if u:
                seen_urls.add(u)
            deduped_merged.append(s)

        # Dedup against KB + curated sources, then cap the merged web pool at 8
        deduped_web = _dedup_web_against_existing(deduped_merged, existing_sources)
        deduped_web = deduped_web[:8]

        # Citations: dedup by URL, align count with the capped source pool
        seen_c, deduped_citations = set(), []
        for c in merged_citations:
            cu = (c.get('url') or c.get('title') or '').strip().lower()
            if cu and cu in seen_c:
                continue
            if cu:
                seen_c.add(cu)
            deduped_citations.append(c)

        logger.info(
            f"[{request_id}] WEB_SEARCH | queries={len(narrow_queries)} "
            f"| raw={raw_merged_count} | merged_dedup={len(deduped_merged)} "
            f"| after_existing_dedup={len(deduped_web)} | capped=8"
        )
        return {
            'sources': deduped_web,
            'citations': deduped_citations[:8],
            'queries': narrow_queries,
        }
    except Exception as e:
        logger.error(f"Phase 2 web search failed: {str(e)}")
        return {'sources': [], 'citations': [], 'queries': []}


def _sanitize_queries(queries: List[str], requirements: Dict[str, Any]) -> List[str]:
    """R2 — clean planner queries before they hit KB/Tavily. Search engines perform poorly on
    long, repetitive, label-polluted strings (we observed queries like '... Ministry of Health
    India Narrative Builder Relevant Stakeholders'). This:
      - removes leaked internal labels (the category/use_case phrase, 'relevant stakeholders', 'n/a'),
      - collapses repeated words within a query (keeping first occurrence),
      - caps each query to ~14 words, and de-duplicates queries.
    Fail-open: returns the original list on any error. Phrase-based removal (not word-based) so it
    never nukes a genuinely meaningful term."""
    try:
        import re as _re
        phrases = []
        for k in ('category', 'use_case'):
            v = (requirements.get(k) or '').strip()
            if v:
                phrases.append(v)
        phrases += ['relevant stakeholders', 'not applicable', 'n/a']
        out, seen = [], set()
        for q in queries or []:
            if not isinstance(q, str) or not q.strip():
                continue
            cq = q
            for p in phrases:
                if p:
                    cq = _re.sub(r'\b' + _re.escape(p) + r'\b', ' ', cq, flags=_re.IGNORECASE)
            # collapse repeated words (keep first occurrence), cap length
            words, wseen, kept = _re.split(r'\s+', cq.strip()), set(), []
            for w in words:
                lw = w.lower().strip(',.;:')
                if not lw or lw in wseen:
                    continue
                wseen.add(lw)
                kept.append(w)
            cq = ' '.join(kept[:14]).strip()
            key = cq.lower()
            if cq and key not in seen:
                seen.add(key)
                out.append(cq)
        return out or queries
    except Exception:
        return queries


def plan_research(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Planning prelude shared by the monolith and the split planner lambda.

    Loads jurisdiction context + output-section template, runs the agentic framing
    decision and the Phase 0 query planner, and returns a NEW requirements dict enriched
    with: _jurisdiction_context, _output_template, _research_framing, _planned_queries.
    Pure (no S3/DDB writes) — safe to run as an isolated stage.
    """
    requirements = requirements.copy()

    # ── Load jurisdiction context (once per request) ──────────────────────────
    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    jurisdiction_context = _load_jurisdiction_context(jurisdiction)
    if jurisdiction_context:
        requirements['_jurisdiction_context'] = jurisdiction_context
        logger.info(f"[{request_id}] Jurisdiction context loaded for '{jurisdiction}' ({len(jurisdiction_context)} chars)")

    # ── Load output-section template (so research is structure-aware) ──────────
    output_template = _load_output_template((requirements.get('category') or '').strip())
    if output_template:
        requirements['_output_template'] = output_template
        logger.info(f"[{request_id}] Output template loaded for category '{requirements.get('category')}' ({len(output_template)} chars)")

    # ── Agentic framing (decides entity anchor + topic-relevance tokens) ──────
    framing = _llm_research_framing(requirements)
    requirements['_research_framing'] = framing

    # ── Phase 0 — Agentic planning (cap queries at 5 after dedup) ────────────
    planned_queries = _llm_plan_research(requirements)
    planned_queries = _sanitize_queries(planned_queries, requirements)  # R2: strip labels, dedupe, cap
    if planned_queries:
        # Cap at 5 planned queries to limit downstream KB query fan-out
        requirements['_planned_queries'] = planned_queries[:5]
        logger.info(f"[{request_id}] Agentic planning: {len(planned_queries)} queries, capped to {len(requirements['_planned_queries'])}")

    return requirements


def conduct_comprehensive_research(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """
    Optimised hybrid retrieval pipeline.

    Phase 0  — Agentic planning: LLM generates up to 5 targeted queries (capped, deduped).
    Phase 1  — 4 primary sources in parallel: uploaded_file, kb_search (top_k=5, threshold=0.5),
               external_links, internal_links (max 3 curated).
    Phase 2  — Web search: ALWAYS runs, single narrow query from planner_queries[0]
               (max 15 words), max 3 results. Web sources deduplicated against KB+curated.
    Phase 3  — Gap fill: max 1 gap query (KB + web), non-fatal.
    Final    — Unified trust-weighted ranking → top 8 sources sent to synthesis.
    """

    # Register request_id for Gemini comparison accumulator
    with _gemini_comparison_lock:
        _gemini_comparison_store['_active_request_id'] = request_id
        _gemini_comparison_store[request_id] = {'url_extractions': [], 'web_searches': []}

    # ── Planning prelude (jurisdiction + template load, framing, query planning) ──
    requirements = plan_research(requirements, request_id)

    # ── Phase 1 — 4 primary sources in parallel ──────────────────────────────
    phase1_tasks = [
        ('uploaded_file',  read_uploaded_file,       [requirements]),
        ('kb_search',      search_internal_knowledge, [requirements]),
        ('external_links', fetch_user_external_links, [requirements]),
        ('internal_links', fetch_internal_weblinks,   [requirements]),
    ]

    research_results = {
        'all_sources': [],
        'uploaded_file_count': 0,
        'kb_count': 0,
        'external_links_count': 0,
        'internal_links_count': 0,
        'web_search_count': 0,
        'consolidated_score': 0.0,
        'web_search_triggered': True,   # always runs now
        'formatted_citations': [],
        'search_queries': [],
    }

    _COUNT_KEY = {
        'uploaded_file':  'uploaded_file_count',
        'kb_search':      'kb_count',
        'external_links': 'external_links_count',
        'internal_links': 'internal_links_count',
        'web_search':     'web_search_count',
    }

    task_outputs: Dict[str, Any] = {}
    with ThreadPoolExecutor(max_workers=4) as executor:
        future_to_task = {
            executor.submit(task_func, *task_args): task_name  # type: ignore[arg-type]
            for task_name, task_func, task_args in phase1_tasks
        }
        for future in as_completed(future_to_task):
            task_name = future_to_task[future]
            try:
                task_outputs[task_name] = future.result()
                logger.info(f"Phase 1 completed: {task_name}")
            except Exception as e:
                logger.error(f"Phase 1 task {task_name} failed: {str(e)}")
                task_outputs[task_name] = {'sources': [], 'citations': [], 'queries': []}

    # Merge Phase 1 in declared order
    for task_name, _, _ in phase1_tasks:
        result = task_outputs.get(task_name, {})
        research_results['all_sources'].extend(result.get('sources', []))
        research_results['formatted_citations'].extend(result.get('citations', []))
        research_results['search_queries'].extend(result.get('queries', []))
        research_results[_COUNT_KEY[task_name]] = len(result.get('sources', []))

    # Compute consolidated score for logging (no longer gates web search)
    _SCORED_TYPES = ('internal_knowledge', 'external_url', 'internal_url')
    scores_by_type: Dict[str, float] = {}
    for s in research_results['all_sources']:
        stype = s.get('type')
        score = s.get('relevance_score')
        if stype in _SCORED_TYPES and score is not None:
            if stype not in scores_by_type or score > scores_by_type[stype]:
                scores_by_type[stype] = round(float(score), 3)

    kb_best = scores_by_type.get('internal_knowledge')
    if kb_best is not None:
        consolidated_score = kb_best
    elif scores_by_type:
        consolidated_score = round(sum(scores_by_type.values()) / len(scores_by_type), 3)
    else:
        consolidated_score = 0.0

    research_results['consolidated_score'] = consolidated_score
    logger.info(
        f"[{request_id}] Phase 1 complete | scores_by_type={scores_by_type} "
        f"| kb_best={kb_best} | consolidated={consolidated_score}"
    )

    # ── Phase 2 — Web search: ALWAYS runs ────────────────────────────────────
    web_stage = run_web_search_stage(requirements, research_results['all_sources'], request_id)
    research_results['all_sources'].extend(web_stage.get('sources', []))
    research_results['formatted_citations'].extend(web_stage.get('citations', []))
    research_results['search_queries'].extend(web_stage.get('queries', []))
    research_results['web_search_count'] = len(web_stage.get('sources', []))

    # ── Deduplicate all sources by URL ────────────────────────────────────────
    research_results['all_sources'] = _dedup_sources_by_url(research_results['all_sources'])

    # Deduplicate citations
    seen_citations: set = set()
    dedup_citations = []
    for c in research_results.get('formatted_citations', []):
        key = c.get('url', '').strip().lower() or c.get('title', '').strip().lower()
        if key and key not in seen_citations:
            seen_citations.add(key)
            dedup_citations.append(c)
    research_results['formatted_citations'] = dedup_citations

    return finalize_research_results(research_results, requirements, request_id)


def finalize_research_results(research_results: Dict[str, Any], requirements: Dict[str, Any],
                              request_id: str) -> Dict[str, Any]:
    """Phase 3 relevance loop + rerank + relevance floor + unified top-k + structured
    fact extraction + final source-count recalculation + citation filtering.

    Extracted from conduct_comprehensive_research so the split synthesis lambda and the
    monolith share the IDENTICAL finalization logic. Mutates and returns research_results.
    Expects requirements to already carry _research_framing, _planned_queries and
    _jurisdiction_context (set by the planning stage).
    """
    # ── Phase 3 — Relevance-driven retrieval loop (≤4 iterations, time-boxed) ──
    # Goal: keep retrieving (KB + web, with escalating agentic reformulation) until at
    # least MIN_RELEVANT genuinely on-topic sources are found. This prevents drafting a
    # document from scored-but-off-topic sources (the failure where a PMI sustainability
    # request collapsed into government foreign-trade results). Coverage is still used as
    # a secondary signal once relevance is satisfied. Hard-bounded by iterations and a
    # wall-clock budget so the Lambda always returns cleanly.
    import time as _time
    RESEARCH_BUDGET_S = int(os.environ.get('RESEARCH_BUDGET_SECONDS', '540'))  # ~9 min, margin under 15-min Lambda
    deadline = _time.time() + RESEARCH_BUDGET_S
    MIN_RELEVANT = 3
    MAX_RELEVANCE_ITERS = 4
    COVERAGE_TARGET = 0.7

    framing = requirements.get('_research_framing', {}) or {}
    tried_queries: List[str] = list(requirements.get('_planned_queries', []) or [])

    def _coverage_ratio(rr: Dict[str, Any]) -> float:
        """Cheap coverage signal: fraction toward a target of strong/diverse sources."""
        srcs = rr.get('all_sources', [])
        strong = [
            s for s in srcs
            if s.get('relevance_score') is None or (s.get('relevance_score') or 0) >= 0.5
        ]
        return min(1.0, len(strong) / 6.0)

    def _rededup_citations() -> None:
        seen = set()
        out = []
        for c in research_results.get('formatted_citations', []):
            key = (c.get('url', '') or '').strip().lower() or (c.get('title', '') or '').strip().lower()
            if key and key not in seen:
                seen.add(key)
                out.append(c)
        research_results['formatted_citations'] = out

    relevant_count = _annotate_relevance(research_results['all_sources'], framing, requirements)
    logger.info(f"[{request_id}] RELEVANCE | initial on-topic sources={relevant_count} (target={MIN_RELEVANT})")

    for rel_iter in range(MAX_RELEVANCE_ITERS):
        coverage = _coverage_ratio(research_results)
        if relevant_count >= MIN_RELEVANT and coverage >= COVERAGE_TARGET:
            logger.info(
                f"[{request_id}] RELEVANCE | satisfied at iter {rel_iter} "
                f"(relevant={relevant_count}, coverage={coverage:.2f}); stopping"
            )
            break
        if _time.time() >= deadline:
            logger.warning(f"[{request_id}] RELEVANCE | time budget exhausted at iter {rel_iter}; stopping")
            break

        # Choose reformulation strategy: prioritise relevance recovery when we lack
        # on-topic sources; otherwise fall back to coverage gap-fill.
        try:
            if relevant_count < MIN_RELEVANT:
                new_queries = _llm_reformulate_for_relevance(framing, requirements, tried_queries, rel_iter)
                reason = 'relevance'
            else:
                new_queries = _llm_identify_gaps(research_results, requirements)
                reason = 'coverage'
            if not new_queries:
                logger.info(f"[{request_id}] RELEVANCE | iter {rel_iter}: no new {reason} queries; stopping")
                break
            new_queries = new_queries[:3]
            tried_queries.extend(new_queries)
            logger.info(f"[{request_id}] RELEVANCE | iter {rel_iter} ({reason}) queries={new_queries}")
            _fill_research_gaps(new_queries, research_results, requirements)
            research_results['all_sources'] = _dedup_sources_by_url(research_results['all_sources'])
            _rededup_citations()
            relevant_count = _annotate_relevance(research_results['all_sources'], framing, requirements)
            logger.info(f"[{request_id}] RELEVANCE | after iter {rel_iter}: on-topic sources={relevant_count}")
        except Exception as e:
            logger.warning(f"[{request_id}] RELEVANCE | iter {rel_iter} failed (non-fatal): {e}")
            break

    # Record final relevance signal for the synthesis gate and downstream review.
    research_results['_relevant_count'] = relevant_count
    research_results['_low_relevance'] = relevant_count < MIN_RELEVANT
    research_results['_research_framing'] = framing
    if relevant_count == 0:
        logger.critical(
            f"[{request_id}] RELEVANCE | ZERO on-topic sources after {MAX_RELEVANCE_ITERS} iterations — "
            f"synthesis will short-circuit to no_data rather than draft off-topic content."
        )

    # ── Rerank: cross-encoder relevancy over the full pool (primary ranking signal) ──
    # Query is built from the understood intent + topic. Non-fatal: on failure the pool
    # is returned unchanged and _unified_top_k falls back to trust/relevance ranking.
    _rerank_query = ' '.join(filter(None, [
        framing.get('intent', '') if isinstance(framing, dict) else '',
        requirements.get('topic', ''),
    ])).strip() or requirements.get('topic', '')
    research_results['all_sources'] = _rerank_sources(_rerank_query, research_results['all_sources'])

    # Relevance floor: drop clearly off-topic sources (rerank_score < RERANK_MIN_SCORE),
    # but only if enough on-topic sources remain — never starve synthesis. uploaded_file exempt.
    _scored = [s for s in research_results['all_sources'] if s.get('rerank_score') is not None]
    if _scored:
        _kept = [
            s for s in research_results['all_sources']
            if s.get('type') == 'uploaded_file'
            or s.get('rerank_score') is None
            or s.get('rerank_score') >= RERANK_MIN_SCORE
        ]
        if len([s for s in _kept if s.get('type') != 'uploaded_file']) >= 3:
            dropped = len(research_results['all_sources']) - len(_kept)
            if dropped:
                logger.info(f"[{request_id}] RERANK_FLOOR | dropped {dropped} source(s) below {RERANK_MIN_SCORE}")
            research_results['all_sources'] = _kept

    # ── Final: unified trust-weighted ranking + dedup/diversity → top 15 ──────
    research_results['all_sources'] = _unified_top_k(research_results['all_sources'], k=15)

    # ── Structured fact extraction (1 Gemini call) ────────────────────────────
    try:
        research_results['structured_facts'] = _extract_structured_facts(
            research_results['all_sources'], requirements
        )
        logger.info(f"[{request_id}] Structured facts extracted: {len(research_results.get('structured_facts', {}).get('statistics', []))} stats")
    except Exception as e:
        logger.warning(f"[{request_id}] Structured fact extraction failed (non-fatal): {e}")
        research_results['structured_facts'] = {}

    # Recalculate source counts after dedup, gap fill, and top_k
    research_results['kb_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'internal_knowledge')
    research_results['web_search_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'web_search')
    research_results['external_links_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'external_url')
    research_results['internal_links_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'internal_url')
    research_results['uploaded_file_count'] = sum(1 for s in research_results['all_sources'] if s.get('type') == 'uploaded_file')

    # Filter citations to only include sources that survived top_k
    surviving_urls = {
        (s.get('url') or s.get('source') or '').strip().lower(): s.get('relevance_score')
        for s in research_results['all_sources']
    }
    surviving_titles = {
        (s.get('title') or '').strip().lower(): s.get('relevance_score')
        for s in research_results['all_sources']
    }
    filtered_citations = []
    for c in research_results.get('formatted_citations', []):
        c_url = (c.get('url') or '').strip().lower()
        c_title = (c.get('title') or '').strip().lower()
        if c_url and c_url in surviving_urls:
            c['relevance_score'] = surviving_urls[c_url]
            filtered_citations.append(c)
        elif c_title and c_title in surviving_titles:
            c['relevance_score'] = surviving_titles[c_title]
            filtered_citations.append(c)
    research_results['formatted_citations'] = filtered_citations

    # Store jurisdiction context for drafter consumption via S3
    research_results['_jurisdiction_context_for_drafter'] = requirements.get('_jurisdiction_context', '')

    logger.info(
        f"[{request_id}] Research complete | total_sources={len(research_results['all_sources'])} "
        f"| web={research_results['web_search_count']} "
        f"| kb={research_results['kb_count']} "
        f"| external={research_results['external_links_count']} "
        f"| internal={research_results['internal_links_count']}"
    )

    return research_results


# ═══════════════════════════════════════════════════════════════════════════════
# Agentic research framing + relevance-driven retrieval
# ───────────────────────────────────────────────────────────────────────────────
# One upfront LLM "framing" decision tells the rest of the pipeline what KIND of
# research this is (PMI's own action vs external regulatory landscape), which entity
# to anchor queries to, and which tokens define topic relevance. That single decision
# drives the planner, the web query, and a relevance-driven retry loop that keeps
# searching (KB + web, with escalating reformulation) until enough on-topic sources
# are found or a bounded budget is exhausted. Every call is non-fatal: on any failure
# the pipeline falls back to its prior (unanchored) behavior.
# ═══════════════════════════════════════════════════════════════════════════════

_RELEVANCE_STOPWORDS = {
    'the', 'and', 'for', 'with', 'this', 'that', 'from', 'into', 'about', 'are',
    'was', 'were', 'has', 'have', 'had', 'will', 'would', 'should', 'could', 'its',
    'their', 'our', 'your', 'his', 'her', 'they', 'them', 'these', 'those', 'such',
    'any', 'all', 'new', 'use', 'used', 'using', 'via', 'per', 'over', 'under',
    'launch', 'update', 'comments', 'input', 'response', 'initiative', 'proposed',
}


def _tokenize_relevance(text: str) -> List[str]:
    """Lowercase content tokens (len>2, stopwords removed) for overlap scoring."""
    import re
    return [
        w for w in re.split(r'[^a-z0-9]+', (text or '').lower())
        if len(w) > 2 and w not in _RELEVANCE_STOPWORDS
    ]


def _llm_call_json(prompt: str, max_tokens: int = 400, timeout: int = 15, model: str = None,
                   temperature: float = 0.1, name: str = 'monolith_llm_call_json'):
    """Minimal LiteLLM call that returns parsed JSON (dict/list) or None.

    Robust to markdown fences and leading/trailing prose. Non-fatal: returns None on
    any error so callers can fall back to deterministic behavior.
    """
    if not LITELLM_KEY:
        return None
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        data = {
            "model": model or LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL, data=json.dumps(data).encode('utf-8'),
            headers=headers, method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=timeout) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(res, name=name, response=resp)
            except Exception:
                pass
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            try:
                return json.loads(raw)
            except Exception:
                # Salvage the outermost JSON object/array from surrounding prose.
                for open_c, close_c in (('{', '}'), ('[', ']')):
                    a, b = raw.find(open_c), raw.rfind(close_c)
                    if a != -1 and b != -1 and b > a:
                        try:
                            return json.loads(raw[a:b + 1])
                        except Exception:
                            continue
            return None
    except Exception as e:
        logger.warning(f"LLM JSON call failed (non-fatal): {e}")
        return None


def _llm_research_framing(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Agentic REQUEST UNDERSTANDING + FRAMING.

    Ingests the ENTIRE request and lets the model dynamically decide which fields are
    meaningful (recipient/addressed_to, cc_to, stakeholders, background, etc. — these vary
    by category in the UI) and identify the user's INTENT, OBJECTIVE, STANCE, and AUDIENCE,
    in addition to the retrieval framing (entity anchor, perspective, topic tokens).

    Returns a dict with both intent fields and framing fields (backward-compatible — all the
    original framing keys are preserved). Returns {} on failure so callers degrade safely.
    """
    topic = (requirements.get('topic') or '').strip()
    if not topic:
        return {}

    # Build a clean view of the request: drop system/metadata noise, keep everything
    # semantically meaningful. The model decides what matters from what remains.
    _METADATA_FIELDS = {
        'request_id', 'user_id', 'created_at', 'updated_at', 'completed_at', 'isSubmit',
        'bypass_duplicate_check', 'progress', 'enable_hitl', 'enable_topic_relevance_check',
        'uploadedFileKeys', 'uploaded_files', 'uploaded_file_s3_key', 'urls', 'reference_urls',
        'external_links', 'output_file_type', 'deadline', 'priority',
        # internal context blobs already injected elsewhere
        '_jurisdiction_context', '_output_template', '_research_framing', '_planned_queries',
        '_web_narrow_query', 're_research_feedback',
        # File source dict (large, injected separately as summary below)
        '_uploaded_file_source',
    }
    clean_request = {}
    for k, v in (requirements or {}).items():
        if k in _METADATA_FIELDS:
            continue
        if v in (None, '', [], {}):
            continue
        # Generous safety cap so a pathological paste can't blow up tokens/cost.
        if isinstance(v, str) and len(v) > 30000:
            v = v[:30000]
        clean_request[k] = v

    request_json = json.dumps(clean_request, ensure_ascii=False, default=str)

    prompt = (
        "You are a REQUEST UNDERSTANDING agent for PMI (Philip Morris International) "
        "Corporate Affairs. You receive a document-generation request as JSON. The set of "
        "fields varies by document category (e.g. some requests include a recipient / "
        "addressed_to / cc_to, others include stakeholders or background). DYNAMICALLY decide "
        "which fields are meaningful for THIS request and ignore empty or system/metadata "
        "fields.\n\n"
        "From the request, determine:\n"
        "1. The user's INTENT and OBJECTIVE (what they actually want the document to achieve).\n"
        "2. The AUTHOR identity (this is PMI) and the STANCE PMI should take. The named "
        "recipient/ministry/audience is who the document is FOR — never adopt the audience's "
        "voice or argue against PMI's own interest.\n"
        "3. The AUDIENCE (recipient/stakeholders) the document addresses.\n"
        "4. The retrieval FRAMING so source search matches the ACTUAL subject, not superficial "
        "keyword matches.\n\n"
        f"REQUEST JSON:\n{request_json}\n\n"
        "Decide the perspective:\n"
        "- 'first_party_pmi'     : about PMI's OWN action/initiative/position/announcement. "
        "Anchor queries to PMI so results are about PMI, not a government with a similarly named programme.\n"
        "- 'external_regulatory' : about external law/regulation/policy or a government "
        "consultation. Do NOT anchor to PMI — you want the regulatory sources themselves.\n"
        "- 'comparative_market'  : needs data from other markets/countries.\n\n"
        "Rules:\n"
        "- Set 'entity_anchor' to 'PMI Philip Morris International' ONLY for first_party_pmi; otherwise empty string.\n"
        "- 'must_exclude_terms': terms that would pull OFF-topic results (e.g. for a PMI "
        "sustainability release, exclude government trade bodies like 'Department of Commerce', 'foreign trade').\n"
        "- 'core_topic_tokens': 5-12 lowercase keywords a genuinely relevant source MUST relate to.\n"
        "- 'stance': if the request is purely informational/neutral, say 'neutral/informational'.\n\n"
        "Output ONLY a JSON object with keys: intent (string), objective (string), "
        "author_identity (string), stance (string), audience (string), subject_entity (string), "
        "perspective (string), entity_anchor (string), must_include_terms (array), "
        "must_exclude_terms (array), core_topic_tokens (array), key_constraints (array). "
        "No explanation, no markdown."
    )

    data = _llm_call_json(prompt, max_tokens=900, model=LLM_MODEL_REASONING, name='monolith_research_framing')
    if not isinstance(data, dict):
        # Deterministic fallback: minimal framing so the pipeline still runs.
        return {
            'intent': topic,
            'objective': (requirements.get('background') or topic),
            'author_identity': 'PMI',
            'stance': '',
            'audience': requirements.get('addressed_to') or requirements.get('stakeholders') or '',
            'subject_entity': '',
            'perspective': '',
            'entity_anchor': '',
            'must_include_terms': [],
            'must_exclude_terms': [],
            'core_topic_tokens': _tokenize_relevance(f"{topic} {requirements.get('background','')}")[:15],
            'key_constraints': [],
            # Tone is a direct user input — preserved verbatim (not LLM-paraphrased),
            # with a sensible default so downstream behavior never regresses.
            'tone': (str(requirements.get('tone_requirements') or '').strip() or DEFAULT_TONE),
        }

    def _strlist(key: str, lower: bool = False, cap: int = 12) -> List[str]:
        out = []
        for t in (data.get(key) or []):
            v = str(t).strip()
            if v:
                out.append(v.lower() if lower else v)
        return out[:cap]

    framing = {
        # Intent fields (new)
        'intent': str(data.get('intent') or '').strip(),
        'objective': str(data.get('objective') or '').strip(),
        'author_identity': str(data.get('author_identity') or 'PMI').strip(),
        'stance': str(data.get('stance') or '').strip(),
        'audience': str(data.get('audience') or '').strip(),
        'key_constraints': _strlist('key_constraints', cap=10),
        # Tone is a direct user input — preserved verbatim (not LLM-paraphrased), with a
        # sensible default so downstream behavior never regresses. Part of the intent
        # object, carried through to the drafter planner and content prompts.
        'tone': (str(requirements.get('tone_requirements') or '').strip() or DEFAULT_TONE),
        # Framing fields (backward-compatible)
        'subject_entity': str(data.get('subject_entity') or '').strip(),
        'perspective': str(data.get('perspective') or '').strip().lower(),
        'entity_anchor': str(data.get('entity_anchor') or '').strip(),
        'must_include_terms': _strlist('must_include_terms'),
        'must_exclude_terms': _strlist('must_exclude_terms', lower=True),
        'core_topic_tokens': _strlist('core_topic_tokens', lower=True, cap=15),
    }
    # Fallback: derive topic tokens from the request if the model gave none.
    if not framing['core_topic_tokens']:
        framing['core_topic_tokens'] = _tokenize_relevance(
            f"{topic} {requirements.get('background', '')}"
        )[:15]

    logger.info(
        f"REQUEST_UNDERSTANDING | perspective='{framing['perspective']}' "
        f"| stance='{framing['stance']}' | audience='{framing['audience'][:60]}' "
        f"| tone='{framing['tone'][:60]}' "
        f"| entity_anchor='{framing['entity_anchor']}' | tokens={framing['core_topic_tokens']}"
    )
    return framing





def _topic_overlap_score(text: str, tokens: List[str]) -> float:
    """Fraction of core topic tokens present in the source text (0.0–1.0)."""
    if not tokens:
        return 0.0
    src = set(_tokenize_relevance(text))
    if not src:
        return 0.0
    hits = sum(1 for t in tokens if t in src)
    return hits / len(tokens)


# Strong PMI entity identifiers + owned domains used to decide whether a source is about
# PMI (the actor), independent of whether it merely shares the topic vocabulary.
_PMI_ENTITY_TERMS = ('pmi', 'philip morris', 'iqos', 'veev', 'zyn', 'pmiscience')
_PMI_DOMAINS = ('pmi.com', 'philipmorris', 'pmiscience', 'insidepmi')


def _is_first_party(framing: Dict[str, Any]) -> bool:
    """True when the document is about PMI's OWN action/position (entity match required)."""
    return framing.get('perspective') == 'first_party_pmi' or bool(framing.get('entity_anchor'))


def _entity_match(source: Dict[str, Any]) -> bool:
    """True if the source actually mentions PMI (the actor), by text or owned domain."""
    text = f"{source.get('title', '')} {source.get('summary', '')}".lower()
    url = (source.get('url') or source.get('source') or '').lower()
    if any(t in text for t in _PMI_ENTITY_TERMS):
        return True
    if any(d in url for d in _PMI_DOMAINS):
        return True
    return False


def _llm_judge_relevance(borderline: List[Dict[str, Any]], framing: Dict[str, Any],
                         requirements: Dict[str, Any]) -> set:
    """Batched LLM judge for borderline sources. Returns the set of relevant indices."""
    if not borderline:
        return set()
    topic = requirements.get('topic', '')
    entity = framing.get('subject_entity') or framing.get('entity_anchor') or 'the subject'
    first_party = _is_first_party(framing)
    listing = '\n'.join(
        f"[{i}] {s.get('title', '?')} — {(s.get('summary') or '')[:200]}"
        for i, s in enumerate(borderline)
    )
    actor_rule = (
        f"CRITICAL: A source is relevant ONLY if it is about '{entity}' AND the topic. "
        f"A source about the SAME topic but a DIFFERENT organisation or a government body "
        f"(e.g. a ministry's own programme of the same name) is NOT relevant — reject it.\n\n"
        if first_party else ""
    )
    prompt = (
        "You are a source relevance judge.\n\n"
        f"DOCUMENT TOPIC: {topic}\n"
        f"INTENDED SUBJECT/ACTOR: {entity}\n"
        f"MUST RELATE TO: {', '.join(framing.get('core_topic_tokens', [])) or topic}\n\n"
        f"{actor_rule}"
        "Decide which of the sources below are genuinely about this topic/subject "
        "(not just sharing a generic word).\n\n"
        f"SOURCES:\n{listing}\n\n"
        'Output ONLY a JSON object: {"relevant_indices": [list of integer indices that ARE relevant]}'
    )
    data = _llm_call_json(prompt, max_tokens=200, model=LLM_MODEL_REASONING, name='monolith_llm_judge_relevance')
    if isinstance(data, dict):
        idxs = data.get('relevant_indices', [])
        return {int(i) for i in idxs if isinstance(i, (int, float)) or str(i).isdigit()}
    return set()


def _annotate_relevance(sources: List[Dict[str, Any]], framing: Dict[str, Any],
                        requirements: Dict[str, Any]) -> int:
    """Mark each source['_topic_relevant'] (True/False) and return the relevant count.

    Two-factor relevance:
      - TOPIC match  : token overlap against core_topic_tokens (fast path).
      - ACTOR match  : for first-party PMI documents, the source must actually be about PMI
                       (entity mention or PMI-owned domain). This is what separates
                       "PMI sustainability" from a government's identically-named programme —
                       both share the topic vocabulary, only the actor differs.
    Borderline cases are batched into a single LLM judge call (token-overlap + LLM judge).
    """
    tokens = framing.get('core_topic_tokens') or _tokenize_relevance(requirements.get('topic', ''))
    exclude = framing.get('must_exclude_terms') or []
    require_entity = _is_first_party(framing)
    HIGH = 0.34  # ≥ ~1/3 of core tokens present → clearly on-topic

    borderline_idx = []
    for i, s in enumerate(sources):
        if s.get('type') == 'uploaded_file':
            s['_topic_relevant'] = True  # user explicitly provided it
            continue
        text = f"{s.get('title', '')} {s.get('summary', '')}"
        low = text.lower()
        overlap = _topic_overlap_score(text, tokens)
        excluded = any(e in low for e in exclude) if exclude else False

        if require_entity:
            # First-party PMI: actor match is mandatory. Right-topic/wrong-actor → reject.
            if not _entity_match(s):
                s['_topic_relevant'] = False
            elif overlap >= HIGH and not excluded:
                s['_topic_relevant'] = True
            elif excluded and overlap < HIGH:
                s['_topic_relevant'] = False
            else:
                # About PMI but topic match unclear → let the judge confirm topic fit.
                s['_topic_relevant'] = None
                borderline_idx.append(i)
        else:
            # External/regulatory/comparative: topic-token logic only (no PMI anchor).
            if overlap >= HIGH and not excluded:
                s['_topic_relevant'] = True
            elif overlap == 0.0 or (excluded and overlap < HIGH):
                s['_topic_relevant'] = False
            else:
                s['_topic_relevant'] = None
                borderline_idx.append(i)

    if borderline_idx:
        judged = _llm_judge_relevance([sources[i] for i in borderline_idx], framing, requirements)
        for k, i in enumerate(borderline_idx):
            sources[i]['_topic_relevant'] = (k in judged)

    return sum(1 for s in sources if s.get('_topic_relevant') is True)


def _llm_reformulate_for_relevance(framing: Dict[str, Any], requirements: Dict[str, Any],
                                   tried_queries: List[str], iteration: int) -> List[str]:
    """Escalating query reformulation when not enough on-topic sources were found.

    Strategy escalates by iteration so retries don't repeat the same failing search:
      0: tight  (entity + topic + jurisdiction)
      1: broaden (drop jurisdiction)
      2: entity synonyms / parent framing
      3: topic-only but apply exclusions
    """
    topic = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    anchor = framing.get('entity_anchor', '')
    strategies = [
        f"Tight: anchor to '{anchor or topic}', include jurisdiction '{jurisdiction}'.",
        "Broaden: drop the jurisdiction; keep the entity and core topic.",
        f"Reframe: use synonyms / parent terms for the subject '{framing.get('subject_entity') or anchor or topic}'.",
        "Topic-only: focus purely on the core topic tokens, but avoid the excluded terms.",
    ]
    strategy = strategies[min(iteration, len(strategies) - 1)]
    prompt = (
        "You are a retrieval recovery agent. Previous searches did not return enough sources "
        "that are genuinely about the intended subject.\n\n"
        f"TOPIC: {topic}\n"
        f"INTENDED SUBJECT: {framing.get('subject_entity') or anchor or 'N/A'}\n"
        f"CORE TOPIC TOKENS: {', '.join(framing.get('core_topic_tokens', [])) or topic}\n"
        f"AVOID (off-topic) TERMS: {', '.join(framing.get('must_exclude_terms', [])) or 'none'}\n"
        f"ALREADY TRIED (do NOT repeat): {tried_queries[-8:]}\n\n"
        f"THIS ROUND'S STRATEGY: {strategy}\n\n"
        "Generate up to 3 NEW search queries (5-15 words each) following this round's strategy.\n"
        "Output ONLY a JSON array of strings, no explanation."
    )
    data = _llm_call_json(prompt, max_tokens=250, name='monolith_llm_reformulate_relevance')
    if not isinstance(data, list):
        return []
    tried_lower = {q.strip().lower() for q in tried_queries}
    out = []
    for q in data:
        v = str(q).strip()
        if v and v.lower() not in tried_lower and v.lower() not in {o.lower() for o in out}:
            out.append(v)
    return out[:3]


def _llm_plan_research(requirements: Dict[str, Any]) -> List[str]:
    """
    Agentic Phase 0: Ask the LLM to plan 5-7 specific fact-targeted queries
    for the research topic. Returns a list of query strings.
    Falls back silently to [] on any failure.
    """
    if not LITELLM_KEY:
        return []

    topic        = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    category     = requirements.get('category', '')
    use_case     = requirements.get('use_case', '')
    background   = requirements.get('background', '')

    if not topic:
        return []

    prompt = (
        "You are a research planning agent for regulatory document preparation.\n\n"
        f"Topic: {topic}\n"
        f"Jurisdiction: {jurisdiction}\n"
        f"Category: {category}\n"
        f"Use case: {use_case}\n"
        f"Background: {background if background else 'N/A'}\n\n"
    )

    # Inject the understood INTENT/STANCE/AUDIENCE so queries serve the user's goal
    # (not just the topic) and never drift into the audience's voice.
    framing = requirements.get('_research_framing', {}) or {}
    if framing.get('intent') or framing.get('objective'):
        prompt += (
            "USER INTENT & OBJECTIVE (plan queries that serve THIS goal):\n"
            f"- Intent: {framing.get('intent', 'N/A')}\n"
            f"- Objective: {framing.get('objective', 'N/A')}\n"
            f"- Author: {framing.get('author_identity', 'PMI')} | Stance: {framing.get('stance', 'N/A')}\n"
            f"- Audience: {framing.get('audience', 'N/A')}\n\n"
        )

    # Inject jurisdiction context (full file, capped at JURISDICTION_CTX_MAX)
    jur_context = requirements.get('_jurisdiction_context', '')
    if jur_context:
        prompt += f"JURISDICTION CONTEXT (use this to inform your queries):\n{jur_context[:JURISDICTION_CTX_MAX]}\n\n"

    # Inject uploaded file summary so queries target the file's real subject
    file_summary = requirements.get('_uploaded_file_summary', '')
    if file_summary:
        prompt += (
            "UPLOADED FILE SUMMARY (the user provided this file as reference — use its content "
            "to inform your queries so they target the file's actual subject matter):\n"
            f"{file_summary[:5000]}\n\n"
        )

    # Inject tone requirements so the planner understands the expected output register
    tone = requirements.get('tone_requirements', '')
    if tone:
        prompt += f"TONE REQUIREMENTS for the final document: {tone}\n\n"

    # Inject the output-section template so the planner targets evidence per section.
    output_template = requirements.get('_output_template', '')
    if output_template:
        prompt += (
            "TARGET DOCUMENT STRUCTURE (the final document will have these sections — "
            "generate queries that gather the specific evidence each section needs):\n"
            f"{output_template[:2500]}\n\n"
        )

    # Inject agentic framing so queries are anchored to the right subject/entity.
    framing = requirements.get('_research_framing', {}) or {}
    if framing:
        anchor = framing.get('entity_anchor', '')
        exclude = framing.get('must_exclude_terms', [])
        if anchor:
            prompt += (
                f"SUBJECT ANCHOR: Every query MUST be anchored to '{anchor}' so results are about "
                f"this entity and not a different organisation with a similarly named programme.\n"
            )
        if framing.get('perspective'):
            prompt += f"RESEARCH PERSPECTIVE: {framing['perspective']}\n"
        if exclude:
            prompt += f"AVOID these off-topic terms in queries: {', '.join(exclude)}\n"
        prompt += "\n"
    
    prompt += (
        "Generate 5-7 specific, targeted retrieval queries that together cover all the "
        "evidence needed to write a comprehensive document on this topic.\n\n"
        "Each query should target ONE specific fact family:\n"
        "- Jurisdiction-specific regulatory authority and current product/policy status\n"
        "- Scientific evidence with specific percentages, study names, dates\n"
        "- Regulatory authorizations in comparable markets (with dates)\n"
        "- Market/economic data (market share, revenue, investment figures)\n"
        "- Comparative country case studies with specific statistics\n"
        "- Opposition/stakeholder positions (WHO, health ministry stance)\n"
        "- Policy precedents or legislation with names and years\n\n"
        "Rules:\n"
        "- Each query: 5-15 words, specific enough to find one fact\n"
        "- Include numbers, dates, or named entities where possible\n"
        "- Output ONLY a JSON array of strings, no explanation\n\n"
        'Example: ["FDA MRTP authorization IQOS July 2020", '
        '"Japan HTP market share adult smoking decline 2022", '
        '"Thailand Disease Control Department tobacco regulatory authority"]'
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 400,
            "temperature": 0.2,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            queries = json.loads(raw)
            if isinstance(queries, list):
                result = [str(q).strip() for q in queries if q and str(q).strip()][:7]
                logger.info(f"AGENTIC_PLAN | planned_queries={len(result)}")
                return result
    except Exception as e:
        logger.warning(f"Agentic research planning failed (non-fatal): {e}")

    return []


def _llm_identify_gaps(research_results: Dict[str, Any], requirements: Dict[str, Any]) -> List[str]:
    """
    Agentic Phase 3: LLM reviews all collected sources and identifies specific
    missing facts that need a second round of targeted retrieval.
    Returns 0-3 targeted gap-fill queries. Empty list = no gaps.
    """
    if not LITELLM_KEY:
        return []

    topic        = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    background   = requirements.get('background', '')

    # Build a compact summary of what was found
    sources = research_results.get('all_sources', [])
    if not sources:
        return []

    found_summaries = []
    for i, s in enumerate(sources[:10]):
        summary_preview = (s.get('summary') or '')[:200]
        found_summaries.append(f"[{i+1}] {s.get('type','?')}: {s.get('title','?')} — {summary_preview}")

    found_text = '\n'.join(found_summaries)

    prompt = (
        "You are a research completeness reviewer.\n\n"
        f"RESEARCH TOPIC: {topic}\n"
        f"JURISDICTION: {jurisdiction}\n"
        f"BACKGROUND: {background if background else 'N/A'}\n\n"
        f"SOURCES FOUND SO FAR:\n{found_text}\n\n"
        "Review the sources above. Identify what SPECIFIC facts are MISSING that would be "
        "critical for a comprehensive regulatory submission on this topic.\n\n"
        "Focus only on major gaps:\n"
        "- Missing specific statistics or figures mentioned in background but not found\n"
        "- Missing regulatory authority or legislation details for the jurisdiction\n"
        "- Missing comparative market data from key reference countries\n"
        "- Missing scientific evidence that would strengthen the document\n\n"
        "For each gap, generate ONE targeted search query (5-12 words) that would find it.\n\n"
        "Rules:\n"
        "- Maximum 3 gap queries (only the most critical gaps)\n"
        "- If research is already sufficient, return an empty array []\n"
        "- Output ONLY a JSON array of strings, no explanation\n\n"
        'Example: ["PMI R&D investment USD 16 billion smoke-free", "Japan MHLW smoking rate decline 2022"]'
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300,
            "temperature": 0.2,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            gaps = json.loads(raw)
            if isinstance(gaps, list):
                result = [str(q).strip() for q in gaps if q and str(q).strip()][:3]
                logger.info(f"AGENTIC_GAP_REVIEW | gaps_found={len(result)} | queries={result}")
                return result
    except Exception as e:
        logger.warning(f"Agentic gap review LLM call failed (non-fatal): {e}")

    return []


def _fill_research_gaps(gap_queries: List[str], research_results: Dict[str, Any], requirements: Dict[str, Any]) -> None:
    """
    Agentic Phase 3.5: Run targeted KB + web searches for identified gaps.
    Appends new sources directly to research_results. Runs in parallel.
    """
    if not gap_queries:
        return

    jurisdiction = requirements.get('jurisdiction', '')

    def _run_gap_query(gap_query: str) -> Dict[str, Any]:
        """Run one gap query against KB and web, return combined sources."""
        combined = {'sources': [], 'citations': [], 'queries': [gap_query]}

        # KB search for this specific gap
        try:
            gap_requirements = requirements.copy()
            gap_requirements['topic'] = gap_query  # Override topic with the gap query
            kb_result = search_internal_knowledge(gap_requirements)
            combined['sources'].extend(kb_result.get('sources', []))
            combined['citations'].extend(kb_result.get('citations', []))
        except Exception as e:
            logger.warning(f"Gap-fill KB search failed for '{gap_query[:40]}': {e}")

        # Web search for this specific gap
        try:
            gap_requirements_web = requirements.copy()
            gap_requirements_web['topic'] = gap_query
            web_result = search_web_tavily(gap_requirements_web)
            combined['sources'].extend(web_result.get('sources', []))
            combined['citations'].extend(web_result.get('citations', []))
        except Exception as e:
            logger.warning(f"Gap-fill web search failed for '{gap_query[:40]}': {e}")

        return combined

    # Run all gap queries in parallel
    with ThreadPoolExecutor(max_workers=min(len(gap_queries), 3)) as ex:
        futures = {ex.submit(_run_gap_query, q): q for q in gap_queries}
        for future in as_completed(futures):
            try:
                result = future.result()
                new_sources = result.get('sources', [])
                # Deduplicate against existing sources by URL
                existing_urls = {s.get('url', '').lower() for s in research_results['all_sources'] if s.get('url')}
                for s in new_sources:
                    s_url = (s.get('url') or '').lower()
                    if s_url and s_url not in existing_urls:
                        research_results['all_sources'].append(s)
                        existing_urls.add(s_url)
                research_results['formatted_citations'].extend(result.get('citations', []))
                research_results['search_queries'].extend(result.get('queries', []))
            except Exception as e:
                logger.warning(f"Gap-fill future failed: {e}")

    logger.info(
        f"AGENTIC_GAP_FILL | gap_queries={len(gap_queries)} "
        f"| total_sources_after={len(research_results['all_sources'])}"
    )


def _extract_structured_facts(all_sources: List[Dict], requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Extract structured facts from top sources for the drafter to use verbatim.
    
    Uses one Gemini call to extract precise statistics, legislation names, dates,
    and authority names from the highest-scoring sources.
    Returns a dict with: statistics, legislation, authorities, key_dates.
    """
    if not LITELLM_KEY:
        return {}
    
    # Pick top 5 by relevance score
    scored = sorted(
        [s for s in all_sources if s.get('relevance_score')],
        key=lambda x: x.get('relevance_score', 0), reverse=True
    )[:5]
    
    if not scored:
        return {}
    
    source_text = "\n".join(
        f"[{i+1}] {s.get('title','')}: {(s.get('summary',''))[:400]}"
        for i, s in enumerate(scored)
    )
    
    topic = requirements.get('topic', '')
    jurisdiction = requirements.get('jurisdiction', '')
    
    prompt = (
        f"Extract specific factual data from these sources about: {topic} in {jurisdiction}\n\n"
        f"Sources:\n{source_text}\n\n"
        "Return ONLY a JSON object with these arrays:\n"
        '- "statistics": [{"metric":"...","value":"...","year":"...","source_index":N}]\n'
        '- "legislation": [{"name":"...","year":"...","status":"..."}]\n'
        '- "authorities": [{"name":"...","role":"..."}]\n'
        '- "key_dates": [{"event":"...","date":"..."}]\n\n'
        "Rules: Only include facts explicitly stated in sources. No inferences. Max 10 items total."
    )
    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        body = {
            "model": GEMINI_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0,
            "max_tokens": 1500,
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {LITELLM_KEY}",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        raw = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        raw = raw.strip()
        if raw.startswith('```'):
            raw = '\n'.join(raw.split('\n')[1:-1]).strip()
        
        result = json.loads(raw)
        logger.info(
            f"STRUCTURED_FACTS | stats={len(result.get('statistics',[]))} "
            f"| legislation={len(result.get('legislation',[]))} "
            f"| authorities={len(result.get('authorities',[]))} "
            f"| dates={len(result.get('key_dates',[]))}"
        )
        return result
    except Exception as e:
        logger.warning(f"Structured fact extraction failed (non-fatal): {e}")
        return {}


def _extract_semantic_signals(
    topic: str, background: str, use_case: str, category: str, jurisdiction: str = ''
) -> Dict[str, str]:
    """
    Use LLM to extract domain-meaningful signals from raw input fields.

    Returns:
        topic_core       — core subject terms, compound concepts preserved
        background_signal — domain-relevant facts stripped of drafting instructions

    Falls back silently to regex if the LLM call fails.
    """
    if LITELLM_KEY and (topic or background):
        prompt = (
            "You are a semantic signal extractor for a document vector retrieval system.\n\n"
            "Given the raw user input below, extract only the domain-relevant semantic content "
            "that would help retrieve matching documents from a knowledge base.\n\n"
            f"Topic: {topic or 'N/A'}\n"
            f"Background: {background or 'N/A'}\n"
            f"Jurisdiction: {jurisdiction or 'N/A'}\n"
            f"Use case: {use_case or 'N/A'}\n"
            f"Category: {category or 'N/A'}\n\n"
            "Extract:\n"
            "1. topic_core — 3 to 8 words capturing the core subject. "
            "Preserve compound domain concepts (e.g. 'heated tobacco products excise duty'). "
            "Strip generic words: submission, document, letter, regarding, about, a, an, the.\n"
            "2. background_signal — up to 100 characters of domain-relevant facts from the background. "
            "Ignore all drafting instructions (please draft, I need, write a, ensure, include, etc.). "
            "Return only factual content: regulation names, policy references, specific requirements.\n\n"
            "Output ONLY a JSON object with exactly two keys. No explanation.\n"
            'Example: {"topic_core": "heated tobacco products excise duty", '
            '"background_signal": "CBIC notification 2023 duty revision HTP"}'
        )
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            data = {
                "model": LITELLM_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 150,
            }
            headers = {
                "Authorization": f"Bearer {LITELLM_KEY}",
                "Content-Type": "application/json",
            }
            req = urllib.request.Request(
                LITELLM_URL,
                data=json.dumps(data).encode('utf-8'),
                headers=headers,
                method='POST',
            )
            with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['choices'][0]['message']['content'].strip()
                if raw.startswith('```'):
                    raw = '\n'.join(raw.split('\n')[1:-1]).strip()
                signals = json.loads(raw)
                if isinstance(signals, dict) and 'topic_core' in signals:
                    result = {
                        'topic_core': str(signals.get('topic_core', '')).strip(),
                        'background_signal': str(signals.get('background_signal', '')).strip(),
                    }
                    logger.info(
                        f"LLM_SIGNAL_EXTRACTION | "
                        f"topic_core='{result['topic_core']}' | "
                        f"background_signal='{result['background_signal']}'"
                    )
                    return result
        except Exception as e:
            logger.warning(f"LLM signal extraction failed, falling back to regex: {e}")

    # Regex fallback — used only when LLM is unavailable or fails
    _STOPWORDS = {
        'a', 'an', 'the', 'for', 'of', 'in', 'on', 'at', 'to', 'with',
        'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be', 'been',
        'about', 'regarding', 'related', 'concerning', 'submission', 'document',
    }
    tokens = re.split(r'[\s,;]+', (topic or '').lower())
    topic_core = ' '.join(t for t in tokens if t and t not in _STOPWORDS and len(t) > 2)

    bg_cleaned = re.sub(
        r'(?i)\b(please|kindly|draft|write|prepare|create|generate|i need|i want|'
        r'can you|could you|help me|assist|ensure|include|provide)\b[^.]*?(?=[A-Z]|\.|$)',
        ' ', background or ''
    )
    background_signal = re.sub(r'\s+', ' ', bg_cleaned).strip()[:150]

    return {'topic_core': topic_core, 'background_signal': background_signal}


def _derive_intent(use_case: str, category: str) -> str:
    """Map use_case/category to a semantic intent phrase for vector search."""
    _INTENT_MAP = {
        'submission': 'regulatory submission compliance',
        'report': 'policy analysis report',
        'communication': 'stakeholder communication',
        'response': 'regulatory response',
        'application': 'regulatory application',
        'representation': 'industry representation',
        'briefing': 'policy briefing',
        'comment': 'public comment regulatory',
        'appeal': 'regulatory appeal',
        'petition': 'regulatory petition',
    }
    combined = f"{use_case} {category}".lower()
    for key, intent in _INTENT_MAP.items():
        if key in combined:
            return intent
    return (use_case or category or '').strip()


def _derive_entity(target_audience: str) -> str:
    """Map target_audience to a semantic entity phrase for vector search."""
    _ENTITY_MAP = {
        'cbic': 'customs excise authority',
        'gst': 'goods services tax authority',
        'mohfw': 'health ministry regulator',
        'ministry of health': 'health ministry regulator',
        'who': 'world health organization international',
        'cpcb': 'environment pollution control authority',
        'fssai': 'food safety standards authority',
        'sebi': 'securities exchange board regulator',
        'rbi': 'reserve bank central authority',
        'parliament': 'legislative authority',
        'committee': 'parliamentary standing committee',
        'ministry': 'government ministry authority',
        'department': 'government department',
        'tribunal': 'judicial regulatory tribunal',
    }
    audience_lower = (target_audience or '').lower()
    for key, entity in _ENTITY_MAP.items():
        if key in audience_lower:
            return entity
    return (target_audience or '').strip()


def _llm_enrich_queries(
    topic_core: str, intent: str, entity: str,
    jurisdiction: str, background_signal: str
) -> List[str]:
    """Call LLM to generate up to 2 semantically enriched vector search queries."""
    if not LITELLM_KEY or not topic_core:
        return []

    prompt = (
        "Generate exactly 2 short semantic search queries for a vector database retrieval task.\n\n"
        "Structured input:\n"
        f"- Topic: {topic_core}\n"
        f"- Intent: {intent}\n"
        f"- Target entity: {entity}\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Domain context: {background_signal or 'N/A'}\n\n"
        "Rules:\n"
        "- Each query must be 5-12 words\n"
        "- Reflect domain document meaning, not user phrasing\n"
        "- Query 1 must be generic and NOT mention any country or jurisdiction.\n"
        "- Query 2 can optionally include the country or jurisdiction.\n"
        "- Queries should match what relevant source documents would contain\n"
        "- Output ONLY a JSON array of 2 strings, no explanation\n\n"
        'Example: ["tobacco excise policy regulatory compliance", '
        '"CBIC heated tobacco products duty submission"]'
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            enriched = json.loads(raw)
            if isinstance(enriched, list):
                return [q for q in enriched if isinstance(q, str) and q.strip()][:2]
    except Exception as e:
        logger.warning(f"LLM query enrichment failed (non-fatal): {e}")
    return []


def search_internal_knowledge(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Search PMI internal knowledge base using semantic query generation."""

    jurisdiction    = requirements.get('jurisdiction', '')
    topic           = requirements.get('topic', '')
    target_audience = requirements.get('target_audience', '')
    background      = requirements.get('background', '')
    category        = requirements.get('category', '')
    use_case        = requirements.get('use_case', '')

    # Step 1 — Extract semantic signals from raw input fields
    signals           = _extract_semantic_signals(topic, background, use_case, category, jurisdiction)
    topic_core        = signals['topic_core']
    background_signal = signals['background_signal']
    intent            = _derive_intent(use_case, category)
    entity            = _derive_entity(target_audience)

    # Step 2 — Base query: all signals combined including background
    base_query = ' '.join(filter(None, [jurisdiction, topic_core, background_signal, intent, entity])).strip()

    # Step 3 — Deterministic variants covering different signal combinations
    query_1 = ' '.join(filter(None, [jurisdiction, topic_core, background_signal, intent])).strip()
    query_2 = ' '.join(filter(None, [entity, jurisdiction, topic_core, background_signal])).strip()
    query_3 = ' '.join(filter(None, [category, intent, jurisdiction, topic_core, background_signal])).strip()

    # Generic variants without jurisdiction to allow cross-border matches
    query_generic_1 = ' '.join(filter(None, [topic_core, background_signal, intent])).strip()
    query_generic_2 = ' '.join(filter(None, [topic_core, intent, entity, background_signal])).strip()

    seen: set = set()
    deterministic = [
        q for q in [base_query, query_1, query_2, query_3, query_generic_1, query_generic_2]
        if q and not (q in seen or seen.add(q))
    ]

    # Step 4 — LLM enrichment: up to 2 additional semantically rich queries
    llm_queries = _llm_enrich_queries(topic_core, intent, entity, jurisdiction, background_signal)

    # Step 4b — Include agentic planned queries if available
    planned_queries = requirements.get('_planned_queries', [])

    # Step 5 — Combine deterministic + LLM + planned, cap at 8 (allow more due to planned)
    all_queries = (deterministic + llm_queries + planned_queries)
    # Deduplicate while preserving order
    seen_q: set = set()
    dedup_queries = []
    for q in all_queries:
        q_lower = q.lower().strip()
        if q_lower and q_lower not in seen_q:
            seen_q.add(q_lower)
            dedup_queries.append(q)
    all_queries = dedup_queries[:8]

    logger.info(
        f"KB_SEMANTIC_QUERIES | count={len(all_queries)} "
        f"| deterministic={len(deterministic)} | llm={len(llm_queries)} | planned={len(planned_queries)}"
    )

    # Step 6 — Execute vector search with score-gated waterfall
    internal_sources: List[Dict] = []
    citations: List[Dict] = []
    used_query = all_queries[0] if all_queries else base_query
    kb_results: List[Dict] = []

    # Step 6a — LLM-driven soft theme mapping for KB metadata filtering
    # The LLM identifies relevant theme-level-1 and theme-level-2 from the topic/background.
    # These are used as SOFT filters (if 0 results, retry without theme filters).
    kb_theme_1 = ''
    kb_theme_2 = ''
    try:
        if LITELLM_KEY and topic_core:
            theme_prompt = (
                "You are classifying a research query for a knowledge base filter.\n\n"
                f"Topic: {topic_core}\n"
                f"Background: {background_signal[:200]}\n"
                f"Jurisdiction: {jurisdiction}\n\n"
                "LEVEL 1 OPTIONS (pick the single BEST match):\n"
                "- Smoke-free products (SFP)/ heated tobacco products (HTP)\n"
                "- Combustible cigarettes\n"
                "- Corporate Equity\n"
                "- Others\n\n"
                "LEVEL 2 OPTIONS (pick the single BEST match):\n"
                "- Regulatory, Product standard system\n"
                "- Fiscal and Taxes\n"
                "- Illicit Trade\n"
                "- Scientific\n"
                "- Youth Access Prevention\n"
                "- Sustainability\n"
                "- Others\n\n"
                "Return ONLY a JSON: {\"level_1\": \"...\", \"level_2\": \"...\"}\n"
                "If the topic doesn't clearly fit one category, use \"Others\"."
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            data = json.dumps({
                "model": LITELLM_MODEL,
                "messages": [{"role": "user", "content": theme_prompt}],
                "max_tokens": 100,
            }).encode('utf-8')
            headers_req = {
                "Authorization": f"Bearer {LITELLM_KEY}",
                "Content-Type": "application/json",
            }
            req = urllib.request.Request(LITELLM_URL, data=data, headers=headers_req, method='POST')
            with urllib.request.urlopen(req, context=ctx, timeout=10) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['choices'][0]['message']['content'].strip()
                if raw.startswith('```'):
                    raw = '\n'.join(raw.split('\n')[1:-1]).strip()
                theme_result = json.loads(raw)
                kb_theme_1 = theme_result.get('level_1', '')
                kb_theme_2 = theme_result.get('level_2', '')
                # Don't filter on "Others" — it's too generic
                if kb_theme_1 == 'Others':
                    kb_theme_1 = ''
                if kb_theme_2 == 'Others':
                    kb_theme_2 = ''
                logger.info(f"KB_THEME_MAP | topic='{topic_core[:50]}' | L1='{kb_theme_1}' | L2='{kb_theme_2}'")
    except Exception as e:
        logger.warning(f"KB theme mapping failed (non-fatal, will search without theme filter): {e}")

    try:
        if search_pmi_knowledge_base:
            kb_filters = {}
            if jurisdiction:
                kb_filters['jurisdiction'] = jurisdiction

            # First attempt: with theme filters (soft)
            for candidate_query in all_queries:
                results = search_pmi_knowledge_base(
                    query=candidate_query, max_results=15, filters=kb_filters,
                    jurisdiction=jurisdiction, theme_level_1=kb_theme_1, theme_level_2=kb_theme_2
                )
                if results:
                    max_score = max((r.get('similarity_score', 0) for r in results), default=0)
                    logger.info(
                        f"KB_QUERY | query='{candidate_query[:80]}' "
                        f"| results={len(results)} | max_score={max_score:.3f}"
                    )
                    if max_score >= 0.50:
                        kb_results = results
                        used_query = candidate_query
                        logger.info(f"KB_HIT | query='{candidate_query[:80]}'")
                        break
                else:
                    logger.info(f"KB_QUERY | query='{candidate_query[:80]}' | results=0")

            # Fallback: if theme filters produced 0 results, retry without them
            if not kb_results and (kb_theme_1 or kb_theme_2):
                logger.info(f"KB_FALLBACK | theme filters produced 0 results, retrying without theme filters")
                for candidate_query in all_queries:
                    results = search_pmi_knowledge_base(
                        query=candidate_query, max_results=15, filters=kb_filters,
                        jurisdiction=jurisdiction
                    )
                    if results:
                        max_score = max((r.get('similarity_score', 0) for r in results), default=0)
                        if max_score >= 0.50:
                            kb_results = results
                            used_query = candidate_query
                            logger.info(f"KB_FALLBACK_HIT | query='{candidate_query[:80]}' | score={max_score:.3f}")
                            break

            # Category-aware KB result limit
            cat_lower = (category or '').lower()
            if 'white paper' in cat_lower or 'narrative' in cat_lower:
                kb_limit = 8  # More KB sources for comprehensive documents
            else:
                kb_limit = 5

            # Apply limit to kb_results before processing
            kb_results = kb_results[:kb_limit]
            logger.info(f"KB_RESULTS | category={category} | limit={kb_limit} | results={len(kb_results)}")

            seen_titles = set()
            for i, result in enumerate(kb_results):
                if result.get('similarity_score', 0) < 0.50:
                    continue

                doc_name = (
                    result.get('document_title')
                    or result.get('metadata', {}).get('file_name')
                    or f'Document_{i}'
                )
                
                # Extract URL properly from any possible metadata field
                meta = result.get('metadata', {})
                sp_url = (
                    result.get('sharepoint_url') or 
                    meta.get('sharepoint_url') or 
                    meta.get('sharepoint_link') or 
                    meta.get('source_url') or 
                    meta.get('url') or 
                    meta.get('s3_bucket_URL') or 
                    ""
                )
                
                # Exclude metadata.json files from sources and citations
                if 'metadata.json' in str(doc_name).lower() or 'metadata.json' in str(sp_url).lower():
                    continue
                
                internal_sources.append({
                    'title': doc_name,
                    'source': 'PMI Knowledge Base',
                    'type': 'internal_knowledge',
                    'date': datetime.now().strftime('%Y-%m-%d'),
                    'relevance_score': round(float(result.get('similarity_score', 0)), 3),
                    'summary': result.get('content', ''),
                })
                
                # Deduplicate citations and remove snippets
                if doc_name not in seen_titles:
                    seen_titles.add(doc_name)
                    
                    citations.append({
                        'title': f"{doc_name}",
                        'url': sp_url,
                        'source_type': 'knowledge_base'
                    })
    except Exception as e:
        logger.error(f"Error querying KB: {str(e)}")

    if not internal_sources:
        logger.warning("KB search returned no results.")

    return {
        'sources': internal_sources,
        'citations': citations,
        'queries': [used_query] + [q for q in all_queries if q != used_query],
    }

def summarize_uploaded_file_with_llm(text: str, requirements: Dict[str, Any]) -> str:
    """Enhanced file summarizer: extracts BOTH facts/evidence AND structure/form/intent.

    Captures three dimensions:
      A. FACTS & EVIDENCE — statistics, laws, citations, dates (tagged with source jurisdiction)
      B. STRUCTURE & FORM — section sequence, argument flow, format style, tone, the asks
      C. INTENT SUMMARY — purpose and outcome of the document

    Also receives tone_requirements (previously missing) and detects exemplar/similar intent
    from the background field so it can prioritize form extraction for "make a similar doc" requests.
    """
    if not LITELLM_KEY or not text.strip():
        return text[:3000]  # Raised fallback from 2000

    topic = requirements.get('topic', 'General Topic')
    background = requirements.get('background', '')
    jurisdiction = requirements.get('jurisdiction', 'Global')
    target_audience = requirements.get('target_audience', 'General')
    target_lang = requirements.get('target_language', 'English')
    category = requirements.get('category', '')
    use_case = requirements.get('use_case', '')
    tone_requirements = requirements.get('tone_requirements', '')  # NEW: was missing

    # Detect if this is a Letters scenario
    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()
    is_letter = 'letter' in cat_lower or 'letter' in uc_lower

    extra_context = ""
    if is_letter:
        subject = requirements.get('topic_of_letter') or requirements.get('topicOfLetter') or ''
        if subject:
            extra_context = f"\n- Subject of the Letter: {subject}"

    # Detect "exemplar/similar" intent from background
    _bg_lower = (background or '').lower()
    is_exemplar = any(cue in _bg_lower for cue in [
        'similar submission', 'similar document', 'similar letter', 'similar draft',
        'refer to attached', 'based on the attached', 'along the lines',
        'replicate', 'mirror this', 'same format', 'use as template',
        'create a similar', 'prepare a similar',
    ])

    exemplar_instruction = ""
    if is_exemplar:
        exemplar_instruction = (
            "\n⚠️ IMPORTANT: This file is an EXEMPLAR/TEMPLATE — the user wants to CREATE A "
            f"SIMILAR DOCUMENT for a DIFFERENT context (target: {jurisdiction}). Focus HEAVILY "
            "on extracting the STRUCTURE, ARGUMENT FLOW, and FORMAT in section B below. "
            f"Tag all facts with their SOURCE jurisdiction — do NOT assert them as facts about {jurisdiction}.\n"
        )

    prompt = f"""You are an expert corporate research assistant supporting a regulatory affairs team.
Your task is to analyze the uploaded file and extract both its CONTENT and its STRUCTURE in the context of the user's request.

RESEARCH CONTEXT:
- Category: {category}
- Target Country/Jurisdiction: {jurisdiction}
- Research Topic: {topic}
- Background: {background or 'N/A'}
- Target Audience: {target_audience or 'N/A'}
- Tone Requirements: {tone_requirements or 'N/A'}{extra_context}
{exemplar_instruction}
Uploaded File Content:
<file_content>
{text}
</file_content>

EXTRACT THE FOLLOWING (be exhaustive, do NOT invent facts not in the file):

## A. FACTS & EVIDENCE
- Key statistics, percentages, dollar amounts, specific dates
- Named legislation, regulatory bodies, authorities cited
- Scientific studies, clinical data, regulatory decisions referenced
- Named organizations, individuals, or specific policy positions
- TAG each fact with its source jurisdiction in brackets (e.g., [Vietnam], [Global]) when it differs from the target jurisdiction "{jurisdiction}"

## B. STRUCTURE & FORM
- Document type and format (letter, briefing note, white paper, submission, etc.)
- Section/argument sequence (numbered list of how the document flows from start to end)
- Opening framing and closing approach
- Tone and register (formal/informal, advocacy/neutral, balanced, etc.)
- Who it is addressed to, who it is from, what it explicitly asks/requests
- Any distinctive stylistic patterns (paragraph length, use of headings, citations style)

## C. INTENT SUMMARY
- In 2-3 sentences: what is the PURPOSE of this document and what outcome does it seek?

Write the output directly in {target_lang}. Prioritize completeness — capture the full gist."""

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 3500,  # Raised from 2000 for structure+facts+intent
            "temperature": 0.2,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            summary = res['choices'][0]['message']['content'].strip()
            return summary
    except Exception as e:
        logger.warning(f"LLM uploaded file summarization failed, falling back: {e}")
        return text[:3000]

def summarize_web_content_with_llm(text: str, requirements: Dict[str, Any], source_url: str) -> str:
    """Uses Bedrock (via LiteLLM) to perform Query-Focused Summarization (QFS) on raw web content."""
    if not LITELLM_KEY or not text.strip():
        return text[:1500] # Safe fallback
        
    topic = requirements.get('topic', 'General Regulatory Topic')
    background = requirements.get('background', '')
    jurisdiction = requirements.get('jurisdiction', 'Global')
    target_audience = requirements.get('target_audience', 'General')
    target_lang = requirements.get('target_language', 'English')
    category = requirements.get('category', '')
    use_case = requirements.get('use_case', '')
    
    # Detect if this is a Letters scenario
    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()
    is_letter = 'letter' in cat_lower or 'letter' in uc_lower
    
    extra_context = ""
    if is_letter:
        subject = requirements.get('topic_of_letter') or requirements.get('topicOfLetter') or ''
        if subject:
            extra_context = f"\n- Subject of the Letter: {subject}"
            
    prompt = (
        "You are an expert corporate regulatory research assistant.\n"
        "Your task is to analyze raw text scraped from a webpage and produce a dense, highly focused summary "
        "tailored specifically to the following research query.\n\n"
        "RESEARCH REQUEST CONTEXT:\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Topic: {topic}\n"
        f"- Target Audience: {target_audience}\n"
        f"- Background Context: {background or 'N/A'}{extra_context}\n\n"
        f"SOURCE WEBPAGE URL: {source_url}\n\n"
        "RAW WEBPAGE CONTENT:\n"
        f"<webpage_content>\n{text}\n</webpage_content>\n\n"
        "INSTRUCTIONS:\n"
        "1. Identify and extract only key findings, statistics, official dates, and compliance mandates "
        "relevant to this specific research request.\n"
        "2. Strip out all noise (cookies notices, ads, irrelevant portal headers/footers).\n"
        "3. Keep the summary factual, dense, and objective. Do not invent details.\n"
        f"4. Write the summary directly in {target_lang} (approx 400-600 words).\n"
        "5. Output only the summary directly (no conversational prefix/suffix).\n"
        "6. Prioritize exact statistics, dollar amounts, dates, legislation names, and named authorities over narrative."
    )
    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 2000,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=45) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            summary = res['choices'][0]['message']['content'].strip()
            return summary
    except Exception as e:
        logger.warning(f"Web QFS failed for URL '{source_url}': {e}")
        return text[:1500]


def read_uploaded_file(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 1 — Read and extract text from the user-uploaded file stored in S3."""
    s3_key = (requirements.get('uploaded_file_s3_key') or '').strip()
    if not s3_key or 'metadata.json' in s3_key.lower():
        return {'sources': [], 'citations': [], 'queries': []}

    try:
        import io as _io
        response = s3.get_object(Bucket=DOCUMENT_BUCKET, Key=s3_key)
        file_bytes = response['Body'].read()
        file_name = s3_key.split('/')[-1]
        ext = file_name.rsplit('.', 1)[-1].lower() if '.' in file_name else ''

        # Base64 Auto-Decoding Check
        # Zip archives (.docx) always start with the magic bytes b'PK\x03\x04'
        if ext == 'docx' and not file_bytes.startswith(b'PK\x03\x04'):
            try:
                import base64 as _base64
                decoded_bytes = _base64.b64decode(file_bytes)
                if decoded_bytes.startswith(b'PK\x03\x04'):
                    file_bytes = decoded_bytes
                    logger.info("Successfully decoded Base64 encoded docx file from S3.")
            except Exception as b64_err:
                logger.warning(f"Failed to check/decode Base64 docx file: {b64_err}")

        text = ''
        if ext == 'txt':
            text = file_bytes.decode('utf-8', errors='ignore')
        elif ext == 'docx':
            try:
                from docx import Document as _DocxDoc  # type: ignore[import]
                doc = _DocxDoc(_io.BytesIO(file_bytes))
                paragraphs_text = '\n'.join(p.text for p in doc.paragraphs if p.text.strip())
                
                # Extract text from tables as well
                tables_text = []
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            for paragraph in cell.paragraphs:
                                if paragraph.text.strip():
                                    tables_text.append(paragraph.text.strip())
                
                # Combine paragraphs and table texts
                all_text_parts = []
                if paragraphs_text:
                    all_text_parts.append(paragraphs_text)
                if tables_text:
                    all_text_parts.append('\n'.join(tables_text))
                
                text = '\n'.join(all_text_parts)
            except Exception as docx_err:
                logger.warning(f"python-docx extraction failed, falling back to decode: {docx_err}", exc_info=True)
                text = file_bytes.decode('utf-8', errors='ignore')
        elif ext == 'pdf':
            try:
                import PyPDF2 as _PyPDF2
                reader = _PyPDF2.PdfReader(_io.BytesIO(file_bytes))
                text = '\n'.join(page.extract_text() for page in reader.pages if page.extract_text())
            except Exception as pdf_err:
                logger.warning(f"PyPDF2 extraction failed, falling back: {pdf_err}", exc_info=True)
                raw = file_bytes.decode('latin-1', errors='ignore')
                text = re.sub(r'[^\x20-\x7E\n]', ' ', raw)
                text = re.sub(r'\s+', ' ', text).strip()
        else:
            text = file_bytes.decode('utf-8', errors='ignore')

        # Read up to 100,000 characters to capture more of large documents
        text = text[:100000]
        
        # Summarize contextually with Bedrock LLM
        summarized_text = summarize_uploaded_file_with_llm(text, requirements)
        
        logger.info(f"UPLOADED_FILE_READ | key='{s3_key}' | ext={ext} | raw_chars={len(text)} | summary_chars={len(summarized_text)}")
        return {
            'sources': [{
                'title': file_name,
                'source': f's3://{DOCUMENT_BUCKET}/{s3_key}',
                'type': 'uploaded_file',
                'date': datetime.now().strftime('%Y-%m-%d'),
                'summary': summarized_text,
            }],
            'citations': [{'title': file_name, 'url': '', 'source_type': 'uploaded_file'}],
            'queries': [],
        }
    except Exception as e:
        logger.warning(f"Failed to read uploaded file '{s3_key}': {e}")
        return {'sources': [], 'citations': [], 'queries': []}


def _gemini_url_context(url: str) -> Dict[str, Any]:
    """
    Fetch and summarize a URL using Gemini's native url_context grounding tool,
    routed through the private LiteLLM proxy.

    Returns a dict with keys:
        content            : str   — summary text from Gemini (empty on failure)
        retrieval_status   : str   — e.g. 'URL_RETRIEVAL_STATUS_SUCCESS'
        output_len         : int   — character count of content
        error              : str   — non-empty when the call failed
    """
    if not LITELLM_KEY:
        return {'content': '', 'retrieval_status': 'NO_CREDENTIALS', 'output_len': 0, 'error': 'no LITELLM_KEY'}

    prompt = (
        f"Use the url_context tool to fetch and read this URL:\n{url}\n\n"
        "Then return ALL of the following in your response:\n"
        "1. ACCESSIBLE: yes or no (was the full page content readable?)\n"
        "2. TITLE: the page title\n"
        "3. FULL_CONTENT: the complete extracted text from the page — do NOT summarise, "
        "return as much raw content as possible including tables, numbers, dates, legislation names.\n"
        "4. SUMMARY: a 5–8 sentence factual summary of the key points.\n\n"
        "Format your response exactly like this:\n"
        "ACCESSIBLE: yes\n"
        "TITLE: <page title>\n"
        "FULL_CONTENT:\n<full text here>\n"
        "SUMMARY:\n<summary here>\n\n"
        "If the page is behind a login, paywalled, or truly inaccessible, respond:\n"
        "ACCESSIBLE: no\n"
        "TITLE: unknown\n"
        "FULL_CONTENT: none\n"
        "SUMMARY: Page could not be accessed."
    )
    body = {
        "model": GEMINI_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 4096,
        "tools": [{"url_context": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        url_ctx_meta = data.get('vertex_ai_url_context_metadata', [])
        retrieval_status = 'UNKNOWN'
        try:
            retrieval_status = url_ctx_meta[0]['urlMetadata'][0]['urlRetrievalStatus']
        except (KeyError, IndexError, TypeError):
            if url_ctx_meta:
                retrieval_status = str(url_ctx_meta)

        # Parse structured fields from the response
        content_stripped = content.strip()
        accessible = 'yes' if 'ACCESSIBLE: yes' in content_stripped else (
                     'no'  if 'ACCESSIBLE: no'  in content_stripped else 'unknown')

        return {
            'content':          content_stripped,
            'retrieval_status': retrieval_status,
            'accessible':       accessible,
            'output_len':       len(content_stripped),
            'error':            '',
        }
    except Exception as e:
        return {'content': '', 'retrieval_status': 'ERROR', 'output_len': 0, 'error': str(e)}


def _gemini_search_web(query: str) -> Dict[str, Any]:
    """
    Run a web search via Gemini's native google_search grounding tool,
    routed through the private LiteLLM proxy.

    Returns a dict with keys:
        content        : str        — Gemini's synthesized answer
        sources        : List[dict] — [{title, url}] from grounding metadata
        output_len     : int
        grounding_used : bool
        error          : str
    """
    if not LITELLM_KEY:
        return {'content': '', 'sources': [], 'output_len': 0, 'grounding_used': False, 'error': 'no LITELLM_KEY'}

    body = {
        "model": GEMINI_MODEL,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0,
        "max_tokens": 2048,
        "tools": [{"google_search": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        grounding_meta = data.get('vertex_ai_grounding_metadata', [])
        grounding_used = any(bool(g) for g in grounding_meta)

        # Extract cited sources from grounding chunks if present
        sources = []
        try:
            for entry in grounding_meta:
                for chunk in (entry.get('groundingChunks') or []):
                    web = chunk.get('web') or {}
                    if web.get('uri'):
                        sources.append({'title': web.get('title', ''), 'url': web['uri']})
        except Exception:
            pass

        return {
            'content': content.strip(),
            'sources': sources,
            'output_len': len(content),
            'grounding_used': grounding_used,
            'error': '',
        }
    except Exception as e:
        return {'content': '', 'sources': [], 'output_len': 0, 'grounding_used': False, 'error': str(e)}


def _gemini_extract_urls(urls: List[str]) -> Dict[str, str]:
    """
    Extract content from URLs using Gemini url_context tool.
    
    This is the central Gemini extraction function used by:
    - External links (user-provided URLs)
    - Internal links (after Tavily ranking)
    - Web search (after Tavily URL discovery)
    
    Returns {url: content} dict.
    Runs extractions in parallel (max 5 workers).
    """
    if not urls or not LITELLM_KEY:
        return {}
    
    result: Dict[str, str] = {}
    
    def _extract_one(url: str) -> tuple:
        try:
            g = _gemini_url_context(url)
            if g.get('accessible') == 'yes' and g.get('content'):
                return url, g['content']
            else:
                logger.warning(
                    f"GEMINI_EXTRACT | url='{url[:60]}' | status={g['retrieval_status']} | error={g.get('error','')}"
                )
                return url, ''
        except Exception as e:
            logger.warning(f"GEMINI_EXTRACT | url='{url[:60]}' failed: {e}")
            return url, ''
    
    with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as executor:
        futures = {executor.submit(_extract_one, u): u for u in urls}
        for future in as_completed(futures):
            url, content = future.result()
            if content:
                result[url] = content
    
    logger.info(f"GEMINI_EXTRACT | requested={len(urls)} | succeeded={len(result)}")
    return result


def _gemini_log_url(request_id: str, url: str, result: Dict[str, Any]) -> None:
    """Append a Gemini url_context result to the per-request comparison store."""
    with _gemini_comparison_lock:
        store = _gemini_comparison_store.setdefault(request_id, {'url_extractions': [], 'web_searches': []})
        store['url_extractions'].append({
            'url':               url,
            'retrieval_status':  result.get('retrieval_status', ''),
            'accessible':        result.get('accessible', 'unknown'),
            'content':           result.get('content', ''),
            'output_len':        result.get('output_len', 0),
            'error':             result.get('error', ''),
        })


def _gemini_log_search(request_id: str, query: str, result: Dict[str, Any]) -> None:
    """Append a Gemini google_search result to the per-request comparison store."""
    with _gemini_comparison_lock:
        store = _gemini_comparison_store.setdefault(request_id, {'url_extractions': [], 'web_searches': []})
        store['web_searches'].append({
            'query':           query,
            'content':         result.get('content', ''),
            'sources':         result.get('sources', []),
            'output_len':      result.get('output_len', 0),
            'grounding_used':  result.get('grounding_used', False),
            'error':           result.get('error', ''),
        })


def _tavily_search_domain(query: str, url: str) -> Dict[str, Any]:
    """
    Search Tavily within a specific domain and return the top result.
    Routes queries through the private VPC LiteLLM proxy if available.
    """
    if not query or not url:
        return {}
        
    try:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        # Detect private Bedrock / VPC gateway environment variables
        litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
        use_private_gateway = bool(litellm_key)

        if use_private_gateway:
            # Route through corporate VPC proxy. Search-tool name is team-scoped:
            # this key is only authorized for 'ccaiaa-dev-tavily' (plain 'tavily' -> 403).
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload_data = {
                "query": query,
                "max_results": 1,
                "search_depth": "advanced",
                "include_domains": [domain]
            }
        else:
            # Local developer laptop fallback to public API
            if not TAVILY_API_KEY:
                logger.warning("TAVILY_API_KEY not configured; skipping domain search.")
                return {}
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload_data = {
                "api_key": TAVILY_API_KEY,
                "query": query,
                "search_depth": "advanced",
                "include_domains": [domain],
                "max_results": 1,
            }

        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload_data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        results = data.get('results', [])
        if not results:
            logger.info(f"TAVILY_DOMAIN_SEARCH | no results | domain={domain}")
            return {}

        top = results[0]
        score = round(min(float(top.get('score', 0.0)), 1.0), 3)
        # Gateway returns 'snippet'; public Tavily returns 'content' — accept both.
        content = (top.get('content') or top.get('snippet') or '').strip()
        result = {
            'domain':  domain,
            'url':     top.get('url', url),
            'title':   (top.get('title') or '').strip(),
            'content': content,
            'score':   score,
        }
        logger.info(f"TAVILY_DOMAIN_SEARCH | domain={domain} | score={score} | content_chars={len(content)} | title='{result['title'][:60]}'")
        return result
        
    except Exception as e:
        logger.warning(f"Tavily domain search failed for '{url[:60]}': {e}")
        return {}


def _compute_description_score(topic: str, text: str) -> float:
    """
    Fallback relevance score (0.0–0.95) when Tavily domain search returns no result.
    Measures word overlap between request topic and a given text.

    Each matching meaningful word contributes 0.25, capped at 0.95.
    Returns a float on the same 0–1 scale as Tavily and KB scores.
    """
    _STOP = {
        'a', 'an', 'the', 'of', 'in', 'on', 'for', 'to', 'and', 'or',
        'with', 'is', 'are', 'at', 'by', 'its', 'this', 'that', 'as',
    }
    topic_words = {
        w for w in re.split(r'[\s,;.()\-]+', (topic or '').lower())
        if len(w) > 2 and w not in _STOP
    }
    text_words = {
        w for w in re.split(r'[\s,;.()\-]+', (text or '').lower())
        if len(w) > 2 and w not in _STOP
    }
    if not topic_words:
        return 0.0
    overlap = len(topic_words & text_words)
    return round(min(overlap * 0.25, 0.95), 3)


def _tavily_extract(urls: List[str], query: str = '') -> Dict[str, str]:
    """Return {url: content} for each URL — full page text where available.

    Gateway / VPC path (AWS_BEARER_TOKEN_BEDROCK is set):
      The private LiteLLM gateway has no /extract endpoint and does not forward
      include_raw_content to Tavily (confirmed by probe_gateway_tavily.py).
      Instead, we run one _tavily_search_domain call per URL in parallel.
      Each call queries the specific domain using the caller's topic query,
      which is the most reliable way to surface indexed content for that domain.

    Local / public path (TAVILY_API_KEY is set, no gateway token):
      Uses the dedicated api.tavily.com/extract endpoint, which returns full
      raw_content for each URL.

    Gemini comparison (parallel, non-blocking):
      For every URL, a Gemini url_context call is fired concurrently.
      Results are logged side-by-side with Tavily for comparison purposes.
      Tavily content is still used as the live source returned to callers.

    Args:
        urls:  List of URLs to fetch content for.
        query: Topic query string from the caller (topic + jurisdiction etc.).
               Used by the gateway path to drive domain-scoped searches.
               Falls back to URL-path hint when empty.

    Returns {} when no credentials are available or all calls fail (non-fatal).
    """
    if not urls:
        return {}

    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)

    if not use_private_gateway and not TAVILY_API_KEY:
        logger.warning("TAVILY_EXTRACT | no credentials available; skipping extract.")
        return {}

    # ── Fire Gemini url_context calls in parallel for comparison ─────────────
    gemini_futures: Dict[Any, str] = {}
    gemini_executor = ThreadPoolExecutor(max_workers=min(len(urls), 5))
    for u in urls:
        gemini_futures[gemini_executor.submit(_gemini_url_context, u)] = u

    if use_private_gateway:
        # ── Gateway path: one domain-search per URL, run in parallel ─────────
        result: Dict[str, str] = {}

        def _fetch_one(url: str) -> tuple:
            from urllib.parse import urlparse, unquote
            if query:
                search_query = query
            else:
                path_hint = unquote(urlparse(url).path).replace('/', ' ').replace('-', ' ').strip()
                search_query = (path_hint or urlparse(url).netloc)[:120]
            domain_result = _tavily_search_domain(search_query, url)
            content  = (domain_result.get('content') or '').strip()
            canonical = domain_result.get('url') or url
            return canonical, url, content

        with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as ex:
            futures = {ex.submit(_fetch_one, u): u for u in urls}
            for future in as_completed(futures):
                try:
                    canonical, original, content = future.result()
                    if content:
                        result[original]  = content
                        result[canonical] = content
                except Exception as e:
                    logger.warning(f"TAVILY_EXTRACT | domain fetch failed for '{futures[future][:60]}': {e}")

        logger.info(
            f"TAVILY_EXTRACT | gateway=private (domain-search) "
            f"| requested={len(urls)} | succeeded={sum(1 for u in urls if u in result)}"
        )

    else:
        # ── Public path: dedicated /extract endpoint ──────────────────────────
        result = {}
        try:
            payload_data = {
                "api_key": TAVILY_API_KEY,
                "urls": urls,
            }
            req = urllib.request.Request(
                'https://api.tavily.com/extract',
                data=json.dumps(payload_data).encode('utf-8'),
                headers={"Content-Type": "application/json"},
                method='POST',
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
                data = json.loads(resp.read().decode('utf-8'))

            for item in data.get('results', []):
                url  = item.get('url', '')
                text = (item.get('raw_content') or item.get('content') or '').strip()
                if url and text:
                    result[url] = text

            for fail in data.get('failed_results', []):
                logger.warning(f"TAVILY_EXTRACT | failed url='{fail.get('url','')}' | {fail.get('error','')}")

            logger.info(
                f"TAVILY_EXTRACT | gateway=public "
                f"| requested={len(urls)} | succeeded={len(result)}"
            )
        except Exception as e:
            logger.warning(f"Tavily extract failed (non-fatal): {e}")

    # ── Collect Gemini comparison results and write to accumulator ───────────
    try:
        for future in as_completed(gemini_futures, timeout=65):
            url = gemini_futures[future]
            try:
                g = future.result()
                tavily_len = len(result.get(url, ''))
                logger.info(
                    f"EXTRACT_COMPARE | url='{url[:80]}' "
                    f"| tavily_chars={tavily_len} "
                    f"| gemini_chars={g['output_len']} "
                    f"| gemini_accessible={g.get('accessible','unknown')} "
                    f"| gemini_retrieval_status={g['retrieval_status']} "
                    f"| gemini_error={g['error'] or 'none'}"
                )
                # Write full content to accumulator for S3 comparison file
                _request_id = _gemini_comparison_store.get('_active_request_id', '')
                if _request_id:
                    _gemini_log_url(_request_id, url, g)
            except Exception as e:
                logger.warning(f"EXTRACT_COMPARE | gemini future failed for '{url[:60]}': {e}")
    except Exception as e:
        logger.warning(f"EXTRACT_COMPARE | gemini collection error: {e}")
    finally:
        gemini_executor.shutdown(wait=False)

    return result


def fetch_user_external_links(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 3 — Fetch content from user-provided external URLs via Gemini.

    HYBRID APPROACH: User explicitly chose these URLs, so we extract directly with Gemini
    (no Tavily involvement). Gemini handles CAPTCHAs and JS-heavy pages better.
    
    Uses Tavily /search with domain filter for scoring only (0–1 scale compatibility).
    """
    external_links = [u for u in (requirements.get('external_links') or []) if u and str(u).startswith('http') and 'metadata.json' not in str(u).lower()]
    if not external_links:
        return {'sources': [], 'citations': [], 'queries': []}

    topic        = (requirements.get('topic') or '').strip()
    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    query        = ' '.join(filter(None, [topic, jurisdiction]))
    urls         = external_links[:5]

    # HYBRID CHANGE: Use Gemini extraction directly (no Tavily)
    extracted_contents = _gemini_extract_urls(urls)
    logger.info(f"EXTERNAL_LINKS | using Gemini extraction only (no Tavily) | extracted={len(extracted_contents)}/{len(urls)}")

    sources: List[Dict] = []
    citations: List[Dict] = []

    for url in urls:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        result = _tavily_search_domain(query, url)
        
        # Get raw content from Gemini extraction
        raw_content = extracted_contents.get(url, '').strip()
        extraction_engine = 'gemini' if raw_content else 'tavily'

        if result:
            page_title = result.get('title', '')
            score      = result.get('score', 0.0)
            title      = f"{domain} — {page_title}" if page_title else domain
            if not raw_content:
                raw_content = result.get('content', '')
                extraction_engine = 'tavily'
        else:
            # Fallback: compute score from word overlap
            if not raw_content:
                logger.warning(f"EXTERNAL_LINK | no content for '{url[:80]}'")
                continue
            score = _compute_description_score(topic, raw_content)
            title = domain

        # Run QFS engine to create a dense, context-focused summary
        summarized_content = summarize_web_content_with_llm(raw_content, requirements, url)

        sources.append({
            'title':           title,
            'source':          url,
            'type':            'external_url',
            'date':            datetime.now().strftime('%Y-%m-%d'),
            'relevance_score': score,
            'summary':         summarized_content,
            'url':             url,
            'extraction_engine': extraction_engine,
        })
        citations.append({'title': title, 'url': url, 'source_type': 'external_url'})
        logger.info(f"EXTERNAL_LINK | url='{url[:80]}' | score={score} | raw_chars={len(raw_content)} | summary_chars={len(summarized_content)}")

    return {'sources': sources, 'citations': citations, 'queries': []}


def _llm_select_curated_links(all_items: List[Dict], topic: str) -> List[str]:
    """
    Pass all curated portal descriptions to the LLM and ask it to pick
    the most relevant ones for the given request topic.

    Returns a list of selected item IDs (the DynamoDB 'id' field).
    Raises on any failure so the caller can fall back to keyword scoring.
    """
    if not LITELLM_KEY or not all_items:
        raise ValueError("LLM key not set or no items to evaluate")

    # Build a numbered portal list — only id + description used for matching
    portal_lines = []
    for i, item in enumerate(all_items, 1):
        row_id = item.get('id', f'row_{i}')
        desc   = (item.get('description') or '').strip()
        portal_lines.append(f"[{i}] ID: {row_id}\n    Description: {desc}")

    prompt = (
        "You are a research assistant selecting the most relevant government and regulatory "
        "portals for a document research task.\n\n"
        f"Request topic: {topic}\n\n"
        "Available portals (match based on description only):\n"
        + '\n'.join(portal_lines)
        + "\n\nSelect the portals whose description is most relevant to the request topic. "
        "A portal is relevant if its description indicates its content would help research "
        "or support the topic.\n"
        "Rules:\n"
        "- Return ONLY a valid JSON array of ID strings from the list above\n"
        "- Maximum 5 IDs, ordered by relevance (most relevant first)\n"
        "- If none are relevant, return an empty array []\n"
        "- No explanation, no markdown — only the JSON array\n\n"
        'Example: ["cbic.gov.in", "tobaccoboard.in"]'
    )

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    req = urllib.request.Request(
        LITELLM_URL,
        data=json.dumps({
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
        }).encode('utf-8'),
        headers={
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        },
        method='POST',
    )
    with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
        res = json.loads(resp.read().decode('utf-8'))
        raw = res['choices'][0]['message']['content'].strip()

    if raw.startswith('```'):
        raw = '\n'.join(raw.split('\n')[1:-1]).strip()

    selected_ids = json.loads(raw)
    if not isinstance(selected_ids, list):
        raise ValueError(f"LLM returned unexpected type: {raw}")

    logger.info(f"CURATED_LINKS_LLM | topic='{topic[:60]}' | selected_ids={selected_ids}")
    return [str(i) for i in selected_ids]


def _tavily_rank_curated_urls(urls: List[str], query: str, max_results: int = 5) -> List[Dict]:
    """
    Use Tavily domain search to rank curated URLs by relevance.
    
    This function takes a list of curated URLs from DynamoDB and uses Tavily's
    search API to rank them by relevance to the query. This acts as an intelligent
    filter to reduce 20-50 curated links down to the top 3-5 most relevant ones.
    
    Returns: List of dicts with keys: url, title, relevance_score
    """
    from urllib.parse import urlparse
    
    # Extract domains from URLs
    domains = list(set(urlparse(u).netloc for u in urls if u))
    if not domains:
        return []
    
    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)
    
    try:
        if use_private_gateway:
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        else:
            if not TAVILY_API_KEY:
                return []
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload = {
                "api_key": TAVILY_API_KEY,
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        
        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        ranked = []
        for result in data.get('results', []):
            ranked.append({
                'url': result.get('url', ''),
                'title': result.get('title', ''),
                'relevance_score': float(result.get('score', 0.7))
            })
        
        logger.info(f"TAVILY_RANK_CURATED | query='{query[:60]}' | input_urls={len(urls)} | ranked={len(ranked)}")
        return ranked[:max_results]
        
    except Exception as e:
        logger.warning(f"Tavily curated URL ranking failed: {e}")
        return []


def fetch_internal_weblinks(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 4 — Fetch content from curated links stored in pmi-agentic-ai-curated-links.

    Schema observed: id(PK), country, description, domain, is_active, language,
                     link (URL), requires_login, source_type, title, topics (StringSet), updated_at

    Steps:
      1. Scan with is_active=True, requires_login=False, country=jurisdiction
      2. Score each row by keyword overlap with request context (topics + description)
      3. Fetch page content from 'link' for the top-scoring rows (up to 5)
    """
    from boto3.dynamodb.conditions import Attr

    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    topic        = (requirements.get('topic') or '').strip()
    category     = (requirements.get('category') or '').strip()
    use_case     = (requirements.get('use_case') or '').strip()
    background   = (requirements.get('background') or '').strip()

    # Build a flat keyword set from all request context fields for scoring
    _STOPWORDS = {'', 'a', 'an', 'the', 'of', 'in', 'on', 'for', 'to', 'and', 'or', 'with', 'is', 'are', 'at'}
    context_text = f"{topic} {category} {use_case} {background}".lower()
    context_words = {w for w in re.split(r'[\s,;.()\-]+', context_text) if w and w not in _STOPWORDS and len(w) > 2}

    all_items: List[Dict] = []
    try:
        import functools
        import operator
        
        # Build country conditions to handle case-insensitivity and common abbreviations (e.g. IN for India)
        country_queries = [jurisdiction, jurisdiction.lower(), jurisdiction.upper(), jurisdiction.title()]
        if jurisdiction.lower() in ('india', 'in'):
            country_queries.extend(['in', 'IN', 'india', 'India'])
        elif jurisdiction.lower() in ('bangladesh', 'bd'):
            country_queries.extend(['bd', 'BD', 'bangladesh', 'Bangladesh'])
        elif jurisdiction.lower() in ('thailand', 'th'):
            country_queries.extend(['th', 'TH', 'thailand', 'Thailand'])
            
        country_set = {c.strip() for c in country_queries if c and c.strip()}
        
        # Fetch rows for the request's jurisdiction AND rows marked "global"
        # (global = curated links that apply regardless of country)
        # is_active + requires_login are always hard gates
        # Note: DynamoDB stores these as strings "TRUE"/"FALSE", not booleans
        base = Attr('is_active').eq('TRUE') & Attr('requires_login').eq('FALSE')
        
        if jurisdiction and country_set:
            # Dynamically build OR conditions for country list
            country_conditions = [Attr('country').eq(c) for c in country_set]
            country_filter = functools.reduce(operator.or_, country_conditions)
            filter_expr = base & (Attr('country').eq('global') | country_filter)
        else:
            filter_expr = base & Attr('country').eq('global')

        resp = curated_links_table.scan(FilterExpression=filter_expr)
        all_items = resp.get('Items', [])

        # Handle DynamoDB 1 MB pagination
        while 'LastEvaluatedKey' in resp:
            resp = curated_links_table.scan(
                FilterExpression=filter_expr,
                ExclusiveStartKey=resp['LastEvaluatedKey']
            )
            all_items.extend(resp.get('Items', []))

        logger.info(f"CURATED_LINKS_DDB | jurisdiction={jurisdiction} | fetched={len(all_items)}")

    except Exception as e:
        logger.warning(f"Failed to query curated links from DynamoDB: {e}")

    if not all_items:
        return {'sources': [], 'citations': [], 'queries': []}

    # ── LLM-based selection ────────────────────────────────────────────────────
    # Pass all portal descriptions to the LLM; let it decide relevance based on
    # semantic understanding of the request topic (handles synonyms, abbreviations,
    # domain concepts that keyword overlap misses).
    def run_hybrid_fallback(all_items: List[Dict], jurisdiction: str, context_words: set, context_text: str, requirements: Dict[str, Any]) -> List[Dict]:
        """Fallback using hybrid (semantic + keyword/topic/country) search over curated links."""
        import math
        scored_items = []
        
        # 1. Generate Query embedding using Bedrock
        query_embedding = None
        try:
            bedrock_runtime = boto3.client('bedrock-runtime', region_name=os.environ.get('AWS_REGION', 'eu-west-1'))
            response = bedrock_runtime.invoke_model(
                modelId='amazon.titan-embed-text-v2:0',
                body=json.dumps({"inputText": context_text[:8000]})
            )
            response_body = json.loads(response['body'].read())
            query_embedding = response_body.get('embedding')
        except Exception as e:
            logger.warning(f"Failed to generate query embedding for fallback: {e}")

        for item in all_items:
            # --- Component A: Country Weight ---
            country_score = 0.0
            row_country = (item.get('country') or '').strip().lower()
            if jurisdiction and row_country == jurisdiction.lower():
                country_score = 1.0
            elif row_country == 'global':
                country_score = 0.8
            
            # --- Component B: Semantic Score ---
            semantic_score = 0.0
            desc = (item.get('description') or '').strip()
            if query_embedding and desc:
                try:
                    # Generate candidate embedding on the fly (small payload, low latency)
                    response = bedrock_runtime.invoke_model(
                        modelId='amazon.titan-embed-text-v2:0',
                        body=json.dumps({"inputText": desc[:8000]})
                    )
                    response_body = json.loads(response['body'].read())
                    desc_embedding = response_body.get('embedding')
                    
                    if desc_embedding:
                        dot_product = sum(a * b for a, b in zip(query_embedding, desc_embedding))
                        norm1 = math.sqrt(sum(a * a for a in query_embedding))
                        norm2 = math.sqrt(sum(b * b for b in desc_embedding))
                        if norm1 > 0 and norm2 > 0:
                            semantic_score = dot_product / (norm1 * norm2)
                except Exception as e:
                    logger.warning(f"Failed to generate embedding for curated description: {e}")

            # --- Component C: Keyword Overlap Score ---
            desc_words = set(re.split(r'[\s,;.()\-]+', desc.lower()))
            overlap_count = len(context_words & desc_words)
            keyword_score = min(overlap_count / 5.0, 1.0) # Normalized up to 5 word overlaps
            
            # --- Component D: Topic Overlap Score ---
            topic_words = set()
            for t in (item.get('topics') or []):
                topic_words.update(re.split(r'[\s,;.()\-]+', str(t).lower()))
            topic_overlap = len(context_words & topic_words)
            topic_score = min(topic_overlap / 3.0, 1.0) # Normalized up to 3 topic overlaps
            
            # --- Combine into a Hybrid Score ---
            # Formula: 40% Semantic + 30% Keywords + 20% Topics + 10% Country
            combined_score = (
                (semantic_score * 0.40) + 
                (keyword_score * 0.30) + 
                (topic_score * 0.20) + 
                (country_score * 0.10)
            )
            
            scored_items.append((item, combined_score))
            
        # Sort and select top items
        scored_items.sort(key=lambda x: x[1], reverse=True)
        # Select items with non-zero hybrid score
        selected = [item for item, score in scored_items if score > 0.15][:3]
        if not selected:
            selected = [item for item, _ in scored_items[:3]]
        return selected

    selected: List[Dict] = []
    try:
        selected_ids = _llm_select_curated_links(all_items, topic)
        if not selected_ids:
            logger.info("LLM selected no curated links. Falling back to hybrid scoring.")
            selected = run_hybrid_fallback(all_items, jurisdiction, context_words, context_text, requirements)
        else:
            selected = [
                item for sid in selected_ids
                for item in all_items
                if str(item.get('id', '')) == sid
            ]
            logger.info(f"CURATED_LINKS_LLM | matched={len(selected)} | ids={selected_ids}")
    except Exception as e:
        logger.warning(f"LLM curated link selection failed, using hybrid fallback: {e}")
        selected = run_hybrid_fallback(all_items, jurisdiction, context_words, context_text, requirements)
        logger.info(f"CURATED_LINKS_FALLBACK | selected={len(selected)} links via hybrid scoring")

    if not selected:
        return {'sources': [], 'citations': [], 'queries': []}

    logger.info(f"CURATED_LINKS_DDB | final_selected={len(selected)}")

    # Build (url, title, description) tuples from selected DynamoDB items
    url_meta = [
        ((item.get('link') or '').strip(), (item.get('title') or '').strip(), (item.get('description') or '').strip())
        for item in selected
        if (item.get('link') or '').strip().startswith('http') and 'metadata.json' not in (item.get('link') or '').strip().lower()
    ]

    if not url_meta:
        return {'sources': [], 'citations': [], 'queries': []}

    # HYBRID APPROACH: Tavily ranks DynamoDB URLs, Gemini extracts top 3-5
    curated_urls = [u for u, _, _ in url_meta]
    logger.info(f"CURATED_LINKS | selected={len(curated_urls)} from DynamoDB, now ranking with Tavily")

    # Step 1: Tavily ranks the URLs
    ranked_urls = _tavily_rank_curated_urls(
        urls=curated_urls,
        query=topic,
        max_results=5
    )

    if not ranked_urls:
        # Fallback: use all URLs if Tavily ranking fails
        logger.warning("CURATED_LINKS | Tavily ranking failed, using all URLs with default scores")
        ranked_urls = [{'url': u, 'title': t, 'relevance_score': 0.7} for u, t, _ in url_meta[:5]]

    # Step 2: Gemini extracts from ranked URLs only
    extracted = _gemini_extract_urls([r['url'] for r in ranked_urls])
    logger.info(f"CURATED_LINKS | Gemini extracted {len(extracted)} of {len(ranked_urls)} ranked URLs")

    sources: List[Dict] = []
    citations: List[Dict] = []

    query = ' '.join(filter(None, [topic, jurisdiction]))

    # Build a lookup map for DDB metadata
    ddb_meta = {u: (t, d) for u, t, d in url_meta}

    for ranked in ranked_urls:
        url = ranked['url']
        tavily_title = ranked.get('title', '')
        tavily_score = ranked.get('relevance_score', 0.7)
        
        # Get DDB metadata
        ddb_title, ddb_desc = ddb_meta.get(url, ('', ''))
        
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        # Get raw content from Gemini extraction
        raw_content = extracted.get(url, '').strip()

        if not raw_content:
            logger.warning(f"INTERNAL_LINK | no Gemini content for '{url[:80]}'")
            continue

        # Combined title: DDB title + Tavily page title
        if ddb_title and tavily_title and ddb_title.lower() != tavily_title.lower():
            title = f"{ddb_title} — {tavily_title}"
        else:
            title = ddb_title or tavily_title or domain

        # Run QFS engine to create a dense, context-focused summary
        summarized_content = summarize_web_content_with_llm(raw_content, requirements, url)

        # Always prepend DDB description as authoritative context label
        summary = (f"{ddb_desc} | " if ddb_desc else '') + summarized_content
        if not summary.strip():
            continue

        sources.append({
            'title':           title,
            'source':          url,
            'type':            'internal_url',
            'date':            datetime.now().strftime('%Y-%m-%d'),
            'relevance_score': tavily_score,  # Use Tavily's ranking score
            'summary':         summary,
            'url':             url,
            'extraction_engine': 'gemini',
        })
        citations.append({'title': title, 'url': url, 'source_type': 'internal_url'})
        logger.info(f"INTERNAL_LINK | title='{title}' | tavily_score={tavily_score} | raw_chars={len(raw_content)} | QFS_chars={len(summarized_content)} | url='{url[:80]}'")

    return {'sources': sources, 'citations': citations, 'queries': []}


def _flag_numeric_inconsistencies(synthesis_result: Dict[str, Any]) -> Dict[str, Any]:
    """Flag internally inconsistent numeric claims in the synthesized findings.

    Catches the class of error seen in production where a figure is stated with the wrong
    magnitude/units — e.g. "INR 1,773.4 million ... more than 1% of GDP", which is
    impossible (millions cannot be ~1% of a multi-trillion economy; the real figure is in
    billions). We do NOT rewrite the number (the correct value must come from the source),
    we attach a `data_quality_flags` list and log a warning so the reviewer / HITL stage
    can verify before the figure reaches a final document.

    Non-destructive and category-agnostic — runs on every synthesis.
    """
    import re

    flags: List[str] = []
    items = (
        list(synthesis_result.get('key_findings', []) or [])
        + list(synthesis_result.get('policy_insights', []) or [])
    )

    # A magnitude word near a "% of GDP" claim is the high-confidence red flag.
    # Allow a few words between "of" and "gdp" (e.g. "1% of India's GDP",
    # "over 1% of the country's GDP").
    gdp_pattern = re.compile(r'%\s*of\b[^.\n]{0,30}?\bgdp', re.IGNORECASE)
    magnitude_pattern = re.compile(r'\b(thousand|million|billion|trillion|lakh|crore)\b', re.IGNORECASE)

    for item in items:
        text = str(item)
        low = text.lower()
        if gdp_pattern.search(low):
            mags = {m.lower() for m in magnitude_pattern.findall(low)}
            # "million"/"thousand"/"lakh" paired with a >=1% of GDP claim is almost
            # always a units error for any sizeable national economy.
            if mags & {'million', 'thousand', 'lakh'}:
                flags.append(
                    f"Possible units error: a '%-of-GDP' claim paired with a "
                    f"'{', '.join(sorted(mags & {'million', 'thousand', 'lakh'}))}' "
                    f"magnitude — verify against source. Claim: \"{text[:160]}\""
                )

    if flags:
        for f in flags:
            logger.warning(f"NUMERIC_INCONSISTENCY | {f}")
        synthesis_result['data_quality_flags'] = flags

    return synthesis_result


def synthesize_research_findings(research_results: Dict[str, Any], requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Use AWS Bedrock to synthesize research findings into key insights"""
    
    try:
        retrieved_docs = research_results.get('all_sources', [])
        query = research_results.get('search_queries', [''])[0] if research_results.get('search_queries') else 'No query'
        
        # All relevance_score values are now on 0–1 scale. uploaded_file has None — exclude it.
        real_scores = [doc['relevance_score'] for doc in retrieved_docs if doc.get('relevance_score') is not None]
        max_similarity_score = round(max(real_scores), 3) if real_scores else 0.0
        
        # Check if a user-uploaded file is present in the retrieved sources
        has_uploaded_file = any(doc.get('type') == 'uploaded_file' for doc in retrieved_docs)
        
        logger.info(f"query: {query}")
        logger.info(f"len(retrieved_docs): {len(retrieved_docs)}")
        logger.info(f"max similarity score: {max_similarity_score}")
        logger.info(f"has uploaded file: {has_uploaded_file}")

        # Prepare research summary for Bedrock
        sources_summary = create_sources_summary(research_results)
        
        if not retrieved_docs:
            return {
                "status": "no_data",
                "message": "No research sources found.",
                "key_findings": [],
                "policy_insights": [],
                "recommendations": [
                    "Refine your query",
                    "Upload relevant documents",
                    "Ensure correct domain/topic"
                ]
            }

        # Relevance gate: if the retrieval loop found ZERO genuinely on-topic sources,
        # do NOT synthesize from off-topic material — short-circuit to no_data so the
        # drafter shows a refine/upload message instead of a wrong document.
        if research_results.get('_relevant_count') == 0:
            logger.critical(
                "SYNTHESIS_GATE | zero on-topic sources — short-circuiting to no_data "
                "instead of drafting from off-topic research."
            )
            return {
                "status": "no_data",
                "message": "No sources relevant to the requested topic were found.",
                "key_findings": [],
                "policy_insights": [],
                "recommendations": [
                    "Refine the topic to be more specific",
                    "Upload relevant source documents",
                    "Verify the subject/entity and jurisdiction"
                ],
                "data_quality_flags": [
                    "Retrieval found no sources matching the requested topic after multiple "
                    "reformulation attempts; document generation was skipped."
                ],
            }
        
        sources_section = f"Research Sources Summary:\n        {sources_summary}" if sources_summary.strip() else "Note: No specific research sources were found in the knowledge base for this query. Exclude all external knowledge and inventions. Since no sources are available, strictly return empty lists for all required JSON keys."

        from core.prompt_registry_new import get_agent_prompt, get_jurisdiction_context
        category = requirements.get('category', '')
        jurisdiction = requirements.get('jurisdiction', '')
        system_prompt = get_agent_prompt(category, agent="researcher")
        jurisdiction_context = get_jurisdiction_context(jurisdiction)

        logger.info(f"PROMPT_ROUTING | category={category} | jurisdiction={jurisdiction} | agent=researcher | docs={len(retrieved_docs)} | max_score={max_similarity_score}")
        
        req_copy = requirements.copy()

        # Include human reviewer feedback when this is a re-research run
        re_research_feedback = (req_copy.get('re_research_feedback') or '').strip()
        feedback_block = (
            f"\n        HUMAN REVIEWER FEEDBACK (must be addressed in your synthesis):\n"
            f"        {re_research_feedback}\n"
            if re_research_feedback else ''
        )

        user_prompt = f"""
        Jurisdiction context: {jurisdiction_context}
        {feedback_block}
"""
        # Inject jurisdiction file context (authoritative regulatory reference)
        jur_file_context = requirements.get('_jurisdiction_context', '')
        if jur_file_context:
            user_prompt += f"""
        JURISDICTION REGULATORY CONTEXT (use as primary reference, do not contradict):
        {jur_file_context[:JURISDICTION_CTX_MAX]}
"""

        user_prompt += f"""
        DOCUMENT PURPOSE — this is the primary lens for your synthesis:
        - Topic: {req_copy.get('topic', 'N/A')}
        - User Query / Purpose: {req_copy.get('user_query', '') or req_copy.get('background', 'N/A')}
        - Document type: {req_copy.get('document_type', 'submission')}
        - Target audience: {req_copy.get('target_audience', 'officials')}
        - Jurisdiction: {req_copy.get('jurisdiction', 'N/A')}

        Synthesize the research below so that it directly serves the User Query / Purpose for
        this audience. Prioritise information that helps achieve that purpose; do not produce a
        generic jurisdiction overview.

        <documents>
        {sources_section}
        </documents>

        Output a valid JSON object with exactly three keys, each a list of strings. The three
        lists must play DISTINCT roles and must NOT overlap — the same fact must appear in only
        one list, phrased once:
        - 'key_findings': concrete factual evidence (data, study results, product/scientific facts,
          specific events). These support the evidence/body sections of the document.
        - 'policy_insights': the regulatory/policy landscape and contextual analysis (current
          status, authorities, frameworks, positions). These support background/context sections.
        - 'recommendations': specific, actionable recommendations or principles. These support the
          recommendations section.

        Quality rules:
        - Make each item self-contained and distinct. Do NOT restate the same point across items
          or across the three lists.
        - Aim for enough distinct items to cover the document (roughly 6-10 key_findings,
          3-6 policy_insights, 3-6 recommendations) where the sources support it.
        - Anchor every item to the Topic/Purpose above; omit material irrelevant to the purpose.

        CRITICAL CITATION RULE:
        - Each finding MUST end with a source attribution in the format [Source: N] where N is the source number from the documents above.
        - Example: "India enacted COTPA 2003 as the key tobacco control legislation. [Source: 2]"
        - If a finding draws from multiple sources, cite all: [Source: 1, 3]
        - NEVER invent a source number. Only use numbers that appear in the documents above.
        
        CRITICAL JSON RULES:
        1. All double quotes inside your string values MUST be escaped (e.g., \"quote\").
        2. Do not include any conversational text before or after the JSON.
        3. Do not use unescaped newlines inside strings.

        Focus on: {req_copy.get('jurisdiction', 'India')} jurisdiction and ensure compliance with local regulations.
        """
        
        # Dump prompt to file for debugging (Disabled for AWS Lambda read-only filesystem)
        # with open('prompt_dump.txt', 'w', encoding='utf-8') as f:
        #     f.write(prompt)
            
        # Bypass SSL verification like verify=False
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": LLM_MODEL_REASONING,
            "system": system_prompt.strip(),
            "messages": [
                {"role": "user", "content": user_prompt.strip()}
            ],
            "temperature": 0.2,
            "max_tokens": 4096
        }
        
        req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')

        import re
        import time as _time
        _rid = requirements.get('request_id', 'unknown') if isinstance(requirements, dict) else 'unknown'
        _preflight_prompt_budget(system_prompt, user_prompt, "research_synthesis", _rid)
        # Retry transient gateway failures (502/503/504/429, connection errors) with backoff
        # before giving up — the synthesis call is fatal to the stage, so self-heal blips.
        ai_response = None
        for _attempt in range(3):
            try:
                with urllib.request.urlopen(req, context=ctx, timeout=180) as response:
                    res = json.loads(response.read().decode('utf-8'))
                    try:
                        from core.langsmith_tracing.llm_usage import record_llm_usage
                        record_llm_usage(res, name='monolith_synthesis_research_findings', response=response)
                    except Exception:
                        pass
                    _check_response_truncation(res, "research_synthesis", _rid)
                    ai_response = res['choices'][0]['message']['content'].strip()
                break
            except urllib.error.HTTPError as _he:
                if _he.code in (429, 500, 502, 503, 504) and _attempt < 2:
                    _wait = 2 ** _attempt
                    logger.warning(f"SYNTHESIS_LLM | transient HTTP {_he.code}; retry {_attempt + 1}/3 after {_wait}s")
                    _time.sleep(_wait)
                    continue
                raise
            except urllib.error.URLError as _ue:
                if _attempt < 2:
                    _wait = 2 ** _attempt
                    logger.warning(f"SYNTHESIS_LLM | transient URLError ({_ue}); retry {_attempt + 1}/3 after {_wait}s")
                    _time.sleep(_wait)
                    continue
                raise

        # Robust JSON extraction
        match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', ai_response)
        if match:
            ai_response = match.group(1).strip()
        else:
            # Fallback to finding the outermost curly braces
            start_idx = ai_response.find('{')
            end_idx = ai_response.rfind('}')
            if start_idx != -1 and end_idx != -1:
                ai_response = ai_response[start_idx:end_idx+1]
                    
        try:
            synthesis_result = json.loads(ai_response)
        except json.JSONDecodeError as e:
            logger.warning(f"Synthesis JSON parse failed ({e}); attempting light repair.")
            # Light repair: strip trailing commas before } or ]
            repaired = re.sub(r',\s*([}\]])', r'\1', ai_response)
            try:
                synthesis_result = json.loads(repaired)
                logger.info("Synthesis JSON recovered after repair.")
            except json.JSONDecodeError:
                logger.error(f"Failed to parse LLM JSON after repair. Raw Output: {ai_response[:1000]}")
                # Neutral fallback — never inject error strings into the document.
                synthesis_result = {
                    "key_findings": [],
                    "policy_insights": [],
                    "recommendations": [],
                }
        # Guarantee the expected shape with list values
        for _k in ('key_findings', 'policy_insights', 'recommendations'):
            if not isinstance(synthesis_result.get(_k), list):
                synthesis_result[_k] = []
        # Flag internally inconsistent numeric claims (e.g. wrong magnitude/units) for review
        synthesis_result = _flag_numeric_inconsistencies(synthesis_result)
        return synthesis_result
        
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        logger.error(f"HTTP Error {e.code}: {error_body}")
        
        # Inject the full sources section into the error to see what triggered the guardrail
        preview = sources_section[:8000]
        raise Exception(f"HTTP {e.code}: {error_body} | Context Preview: {preview}")
    except Exception as e:
        logger.error(f"Error in research synthesis: {str(e)}")
        raise e


def create_sources_summary(research_results: Dict[str, Any]) -> str:
    """
    Build a ranked source summary for the synthesis LLM prompt.

    Changes from original:
    - Sources sorted by relevance_score descending so synthesiser sees the
      most relevant content first (was positional — arrival order).
    - Sources with score below 0.30 are excluded — very low relevance sources
      dilute synthesis quality without adding signal.
    - Uploaded file (null score) is always included regardless of threshold
      since the user explicitly provided it.
    - Top 15 selected after ranking and filtering.
    - Score displayed as percentage (score × 100) for LLM readability.
    """
    sources = research_results.get('all_sources', [])

    # Sort: uploaded_file first, then by rerank_score (primary) → relevance_score (fallback)
    def _sort_key(s: Dict) -> float:
        if s.get('type') == 'uploaded_file':
            return 2.0   # uploaded_file always first
        rerank = s.get('rerank_score')
        if rerank is not None:
            return float(rerank)
        score = s.get('relevance_score')
        if score is None:
            return 2.0
        return float(score)

    ranked = sorted(sources, key=_sort_key, reverse=True)

    # Keep uploaded_file (always relevant) + any source that passed rerank, or scored >= 0.35
    filtered = [
        s for s in ranked
        if s.get('type') == 'uploaded_file'
        or s.get('rerank_score') is not None          # survived rerank floor upstream
        or (s.get('relevance_score') or 0) >= 0.35
    ]

    summary_parts = []
    SYNTH_SOURCE_CAP = 15  # number of ranked sources fed to the synthesis LLM
    for idx, source in enumerate(filtered[:SYNTH_SOURCE_CAP], 1):
        score      = source.get('relevance_score')
        score_disp = f"{round(score * 100)}%" if score is not None else "user-provided"
        url        = source.get('url', source.get('source', ''))
        summary_parts.append(
            f"[{idx}] {source.get('title', 'Unknown Title')} "
            f"({source.get('source', 'Unknown Source')}) "
            f"[Relevance: {score_disp}] [URL: {url}] - {source.get('summary', 'No summary available')}"
        )

    logger.info(
        f"SOURCES_SUMMARY | total={len(sources)} | after_filter={len(filtered)} "
        f"| sent_to_llm={min(len(filtered), SYNTH_SOURCE_CAP)}"
    )
    return '\n'.join(summary_parts)


def store_research_results(request_id: str, research_results: Dict[str, Any], synthesis: Dict[str, Any]) -> str:
    """Store comprehensive research results in S3"""
    
    try:
        import os
        bucket_name = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')
        s3_key = f"research/{request_id}/research_results.json"
        
        research_package = {
            'request_id': request_id,
            'timestamp': datetime.now().isoformat(),
            'research_results': research_results,
            'synthesis': synthesis,
            'metadata': {
                'total_sources': len(research_results.get('all_sources', [])),
                'research_duration': '62 minutes',
                'confidence_score': 92
            }
        }
        
        # Upload to S3
        s3.put_object(
            Bucket=bucket_name,
            Key=s3_key,
            Body=json.dumps(research_package, indent=2)
        )
        
        return s3_key
        
    except Exception as e:
        logger.error(f"Error storing research results: {str(e)}")
        return f"research/{request_id}/research_results.json"


def search_web_tavily(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Search the web using Tavily API, routing via private LiteLLM gateway if inside VPC.

    Also fires a parallel Gemini google_search for the same query and logs
    side-by-side results so callers can compare coverage.
    Tavily results are used as the live source returned to downstream agents.
    """
    topic        = (requirements.get('topic')        or '').strip()
    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    background   = (requirements.get('background')   or '').strip()

    # Use up to 500 chars of background for web search context
    background_hint = background[:500] if background else ''
    query = ' '.join(filter(None, [topic, jurisdiction, background_hint]))[:300].strip()

    # Use narrow query from conductor if provided (max 15 words, from planner_queries[0])
    narrow_override = (requirements.get('_web_narrow_query') or '').strip()
    if narrow_override:
        query = narrow_override

    # Anchor to the framing entity so a generic topic (e.g. "Sustainability Initiative")
    # does not resolve to an unrelated organisation. Only prepended when the framing
    # decided this is a first-party PMI subject (entity_anchor is otherwise empty).
    framing = requirements.get('_research_framing', {}) or {}
    entity_anchor = framing.get('entity_anchor', '')
    if entity_anchor and entity_anchor.split()[0].lower() not in query.lower():
        query = f"{entity_anchor} {query}".strip()[:300]
        logger.info(f"TAVILY_SEARCH | using narrow query override: '{query}'")

    if not query:
        return {'sources': [], 'citations': [], 'queries': []}

    web_sources: List[Dict] = []
    citations: List[Dict] = []

    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)

    # ── Fire Gemini google_search in parallel (comparison-only; gated off by default) ──
    gemini_search_executor = None
    gemini_search_future = None
    if ENABLE_GEMINI_COMPARISON:
        gemini_search_executor = ThreadPoolExecutor(max_workers=1)
        gemini_search_future = gemini_search_executor.submit(_gemini_search_web, query)

    # ── Jurisdiction official domains — used ONLY as a soft ranking boost ─────
    # (NOT a hard search filter). These nudge authoritative local sources to the
    # top when Tavily naturally surfaces them; they never exclude other results.
    _JURISDICTION_DOMAINS: Dict[str, List[str]] = {
        'india': [
            'cbic.gov.in',
            'commerce.gov.in',
            'financialservices.gov.in',
            'tobaccoboard.in',
            'mohfw.gov.in',
        ],
        'in': [
            'cbic.gov.in',
            'commerce.gov.in',
            'financialservices.gov.in',
            'tobaccoboard.in',
            'mohfw.gov.in',
        ],
        'bangladesh': ['nbr.gov.bd', 'mohfw.gov.bd', 'commerce.gov.bd'],
        'bd':         ['nbr.gov.bd', 'mohfw.gov.bd', 'commerce.gov.bd'],
        'thailand':   ['rd.go.th', 'fda.moph.go.th', 'moc.go.th'],
        'th':         ['rd.go.th', 'fda.moph.go.th', 'moc.go.th'],
    }
    include_domains = _JURISDICTION_DOMAINS.get(jurisdiction.lower(), [])
    logger.info(
        f"TAVILY_SEARCH | jurisdiction='{jurisdiction}' "
        f"| soft_boost_domains={include_domains or 'none'} (no hard filter)"
    )

    try:
        if use_private_gateway:
            # Gateway search-tool name is team-scoped: this key is only authorized for
            # 'ccaiaa-dev-tavily' (the generic 'tavily' tool returns 403 key_model_access_denied).
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            base_payload: Dict[str, Any] = {
                "query": query,
                "max_results": 6,
                "search_depth": "advanced",
            }
        else:
            if not TAVILY_API_KEY:
                logger.warning("TAVILY_API_KEY not configured; skipping web search.")
                return {'sources': [], 'citations': [], 'queries': []}

            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            base_payload = {
                "api_key": TAVILY_API_KEY,
                "query": query,
                "search_depth": "advanced",
                "include_answer": False,
                "include_raw_content": True,
                "max_results": 6,
            }

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        def _tavily_fetch(domains: List[str]) -> List[Dict]:
            """Single Tavily call. When `domains` is non-empty it is a hard include-filter
            (Tavily returns ONLY results from those domains); when empty the search is broad
            and Tavily's own relevance engine selects the best sites for the topic."""
            payload = dict(base_payload)
            if domains:
                payload["include_domains"] = domains
            req = urllib.request.Request(
                search_url,
                data=json.dumps(payload).encode('utf-8'),
                headers=headers,
                method='POST',
            )
            with urllib.request.urlopen(req, context=ctx, timeout=45) as resp:
                data = json.loads(resp.read().decode('utf-8'))
            return data.get('results', []) or []

        # ── Broad, topic-driven search (document-agnostic) ────────────────────
        # No hard domain filter: Tavily's relevance engine intelligently selects
        # the best sites for the topic (global evidence, regulatory precedents,
        # scientific sources, AND official jurisdiction sites when relevant).
        # The jurisdiction allow-list is used ONLY as a soft ranking boost below
        # (a nudge, never an exclusion) so authoritative local sources rank first
        # when Tavily naturally surfaces them.
        results_list = _tavily_fetch([])[:6]
        logger.info(
            f"TAVILY_SEARCH | broad_unrestricted | results={len(results_list)} "
            f"| soft_boost_domains={include_domains or 'none'}"
        )

        urls = [r.get('url') for r in results_list if r.get('url')]
        
        # HYBRID APPROACH: Tavily finds URLs, Gemini extracts content
        gemini_extracted = _gemini_extract_urls(urls)
        logger.info(f"WEB_SEARCH | Tavily found {len(urls)} URLs, Gemini extracted {len(gemini_extracted)}")

        for result in results_list:
            title   = result.get('title', 'Web Result')
            url     = result.get('url', '')
            score   = float(result.get('score', 0.5))

            if 'metadata.json' in url.lower() or 'metadata.json' in title.lower():
                continue

            # Use Gemini-extracted content, fallback to Tavily snippet if Gemini failed
            raw_content = gemini_extracted.get(url, '').strip()
            extraction_engine = 'gemini'
            if not raw_content:
                raw_content = result.get('content') or result.get('snippet') or ''
                extraction_engine = 'tavily'
                logger.warning(f"WEB_SEARCH | Gemini extraction failed for '{url[:60]}', using Tavily snippet")

            summarized_content = summarize_web_content_with_llm(raw_content, requirements, url)

            web_sources.append({
                'title':           title,
                'source':          'Tavily Web Search',
                'type':            'web_search',
                'date':            datetime.now().strftime('%Y-%m-%d'),
                'relevance_score': round(min(score, 1.0), 3),
                'summary':         summarized_content,
                'url':             url,
                'extraction_engine': extraction_engine,
            })
            citations.append({'title': title, 'url': url, 'source_type': 'web_search'})
            logger.info(f"WEB_SEARCH_RESULT | title='{title}' | url='{url[:80]}' | score={score} | raw_chars={len(raw_content)} | QFS_chars={len(summarized_content)}")

        logger.info(f"WEB_SEARCH | query='{query[:80]}' | results={len(web_sources)}")

    except Exception as e:
        logger.warning(f"Tavily web search failed (non-fatal): {e}")

    # ── Collect and log Gemini google_search comparison (only when enabled) ───
    if ENABLE_GEMINI_COMPARISON and gemini_search_future is not None:
        try:
            g = gemini_search_future.result(timeout=65)
            tavily_urls = [s['url'] for s in web_sources]
            gemini_urls = [s['url'] for s in g.get('sources', [])]
            overlap = set(tavily_urls) & set(gemini_urls)
            logger.info(
                f"WEB_SEARCH_COMPARE | query='{query[:80]}' "
                f"| tavily_results={len(web_sources)} "
                f"| gemini_results={len(gemini_urls)} "
                f"| gemini_chars={g['output_len']} "
                f"| gemini_grounding_used={g['grounding_used']} "
                f"| url_overlap={len(overlap)} "
                f"| gemini_error={g['error'] or 'none'}"
            )
            if gemini_urls:
                logger.info(f"WEB_SEARCH_COMPARE | gemini_urls={gemini_urls}")
            # Write full content to accumulator for S3 comparison file
            _request_id = _gemini_comparison_store.get('_active_request_id', '')
            if _request_id:
                _gemini_log_search(_request_id, query, g)
        except Exception as e:
            logger.warning(f"WEB_SEARCH_COMPARE | gemini collection error: {e}")
        finally:
            if gemini_search_executor is not None:
                gemini_search_executor.shutdown(wait=False)

    return {'sources': web_sources, 'citations': citations, 'queries': [query]}


def _store_research_to_s3(request_id: Any, research_results: Dict[str, Any], synthesis_result: Dict[str, Any]) -> str:
    """Write research data (all_sources + synthesis) to S3 and return the object key.

    Also writes a separate gemini_comparison.json alongside the main file so
    you can open it in S3 and read the full Gemini content side-by-side with
    Tavily to decide which engine produces better results.
    """
    if not request_id:
        logger.warning("No request_id; skipping S3 research data write.")
        return ''
    try:
        payload = {
            'all_sources':         research_results.get('all_sources', []),
            'formatted_citations': research_results.get('formatted_citations', []),
            'synthesis':           synthesis_result,
            'structured_facts':    research_results.get('structured_facts', {}),
            'jurisdiction_context': research_results.get('_jurisdiction_context_for_drafter', ''),
            'research_framing':    research_results.get('_research_framing', {}),
        }
        key = f"research/{request_id}/research_data.json"
        s3.put_object(
            Bucket=DOCUMENT_BUCKET,
            Key=key,
            Body=json.dumps(payload, indent=2),
            ContentType='application/json',
        )
        logger.info(f"[{request_id}] Research data stored at s3://{DOCUMENT_BUCKET}/{key}")

        # The Gemini comparison file is an evaluation-only artifact (not used by the
        # drafter). Skip it entirely unless the comparison harness is enabled.
        if not ENABLE_GEMINI_COMPARISON:
            with _gemini_comparison_lock:
                _gemini_comparison_store.pop(str(request_id), None)
            return key

        # ── Write Gemini comparison file ──────────────────────────────────────
        # Collect all Tavily sources for side-by-side comparison
        tavily_web_sources = [
            {
                'url':     s.get('url', ''),
                'title':   s.get('title', ''),
                'summary': s.get('summary', ''),
                'score':   s.get('relevance_score'),
                'source':  s.get('source', ''),
            }
            for s in research_results.get('all_sources', [])
            if s.get('type') == 'web_search'
        ]
        tavily_url_sources = [
            {
                'url':     s.get('url', ''),
                'title':   s.get('title', ''),
                'summary': s.get('summary', ''),
                'score':   s.get('relevance_score'),
                'type':    s.get('type', ''),
            }
            for s in research_results.get('all_sources', [])
            if s.get('type') in ('external_url', 'internal_url')
        ]

        with _gemini_comparison_lock:
            gemini_data = _gemini_comparison_store.get(str(request_id), {})

        comparison_payload = {
            'request_id':   str(request_id),
            'generated_at': datetime.now().isoformat(),
            'model':        GEMINI_MODEL,
            'note': (
                'This file contains Gemini results run in parallel with Tavily for comparison. '
                'Tavily content is what the drafter used. '
                'Compare summaries and content here to decide which engine to use.'
            ),
            'url_extraction_comparison': [
                {
                    'url':                    g_entry.get('url', ''),
                    'gemini_retrieval_status': g_entry.get('retrieval_status', ''),
                    'gemini_accessible':       g_entry.get('accessible', 'unknown'),
                    'gemini_output_len':       g_entry.get('output_len', 0),
                    'gemini_content':          g_entry.get('content', ''),
                    'gemini_error':            g_entry.get('error', ''),
                    'tavily_output_len': len(next(
                        (t['summary'] for t in tavily_url_sources if t['url'] == g_entry.get('url', '')),
                        ''
                    )),
                    'tavily_summary': next(
                        (t['summary'] for t in tavily_url_sources if t['url'] == g_entry.get('url', '')),
                        '(not in tavily url sources)'
                    ),
                }
                for g_entry in gemini_data.get('url_extractions', [])
            ],
            'web_search_comparison': [
                {
                    'query':                  g_entry.get('query', ''),
                    'gemini_content':         g_entry.get('content', ''),
                    'gemini_sources':         g_entry.get('sources', []),
                    'gemini_output_len':      g_entry.get('output_len', 0),
                    'gemini_grounding_used':  g_entry.get('grounding_used', False),
                    'gemini_error':           g_entry.get('error', ''),
                    'tavily_sources': tavily_web_sources,
                }
                for g_entry in gemini_data.get('web_searches', [])
            ],
        }

        comparison_key = f"research/{request_id}/gemini_comparison.json"
        s3.put_object(
            Bucket=DOCUMENT_BUCKET,
            Key=comparison_key,
            Body=json.dumps(comparison_payload, indent=2),
            ContentType='application/json',
        )
        logger.info(f"[{request_id}] Gemini comparison stored at s3://{DOCUMENT_BUCKET}/{comparison_key}")

        # Clean up accumulator entry to free memory
        with _gemini_comparison_lock:
            _gemini_comparison_store.pop(str(request_id), None)

        return key
    except Exception as e:
        logger.error(f"Failed to store research data to S3: {e}")
        return ''


def _build_selection_reason(raw_type: str, relevance_score: 'float | None', source_origin: str) -> str:
    """
    Build a deterministic human-readable reason explaining why the agent picked this source.
    relevance_score is on a 0–1 scale (None for uploaded_file).
    """
    score = relevance_score or 0.0
    score_label = (
        'high'     if score >= 0.75 else
        'moderate' if score >= 0.50 else
        'low'
    )
    score_pct = f"{round(score * 100)}%"

    if raw_type == 'internal_knowledge':
        return (
            f"Retrieved from {source_origin or 'PMI Knowledge Base'} with {score_pct} semantic "
            f"relevance to the research query. Selected as a primary internal reference."
        )
    elif raw_type == 'uploaded_file':
        return (
            f"Extracted from a user-uploaded input document. Included because it was explicitly "
            f"provided as a reference for this request."
        )
    elif raw_type == 'internal_url':
        return (
            f"Retrieved from a curated internal portal. "
            f"Selected for internal policy context with {score_label} relevance ({score_pct})."
        )
    elif raw_type == 'web_search':
        return (
            f"Surfaced via external web search on the research topic. "
            f"Selected for {score_label} topical relevance ({score_pct})."
        )
    elif raw_type == 'external_url':
        return (
            f"Retrieved from an external link provided with the request. "
            f"Relevance to topic: {score_label} ({score_pct})."
        )
    else:
        return (
            f"Source selected based on {score_label} relevance ({score_pct}) "
            f"to the research topic."
        )


def build_structured_sources(research_results: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Build structured source list for HITL review from raw research results.
    Summaries and reasons are derived deterministically — no LLM calls.
    Each entry includes source_id so it can be referenced in future human feedback.
    Deduplicates by URL — keeps the highest-scoring chunk per URL.
    """
    all_sources = research_results.get('all_sources', [])
    citations = research_results.get('formatted_citations', [])

    url_by_title: Dict[str, str] = {c.get('title', ''): c.get('url', '') for c in citations}

    # Deduplicate by URL: keep highest-scoring entry per URL
    _seen_urls: Dict[str, Dict] = {}
    for source in all_sources:
        url_key = (source.get('url') or source.get('source') or '').strip().lower()
        if not url_key or source.get('type') == 'uploaded_file':
            # uploaded_file has no URL — always include
            _seen_urls[f"_uploaded_{id(source)}"] = source
            continue
        existing = _seen_urls.get(url_key)
        if existing is None:
            _seen_urls[url_key] = source
        else:
            # Keep the one with higher relevance_score
            existing_score = existing.get('relevance_score') or 0
            new_score = source.get('relevance_score') or 0
            if new_score > existing_score:
                _seen_urls[url_key] = source
    
    deduped_sources = list(_seen_urls.values())

    _TYPE_MAP = {
        'internal_knowledge': 'knowledge_base',
        'uploaded_file':      'uploaded_file',
        'internal_url':       'internal_url',
        'web_search':         'web_search',
        'external_url':       'external_url',
    }

    structured = []
    src_idx = 1
    for source in deduped_sources:
        title = source.get('title', f'Source {src_idx}')
        raw_summary = source.get('summary', '')
        raw_type = source.get('type', '')
        raw_score = source.get('relevance_score')
        relevance_score = round(float(raw_score), 3) if raw_score is not None else None
        source_origin = source.get('source', '')

        # Exclude metadata.json files from structured sources list
        if 'metadata.json' in str(title).lower() or 'metadata.json' in str(source_origin).lower():
            continue

        # Deterministic 2-3 sentence summary: trim at last sentence boundary within 450 chars
        short_summary = raw_summary[:450]
        last_period = short_summary.rfind('. ')
        if last_period > 80:
            short_summary = short_summary[:last_period + 1]
        short_summary = short_summary.strip() or 'No summary available.'

        source_type = _TYPE_MAP.get(raw_type, 'external')
        url = url_by_title.get(title, '') or source.get('url', '')

        structured.append({
            'source_id': f'src_{src_idx:03d}',
            'title': title,
            'source_type': source_type,
            'relevance_score': relevance_score,
            'url': url,
            'summary': short_summary,
            'reason': _build_selection_reason(raw_type, relevance_score, source_origin),
            'extraction_engine': source.get('extraction_engine', ''),
        })
        src_idx += 1

    return structured


def update_request_status(request_id: str, status: str, notes: str, research_output: Dict = None, uploaded_file_summary: str = None) -> None:
    """Update request status in DynamoDB"""
    
    def _convert_floats_to_decimals(obj):
        from decimal import Decimal
        if isinstance(obj, float):
            return Decimal(str(obj))
        elif isinstance(obj, dict):
            return {k: _convert_floats_to_decimals(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [_convert_floats_to_decimals(x) for x in obj]
        return obj

    try:
        from datetime import datetime
        timestamp = datetime.utcnow().isoformat() + 'Z'
        
        update_expr = 'SET #status = :status, #notes = :notes, #updated_at = :timestamp'
        expr_names = {
            '#status': 'status',
            '#notes': 'processing_notes',
            '#updated_at': 'updated_at'
        }
        expr_values = {
            ':status': status,
            ':notes': notes,
            ':timestamp': datetime.now().isoformat()
        }
        
        if research_output is not None:
            research_output = _convert_floats_to_decimals(research_output)
            update_expr += ', #research_output = :research_output'
            expr_names['#research_output'] = 'research_output'
            expr_values[':research_output'] = research_output
            
        if uploaded_file_summary:
            update_expr += ', #uploaded_file_summary = :uploaded_file_summary'
            expr_names['#uploaded_file_summary'] = 'uploaded_file_summary'
            expr_values[':uploaded_file_summary'] = uploaded_file_summary
            
        requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values
        )
    except Exception as e:
        logger.error(f"Error updating request status: {str(e)}")
