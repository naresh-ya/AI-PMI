"""Split-research stage lambda: RE-RESEARCH (HITL revise path).

Invoked by Step Functions when the HITL decision is 'revise'. Receives the
HITL callback output (feedback, approved_sources, removed_source_ids) plus
the original requirements, runs intelligent selective re-research, and returns
a research_summary in the same shape as the initial synthesis output.

Event payload (from ResearchGateChoice → ReResearch):
    {
        "request_id": str,
        "requirements": {...},          # from planner_output.requirements
        "hitl_result": {
            "decision": "revise",
            "approved_sources": [...],
            "removed_source_ids": [...],
            "feedback": "...",
            "hitl_id": "...",
        },
        "hitl_retry_count": int,
        "langsmith_headers": {...}      # from prior synthesis_output iteration
    }
Returns:
    {"research_summary": {...}, "langsmith_headers": {...}}
    ^ langsmith_headers MUST be in output since ResultPath=$.synthesis_output
      and next iteration of HITLResearchGate reads it from there.

LangSmith tracing: middle-of-pipeline stage (part of the research revise loop) —
receives + re-attaches propagated trace context. See handler_planner.py for the
canonical pattern.
"""
import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (MUST import before langsmith)

try:
    import researcher_reresearch as reresearch
except ImportError:
    from agents.master_researcher import researcher_reresearch as reresearch

from core.researcher_common import logger

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers,
        attach_outgoing_langsmith_headers,
    )
    _LANGSMITH_TRACING_AVAILABLE = True
except Exception:
    _LANGSMITH_TRACING_AVAILABLE = False

    def traceable(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator if not args else _decorator(args[0])

    def get_incoming_langsmith_headers(event):
        return {}

    def attach_outgoing_langsmith_headers(result, run_tree):
        return result


@traceable(name="research_reresearch", run_type="chain")
def _traced_reresearch(reresearch_event, request_id, run_tree=None):
    result = reresearch.handle_reresearch(reresearch_event, request_id)
    result = attach_outgoing_langsmith_headers(result, run_tree)
    # Ensure langsmith_headers is always present, even if empty
    if 'langsmith_headers' not in result:
        result['langsmith_headers'] = {}
    return result


def lambda_handler(event, context):
    request_id = str(event.get('request_id') or 'unknown')
    hitl_result = event.get('hitl_result', {}) or {}
    requirements = event.get('requirements', {}) or {}
    hitl_retry_count = int(event.get('hitl_retry_count') or 0)

    logger.info(f"[{request_id}] STAGE re_research start (retry={hitl_retry_count})")

    reresearch_event = {
        'human_feedback': hitl_result.get('feedback', ''),
        'approved_sources': hitl_result.get('approved_sources', []),
        'removed_source_ids': hitl_result.get('removed_source_ids', []),
        'requirements': requirements,
        'hitl_retry_count': hitl_retry_count,
    }

    if not _LANGSMITH_TRACING_AVAILABLE:
        return _traced_reresearch(reresearch_event, request_id)

    from langsmith.run_helpers import tracing_context
    incoming_headers = get_incoming_langsmith_headers(event)
    with tracing_context(parent=incoming_headers):
        return _traced_reresearch(reresearch_event, request_id)
