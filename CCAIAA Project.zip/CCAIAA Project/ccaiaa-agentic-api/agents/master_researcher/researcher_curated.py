"""
Researcher Curated Links Module (fully standalone).

Provides: fetch_internal_weblinks(), stage_curated(), _llm_select_curated_links()

Performance notes:
  - Module-level SSL context avoids repeated TLS setup across threads.
  - QFS summarization on curated URLs runs in parallel via ThreadPoolExecutor.
  - All models, prompts, and fallback behaviour remain identical.
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, Any, List

import boto3

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    LITELLM_RERANK_URL, LITELLM_RERANK_MODEL, TAVILY_API_KEY,
    GEMINI_MODEL, _llm_call_json, get_dynamodb_resource,
)

# ── Module-level shared SSL context ──────────────────────────────────────────
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

dynamodb = get_dynamodb_resource()
curated_links_table = dynamodb.Table(os.environ.get('CURATED_LINKS_TABLE', 'pmi-agentic-ai-curated-links'))

# ======================================================================
# stage_curated (lines 638-640)
# ======================================================================

# ── Tavily helper (used by fetch_internal_weblinks) ──

def _tavily_rank_curated_urls(urls: List[str], query: str, max_results: int = 5) -> List[Dict]:
    """
    Use Tavily domain search to rank curated URLs by relevance.
    
    This function takes a list of curated URLs from DynamoDB and uses Tavily's
    search API to rank them by relevance to the query. This acts as an intelligent
    filter to reduce 20-50 curated links down to the top 3-5 most relevant ones.
    
    Returns: List of dicts with keys: url, title, relevance_score
    """
    from urllib.parse import urlparse
    
    # Extract domains from URLs
    domains = list(set(urlparse(u).netloc for u in urls if u))
    if not domains:
        return []
    
    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    use_private_gateway = bool(litellm_key)
    
    try:
        if use_private_gateway:
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        else:
            if not TAVILY_API_KEY:
                return []
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload = {
                "api_key": TAVILY_API_KEY,
                "query": query[:150],
                "include_domains": domains,
                "max_results": max_results,
                "search_depth": "advanced",
            }
        
        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        ranked = []
        for result in data.get('results', []):
            ranked.append({
                'url': result.get('url', ''),
                'title': result.get('title', ''),
                'relevance_score': float(result.get('score', 0.7))
            })
        
        logger.info(f"TAVILY_RANK_CURATED | query='{query[:60]}' | input_urls={len(urls)} | ranked={len(ranked)}")
        return ranked[:max_results]
        
    except Exception as e:
        logger.warning(f"Tavily curated URL ranking failed: {e}")
        return []



def stage_curated(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Curated internal weblinks stage."""
    return fetch_internal_weblinks(requirements)


# ======================================================================
# fetch_internal_weblinks (lines 3622-3885)
# ======================================================================
def fetch_internal_weblinks(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 4 — Fetch content from curated links stored in pmi-agentic-ai-curated-links.

    Schema observed: id(PK), country, description, domain, is_active, language,
                     link (URL), requires_login, source_type, title, topics (StringSet), updated_at

    Steps:
      1. Scan with is_active=True, requires_login=False, country=jurisdiction
      2. Score each row by keyword overlap with request context (topics + description)
      3. Fetch page content from 'link' for the top-scoring rows (up to 5)
    """
    from boto3.dynamodb.conditions import Attr

    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    topic        = (requirements.get('topic') or '').strip()
    category     = (requirements.get('category') or '').strip()
    use_case     = (requirements.get('use_case') or '').strip()
    background   = (requirements.get('background') or '').strip()

    # Build a flat keyword set from all request context fields for scoring
    _STOPWORDS = {'', 'a', 'an', 'the', 'of', 'in', 'on', 'for', 'to', 'and', 'or', 'with', 'is', 'are', 'at'}
    context_text = f"{topic} {category} {use_case} {background}".lower()
    context_words = {w for w in re.split(r'[\s,;.()\-]+', context_text) if w and w not in _STOPWORDS and len(w) > 2}

    all_items: List[Dict] = []
    try:
        import functools
        import operator
        
        # Build country conditions to handle case-insensitivity and common abbreviations (e.g. IN for India)
        country_queries = [jurisdiction, jurisdiction.lower(), jurisdiction.upper(), jurisdiction.title()]
        if jurisdiction.lower() in ('india', 'in'):
            country_queries.extend(['in', 'IN', 'india', 'India'])
        elif jurisdiction.lower() in ('bangladesh', 'bd'):
            country_queries.extend(['bd', 'BD', 'bangladesh', 'Bangladesh'])
        elif jurisdiction.lower() in ('thailand', 'th'):
            country_queries.extend(['th', 'TH', 'thailand', 'Thailand'])
            
        country_set = {c.strip() for c in country_queries if c and c.strip()}
        
        # Fetch rows for the request's jurisdiction AND rows marked "global"
        # (global = curated links that apply regardless of country)
        # is_active + requires_login are always hard gates
        # Note: DynamoDB stores these as strings "TRUE"/"FALSE", not booleans
        base = Attr('is_active').eq('TRUE') & Attr('requires_login').eq('FALSE')
        
        if jurisdiction and country_set:
            # Dynamically build OR conditions for country list
            country_conditions = [Attr('country').eq(c) for c in country_set]
            country_filter = functools.reduce(operator.or_, country_conditions)
            filter_expr = base & (Attr('country').eq('global') | country_filter)
        else:
            filter_expr = base & Attr('country').eq('global')

        resp = curated_links_table.scan(FilterExpression=filter_expr)
        all_items = resp.get('Items', [])

        # Handle DynamoDB 1 MB pagination
        while 'LastEvaluatedKey' in resp:
            resp = curated_links_table.scan(
                FilterExpression=filter_expr,
                ExclusiveStartKey=resp['LastEvaluatedKey']
            )
            all_items.extend(resp.get('Items', []))

        logger.info(f"CURATED_LINKS_DDB | jurisdiction={jurisdiction} | fetched={len(all_items)}")

    except Exception as e:
        logger.warning(f"Failed to query curated links from DynamoDB: {e}")

    if not all_items:
        return {'sources': [], 'citations': [], 'queries': []}

    # ── LLM-based selection ────────────────────────────────────────────────────
    # Pass all portal descriptions to the LLM; let it decide relevance based on
    # semantic understanding of the request topic (handles synonyms, abbreviations,
    # domain concepts that keyword overlap misses).
    def run_hybrid_fallback(all_items: List[Dict], jurisdiction: str, context_words: set, context_text: str, requirements: Dict[str, Any]) -> List[Dict]:
        """Fallback using hybrid (semantic + keyword/topic/country) search over curated links."""
        import math
        scored_items = []
        
        # 1. Generate Query embedding using Bedrock
        query_embedding = None
        try:
            bedrock_runtime = boto3.client('bedrock-runtime', region_name=os.environ.get('AWS_REGION', 'eu-west-1'))
            response = bedrock_runtime.invoke_model(
                modelId='amazon.titan-embed-text-v2:0',
                body=json.dumps({"inputText": context_text[:8000]})
            )
            response_body = json.loads(response['body'].read())
            query_embedding = response_body.get('embedding')
        except Exception as e:
            logger.warning(f"Failed to generate query embedding for fallback: {e}")

        for item in all_items:
            # --- Component A: Country Weight ---
            country_score = 0.0
            row_country = (item.get('country') or '').strip().lower()
            if jurisdiction and row_country == jurisdiction.lower():
                country_score = 1.0
            elif row_country == 'global':
                country_score = 0.8
            
            # --- Component B: Semantic Score ---
            semantic_score = 0.0
            desc = (item.get('description') or '').strip()
            if query_embedding and desc:
                try:
                    # Generate candidate embedding on the fly (small payload, low latency)
                    response = bedrock_runtime.invoke_model(
                        modelId='amazon.titan-embed-text-v2:0',
                        body=json.dumps({"inputText": desc[:8000]})
                    )
                    response_body = json.loads(response['body'].read())
                    desc_embedding = response_body.get('embedding')
                    
                    if desc_embedding:
                        dot_product = sum(a * b for a, b in zip(query_embedding, desc_embedding))
                        norm1 = math.sqrt(sum(a * a for a in query_embedding))
                        norm2 = math.sqrt(sum(b * b for b in desc_embedding))
                        if norm1 > 0 and norm2 > 0:
                            semantic_score = dot_product / (norm1 * norm2)
                except Exception as e:
                    logger.warning(f"Failed to generate embedding for curated description: {e}")

            # --- Component C: Keyword Overlap Score ---
            desc_words = set(re.split(r'[\s,;.()\-]+', desc.lower()))
            overlap_count = len(context_words & desc_words)
            keyword_score = min(overlap_count / 5.0, 1.0) # Normalized up to 5 word overlaps
            
            # --- Component D: Topic Overlap Score ---
            topic_words = set()
            for t in (item.get('topics') or []):
                topic_words.update(re.split(r'[\s,;.()\-]+', str(t).lower()))
            topic_overlap = len(context_words & topic_words)
            topic_score = min(topic_overlap / 3.0, 1.0) # Normalized up to 3 topic overlaps
            
            # --- Combine into a Hybrid Score ---
            # Formula: 40% Semantic + 30% Keywords + 20% Topics + 10% Country
            combined_score = (
                (semantic_score * 0.40) + 
                (keyword_score * 0.30) + 
                (topic_score * 0.20) + 
                (country_score * 0.10)
            )
            
            scored_items.append((item, combined_score))
            
        # Sort and select top items
        scored_items.sort(key=lambda x: x[1], reverse=True)
        # Select items with non-zero hybrid score
        selected = [item for item, score in scored_items if score > 0.15][:3]
        if not selected:
            selected = [item for item, _ in scored_items[:3]]
        return selected

    selected: List[Dict] = []
    try:
        selected_ids = _llm_select_curated_links(all_items, topic)
        if not selected_ids:
            logger.info("LLM selected no curated links. Falling back to hybrid scoring.")
            selected = run_hybrid_fallback(all_items, jurisdiction, context_words, context_text, requirements)
        else:
            selected = [
                item for sid in selected_ids
                for item in all_items
                if str(item.get('id', '')) == sid
            ]
            logger.info(f"CURATED_LINKS_LLM | matched={len(selected)} | ids={selected_ids}")
    except Exception as e:
        logger.warning(f"LLM curated link selection failed, using hybrid fallback: {e}")
        selected = run_hybrid_fallback(all_items, jurisdiction, context_words, context_text, requirements)
        logger.info(f"CURATED_LINKS_FALLBACK | selected={len(selected)} links via hybrid scoring")

    if not selected:
        return {'sources': [], 'citations': [], 'queries': []}

    logger.info(f"CURATED_LINKS_DDB | final_selected={len(selected)}")

    # Build (url, title, description) tuples from selected DynamoDB items
    url_meta = [
        ((item.get('link') or '').strip(), (item.get('title') or '').strip(), (item.get('description') or '').strip())
        for item in selected
        if (item.get('link') or '').strip().startswith('http') and 'metadata.json' not in (item.get('link') or '').strip().lower()
    ]

    if not url_meta:
        return {'sources': [], 'citations': [], 'queries': []}

    # HYBRID APPROACH: Tavily ranks DynamoDB URLs, Gemini extracts top 3-5
    curated_urls = [u for u, _, _ in url_meta]
    logger.info(f"CURATED_LINKS | selected={len(curated_urls)} from DynamoDB, now ranking with Tavily")

    # Step 1: Tavily ranks the URLs
    ranked_urls = _tavily_rank_curated_urls(
        urls=curated_urls,
        query=topic,
        max_results=5
    )

    if not ranked_urls:
        # Fallback: use all URLs if Tavily ranking fails
        logger.warning("CURATED_LINKS | Tavily ranking failed, using all URLs with default scores")
        ranked_urls = [{'url': u, 'title': t, 'relevance_score': 0.7} for u, t, _ in url_meta[:5]]

    # Step 2: Gemini extracts from ranked URLs only
    extracted = _gemini_extract_urls([r['url'] for r in ranked_urls])
    logger.info(f"CURATED_LINKS | Gemini extracted {len(extracted)} of {len(ranked_urls)} ranked URLs")

    sources: List[Dict] = []
    citations: List[Dict] = []

    query = ' '.join(filter(None, [topic, jurisdiction]))

    # Build a lookup map for DDB metadata
    ddb_meta = {u: (t, d) for u, t, d in url_meta}

    # ── Parallel QFS summarisation for curated URLs ─────────────────────────────
    # Same model (Sonnet), same prompt, same fallback — just concurrent.
    items_to_summarize = []
    for ranked in ranked_urls:
        url = ranked['url']
        raw_content = extracted.get(url, '').strip()
        if not raw_content:
            logger.warning(f"INTERNAL_LINK | no Gemini content for '{url[:80]}'")
            continue
        items_to_summarize.append({
            'url': url,
            'tavily_title': ranked.get('title', ''),
            'tavily_score': ranked.get('relevance_score', 0.7),
            'raw_content': raw_content,
        })

    def _qfs_one_curated(item: Dict) -> Dict:
        """Thread-safe QFS for a single curated URL."""
        url = item['url']
        ddb_title, ddb_desc = ddb_meta.get(url, ('', ''))
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url
        tavily_title = item['tavily_title']

        if ddb_title and tavily_title and ddb_title.lower() != tavily_title.lower():
            title = f"{ddb_title} — {tavily_title}"
        else:
            title = ddb_title or tavily_title or domain

        summarized_content = summarize_web_content_with_llm(item['raw_content'], requirements, url)
        summary = (f"{ddb_desc} | " if ddb_desc else '') + summarized_content
        item['title'] = title
        item['summary'] = summary
        item['summarized_len'] = len(summarized_content)
        return item

    with ThreadPoolExecutor(max_workers=min(len(items_to_summarize) or 1, 5)) as qfs_ex:
        qfs_futures = {qfs_ex.submit(_qfs_one_curated, item): item['url'] for item in items_to_summarize}
        for fut in as_completed(qfs_futures):
            try:
                item = fut.result()
                if not item['summary'].strip():
                    continue
                sources.append({
                    'title':           item['title'],
                    'source':          item['url'],
                    'type':            'internal_url',
                    'date':            datetime.now().strftime('%Y-%m-%d'),
                    'relevance_score': item['tavily_score'],
                    'summary':         item['summary'],
                    'url':             item['url'],
                    'extraction_engine': 'gemini',
                })
                citations.append({'title': item['title'], 'url': item['url'], 'source_type': 'internal_url'})
                logger.info(f"INTERNAL_LINK | title='{item['title']}' | tavily_score={item['tavily_score']} | raw_chars={len(item['raw_content'])} | QFS_chars={item['summarized_len']} | url='{item['url'][:80]}'")
            except Exception as e:
                url_key = qfs_futures[fut]
                logger.warning(f"INTERNAL_LINK | QFS failed for '{url_key[:60]}' (non-fatal): {e}")

    return {'sources': sources, 'citations': citations, 'queries': []}


# ======================================================================
# _llm_select_curated_links (lines 3480-3544)
# ======================================================================
def _llm_select_curated_links(all_items: List[Dict], topic: str) -> List[str]:
    """
    Pass all curated portal descriptions to the LLM and ask it to pick
    the most relevant ones for the given request topic.

    Returns a list of selected item IDs (the DynamoDB 'id' field).
    Raises on any failure so the caller can fall back to keyword scoring.
    """
    if not LITELLM_KEY or not all_items:
        raise ValueError("LLM key not set or no items to evaluate")

    # Build a numbered portal list — only id + description used for matching
    portal_lines = []
    for i, item in enumerate(all_items, 1):
        row_id = item.get('id', f'row_{i}')
        desc   = (item.get('description') or '').strip()
        portal_lines.append(f"[{i}] ID: {row_id}\n    Description: {desc}")

    prompt = (
        "You are a research assistant selecting the most relevant government and regulatory "
        "portals for a document research task.\n\n"
        f"Request topic: {topic}\n\n"
        "Available portals (match based on description only):\n"
        + '\n'.join(portal_lines)
        + "\n\nSelect the portals whose description is most relevant to the request topic. "
        "A portal is relevant if its description indicates its content would help research "
        "or support the topic.\n"
        "Rules:\n"
        "- Return ONLY a valid JSON array of ID strings from the list above\n"
        "- Maximum 5 IDs, ordered by relevance (most relevant first)\n"
        "- If none are relevant, return an empty array []\n"
        "- No explanation, no markdown — only the JSON array\n\n"
        'Example: ["cbic.gov.in", "tobaccoboard.in"]'
    )

    req = urllib.request.Request(
        LITELLM_URL,
        data=json.dumps({
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
        }).encode('utf-8'),
        headers={
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        },
        method='POST',
    )
    with urllib.request.urlopen(req, context=_SSL_CTX, timeout=20) as resp:
        res = json.loads(resp.read().decode('utf-8'))
        try:
            from core.langsmith_tracing.llm_usage import record_llm_usage
            record_llm_usage(res, name='curated_llm_selection', response=resp)
        except Exception:
            pass
        raw = res['choices'][0]['message']['content'].strip()

    if raw.startswith('```'):
        raw = '\n'.join(raw.split('\n')[1:-1]).strip()

    selected_ids = json.loads(raw)
    if not isinstance(selected_ids, list):
        raise ValueError(f"LLM returned unexpected type: {raw}")

    logger.info(f"CURATED_LINKS_LLM | topic='{topic[:60]}' | selected_ids={selected_ids}")
    return [str(i) for i in selected_ids]




# ── Additional helpers (auto-extracted) ──────────────────────────

def _gemini_extract_urls(urls: List[str]) -> Dict[str, str]:
    """
    Extract content from URLs using Gemini url_context tool.
    
    This is the central Gemini extraction function used by:
    - External links (user-provided URLs)
    - Internal links (after Tavily ranking)
    - Web search (after Tavily URL discovery)
    
    Returns {url: content} dict.
    Runs extractions in parallel (max 5 workers).
    """
    if not urls or not LITELLM_KEY:
        return {}
    
    result: Dict[str, str] = {}
    
    def _extract_one(url: str) -> tuple:
        try:
            g = _gemini_url_context(url)
            if g.get('accessible') == 'yes' and g.get('content'):
                return url, g['content']
            else:
                logger.warning(
                    f"GEMINI_EXTRACT | url='{url[:60]}' | status={g['retrieval_status']} | error={g.get('error','')}"
                )
                return url, ''
        except Exception as e:
            logger.warning(f"GEMINI_EXTRACT | url='{url[:60]}' failed: {e}")
            return url, ''
    
    with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as executor:
        futures = {executor.submit(_extract_one, u): u for u in urls}
        for future in as_completed(futures):
            url, content = future.result()
            if content:
                result[url] = content
    
    logger.info(f"GEMINI_EXTRACT | requested={len(urls)} | succeeded={len(result)}")
    return result


def summarize_web_content_with_llm(text: str, requirements: Dict[str, Any], source_url: str) -> str:
    """Uses Bedrock (via LiteLLM) to perform Query-Focused Summarization (QFS) on raw web content."""
    if not LITELLM_KEY or not text.strip():
        return text[:1500] # Safe fallback
        
    topic = requirements.get('topic', 'General Regulatory Topic')
    background = requirements.get('background', '')
    jurisdiction = requirements.get('jurisdiction', 'Global')
    target_audience = requirements.get('target_audience', 'General')
    target_lang = requirements.get('target_language', 'English')
    category = requirements.get('category', '')
    use_case = requirements.get('use_case', '')
    
    # Detect if this is a Letters scenario
    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()
    is_letter = 'letter' in cat_lower or 'letter' in uc_lower
    
    extra_context = ""
    if is_letter:
        subject = requirements.get('topic_of_letter') or requirements.get('topicOfLetter') or ''
        if subject:
            extra_context = f"\n- Subject of the Letter: {subject}"
            
    prompt = (
        "You are an expert corporate regulatory research assistant.\n"
        "Your task is to analyze raw text scraped from a webpage and produce a dense, highly focused summary "
        "tailored specifically to the following research query.\n\n"
        "RESEARCH REQUEST CONTEXT:\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Topic: {topic}\n"
        f"- Target Audience: {target_audience}\n"
        f"- Background Context: {background or 'N/A'}{extra_context}\n\n"
        f"SOURCE WEBPAGE URL: {source_url}\n\n"
        "RAW WEBPAGE CONTENT:\n"
        f"<webpage_content>\n{text}\n</webpage_content>\n\n"
        "INSTRUCTIONS:\n"
        "1. Identify and extract only key findings, statistics, official dates, and compliance mandates "
        "relevant to this specific research request.\n"
        "2. Strip out all noise (cookies notices, ads, irrelevant portal headers/footers).\n"
        "3. Keep the summary factual, dense, and objective. Do not invent details.\n"
        f"4. Write the summary directly in {target_lang} (approx 400-600 words).\n"
        "5. Output only the summary directly (no conversational prefix/suffix).\n"
        "6. Prioritize exact statistics, dollar amounts, dates, legislation names, and named authorities over narrative."
    )
    
    try:
        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 2000,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=45) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(res, name='curated_qfs_summarize', response=resp)
            except Exception:
                pass
            summary = res['choices'][0]['message']['content'].strip()
            return summary
    except Exception as e:
        logger.warning(f"Web QFS failed for URL '{source_url}': {e}")
        return text[:1500]




def _gemini_url_context(url: str) -> Dict[str, Any]:
    """
    Fetch and summarize a URL using Gemini's native url_context grounding tool,
    routed through the private LiteLLM proxy.

    Returns a dict with keys:
        content            : str   — summary text from Gemini (empty on failure)
        retrieval_status   : str   — e.g. 'URL_RETRIEVAL_STATUS_SUCCESS'
        output_len         : int   — character count of content
        error              : str   — non-empty when the call failed
    """
    if not LITELLM_KEY:
        return {'content': '', 'retrieval_status': 'NO_CREDENTIALS', 'output_len': 0, 'error': 'no LITELLM_KEY'}

    prompt = (
        f"Use the url_context tool to fetch and read this URL:\n{url}\n\n"
        "Then return ALL of the following in your response:\n"
        "1. ACCESSIBLE: yes or no (was the full page content readable?)\n"
        "2. TITLE: the page title\n"
        "3. FULL_CONTENT: the complete extracted text from the page — do NOT summarise, "
        "return as much raw content as possible including tables, numbers, dates, legislation names.\n"
        "4. SUMMARY: a 5–8 sentence factual summary of the key points.\n\n"
        "Format your response exactly like this:\n"
        "ACCESSIBLE: yes\n"
        "TITLE: <page title>\n"
        "FULL_CONTENT:\n<full text here>\n"
        "SUMMARY:\n<summary here>\n\n"
        "If the page is behind a login, paywalled, or truly inaccessible, respond:\n"
        "ACCESSIBLE: no\n"
        "TITLE: unknown\n"
        "FULL_CONTENT: none\n"
        "SUMMARY: Page could not be accessed."
    )
    body = {
        "model": GEMINI_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 4096,
        "tools": [{"url_context": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    try:
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(data, name='curated_gemini_url_context', response=resp)
            except Exception:
                pass

        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        url_ctx_meta = data.get('vertex_ai_url_context_metadata', [])
        retrieval_status = 'UNKNOWN'
        try:
            retrieval_status = url_ctx_meta[0]['urlMetadata'][0]['urlRetrievalStatus']
        except (KeyError, IndexError, TypeError):
            if url_ctx_meta:
                retrieval_status = str(url_ctx_meta)

        # Parse structured fields from the response
        content_stripped = content.strip()
        accessible = 'yes' if 'ACCESSIBLE: yes' in content_stripped else (
                     'no'  if 'ACCESSIBLE: no'  in content_stripped else 'unknown')

        return {
            'content':          content_stripped,
            'retrieval_status': retrieval_status,
            'accessible':       accessible,
            'output_len':       len(content_stripped),
            'error':            '',
        }
    except Exception as e:
        return {'content': '', 'retrieval_status': 'ERROR', 'output_len': 0, 'error': str(e)}


