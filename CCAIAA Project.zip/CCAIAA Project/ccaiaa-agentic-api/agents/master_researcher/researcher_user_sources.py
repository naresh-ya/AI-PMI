"""
Researcher User Sources Module (fully standalone).

Provides: stage_user_sources(), fetch_user_external_links()

Performance notes:
  - Module-level SSL context avoids repeated TLS setup across threads.
  - Per-URL processing (Tavily scoring + QFS) runs in parallel via ThreadPoolExecutor.
  - All models, prompts, and fallback behaviour remain identical.
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, Any, List

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.researcher_common import (
    logger, LITELLM_KEY, LITELLM_URL, LITELLM_MODEL,
    GEMINI_MODEL, TAVILY_API_KEY, _llm_call_json,
)

# ── Module-level shared SSL context ──────────────────────────────────────────
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

# Import file processor for fallback file read
try:
    from researcher_file_processor import read_uploaded_file
except ImportError:
    from agents.master_researcher.researcher_file_processor import read_uploaded_file

# ======================================================================
# stage_user_sources (lines 599-635)
# ======================================================================
def stage_user_sources(requirements: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """User-provided sources stage: uploaded file + user external links combined.

    If the file was already processed by the FileProcessor stage (runs before the planner),
    the pre-processed source is reused here instead of re-reading and re-summarizing the file.
    External-URL fetch always runs regardless.
    """
    merged = {'sources': [], 'citations': [], 'queries': []}

    # Uploaded file: use pre-processed source if available, otherwise read as before
    pre_processed = requirements.get('_uploaded_file_source')
    if pre_processed:
        merged['sources'].append(pre_processed)
        merged['citations'].append({
            'title': pre_processed.get('title', ''),
            'url': '', 'source_type': 'uploaded_file',
        })
        logger.info(f"[{request_id}] user_sources: using pre-processed file source from FileProcessor")
    else:
        try:
            out = read_uploaded_file(requirements) or {}
            merged['sources'].extend(out.get('sources', []))
            merged['citations'].extend(out.get('citations', []))
            merged['queries'].extend(out.get('queries', []))
        except Exception as e:
            logger.error(f"[{request_id}] user_sources file read failed: {e}")

    # External URLs: always processed here (unchanged)
    try:
        out = fetch_user_external_links(requirements) or {}
        merged['sources'].extend(out.get('sources', []))
        merged['citations'].extend(out.get('citations', []))
        merged['queries'].extend(out.get('queries', []))
    except Exception as e:
        logger.error(f"[{request_id}] user_sources ext links failed: {e}")

    return merged


# ======================================================================
# fetch_user_external_links (lines 3412-3477)
# ======================================================================
def fetch_user_external_links(requirements: Dict[str, Any]) -> Dict[str, Any]:
    """Source 3 — Fetch content from user-provided external URLs via Gemini.

    HYBRID APPROACH: User explicitly chose these URLs, so we extract directly with Gemini
    (no Tavily involvement). Gemini handles CAPTCHAs and JS-heavy pages better.
    
    Uses Tavily /search with domain filter for scoring only (0–1 scale compatibility).
    """
    external_links = [u for u in (requirements.get('external_links') or []) if u and str(u).startswith('http') and 'metadata.json' not in str(u).lower()]
    if not external_links:
        return {'sources': [], 'citations': [], 'queries': []}

    topic        = (requirements.get('topic') or '').strip()
    jurisdiction = (requirements.get('jurisdiction') or '').strip()
    query        = ' '.join(filter(None, [topic, jurisdiction]))
    urls         = external_links[:5]

    # HYBRID CHANGE: Use Gemini extraction directly (no Tavily)
    extracted_contents = _gemini_extract_urls(urls)
    logger.info(f"EXTERNAL_LINKS | using Gemini extraction only (no Tavily) | extracted={len(extracted_contents)}/{len(urls)}")

    sources: List[Dict] = []
    citations: List[Dict] = []

    # ── Parallel per-URL processing (Tavily scoring + QFS) ────────────────────
    def _process_one_url(url: str) -> Dict[str, Any]:
        """Process a single external URL: score via Tavily, summarize content. Thread-safe."""
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        result = _tavily_search_domain(query, url)

        # Get raw content from Gemini extraction
        raw_content = extracted_contents.get(url, '').strip()
        extraction_engine = 'gemini' if raw_content else 'tavily'

        if result:
            page_title = result.get('title', '')
            score      = result.get('score', 0.0)
            title      = f"{domain} — {page_title}" if page_title else domain
            if not raw_content:
                raw_content = result.get('content', '')
                extraction_engine = 'tavily'
        else:
            # Fallback: compute score from word overlap
            if not raw_content:
                return None  # Signal: skip this URL
            score = _compute_description_score(topic, raw_content)
            title = domain

        # Run QFS engine to create a dense, context-focused summary
        summarized_content = summarize_web_content_with_llm(raw_content, requirements, url)

        return {
            'title': title, 'url': url, 'score': score,
            'summarized_content': summarized_content,
            'extraction_engine': extraction_engine,
            'raw_content_len': len(raw_content),
        }

    with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as ex:
        futures = {ex.submit(_process_one_url, url): url for url in urls}
        for fut in as_completed(futures):
            try:
                item = fut.result()
                if item is None:
                    url_key = futures[fut]
                    logger.warning(f"EXTERNAL_LINK | no content for '{url_key[:80]}'")
                    continue
                sources.append({
                    'title':           item['title'],
                    'source':          item['url'],
                    'type':            'external_url',
                    'date':            datetime.now().strftime('%Y-%m-%d'),
                    'relevance_score': item['score'],
                    'summary':         item['summarized_content'],
                    'url':             item['url'],
                    'extraction_engine': item['extraction_engine'],
                })
                citations.append({'title': item['title'], 'url': item['url'], 'source_type': 'external_url'})
                logger.info(f"EXTERNAL_LINK | url='{item['url'][:80]}' | score={item['score']} | raw_chars={item['raw_content_len']} | summary_chars={len(item['summarized_content'])}")
            except Exception as e:
                url_key = futures[fut]
                logger.warning(f"EXTERNAL_LINK | processing failed for '{url_key[:60]}' (non-fatal): {e}")

    return {'sources': sources, 'citations': citations, 'queries': []}




# ── Additional helpers (auto-extracted) ──────────────────────────

def _compute_description_score(topic: str, text: str) -> float:
    """
    Fallback relevance score (0.0–0.95) when Tavily domain search returns no result.
    Measures word overlap between request topic and a given text.

    Each matching meaningful word contributes 0.25, capped at 0.95.
    Returns a float on the same 0–1 scale as Tavily and KB scores.
    """
    _STOP = {
        'a', 'an', 'the', 'of', 'in', 'on', 'for', 'to', 'and', 'or',
        'with', 'is', 'are', 'at', 'by', 'its', 'this', 'that', 'as',
    }
    topic_words = {
        w for w in re.split(r'[\s,;.()\-]+', (topic or '').lower())
        if len(w) > 2 and w not in _STOP
    }
    text_words = {
        w for w in re.split(r'[\s,;.()\-]+', (text or '').lower())
        if len(w) > 2 and w not in _STOP
    }
    if not topic_words:
        return 0.0
    overlap = len(topic_words & text_words)
    return round(min(overlap * 0.25, 0.95), 3)


def _gemini_extract_urls(urls: List[str]) -> Dict[str, str]:
    """
    Extract content from URLs using Gemini url_context tool.
    
    This is the central Gemini extraction function used by:
    - External links (user-provided URLs)
    - Internal links (after Tavily ranking)
    - Web search (after Tavily URL discovery)
    
    Returns {url: content} dict.
    Runs extractions in parallel (max 5 workers).
    """
    if not urls or not LITELLM_KEY:
        return {}
    
    result: Dict[str, str] = {}
    
    def _extract_one(url: str) -> tuple:
        try:
            g = _gemini_url_context(url)
            if g.get('accessible') == 'yes' and g.get('content'):
                return url, g['content']
            else:
                logger.warning(
                    f"GEMINI_EXTRACT | url='{url[:60]}' | status={g['retrieval_status']} | error={g.get('error','')}"
                )
                return url, ''
        except Exception as e:
            logger.warning(f"GEMINI_EXTRACT | url='{url[:60]}' failed: {e}")
            return url, ''
    
    with ThreadPoolExecutor(max_workers=min(len(urls), 5)) as executor:
        futures = {executor.submit(_extract_one, u): u for u in urls}
        for future in as_completed(futures):
            url, content = future.result()
            if content:
                result[url] = content
    
    logger.info(f"GEMINI_EXTRACT | requested={len(urls)} | succeeded={len(result)}")
    return result


def _tavily_search_domain(query: str, url: str) -> Dict[str, Any]:
    """
    Search Tavily within a specific domain and return the top result.
    Routes queries through the private VPC LiteLLM proxy if available.
    """
    if not query or not url:
        return {}
        
    try:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or url

        # Detect private Bedrock / VPC gateway environment variables
        litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
        use_private_gateway = bool(litellm_key)

        if use_private_gateway:
            # Route through corporate VPC proxy. Search-tool name is team-scoped:
            # this key is only authorized for 'ccaiaa-dev-tavily' (plain 'tavily' -> 403).
            search_url = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/v1/search/ccaiaa-dev-tavily'
            headers = {
                "Authorization": f"Bearer {litellm_key}",
                "Content-Type": "application/json"
            }
            payload_data = {
                "query": query,
                "max_results": 1,
                "search_depth": "advanced",
                "include_domains": [domain]
            }
        else:
            # Local developer laptop fallback to public API
            if not TAVILY_API_KEY:
                logger.warning("TAVILY_API_KEY not configured; skipping domain search.")
                return {}
            search_url = 'https://api.tavily.com/search'
            headers = {"Content-Type": "application/json"}
            payload_data = {
                "api_key": TAVILY_API_KEY,
                "query": query,
                "search_depth": "advanced",
                "include_domains": [domain],
                "max_results": 1,
            }

        req = urllib.request.Request(
            search_url,
            data=json.dumps(payload_data).encode('utf-8'),
            headers=headers,
            method='POST',
        )

        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        results = data.get('results', [])
        if not results:
            logger.info(f"TAVILY_DOMAIN_SEARCH | no results | domain={domain}")
            return {}

        top = results[0]
        score = round(min(float(top.get('score', 0.0)), 1.0), 3)
        # Gateway returns 'snippet'; public Tavily returns 'content' — accept both.
        content = (top.get('content') or top.get('snippet') or '').strip()
        result = {
            'domain':  domain,
            'url':     top.get('url', url),
            'title':   (top.get('title') or '').strip(),
            'content': content,
            'score':   score,
        }
        logger.info(f"TAVILY_DOMAIN_SEARCH | domain={domain} | score={score} | content_chars={len(content)} | title='{result['title'][:60]}'")
        return result
        
    except Exception as e:
        logger.warning(f"Tavily domain search failed for '{url[:60]}': {e}")
        return {}


def summarize_web_content_with_llm(text: str, requirements: Dict[str, Any], source_url: str) -> str:
    """Uses Bedrock (via LiteLLM) to perform Query-Focused Summarization (QFS) on raw web content."""
    if not LITELLM_KEY or not text.strip():
        return text[:1500] # Safe fallback
        
    topic = requirements.get('topic', 'General Regulatory Topic')
    background = requirements.get('background', '')
    jurisdiction = requirements.get('jurisdiction', 'Global')
    target_audience = requirements.get('target_audience', 'General')
    target_lang = requirements.get('target_language', 'English')
    category = requirements.get('category', '')
    use_case = requirements.get('use_case', '')
    
    # Detect if this is a Letters scenario
    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()
    is_letter = 'letter' in cat_lower or 'letter' in uc_lower
    
    extra_context = ""
    if is_letter:
        subject = requirements.get('topic_of_letter') or requirements.get('topicOfLetter') or ''
        if subject:
            extra_context = f"\n- Subject of the Letter: {subject}"
            
    prompt = (
        "You are an expert corporate regulatory research assistant.\n"
        "Your task is to analyze raw text scraped from a webpage and produce a dense, highly focused summary "
        "tailored specifically to the following research query.\n\n"
        "RESEARCH REQUEST CONTEXT:\n"
        f"- Jurisdiction: {jurisdiction}\n"
        f"- Topic: {topic}\n"
        f"- Target Audience: {target_audience}\n"
        f"- Background Context: {background or 'N/A'}{extra_context}\n\n"
        f"SOURCE WEBPAGE URL: {source_url}\n\n"
        "RAW WEBPAGE CONTENT:\n"
        f"<webpage_content>\n{text}\n</webpage_content>\n\n"
        "INSTRUCTIONS:\n"
        "1. Identify and extract only key findings, statistics, official dates, and compliance mandates "
        "relevant to this specific research request.\n"
        "2. Strip out all noise (cookies notices, ads, irrelevant portal headers/footers).\n"
        "3. Keep the summary factual, dense, and objective. Do not invent details.\n"
        f"4. Write the summary directly in {target_lang} (approx 400-600 words).\n"
        "5. Output only the summary directly (no conversational prefix/suffix).\n"
        "6. Prioritize exact statistics, dollar amounts, dates, legislation names, and named authorities over narrative."
    )
    
    try:
        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 2000,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=45) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(res, name='user_sources_qfs_summarize', response=resp)
            except Exception:
                pass
            summary = res['choices'][0]['message']['content'].strip()
            return summary
    except Exception as e:
        logger.warning(f"Web QFS failed for URL '{source_url}': {e}")
        return text[:1500]




def _gemini_url_context(url: str) -> Dict[str, Any]:
    """
    Fetch and summarize a URL using Gemini's native url_context grounding tool,
    routed through the private LiteLLM proxy.

    Returns a dict with keys:
        content            : str   — summary text from Gemini (empty on failure)
        retrieval_status   : str   — e.g. 'URL_RETRIEVAL_STATUS_SUCCESS'
        output_len         : int   — character count of content
        error              : str   — non-empty when the call failed
    """
    if not LITELLM_KEY:
        return {'content': '', 'retrieval_status': 'NO_CREDENTIALS', 'output_len': 0, 'error': 'no LITELLM_KEY'}

    prompt = (
        f"Use the url_context tool to fetch and read this URL:\n{url}\n\n"
        "Then return ALL of the following in your response:\n"
        "1. ACCESSIBLE: yes or no (was the full page content readable?)\n"
        "2. TITLE: the page title\n"
        "3. FULL_CONTENT: the complete extracted text from the page — do NOT summarise, "
        "return as much raw content as possible including tables, numbers, dates, legislation names.\n"
        "4. SUMMARY: a 5–8 sentence factual summary of the key points.\n\n"
        "Format your response exactly like this:\n"
        "ACCESSIBLE: yes\n"
        "TITLE: <page title>\n"
        "FULL_CONTENT:\n<full text here>\n"
        "SUMMARY:\n<summary here>\n\n"
        "If the page is behind a login, paywalled, or truly inaccessible, respond:\n"
        "ACCESSIBLE: no\n"
        "TITLE: unknown\n"
        "FULL_CONTENT: none\n"
        "SUMMARY: Page could not be accessed."
    )
    body = {
        "model": GEMINI_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 4096,
        "tools": [{"url_context": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    try:
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(data, name='user_sources_gemini_url_context', response=resp)
            except Exception:
                pass

        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        url_ctx_meta = data.get('vertex_ai_url_context_metadata', [])
        retrieval_status = 'UNKNOWN'
        try:
            retrieval_status = url_ctx_meta[0]['urlMetadata'][0]['urlRetrievalStatus']
        except (KeyError, IndexError, TypeError):
            if url_ctx_meta:
                retrieval_status = str(url_ctx_meta)

        # Parse structured fields from the response
        content_stripped = content.strip()
        accessible = 'yes' if 'ACCESSIBLE: yes' in content_stripped else (
                     'no'  if 'ACCESSIBLE: no'  in content_stripped else 'unknown')

        return {
            'content':          content_stripped,
            'retrieval_status': retrieval_status,
            'accessible':       accessible,
            'output_len':       len(content_stripped),
            'error':            '',
        }
    except Exception as e:
        return {'content': '', 'retrieval_status': 'ERROR', 'output_len': 0, 'error': str(e)}


