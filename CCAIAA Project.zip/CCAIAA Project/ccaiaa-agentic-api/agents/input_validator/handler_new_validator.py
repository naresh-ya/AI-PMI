"""
Input Validator Agent for PMI Agentic AI Platform

This agent validates incoming requests and ensures all required fields are present
for government submission generation. It acts as the first gate in the workflow.

Responsibilities:
- Validate request format and required fields
- Extract and normalize input parameters
- Determine document type and requirements
- Set processing priority and SLA targets

LangSmith tracing: this handler is the ROOT of the Step Functions execution's
trace (the first state in the pipeline). See core/langsmith_tracing/ for the
shared SSL bootstrap, usage-recording, and cross-state propagation helpers.
"""

# NOTE on import path: at Lambda runtime, deploy_lambdas.py copies core/ as a
# FLAT sibling of this handler file inside the deployment zip (see the
# "includes" list for this Lambda in deploy_lambdas.py) -- so `import core...`
# resolves correctly with NO sys.path manipulation needed, exactly like every
# other agent handler in this repo that already imports from core.*.
import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (MUST import before langsmith)

import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import boto3

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers,
        attach_outgoing_langsmith_headers,
    )
    from core.langsmith_tracing.llm_usage import record_llm_usage as _record_llm_usage
    _LANGSMITH_TRACING_AVAILABLE = True
except Exception as _ls_import_err:
    _LANGSMITH_TRACING_AVAILABLE = False

    # No-op fallbacks so the validator boots and runs normally even if
    # langsmith tracing is unavailable (fail-open, matches the pattern
    # already used elsewhere for optional/best-effort dependencies).
    def traceable(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator if not args else _decorator(args[0])

    def get_incoming_langsmith_headers(event):
        return {}

    def attach_outgoing_langsmith_headers(result, run_tree):
        return result

    def _record_llm_usage(*args, **kwargs):
        pass
# pyrefly: ignore [missing-import]
from pydantic import BaseModel, ValidationError, model_validator
import os

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
requests_table = dynamodb.Table(os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests'))


class RequestInput(BaseModel):
    """Pydantic model for request validation"""
    document_type: Optional[str] = None
    category: Optional[str] = None
    use_case: Optional[str] = None
    topic: Optional[str] = None
    jurisdiction: Optional[str] = None
    deadline: Optional[str] = None
    target_audience: Optional[str] = None
    regulation_topic: Optional[str] = None
    background: Optional[str] = None
    stakeholders: Optional[str] = None
    priority: str = "medium"
    sources: Optional[str] = ""
    tone_requirements: str = "Formal, neutral, compliance-first, fact-based and non-promotional"
    uploaded_files: Optional[list] = []
    urls: Optional[list] = []
    reference_urls: Optional[list] = []
    output_file_type: str = "Microsoft Word (.docx)"
    
    # Extra fields that might be present in specific scenarios
    addressed_to: Optional[str] = None
    addressedTo: Optional[str] = None
    cc_to: Optional[str] = None
    ccTo: Optional[str] = None
    topic_of_letter: Optional[str] = None
    topicOfLetter: Optional[str] = None
    annexure: Optional[Any] = None # Using Any so it accepts string or list gracefully
    
    # New metadata fields from UI
    target_language: str = "English"
    category: Optional[str] = None
    use_case: Optional[str] = None
    user_id: Optional[str] = None
    enable_hitl: bool = True
    enable_topic_relevance_check: bool = True

    @model_validator(mode='before')
    @classmethod
    def map_frontend_fields(cls, data: Any) -> Any:
        if isinstance(data, dict):
            # Target audience can come from multiple frontend fields depending on scenario
            if not data.get('target_audience'):
                data['target_audience'] = (
                    data.get('addressed_to') or 
                    data.get('addressedTo') or 
                    data.get('stakeholders') or
                    "Relevant Stakeholders"
                )
            
            # Map uploadedFileKeys -> uploaded_files
            if not data.get('uploaded_files') and data.get('uploadedFileKeys'):
                data['uploaded_files'] = data.get('uploadedFileKeys')
                
        return data
        
    class Config:
        extra = "allow"

@traceable(name="input_validator", run_type="chain")
def _traced_lambda_handler(event: Dict[str, Any], context: Any, run_tree=None) -> Dict[str, Any]:
    """
    Thin @traceable wrapper around _do_validation().

    run_tree is only ever a live, usable reference INSIDE this function's
    call frame -- get_current_run_tree() returns None as soon as this
    function returns, even from inside the same tracing_context(...) block
    (verified directly against the SDK). So headers MUST be exported here,
    not by the caller. Calling run_tree.to_headers() here and embedding the
    plain resulting dict (not the RunTree object itself) into the result is
    also what avoids a "Failed to use dict to serialize RunTree..."
    RecursionError" warning that @traceable's own output-logging emits if a
    raw RunTree object is anywhere in the return value.
    """
    result = _do_validation(event, context, run_tree=run_tree)
    return attach_outgoing_langsmith_headers(result, run_tree)


def _do_validation(event: Dict[str, Any], context: Any, run_tree=None) -> Dict[str, Any]:
    """
    Lambda handler for Input Validator Agent

    This is the ROOT trace of the Step Functions execution -- the first
    state in the pipeline. request_id/user_id are attached as trace metadata
    here as soon as they're known.

    Args:
        event: Contains the request payload from frontend
        context: Lambda context object

    Returns:
        Validation result with status and extracted data
    """

    try:
        logger.info(f"Starting input validation for request: {json.dumps(event, default=str)}")

        # Extract request data (support nested request_data, requestData, or raw payload)
        request_data = event.get('request_data', event.get('requestData', event))
        request_id = event.get('request_id')

        if run_tree:
            run_tree.add_metadata({
                "request_id": request_id,
                "user_id": (request_data or {}).get('user_id') if isinstance(request_data, dict) else None,
            })
        
        if not request_id:
            request_id = f"req_{int(datetime.now().timestamp())}"
        
        # Validate input using Pydantic model
        try:
            validated_request = RequestInput(**request_data)
        except ValidationError as e:
            logger.error(f"Validation error: {e}")
            return {
                "status": "error",
                "error": "Invalid input format",
                "details": str(e),
                "request_id": request_id
            }
        
        # ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Required field presence check ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
        # Pydantic only checks types; these fields must also be non-empty
        # because the researcher uses them for KB query + prompt routing.
        REQUIRED_FIELDS = {
            "topic":        validated_request.topic,
            "category":     validated_request.category,
            "jurisdiction": validated_request.jurisdiction,
        }
        missing_fields = [field for field, value in REQUIRED_FIELDS.items() if not value or not str(value).strip()]
        if missing_fields:
            logger.warning(f"Required fields missing or empty: {missing_fields}")
            try:
                requests_table.update_item(
                    Key={'request_id': request_id},
                    UpdateExpression="SET #status = :status, error_msg = :err, updated_at = :ts",
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':status': 'VALIDATION_FAILED',
                        ':err': f"Required fields missing: {missing_fields}",
                        ':ts': datetime.utcnow().isoformat() + 'Z'
                    }
                )
            except Exception as db_err:
                logger.error(f"Failed to update status: {db_err}")
            return {
                "status": "missing_required_fields",
                "error": f"The following required fields are missing or empty: {missing_fields}",
                "request_id": request_id
            }

        # ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Topic Relevance Check (Toggle-Enabled) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
        if getattr(validated_request, 'enable_topic_relevance_check', False):
            logger.info("Topic relevance check is enabled. Calling LLM to validate input topic.")
            relevance_result = validate_topic_relevance_with_llm(
                validated_request.topic, 
                validated_request.background or ""
            )
            if not relevance_result.get('is_relevant', True):
                reason = relevance_result.get('reason', 'Irrelevant topic')
                logger.warning(f"Request {request_id} rejected due to irrelevant topic: {reason}")
                
                # Update requests table status to CANCELLED
                now_iso = datetime.utcnow().isoformat() + 'Z'
                try:
                    requests_table.update_item(
                        Key={'request_id': request_id},
                        UpdateExpression="SET #status = :status, progress_step = :progress_step, progress_pct = :progress_pct, cancel_reason = :reason, updated_at = :ts, #user_id = :user_id",
                        ExpressionAttributeNames={
                            '#status': 'status',
                            '#user_id': 'user_id'
                        },
                        ExpressionAttributeValues={
                            ':status': 'CANCELLED',
                            ':progress_step': 'CANCELLED',
                            ':progress_pct': 0,
                            ':reason': 'Irrelevant topic',
                            ':ts': now_iso,
                            ':user_id': validated_request.user_id or "anonymous"
                        }
                    )
                except Exception as db_err:
                    logger.error(f"Failed to update request status to CANCELLED in DB: {str(db_err)}")
                
                return {
                    "status": "irrelevant_topic",
                    "error": "The submitted topic is irrelevant to the corporate affairs and regulatory domain.",
                    "details": reason,
                    "request_id": request_id
                }

        # Calculate SLA deadline (30 minutes from now)
        sla_deadline = datetime.now() + timedelta(minutes=30)
        
        # Determine complexity level directly
        complexity_level = determine_complexity_level(validated_request)
        
        # Determine processing priority (deterministic)
        priority_score = calculate_priority_score(
            validated_request.priority, 
            validated_request.deadline,
            complexity_level
        )
        
        # Extract document requirements (deterministic)
        document_requirements = extract_document_requirements(validated_request)
        
        now_iso = datetime.utcnow().isoformat() + 'Z'
        
        update_expr = 'SET #status = :status, #validation_result = :validation_result, #priority_score = :priority_score, #deadline = :deadline, #created_at = :created_at, #updated_at = :updated_at, #category = :category, #jurisdiction = :jurisdiction, #topic = :topic, #user_id = :user_id'
        expr_names = {
            '#status': 'status',
            '#validation_result': 'validation_result',
            '#priority_score': 'priority_score',
            '#deadline': 'deadline',
            '#created_at': 'created_at',
            '#updated_at': 'updated_at',
            '#category': 'category',
            '#jurisdiction': 'jurisdiction',
            '#topic': 'topic',
            '#user_id': 'user_id'
        }
        expr_values = {
            ':status': 'VALIDATION_COMPLETED',
            ':validation_result': document_requirements,
            ':priority_score': priority_score,
            ':deadline': validated_request.deadline if validated_request.deadline else "2026-05-22",
            ':created_at': int(datetime.utcnow().timestamp()),
            ':updated_at': now_iso,
            ':category': validated_request.category if validated_request.category else "General",
            ':jurisdiction': validated_request.jurisdiction if validated_request.jurisdiction else "India",
            ':topic': validated_request.topic if validated_request.topic else "General Topic",
            ':user_id': validated_request.user_id if validated_request.user_id else "anonymous"
        }
        
        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression=update_expr,
                ExpressionAttributeNames=expr_names,
                ExpressionAttributeValues=expr_values
            )
        except Exception as db_err:
            logger.error(f"Failed to update DynamoDB record in Validator: {str(db_err)}")
            return {
                "status": "error",
                "error": "DynamoDB Update Failed in Validator",
                "details": str(db_err),
                "request_id": request_id
            }
        from datetime import timezone
        current_time = datetime.now()
        valid_till_date = current_time.replace(year=current_time.year + 5)
        
        document_metadata = {
            "document_id": request_id,
            "document_title": validated_request.topic,
            "created_date": current_time.strftime("%Y-%m-%d"),
            "last_modified_date": current_time.strftime("%Y-%m-%d"),
            "document_theme": validated_request.category or "Policy Document",
            "document_owner": validated_request.user_id or "Corporate Affairs",
            "country": validated_request.jurisdiction,
            "language": validated_request.target_language,
            "valid_till_date": valid_till_date.strftime("%Y-%m-%d"),
            "archive_flag": False,
            "department": validated_request.category or "Corporate Affairs"
        }
        
        # Prepare validation result
        validation_result = {
            "status": "success",
            "request_id": request_id,
            "priority_score": priority_score,
            "sla_deadline": sla_deadline.isoformat(),
            "document_requirements": document_requirements,
            "document_metadata": document_metadata,
            "enable_hitl": document_requirements.get("enable_hitl", True),
            "processing_notes": {
                "language": validated_request.target_language,
                "output_format": validated_request.output_file_type,
                "complexity_level": complexity_level,
                "validation_notes": ["Passed strict Pydantic and regex validation"]
            },
            "next_agent": "master_researcher"
        }
        
        logger.info(f"Input validation completed successfully for request {request_id}")
        
        return validation_result
        
    except Exception as e:
        logger.error(f"Error in input validation: {str(e)}")
        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression="SET #status = :status, error_msg = :err, updated_at = :ts",
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':status': 'VALIDATION_FAILED',
                    ':err': f"Validator exception: {str(e)}",
                    ':ts': datetime.utcnow().isoformat() + 'Z'
                }
            )
        except Exception as db_err:
            logger.error(f"Failed to update status: {db_err}")
        return {
            "status": "error",
            "error": "Input validation failed",
            "details": str(e),
            "request_id": request_id if 'request_id' in locals() else "unknown"
        }


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Real Lambda entry point.

    Reads any propagated LangSmith trace context off the incoming event
    (there is none for THIS stage today, since it's the pipeline's root --
    but resolving it generically here keeps this handler consistent with
    every downstream stage's wrapper, and future-proofs against this ever
    being re-entered mid-pipeline), opens tracing_context so
    @traceable(name="input_validator", ...) correctly nests under it if
    present, and runs the real handler. _traced_lambda_handler itself
    exports the outgoing langsmith_headers onto its result before
    returning (see its docstring for why this must happen there, not here).
    """
    if not _LANGSMITH_TRACING_AVAILABLE:
        return _traced_lambda_handler(event, context)

    from langsmith.run_helpers import tracing_context

    incoming_headers = get_incoming_langsmith_headers(event)
    with tracing_context(parent=incoming_headers):
        return _traced_lambda_handler(event, context)


def calculate_priority_score(priority: str, deadline: str, complexity_level: str) -> int:
    """Calculate priority score based on priority level, deadline, and complexity assessment"""
    from datetime import datetime, timezone
    
    # Safely handle None values
    safe_priority = (priority or "medium").lower()
    base_score = {"high": 90, "medium": 60, "low": 30}.get(safe_priority, 50)
    
    try:
        if deadline:
            deadline_date = datetime.fromisoformat(deadline.replace('Z', '+00:00'))
            # Ensure we use timezone-aware current time for subtraction
            days_until_deadline = (deadline_date - datetime.now(timezone.utc)).days
            
            # Increase score for tight deadlines
            if days_until_deadline < 2:
                base_score += 20
            elif days_until_deadline < 5:
                base_score += 10
            
    except (ValueError, TypeError, AttributeError):
        # Ignore invalid dates
        pass
        
    # Adjust based on complexity
    safe_complexity = (complexity_level or "medium").lower()
    if safe_complexity == "high":
        base_score += 15
    elif safe_complexity == "low":
        base_score -= 5   # Lower priority for simple requests
    
    return min(100, max(1, base_score))


def extract_document_requirements(request: RequestInput) -> Dict[str, Any]:
    """Extract document requirements based on request type and jurisdiction"""
    
    # Merge user-provided sources and URLs into a flat list
    user_sources = []
    if request.sources:
        user_sources.append(request.sources)
    if request.reference_urls:
        user_sources.extend(request.reference_urls)
    if request.uploaded_files:
        user_sources.extend(request.uploaded_files)

    # Combine urls and reference_urls as external links for the researcher
    external_links = list({u for u in (request.urls or []) + (request.reference_urls or []) if u})

    requirements = {
        "jurisdiction": request.jurisdiction or "India",
        "target_audience": request.target_audience or "General Audience",
        "topic": request.topic or "General Topic",
        "background": request.background or "No background provided",
        "tone_requirements": request.tone_requirements or "Formal",
        "addressed_to": request.addressed_to or request.addressedTo or "",
        "cc_to": request.cc_to or request.ccTo or "",
        "category": request.category or "General",
        "target_language": request.target_language or "English",
        "compliance_requirements": [],
        "research_sources": user_sources,
        "required_sections": [],
        "citation_style": "APA",
        "word_count_target": 2000,
        "completeness_score": 100,
        "confidence_score": 95,
        # Fields consumed by the researcher agent
        "uploaded_file_s3_key": request.uploaded_files[0] if request.uploaded_files else "",
        "external_links": external_links,
        "enable_hitl": request.enable_hitl,
        "enable_topic_relevance_check": request.enable_topic_relevance_check,
    }
    
    # Jurisdiction-specific requirements
    topic_lower = (request.topic or "").lower()
    if "tobacco" in topic_lower:
        requirements["compliance_requirements"].extend([
            "COTPA 2003 compliance",
            "International Treaty obligations", 
            "No youth-targeted claims",
            "Statutory warnings included"
        ])
        requirements["research_sources"].extend([
            "Local Trade website",
            "Agriculture portal",
            "PIB notifications", 
            "FMI SharePoint India folder"
        ])
    
    # Section requirements are now driven by templates (loaded from S3 during drafting)
    # No hardcoded section lists here ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â the drafter uses template files per category
    
    return requirements


def determine_complexity_level(request: RequestInput) -> str:
    """Determine document complexity based on various factors"""
    
    complexity_factors = 0
    
    # Category complexity
    complex_categories = ["White Papers", "Official PMI Submission"]
    if request.category in complex_categories:
        complexity_factors += 2
    
    # Jurisdiction complexity
    if "India" in (request.jurisdiction or ""):
        complexity_factors += 1  # Complex regulatory environment
    
    # Topic complexity
    complex_topics = ["clinical", "toxicology", "taxation", "excise", "youth access"]
    regulation_topic_lower = (request.regulation_topic or "").lower()
    if any(topic in regulation_topic_lower for topic in complex_topics):
        complexity_factors += 1
    
    # Additional sources
    if len(request.uploaded_files or []) > 3:
        complexity_factors += 1
    if len(request.urls or []) > 5:
        complexity_factors += 1
    
    if complexity_factors >= 4:
        return "high"
    elif complexity_factors >= 2:
        return "medium"
    else:
        return "low"


def validate_topic_relevance_with_llm(topic: str, background: str) -> Dict[str, Any]:
    """
    Invokes LiteLLM to validate if the input topic/background are relevant to the PMI business context.
    Returns:
        Dict: {"is_relevant": bool, "reason": str}
    """
    import urllib.request
    import ssl
    import json
    import os

    # LiteLLM endpoint & credentials
    litellm_url = os.environ.get('AWS_LITELLM_ENDPOINT', 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions')
    litellm_model = os.environ.get('AWS_LITELLM_MODEL', 'anthropic.claude-3-haiku-20240307-v1:0')
    litellm_key = os.environ.get('AWS_BEARER_TOKEN_BEDROCK', '')

    if not litellm_key:
        logger.warning("AWS_BEARER_TOKEN_BEDROCK is not configured. Skipping topic relevance validation.")
        return {"is_relevant": True, "reason": "Bypassed relevance validation: no LLM token"}

    system_prompt = """
You are an expert input validation assistant for the PMI Corporate Affairs Agentic Platform.
Your job is to determine whether the user's submitted topic and background description are relevant to the corporate affairs, public policy, trade, or tobacco/nicotine regulatory domain.

Relevant topics/backgrounds include:
- Tobacco or nicotine regulations (FCTC, COTPA, FDA, excise duties, tax policies, plain packaging, product classifications, tobacco harm reduction).
- Corporate Social Responsibility (CSR) and Environmental, Social, and Governance (ESG) policies relevant to corporate operations.
- Government advocacy strategies, public consultations, policy updates, media relation drafts, and internal briefing documents regarding regulatory affairs or commercial updates.

Irrelevant topics include:
- General weather, sports updates (IPL, cricket matches, football scores), movies, pop culture, entertainment reviews.
- Writing code, solving general math equations, writing general emails/letters unrelated to corporate/policy affairs.
- Conversational chitchat (e.g. "how are you today?").

You must reply with a valid JSON object only. The JSON must contain exactly two keys:
1. "is_relevant": true or false.
2. "reason": a short explanation of why the input is relevant or irrelevant.
"""

    user_prompt = f"""
Evaluate the following query:
- Topic: {topic}
- Background: {background}

Return JSON with "is_relevant" and "reason" keys. Do not include any other text or markdown wrappers.
"""

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        headers = {
            "Authorization": f"Bearer {litellm_key}",
            "Content-Type": "application/json"
        }

        data = {
            "model": litellm_model,
            "system": system_prompt.strip(),
            "messages": [
                {"role": "user", "content": user_prompt.strip()}
            ],
            "max_tokens": 512,
            "temperature": 0.0  # Deterministic categorization
        }

        req = urllib.request.Request(
            litellm_url,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST'
        )

        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            res = json.loads(response.read().decode('utf-8'))
            _record_llm_usage(res, name="topic_relevance_llm", response=response)
            raw_content = res['choices'][0]['message']['content'].strip()

            # Clean markdown wrappers if returned
            if raw_content.startswith('```'):
                lines = raw_content.split('\n')
                if len(lines) > 2:
                    raw_content = '\n'.join(lines[1:-1]).strip()

            result = json.loads(raw_content)
            return {
                "is_relevant": bool(result.get("is_relevant", True)),
                "reason": str(result.get("reason", "No reason provided"))
            }

    except Exception as e:
        logger.error(f"Failed to perform LLM topic relevance validation: {str(e)}")
        # Default to True on failure so we don't block legitimate users in production
        return {"is_relevant": True, "reason": f"Validation call error: {str(e)}"}
