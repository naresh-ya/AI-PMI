"""
Draft Re-Draft Module (fully standalone).

Provides: handle_redraft(), analyze_redraft_intent(), conduct_selective_redraft()

Uses Haiku for intent classification. Falls back to full redraft if confidence < 0.7.
Imports drafter stage modules directly (planner, generator, assembler) via _DRAFT_EXTRA.
Generates versioned .docx files (up to 3 versions).
"""
import json
import logging
import os
import re
import ssl
import urllib.request
from datetime import datetime
from typing import Dict, Any, List

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import core.langsmith_tracing.ssl_bootstrap  # must precede langsmith
from core.drafter_common import (
    logger, LITELLM_KEY, LITELLM_URL, LLM_MODEL_FAST,
    s3, DOCUMENT_BUCKET, load_draft_artifact, save_draft_artifact,
    update_request_status, load_research_data,
    requests_table, clean_citation_title,
)

try:
    from core.langsmith_tracing.llm_usage import record_llm_usage
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False
    def record_llm_usage(*args, **kwargs):
        pass
from difflib import SequenceMatcher

try:
    import drafter_planner as planner
    import drafter_generator as generator
    import drafter_assembler as assembler
except ImportError:
    from agents.master_drafter import drafter_planner as planner
    from agents.master_drafter import drafter_generator as generator
    from agents.master_drafter import drafter_assembler as assembler


# â”€â”€ Configuration â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
REDRAFT_CONFIDENCE_THRESHOLD = float(os.environ.get('REDRAFT_CONFIDENCE_THRESHOLD', '0.7'))
REDRAFT_MAX_RETRIES = int(os.environ.get('REDRAFT_MAX_RETRIES', '3'))

VALID_STAGES = {'planner', 'generator', 'assembler'}

# Confidence threshold for treating a fuzzy title match as "the reference the reviewer meant".
CITATION_REMOVAL_FUZZY_THRESHOLD = float(os.environ.get('CITATION_REMOVAL_FUZZY_THRESHOLD', '0.62'))

# Keywords that signal the reviewer wants a reference/citation/source removed.
_REMOVE_INTENT_RE = re.compile(
    r'\b(remove|delete|drop|take\s+out|exclude|get\s+rid\s+of)\b.*?'
    r'\b(reference|citation|source|link)\b',
    re.IGNORECASE | re.DOTALL,
)


def _normalize_title(t: str) -> str:
    """Lower, strip file extensions and trailing ellipses/punctuation, collapse whitespace —
    so 'Small Batch Manufacturers and Third Party Testing' matches the cited title regardless
    of a '.docx' suffix, a trailing ' ...', or case."""
    t = (t or '').strip().lower()
    t = re.sub(r'\.(docx?|pdf|xlsx?|pptx?|html?|json|txt)\b', '', t)
    t = re.sub(r'[\u2026]|\.\.\.', ' ', t)
    t = re.sub(r'[^a-z0-9 ]', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t


def _extract_removal_targets(feedback: str) -> List[str]:
    """From free-text reviewer feedback, extract the citation title(s) they want removed.

    Per product decision: prefer quoted text; if no quotes but there is a clear remove-a-reference
    intent, fall back to the phrase after the intent keywords. Returns a list (may be empty)."""
    if not feedback:
        return []
    # 1) Quoted text has highest priority (straight or smart quotes).
    quoted = re.findall(r'["\u201c\u2018\u2019\u201d\']([^"\u201c\u2018\u2019\u201d\']{3,})["\u201c\u2018\u2019\u201d\']', feedback)
    quoted = [q.strip() for q in quoted if q and q.strip()]
    if quoted:
        return quoted
    # 2) No quotes: only if there's an explicit remove-reference intent, take the trailing phrase.
    if _REMOVE_INTENT_RE.search(feedback):
        m = re.search(r'\b(?:reference|citation|source|link)s?\s*(?:of|for|to|named|titled|:)?\s*(.+)$',
                      feedback, re.IGNORECASE | re.DOTALL)
        if m:
            tail = m.group(1).strip()
            tail = re.sub(r'\bfrom the (draft|document|references?)\b.*$', '', tail, flags=re.IGNORECASE).strip()
            tail = tail.strip(' .,:;-')
            if len(tail) >= 3:
                return [tail]
    return []


def _prune_citations_by_feedback(request_id: str, research_result: Dict[str, Any],
                                 research_data: Dict[str, Any], feedback: str) -> int:
    """If the reviewer asked to remove a reference, drop the matching citation(s) from ALL the
    lists that feed the References section and the inline [N] registry, so both stay consistent.

    Matches a target against citation titles by exact normalized equality, containment, or a
    fuzzy ratio >= threshold. Mutates research_result['citations'|'sources'] and
    research_data['formatted_citations'|'all_sources'] in place. Returns count removed.
    Best-effort: never raises."""
    try:
        targets = _extract_removal_targets(feedback)
        if not targets:
            return 0
        norm_targets = [_normalize_title(t) for t in targets if _normalize_title(t)]
        if not norm_targets:
            return 0

        def _matches(title: str) -> bool:
            nt = _normalize_title(title)
            if not nt:
                return False
            for tgt in norm_targets:
                if nt == tgt or tgt in nt or nt in tgt:
                    return True
                if SequenceMatcher(None, nt, tgt).ratio() >= CITATION_REMOVAL_FUZZY_THRESHOLD:
                    return True
            return False

        removed_titles = []

        def _filter_list(lst):
            if not isinstance(lst, list):
                return lst
            kept = []
            for c in lst:
                title = c.get('title', '') if isinstance(c, dict) else str(c)
                if _matches(title):
                    removed_titles.append(title)
                else:
                    kept.append(c)
            return kept

        if isinstance(research_result, dict):
            for k in ('citations', 'sources'):
                if k in research_result:
                    research_result[k] = _filter_list(research_result[k])
        if isinstance(research_data, dict):
            for k in ('formatted_citations', 'all_sources'):
                if k in research_data:
                    research_data[k] = _filter_list(research_data[k])

        removed_count = len(removed_titles)
        if removed_count:
            logger.info(f"[{request_id}] CITATION_REMOVAL | targets={norm_targets} "
                        f"removed={list(dict.fromkeys(removed_titles))}")
        else:
            logger.info(f"[{request_id}] CITATION_REMOVAL | no citation matched targets={norm_targets}")
        return removed_count
    except Exception as e:
        logger.warning(f"[{request_id}] CITATION_REMOVAL failed (non-fatal): {e}")
        return 0


def _recover_document_requirements(request_id: str, validation_result: Dict[str, Any]) -> None:
    """Fix the redraft category regression. The stored plan artifact often has an EMPTY category
    in validation_result.document_requirements, and the API passes validation_result={}, so the
    assembler falls back to 'unknown_category' (wrong served filename/template).

    Backfill category/use_case/document_type/topic/jurisdiction from the authoritative request
    record whenever missing. Mutates validation_result in place. Best-effort."""
    try:
        dr = validation_result.get('document_requirements', {}) or {}
        if (dr.get('category') or '').strip():
            validation_result['document_requirements'] = dr
            return  # category present -> nothing to recover
        item = requests_table.get_item(Key={'request_id': request_id}).get('Item') or {}
        for k in ('category', 'use_case', 'document_type', 'topic', 'jurisdiction'):
            if not str(dr.get(k) or '').strip() and str(item.get(k) or '').strip():
                dr[k] = item.get(k)
        validation_result['document_requirements'] = dr
        logger.info(f"[{request_id}] REDRAFT_REQS_RECOVERED | category='{dr.get('category','')}'")
    except Exception as e:
        logger.warning(f"[{request_id}] _recover_document_requirements failed (non-fatal): {e}")


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# Public Entry Point
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

def handle_redraft(event: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Main entry point for intelligent re-drafting.

    Analyzes feedback, selectively re-runs required drafter stages, and
    returns a draft_result in the same shape as the normal assembler output.
    """
    draft_hitl_result = event.get('draft_hitl_result', {}) or {}
    human_feedback = (draft_hitl_result.get('feedback') or '').strip()
    plan_s3_key = event.get('plan_s3_key', '')
    sections_s3_key = event.get('sections_s3_key', '')
    validation_result = event.get('validation_result', {}) or {}
    synthesis_output = event.get('synthesis_output', {}) or {}
    hitl_draft_retry_count = int(event.get('hitl_draft_retry_count') or 0)

    requirements = validation_result.get('document_requirements', {}) or {}

    logger.info(
        f"[{request_id}] RE_DRAFT | feedback='{human_feedback[:100]}' "
        f"| retry={hitl_draft_retry_count}"
    )

    # Safety: max retries
    if hitl_draft_retry_count >= REDRAFT_MAX_RETRIES:
        logger.warning(f"[{request_id}] Max re-draft retries ({REDRAFT_MAX_RETRIES}) reached, full redraft")
        return _full_redraft(request_id, plan_s3_key, sections_s3_key,
                            synthesis_output, validation_result, human_feedback)

    # Analyze intent
    intent = analyze_redraft_intent(
        human_feedback=human_feedback,
        requirements=requirements,
        request_id=request_id,
    )

    logger.info(
        f"[{request_id}] REDRAFT_INTENT | required={intent['required_stages']} "
        f"| confidence={intent['confidence']:.2f} "
        f"| reasoning='{intent['reasoning'][:100]}'"
    )

    # Decision: selective vs full redraft
    if intent['confidence'] >= REDRAFT_CONFIDENCE_THRESHOLD:
        return conduct_selective_redraft(
            request_id=request_id,
            required_stages=intent['required_stages'],
            plan_s3_key=plan_s3_key,
            sections_s3_key=sections_s3_key,
            synthesis_output=synthesis_output,
            validation_result=validation_result,
            human_feedback=human_feedback,
        )
    else:
        logger.warning(
            f"[{request_id}] Redraft confidence {intent['confidence']:.2f} "
            f"< threshold {REDRAFT_CONFIDENCE_THRESHOLD}, using full redraft"
        )
        return _full_redraft(request_id, plan_s3_key, sections_s3_key,
                            synthesis_output, validation_result, human_feedback)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# Intent Analysis
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

def analyze_redraft_intent(
    human_feedback: str,
    requirements: Dict[str, Any],
    request_id: str = 'unknown',
) -> Dict[str, Any]:
    """LLM-based intent classification for draft revision routing.

    Uses Haiku for fast, cheap classification. Returns required_stages + confidence.
    On failure, returns confidence=0.0 (triggers full redraft).
    """
    system_prompt = _build_intent_system_prompt()
    user_prompt = (
        f"USER FEEDBACK: \"{human_feedback}\"\n\n"
        f"DOCUMENT CONTEXT:\n"
        f"- Category: {requirements.get('category', '')}\n"
        f"- Topic: {requirements.get('topic', '')}\n"
        f"- Jurisdiction: {requirements.get('jurisdiction', '')}\n\n"
        f"Based on the feedback, which drafter stages need to be re-executed?\n"
        f"Return ONLY the JSON object."
    )

    try:

        data = json.dumps({
            "model": LLM_MODEL_FAST,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "max_tokens": 300,
            "temperature": 0.0,
        }).encode('utf-8')

        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(LITELLM_URL, data=data, headers=headers, method='POST')
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=15) as resp:
            raw_response = resp.read().decode('utf-8')
            res = json.loads(raw_response)
            if LANGSMITH_AVAILABLE:
                try:
                    record_llm_usage(res, 'drafter_redraft_intent', raw_response)
                except Exception:
                    pass
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            m = re.search(r'\{[\s\S]*\}', raw)
            intent = json.loads(m.group(0) if m else raw)

        # Validate
        raw_stages = intent.get('required_stages', [])
        if isinstance(raw_stages, str):
            raw_stages = [s.strip() for s in raw_stages.split(',')]
        intent['required_stages'] = [s for s in raw_stages if s in VALID_STAGES]

        # Ensure downstream stages are included (planner requires generator+assembler, etc.)
        if 'planner' in intent['required_stages']:
            intent['required_stages'] = ['planner', 'generator', 'assembler']
        elif 'generator' in intent['required_stages'] and 'assembler' not in intent['required_stages']:
            intent['required_stages'].append('assembler')

        intent['confidence'] = max(0.0, min(1.0, float(intent.get('confidence', 0.0))))
        intent['reasoning'] = str(intent.get('reasoning', ''))

        return intent

    except Exception as e:
        logger.error(f"[{request_id}] Redraft intent analysis failed: {e}", exc_info=True)
        return {
            'required_stages': ['planner', 'generator', 'assembler'],
            'reasoning': f'Intent analysis failed ({str(e)}), full redraft',
            'confidence': 0.0,
        }


def _build_intent_system_prompt() -> str:
    return """You are a document revision router for a draft generation system.

Given user feedback on a generated document, determine which drafter stages need to be re-executed.

Available stages (each depends on the previous):
- planner: Re-creates the document structure/outline. Use when feedback asks to ADD/REMOVE/REORDER sections.
- generator: Re-generates section content. Use when feedback asks to change TONE, EXPAND/SHORTEN content, REWRITE sections, add more detail, change style, or FIX CITATION MISMATCHES (where inline [N] markers in the body don't match the References section â€” this requires content re-generation to produce correct citations).
- assembler: Re-formats and re-assembles the .docx. Use when feedback asks to fix FORMATTING (fonts, page breaks, bold/italic), TRANSLATION, or superficial layout issues. Do NOT use assembler-only for citation content problems.

Dependency rules:
- If planner is needed â†’ generator + assembler also run (downstream dependency)
- If generator is needed â†’ assembler also runs
- If only assembler is needed â†’ just assembler runs

Examples:
- "Add a new section on youth prevention" â†’ planner + generator + assembler (structure change)
- "Remove the executive summary section" â†’ planner + generator + assembler (structure change)
- "Make the tone more formal throughout" â†’ generator + assembler (content change)
- "Expand the evidence section with more data" â†’ generator + assembler (content change)
- "Shorten to 1500 words" â†’ generator + assembler (content change)
- "Remove promotional language" â†’ generator + assembler (content change)
- "Fix citation numbering" â†’ generator + assembler (citation mismatch requires content re-generation)
- "Some references in the body don't match the References section" â†’ generator + assembler (citation mismatch)
- "Translate to Thai" â†’ assembler only (formatting)
- "Make headings bold" â†’ assembler only (formatting)
- "Fix page breaks" â†’ assembler only (formatting)
- "Start over completely" â†’ planner + generator + assembler (full redraft)
- "This doesn't match my request" â†’ planner + generator + assembler (full redraft)

Return ONLY a JSON object:
{"required_stages": ["generator", "assembler"], "reasoning": "User wants tone change which requires content regeneration", "confidence": 0.88}"""


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# Selective Re-Draft Execution
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

def conduct_selective_redraft(
    request_id: str,
    required_stages: List[str],
    plan_s3_key: str,
    sections_s3_key: str,
    synthesis_output: Dict[str, Any],
    validation_result: Dict[str, Any],
    human_feedback: str,
) -> Dict[str, Any]:
    """Execute only required drafter stages and return draft_result."""

    logger.info(f"[{request_id}] SELECTIVE_REDRAFT | stages={required_stages}")

    # Fix B — recover the real document requirements (esp. category) from the request record.
    # The plan artifact often stores an empty category and the API passes validation_result={},
    # which made the assembler fall back to 'unknown_category'. Backfill BEFORE anything runs so
    # prompts and the served filename use the correct category/topic/jurisdiction.
    _recover_document_requirements(request_id, validation_result)

    # Inject feedback into validation for prompt context
    if human_feedback:
        dr = validation_result.get('document_requirements', {})
        dr['_redraft_feedback'] = human_feedback
        validation_result['document_requirements'] = dr

    # Load existing artifacts
    plan = load_draft_artifact(plan_s3_key)
    research_result = plan.get('research_result', synthesis_output)

    # Fix A — if the reviewer asked to remove a reference/citation, prune the matching
    # citation(s) from the research data BEFORE any stage runs. The References section and the
    # inline [N] registry both derive from these lists, so this removes the reference from the
    # rendered document and keeps body markers consistent. Applies to every stage path because
    # research_result / plan['research_data'] are shared by planner, generator and assembler.
    _pruned = _prune_citations_by_feedback(
        request_id, research_result, plan.get('research_data', {}), human_feedback
    )
    if _pruned:
        logger.info(f"[{request_id}] REDRAFT | pruned {_pruned} citation(s) per reviewer feedback")

    if 'planner' in required_stages:
        # Full redraft path: re-plan â†’ re-generate â†’ re-assemble
        logger.info(f"[{request_id}] REDRAFT | running planner + generator + assembler")
        new_plan = planner.plan_document(research_result, validation_result, request_id)
        document_content = generator.generate_document(
            new_plan['document_structure'], new_plan['research_data'], validation_result, request_id
        )
        # Save updated plan + sections artifacts
        new_plan_key = save_draft_artifact(request_id, 'plan', {
            'document_structure': new_plan['document_structure'],
            'research_data': new_plan['research_data'],
            'research_result': research_result,
            'validation_result': validation_result,
        })
        new_sections_key = save_draft_artifact(request_id, 'sections', {
            'document_content': document_content,
        })

    elif 'generator' in required_stages:
        # Re-generate content with existing structure
        logger.info(f"[{request_id}] REDRAFT | running generator + assembler (existing plan)")
        document_content = generator.generate_document(
            plan['document_structure'], plan['research_data'], validation_result, request_id
        )
        new_sections_key = save_draft_artifact(request_id, 'sections', {
            'document_content': document_content,
        })

    else:
        # Assembler only â€” load existing sections
        logger.info(f"[{request_id}] REDRAFT | running assembler only")
        sections = load_draft_artifact(sections_s3_key)
        document_content = sections['document_content']

    # Always run assembler (stores the clean served doc + an immutable versioned copy).
    return assembler.assemble_document(
        document_content,
        plan['document_structure'],
        research_result,
        validation_result,
        request_id,
    )


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# Full Redraft Fallback
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

def _full_redraft(
    request_id: str,
    plan_s3_key: str,
    sections_s3_key: str,
    synthesis_output: Dict[str, Any],
    validation_result: Dict[str, Any],
    human_feedback: str,
) -> Dict[str, Any]:
    """Fallback: run all 3 stages."""
    return conduct_selective_redraft(
        request_id=request_id,
        required_stages=['planner', 'generator', 'assembler'],
        plan_s3_key=plan_s3_key,
        sections_s3_key=sections_s3_key,
        synthesis_output=synthesis_output,
        validation_result=validation_result,
        human_feedback=human_feedback,
    )
