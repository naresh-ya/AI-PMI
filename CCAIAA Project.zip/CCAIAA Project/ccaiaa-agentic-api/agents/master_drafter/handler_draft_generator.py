"""Drafter split stage 2: GENERATOR (client-demo2).

Thin wrapper around drafter_generator.generate_document. Loads the plan artifact from S3,
generates document content (SEQUENTIAL section generation + internal review/dedup, or the
single-call letter path), and persists a 'sections' artifact to S3 for the assembler.

Event (from the SF):
    {"request_id": str, "plan_s3_key": str}
Returns:
    {"request_id": str, "plan_s3_key": str, "sections_s3_key": str}

Writes nothing user-facing; only an inter-stage S3 artifact.
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import core.langsmith_tracing.ssl_bootstrap  # must precede langsmith
from core.drafter_common import logger, load_draft_artifact, save_draft_artifact

try:
    import drafter_generator as generator          # Lambda package root
except ImportError:                                # local / dev
    from agents.master_drafter import drafter_generator as generator

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers, attach_outgoing_langsmith_headers, tracing_context
    )
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False


@traceable(name="draft_generator_stage", run_type="chain")
def _traced_generator(request_id, plan_s3_key, plan, langsmith_headers=None):
    logger.info(f"[{request_id}] STAGE draft_generator start (plan={plan_s3_key})")
    if langsmith_headers is None:
        langsmith_headers = {}
    document_content = generator.generate_document(
        plan['document_structure'], plan['research_data'], plan['validation_result'], request_id
    )
    sections_s3_key = save_draft_artifact(request_id, 'sections', {
        'document_content': document_content,
    })
    return {'request_id': request_id, 'plan_s3_key': plan_s3_key, 'sections_s3_key': sections_s3_key, 'langsmith_headers': langsmith_headers}


def lambda_handler(event, context):
    request_id = str(event.get('request_id') or 'unknown')
    plan_s3_key = event.get('plan_s3_key')
    langsmith_headers = event.get('langsmith_headers', {})
    plan = load_draft_artifact(plan_s3_key)

    if LANGSMITH_AVAILABLE:
        try:
            incoming = get_incoming_langsmith_headers(event)
            with tracing_context(parent=incoming):
                result = _traced_generator(request_id, plan_s3_key, plan, langsmith_headers)
            from langsmith import get_current_run_tree
            run_tree = get_current_run_tree()
            attach_outgoing_langsmith_headers(result, run_tree)
            return result
        except Exception as e:
            logger.warning(f"[{request_id}] LangSmith tracing failed: {e}", exc_info=True)
    return _traced_generator(request_id, plan_s3_key, plan, langsmith_headers)
