"""Drafter split stage 1: PLANNER (client-demo2).

Thin wrapper around drafter_planner.plan_document. Loads research data from S3 and
builds the document structure, then persists a 'plan' artifact to S3 for the generator.

Event (from the SF, same inputs the monolith drafter received):
    {"request_id": str, "research_result": {...synthesis_output...}, "validation_result": {...}}
Returns:
    {"request_id": str, "plan_s3_key": str}

Writes nothing user-facing; only an inter-stage S3 artifact. (HITL approval can be inserted
right after this stage in the Step Function later.)
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import core.langsmith_tracing.ssl_bootstrap  # must precede langsmith
from core.drafter_common import (
    logger, _unwrap_drafter_inputs, update_request_status, save_draft_artifact,
)

try:
    import drafter_planner as planner              # Lambda package root
except ImportError:                                # local / dev
    from agents.master_drafter import drafter_planner as planner

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers, attach_outgoing_langsmith_headers, tracing_context
    )
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False


@traceable(name="draft_planner_stage", run_type="chain")
def _traced_planner(request_id, research_result, validation_result, langsmith_headers=None):
    logger.info(f"[{request_id}] STAGE draft_planner start")
    update_request_status(request_id, 'DRAFTING_IN_PROGRESS', 'Document planning initiated')
    
    if langsmith_headers is None:
        langsmith_headers = {}

    plan = planner.plan_document(research_result, validation_result, request_id)

    # The S3 research_data.json is the single source of truth for sources/citations.
    # If HITL exclusions were applied, they're in S3 — override the SF event data
    # so downstream stages (generator, assembler) use only approved sources.
    research_data = plan['research_data']
    research_result['citations'] = research_data.get('formatted_citations', research_result.get('citations', []))
    if research_data.get('all_sources'):
        research_result['sources'] = [
            {'source_id': f"src_{i+1:03d}", 'title': s.get('title', ''), 'url': s.get('url', ''),
             'source_type': s.get('type', ''), 'relevance_score': s.get('relevance_score', 0),
             'summary': s.get('summary', '')[:200]}
            for i, s in enumerate(research_data['all_sources'])
        ]

    plan_s3_key = save_draft_artifact(request_id, 'plan', {
        'document_structure': plan['document_structure'],
        'research_data': plan['research_data'],
        'research_result': research_result,
        'validation_result': validation_result,
    })
    return {'request_id': request_id, 'plan_s3_key': plan_s3_key, 'langsmith_headers': langsmith_headers}


def lambda_handler(event, context):
    request_id, research_result, validation_result, langsmith_headers = _unwrap_drafter_inputs(event)
    if LANGSMITH_AVAILABLE:
        try:
            incoming = get_incoming_langsmith_headers(event)
            with tracing_context(parent=incoming):
                result = _traced_planner(request_id, research_result, validation_result, langsmith_headers)
            from langsmith import get_current_run_tree
            run_tree = get_current_run_tree()
            attach_outgoing_langsmith_headers(result, run_tree)
            return result
        except Exception as e:
            logger.warning(f"[{request_id}] LangSmith tracing failed: {e}", exc_info=True)
    return _traced_planner(request_id, research_result, validation_result, langsmith_headers)
