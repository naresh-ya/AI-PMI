"""Drafter split stage 3: ASSEMBLER (client-demo2, TERMINAL).

Thin wrapper around drafter_assembler.assemble_document. Loads the plan + sections
artifacts from S3, translates (if requested), formats the .docx, stores it to S3, sets
DRAFTING_COMPLETED in DynamoDB, and returns the canonical drafting_result.

This is the ONLY drafter stage that writes the final document + status + return contract,
identical to what the monolith drafter produced.

Event (from the SF):
    {"request_id": str, "plan_s3_key": str, "sections_s3_key": str}
Returns:
    drafting_result (same shape as the monolith drafter).
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import core.langsmith_tracing.ssl_bootstrap  # must precede langsmith
from core.drafter_common import logger, load_draft_artifact

try:
    import drafter_assembler as assembler          # Lambda package root
except ImportError:                                # local / dev
    from agents.master_drafter import drafter_assembler as assembler

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers, attach_outgoing_langsmith_headers, tracing_context
    )
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False


@traceable(name="draft_assembler_stage", run_type="chain")
def _traced_assembler(request_id, sections_content, document_structure, research_result, validation_result, langsmith_headers=None):
    logger.info(f"[{request_id}] STAGE draft_assembler start")
    return assembler.assemble_document(
        sections_content,
        document_structure,
        research_result,
        validation_result,
        request_id,
        langsmith_headers=langsmith_headers,
    )


def lambda_handler(event, context):
    request_id = str(event.get('request_id') or 'unknown')
    plan = load_draft_artifact(event.get('plan_s3_key'))
    sections = load_draft_artifact(event.get('sections_s3_key'))
    langsmith_headers = event.get('langsmith_headers', {})

    if LANGSMITH_AVAILABLE:
        try:
            incoming = get_incoming_langsmith_headers(event)
            with tracing_context(parent=incoming):
                result = _traced_assembler(
                    request_id,
                    sections['document_content'],
                    plan['document_structure'],
                    plan['research_result'],
                    plan['validation_result'],
                    langsmith_headers,
                )
            from langsmith import get_current_run_tree
            run_tree = get_current_run_tree()
            attach_outgoing_langsmith_headers(result, run_tree)
            return result
        except Exception as e:
            logger.warning(f"[{request_id}] LangSmith tracing failed: {e}", exc_info=True)
    return _traced_assembler(
        request_id,
        sections['document_content'],
        plan['document_structure'],
        plan['research_result'],
        plan['validation_result'],
        langsmith_headers,
    )
