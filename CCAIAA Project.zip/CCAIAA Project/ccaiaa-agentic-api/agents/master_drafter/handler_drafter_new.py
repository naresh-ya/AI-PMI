"""
Master Drafting Agent for PMI Agentic AI Platform

This agent generates comprehensive government submission documents based on 
research findings and compliance requirements.

Responsibilities:
- Analyze research findings and synthesize key insights
- Generate document structure and outline
- Create comprehensive draft content with proper citations
- Ensure compliance with regulatory requirements
- Format document according to government submission standards
"""

import json
import logging
import re
from typing import Dict, Any, List
from datetime import datetime
import boto3
import urllib3

# Suppress insecure request warnings for the internal LiteLLM proxy
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import ssl

# LangSmith bootstrap (must precede langsmith imports)
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import core.langsmith_tracing.ssl_bootstrap  # noqa: E402

# Prompt is now loaded dynamically from core.prompt_registry
from docx import Document
from docx.shared import Inches, Pt
import io
import base64

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

import os

import urllib.request
import ssl
import json
import os

# Set LiteLLM API Configurations
LITELLM_URL = os.environ.get('AWS_LITELLM_ENDPOINT', 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions')
# Honor either AWS_LITELLM_MODEL (drafter-specific) or LITELLM_MODEL (shared env that
# Lambda sets to the stronger Sonnet inference profile). Falls back to Haiku only if
# neither is configured. This keeps drafting quality on par with the researcher.
LITELLM_MODEL = (
    os.environ.get('LLM_MODEL_DEFAULT')
    or os.environ.get('AWS_LITELLM_MODEL')
    or os.environ.get('LITELLM_MODEL')
    or 'bedrock/us.anthropic.claude-sonnet-4-6'
)
# Per-task tiering: Opus for critic/critical loops, Sonnet (above) for the rest, Haiku for cheap tasks.
LLM_MODEL_REASONING = os.environ.get('LLM_MODEL_REASONING', 'bedrock/us.anthropic.claude-opus-4-8')
LLM_MODEL_FAST = os.environ.get('LLM_MODEL_FAST', 'bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0')
LITELLM_KEY = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
requests_table = dynamodb.Table(os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests'))
DOCUMENT_BUCKET = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')

# LangSmith tracing setup (fail-open)
try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers, attach_outgoing_langsmith_headers, tracing_context
    )
    from core.langsmith_tracing.llm_usage import record_llm_usage
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False
    def record_llm_usage(*args, **kwargs):
        pass

# ── Token-budget observability ────────────────────────────────────────────────
# These are heuristic, dependency-free safeguards (NOT tiktoken — the models here are
# Claude/Bedrock with non-OpenAI tokenizers, so a chars/4 estimate is the honest
# approximation).
#
#  • Preflight  : warn if the combined input (system + user) prompt approaches a soft
#                 budget. Input overflow is the LESS likely failure (the models carry a
#                 ~200K context window and the gateway errors on true overflow rather than
#                 silently dropping prompt text) — this is pure observability.
#  • Postflight : the REAL silent-truncation risk. If the model stops because it hit
#                 max_tokens, the OUTPUT is cut mid-thought and nothing downstream knows.
#                 We detect that, log a WARN with the section + request_id, and surface it
#                 so assemble_document can raise review_required.
PROMPT_SOFT_BUDGET_TOKENS = int(os.environ.get('PROMPT_SOFT_BUDGET_TOKENS', '150000'))

# Default document tone when neither the request nor the researcher framing supplies one.
# Single source of truth so tone never regresses to divergent hardcoded literals.
DEFAULT_TONE = "formal, neutral, compliance-first, fact-based and non-promotional"

# ── Grounding / citation-integrity helpers ────────────────────────────────────
# Markers the researcher uses to flag evidence it could NOT find in the provided sources.
_CITATION_GAP_MARKERS = ('[insufficient information]', '[citation to external source]')


def _extract_data_gaps(synthesis: Dict[str, Any]) -> List[str]:
    """Return the synthesis findings the researcher explicitly flagged as unavailable in the
    provided sources. The drafter surfaces these to the LLM as 'DO NOT FABRICATE' guardrails."""
    if not isinstance(synthesis, dict):
        return []
    pool: List[str] = []
    for k in ('key_findings', 'policy_insights', 'recommendations'):
        pool.extend(synthesis.get(k, []) or [])
    return [f for f in pool if isinstance(f, str)
            and any(m in f.lower() for m in (mm.lower() for mm in _CITATION_GAP_MARKERS))]


def _strip_researcher_source_markers(text: str) -> str:
    """C1 — remove the researcher's inline [Source: N] / (Source: N) numbering from evidence
    text BEFORE it is injected into a drafting prompt. The researcher numbers sources in its
    own order; if the LLM copies those numbers they collide with the drafter's single canonical
    [N] registry (the root cause of body↔reference misalignment). Stripping forces the LLM to
    cite ONLY from the registry. Leaves [insufficient information]/[citation to external source]
    gap tags intact (they reinforce the no-fabrication instruction)."""
    if not text:
        return text
    import re as _re
    text = _re.sub(r'\[\s*sources?\s*:?\s*(?:\d+\s*,\s*)*\d+\s*\]', '', text, flags=_re.IGNORECASE)
    text = _re.sub(r'\(\s*sources?\s*:?\s*(?:\d+\s*,\s*)*\d+\s*\)', '', text, flags=_re.IGNORECASE)
    text = _re.sub(r'[ \t]{2,}', ' ', text)
    text = _re.sub(r'\s+([.,;:])', r'\1', text)
    return text.strip()


def _build_data_gaps_block(gaps: List[str]) -> str:
    """Render the anti-fabrication guardrail block (empty string when there are no gaps)."""
    if not gaps:
        return ""
    return (
        "\n## DATA GAPS — DO NOT FABRICATE (CRITICAL)\n"
        "The research explicitly flagged the following as NOT available in the provided sources:\n"
        + "\n".join(f"- {g}" for g in gaps[:12]) + "\n"
        "You are FORBIDDEN from inventing statistics, percentages, study names, dates, or named "
        "authorities to fill these gaps. If a point needs such data and it is not in the evidence "
        "above, omit it or stay conceptual — never attach an invented figure to a [N] marker.\n"
    )


def _estimate_tokens(text: str) -> int:
    """Rough, model-agnostic token estimate (~4 chars/token). For logging only — not exact."""
    if not text:
        return 0
    return len(text) // 4


def _preflight_prompt_budget(system_prompt: str, user_prompt: str, label: str,
                             request_id: str = 'unknown') -> int:
    """Log a WARN if the combined input prompt approaches the soft token budget.
    Returns the estimated input token count."""
    est = _estimate_tokens(system_prompt) + _estimate_tokens(user_prompt)
    if est >= PROMPT_SOFT_BUDGET_TOKENS:
        logger.warning(
            f"[{request_id}] TOKEN_PREFLIGHT | label='{label}' | est_input_tokens=~{est} "
            f">= soft_budget={PROMPT_SOFT_BUDGET_TOKENS} | input prompt is large; consider "
            f"trimming injected context (KB / template / jurisdiction / web blocks)."
        )
    else:
        logger.info(f"[{request_id}] TOKEN_PREFLIGHT | label='{label}' | est_input_tokens=~{est}")
    return est


def _check_response_truncation(res: Dict[str, Any], label: str, request_id: str = 'unknown') -> bool:
    """Postflight: detect OUTPUT truncation from the LiteLLM / OpenAI-compatible response.
    Logs a WARN when the model stopped because it hit max_tokens. Returns True if truncated."""
    try:
        finish_reason = None
        choices = res.get('choices') or []
        if choices and isinstance(choices[0], dict):
            finish_reason = choices[0].get('finish_reason')
        # Some gateways also surface Anthropic's native stop_reason field.
        native_stop = res.get('stop_reason')
        truncated = (finish_reason == 'length') or (native_stop in ('max_tokens', 'length'))
        if truncated:
            logger.warning(
                f"[{request_id}] TOKEN_POSTFLIGHT | label='{label}' | OUTPUT TRUNCATED "
                f"(finish_reason={finish_reason!r}, stop_reason={native_stop!r}) — content is "
                f"incomplete (hit max_tokens). Raise max_tokens for this path or split the section."
            )
        return truncated
    except Exception as e:
        logger.warning(f"[{request_id}] TOKEN_POSTFLIGHT | label='{label}' | truncation check failed: {e}")
        return False

# ── Template and Jurisdiction context loading ─────────────────────────────────
# Templates define section structure per category.
# Jurisdiction files provide regulatory ground truth per country.
# Both are loaded from the templates/ folder bundled with the Lambda code.

_TEMPLATE_CACHE: Dict[str, str] = {}
_JURISDICTION_CACHE: Dict[str, str] = {}

# Max characters of jurisdiction ground-truth injected into any LLM prompt.
# Sized to fit the largest jurisdiction file in full (~6.5k chars) so the
# compliance-critical tail sections (APPROVED TERMINOLOGY / AVOID / statistics)
# are never truncated. Kept identical to the researcher for consistency.
JURISDICTION_CTX_MAX = 8000

# Category → template filename mapping
_CATEGORY_TEMPLATE_MAP = {
    "Official PMI Submission": "official-pmi-submission.md",
    "Third Party Submission":  "third-party-submission.md",
    "White Papers":            "white-papers.md",
    "Internal Communications": "internal-communications.md",
    "Media Releases":          "media-releases.md",
    "Narrative Builder":       "narrative-builder.md",
}


def _find_templates_dir() -> str:
    """Locate the bundled 'templates' directory across environments.

    Handles both layouts:
      - AWS Lambda: handler.py at package root, templates/ copied alongside it
        (deploy_lambdas.py 'includes') → <handler_dir>/templates
      - Local dev: handler at agents/master_drafter/, templates at repo root
        → <handler_dir>/../../templates

    Returns the first existing candidate, or '' if none found.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, 'templates'),                      # Lambda package root
        os.path.join(here, os.pardir, 'templates'),           # one level up
        os.path.join(here, os.pardir, os.pardir, 'templates'),  # repo root (local dev)
    ]
    for cand in candidates:
        norm = os.path.normpath(cand)
        if os.path.isdir(norm):
            return norm
    return ''


def _load_template(category: str) -> str:
    """Load the section template for a category. Cached after first load.

    With PROMPT_MGMT_ENABLED=true, resolves from Bedrock Prompt Management first
    (fail-open to local disk if Bedrock is unreachable or missing).
    """
    if category in _TEMPLATE_CACHE:
        return _TEMPLATE_CACHE[category]

    filename = _CATEGORY_TEMPLATE_MAP.get(category, '')
    if not filename:
        logger.warning(f"No template mapping for category '{category}'")
        return ''

    # ── Phase 2: Try Bedrock Prompt Management first ─────────────────────────
    try:
        try:
            from core import bedrock_prompt_client as _bpc
        except ImportError:
            import bedrock_prompt_client as _bpc
        if _bpc.is_enabled():
            import re as _re
            slug = _re.sub(r"[^a-zA-Z0-9]+", "-", category.strip().lower()).strip("-")
            bedrock_name = f"ccaiaa-template-{slug}"
            text = _bpc.get_prompt_text(bedrock_name)
            if text:
                _TEMPLATE_CACHE[category] = text
                logger.info(f"TEMPLATE_LOADED | source=bedrock | name={bedrock_name} | chars={len(text)}")
                return text
            else:
                logger.info(f"TEMPLATE_LOADED | bedrock miss for '{bedrock_name}', falling back to disk")
    except Exception as e:
        logger.warning(f"TEMPLATE_LOADED | bedrock error ({e}), falling back to disk")

    # ── Fallback: local disk read (original behavior) ────────────────────────
    templates_dir = _find_templates_dir()
    local_path = os.path.join(templates_dir, filename) if templates_dir else ''

    if local_path and os.path.exists(local_path):
        with open(local_path, 'r', encoding='utf-8') as f:
            content = f.read()
        _TEMPLATE_CACHE[category] = content
        logger.info(f"TEMPLATE_LOADED | source=disk | category={category} | file={filename} | chars={len(content)}")
        return content

    logger.warning(f"Template not found locally for '{category}' (file={filename})")
    _TEMPLATE_CACHE[category] = ''
    return ''


def _load_jurisdiction_file(jurisdiction: str) -> str:
    """Load the jurisdiction ground truth file. Cached after first load.

    With PROMPT_MGMT_ENABLED=true, resolves from Bedrock Prompt Management first
    (fail-open to local disk if Bedrock is unreachable or missing).
    """
    if jurisdiction in _JURISDICTION_CACHE:
        return _JURISDICTION_CACHE[jurisdiction]

    # Normalize jurisdiction name to filename
    jur_lower = (jurisdiction or '').strip().lower().replace(' ', '_')
    filename = f"{jur_lower}.md"

    # ── Phase 2: Try Bedrock Prompt Management first ─────────────────────────
    try:
        try:
            from core import bedrock_prompt_client as _bpc
        except ImportError:
            import bedrock_prompt_client as _bpc
        if _bpc.is_enabled():
            bedrock_name = f"ccaiaa-jurisdiction-{jur_lower}"
            text = _bpc.get_prompt_text(bedrock_name)
            if text:
                _JURISDICTION_CACHE[jurisdiction] = text
                logger.info(f"JURISDICTION_LOADED | source=bedrock | name={bedrock_name} | chars={len(text)}")
                return text
            else:
                logger.info(f"JURISDICTION_LOADED | bedrock miss for '{bedrock_name}', falling back to disk")
    except Exception as e:
        logger.warning(f"JURISDICTION_LOADED | bedrock error ({e}), falling back to disk")

    # ── Fallback: local disk read (original behavior) ────────────────────────
    templates_dir = _find_templates_dir()
    local_path = os.path.join(templates_dir, 'jurisdiction', filename) if templates_dir else ''

    if local_path and os.path.exists(local_path):
        with open(local_path, 'r', encoding='utf-8') as f:
            content = f.read()
        _JURISDICTION_CACHE[jurisdiction] = content
        logger.info(f"JURISDICTION_LOADED | source=disk | jurisdiction={jurisdiction} | file={filename} | chars={len(content)}")
        return content

    logger.info(f"No jurisdiction file found locally for '{jurisdiction}' (file={filename})")
    _JURISDICTION_CACHE[jurisdiction] = ''
    return ''


# Hardcoded PMI "About Us" boilerplate. Financial/market figures sourced from the
# PMI 2025 Fourth-Quarter & Full-Year earnings release (dated February 6, 2026);
# corporate-profile facts (headcount, manufacturing footprint, Forbes recognition)
# sourced from the PMI website. Used verbatim for all "Introduction to PMI" / "About PMI"
# sections to prevent LLM hallucination of corporate facts. Update this constant when
# newer figures are published.
_PMI_ABOUT_US = (
    "Philip Morris International (PMI) is the world's largest publicly traded international tobacco "
    "company, headquartered in Stamford, Connecticut, United States, and listed on the New York Stock "
    "Exchange (NYSE: PM). With approximately 84,900 employees representing 133 nationalities, PMI "
    "operates in 180 markets worldwide through 50 manufacturing facilities, of which 21 are dedicated "
    "to the production of smoke-free products. PMI is undergoing the most significant transformation "
    "in the history of the tobacco industry: a deliberate and systematic pivot away from combustible "
    "cigarettes toward a future built on science-based smoke-free alternatives. In full-year 2025, PMI's "
    "total net revenues surpassed USD 40 billion, of which the smoke-free business generated USD 16.9 billion, "
    "representing 41.5% of total net revenues. PMI's smoke-free products are available for sale in over 105 "
    "markets, and as of December 31, 2025 were used by over 43 million adult consumers worldwide, many of "
    "whom have moved away from cigarettes or significantly reduced their consumption. The company has "
    "invested more than USD 16 billion since 2008 in the research, development, scientific "
    "substantiation, manufacturing, and commercialization of these innovative alternatives to cigarettes. "
    "PMI has also been recognized for its sustainability leadership, ranked by Forbes among the world's "
    "top Net Zero leaders, placing first in the fast-moving consumer goods category."
)


# ═══════════════════════════════════════════════════════════════════════════════
# Drafter split (client-demo2): plan -> generate -> assemble
# ───────────────────────────────────────────────────────────────────────────────
# Three shared stage functions used by BOTH the monolith lambda_handler and the three
# split stage lambdas (handler_draft_planner/generator/assembler). Additive: the monolith
# still works unchanged. Section generation stays SEQUENTIAL inside generate_document so the
# anti-duplication "already covered" ledger is preserved. Only the terminal assemble stage
# writes the .docx to S3, sets DRAFTING_COMPLETED, and returns the canonical result.
# ═══════════════════════════════════════════════════════════════════════════════

def _unwrap_drafter_inputs(event: Dict[str, Any]):
    """Normalize the drafter event into (request_id, research_result, validation_result),
    unwrapping Step Function ResultSelector ('output') and API Gateway ('body') envelopes.
    Shared by the monolith and the split planner so both accept identical inputs."""
    request_id = event.get('request_id')
    research_result = event.get('research_result', {}) or {}
    validation_result = event.get('validation_result', {}) or {}

    if isinstance(research_result, dict) and 'output' in research_result:
        research_result = research_result['output']
    if isinstance(validation_result, dict) and 'output' in validation_result:
        validation_result = validation_result['output']

    if isinstance(validation_result, dict) and 'body' in validation_result:
        body = validation_result['body']
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except Exception:
                pass
        validation_result = body
    if isinstance(research_result, dict) and 'body' in research_result:
        body = research_result['body']
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except Exception:
                pass
        research_result = body

    if not request_id:
        request_id = (event.get('request_id')
                      or (validation_result.get('request_id') if isinstance(validation_result, dict) else None)
                      or (research_result.get('request_id') if isinstance(research_result, dict) else None))
    return str(request_id or 'unknown'), research_result, validation_result


def _draft_artifact_key(request_id: str, name: str) -> str:
    return f"draft_artifacts/{request_id}/{name}.json"


def save_draft_artifact(request_id: str, name: str, obj: Dict[str, Any]) -> str:
    """Persist an inter-stage hand-off artifact to S3 (keeps Step Functions state tiny)."""
    key = _draft_artifact_key(request_id, name)
    s3.put_object(
        Bucket=DOCUMENT_BUCKET, Key=key,
        Body=json.dumps(obj, default=str).encode('utf-8'),
        ContentType='application/json',
    )
    logger.info(f"[{request_id}] draft artifact saved -> {key}")
    return key


def load_draft_artifact(s3_key: str) -> Dict[str, Any]:
    resp = s3.get_object(Bucket=DOCUMENT_BUCKET, Key=s3_key)
    return json.loads(resp['Body'].read())


def plan_document(research_result: Dict[str, Any], validation_result: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Stage 1 — load research data (S3) + build the document structure.
    Returns {'research_data', 'document_structure'}. Pure (no S3/DDB writes)."""
    research_data = load_research_data(research_result.get('research_s3_key'))
    # LLM-driven outline (reads template + jurisdiction + research + intent); falls back to
    # the deterministic structure builder on any failure or when no template is mapped.
    document_structure = (
        build_document_structure_llm(validation_result, research_result, research_data, request_id)
        or create_document_structure(validation_result, research_result)
    )
    logger.info(f"[{request_id}] PLAN | sections={len(document_structure.get('sections', []))}")
    # Advisory sufficiency assessment — informs review_required downstream; never blocks.
    document_structure['_sufficiency'] = assess_research_sufficiency(
        research_result, research_data, document_structure, request_id
    )
    return {'research_data': research_data, 'document_structure': document_structure}


def generate_document(document_structure: Dict[str, Any], research_data: Dict[str, Any],
                      validation_result: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """Stage 2 — generate document content (sequential section generation + internal
    review/dedup, or single-call letter). Returns document_content."""
    document_content = generate_document_content(document_structure, research_data, validation_result, request_id)
    logger.info(f"[{request_id}] GENERATE | sections={len(document_content.get('sections', {}))}")
    return document_content


def assemble_document(document_content: Dict[str, Any], document_structure: Dict[str, Any],
                      research_result: Dict[str, Any], validation_result: Dict[str, Any],
                      request_id: str) -> Dict[str, Any]:
    """Stage 3 (TERMINAL) — translate (if requested) + format .docx + store to S3 +
    set DRAFTING_COMPLETED + return the canonical drafting_result. Owns the contract."""
    document_metadata = validation_result.get('document_metadata', {})
    document_requirements = validation_result.get('document_requirements', {})
    target_language = document_requirements.get('target_language', 'English')

    translated_sections = None
    translated_title = None
    if target_language and target_language.lower() not in ['english', 'en', '']:
        if document_content.get('translated_sections') and document_content.get('translated_title'):
            logger.info("Using parallel translated sections from document content.")
            translated_sections = document_content.get('translated_sections')
            translated_title = document_content.get('translated_title')
        else:
            logger.info(f"Translating document into {target_language} sequentially...")
            try:
                translated_title = translate_text_with_llm(document_content.get('title', ''), target_language)
                translated_sections = {}
                for key, section_data in document_content.get('sections', {}).items():
                    translated_sections[key] = {
                        'title': translate_text_with_llm(section_data['title'], target_language),
                        'content': translate_text_with_llm(section_data['content'], target_language),
                    }
            except Exception as e:
                logger.error(f"Failed to translate document to {target_language}: {str(e)}")
                translated_sections = None
                translated_title = None

    formatted_document = create_formatted_document(
        document_content,
        document_structure,
        research_result.get('citations', []),
        document_metadata,
        translated_sections=translated_sections,
        translated_title=translated_title,
    )

    document_requirements = validation_result.get('document_requirements', {})
    category = document_requirements.get('category', 'unknown_category')

    document_s3_key = store_document(request_id, formatted_document, document_content, category)

    # ── Quality metrics (deterministic Python) + non-blocking LLM judge ───────
    quality = compute_quality_metrics(document_content, document_structure, research_result)
    judge = llm_judge_document(document_content, validation_result, research_result)
    truncated_sections = document_content.get('_truncation_events', []) or []
    _groundedness = judge.get('dimensions', {}).get('groundedness', 100)
    _unsupported = judge.get('unsupported_claims', []) or []
    _citation_issues = judge.get('citation_issues', []) or []
    _sufficiency = (document_structure or {}).get('_sufficiency', {}) or {}
    _insufficient = _sufficiency.get('verdict') == 'insufficient'
    review_required = bool(
        judge.get('verdict') == 'revise'
        or judge.get('dimensions', {}).get('stance_ok') is False
        or (isinstance(_groundedness, (int, float)) and _groundedness < 70)
        or _unsupported
        or _citation_issues
        or _insufficient
        or quality['structure_completeness'] < 80
        or truncated_sections
    )
    if _insufficient:
        logger.warning(
            f"[{request_id}] SUFFICIENCY | research insufficient (score={_sufficiency.get('score')}) "
            f"| reasons={_sufficiency.get('reasons')} — draft flagged for review."
        )
    if _unsupported or _citation_issues:
        logger.warning(
            f"[{request_id}] GROUNDING | groundedness={_groundedness} "
            f"| unsupported={len(_unsupported)} | citation_issues={len(_citation_issues)} "
            f"| examples={(_unsupported + _citation_issues)[:3]}"
        )
    if truncated_sections:
        logger.warning(
            f"[{request_id}] REVIEW_REQUIRED | output truncation in section(s): {truncated_sections} "
            f"— document may be incomplete."
        )
    logger.info(
        f"[{request_id}] QUALITY | structure={quality['structure_completeness']}% "
        f"| confidence={quality['confidence_score']} "
        f"| flesch={quality['readability']['flesch_reading_ease']} "
        f"| judge={judge.get('score', 'n/a')}/{judge.get('verdict', 'n/a')} "
        f"| groundedness={_groundedness} "
        f"| truncated={len(truncated_sections)} "
        f"| review_required={review_required}"
    )

    drafting_result = {
        "status": "success",
        "request_id": request_id,
        "document_metadata": {
            "word_count": calculate_word_count(document_content),
            "sections": len(document_structure.get('sections', [])),
            "citations": len(research_result.get('citations', [])),
            "confidence_score": quality['confidence_score'],
            "drafting_duration": "30 minutes"
        },
        "document_s3_key": document_s3_key,
        "document_summary": {
            "title": document_content.get('title', ''),
            "executive_summary": document_content.get('sections', {}).get('executive_summary', {}).get('content', '')[:200] + '...',
            "key_recommendations": document_content.get('key_recommendations', []),
            "compliance_status": "All requirements met"
        },
        "next_agent": "master_reviewer",
        "quality_metrics": {
            "structure_completeness": quality['structure_completeness'],
            "sections_filled": quality['sections_filled'],
            "sections_planned": quality['sections_planned'],
            "readability_score": quality['readability']['flesch_reading_ease'],
            "readability": quality['readability'],
            "confidence_score": quality['confidence_score'],
            "llm_judge": judge,
            "review_required": review_required,
            "truncated_sections": truncated_sections,
            "groundedness": _groundedness,
            "unsupported_claims": _unsupported,
            "citation_issues": _citation_issues,
            "research_sufficiency": _sufficiency,
        }
    }

    update_request_status(request_id, 'DRAFTING_COMPLETED', 'Document draft completed successfully', document_s3_key)
    logger.info(f"Document drafting completed successfully for request {request_id}")
    return drafting_result


@traceable(name="monolith_drafter", run_type="chain")
def _traced_drafter(request_id, research_result, validation_result):
    logger.info(f"Starting document drafting for request: {request_id}")
    update_request_status(request_id, 'DRAFTING_IN_PROGRESS', 'Document drafting initiated')
    
    # Stage 1 — plan (research load + structure)
    plan = plan_document(research_result, validation_result, request_id)
    
    # Stage 2 — generate (sequential sections + internal review/dedup)
    document_content = generate_document(
        plan['document_structure'], plan['research_data'], validation_result, request_id
    )
    
    # Stage 3 — assemble (translate + format + store + status + return)
    return assemble_document(
        document_content, plan['document_structure'], research_result, validation_result, request_id
    )


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for Master Drafting Agent
    
    Args:
        event: Contains research results and validation data
        context: Lambda context object
        
    Returns:
        Drafting result with generated document and metadata
    """
    
    try:
        request_id, research_result, validation_result = _unwrap_drafter_inputs(event)
        
        if LANGSMITH_AVAILABLE:
            try:
                incoming = get_incoming_langsmith_headers(event)
                with tracing_context(parent=incoming):
                    result = _traced_drafter(request_id, research_result, validation_result)
                from langsmith import get_current_run_tree
                run_tree = get_current_run_tree()
                attach_outgoing_langsmith_headers(result, run_tree)
                return result
            except Exception as e:
                logger.warning(f"[{request_id}] LangSmith tracing failed: {e}", exc_info=True)
        
        return _traced_drafter(request_id, research_result, validation_result)

    except Exception as e:
        logger.error(f"Error in document drafting: {str(e)}")
        request_id = event.get('request_id', 'unknown')
        update_request_status(request_id, 'DRAFTING_FAILED', f'Drafting failed: {str(e)}')
        
        raise e


def load_research_data(research_s3_key: str) -> Dict[str, Any]:
    """Load research data from S3"""
    
    if not research_s3_key:
        raise ValueError("No research S3 key provided.")
    
    try:
        import os
        bucket_name = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')
        response = s3.get_object(Bucket=bucket_name, Key=research_s3_key)
        research_data = json.loads(response['Body'].read())
        
        return research_data
        
    except Exception as e:
        logger.error(f"Error loading research data: {str(e)}")
        raise


def _is_letter_submission(category: str, use_case: str = '') -> bool:
    """Return True when the request is a letter/submission scenario."""
    cat_lower = (category or '').lower()
    return 'submission' in cat_lower or 'letter' in cat_lower


def _build_web_search_context(all_sources: List[Dict[str, Any]], category: str, use_case: str) -> str:
    """
    Format Tavily web search results into a structured context block for the drafter prompt.
    Label and framing are tailored per category/use_case so the LLM integrates them correctly.
    Returns an empty string when no web sources are present.
    """
    web_sources = [s for s in (all_sources or []) if s.get('type') == 'web_search']
    if not web_sources:
        return ''

    cat_lower = (category or '').lower()
    uc_lower  = (use_case or '').lower()

    if 'letter' in cat_lower or 'letter' in uc_lower:
        label = "Recent regulatory news and government notifications relevant to the letter subject:"
    elif 'media' in cat_lower:
        label = "Recent industry news and policy announcements to support media release claims:"
    elif 'internal' in cat_lower:
        label = "Latest regulatory updates and news for internal briefing context:"
    elif 'narrative' in cat_lower:
        label = "Recent regulatory and policy developments for preparation context:"
    elif 'advocacy' in uc_lower or 'white paper' in cat_lower:
        label = "Recent scientific and regulatory publications to strengthen advocacy arguments:"
    else:
        label = "Current regulatory landscape and recent policy developments from web research:"

    lines = [label]
    # Category-aware source limit
    cat_lower_check = (category or '').lower()
    limit = 12 if ('white paper' in cat_lower_check or 'narrative' in cat_lower_check) else 7
    for src in web_sources[:limit]:
        title   = src.get('title', 'Web Source')
        summary = (src.get('summary', '') or '')[:500].strip()
        url     = src.get('url', '')
        line    = f"- {title}: {summary}"
        if url:
            line += f" [Source: {url}]"
        lines.append(line)

    return '\n'.join(lines)


def create_document_structure(validation_result: Dict[str, Any], research_result: Dict[str, Any]) -> Dict[str, Any]:
    """Create document structure based on requirements and research findings"""

    document_requirements = validation_result.get('document_requirements', {})
    document_type = document_requirements.get('document_type', '')
    category  = document_requirements.get('category', '')
    use_case  = document_requirements.get('use_case', '')

    base = {
        'document_type': document_type,
        'citation_style': 'APA',
    }

    cat_lower = str(category).lower()
    uc_lower = str(use_case).lower()

    # ── 1. Letters Category (Clean Letter presentation) ──────
    if _is_letter_submission(category, use_case) or 'letter' in cat_lower or 'letter' in uc_lower:
        base['title'] = f"Formal Correspondence"
        base['total_word_target'] = 800
        base['sections'] = [
            {'name': 'Address Block', 'description': 'Addressed To and CC lines', 'word_target': 100, 'required': True},
            {'name': 'Subject Line', 'description': 'Subject of the letter', 'word_target': 50, 'required': True},
            {'name': 'Letter Body', 'description': '4-5 paragraphs addressing the query', 'word_target': 600, 'required': True},
            {'name': 'Greetings', 'description': 'Ending greetings and signature', 'word_target': 50, 'required': True}
        ]
        return base

    # ── 2. White Papers ────────────────
    if 'white paper' in cat_lower or 'advocacy' in uc_lower:
        base['title'] = f"{document_requirements.get('topic', 'Topic Brief')}"
        base['total_word_target'] = 2600
        base['sections'] = [
            {'name': 'Executive Summary', 'description': 'High-level synthesis', 'word_target': 300, 'required': True},
            {'name': 'Introduction to PMI', 'description': 'Standard organizational context', 'word_target': 250, 'required': True},
            {'name': 'Introduction to the Topic', 'description': 'Topic introductory definitions', 'word_target': 300, 'required': True},
            {'name': 'Core Concepts', 'description': 'Products description, scientific evidence, global precedents (3-4 pages)', 'word_target': 1200, 'required': True},
            {'name': 'Conclusion', 'description': 'Final summary and recommendations', 'word_target': 350, 'required': True},
        ]
        # Add Annexures section only if user provided annexure content
        annexure_content = document_requirements.get('annexure', '').strip()
        if annexure_content:
            base['sections'].append(
                {'name': 'Annexures', 'description': annexure_content, 'word_target': 200, 'required': True}
            )
        return base

    # ── 3. Internal Communications Category ────────────────
    if 'internal' in cat_lower:
        base['title'] = f"Internal Briefing"
        base['total_word_target'] = 1000
        if 'business update' in uc_lower:
            base['sections'] = [
                {'name': 'Greetings', 'description': 'Internal Greetings', 'word_target': 50, 'required': True},
                {'name': 'Here are the key updates for the month', 'description': 'Key Monthly Updates (NO other subheadings inside)', 'word_target': 700, 'required': True},
                {'name': 'Summary', 'description': 'Takeaway summary', 'word_target': 250, 'required': True}
            ]
        elif 'regulation' in uc_lower:
            base['sections'] = [
                {'name': 'Greetings', 'description': 'Internal Greetings', 'word_target': 50, 'required': True},
                {'name': 'Introduction of the Topic', 'description': 'Introduction to regulation change', 'word_target': 200, 'required': True},
                {'name': 'Please find below an analysis', 'description': '4-5 bullet points analysis of the regulation (NO other subheadings inside)', 'word_target': 500, 'required': True},
                {'name': 'Summary', 'description': 'Conclusion summary', 'word_target': 250, 'required': True}
            ]
        else: # Parliamentary updates & Others
            base['sections'] = [
                {'name': 'Greetings', 'description': 'Internal Greetings', 'word_target': 50, 'required': True},
                {'name': 'Here are the key updates', 'description': 'Factual bullet points and details of the update (NO other subheadings inside). Cover all key changes, dates, and implications.', 'word_target': 600, 'required': True},
                {'name': 'Summary', 'description': 'Brief 2-3 sentence takeaway for leadership. Do NOT repeat the details above — only the key implications.', 'word_target': 150, 'required': True}
            ]
        return base

    # ── 4. Media Releases Category ────────────────────────
    if 'media' in cat_lower:
        base['title'] = f"{document_requirements.get('topic', 'Media Release')}"
        base['total_word_target'] = 1500
        base['sections'] = [
            {'name': 'Place and date', 'description': 'Location and date dateline', 'word_target': 30, 'required': True},
            {'name': 'Introduction of the topic', 'description': 'Core announcement context', 'word_target': 250, 'required': True},
            {'name': 'Expansion of the topic', 'description': '5-6 factual expansion paragraphs', 'word_target': 900, 'required': True},
            {'name': 'Conclusion', 'description': 'Concluding remarks', 'word_target': 200, 'required': True},
            {'name': 'About PMI', 'description': 'Standard organizational overview (NO other subheadings inside)', 'word_target': 150, 'required': True}
        ]
        return base

    # ── 5. Narrative Builder Category ───────────────
    if 'narrative builder' in cat_lower or 'narrative' in cat_lower:
        base['title'] = f"{document_requirements.get('use_case', 'Preparation Note').upper()}: {document_requirements.get('topic', 'Briefing')}"
        base['total_word_target'] = 1200
        base['sections'] = [
            {'name': 'Title Heading', 'description': 'Clean heading at the top', 'word_target': 50, 'required': True},
            {'name': 'Preparation Brief', 'description': 'Plain-text structured talking points and preparation Q&As based on user prompt', 'word_target': 1150, 'required': True}
        ]
        return base

    # ── 6. Narrative Builder Category (meeting/engagement narrative — NOT a submission) ──
    if 'narrative' in cat_lower:
        topic = document_requirements.get('topic', 'Engagement')
        use_case = document_requirements.get('use_case', '')
        base['title'] = f"{use_case}: {topic}" if use_case else f"{topic}"
        base['total_word_target'] = 1300
        base['sections'] = [
            {'name': 'Title Heading', 'description': 'A single clean title reflecting the engagement and topic. No metadata table. Do NOT use "Submission on... Consultation" phrasing.', 'word_target': 50, 'required': True},
            {'name': 'Context & Objective', 'description': 'Why this engagement is happening and what PMI wants to achieve. Anchor explicitly to the user query/purpose. State the purpose once here only.', 'word_target': 150, 'required': True},
            {'name': 'Key Messages', 'description': '4-6 distinct, concise talking points the spokesperson should land. Each point must be unique — do NOT restate the same fact across points. Frame around the engagement, not as a literature review.', 'word_target': 500, 'required': True},
            {'name': 'Supporting Facts & Evidence', 'description': 'The specific data, legislation, and citations behind the talking points. Put each fact here ONCE; key messages reference them rather than repeating them.', 'word_target': 300, 'required': True},
            {'name': 'Anticipated Questions & Suggested Responses', 'description': "3-5 likely questions with brief, factual suggested responses. MANDATORY FORMAT: write each item as a bold numbered question line '**Q1. <question>**' on its OWN line, then the answer as plain prose on the next line, and a BLANK LINE between each Q&A pair. Never run questions together; never write bare questions without the 'Qn.' prefix.", 'word_target': 250, 'required': True},
        ]
        # Optional sensitivities block only if user provided annexure/sensitivity content
        sensitivities = document_requirements.get('annexure', '').strip()
        if sensitivities:
            base['sections'].append(
                {'name': 'Sensitivities / Do-Not-Say', 'description': f'Topics to avoid or handle carefully; compliance boundaries. {sensitivities}', 'word_target': 100, 'required': False}
            )
        return base

    # ── Default report structure fallback ───────────────────────────────────────
    base['title'] = f"Submission on {document_requirements.get('target_audience', 'Government Authority')} Consultation"
    base['total_word_target'] = 2500
    base['sections'] = [
        {'name': 'Executive Summary',            'description': 'High-level synthesis of the position and key recommendations. This is the ONLY section that recaps the whole document. State headline figures here; do not re-explain detail covered later.', 'word_target': 300, 'required': True},
        {'name': 'Background and Context',        'description': 'Regulatory and market context ONLY — the current landscape, frameworks, and why this matters. Do NOT state PMI\'s position or present scientific evidence here (those have their own sections).', 'word_target': 400, 'required': True},
        {'name': 'PMI Position and Rationale',    'description': 'A clear, explicit statement of PMI\'s position and the reasoning for it. Do NOT repeat the background landscape or list the scientific evidence — argue the position and reference evidence briefly.', 'word_target': 600, 'required': True},
        {'name': 'Evidence Base',                 'description': 'The scientific and regulatory evidence supporting the position — studies, data, precedents. Introduce each piece of evidence ONCE here. Do not restate the position statement.', 'word_target': 700, 'required': True},
        {'name': 'Policy Recommendations',        'description': 'Specific, actionable recommendations only. Do NOT re-argue the rationale or re-present evidence — list and justify the asks concisely.', 'word_target': 500, 'required': True},
        {'name': 'Implementation Considerations', 'description': 'Practical implementation aspects only (timing, feasibility, safeguards). New material not covered above.', 'word_target': 300, 'required': False},
        {'name': 'Conclusion',                    'description': 'Brief synthesis and call to action. Reference earlier points by summary; do NOT restate full data, evidence, or recommendation rationale.', 'word_target': 200, 'required': True},
    ]
    base['appendices'] = ['Scientific Evidence Summary', 'Regulatory Precedents', 'Economic Impact Analysis']
    return base


def build_document_structure_llm(validation_result: Dict[str, Any], research_result: Dict[str, Any],
                                 research_data: Dict[str, Any], request_id: str = '') -> Dict[str, Any]:
    """LLM-driven document planner (Planner stage).

    Reads the category template outline, jurisdiction ground truth, user intent and the
    retrieved research, and proposes a TAILORED section outline. Returns a structure dict in
    the SAME shape as create_document_structure ({title, sections:[{name,description,word_target}],
    total_word_target, document_type, category}), or None on any failure so the caller falls
    back to the deterministic planner. Runs ONE LLM call; never raises."""
    if not LITELLM_KEY:
        return None
    dr = validation_result.get('document_requirements', {}) or {}
    category = dr.get('category', '')
    template_text = _load_template(category)
    if not template_text:
        return None  # no outline to anchor on → deterministic planner is safer

    jurisdiction = dr.get('jurisdiction', '')
    jur_ctx = (_load_jurisdiction_file(jurisdiction) or '')[:JURISDICTION_CTX_MAX]
    synthesis = (research_data or {}).get('synthesis', {}) or {}
    kf = synthesis.get('key_findings', []) or research_result.get('key_findings', []) or []
    pi = synthesis.get('policy_insights', []) or research_result.get('policy_insights', []) or []
    rc = synthesis.get('recommendations', []) or research_result.get('recommendations', []) or []
    framing = (research_result.get('research_metadata', {}) or {}).get('research_framing', {}) or {}

    def _snip(lst, n=8):
        return "\n".join(f"- {str(x)[:160]}" for x in (lst or [])[:n]) or "- (none)"

    system_prompt = (
        "You are a senior PMI corporate-affairs document architect. Given a category template "
        "outline and the available research, design the clearest, most persuasive and well-ordered "
        "section outline for THIS specific document — comparable in quality to a top management "
        "consultant's deliverable. Favour a logical narrative arc (context → evidence → "
        "implications → recommendations), self-descriptive section names, and a structure the "
        "target audience can scan. Only include sections the available evidence can actually "
        "support. Return ONLY a JSON object."
    )
    user_prompt = f"""Category: {category}
Document type: {dr.get('document_type', '')}
Topic: {dr.get('topic', '')}
Jurisdiction: {jurisdiction}
Target audience: {dr.get('target_audience', '')}
Author intent / stance: {framing.get('intent', '')} | {framing.get('stance', '')}
Required tone: {framing.get('tone') or dr.get('tone_requirements') or DEFAULT_TONE}
Background: {(dr.get('background', '') or '')[:600]}

CATEGORY TEMPLATE OUTLINE (use as the basis; you may adapt, rename or merge sections to fit the
intent and the available evidence, but stay within this document type's conventions):
{template_text[:3000]}

JURISDICTION CONTEXT (authoritative facts to respect):
{jur_ctx}

AVAILABLE RESEARCH EVIDENCE:
Key findings:
{_snip(kf)}
Policy insights:
{_snip(pi)}
Recommendations:
{_snip(rc)}

Design the outline. Return ONLY this JSON:
{{"title": "document title",
  "sections": [
    {{"name": "Section name", "description": "what this section must cover and which evidence to emphasise (1-2 sentences)", "word_target": 350}}
  ]}}
Rules:
- 4 to 8 sections, ordered as a logical narrative arc (context → evidence → implications → recommendations) appropriate to the category.
- Anchor to the template outline and the user's intent; adapt/rename/merge sections to fit the topic and evidence; include only sections the evidence/purpose supports.
- Section names must be specific and self-descriptive (e.g. "International Regulatory Precedents", not "Section 3"); avoid generic or duplicated names.
- Each description must state what the section covers AND which of the available findings/insights it should draw on, so each section has a distinct, non-overlapping scope.
- Do NOT add a References/Bibliography section (added automatically); do NOT add a metadata/Document-Information section.
- word_target between 150 and 600 per section, proportional to how much evidence supports it."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        data = {
            "model": LLM_MODEL_REASONING,   # Opus — document planning/outline is high-stakes reasoning
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
            "max_tokens": 1500,
            "temperature": 0.2,
        }
        headers = {"Authorization": f"Bearer {LITELLM_KEY}", "Content-Type": "application/json"}
        req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            raw_response = resp.read().decode('utf-8')
            res = json.loads(raw_response)
            if LANGSMITH_AVAILABLE:
                try:
                    record_llm_usage(res, 'monolith_drafter_structure', raw_response)
                except Exception:
                    pass
            raw = res['choices'][0]['message']['content'].strip()
        import re as _re
        m = _re.search(r'\{[\s\S]*\}', raw)
        plan = json.loads(m.group(0) if m else raw)

        norm_sections = []
        for s in (plan.get('sections') or []):
            name = (s.get('name') or '').strip()
            if not name:
                continue
            try:
                wt = int(s.get('word_target', 350))
            except Exception:
                wt = 350
            norm_sections.append({
                'name': name,
                'description': (s.get('description') or '').strip(),
                'word_target': max(150, min(600, wt)),
            })
        if len(norm_sections) < 2:
            return None

        structure = {
            'title': (plan.get('title') or dr.get('topic') or 'Document').strip(),
            'sections': norm_sections,
            'total_word_target': sum(s['word_target'] for s in norm_sections),
            'document_type': dr.get('document_type', ''),
            'category': category,
        }
        logger.info(f"[{request_id}] LLM_PLANNER | {len(norm_sections)} sections: {[s['name'] for s in norm_sections]}")
        return structure
    except Exception as e:
        logger.warning(f"[{request_id}] LLM_PLANNER failed (non-fatal, using deterministic structure): {e}")
        return None


def assess_research_sufficiency(research_result: Dict[str, Any], research_data: Dict[str, Any],
                                document_structure: Dict[str, Any], request_id: str = '') -> Dict[str, Any]:
    """Advisory, fail-open research-sufficiency assessment (deterministic).

    Returns {'verdict': 'sufficient'|'insufficient', 'score', 'reasons':[...], 'gap_queries':[...]}.
    NEVER raises and defaults to 'sufficient', so it can NEVER block drafting. For now it only
    informs `review_required` (so a thin-research draft is flagged for review) and documents the
    gaps; the bounded re-research loop that acts on 'insufficient' is a later phase. Requires
    2+ corroborating signals before declaring 'insufficient' to avoid false alarms."""
    try:
        rr = research_result or {}
        rs = rr.get('research_summary', {}) or {}
        synthesis = (research_data or {}).get('synthesis', {}) or {}
        citations = rr.get('citations', []) or (research_data or {}).get('formatted_citations', []) or []
        relevant = rr.get('relevant_source_count', rs.get('relevant_sources', None))
        low_relevance = bool(rr.get('low_relevance') or rs.get('low_relevance'))
        gaps = _extract_data_gaps(synthesis)
        n_sections = len(document_structure.get('sections', []) or [])
        n_citations = len(_canonical_citations(citations))

        reasons = []
        if low_relevance:
            reasons.append('researcher flagged low_relevance')
        if relevant is not None and int(relevant or 0) <= 1:
            reasons.append(f'only {relevant} topic-relevant source(s)')
        if n_citations <= max(2, n_sections // 3):
            reasons.append(f'{n_citations} usable citation(s) for {n_sections} planned sections')
        if len(gaps) >= 2:
            reasons.append(f'{len(gaps)} research-flagged evidence gap(s)')

        insufficient = len(reasons) >= 2
        verdict = 'insufficient' if insufficient else 'sufficient'
        score = max(0, 100 - 25 * len(reasons))
        logger.info(f"[{request_id}] SUFFICIENCY | verdict={verdict} | score={score} | reasons={reasons}")
        return {'verdict': verdict, 'score': score, 'reasons': reasons, 'gap_queries': gaps[:8]}
    except Exception as e:
        logger.warning(f"[{request_id}] SUFFICIENCY assessment failed (fail-open=sufficient): {e}")
        return {'verdict': 'sufficient', 'score': 100, 'reasons': [], 'gap_queries': []}


def clean_citation_title(title: str) -> str:
    """Strip raw S3 prefixes, SharePoint suffixes, and file extensions from citation titles."""
    if not title:
        return "Reference Document"
    import re
    # Remove file extensions
    cleaned = re.sub(r'\.(docx|pdf|xlsx|xls|json|txt|doc|db|zip|csv|pptx|ppt)', '', title, flags=re.IGNORECASE)
    # Normalize separators to spaces first so glued digit-run suffixes become detectable
    cleaned = cleaned.replace('_', ' ').replace('-', ' ')
    # Remove raw date/hash suffixes (e.g. 150202024, 103025)
    cleaned = re.sub(r'\b\d{6,10}\b', '', cleaned)
    # Remove parenthetical counts or random hashes
    cleaned = re.sub(r'\(\d+\)', '', cleaned)
    # Clean multiple spaces
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    # Title-case all-lowercase or all-uppercase titles for a tidy reference list
    if cleaned and (cleaned.islower() or cleaned.isupper()):
        cleaned = cleaned.title()

    # C2: internal engine/test artifacts (date-prefixed dumps, "CA Engine", "vNN") are not
    # client-facing citations — relabel to a clean generic rather than exposing the raw name.
    _artifact = (
        re.match(r'^\s*\d{4}[\s\-_]\d{2}[\s\-_]\d{2}\b', title or '')
        or re.search(r'\bca engine\b', cleaned, re.IGNORECASE)
        or re.search(r'\bv\d{1,3}\b', cleaned, re.IGNORECASE)
    )
    if _artifact:
        return "PMI Internal Knowledge Base"

    return cleaned if cleaned else "Reference Document"


def validate_section_draft(section_name: str, section_content: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validates the generated section draft against strict professional standards.
    """
    passed = True
    feedback_items = []
    content_lower = section_content.lower()

    # Rule 1: Header Repeating check (Only permitted in DOCUMENT TITLE & HEADER / section 1)
    # Note: If the document type is a report, Section 1 is title & header, which is printed in the info table or header.
    # We should ensure that section body text does not repeat "Product Advocacy Brief", Date, Subject, etc.
    if "title" not in section_name.lower() and "header" not in section_name.lower():
        forbidden_headers = ["product advocacy brief:", "recipient:", "subject:", "date:"]
        for header in forbidden_headers:
            if header in content_lower:
                passed = False
                feedback_items.append(f"Contains forbidden metadata header/label: '{header}'. Remove all title blocks, Dates, Recipients, and Subjects.")

    # Rule 2: Statistics Leakage check (Only permitted in Executive Summary, Background, or Conclusion)
    if ("executive summary" not in section_name.lower() 
        and "background" not in section_name.lower()
        and "conclusion" not in section_name.lower()):
        findings = context.get('key_findings', [])
        for chunk in findings:
            pcts = re.findall(r'\b\d+(?:\.\d+)?%', chunk)
            for pct in pcts:
                if pct in section_content:
                    passed = False
                    feedback_items.append(f"Contains repeated raw statistic '{pct}' from findings. You are forbidden from repeating raw figures outside Section 2. Replace with a conceptual reference.")

    # Rule 3: Citation Integrity check — detect raw filenames/S3 artifacts and system noise.
    # Generic: any file extension, raw long digit-run suffixes (e.g. "...150202024"),
    # placeholder/markdown artifacts, and LLM refusal phrases.
    import re as _re3
    if _re3.search(r'\.(docx|pdf|xlsx?|pptx?|json|txt|doc|db|zip|csv)\b', content_lower):
        passed = False
        feedback_items.append("Contains a raw filename/extension (e.g. .docx/.pdf). Remove it and refer to the source by its clean title or an inline [N] marker.")
    if _re3.search(r'\b\w+\s+\d{6,}\b', section_content):
        passed = False
        feedback_items.append("Contains a raw database/SharePoint filename suffix (long digit run). Remove it and use the clean source title or an inline [N] marker.")
    leakage_indicators = [
        "[insert", "[todo", "[placeholder", "[tbd", "[add ",
        "[insufficient information", "[citation to external source",
        "as an ai", "i cannot", "i'm sorry",
    ]
    for leak in leakage_indicators:
        if leak in content_lower:
            passed = False
            feedback_items.append(f"Contains system artifact or placeholder '{leak}' in text. Remove it and rewrite with proper formal content.")

    # Rule 4: Promotional language check
    promotional_words = [
        'revolutionary', 'breakthrough', 'superior', 'best-in-class',
        'amazing', 'unmatched', 'pioneering', 'game-changing', 'world-class',
        'cutting-edge', 'industry-leading',
    ]
    for word in promotional_words:
        if word in content_lower:
            passed = False
            feedback_items.append(f"Promotional language detected: '{word}'. Replace with neutral, evidence-based language (e.g. 'evidence suggests', 'data indicates').")

    # Rule 5: Unsupported absolute claim check
    unsupported_triggers = [
        'studies prove', 'it is proven', 'conclusively demonstrates',
        'all experts agree', 'universally accepted', 'undeniably', 'irrefutably',
    ]
    findings_blob = ' '.join(context.get('key_findings', [])).lower()
    for trigger in unsupported_triggers:
        if trigger in content_lower and trigger not in findings_blob:
            passed = False
            feedback_items.append(
                f"Absolute unsupported claim '{trigger}' has no matching support in research findings. "
                f"Soften to 'evidence suggests' or 'research indicates'."
            )

    # Rule 6: Banned terminology and required rephrasing
    banned_phrases = {
        'novel tobacco product':          'smoke-free tobacco product',
        'novel htp':                      'smoke-free HTP',
        'novel heated tobacco':           'smoke-free heated tobacco',
        'referred to as novel':           'referred to as smoke-free',
        'classified as novel':            'classified as smoke-free',
        'without the harmful chemicals':  'with substantially fewer harmful chemicals',
        'without harmful chemicals':      'with substantially fewer harmful chemicals',
        'deliver nicotine without':       'deliver nicotine with substantially fewer harmful chemicals than',
    }
    for phrase, replacement in banned_phrases.items():
        if phrase in content_lower:
            passed = False
            feedback_items.append(
                f"Banned phrase detected: '{phrase}'. "
                f"Rewrite as: '{replacement}'."
            )

    # Rule 7: LLM-based vague citation check
    vague_citations = _llm_check_vague_citations(section_content)
    for phrase in vague_citations:
        passed = False
        feedback_items.append(
            f"Vague or unattributed reference: '{phrase}'. "
            f"Either cite a specific source (name, year, document) or remove the claim entirely."
        )

    # Rule 8: Sentence-level factual accuracy blocklist
    # Checks known wrong factual combinations at the sentence level to avoid false positives
    # (e.g. "China" alone is fine; "China has regulated HTPs" is not).
    _FACTUAL_ERRORS = [
        {
            'trigger':  'china',
            'co_terms': ['regulated', 'approved', 'regulation', 'regulatory framework', 'htp market', 'heat-not-burn market'],
            'message':  (
                "Factual error: China has not regulated the HTP market. "
                "Remove China from any list of countries with HTP regulatory frameworks."
            ),
        },
        {
            'trigger':  'thai fda',
            'co_terms': ['htp', 'heated tobacco', 'heat-not-burn', 'regulat', 'approved', 'authoris'],
            'message':  (
                "Factual error: Thai FDA does not regulate HTPs. "
                "Remove Thai FDA references in the context of HTP regulation or approval."
            ),
        },
        {
            'trigger':  'who',
            'co_terms': ['approved htp', 'endorses htp', 'recommends htp', 'supports htp',
                         'approved heat', 'endorses heat', 'recommends heat'],
            'message':  (
                "Factual error: WHO has not approved or endorsed HTPs. "
                "Do not attribute HTP approval or endorsement to WHO."
            ),
        },
    ]
    sentences = re.split(r'(?<=[.!?])\s+', content_lower)
    reported_rules: set = set()
    for sentence in sentences:
        for rule in _FACTUAL_ERRORS:
            if rule['trigger'] in sentence and rule['message'] not in reported_rules:
                if any(co in sentence for co in rule['co_terms']):
                    passed = False
                    feedback_items.append(rule['message'])
                    reported_rules.add(rule['message'])

    # Rule 9: Per-section reference list detection
    # Reject if the section contains a full references/bibliography list
    # (the document should have ONE references section at the end, not per-section)
    _REFERENCE_SECTION_MARKERS = [
        'references:', 'bibliography:', 'sources:', 'works cited:',
        '[1] ', '[2] ', '[3] ',  # Numbered reference lists within body
    ]
    # Only flag if we see MULTIPLE numbered references in sequence (not just inline [1] markers)
    import re as _re
    numbered_refs = _re.findall(r'^\s*\[\d+\]\s+\w', section_content, _re.MULTILINE)
    if len(numbered_refs) >= 3:
        passed = False
        feedback_items.append(
            "Per-section references list detected (3+ numbered citations listed). "
            "Remove the references list entirely. Use only inline [N] markers in the text. "
            "A combined References section will be added at the end of the document automatically."
        )
    # Also catch explicit section headers for references within body sections
    if "references" not in section_name.lower() and "bibliography" not in section_name.lower():
        for marker in ['references:', 'bibliography:', 'sources:', 'works cited:']:
            if marker in content_lower:
                passed = False
                feedback_items.append(
                    f"Reference section header '{marker}' found in non-reference section. "
                    f"Remove it. Only use inline [N] markers."
                )
                break

    return {
        "passed": passed,
        "feedback": "; ".join(feedback_items) if feedback_items else "Passed validation."
    }


def _llm_check_vague_citations(section_content: str) -> List[str]:
    """
    Ask the LLM to identify vague or unattributed references in a section draft.
    Returns a list of exact offending phrases. Falls back silently to [] on any failure.
    """
    if not LITELLM_KEY or not section_content.strip():
        return []

    prompt = (
        "You are a citation compliance checker for regulatory and government submissions.\n\n"
        "Review the text below and identify any vague or unattributed references — "
        "phrases that make a claim without citing a specific source, document name, year, or authority.\n\n"
        "Flag phrases like:\n"
        "- 'a recent independent study', 'studies show', 'research suggests' (no source named)\n"
        "- 'according to experts', 'international studies indicate', 'evidence suggests' (no source)\n"
        "- 'ASEAN trade agreements' (no specific agreement name or year)\n"
        "- 'regulatory frameworks in several countries' (countries not named)\n"
        "- 'it has been shown that', 'widely recognised', 'globally acknowledged'\n\n"
        "Do NOT flag references that name a specific source, for example:\n"
        "- 'WHO FCTC Article 6 (2003)' — specific\n"
        "- 'FDA PMTA guidance (2020)' — specific\n"
        "- 'a 2023 study published in the Lancet' — specific enough\n\n"
        f"Text to review:\n{section_content[:2500]}\n\n"
        "Output ONLY a JSON array of the exact vague phrases found, as they appear in the text. "
        "Return an empty array [] if none are found. No explanation.\n"
        'Example: ["a recent independent study", "ASEAN trade agreements", "research suggests"]'
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300,
            "temperature": 0.1,   # citation QA — deterministic detection, keep low
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            result = json.loads(raw)
            if isinstance(result, list):
                return [str(p) for p in result if p]
    except Exception as e:
        logger.warning(f"LLM vague citation check failed (non-fatal): {e}")

    return []


def clean_section_header(section_name: str, content: str) -> str:
    """
    Cleans section content by:
    - Stripping the section name or header blocks from the top if the LLM repeated it.
    - Resolving date placeholders like [Current Date] with the dynamically formatted date.
    """
    if not content:
        return ""
        
    lines = content.split('\n')
    
    # Strip leading empty lines
    while lines and not lines[0].strip():
        lines.pop(0)
        
    # Check if first 1-3 lines contain the section name (case-insensitive) or markdown headers
    # and strip them if they match.
    name_clean = section_name.strip().lower()
    for _ in range(min(3, len(lines))):
        if not lines:
            break
        first_line = lines[0].strip().lower()
        # Remove common markdown symbols like # or **
        first_line_clean = first_line.replace('#', '').replace('*', '').replace(':', '').strip()
        
        if first_line_clean == name_clean or first_line_clean in name_clean or name_clean in first_line_clean:
            lines.pop(0)
            # Remove any trailing empty line immediately following the stripped header
            if lines and not lines[0].strip():
                lines.pop(0)
        else:
            break
            
    cleaned_content = '\n'.join(lines).strip()
    
    # Resolve date placeholders programmatically
    from datetime import datetime
    current_date = datetime.now().strftime("%B %d, %Y")
    placeholders = ["[Current Date]", "[current date]", "[Date]", "[date]"]
    for placeholder in placeholders:
        cleaned_content = cleaned_content.replace(placeholder, current_date)

    # Strip markdown bold (**text**) — convert to plain text for Word output
    import re as _re
    cleaned_content = _re.sub(r'\*\*([^*]+)\*\*', r'\1', cleaned_content)
    # Strip remaining stray ** that didn't close properly
    cleaned_content = cleaned_content.replace('**', '')
    # Strip markdown headers (# , ## , ### )
    cleaned_content = _re.sub(r'^#{1,4}\s+', '', cleaned_content, flags=_re.MULTILINE)

    return cleaned_content


def _extract_section_template_rule(template_text: str, section_name: str) -> str:
    """Return ONLY the template block that matches `section_name`.

    The category templates enumerate the entire document (Purpose + every section's
    spec). Injecting the whole template into each per-section LLM call caused the model
    to regenerate the full document under each section (root cause of cross-section
    duplication). This slices out just the numbered block for the section being drafted.

    Returns '' when there is no confident match, in which case the caller relies on the
    outline's own section description rather than leaking sibling-section specs.
    """
    import re

    if not template_text or not section_name:
        return ''

    # Capture numbered blocks like:
    #   "1. **Section Name** (~300 words)\n   - bullet\n   - bullet"
    # up to the next numbered block, the next ## / ### heading, or end of text.
    pattern = re.compile(
        r'^\s*\d+\.\s*\*\*(?P<head>.+?)\*\*(?P<body>.*?)'
        r'(?=^\s*\d+\.\s*\*\*|^\s*#{2,3}\s|\Z)',
        re.MULTILINE | re.DOTALL,
    )

    target = section_name.strip().lower()
    target_words = {w for w in re.split(r'[^a-z0-9]+', target) if len(w) > 2}

    best = ''
    best_score = 0.0
    for m in pattern.finditer(template_text):
        head = m.group('head').strip().lower()
        # Strong match: one name contains the other (e.g. outline "Key Messages"
        # vs template "Key Messages / Talking Points").
        if target and (target in head or head in target):
            return m.group(0).strip()
        head_words = {w for w in re.split(r'[^a-z0-9]+', head) if len(w) > 2}
        if target_words and head_words:
            overlap = len(target_words & head_words) / len(target_words)
            if overlap > best_score:
                best_score = overlap
                best = m.group(0).strip()

    # Require meaningful overlap to avoid returning the wrong block.
    return best if best_score >= 0.5 else ''


def _dedup_repeated_sentences(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Fact-level de-duplication: strip near-verbatim sentences that already appeared
    in an earlier section.

    The per-section `already_covered` ledger reduces gross duplication but the same fact
    still recurs across Context / Key Messages / Supporting Facts. This deterministic pass
    removes sentences in later sections that are ≥0.8 token-Jaccard similar to a sentence
    already kept earlier. It is conservative (near-verbatim only) and EXEMPTS sections
    where restatement is legitimate (Q&A answers, conclusion/summary, structural/about),
    so it never strips a self-contained answer or a deliberate recap.
    """
    import re

    sections = document_content.get('sections', {})
    if len(sections) <= 1:
        return document_content

    # Sections that should keep their content intact (restatement is expected there).
    EXEMPT_MARKERS = (
        'anticipated', 'question', 'q&a', 'conclusion', 'summary',
        'greeting', 'about pmi', 'about philip', 'references', 'title', 'place and date',
    )

    def _fingerprint(sentence: str) -> set:
        return {w for w in re.split(r'[^a-z0-9]+', sentence.lower()) if len(w) > 2}

    seen_fps: List[set] = []
    removed = 0

    for key, sec in sections.items():
        name = (sec.get('title', '') or key).lower()
        exempt = any(m in name for m in EXEMPT_MARKERS)
        content = sec.get('content', '') or ''
        if not content:
            continue

        sentences = re.split(r'(?<=[.!?])\s+', content)
        kept = []
        for sent in sentences:
            fp = _fingerprint(sent)
            is_dup = False
            if not exempt and len(fp) >= 5:
                for prev in seen_fps:
                    if not prev:
                        continue
                    inter = len(fp & prev)
                    union = len(fp | prev) or 1
                    if inter / union >= 0.8:
                        is_dup = True
                        break
            if is_dup:
                removed += 1
                continue
            kept.append(sent)
            if len(fp) >= 5:
                seen_fps.append(fp)

        new_content = ' '.join(kept).strip()
        if new_content:  # never blank out a section
            sec['content'] = new_content
            sec['word_count'] = len(new_content.split())

    if removed:
        logger.info(f"FACT_DEDUP | removed {removed} near-duplicate sentence(s) across sections")
        document_content.setdefault('metadata', {})['duplicate_sentences_removed'] = removed

    return document_content


def _reconcile_citations(document_content: Dict[str, Any], num_valid: int) -> Dict[str, Any]:
    """Normalize and validate inline citation markers across all sections.

    Fixes the marker drift that produced [N/A], [Supplementary web findings], and orphan
    numbers (e.g. [6] when only 5 references exist):
      - Normalize [Source: N] / [Sources: N] / [source N] -> [N]
      - Strip non-resolving textual markers ([N/A], [Supplementary web findings],
        [citation needed], [TBD], [Source: web], etc.)
      - Drop numeric markers out of range (< 1 or > num_valid) — these have no matching
        reference entry, so leaving them would dangle.

    Non-destructive to facts: only citation markers are touched, never the surrounding
    claim text. Flags via metadata when markers were changed so review can catch it.
    """
    import re

    sections = document_content.get('sections', {})
    if not sections:
        return document_content

    stripped_total = 0
    normalized_total = 0

    # Junk / unresolved textual markers to remove outright.
    junk_pattern = re.compile(
        r'\[\s*(?:n/?a|supplementary[^\]]*|citation needed|tbd|source\s*:?\s*(?:web|n/?a|tbd)'
        r'|ref(?:erence)?\s*:?\s*(?:n/?a|tbd))\s*\]',
        re.IGNORECASE,
    )
    # [Source: N], [Sources: N, M], [source N] -> capture the numbers
    source_word_pattern = re.compile(
        r'\[\s*sources?\s*:?\s*((?:\d+\s*,\s*)*\d+)\s*\]', re.IGNORECASE
    )
    # Parenthesized variants the letter path can emit: (Source: N), (Sources: N, M), (source N)
    source_paren_pattern = re.compile(
        r'\(\s*sources?\s*:?\s*((?:\d+\s*,\s*)*\d+)\s*\)', re.IGNORECASE
    )

    def _filter_numbers(num_csv: str) -> str:
        """Keep only in-range citation numbers from a comma list; return '' if none."""
        nums = [n.strip() for n in num_csv.split(',') if n.strip().isdigit()]
        valid = [n for n in nums if 1 <= int(n) <= num_valid]
        return ', '.join(valid)

    for key, sec in sections.items():
        content = sec.get('content', '') or ''
        if not content:
            continue
        original = content

        # 1) Remove junk textual markers
        content, n_junk = junk_pattern.subn('', content)
        stripped_total += n_junk

        # 2) Normalize [Source: N] style -> [N] (dropping out-of-range numbers)
        def _src_repl(m):
            kept = _filter_numbers(m.group(1))
            return f"[{kept}]" if kept else ''
        content, n_src = source_word_pattern.subn(_src_repl, content)
        normalized_total += n_src

        # 2b) Normalize parenthesized (Source: N) -> [N] (the letter path emits this form)
        content, n_paren = source_paren_pattern.subn(_src_repl, content)
        normalized_total += n_paren

        # 3) Drop bare numeric markers that are out of range (orphans like [6] of 5).
        #    Only touch markers that are purely numeric/comma so we never disturb prose.
        def _bare_repl(m):
            kept = _filter_numbers(m.group(1))
            return f"[{kept}]" if kept else ''
        content = re.sub(r'\[\s*((?:\d+\s*,\s*)*\d+)\s*\]', _bare_repl, content)

        # Tidy doubled spaces / space-before-punctuation left by removals
        content = re.sub(r'[ \t]{2,}', ' ', content)
        content = re.sub(r'\s+([.,;:])', r'\1', content)

        if content != original:
            sec['content'] = content.strip()
            sec['word_count'] = len(content.split())

    if stripped_total or normalized_total:
        logger.info(
            f"CITATION_RECONCILE | normalized_source_markers={normalized_total} "
            f"| stripped_junk_markers={stripped_total} | valid_refs={num_valid}"
        )
        meta = document_content.setdefault('metadata', {})
        meta['citation_markers_normalized'] = normalized_total
        meta['citation_markers_stripped'] = stripped_total

    return document_content


def _flag_duplicate_sections(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Detect near-duplicate sections (the cross-section bleed symptom) and flag the doc.

    Compares word-set Jaccard similarity between every pair of non-structural sections.
    A high score means a section likely regenerated another section's content. We do not
    auto-delete (risk of data loss) — we surface it via metadata + a critical log so the
    reviewer/HITL stage catches it instead of shipping a duplicated document silently.
    """
    import re

    sections = document_content.get('sections', {})
    if len(sections) <= 1:
        return document_content

    def _word_set(text: str) -> set:
        return {w for w in re.split(r'[^a-z0-9]+', (text or '').lower()) if len(w) > 3}

    keys = list(sections.keys())
    word_sets = {k: _word_set(sections[k].get('content', '')) for k in keys}
    flagged_pairs = []

    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            a, b = word_sets[keys[i]], word_sets[keys[j]]
            if len(a) < 20 or len(b) < 20:
                continue  # too short to judge (titles, datelines, etc.)
            inter = len(a & b)
            union = len(a | b) or 1
            jaccard = inter / union
            if jaccard >= 0.6:
                flagged_pairs.append((keys[i], keys[j], round(jaccard, 2)))

    if flagged_pairs:
        logger.critical(
            "SECTION_DUPLICATION_DETECTED | likely cross-section bleed — review required | "
            + "; ".join(f"{a}~{b}={s}" for a, b, s in flagged_pairs)
        )
        meta = document_content.setdefault('metadata', {})
        meta['duplicate_sections_detected'] = True
        meta['duplicate_section_pairs'] = [f"{a}~{b}={s}" for a, b, s in flagged_pairs]

    return document_content


def generate_section_content_react(section: Dict[str, Any], context: Dict[str, Any]) -> str:
    """Generate section content usingLiteLLM and a ReAct self-correction loop (max 3 retries)."""
    section_name = section['name']
    word_target = section.get('word_target', 300)
    
    if section_name.lower().strip() in ['place and date', 'place & date']:
        jurisdiction = context.get('jurisdiction', 'Thailand')
        logger.info(f"Programmatically generating 'Place and date' section for {jurisdiction} to prevent LLM date/place hallucination.")
        return f"{jurisdiction}, {datetime.now().strftime('%B %d, %Y')}"

    _PMI_SECTION_NAMES = {
        'introduction to pmi', 'about pmi', 'about pmi india',
        'about philip morris', 'about philip morris international',
    }
    if section_name.lower().strip() in _PMI_SECTION_NAMES:
        logger.info(f"Programmatically returning PMI About Us boilerplate for section '{section_name}' to prevent hallucination of corporate facts.")
        return _PMI_ABOUT_US
    
    from core.prompt_registry_new import get_agent_prompt, get_jurisdiction_context
    category = context.get('category', '')
    jurisdiction = context.get('jurisdiction', '')
    system_prompt = get_agent_prompt(category, agent="drafter")
    jurisdiction_context = get_jurisdiction_context(jurisdiction)
    
    # ── Findings and Insights Partitioning ──
    sect_lower = section_name.lower()

    # C2: Prefer the per-section evidence slice allocated upstream. Each section
    # receives a DISTINCT, non-overlapping subset of findings/insights/recommendations
    # so the same facts are not handed to every section (the root cause of duplication).
    preallocated = context.get('section_findings_text')
    if preallocated is not None:
        findings_text = preallocated
    else:
        # Fallback partitioning (only used when no allocation was provided).
        filtered_findings = []
        for f in context.get('key_findings', []):
            f_lower = f.lower()
            if "prevalence" in f_lower or "smoking rate" in f_lower or "gdp" in f_lower:
                if "executive summary" in sect_lower or "context" in sect_lower:
                    filtered_findings.append(f)
            else:
                filtered_findings.append(f)

        if "global precedents" in sect_lower or "progressive policies" in sect_lower:
            findings_text = "\n".join(f"- {p}" for p in context.get('policy_insights', []))
        elif "regulatory principles" in sect_lower or "proposed regulatory" in sect_lower:
            findings_text = "\n".join(f"- {r}" for r in context.get('recommendations', []))
        elif "scientific evidence" in sect_lower or "independent reviews" in sect_lower or "core concepts" in sect_lower or "risk continuum" in sect_lower:
            findings_text = "\n".join(f"- {f}" for f in filtered_findings if any(kw in f.lower() for kw in ["toxic", "exposure", "aerosol", "clinical", "scientific", "study", "evidence", "harm", "reduction", "nicotine", "smoke", "combust"]))
            if not findings_text.strip():
                findings_text = "\n".join(f"- {f}" for f in filtered_findings)
        elif "conclusion" in sect_lower or "bibliography" in sect_lower:
            combined_findings = filtered_findings[:3] + context.get('policy_insights', [])[:2] + context.get('recommendations', [])[:2]
            findings_text = "\n".join(f"- {item}" for item in combined_findings)
        else:
            findings_text = "\n".join(f"- {f}" for f in filtered_findings)

    # C1: cite ONLY from the canonical [N] registry — strip the researcher's inline
    # [Source: N] numbering so the LLM cannot copy a conflicting numbering scheme.
    findings_text = _strip_researcher_source_markers(findings_text)

    # Sections that are purely structural — web context adds no value there
    _NO_WEB_SECTIONS = {
        'address block', 'greetings', 'references', 'subject line',
        'place and date', 'title heading', 'letter body',
    }
    web_search_context = context.get('web_search_context', '')
    include_web_context = bool(web_search_context) and sect_lower not in _NO_WEB_SECTIONS

    max_retries = 3
    retry_count = 0
    validation_feedback = ""
    draft_content = ""

    # Load template and jurisdiction ground truth for this request
    template_context = _load_template(category)
    jurisdiction_ground_truth = _load_jurisdiction_file(jurisdiction)

    while retry_count < max_retries:
        section_desc = section.get('description', '')
        user_prompt = f"""
You are drafting a section for a document with the following metadata:
- Topic: {context.get('topic', 'N/A')}
- Background Context: {context.get('background', 'N/A')}
- Target Audience: {context.get('target_audience', 'N/A')}
- Country/Jurisdiction: {jurisdiction}
- Category: {category}
- User Query/Stance: {context.get('user_query', 'N/A')}
- Today's Date: {datetime.now().strftime("%B %d, %Y")}

Local Jurisdiction Context: {jurisdiction_context}
"""
        # Author identity & stance guardrail — keeps the draft in PMI's voice and prevents
        # adopting the audience's voice or arguing against PMI's own position.
        _stance = context.get('stance', '')
        _audience = context.get('audience', '') or context.get('target_audience', '')
        if context.get('author_identity') or _stance or _audience:
            user_prompt += f"""
## AUTHOR IDENTITY & STANCE (CRITICAL — DO NOT VIOLATE)
- You are writing AS {context.get('author_identity', 'PMI')} — this is the author's voice.
- PMI's stance for this document: {_stance or "represent PMI's position consistent with the objective below"}.
- Audience / recipient: {_audience or 'N/A'} — this is who the document is ADDRESSED TO, NOT the author. Never write in the audience's voice (e.g. do NOT speak as the ministry/regulator) and never argue against PMI's own position.
- Document objective: {context.get('objective', '') or context.get('intent', 'N/A')}
"""
        # Inject jurisdiction ground truth file (authoritative regulatory facts)
        if jurisdiction_ground_truth:
            user_prompt += f"""
## JURISDICTION CONTEXT — AUTHORITATIVE (use as primary reference, supplement with research findings but do not contradict)
{jurisdiction_ground_truth[:JURISDICTION_CTX_MAX]}
"""

        # Inject structured facts (exact numbers, legislation, dates from Gemini extraction)
        structured_facts = context.get('structured_facts', '')
        if structured_facts:
            user_prompt += f"""
## VERIFIED FACTS — USE EXACT VALUES (do not approximate, paraphrase, or round numbers)
{structured_facts}
"""

        # Inject ONLY the rule for the section currently being drafted — never the full
        # template. Injecting the entire template (every section's spec) caused each
        # section call to regenerate the whole document. See _extract_section_template_rule.
        if template_context:
            section_rule = _extract_section_template_rule(template_context, section_name)
            if section_rule:
                user_prompt += f"""
## TEMPLATE RULE FOR THIS SECTION ONLY (structural guidance for '{section_name}')
{section_rule}
"""
            user_prompt += f"""
## CRITICAL OUTPUT SCOPE — READ CAREFULLY
You are drafting ONLY the '{section_name}' section. Output the body text of this one
section and nothing else. Do NOT write any other section. Do NOT add section headings,
titles, or a table of contents. Do NOT append a 'Sensitivities' / 'Do-Not-Say' block,
a references list, or Q&A unless THIS section ('{section_name}') is explicitly that
section. Every other section of the document is produced by a separate call.
"""

        user_prompt += f"""
PRIMARY OBJECTIVE — serve the user's actual purpose first:
The single most important goal is to address the User Query/Purpose and Topic above for
the target audience. The research findings are SUPPORTING EVIDENCE — use them to substantiate
points that serve the purpose, not as a list to summarise. If a finding does not serve the
user's purpose for THIS section, leave it out.

Now draft the '{section_name}' section.
Section Description/Instructions: {section_desc}

Supporting evidence (use what is relevant to the purpose; do not invent facts beyond it):
<findings>
{findings_text}
</findings>
"""
        # D1: anti-fabrication guardrail — forbid filling research-flagged gaps with invented specifics.
        user_prompt += _build_data_gaps_block(context.get('data_gaps', []))
        # C1: Inject a ledger of what earlier sections have already covered so this
        # section does not repeat the same facts/arguments. Cross-reference instead.
        already_covered = context.get('already_covered', '')
        if already_covered:
            user_prompt += f"""
## ALREADY COVERED IN EARLIER SECTIONS — DO NOT REPEAT
The following points have already been written in previous sections of THIS document.
Do NOT restate or re-explain them. If you must refer to them, use a brief cross-reference
(e.g. "as noted earlier") and then add only NEW information specific to this section.
<already_covered>
{already_covered}
</already_covered>
"""
        if include_web_context:
            user_prompt += f"""
The following current web research results provide additional regulatory and policy context. Incorporate relevant points to add recency and external credibility. Cite source URLs inline where appropriate.
<web_search_results>
{web_search_context}
</web_search_results>
"""
        # Inject KB source context for comprehensive sections
        kb_context = context.get('kb_sources_context', '')
        _NO_WEB_SECTIONS = {
            'address block', 'greetings', 'references', 'subject line',
            'place and date', 'title heading', 'letter body',
        }
        if kb_context and sect_lower not in _NO_WEB_SECTIONS:
            user_prompt += f"""
## PMI INTERNAL KNOWLEDGE BASE SOURCES (primary reference material)
{kb_context[:6000]}

"""
        user_prompt += f"""
Requirements:
- Lead with the user's purpose/query; use the findings and background context as supporting
  evidence. Supplement with web search results where relevant but do not invent facts not
  present in the provided sources. Use statistics, percentages, study names, dates and named
  authorities ONLY if they appear in the evidence above; never invent jurisdiction outcome data
  or attribute a claim to a source that does not state it.
- Word Target: ~{word_target} words
- Exclude the section title from the output body.
- Maintain a {context.get('tone') or DEFAULT_TONE} tone.
- Adapt all arguments, terminology, and recommendations to the Topic and User Query/Stance. Do not force-fit heated tobacco concepts if the topic is unrelated.

READABILITY & FORMATTING (Markdown — required for clarity):
- Write SHORT paragraphs: 3-5 sentences each, every paragraph expressing ONE distinct idea. Separate paragraphs with a blank line.
- Convert long explanatory passages and any enumeration of items, criteria, or examples into Markdown bullet points using "- " (one idea per bullet).
- For a longer section with multiple themes, organise it under Markdown sub-headings using "## Sub-heading" (do NOT repeat the section's own title). Put EVERY sub-heading on its OWN line, prefixed with "## "; never append a heading phrase to the end of a paragraph.
- Emphasise key terms, figures, legislation names and authorities in **bold**.
- Keep numbered steps/sequences as "1." "2." numbered lists.
- DECIDE ON STRUCTURE (use your judgment — there are NO fixed per-category rules): based on
  THIS section's purpose and the user's intent, choose the clearest presentation. Use a visual
  structure ONLY when it genuinely improves comprehension; otherwise prefer concise prose/bullets.
  * COMPARISON TABLES: whenever this section sets out two or more countries/jurisdictions/products/
    categories against the same dimensions, PREFER a Markdown comparison table — comparison-heavy
    documents (e.g. white papers, advocacy briefs) typically warrant 2+ such tables across the
    document. This is a strong default, NOT a quota: only render a table where a genuine
    multi-item comparison exists. Use a header row + "---" separator row, e.g.:
    | Jurisdiction | Status | Key rule |
    | --- | --- | --- |
    | UK | Permitted | Regulated as consumer product |
    | Canada | Restricted | Federal authorisation required |
  * CALLOUT BOXES: if the section highlights what a single jurisdiction/authority prohibits/allows/
    regulates, render a Markdown blockquote callout whose first line is the title:
    > What the UK allows
    > - Point one
    > - Point two
  Do NOT force a table or callout where plain prose or bullets communicate the point better — you
  decide based on intent.
- Do NOT produce a references/bibliography list here; a combined References section is added at the end automatically.
"""
        # Prevent "About PMI" content from leaking into non-PMI sections
        _PMI_SECTION_NAMES_CHECK = {'introduction to pmi', 'about pmi', 'about pmi india', 'about philip morris', 'about philip morris international'}
        if sect_lower not in _PMI_SECTION_NAMES_CHECK:
            user_prompt += "- CRITICAL: Do NOT include any 'About PMI' organizational overview content in this section. That content belongs ONLY in the dedicated 'About PMI' section at the end of the document.\n"

        # Track B: Inject citation registry and citation rules
        citation_registry = context.get('citation_registry', '')
        if citation_registry:
            user_prompt += f"""
CITATION RULES — MANDATORY:
- When citing a source, use ONLY the inline marker [N] from the numbered source list below.
- Do NOT write full citations in the body (e.g., do NOT write "WHO FCTC (2003)" — write [1] instead).
- Do NOT create a references list or bibliography in this section.
- A single References section will be added at the end of the complete document automatically.

NUMBERED SOURCE LIST (use [N] markers only):
{citation_registry}
"""
        if section_name.lower().strip() not in ['greetings', 'address block', 'subject line']:
            user_prompt += "- CRITICAL DIRECTIVE: Do NOT generate or append any salutations/greetings (such as 'Dear Colleagues,') or sign-offs in this section body. Start writing the actual content immediately.\n"
        # Fixed, reproducible Q&A format for Anticipated Questions / Q&A sections.
        if 'question' in sect_lower or 'q&a' in sect_lower:
            user_prompt += (
                "\n- MANDATORY Q&A FORMAT (follow EXACTLY, every time):\n"
                "  * Write each item as a bold numbered question on its OWN line: '**Q1. <question>**', '**Q2. <question>**', ...\n"
                "  * Put the suggested response as plain prose on the line(s) immediately BELOW the question.\n"
                "  * Insert ONE BLANK LINE between every Q&A pair.\n"
                "  * NEVER run multiple questions together in one paragraph; NEVER write a bare question without the 'Qn.' prefix.\n"
                "  Example:\n"
                "  **Q1. <first question>?**\n"
                "  <answer to the first question>\n\n"
                "  **Q2. <second question>?**\n"
                "  <answer to the second question>\n"
            )
        # Inject strict bibliography ban for White Papers / Product Advocacy conclusion
        is_product_advocacy = 'white paper' in str(category).lower()
        if is_product_advocacy and "conclusion" in sect_lower:
            user_prompt += "\n- CRITICAL DIRECTIVE: Do NOT generate or append any bibliography, references listing, or numbered academic citations list in this section body. Focus solely on summarizing the risks of regulatory delays, bans, and concluding statements.\n"

        if validation_feedback:
            user_prompt += f"\n\nCRITICAL SELF-CORRECTION FEEDBACK FROM PREVIOUS DRAFT:\n{validation_feedback}\nRewrite the draft to fix these issues immediately."

        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            headers = {
                "Authorization": f"Bearer {LITELLM_KEY}",
                "Content-Type": "application/json"
            }
            
            data = {
                "model": LLM_MODEL_REASONING,   # Opus — section content is the core drafting quality
                "system": system_prompt.strip(),
                "messages": [
                    {"role": "user", "content": user_prompt.strip()}
                ],
                "max_tokens": 4096,
                "temperature": 0.3
            }

            _rid = context.get('request_id', 'unknown')
            _preflight_prompt_budget(system_prompt, user_prompt, f"section:{section_name}", _rid)

            req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')
            
            with urllib.request.urlopen(req, context=ctx, timeout=180) as response:
                raw_response = response.read().decode('utf-8')
                res = json.loads(raw_response)
                if LANGSMITH_AVAILABLE:
                    try:
                        record_llm_usage(res, f'monolith_drafter_section_{section_name}', raw_response)
                    except Exception:
                        pass
                if _check_response_truncation(res, f"section:{section_name}", _rid):
                    # Surface to generate_document_content -> document_content -> assemble_document
                    context['_section_truncated'] = True
                draft_content = res['choices'][0]['message']['content'].strip()
                
                # Clean up markdown if any
                if draft_content.startswith('```'):
                    lines = draft_content.split('\n')
                    if len(lines) > 2:
                        draft_content = '\n'.join(lines[1:-1]).strip()
                
                # Run validation check
                validation_res = validate_section_draft(section_name, draft_content, context)
                if validation_res['passed']:
                    logger.info(f"Section '{section_name}' passed compliance validation.")
                    return draft_content
                else:
                    retry_count += 1
                    validation_feedback = validation_res['feedback']
                    logger.warning(f"Section '{section_name}' failed validation (Attempt {retry_count}/{max_retries}). Feedback: {validation_feedback}")
                    
        except Exception as e:
            logger.error(f"Error generating section {section_name} on attempt {retry_count + 1}: {str(e)}")
            retry_count += 1
            validation_feedback = f"Error in LLM call: {str(e)}"
            
    # If all retries failed, return the best (last) generation. If even that is empty
    # (e.g. all attempts errored), return a neutral placeholder rather than an empty
    # string so the document stays coherent and never shows internal error text.
    if draft_content and draft_content.strip():
        logger.critical(f"Drafting: Section '{section_name}' did not pass all compliance checks after {max_retries} attempts. Returning best available draft.")
        return draft_content

    logger.critical(f"Drafting: Section '{section_name}' produced no content after {max_retries} attempts. Returning neutral placeholder.")
    return f"This section could not be generated from the available research for the requested topic."


def draft_single_section_worker(section: Dict[str, Any], context: Dict[str, Any], idx: int, target_language: str) -> Dict[str, Any]:
    """
    Worker task for ThreadPoolExecutor.
    Drafts a single section using ReAct self-correction, and translates it concurrently if needed.
    """
    section_name = section['name']
    logger.info(f"Thread starting for section {idx}: '{section_name}'")
    
    # 1. Draft the section in English
    draft_content = generate_section_content_react(section, context)
    
    # Programmatic cleaning and placeholder resolution
    draft_content = clean_section_header(section_name, draft_content)
    
    # Strip common salutations/greetings if generated in subsequent sections
    if idx > 0:
        greeting_patterns = [
            "dear colleagues,", "dear colleagues", "dear team,", "dear team",
            "dear colleague,", "dear colleague", "dear all,", "dear all"
        ]
        lines = draft_content.split('\n')
        while lines:
            line_strip = lines[0].strip().lower().rstrip(':')
            if any(line_strip.startswith(p) for p in greeting_patterns) or not line_strip:
                lines.pop(0)
            else:
                break
        draft_content = '\n'.join(lines).strip()
    
    # 2. Concurrently translate if requested
    translated_content = None
    translated_title = None
    if target_language and target_language.lower() not in ['english', 'en', '']:
        logger.info(f"Thread translating section {idx}: '{section_name}' into {target_language}")
        try:
            translated_content = translate_text_with_llm(draft_content, target_language)
            translated_title = translate_text_with_llm(section_name, target_language)
            if translated_content:
                translated_content = clean_section_header(translated_title or section_name, translated_content)
                # Guard: reject if translation is truncated (< 30% of source length)
                if len(translated_content) < len(draft_content) * 0.3:
                    logger.warning(f"Translation of section '{section_name}' too short — falling back to English.")
                    translated_content = None
                    translated_title = None
                # Guard: reject if LLM refused instead of translating
                elif any(p in translated_content.lower() for p in ["as an ai", "i cannot", "i'm sorry"]):
                    logger.warning(f"Translation refusal detected in section '{section_name}' — falling back to English.")
                    translated_content = None
                    translated_title = None
        except Exception as e:
            logger.error(f"Thread failed to translate section {idx}: {str(e)}")
            
    return {
        'index': idx,
        'section_name': section_name,
        'section_key': section_name.lower().replace(' ', '_'),
        'content': draft_content,
        'translated_title': translated_title,
        'translated_content': translated_content
    }
def eliminate_document_duplicity(document_content: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Performs a post-generation ReACT refinement pass on the stitched document content 
    to scan for, identify, and eliminate semantic redundancies (specifically repeated 
    introductory explanations of the combustion-nicotine risk continuum) and correct 
    typographical errors (like 'poseBl' -> 'pose a').
    """
    sections = document_content.get('sections', {})
    if not sections or len(sections) <= 1:
        return document_content

    # Check if this is a Letters scenario (where we skip deduplication pass to preserve simple flowing prose structure)
    document_requirements = context.get('document_requirements', {}) if context else {}
    category = document_requirements.get('category', '')
    use_case = document_requirements.get('use_case', '')
    is_letter = 'letter' in (category or '').lower() or 'letter' in (use_case or '').lower()
    
    if is_letter:
        # Skip post-pass deduplication for simple, single-section letters
        return document_content

    # Sections whose EXACT formatting must survive the LLM dedup pass (the rewrite LLM
    # otherwise flattens their structure — e.g. collapsing the "**Q1. ...**" + blank-line
    # Q&A layout into a single run-on paragraph). These are preserved verbatim: never sent
    # to the dedup LLM and never overwritten.
    _PRESERVE_MARKERS = (
        'anticipated', 'question', 'q&a', 'greeting', 'about pmi', 'about philip',
        'references', 'title heading', 'place and date', 'address block', 'subject line',
    )

    def _is_preserved(title: str) -> bool:
        t = (title or '').lower()
        return any(m in t for m in _PRESERVE_MARKERS)

    # Only the dedup-eligible (content) sections go to the LLM; preserved sections are untouched.
    eligible_sections = {
        k: v for k, v in sections.items() if not _is_preserved(v.get('title', ''))
    }
    if len(eligible_sections) <= 1:
        logger.info("DEDUPLICATION_LOOP | <=1 dedup-eligible section after preserving Q&A/structural; skipping.")
        return document_content

    logger.info("DEDUPLICATION_LOOP | Initiating ReACT post-processing critique-and-refinement pass...")

    try:
        # Prepare structured input for the LLM — dedup-eligible sections ONLY.
        input_data = {
            "title": document_content.get('title', ''),
            "sections": {
                k: {
                    "title": v.get('title', ''),
                    "content": v.get('content', '')
                } for k, v in eligible_sections.items()
            }
        }

        # Determine category for category-specific rules
        category = document_requirements.get('category', '')
        cat_lower = (category or '').lower()

        # Build category-specific deduplication rules
        category_rules = ""
        if 'white paper' in cat_lower:
            category_rules = """
CATEGORY: WHITE PAPERS
Specific duplication patterns to eliminate:
1. Scientific explanations of smoke-free products repeated across Introduction to Topic, Core Concepts, and Conclusion
2. Product descriptions (e.g., heated tobacco products, IQOS) appearing in multiple sections
3. Regulatory precedents or global examples (e.g., FDA PMTA, Japan market data) duplicated across sections
4. "About PMI" content leaking into sections other than the dedicated Introduction to PMI section
"""
        elif 'narrative' in cat_lower:
            category_rules = """
CATEGORY: NARRATIVE BUILDER / SELF-CONSUMPTION CONTENT
Specific duplication patterns to eliminate:
1. Talking points or Q&A responses that repeat identical facts or arguments
2. Background context or regulatory updates appearing multiple times in the preparation brief
3. Repeated explanations of policy positions or company stances
"""
        elif 'official' in cat_lower and 'submission' in cat_lower:
            category_rules = """
CATEGORY: OFFICIAL PMI SUBMISSION
Specific duplication patterns to eliminate:
1. Executive summary points repeated verbatim in conclusion
2. Policy recommendations appearing in both Position section and Recommendations section
3. Regulatory context duplicated across Background and Evidence sections
"""
        elif 'third party' in cat_lower and 'submission' in cat_lower:
            category_rules = """
CATEGORY: THIRD PARTY SUBMISSION
Specific duplication patterns to eliminate:
1. Scientific evidence repeated across multiple sections
2. Risk continuum explanations duplicated in introduction and body sections
3. Regulatory precedents mentioned multiple times
"""
        elif 'internal' in cat_lower and 'communication' in cat_lower:
            category_rules = """
CATEGORY: INTERNAL COMMUNICATIONS
Specific duplication patterns to eliminate:
1. Multiple greetings beyond the opening greeting
2. Key updates or business intelligence repeated in summary
3. Regulatory changes mentioned in both main content and summary
"""
        elif 'media' in cat_lower and 'release' in cat_lower:
            category_rules = """
CATEGORY: MEDIA RELEASES
Specific duplication patterns to eliminate:
1. Core announcement repeated in introduction and expansion sections
2. "About PMI" content appearing before the dedicated About section
3. Key messages or quotes duplicated across paragraphs
"""

        system_prompt = f"""
You are an elite editorial refinement agent for regulatory and product advocacy submissions.
Your core task is to critique, refine, and deduplicate a stitched draft of a long report.

Document Category: {category}

{category_rules}

UNIVERSAL DEDUPLICATION RULES (apply to all categories):
1. The explanation of the "combustion vs. nicotine risk continuum" is often repeated as an introduction across multiple sections (e.g. Executive Summary, Core Concepts, Scientific Evidence, Conclusion).
2. Country-specific statistics (e.g. Japan's 35% decline in sales, Bangladesh's 20 million smokers) may be repeated identically in sections other than the Executive Summary / local context.
3. Multiple greetings or salutations: Ensure there is only ONE greeting at the very beginning of the document and NO greetings or salutations in any subsequent sections.
4. Any argument or policy recommendation that appears in more than one section must be kept in the most relevant section only and replaced elsewhere with a one-line cross-reference (e.g. "As detailed in [Section Name]...").
5. Any statistic, study citation, or product description that is repeated verbatim or near-verbatim across sections must be deduplicated — retain in the first or most appropriate section and remove from all others.

YOUR EDITING INSTRUCTIONS:
- Identify all instances of semantic duplication (both category-specific and universal patterns).
- Consolidate: Keep the detailed explanation in the most appropriate section and replace subsequent repetitions with short, clean transition sentences that maintain the argument flow without duplicating the details.
- Typo/Spacing Clean Up: Actively scan for and correct formatting typos, such as changing 'poseBl' to 'pose a', stripping weird spacing control characters, or trailing junk characters.
- Strict Constraints:
  * Do NOT delete unique factual details, clinical data, or policy principles. Only eliminate duplicate conceptual paragraphs/phrases.
  * The structure, keys, and titles of the sections MUST remain exactly identical to the input.
  * You MUST output ONLY a valid, parseable JSON object matching the input structure, with no markdown wrappers or introductory conversational text.
"""

        user_prompt = f"""
Stitched Report Draft for Critique and Refinement:
<draft>
{json.dumps(input_data, indent=2)}
</draft>

Please apply your editing instructions and return the deduplicated, refined sections as a single, valid JSON object matching this schema:
{{
  "sections": {{
    "section_key": {{
      "title": "Section Title",
      "content": "Refined and deduplicated section content..."
    }}
  }}
}}
"""

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": LITELLM_MODEL,
            "system": system_prompt.strip(),
            "messages": [
                {"role": "user", "content": user_prompt.strip()}
            ],
            "max_tokens": 8192,
            "temperature": 0.2
        }
        
        req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')
        
        with urllib.request.urlopen(req, context=ctx, timeout=180) as response:
            raw_response = response.read().decode('utf-8')
            res = json.loads(raw_response)
            if LANGSMITH_AVAILABLE:
                try:
                    record_llm_usage(res, 'monolith_drafter_dedup', raw_response)
                except Exception:
                    pass
            refined_response_raw = res['choices'][0]['message']['content'].strip()
            
            # Extract JSON if markdown wrapper was generated despite instructions
            if refined_response_raw.startswith('```'):
                lines = refined_response_raw.split('\n')
                if len(lines) > 2:
                    if lines[0].startswith('```json') or lines[0].startswith('```'):
                        refined_response_raw = '\n'.join(lines[1:-1]).strip()
            
            try:
                refined_data = json.loads(refined_response_raw)
            except Exception as parse_err:
                # Light repair: drop trailing commas, then retry once before giving up.
                logger.warning(f"DEDUPLICATION_LOOP | JSON parse failed ({parse_err}); attempting repair.")
                import re as _re_dedup
                repaired = _re_dedup.sub(r',\s*([}\]])', r'\1', refined_response_raw)
                try:
                    refined_data = json.loads(repaired)
                    logger.info("DEDUPLICATION_LOOP | JSON recovered after repair.")
                except Exception as e2:
                    logger.critical(
                        f"DEDUPLICATION_LOOP | Failed to parse refined JSON after repair. "
                        f"Returning UN-deduplicated content — manual review required: {e2}"
                    )
                    refined_data = None
                    document_content.setdefault('metadata', {})['dedup_status'] = 'failed_parse_review_required'

            if refined_data is not None:
                refined_sections = refined_data.get('sections', {})
                if refined_sections:
                    for k, v in refined_sections.items():
                        if k in document_content['sections']:
                            new_content = (v.get('content', '') or '').strip()
                            # Safety: never let the dedup pass blank out a section
                            if new_content:
                                document_content['sections'][k]['content'] = new_content
                                document_content['sections'][k]['word_count'] = len(new_content.split())
                                logger.info(f"DEDUPLICATION_LOOP | Section '{k}' successfully refined and deduplicated.")

                    # Clear parallel translated sections if they exist, so that lambda_handler
                    # re-translates the finalized, deduplicated English sections sequentially
                    if 'translated_sections' in document_content:
                        del document_content['translated_sections']
                    if 'translated_title' in document_content:
                        del document_content['translated_title']
                
    except Exception as e:
        logger.critical(f"DEDUPLICATION_LOOP | Error in ReACT refinement loop — review required: {str(e)}")
        document_content.setdefault('metadata', {})['dedup_status'] = 'error_review_required'

    return document_content


_STRUCTURAL_SECTION_NAMES = {
    'address block', 'subject line', 'greetings', 'place and date',
    'title heading', 'about pmi', 'about pmi india', 'about philip morris',
    'about philip morris international', 'introduction to pmi', 'references',
}


def _section_role(name: str) -> str:
    """Classify a section by its name so evidence can be routed sensibly."""
    nl = (name or '').lower().strip()
    if nl in _STRUCTURAL_SECTION_NAMES:
        return 'structural'
    if 'executive summary' in nl:
        return 'summary'
    if 'conclusion' in nl or nl == 'summary':
        return 'conclusion'
    if any(k in nl for k in ['recommend', 'principle', 'propos']):
        return 'recommendations'
    if any(k in nl for k in ['evidence', 'scientific', 'core concept', 'risk', 'expansion', 'analysis', 'key update']):
        return 'evidence'
    if any(k in nl for k in ['background', 'context', 'introduction', 'topic', 'position', 'rationale', 'implementation', 'preparation', 'brief', 'letter body']):
        return 'background'
    return 'body'


def _allocate_findings_to_sections(sections: List[Dict[str, Any]], context: Dict[str, Any]):
    """C2: Distribute findings/insights/recommendations into DISTINCT per-section
    slices so each section works from its own evidence rather than the full pool.

    Returns (allocation, roles) where allocation maps section index -> a formatted
    findings_text string, and roles is the per-section role list.
    """
    findings = list(context.get('key_findings', []) or [])
    insights = list(context.get('policy_insights', []) or [])
    recs = list(context.get('recommendations', []) or [])
    n = len(sections)
    roles = [_section_role(s.get('name', '')) for s in sections]
    buckets = {i: [] for i in range(n)}

    # Content sections that can hold bulk findings (exclude structural/summary/conclusion)
    bulk_idxs = [i for i, r in enumerate(roles) if r in ('evidence', 'body', 'background')]
    if not bulk_idxs:
        bulk_idxs = [i for i, r in enumerate(roles) if r != 'structural'] or list(range(n))

    rec_idxs = [i for i, r in enumerate(roles) if r == 'recommendations'] or bulk_idxs
    ins_idxs = [i for i, r in enumerate(roles) if r == 'background'] or bulk_idxs

    # Recommendations -> recommendation sections (each item placed once)
    for k, item in enumerate(recs):
        buckets[rec_idxs[k % len(rec_idxs)]].append(item)
    # Policy insights -> background/position sections
    for k, item in enumerate(insights):
        buckets[ins_idxs[k % len(ins_idxs)]].append(item)
    # Findings -> spread round-robin across bulk content sections (distinct, no repeats)
    for k, item in enumerate(findings):
        buckets[bulk_idxs[k % len(bulk_idxs)]].append(item)

    # Summary & conclusion get a compact synthesis (their role is to recap at a high level)
    synth = findings[:2] + insights[:1] + recs[:1]
    for i, r in enumerate(roles):
        if r in ('summary', 'conclusion'):
            buckets[i] = list(synth)

    allocation = {}
    for i in range(n):
        items = buckets[i]
        if not items and roles[i] != 'structural':
            # Don't leave a content section empty — give it a minimal fallback slice
            items = (findings[:2] or insights[:2] or recs[:2])
        allocation[i] = "\n".join(f"- {it}" for it in items)

    logger.info(
        "FINDINGS_ALLOCATION | sections=%d | findings=%d insights=%d recs=%d | bulk_sections=%s"
        % (n, len(findings), len(insights), len(recs), bulk_idxs)
    )
    return allocation, roles


def generate_document_content(structure: Dict[str, Any], research_data: Dict[str, Any], validation_result: Dict[str, Any], request_id: str = '') -> Dict[str, Any]:
    """Generate document content — routes to letter or report generation based on category/use_case."""

    try:
        synthesis = research_data.get('synthesis', {})
        all_sources = research_data.get('all_sources', [])
        if synthesis.get('status') == 'no_data' and not all_sources:
            logger.info("Short-circuiting document generation due to absolute lack of sources.")
            return {
                'title': structure.get('title', 'Government Submission'),
                'sections': {
                    'executive_summary': {
                        'title': 'Executive Summary',
                        'content': 'Document drafting has been skipped because no sufficiently relevant knowledge base sources were found. Please refine your query or upload relevant documents to proceed.',
                        'word_count': 24
                    }
                },
                'key_recommendations': ['Refine query', 'Upload relevant documents', 'Ensure correct domain/topic'],
                'metadata': {
                    'generated_at': datetime.now().isoformat(),
                    'total_sections': 1,
                    'document_type': structure.get('document_type', ''),
                    'status': 'no_data'
                }
            }

        document_requirements = validation_result.get('document_requirements', {})
        category = document_requirements.get('category', '')
        use_case = document_requirements.get('use_case', '')
        target_language = document_requirements.get('target_language', 'English')

        # Route: Letters/Submission → single coherent letter call
        if _is_letter_submission(category, use_case):
            letter_doc = _generate_full_letter(structure, research_data, validation_result, request_id)
            # Citation parity with the section path: normalize any [Source: N] / (Source: N)
            # markers to [N] and drop out-of-range numbers so body markers line up with the
            # canonical References list. (The section path runs this further below.)
            _valid_ref_count = len(_canonical_citations(research_data.get('formatted_citations', [])))
            letter_doc = _reconcile_citations(letter_doc, _valid_ref_count)
            return letter_doc

        # Route: everything else → section-by-section report, drafted SEQUENTIALLY
        # so each section is aware of what earlier sections already covered (C1) and
        # receives a distinct evidence slice (C2).
        context = prepare_generation_context(structure, research_data, validation_result)
        # Add topic, background, user_query into context for prompts
        context['topic'] = document_requirements.get('topic', 'N/A')
        context['background'] = document_requirements.get('background', 'N/A')
        context['user_query'] = document_requirements.get('user_query', 'N/A')
        context['target_audience'] = document_requirements.get('target_audience', 'N/A')
        context['request_id'] = request_id

        sections = structure.get('sections', [])
        num_sections = len(sections)

        # C2: allocate a distinct, non-overlapping evidence slice to each section
        allocation, roles = _allocate_findings_to_sections(sections, context)

        logger.info(f"Initiating sequential, duplication-aware drafting for {num_sections} sections...")

        drafted_sections_dict = {}
        covered_ledger = []  # running list of "### Title\n<excerpt>" from prior sections
        truncation_events = []  # section names whose OUTPUT hit max_tokens (incomplete)

        for idx, section in enumerate(sections):
            # Per-section context: distinct evidence slice + ledger of prior coverage
            sec_ctx = dict(context)
            sec_ctx['section_findings_text'] = allocation.get(idx, '')
            sec_ctx['already_covered'] = "\n\n".join(covered_ledger)

            try:
                result = draft_single_section_worker(section, sec_ctx, idx, target_language)
            except Exception as e:
                logger.critical(f"Section drafting failure (idx={idx}, '{section.get('name','')}'): {str(e)}")
                raise e

            if sec_ctx.get('_section_truncated'):
                truncation_events.append(section.get('name', f'section_{idx}'))

            drafted_sections_dict[idx] = result
            logger.info(f"Section {idx} ('{result['section_name']}') drafted/translated successfully.")

            # Update the coverage ledger so later sections avoid repeating this content.
            # Skip boilerplate/structural sections (greetings, About PMI, etc.).
            if roles[idx] != 'structural':
                excerpt = (result.get('content') or '').strip()
                if excerpt:
                    covered_ledger.append(f"### {result['section_name']}\n{excerpt[:700]}")

        # Stitch drafts back together in the exact original order of the outline array
        ordered_sections = [drafted_sections_dict[i] for i in range(num_sections)]
        
        document_content = {
            'title': structure.get('title', ''),
            'sections': {},
            'key_recommendations': [],
            'metadata': {
                'generated_at': datetime.now().isoformat(),
                'total_sections': num_sections,
                'document_type': structure.get('document_type', '')
            }
        }
        
        # Check if we need translation, and build the translations concurrently
        translated_sections = {}
        translated_title = None
        
        for item in ordered_sections:
            section_key = item['section_key']
            document_content['sections'][section_key] = {
                'title': item['section_name'],
                'content': item['content'],
                'word_count': len(item['content'].split())
            }
            if item['translated_content']:
                translated_sections[section_key] = {
                    'title': item['translated_title'] or item['section_name'],
                    'content': item['translated_content']
                }
                
        if target_language and target_language.lower() not in ['english', 'en', ''] and translated_sections:
            logger.info(f"Parallel translation complete. Translating title...")
            try:
                translated_title = translate_text_with_llm(document_content.get('title', ''), target_language)
            except Exception as e:
                logger.error(f"Failed to translate title: {str(e)}")
            
            document_content['translated_title'] = translated_title
            document_content['translated_sections'] = translated_sections

        # Eliminate duplication and clean up the document content
        document_content = eliminate_document_duplicity(document_content, validation_result)

        # Track D: Agentic post-draft review — LLM reviews full document for quality issues
        document_content = _agentic_review_document(document_content, context)

        # Fact-level de-duplication: strip near-verbatim sentences repeated across sections
        # (Q&A / conclusion / structural sections are exempt).
        document_content = _dedup_repeated_sentences(document_content)

        # Structural safety net: flag any near-duplicate sections that survived the
        # dedup pass (cross-section bleed) so the review/HITL stage can catch them.
        document_content = _flag_duplicate_sections(document_content)

        # Citation integrity: normalize [Source: N] markers, strip unresolved/junk
        # markers, and drop orphan numbers that exceed the available reference count.
        _valid_ref_count = len(_canonical_citations(research_data.get('formatted_citations', [])))
        document_content = _reconcile_citations(document_content, _valid_ref_count)

        document_content['key_recommendations'] = extract_key_recommendations(
            document_content['sections']
        )
        if truncation_events:
            document_content['_truncation_events'] = truncation_events
            logger.warning(
                f"[{request_id}] TOKEN_POSTFLIGHT | {len(truncation_events)} section(s) truncated: "
                f"{truncation_events} — flagging document for review."
            )
        return document_content

    except Exception as e:
        logger.error(f"Error generating document content: {str(e)}")
        return create_fallback_content(structure, str(e))


def _generate_full_letter(structure: Dict[str, Any], research_data: Dict[str, Any], validation_result: Dict[str, Any], request_id: str = '') -> Dict[str, Any]:
    """Generate the complete formal letter in a single LLM call."""

    document_requirements = validation_result.get('document_requirements', {})
    synthesis = research_data.get('synthesis', {})

    category    = document_requirements.get('category', '')
    use_case    = document_requirements.get('use_case', '')
    jurisdiction = document_requirements.get('jurisdiction', '')
    target_audience = document_requirements.get('target_audience', '')
    topic       = document_requirements.get('topic', '')
    compliance  = document_requirements.get('compliance_requirements', [])

    background  = document_requirements.get('background', '')
    tone        = document_requirements.get('tone_requirements') or DEFAULT_TONE
    cc_to       = document_requirements.get('cc_to', '')

    from core.prompt_registry_new import get_agent_prompt, get_jurisdiction_context
    system_prompt       = get_agent_prompt(category, agent="drafter")
    jurisdiction_context = get_jurisdiction_context(jurisdiction)

    logger.info(f"PROMPT_ROUTING | category={category} | jurisdiction={jurisdiction} | agent=drafter | mode=full_letter")

    # Build research context block
    key_findings = synthesis.get('key_findings', [])
    findings_text = '\n'.join(f"- {f}" for f in key_findings) if key_findings else 'No findings available.'
    # C1: strip the researcher's inline [Source: N] numbering (single canonical registry only).
    findings_text = _strip_researcher_source_markers(findings_text)
    _letter_gaps = _extract_data_gaps(synthesis)

    policy_insights = synthesis.get('policy_insights', [])
    insights_text = '\n'.join(f"- {p}" for p in policy_insights) if policy_insights else ''

    all_sources = research_data.get('all_sources', [])
    web_search_context = _build_web_search_context(all_sources, category, use_case)

    user_prompt = f"""
Jurisdiction context: {jurisdiction_context}

Draft a complete formal regulatory submission LETTER with the following details:

Recipient: {target_audience}
{f"CC: {cc_to}" if cc_to else ""}
Subject matter: {topic}
Jurisdiction: {jurisdiction}
Compliance framework: {', '.join(compliance) if compliance else 'applicable local regulations'}
{f"Background Context: {background}" if background else ""}
Today's Date: {datetime.now().strftime("%B %d, %Y")}

Research findings to incorporate:
<documents>
{findings_text}
</documents>

{f"Policy insights:{chr(10)}{insights_text}" if insights_text else ""}
"""
    if web_search_context:
        user_prompt += f"""
Current regulatory context from web research (incorporate relevant points to add recency):
<web_search_results>
{web_search_context}
</web_search_results>
"""
    citation_registry = _build_citation_registry(research_data.get('formatted_citations', []))
    if citation_registry:
        user_prompt += f"""
NUMBERED SOURCE LIST (cite ONLY with inline [N] markers from this list, e.g. [1], [2]):
{citation_registry}
"""
    # D1: anti-fabrication guardrail for the letter path.
    user_prompt += _build_data_gaps_block(_letter_gaps)

    user_prompt += f"""
INSTRUCTIONS:
- Output the full letter as flowing prose — exclude section headers or markdown.
- Follow the letter structure: recipient block, subject line, opening, body, requests, closing, signature placeholder.
- DO NOT include structural LABELS in the output (e.g., do NOT print '[Recipient]', '[Subject Line]', '[Opening Paragraph]', '[Body Paragraph 1 - Regulatory Background]', '[Body Paragraph 2 - Core Arguments]', '[Requests/Positions]', '[Closing Paragraph]', or '[Signature Placeholder]'). Start directly with the address details and flow naturally. NOTE: this does NOT apply to inline citation markers like [1], which ARE required (see CITATIONS below).
- CITATIONS: When citing a source, use ONLY the inline marker [N] taken from the NUMBERED SOURCE LIST above (e.g. [1], [2]). Do NOT write '(Source: N)', 'Source 3', or full citations in the body, and do NOT add a references list — a References section is appended to the document automatically.
- Use the research findings, policy insights, and web search results above — strictly rely on provided facts without inventing new ones.
- CRITICAL: Ensure absolutely NO duplicacy of content. Do not repeat arguments, facts, or sentences. Consolidate similar points into single, powerful statements.
- Tone: {tone}
- Length Constraint: The letter MUST NOT exceed 2 pages in length. Be concise and impactful.
"""

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LLM_MODEL_REASONING,   # Opus — the full letter is the core drafting quality
            "system": system_prompt.strip(),
            "messages": [{"role": "user", "content": user_prompt.strip()}],
            "max_tokens": 8192,
            "temperature": 0.3,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        _preflight_prompt_budget(system_prompt, user_prompt, "full_letter", request_id or 'unknown')
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=180) as response:
            raw_response = response.read().decode('utf-8')
            res = json.loads(raw_response)
            if LANGSMITH_AVAILABLE:
                try:
                    record_llm_usage(res, 'monolith_drafter_full_letter', raw_response)
                except Exception:
                    pass
            letter_truncated = _check_response_truncation(res, "full_letter", request_id or 'unknown')
            letter_text = res['choices'][0]['message']['content'].strip()
            if letter_text.startswith('```'):
                lines = letter_text.split('\n')
                letter_text = '\n'.join(lines[1:-1]).strip()
                
            # Programmatic regex safeguard to clean out bracketed labels
            import re
            bracket_labels = [
                r'\[Recipient\]', 
                r'\[Subject Line\]', 
                r'\[Opening Paragraph\]', 
                r'\[Body Paragraph[^\]]*\]', 
                r'\[Requests?/Positions?\]', 
                r'\[Closing Paragraph\]', 
                r'\[Signature Placeholder\]',
                r'\[Greetings\]'
            ]
            for pattern in bracket_labels:
                letter_text = re.sub(pattern, '', letter_text, flags=re.IGNORECASE)
                
            # Strip multiple newlines
            letter_text = re.sub(r'\n{3,}', '\n\n', letter_text).strip()
            
            # Strip markdown bold (**text**) from letter output
            letter_text = re.sub(r'\*\*([^*]+)\*\*', r'\1', letter_text)
            letter_text = letter_text.replace('**', '')
            letter_text = re.sub(r'^#{1,4}\s+', '', letter_text, flags=re.MULTILINE)

    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        logger.error(f"HTTPError generating letter: {e.code} - {error_body}")
        raise Exception(f"HTTP {e.code}: {error_body}")
    except Exception as e:
        logger.error(f"Error generating full letter: {str(e)}")
        raise

    return {
        'title': structure.get('title', f"Formal Submission to {target_audience}"),
        'sections': {
            'letter_body': {
                'title': 'Letter Body',
                'content': letter_text,
                'word_count': len(letter_text.split()),
            }
        },
        'key_recommendations': [],
        'metadata': {
            'generated_at': datetime.now().isoformat(),
            'total_sections': 1,
            'document_type': structure.get('document_type', ''),
            'format': 'formal_letter',
        },
        **({'_truncation_events': ['letter_body']} if letter_truncated else {}),
    }


def _agentic_review_document(document_content: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Track D: Agentic post-draft review pass.
    
    After all sections are drafted and deduplication runs, the LLM reviews the
    full stitched document for:
    1. Repeated facts/statistics across sections
    2. Per-section reference lists that should be inline [N] only
    3. Content that doesn't match its section scope
    
    If issues found, flagged sections are re-drafted with specific correction instructions.
    Maximum 1 review cycle — falls back gracefully on any failure.
    """
    if not LITELLM_KEY:
        return document_content

    sections = document_content.get('sections', {})
    if not sections or len(sections) < 2:
        return document_content

    # Build the full stitched text for review
    full_text_parts = []
    for key, sec_data in sections.items():
        title   = sec_data.get('title', key)
        content = sec_data.get('content', '')
        full_text_parts.append(f"## {title}\n{content}")
    
    full_text = '\n\n'.join(full_text_parts)
    
    # Don't review very short documents (< 500 words)
    if len(full_text.split()) < 500:
        return document_content

    review_prompt = (
        "You are a document quality reviewer for formal regulatory submissions.\n\n"
        "Review the full document below and identify specific quality issues.\n\n"
        f"DOCUMENT:\n{full_text[:12000]}\n\n"
        "Identify:\n"
        "1. REPEATED FACTS: Any statistic, fact, or argument that appears in more than one section "
        "(exact or paraphrased). List the repeated fact and which sections it appears in.\n"
        "2. INLINE CITATION ISSUES: Any section that contains a full references list "
        "(numbered [1], [2], etc. WITH full source text) instead of just inline [N] markers.\n"
        "3. SECTION SCOPE VIOLATIONS: Any section that covers content that belongs in a different section "
        "(e.g., scientific evidence appearing in the Conclusion).\n\n"
        "For each issue found, output:\n"
        '{"section_key": "...", "issue_type": "repeated_fact|citation_list|scope_violation", '
        '"description": "what the problem is", "fix_instruction": "how to fix it"}\n\n'
        "Return a JSON array of issues. Empty array [] if no issues found.\n"
        "Maximum 5 issues. Focus on the most impactful ones only."
    )

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        data = {
            "model": LLM_MODEL_REASONING,
            "messages": [{"role": "user", "content": review_prompt}],
            "max_tokens": 1000,
            "temperature": 0.1,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=120) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            
            issues = json.loads(raw)
            if not isinstance(issues, list) or not issues:
                logger.info("AGENTIC_REVIEW | no issues found — document quality is good")
                return document_content

        logger.info(f"AGENTIC_REVIEW | found {len(issues)} issues — attempting targeted fixes")

        # For each flagged section, re-draft with the fix instruction
        # (never rewrite format-preserved sections — the rewrite LLM flattens their layout).
        _PRESERVE = ('anticipated', 'question', 'q&a', 'greeting', 'about pmi', 'about philip',
                     'references', 'title heading', 'place and date', 'address block', 'subject line')
        sections_to_fix = {}
        for issue in issues[:5]:
            sec_key = issue.get('section_key', '')
            fix_instruction = issue.get('fix_instruction', '')
            if sec_key and fix_instruction and sec_key in sections:
                _title = (sections[sec_key].get('title', sec_key) or '').lower()
                if any(m in _title for m in _PRESERVE):
                    logger.info(f"AGENTIC_REVIEW | skipping rewrite of preserved section '{sec_key}' (format-protected)")
                    continue
                if sec_key not in sections_to_fix:
                    sections_to_fix[sec_key] = []
                sections_to_fix[sec_key].append(fix_instruction)

        if not sections_to_fix:
            return document_content

        # Re-draft flagged sections with fix instructions
        for sec_key, fix_instructions in sections_to_fix.items():
            sec_data = sections[sec_key]
            original_content = sec_data.get('content', '')
            fix_text = '\n'.join(f"- {f}" for f in fix_instructions)

            rewrite_prompt = (
                "You are rewriting a section of a formal regulatory submission to fix quality issues.\n\n"
                f"SECTION TITLE: {sec_data.get('title', sec_key)}\n\n"
                f"CURRENT CONTENT:\n{original_content}\n\n"
                f"ISSUES TO FIX:\n{fix_text}\n\n"
                "Rewrite the section fixing all listed issues. Keep the same factual content "
                "but eliminate repetition, remove any embedded reference lists (use only [N] markers), "
                "and ensure content stays within the section's scope.\n"
                "Output ONLY the rewritten section content — no explanation, no title, no markers."
            )

            try:
                data = {
                    "model": LITELLM_MODEL,
                    "messages": [{"role": "user", "content": rewrite_prompt}],
                    "max_tokens": 4096,
                    "temperature": 0.2,
                }
                req = urllib.request.Request(
                    LITELLM_URL,
                    data=json.dumps(data).encode('utf-8'),
                    headers=headers,
                    method='POST',
                )
                with urllib.request.urlopen(req, context=ctx, timeout=120) as resp:
                    res = json.loads(resp.read().decode('utf-8'))
                    rewritten = res['choices'][0]['message']['content'].strip()
                    if rewritten and len(rewritten) > 100:
                        sections[sec_key]['content'] = rewritten
                        sections[sec_key]['word_count'] = len(rewritten.split())
                        logger.info(f"AGENTIC_REVIEW | rewrote section '{sec_key}' — {len(rewritten)} chars")
            except Exception as e:
                logger.warning(f"AGENTIC_REVIEW | failed to rewrite '{sec_key}': {e}")

        document_content['sections'] = sections
        return document_content

    except Exception as e:
        logger.warning(f"AGENTIC_REVIEW | review failed (non-fatal): {e}")
        return document_content


def _build_uploaded_files_context(all_sources: List[Dict[str, Any]]) -> str:
    """Format user-uploaded file summaries into a structured context block for the drafting agent."""
    uploaded_files = [s for s in (all_sources or []) if s.get('type') == 'uploaded_file']
    if not uploaded_files:
        return ''

    parts = []
    for file in uploaded_files:
        title = file.get('title', 'Uploaded Reference File')
        summary = file.get('summary', 'No content summary available')
        parts.append(f"Document Name: {title}\nSummary & Key Reference Facts:\n{summary}")

    return "User-Uploaded Reference Documents Context:\n" + "\n\n".join(parts)


def _build_kb_sources_context(all_sources: List[Dict[str, Any]], category: str) -> str:
    """Format knowledge base retrieval results into a structured context block for the drafting agent."""
    kb_sources = [s for s in (all_sources or []) if s.get('type') == 'internal_knowledge']
    if not kb_sources:
        return ''

    # For White Papers and Narrative Builder, include more KB sources
    cat_lower = (category or '').lower()
    if 'white paper' in cat_lower or 'narrative' in cat_lower:
        limit = 15  # More sources for comprehensive documents
    else:
        limit = 10

    parts = []
    for src in kb_sources[:limit]:
        title = clean_citation_title(src.get('title', 'Knowledge Base Document'))
        summary = src.get('summary', '')[:800].strip()  # Cap at 800 chars per source
        relevance = src.get('relevance_score', 0)
        parts.append(f"**{title}** (relevance: {relevance:.1f}%)\n{summary}")

    return "PMI Internal Knowledge Base Sources:\n\n" + "\n\n".join(parts)


def _canonical_citations(formatted_citations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return the single canonical, de-duplicated, capped citation list.

    This is the ONE ordered list that drives BOTH the inline [N] citation registry
    (injected into section prompts) AND the rendered References section. Using a single
    source of truth guarantees that body marker [N] and reference entry N always point to
    the same source — previously the registry de-duplicated while the References renderer
    enumerated the raw list, so the two numbering schemes could drift apart.
    """
    seen = set()
    unique: List[Dict[str, Any]] = []
    for c in formatted_citations or []:
        if not isinstance(c, dict):
            continue
        key = (c.get('url') or c.get('title', '')).strip().lower()
        if key and key not in seen:
            seen.add(key)
            unique.append(c)
    return unique[:20]  # cap at 20 — registry and references share this bound


def _build_citation_registry(formatted_citations: List[Dict[str, Any]]) -> str:
    """
    Track B: Build a numbered global citation registry from the researcher's citations.
    
    This is injected into every section's prompt so the LLM uses only [N] markers
    and never creates per-section reference lists.
    
    Returns a formatted string like:
        [1] WHO Framework Convention on Tobacco Control (2003) — who.int/fctc
        [2] FDA MRTP Order for IQOS (July 2020) — fda.gov
        ...
    """
    if not formatted_citations:
        return ""
    
    # Single canonical list (shared with the References renderer)
    unique_citations = _canonical_citations(formatted_citations)
    
    lines = []
    for i, c in enumerate(unique_citations[:20], 1):  # Cap at 20
        title = clean_citation_title(c.get('title', 'Unknown Source'))
        url   = c.get('url', '')
        date  = c.get('date', '')
        
        # Format: [N] Title (Date) — URL
        parts = [f"[{i}] {title}"]
        if date:
            parts[0] += f" ({date})"
        if url:
            parts.append(f"— {url}")
        lines.append(' '.join(parts))
    
    registry = '\n'.join(lines)
    logger.info(f"CITATION_REGISTRY | total_unique={len(unique_citations)} | used={min(len(unique_citations), 20)}")
    return registry


def _build_structured_facts_context(research_data: Dict[str, Any]) -> str:
    """Format structured facts into a high-priority context block for section prompts.
    
    These facts come from the researcher's Gemini-based extraction and contain
    exact numbers, legislation names, dates, and authority names.
    """
    facts = research_data.get('structured_facts', {})
    if not facts:
        return ''
    
    lines = ["VERIFIED FACTS — use these exact values (do not paraphrase numbers or dates):"]
    
    for s in facts.get('statistics', []):
        lines.append(f"• STAT: {s.get('metric','')} = {s.get('value','')} ({s.get('year','')}) [Source {s.get('source_index','')}]")
    for l in facts.get('legislation', []):
        lines.append(f"• LAW: {l.get('name','')} ({l.get('year','')}) — {l.get('status','')}")
    for a in facts.get('authorities', []):
        lines.append(f"• AUTHORITY: {a.get('name','')} — {a.get('role','')}")
    for d in facts.get('key_dates', []):
        lines.append(f"• DATE: {d.get('event','')} — {d.get('date','')}")
    
    return '\n'.join(lines) if len(lines) > 1 else ''


def prepare_generation_context(structure: Dict[str, Any], research_data: Dict[str, Any], validation_result: Dict[str, Any]) -> Dict[str, Any]:
    """Prepare context for document content generation"""

    document_requirements = validation_result.get('document_requirements', {})
    synthesis = research_data.get('synthesis', {})
    category  = document_requirements.get('category', '')
    use_case  = document_requirements.get('use_case', '')

    # Intent object from the researcher's Request Understanding agent (author identity,
    # stance, audience). Carrying this into the drafter prevents persona/stance inversion.
    research_framing = research_data.get('research_framing', {}) or {}

    context = {
        'document_type': structure.get('document_type', ''),
        'target_audience': document_requirements.get('target_audience', ''),
        'jurisdiction': document_requirements.get('jurisdiction', ''),
        'category': category,
        'use_case': use_case,
        'compliance_requirements': document_requirements.get('compliance_requirements', []),
        'key_findings': synthesis.get('key_findings', []),
        'policy_insights': synthesis.get('policy_insights', []),
        'recommendations': synthesis.get('recommendations', []),
        # Intent / stance (from Request Understanding) — keeps the draft in PMI's voice
        'author_identity': research_framing.get('author_identity', 'PMI'),
        'stance': research_framing.get('stance', ''),
        'audience': research_framing.get('audience', ''),
        'intent': research_framing.get('intent', ''),
        'objective': research_framing.get('objective', ''),
        # Tone flows from the researcher framing (which captured the user's
        # tone_requirements verbatim); fall back to the request, then the default.
        'tone': (
            research_framing.get('tone')
            or document_requirements.get('tone_requirements')
            or DEFAULT_TONE
        ),
        'word_target': structure.get('total_word_target', 2500),
        'web_search_context': _build_web_search_context(
            research_data.get('all_sources', []), category, use_case
        ),
        'uploaded_files_context': _build_uploaded_files_context(
            research_data.get('all_sources', [])
        ),
        # Structured facts from Gemini extraction (exact numbers, legislation, dates)
        'structured_facts': _build_structured_facts_context(research_data),
        # Track B: Global citation registry — numbered source list for inline [N] markers
        'citation_registry': _build_citation_registry(
            research_data.get('formatted_citations', [])
        ),
        # KB source context for content generation (full summaries, not just citations)
        'kb_sources_context': _build_kb_sources_context(
            research_data.get('all_sources', []), category
        ),
        # D1: research-flagged evidence gaps — injected into section prompts as a
        # "do not fabricate" guardrail.
        'data_gaps': _extract_data_gaps(synthesis),
    }

    return context


def generate_section_content(section: Dict[str, Any], context: Dict[str, Any]) -> str:
    """DEPRECATED / UNUSED — legacy single-shot section drafter.

    The active section path is `generate_section_content_react` (Opus + ReAct self-correction).
    This function is retained only as a fallback reference and is not called anywhere in the
    current pipeline. Kept temporarily for safety; safe to remove once confirmed unneeded.
    """
    
    section_name = section['name']
    word_target = section.get('word_target', 300)
    
    # ── Findings and Insights Partitioning ──
    sect_lower = section_name.lower()
    
    # Filter out raw background prevalence statistics to prevent creep
    # (specifically 45.3% and 1.9% or similar GDP/smoking rates)
    filtered_findings = []
    for f in context.get('key_findings', []):
        f_lower = f.lower()
        if "45.3%" in f_lower or "1.9%" in f_lower or "prevalence" in f_lower or "smoking rate" in f_lower or "gdp" in f_lower:
            # Only allow background stats in Executive Summary
            if "executive summary" in sect_lower or "context" in sect_lower:
                filtered_findings.append(f)
        else:
            filtered_findings.append(f)

    if "global precedents" in sect_lower or "progressive policies" in sect_lower:
        # Global Precedents receives strictly international policy insights
        findings_text = "\n".join(f"- {p}" for p in context.get('policy_insights', []))
    elif "regulatory principles" in sect_lower or "proposed regulatory" in sect_lower:
        # Regulatory Principles receives strictly concrete recommendations
        findings_text = "\n".join(f"- {r}" for r in context.get('recommendations', []))
    elif "scientific evidence" in sect_lower or "independent reviews" in sect_lower or "core concepts" in sect_lower or "risk continuum" in sect_lower:
        # Scientific Sections receive scientific/toxicological findings
        findings_text = "\n".join(f"- {f}" for f in filtered_findings if any(kw in f.lower() for kw in ["toxic", "exposure", "aerosol", "clinical", "scientific", "study", "evidence", "harm", "reduction", "nicotine", "smoke", "combust"]))
        # Fallback to general filtered findings if too empty
        if not findings_text.strip():
            findings_text = "\n".join(f"- {f}" for f in filtered_findings)
    elif "conclusion" in sect_lower or "bibliography" in sect_lower:
        # Conclusion receives a synthesis of insights and recommendations
        combined_findings = filtered_findings[:3] + context.get('policy_insights', [])[:2] + context.get('recommendations', [])[:2]
        findings_text = "\n".join(f"- {item}" for item in combined_findings)
    else:
        # Default fallback for other sections
        findings_text = "\n".join(f"- {f}" for f in filtered_findings)
        
    findings_section = f"Key Findings from Research:\n    {findings_text}"
    
    # Inject user-uploaded file summaries directly into the Bedrock drafting context block
    if context.get('uploaded_files_context'):
        findings_section += f"\n\n{context['uploaded_files_context']}"
    
    from core.prompt_registry_new import get_agent_prompt, get_jurisdiction_context
    category = context.get('category', '')
    jurisdiction = context.get('jurisdiction', '')
    system_prompt = get_agent_prompt(category, agent="drafter")
    jurisdiction_context = get_jurisdiction_context(jurisdiction)

    logger.info(f"PROMPT_ROUTING | category={category} | jurisdiction={jurisdiction} | agent=drafter | section={section_name}")
    ctx_copy = context.copy()

    # Enforce constraints only on specific sections: Greetings, Summary, and Description
    extra_requirements = ""
    sect_lower = section_name.lower()
    
    if "greetings" in sect_lower:
        audience = ctx_copy.get('target_audience', 'Colleagues')
        if not audience or audience.lower() in ['general', 'unknown', 'internal']:
            audience = "Colleagues"
        topic_str = context.get('topic', 'this update')
        extra_requirements = f"""
    - CRITICAL: Greetings must be EXACTLY ONE paragraph.
    - SALUTATION: Begin the paragraph directly with a professional salutation addressed to the target audience (e.g., "Dear {audience}," or "Dear Colleagues,").
    - MEANINGFUL CONTENT: Immediately follow the salutation in the SAME paragraph with a meaningful opening sentence introducing the document topic ({topic_str}) and its relevance.
    - NO PLACEHOLDERS: Under NO circumstances include generic brackets or placeholders (e.g., DO NOT use "[Recipient]", "[Name]", or "[Insert Date]")."""
        
    elif "summary" in sect_lower:
        extra_requirements = """
    - CRITICAL: The Summary must be EXACTLY ONE paragraph synthesizing the key takeaways and business relevance.
    - NO BULLETS: Do not use bullet points or split the text into multiple paragraphs.
    - NO HEADING PREFIX: Strictly do NOT write any section title, heading, or prefix (e.g., do NOT start with "Summary" or "**Summary:**"). Start writing the actual summary content directly from the first word."""
        
    elif "description" in sect_lower:
        extra_requirements = """
    - CRITICAL: The Description must be EXACTLY ONE paragraph providing a cohesive, factual, and meaningful overview of the updates. Strictly do NOT use bullet points, multiple paragraphs, or write any heading prefixes."""

    user_prompt = f"""
    Jurisdiction context: {jurisdiction_context}

    Please draft the {section_name} section based on these findings:

    <documents>
    {findings_section}
    </documents>

    Requirements:
    - Target: {ctx_copy.get('target_audience', 'General')} in {ctx_copy.get('jurisdiction', 'Global')}
    - Length: ~{word_target} words
    - No section title in output.{extra_requirements}
    """
            
    try:
        # Bypass SSL verification like verify=False
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": LITELLM_MODEL,
            "system": system_prompt.strip(),
            "messages": [
                {"role": "user", "content": user_prompt.strip()}
            ],
            "max_tokens": 4096,
            "temperature": 0.3,   # legacy section drafter — match the active section-gen temp
        }
        
        req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')
        
        with urllib.request.urlopen(req, context=ctx, timeout=180) as response:
            res = json.loads(response.read().decode('utf-8'))
            ai_response = res['choices'][0]['message']['content'].strip()
            
            
            # Clean up markdown if any
            if ai_response.startswith('```'):
                lines = ai_response.split('\n')
                if len(lines) > 2:
                    ai_response = '\n'.join(lines[1:-1]).strip()
                    
            return ai_response
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        logger.error(f"HTTPError in section {section_name}: {e.code} - {error_body}")
        raise Exception(f"HTTP {e.code}: {error_body}")
    except Exception as e:
        logger.error(f"Error generating section {section_name}: {str(e)}")
        raise e


def generate_executive_summary(context: Dict[str, Any], word_target: int) -> str:
    """Generate executive summary content"""
    
    return f"""
Philip Morris International (PMI) respectfully submits this response to the {context.get('target_audience', 'regulatory authority')} consultation on tobacco product regulation in {context.get('jurisdiction', 'India')}. 

This submission presents evidence-based recommendations for a regulatory framework that balances public health objectives with practical implementation considerations. Our position is grounded in scientific evidence and international regulatory best practices.

Key recommendations include:
• Implementation of risk-proportionate regulatory approaches
• Enhanced regulatory clarity for novel tobacco products  
• Adoption of evidence-based taxation frameworks
• Strengthened compliance and enforcement mechanisms

PMI supports regulations that advance public health while providing regulatory certainty for responsible industry participants. We believe the recommendations presented herein will contribute to effective policy development that serves the interests of all stakeholders.

This submission has been prepared in full compliance with {', '.join(context.get('compliance_requirements', ['applicable regulations']))} and reflects PMI's commitment to transparent and constructive engagement with regulatory authorities.
"""


def generate_background_section(context: Dict[str, Any], word_target: int) -> str:
    """Generate background and context section"""
    
    return f"""
The regulatory landscape for tobacco products in {context.get('jurisdiction', 'India')} continues to evolve in response to emerging scientific evidence and technological innovations. The current consultation represents an important opportunity to modernize regulatory frameworks to reflect contemporary understanding of tobacco harm reduction.

{context.get('target_audience', 'The regulatory authority')} has consistently demonstrated commitment to evidence-based policy making. This consultation builds upon previous regulatory initiatives while addressing emerging challenges in tobacco product regulation.

International regulatory developments provide valuable insights for policy development. Jurisdictions worldwide are increasingly adopting risk-proportionate approaches that differentiate between products based on their relative risk profiles. These developments inform the recommendations presented in this submission.

The tobacco industry has undergone significant transformation in recent years, with increased focus on reduced-risk products. This transformation necessitates regulatory frameworks that can accommodate innovation while maintaining robust public health protections.

PMI's engagement in this consultation reflects our commitment to constructive dialogue with regulatory authorities. We believe that transparent, evidence-based discussions contribute to effective policy development that serves public health objectives while providing regulatory certainty for industry participants.
"""


def generate_position_section(context: Dict[str, Any], word_target: int) -> str:
    """Generate PMI position and rationale section"""
    
    return f"""
PMI's position on tobacco product regulation is founded on three core principles: scientific evidence, public health advancement, and regulatory proportionality.

**Scientific Evidence Foundation**
All regulatory decisions should be grounded in robust scientific evidence. The expanding body of research on tobacco harm reduction provides clear guidance for risk-proportionate regulatory approaches. PMI supports regulatory frameworks that reflect the scientific consensus on relative product risks.

**Public Health Advancement**  
Effective tobacco regulation should maximize public health benefits while minimizing unintended consequences. This requires balanced approaches that encourage transition from higher-risk to lower-risk products while maintaining strong protections against youth access and inappropriate marketing.

**Regulatory Proportionality**
Regulatory requirements should be proportionate to product risks. Products with significantly reduced risk profiles warrant differentiated regulatory treatment, including taxation, marketing restrictions, and quality requirements. This approach incentivizes innovation in harm reduction while maintaining appropriate oversight.

**Implementation Considerations**
Effective regulation requires clear implementation guidelines, adequate enforcement resources, and stakeholder engagement. PMI supports phased implementation approaches that allow for regulatory learning and adjustment based on real-world experience.

These principles align with international regulatory trends and reflect best practices in evidence-based policy development. The specific recommendations presented in this submission operationalize these principles within the {context.get('jurisdiction', 'Indian')} regulatory context.
"""


def generate_evidence_section(context: Dict[str, Any], word_target: int) -> str:
    """Generate evidence base section"""
    
    return f"""
The scientific evidence base for tobacco harm reduction has expanded significantly in recent years, providing robust foundation for risk-proportionate regulatory approaches.

**Toxicological Evidence**
Independent scientific assessments consistently demonstrate substantial reductions in harmful constituents in aerosols from heated tobacco products compared to cigarette smoke. Studies by regulatory authorities including FDA, Health Canada, and others confirm these findings.

**Clinical Evidence**  
Clinical studies demonstrate reduced exposure to harmful constituents among users of heated tobacco products compared to continued cigarette smoking. These studies provide important insights into the potential public health benefits of product substitution.

**Population-Level Evidence**
Real-world evidence from markets where heated tobacco products are available indicates patterns of use consistent with harm reduction objectives. Population surveys demonstrate that these products primarily attract existing adult smokers rather than non-users or youth.

**Regulatory Precedents**
Multiple regulatory authorities worldwide have recognized the reduced-risk profile of certain tobacco products through differentiated regulatory treatment. These precedents provide valuable guidance for policy development in {context.get('jurisdiction', 'India')}.

**Economic Evidence**
Economic analyses demonstrate that risk-proportionate taxation approaches can generate significant public health benefits while maintaining government revenue. These studies inform recommendations for taxation policy reform.

The evidence base continues to evolve, with ongoing research providing additional insights into product risks and population-level impacts. PMI supports continued scientific research and transparent sharing of findings to inform evidence-based policy development.
"""


def generate_recommendations_section(context: Dict[str, Any], word_target: int) -> str:
    """Generate policy recommendations section"""
    
    return f"""
Based on the evidence presented, PMI respectfully recommends the following policy measures:

**1. Risk-Proportionate Regulatory Framework**
Implement regulatory requirements that reflect relative product risk profiles. Products with substantially reduced risk should be subject to differentiated requirements for taxation, marketing, and quality standards.

**2. Enhanced Regulatory Clarity**
Provide clear guidance on regulatory requirements for novel tobacco products, including application procedures, evidence requirements, and approval timelines. Regulatory certainty encourages responsible innovation and investment.

**3. Evidence-Based Taxation Policy**
Adopt taxation approaches that incentivize transition from higher-risk to lower-risk products while maintaining government revenue objectives. International experience demonstrates the effectiveness of such approaches.

**4. Robust Quality Standards**
Establish comprehensive quality and safety requirements for all tobacco products, with standards appropriate to each product category. These should include manufacturing standards, product testing requirements, and supply chain controls.

**5. Effective Enforcement Mechanisms**  
Implement strong enforcement measures to ensure compliance with regulatory requirements, prevent illicit trade, and protect against non-compliant products entering the market.

**6. Stakeholder Engagement Framework**
Establish ongoing mechanisms for stakeholder consultation on regulatory development and implementation. Regular dialogue enhances policy effectiveness and identifies implementation challenges.

**7. Monitoring and Evaluation System**
Implement comprehensive monitoring systems to track policy impacts on public health, market dynamics, and compliance. Regular evaluation enables evidence-based policy refinement.

These recommendations reflect international best practices and are tailored to the specific context of {context.get('jurisdiction', 'India')}. PMI stands ready to support implementation through continued dialogue and technical expertise.
"""


def generate_implementation_section(context: Dict[str, Any], word_target: int) -> str:
    """Generate implementation considerations section"""
    
    return f"""
Effective implementation of regulatory reforms requires careful planning, adequate resources, and stakeholder coordination. PMI offers the following implementation considerations:

**Phased Implementation Approach**
Complex regulatory changes benefit from phased implementation that allows for learning and adjustment. Priority should be given to core requirements, with additional elements introduced over time as experience is gained.

**Industry Readiness**
Responsible industry participants require adequate lead times to ensure compliance with new requirements. PMI recommends minimum 12-month implementation periods for significant regulatory changes to allow for necessary operational adjustments.

**Enforcement Capacity**
Effective enforcement requires adequate resources, training, and coordination among relevant authorities. Investment in enforcement capabilities should accompany regulatory implementation to ensure effectiveness.

**Stakeholder Communication**
Clear communication of regulatory requirements to all stakeholders, including industry, retailers, and consumers, is essential for successful implementation. Multi-channel communication strategies enhance understanding and compliance.

**Monitoring Systems**
Implementation should be accompanied by robust monitoring systems to track compliance, market impacts, and policy effectiveness. These systems should capture both quantitative metrics and qualitative insights from stakeholders.

**International Coordination**
Where appropriate, coordination with international regulatory developments can enhance effectiveness and reduce compliance burdens for multinational companies. Alignment with international standards facilitates trade and investment.

PMI commits to supporting implementation through constructive engagement, technical expertise, and operational compliance. We believe that collaborative approaches enhance policy effectiveness and serve the interests of all stakeholders.
"""


def generate_conclusion_section(context: Dict[str, Any], word_target: int) -> str:
    """Generate conclusion section"""
    
    return f"""
PMI appreciates the opportunity to contribute to this important regulatory consultation. The recommendations presented in this submission reflect our commitment to evidence-based policy development that advances public health objectives while providing regulatory certainty.

The scientific evidence clearly supports risk-proportionate regulatory approaches that differentiate between products based on their relative risk profiles. Implementation of such approaches in {context.get('jurisdiction', 'India')} would align with international best practices and contribute to public health advancement.

Key benefits of the recommended approach include:
• Enhanced public health outcomes through harm reduction
• Increased regulatory clarity and investment certainty  
• Alignment with international regulatory trends
• Balanced consideration of all stakeholder interests

PMI stands ready to support implementation of these recommendations through continued dialogue, technical expertise, and operational compliance. We believe that collaborative engagement between regulators and responsible industry participants serves the public interest.

We respectfully request that {context.get('target_audience', 'the regulatory authority')} give careful consideration to the evidence and recommendations presented in this submission. PMI looks forward to continued constructive engagement as regulatory development proceeds.

For any questions or clarification regarding this submission, please contact the PMI regulatory affairs team. We remain committed to supporting evidence-based policy development that serves the interests of public health and all stakeholders.
"""


def extract_key_recommendations(sections: Dict[str, Any]) -> List[str]:
    """Extract key recommendations from document sections"""
    
    recommendations = [
        "Implement risk-proportionate regulatory framework for tobacco products",
        "Enhance regulatory clarity for novel tobacco product categories", 
        "Adopt evidence-based taxation policies that incentivize harm reduction",
        "Establish robust quality and safety standards for all product categories",
        "Implement effective enforcement mechanisms to ensure compliance"
    ]
    
    return recommendations


def add_hyperlink(paragraph, url, text):
    """Add a clickable hyperlink to a python-docx paragraph"""
    import docx
    from docx.oxml.shared import OxmlElement
    from docx.oxml.ns import qn
    
    part = paragraph.part
    r_id = part.relate_to(url, docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, is_external=True)
    hyperlink = OxmlElement('w:hyperlink')
    hyperlink.set(qn('r:id'), r_id)
    new_run = OxmlElement('w:r')
    rPr = OxmlElement('w:rPr')
    
    rStyle = OxmlElement('w:rStyle')
    rStyle.set(qn('w:val'), 'Hyperlink')
    rPr.append(rStyle)
    new_run.append(rPr)
    
    text_elem = OxmlElement('w:t')
    text_elem.text = text
    new_run.append(text_elem)
    hyperlink.append(new_run)
    paragraph._p.append(hyperlink)
    return hyperlink


def _add_runs_with_bold(paragraph, text, font_name, size, color):
    """Add text to a paragraph, rendering **bold** segments as bold runs (Tier-1 readability)."""
    import re as _re
    for part in _re.split(r'(\*\*[^*]+\*\*)', text):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**') and len(part) > 4:
            run = paragraph.add_run(part[2:-2])
            run.font.bold = True
        else:
            run = paragraph.add_run(part)
        run.font.name = font_name
        run.font.size = size
        run.font.color.rgb = color


def _set_cell_shading(cell, fill_hex):
    """Apply a solid background fill to a table cell (callout boxes / table headers)."""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), fill_hex)
    tcPr.append(shd)


def _render_md_table(doc, table_lines, font_name, body_size, body_color, heading_color):
    """Render a Markdown pipe table (header row, '---' separator, body rows) as a styled Word table."""
    def _cells(line):
        return [c.strip() for c in line.strip().strip('|').split('|')]
    parsed = [_cells(l) for l in table_lines if l.strip()]
    if not parsed:
        return
    header = parsed[0]
    body = parsed[2:] if len(parsed) >= 2 else []
    ncols = max(len(header), 1)
    t = doc.add_table(rows=1 + len(body), cols=ncols)
    t.style = 'Table Grid'
    for j in range(ncols):
        cell = t.cell(0, j)
        cell.text = ''
        txt = (header[j] if j < len(header) else '').replace('**', '')
        _add_runs_with_bold(cell.paragraphs[0], txt, font_name, body_size, heading_color)
        for r in cell.paragraphs[0].runs:
            r.font.bold = True
        _set_cell_shading(cell, 'D9E1F2')  # light blue header
    for ri, row in enumerate(body, start=1):
        for j in range(ncols):
            cell = t.cell(ri, j)
            cell.text = ''
            val = row[j] if j < len(row) else ''
            _add_runs_with_bold(cell.paragraphs[0], val, font_name, body_size, body_color)


def _render_callout(doc, callout_lines, font_name, body_size, body_color, heading_color):
    """Render a blockquote callout (lines that began with '>') as a shaded single-cell box.
    The first non-empty line becomes the bold title; remaining lines are body (bullets supported)."""
    import re as _re
    t = doc.add_table(rows=1, cols=1)
    t.style = 'Table Grid'
    cell = t.cell(0, 0)
    _set_cell_shading(cell, 'F2F2F2')  # light grey
    cell.text = ''
    first = True
    for ln in callout_lines:
        ln = ln.strip()
        if not ln:
            continue
        if first:
            p = cell.paragraphs[0]
            run = p.add_run(ln.replace('**', '').rstrip(':'))
            run.font.bold = True
            run.font.name = font_name
            run.font.size = body_size
            run.font.color.rgb = heading_color
            first = False
            continue
        mb = _re.match(r'^[-*\u2022]\s+(.*)$', ln)
        if mb:
            p = cell.add_paragraph(style='List Bullet')
            _add_runs_with_bold(p, mb.group(1).strip(), font_name, body_size, body_color)
        else:
            p = cell.add_paragraph()
            _add_runs_with_bold(p, ln, font_name, body_size, body_color)


def _render_rich_text(doc, text, font_name, body_size, body_color, line_spacing, heading_color):
    """Render lightweight Markdown into a python-docx document for readability:
      - blank-line-separated short paragraphs
      - "- " / "* " bullets and "1." numbered lists
      - "## " / "### " sub-headings (bold, heading colour)
      - **bold** inline emphasis
      - Markdown pipe tables (header | --- | rows) -> styled Word tables (Tier 2)
      - blockquote callouts ("> Title" + "> body") -> shaded callout boxes (Tier 2)
    """
    import re as _re
    if not text:
        return
    # D4: the model sometimes inlines list items after a sentence ("...standards. - Introduce...")
    # or numbered items ("...section. 2. Adopt..."). Split these onto their own lines so they
    # render as real bullets/numbers. Gated on a preceding '.'/':' + a capitalised item so it
    # never touches ranges (2014-2020) or mid-sentence hyphens.
    text = _re.sub(r'(?<=[.:])\s+(?=-\s+[A-Z])', '\n', text)
    text = _re.sub(r'(?<=[.:])\s+(?=\d{1,2}[.)]\s+[A-Z])', '\n', text)
    # Q&A readability: start each "Q1." / "**Q2." / "Q3:" question on its own paragraph so a
    # run of anticipated questions does not collapse into a single unreadable block. Allows an
    # optional leading "**" (bold marker) since the Q&A contract emits "**Q1. ...**".
    text = _re.sub(r'(?<=[.?!])\s+(?=\*{0,2}Q\d{1,2}\s*[.:)]\s)', '\n\n', text)
    lines = text.replace('\r\n', '\n').split('\n')
    n = len(lines)
    buffer = []

    def _flush():
        joined = ' '.join(s.strip() for s in buffer if s.strip()).strip()
        buffer.clear()
        joined = _re.sub(r'\s*[-*_]{3,}\s*$', '', joined).strip()  # D4: drop a trailing '---' rule glued to prose
        if not joined:
            return
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = line_spacing
        _add_runs_with_bold(p, joined, font_name, body_size, body_color)

    def _is_table_row(s):
        s = s.strip()
        return s.startswith('|') and s.endswith('|') and s.count('|') >= 2

    def _is_table_sep(s):
        return bool(_re.match(r'^\|[\s:|-]+\|$', s.strip())) and '-' in s

    i = 0
    while i < n:
        stripped = lines[i].strip()

        if not stripped:
            _flush()
            i += 1
            continue

        # D4: standalone markdown horizontal rule (---, ***, ___) — treat as a separator, drop it
        if _re.match(r'^([-*_])\1{2,}$', stripped):
            _flush()
            i += 1
            continue

        # Markdown table (current row + separator on next line)
        if _is_table_row(stripped) and i + 1 < n and _is_table_sep(lines[i + 1]):
            _flush()
            block = [stripped, lines[i + 1].strip()]
            j = i + 2
            while j < n and _is_table_row(lines[j]):
                block.append(lines[j].strip())
                j += 1
            _render_md_table(doc, block, font_name, body_size, body_color, heading_color)
            i = j
            continue

        # Blockquote callout box
        if stripped.startswith('>'):
            _flush()
            block = []
            j = i
            while j < n and lines[j].strip().startswith('>'):
                block.append(_re.sub(r'^\s*>\s?', '', lines[j]))
                j += 1
            _render_callout(doc, block, font_name, body_size, body_color, heading_color)
            i = j
            continue

        # Sub-heading
        m_h = _re.match(r'^(#{2,4})\s+(.*)$', stripped)
        if m_h:
            _flush()
            level = 2 if len(m_h.group(1)) <= 2 else 3
            h = doc.add_heading('', level=level)
            run = h.add_run(m_h.group(2).replace('**', '').strip())
            run.font.name = font_name
            run.font.bold = True
            run.font.color.rgb = heading_color
            i += 1
            continue

        # Q&A question line ("Q1." / "Q2:" / "Q3)") — own paragraph with a bold marker so
        # Anticipated-Questions sections read as a clean list instead of one run-on block.
        m_q = _re.match(r'^(Q\d{1,2}\s*[.:)])\s+(.*)$', stripped)
        if m_q:
            _flush()
            p = doc.add_paragraph()
            p.paragraph_format.line_spacing = line_spacing
            p.paragraph_format.space_before = Pt(6)
            q_run = p.add_run(m_q.group(1) + ' ')
            q_run.font.name = font_name
            q_run.font.size = body_size
            q_run.font.color.rgb = body_color
            q_run.font.bold = True
            _add_runs_with_bold(p, m_q.group(2).strip(), font_name, body_size, body_color)
            i += 1
            continue

        # Bullet
        m_b = _re.match(r'^[-*\u2022]\s+(.*)$', stripped)
        if m_b:
            _flush()
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.line_spacing = line_spacing
            _add_runs_with_bold(p, m_b.group(1).strip(), font_name, body_size, body_color)
            i += 1
            continue

        # Numbered — render the literal number the model wrote, as a manual prefix with a
        # hanging indent. We deliberately AVOID python-docx style='List Number' because all
        # 'List Number' paragraphs share ONE document-wide numbering definition, so lists in
        # later sections continue the counter (producing 7., 8., 9. instead of 1., 2., 3.) and
        # even bleed into the References list. Manual numbering restarts each list correctly.
        m_n = _re.match(r'^(\d{1,2})[.)]\s+(.*)$', stripped)
        if m_n:
            _flush()
            p = doc.add_paragraph()
            p.paragraph_format.line_spacing = line_spacing
            p.paragraph_format.left_indent = Inches(0.5)
            p.paragraph_format.first_line_indent = Inches(-0.25)
            _add_runs_with_bold(
                p, f"{m_n.group(1)}. {m_n.group(2).strip()}", font_name, body_size, body_color
            )
            i += 1
            continue

        # Normal line
        buffer.append(stripped)
        i += 1

    _flush()


# ── Quality metrics: deterministic (Python) + LLM judge ───────────────────────

_QM_PLACEHOLDER_MARKERS = (
    'could not be generated', 'neutral placeholder', '[placeholder', '[insert',
    '[tbd', '[todo', 'content could not', 'requires manual review',
)


def _count_syllables(word: str) -> int:
    import re as _re
    w = _re.sub(r'[^a-z]', '', word.lower())
    if not w:
        return 0
    count = len(_re.findall(r'[aeiouy]+', w))
    if w.endswith('e') and count > 1:
        count -= 1
    return max(1, count)


def _compute_readability(document_content: Dict[str, Any]) -> Dict[str, float]:
    """Flesch Reading Ease + Flesch-Kincaid grade + structural readability signals (pure Python)."""
    import re as _re
    text = '\n\n'.join(
        (s.get('content') or '').strip()
        for s in document_content.get('sections', {}).values()
        if (s.get('content') or '').strip()
    )
    if not text.strip():
        return {'flesch_reading_ease': 0.0, 'flesch_kincaid_grade': 0.0,
                'avg_sentence_length': 0.0, 'avg_paragraph_sentences': 0.0}
    words = _re.findall(r"[A-Za-z']+", text)
    n_words = max(1, len(words))
    n_sent = max(1, len([s for s in _re.split(r'[.!?]+', text) if s.strip()]))
    n_syll = sum(_count_syllables(w) for w in words)
    wps = n_words / n_sent
    spw = n_syll / n_words
    fre = 206.835 - 1.015 * wps - 84.6 * spw
    fkg = 0.39 * wps + 11.8 * spw - 15.59
    n_para = max(1, len([p for p in _re.split(r'\n\s*\n', text) if p.strip()]))
    return {
        'flesch_reading_ease': round(max(0.0, min(100.0, fre)), 1),
        'flesch_kincaid_grade': round(max(0.0, fkg), 1),
        'avg_sentence_length': round(wps, 1),
        'avg_paragraph_sentences': round(n_sent / n_para, 1),
    }


def _compute_structure_completeness(structure: Dict[str, Any], document_content: Dict[str, Any],
                                    min_words: int = 15) -> Dict[str, int]:
    """Percent of planned sections that are present AND substantively filled (pure Python)."""
    gen = document_content.get('sections', {}) or {}
    total = len(structure.get('sections', []) or []) or len(gen)
    if total == 0:
        return {'structure_completeness': 0, 'sections_filled': 0, 'sections_planned': 0}
    filled = 0
    for sec in gen.values():
        content = (sec.get('content') or '').strip()
        wc = sec.get('word_count') or len(content.split())
        if content and wc >= min_words and not any(m in content.lower() for m in _QM_PLACEHOLDER_MARKERS):
            filled += 1
    return {
        'structure_completeness': round(100 * min(filled, total) / total),
        'sections_filled': filled,
        'sections_planned': total,
    }


def _compute_confidence(document_content: Dict[str, Any], research_result: Dict[str, Any]) -> int:
    """Grounding/citation-coverage confidence blended with researcher source quality (pure Python).
    Uses the synthesis research_summary (research_result), which carries confidence_score, sources,
    citations and relevance flags."""
    import re as _re
    substantive = [s for s in (document_content.get('sections', {}) or {}).values()
                   if (s.get('content') or '').strip()]
    n_sub = max(1, len(substantive))
    cited = sum(1 for s in substantive if _re.search(r'\[\d+\]|\[Source:\s*\d+', s.get('content', '')))
    citation_coverage = cited / n_sub

    citations = research_result.get('citations', []) or []
    available_refs = research_result.get('citation_count') or len(citations)
    used = set()
    for s in substantive:
        used.update(_re.findall(r'\[(\d+)\]', s.get('content', '')))
    citation_usage = min(1.0, len(used) / available_refs) if available_refs else 0.0

    rconf = research_result.get('confidence_score', 0) or 0
    research_quality = (rconf / 100.0) if rconf > 1 else float(rconf)   # normalise to 0..1

    score = 100 * (0.45 * research_quality + 0.35 * citation_coverage + 0.20 * citation_usage)
    if research_result.get('low_relevance') or (research_result.get('relevant_source_count', 1) == 0):
        score = min(score, 40)
    return int(round(max(0, min(100, score))))


def compute_quality_metrics(document_content: Dict[str, Any], structure: Dict[str, Any],
                            research_result: Dict[str, Any]) -> Dict[str, Any]:
    """Real, deterministic drafting quality metrics (no LLM, no new dependency)."""
    sc = _compute_structure_completeness(structure, document_content)
    return {
        'structure_completeness': sc['structure_completeness'],
        'sections_filled': sc['sections_filled'],
        'sections_planned': sc['sections_planned'],
        'readability': _compute_readability(document_content),
        'confidence_score': _compute_confidence(document_content, research_result),
    }


def llm_judge_document(document_content: Dict[str, Any], validation_result: Dict[str, Any],
                       research_result: Dict[str, Any] = None) -> Dict[str, Any]:
    """Evidence-aware LLM-as-judge (Opus): qualitative validity verdict + score + grounding audit.

    Unlike a blind reviewer, this judge is given the research evidence (synthesis findings +
    the canonical source list) so it can detect FABRICATION — statistics, studies, dates, or
    named authorities asserted in the draft that are NOT supported by the provided evidence —
    and citation misalignment ([N] markers that don't resolve to a real source).

    Non-blocking: returns {} on any failure so it never blocks document delivery.
    """
    if not LITELLM_KEY:
        return {}
    dr = validation_result.get('document_requirements', {}) or {}

    # ── Build the EVIDENCE block the judge grounds against ────────────────────
    research_result = research_result or {}
    ev_parts = []
    for key in ('key_findings', 'policy_insights', 'recommendations'):
        vals = research_result.get(key, []) or []
        if vals:
            ev_parts.append(f"{key}:\n" + "\n".join(f"- {str(v)[:300]}" for v in vals[:20]))
    canon = _canonical_citations(research_result.get('citations', []) or [])
    if canon:
        ev_parts.append("AVAILABLE SOURCES (the only valid [N] references):\n" +
                        "\n".join(f"[{i}] {clean_citation_title(c.get('title','')) if isinstance(c, dict) else str(c)}"
                                  for i, c in enumerate(canon, 1)))
    # Approved corporate facts: the About-PMI boilerplate is deterministic, pre-verified
    # content (from the PMI earnings release / website) that the drafter injects verbatim into
    # the "Introduction to PMI" / "About PMI" section. It is NOT part of the topic research,
    # so without this the judge wrongly flags every corporate statistic (headcount, revenue,
    # market counts) as fabrication and crashes groundedness. Feeding the same constant in as
    # approved evidence makes those facts grounded while still policing the topic content.
    # It gets a RESERVED slot (prepended + budgeted) so it survives the evidence-size cap.
    corporate_facts = (
        "APPROVED CORPORATE FACTS (pre-verified; treat as fully grounded — do NOT flag "
        "as unsupported):\n" + _PMI_ABOUT_US.strip()
    )
    research_blob = ("\n\n".join(ev_parts))[: max(0, 9000 - len(corporate_facts) - 4)]
    evidence_blob = (
        (research_blob + "\n\n" + corporate_facts) if research_blob.strip() else corporate_facts
    )

    parts = [f"TITLE: {document_content.get('title', '')}"]
    for s in document_content.get('sections', {}).values():
        parts.append(f"\n## {s.get('title', '')}\n{(s.get('content') or '')[:1400]}")
    doc_text = "\n".join(parts)[:16000]

    system_prompt = (
        "You are a senior reviewer for PMI corporate-affairs documents. Judge the draft for "
        "validity, coherence, stance, and — most importantly — GROUNDEDNESS against the supplied "
        "evidence. Return ONLY a JSON object."
    )
    user_prompt = f"""Assess this {dr.get('category', 'document')} for {dr.get('jurisdiction', '')} on topic: {dr.get('topic', '')}.
The author is PMI; the document MUST represent PMI's interest and never argue against it or adopt the regulator's voice.

You are given the ONLY evidence that was available to the drafter. Treat anything in the draft
that is NOT supported by this evidence as a FABRICATION (especially specific statistics,
percentages, study names, dates, and named authorities). Also flag any inline [N] marker that
does not map to one of the AVAILABLE SOURCES below.

<evidence>
{evidence_blob}
</evidence>

<document>
{doc_text}
</document>

Return ONLY this JSON (no prose):
{{"verdict": "pass" or "revise",
  "score": 0-100,
  "dimensions": {{"coherence": 0-100, "stance_ok": true or false, "groundedness": 0-100, "formatting": 0-100, "completeness": 0-100}},
  "unsupported_claims": ["specific stat/study/authority asserted but NOT in the evidence", "..."],
  "citation_issues": ["[N] marker that does not resolve to an available source", "..."],
  "issues": ["other concise issue", "..."]}}
Rules:
- Set stance_ok=false and verdict="revise" if the document argues against PMI's interest or speaks in the regulator's voice.
- Lower groundedness sharply and set verdict="revise" if unsupported_claims is non-empty.
- Max 8 items per list."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        data = {
            "model": LLM_MODEL_REASONING,   # Opus — grounding audit is high-stakes reasoning
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
            "max_tokens": 1200,
            "temperature": 0.1,
        }
        headers = {"Authorization": f"Bearer {LITELLM_KEY}", "Content-Type": "application/json"}
        req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req, context=ctx, timeout=120) as resp:
            raw = json.loads(resp.read().decode('utf-8'))['choices'][0]['message']['content'].strip()
        import re as _re
        m = _re.search(r'\{[\s\S]*\}', raw)
        verdict = json.loads(m.group(0) if m else raw)
        if isinstance(verdict, dict):
            return verdict
    except Exception as e:
        logger.warning(f"LLM judge failed (non-fatal): {e}")
    return {}


def create_formatted_document(content: Dict[str, Any], structure: Dict[str, Any], citations: List[Any], metadata: Dict[str, Any] = None, translated_sections: Dict[str, Any] = None, translated_title: str = None) -> bytes:
    """Create formatted Word document with PMI corporate styling."""
    
    if metadata is None:
        metadata = {}
        
    try:
        from docx.shared import Inches, Pt, Cm, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.style import WD_STYLE_TYPE
        import re as _re_docx

        # Create new Document
        doc = Document()

        # ── PMI Corporate Styling ─────────────────────────────────────────────
        # Font: Calibri (clean sans-serif, corporate standard)
        # Heading color: Dark teal/navy (#1F3864) — matches PMI corporate blue
        # Body color: Dark charcoal (#333333) — softer than pure black, professional
        # Line spacing: 1.15 for readability
        
        PMI_HEADING_COLOR = RGBColor(0x1F, 0x38, 0x64)  # Dark navy blue
        PMI_BODY_COLOR = RGBColor(0x33, 0x33, 0x33)      # Dark charcoal
        PMI_FONT = 'Calibri'
        PMI_HEADING_FONT_SIZE = Pt(14)
        PMI_TITLE_FONT_SIZE = Pt(22)
        PMI_BODY_FONT_SIZE = Pt(11)
        PMI_LINE_SPACING = 1.15

        # Set default document font
        style = doc.styles['Normal']
        font = style.font
        font.name = PMI_FONT
        font.size = PMI_BODY_FONT_SIZE
        font.color.rgb = PMI_BODY_COLOR

        # Set default paragraph spacing
        style.paragraph_format.space_after = Pt(6)
        style.paragraph_format.line_spacing = PMI_LINE_SPACING

        # Configure Heading 1 style
        h1_style = doc.styles['Heading 1']
        h1_style.font.name = PMI_FONT
        h1_style.font.size = PMI_HEADING_FONT_SIZE
        h1_style.font.bold = True
        h1_style.font.color.rgb = PMI_HEADING_COLOR
        h1_style.paragraph_format.space_before = Pt(18)
        h1_style.paragraph_format.space_after = Pt(8)

        # Configure Heading 2 style
        h2_style = doc.styles['Heading 2']
        h2_style.font.name = PMI_FONT
        h2_style.font.size = Pt(12)
        h2_style.font.bold = True
        h2_style.font.color.rgb = PMI_HEADING_COLOR
        h2_style.paragraph_format.space_before = Pt(12)
        h2_style.paragraph_format.space_after = Pt(6)

        # Configure Title style
        title_style = doc.styles['Title']
        title_style.font.name = PMI_FONT
        title_style.font.size = PMI_TITLE_FONT_SIZE
        title_style.font.bold = True
        title_style.font.color.rgb = PMI_HEADING_COLOR

        # ── Document Title ────────────────────────────────────────────────────
        title = doc.add_heading(content.get('title', 'Government Submission'), 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in title.runs:
            run.font.name = PMI_FONT
            run.font.size = PMI_TITLE_FONT_SIZE
            run.font.color.rgb = PMI_HEADING_COLOR
        
        # Resolve the document category (used below for section-heading rules).
        doc_category = ''
        if metadata:
            doc_category = metadata.get('department', '') or metadata.get('category', '')
        if not doc_category and structure:
            doc_category = structure.get('category', '')

        # NOTE: The "Document Information" metadata table was intentionally removed from the
        # generated draft (business requirement: drafts must not contain a metadata table).
        # Document metadata (id, dates, owner, jurisdiction, language, validity) remains
        # available via DynamoDB and the request APIs — it is no longer rendered in the .docx.
        # ── Section Content ───────────────────────────────────────────────────
        _NO_HEADING_CATEGORIES = {'Official PMI Submission', 'Third Party Submission'}
        _NO_HEADING_SECTIONS = {'summary', 'greetings', 'ending greetings', 'address block', 'subject line'}

        for section_key, section_data in content.get('sections', {}).items():
            section_title = section_data.get('title', '')
            sect_lower = section_title.lower().strip()

            # Determine if this section should have a visible heading
            should_add_heading = (
                doc_category not in _NO_HEADING_CATEGORIES
                and sect_lower not in _NO_HEADING_SECTIONS
                and section_title.strip()
                and 'letter' not in sect_lower
            )

            if should_add_heading:
                heading = doc.add_heading(section_title, level=1)
                for run in heading.runs:
                    run.font.name = PMI_FONT
                    run.font.color.rgb = PMI_HEADING_COLOR

            # Render lightweight Markdown → short paragraphs, bullets, sub-headings, bold runs
            _render_rich_text(
                doc, section_data['content'].strip(),
                PMI_FONT, PMI_BODY_FONT_SIZE, PMI_BODY_COLOR, PMI_LINE_SPACING, PMI_HEADING_COLOR
            )
        
        # ── Translated Content ────────────────────────────────────────────────
        if translated_sections:
            doc.add_page_break()
            trans_title = doc.add_heading(translated_title or "Translation", 0)
            trans_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in trans_title.runs:
                run.font.name = PMI_FONT
                run.font.color.rgb = PMI_HEADING_COLOR
            
            for section_key, section_data in translated_sections.items():
                section_title = section_data.get('title', '')
                sect_lower = section_title.lower().strip()
                should_add_heading = (
                    doc_category not in _NO_HEADING_CATEGORIES
                    and sect_lower not in _NO_HEADING_SECTIONS
                    and section_title.strip()
                    and 'letter' not in sect_lower
                )
                if should_add_heading:
                    heading = doc.add_heading(section_title, level=1)
                    for run in heading.runs:
                        run.font.name = PMI_FONT
                        run.font.color.rgb = PMI_HEADING_COLOR
                
                _render_rich_text(
                    doc, section_data['content'].strip(),
                    PMI_FONT, PMI_BODY_FONT_SIZE, PMI_BODY_COLOR, PMI_LINE_SPACING, PMI_HEADING_COLOR
                )

        # ── References (ALL categories) ───────────────────────────────────────
        # Sources/References are rendered for EVERY document category whenever the
        # researcher supplied citations — there is NO category gating. The list reuses
        # the same canonical (de-duplicated, capped) set as the inline [N] markers so
        # the reference numbering matches the body markers exactly.
        if citations:
            doc.add_page_break()
            ref_heading = doc.add_heading('References', level=1)
            for run in ref_heading.runs:
                run.font.name = PMI_FONT
                run.font.color.rgb = PMI_HEADING_COLOR
            
            # Use the SAME canonical (de-duplicated, capped) list as the inline [N]
            # citation registry so reference numbering matches body markers exactly.
            # Render the number as an explicit [N] text prefix (NOT style='List Number'):
            # 'List Number' shares one document-wide counter, so the references would
            # continue the body-list numbering (e.g. start at 10) and no longer match the
            # inline [N] markers. Manual [N] + hanging indent guarantees [N] == reference N.
            for i, citation in enumerate(_canonical_citations(citations), 1):
                p = doc.add_paragraph()
                p.paragraph_format.line_spacing = PMI_LINE_SPACING
                p.paragraph_format.left_indent = Inches(0.5)
                p.paragraph_format.first_line_indent = Inches(-0.5)
                num_run = p.add_run(f"[{i}] ")
                num_run.font.name = PMI_FONT
                num_run.font.size = Pt(10)
                num_run.font.bold = True
                num_run.font.color.rgb = PMI_BODY_COLOR
                if isinstance(citation, dict):
                    cleaned_title = clean_citation_title(citation.get('title', 'Document'))
                    # Clean, client-facing reference: Title (Year) — no internal
                    # source-type tags or relevance scores in the final document.
                    date = str(citation.get('date', '') or citation.get('year', '')).strip()
                    display_text = f"{cleaned_title} ({date})" if date else cleaned_title
                    if citation.get('url'):
                        add_hyperlink(p, citation['url'], display_text)
                    else:
                        run = p.add_run(display_text)
                        run.font.name = PMI_FONT
                        run.font.size = Pt(10)
                        run.font.color.rgb = PMI_BODY_COLOR
                else:
                    run = p.add_run(clean_citation_title(str(citation)))
                    run.font.name = PMI_FONT
                    run.font.size = Pt(10)
                    run.font.color.rgb = PMI_BODY_COLOR
        
        # Save to bytes
        doc_io = io.BytesIO()
        doc.save(doc_io)
        doc_io.seek(0)
        
        return doc_io.getvalue()
        
    except Exception as e:
        logger.error(f"Error creating formatted document: {str(e)}")
        # Return minimal document
        doc = Document()
        doc.add_heading('Document Generation Error', 0)
        doc.add_paragraph(f"Error occurred during document formatting: {str(e)}")
        doc_io = io.BytesIO()
        doc.save(doc_io)
        doc_io.seek(0)
        return doc_io.getvalue()


def store_document(request_id: str, formatted_doc: bytes, content: Dict[str, Any], category: str = "category", use_case: str = "") -> str:
    """Store generated document in S3"""
    
    try:
        import os
        import re
        bucket_name = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')
        
        # Clean category to make it S3/URL safe
        safe_cat = re.sub(r'[^a-zA-Z0-9]', '_', category).strip('_').lower()

        # Filename = {Category}.docx. The request_id in the prefix already guarantees
        # uniqueness (documents/{request_id}/...), so the title adds no value here.
        filename_base = safe_cat or "document"

        doc_s3_key = f"documents/{request_id}/{filename_base}.docx"
        content_s3_key = f"documents/{request_id}/{filename_base}.json"

        
        # Upload to S3
        s3.put_object(
            Bucket=bucket_name,
            Key=doc_s3_key,
            Body=formatted_doc,
            ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
        
        s3.put_object(
            Bucket=bucket_name,
            Key=content_s3_key,
            Body=json.dumps(content, indent=2),
            ContentType='application/json'
        )
        
        return doc_s3_key
        
    except Exception as e:
        logger.error(f"Error storing document: {str(e)}")
        safe_cat_fb = re.sub(r'[^a-zA-Z0-9]', '_', category).strip('_').lower() if 'category' in locals() else "unknown"
        return f"documents/{request_id}/{safe_cat_fb}.docx"


def calculate_word_count(content: Dict[str, Any]) -> int:
    """Calculate total word count of document content"""
    
    total_words = 0
    
    # Count words in title
    title = content.get('title', '')
    total_words += len(title.split())
    
    # Count words in sections
    for section_data in content.get('sections', {}).values():
        section_content = section_data.get('content', '')
        total_words += len(section_content.split())
    
    return total_words


def create_fallback_content(structure: Dict[str, Any], error_msg: str = "Unknown error") -> Dict[str, Any]:
    """Create fallback content if generation fails"""
    
    return {
        'title': structure.get('title', 'Government Submission'),
        'sections': {
            'executive_summary': {
                'title': 'Executive Summary',
                'content': f'This submission presents PMI\'s position on the regulatory consultation. Detailed content generation failed and requires manual review. Error: {error_msg}',
                'word_count': 25
            }
        },
        'key_recommendations': ['Manual content review required'],
        'metadata': {
            'generated_at': datetime.now().isoformat(),
            'status': 'fallback_content',
            'total_sections': 1
        }
    }


def update_request_status(request_id: str, status: str, notes: str, document_s3_key: str = None) -> None:
    """Update request status in DynamoDB"""
    
    try:
        update_expr = 'SET #status = :status, #notes = :notes, #updated_at = :timestamp'
        expr_attr_names = {
            '#status': 'status',
            '#notes': 'processing_notes',
            '#updated_at': 'updated_at'
        }
        expr_attr_values = {
            ':status': status,
            ':notes': notes,
            ':timestamp': datetime.utcnow().isoformat() + 'Z'
        }
        
        if document_s3_key:
            update_expr += ', #doc_key = :doc_key'
            expr_attr_names['#doc_key'] = 'document_s3_key'
            expr_attr_values[':doc_key'] = document_s3_key
            
            # Construct and add the full S3 Object URL
            import os
            bucket_name = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')
            region = os.environ.get('AWS_REGION', 'eu-west-1')
            s3_url = f"https://{bucket_name}.s3.{region}.amazonaws.com/{document_s3_key}"
            
            update_expr += ', #s3_url = :s3_url'
            expr_attr_names['#s3_url'] = 's3_bucket_URL'
            expr_attr_values[':s3_url'] = s3_url
            
        requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_attr_names,
            ExpressionAttributeValues=expr_attr_values
        )
    except Exception as e:
        logger.error(f"Error updating request status: {str(e)}")


def translate_text_with_llm(text: str, target_language: str) -> str:
    """Translate text into the target language via the LiteLLM gateway using LITELLM_MODEL
    (Sonnet). Low temperature for faithful, literal translation (no embellishment)."""
    if not text or not text.strip():
        return text
        
    system_prompt = f"""You are an expert, highly accurate corporate translator. 
Your ONLY task is to translate the user's text into {target_language}. 
CRITICAL RULES:
1. Translate EXACTLY what is written. Do NOT add, invent, or hallucinate any new text.
2. Do NOT fill in any placeholders or templates (like [Recipient] or [CC]).
3. Preserve all original line breaks, formatting, and layout.
4. Output ONLY the direct translation wrapped in <translation> and </translation> XML tags. Do not include any conversational text."""
    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": LITELLM_MODEL,
            "system": system_prompt.strip(),
            "messages": [
                {
                    "role": "user", 
                    "content": f"Please accurately translate the following source text. Do NOT hallucinate, invent, or fill in any letter templates. ONLY translate the text provided inside the tags.\n\n<source_text>\n{text.strip()}\n</source_text>"
                }
            ],
            "max_tokens": 4096,
            "temperature": 0.2,   # faithful translation — keep low for literal accuracy
        }
        
        req = urllib.request.Request(LITELLM_URL, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')
        
        with urllib.request.urlopen(req, context=ctx, timeout=180) as response:
            res = json.loads(response.read().decode('utf-8'))
            ai_response = res['choices'][0]['message']['content'].strip()
            
            import re
            match = re.search(r'<translation>(.*?)</translation>', ai_response, re.DOTALL | re.IGNORECASE)
            if match:
                ai_response = match.group(1).strip()
            else:
                ai_response = ai_response.replace('<translation>', '').replace('</translation>', '').strip()
                
            return ai_response
            
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        logger.error(f"HTTPError in translation: {e.code} - {error_body}")
        raise Exception(f"HTTP {e.code}: {error_body}")
    except Exception as e:
        logger.error(f"Error in translation: {str(e)}")
        raise e
