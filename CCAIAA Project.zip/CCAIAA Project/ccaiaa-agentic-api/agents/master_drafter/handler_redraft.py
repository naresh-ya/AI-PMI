"""Re-Draft Lambda handler for Draft HITL revisions.

Invoked by Step Functions when the Draft HITL decision is 'revise'.
Receives feedback + existing plan/sections artifacts, runs intelligent
selective re-draft, and returns draft_result (same shape as assembler output).
"""
import core.langsmith_tracing.ssl_bootstrap  # must precede langsmith

try:
    import drafter_redraft as redraft
except ImportError:
    from agents.master_drafter import drafter_redraft as redraft

from core.drafter_common import logger

try:
    from langsmith import traceable
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers, attach_outgoing_langsmith_headers, tracing_context
    )
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False


@traceable(name="re_draft_stage", run_type="chain")
def _traced_redraft(event, request_id):
    hitl_draft_retry_count = int(event.get('hitl_draft_retry_count') or 0)
    logger.info(f"[{request_id}] STAGE re_draft start (retry={hitl_draft_retry_count})")
    return redraft.handle_redraft(event, request_id)


def lambda_handler(event, context):
    request_id = str(event.get('request_id') or 'unknown')
    if LANGSMITH_AVAILABLE:
        try:
            incoming = get_incoming_langsmith_headers(event)
            with tracing_context(parent=incoming):
                result = _traced_redraft(event, request_id)
            from langsmith import get_current_run_tree
            run_tree = get_current_run_tree()
            attach_outgoing_langsmith_headers(result, run_tree)
            return result
        except Exception as e:
            logger.warning(f"[{request_id}] LangSmith tracing failed: {e}", exc_info=True)
    return _traced_redraft(event, request_id)
