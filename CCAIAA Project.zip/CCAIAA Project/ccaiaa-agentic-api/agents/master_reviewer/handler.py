"""
Master Review Agent for PMI Agentic AI Platform

This agent conducts comprehensive review and validation of generated documents
to ensure compliance, accuracy, and quality before final approval.

Responsibilities:
- Compliance and risk assessment
- Regulatory requirement validation  
- Scientific assertion verification
- Legal terminology review
- Policy intelligence generation
- Final quality assurance and approval
"""

import json
import logging
from typing import Dict, Any, List, Tuple
from datetime import datetime
import boto3
import re
from dataclasses import dataclass

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
bedrock_runtime = boto3.client('bedrock-runtime')
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
requests_table = dynamodb.Table(os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests'))


@dataclass
class ReviewResult:
    """Data class for review results"""
    category: str
    status: str  # 'pass', 'warning', 'fail'
    score: int  # 0-100
    findings: List[str]
    recommendations: List[str]


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for Master Review Agent
    
    Args:
        event: Contains draft results and previous processing data
        context: Lambda context object
        
    Returns:
        Review result with compliance assessment and final document status
    """
    
    try:
        logger.info(f"Starting document review for request: {event.get('request_id')}")
        
        request_id = event.get('request_id')
        draft_result = event.get('draft_result', {})
        validation_result = event.get('validation_result', {})
        research_result = event.get('research_result', {})
        
        # Update request status
        update_request_status(request_id, 'reviewing', 'Comprehensive review initiated')
        
        # Load document content for review
        document_content = load_document_content(draft_result.get('document_s3_key'))
        
        # Conduct multi-dimensional review
        review_results = conduct_comprehensive_review(
            document_content, 
            validation_result, 
            research_result
        )
        
        # Generate policy intelligence insights
        policy_intelligence = generate_policy_intelligence(
            document_content,
            research_result,
            validation_result
        )
        
        # Calculate overall confidence score
        overall_confidence = calculate_overall_confidence(review_results)
        
        # Determine final status
        final_status = determine_final_status(review_results, overall_confidence)
        
        # Create final document package
        final_document_s3_key = create_final_document_package(
            request_id,
            document_content,
            review_results,
            policy_intelligence
        )
        
        # Prepare review result
        review_summary = {
            "status": "success" if final_status == "approved" else "requires_attention",
            "request_id": request_id,
            "review_summary": {
                "overall_confidence": overall_confidence,
                "final_status": final_status,
                "total_checks": len(review_results),
                "passed_checks": len([r for r in review_results if r.status == 'pass']),
                "warning_checks": len([r for r in review_results if r.status == 'warning']),
                "failed_checks": len([r for r in review_results if r.status == 'fail']),
                "review_duration": "7 minutes"
            },
            "compliance_assessment": {
                "cotpa_compliance": get_review_status(review_results, "regulatory_compliance"),
                "fctc_compliance": get_review_status(review_results, "regulatory_compliance"),
                "youth_protection": get_review_status(review_results, "compliance_risk"),
                "scientific_accuracy": get_review_status(review_results, "scientific_review"),
                "legal_terminology": get_review_status(review_results, "legal_review")
            },
            "policy_intelligence": policy_intelligence,
            "final_document_s3_key": final_document_s3_key,
            "review_details": [
                {
                    "category": r.category,
                    "status": r.status,
                    "score": r.score,
                    "key_findings": r.findings[:3],  # Top 3 findings
                    "recommendations": r.recommendations[:2]  # Top 2 recommendations
                }
                for r in review_results
            ],
            "next_step": "human_approval" if final_status == "approved" else "revision_required"
        }
        
        # Update final request status
        final_request_status = 'ready_for_approval' if final_status == 'approved' else 'requires_revision'
        update_request_status(request_id, final_request_status, f'Review completed - {final_status}')
        
        logger.info(f"Document review completed for request {request_id} - Status: {final_status}")
        
        return review_summary
        
    except Exception as e:
        logger.error(f"Error in document review: {str(e)}")
        request_id = event.get('request_id', 'unknown')
        update_request_status(request_id, 'review_failed', f'Review failed: {str(e)}')
        
        return {
            "status": "error",
            "error": "Document review failed",
            "details": str(e),
            "request_id": request_id
        }


def load_document_content(document_s3_key: str) -> Dict[str, Any]:
    """Load document content from S3 for review"""
    
    try:
        if not document_s3_key:
            logger.warning("No document S3 key provided, using mock content")
            return create_mock_document_content()
        
        # In real implementation, load from S3
        # content_s3_key = document_s3_key.replace('.docx', '_content.json')
        # response = s3.get_object(Bucket='pmi-agentic-ai-documents', Key=content_s3_key)
        # document_content = json.loads(response['Body'].read())
        
        # For now, return mock data
        return create_mock_document_content()
        
    except Exception as e:
        logger.error(f"Error loading document content: {str(e)}")
        return create_mock_document_content()


def create_mock_document_content() -> Dict[str, Any]:
    """Create mock document content for review"""
    
    return {
        'title': 'Submission on CBIC Consultation - Excise Duty Framework',
        'sections': {
            'executive_summary': {
                'title': 'Executive Summary',
                'content': 'PMI respectfully submits evidence-based recommendations for excise duty framework modernization...',
                'word_count': 250
            },
            'background_and_context': {
                'title': 'Background and Context',
                'content': 'The regulatory landscape continues to evolve with scientific advancements...',
                'word_count': 400
            }
        },
        'key_recommendations': [
            'Implement risk-proportionate taxation framework',
            'Enhance regulatory clarity for novel products'
        ],
        'total_word_count': 2450
    }


def conduct_comprehensive_review(document_content: Dict[str, Any], validation_result: Dict[str, Any], research_result: Dict[str, Any]) -> List[ReviewResult]:
    """Conduct comprehensive multi-dimensional review"""
    
    review_results = []
    
    # 1. Compliance and Risk Review
    compliance_review = conduct_compliance_review(document_content, validation_result)
    review_results.append(compliance_review)
    
    # 2. Regulatory Review  
    regulatory_review = conduct_regulatory_review(document_content, validation_result)
    review_results.append(regulatory_review)
    
    # 3. Scientific Review
    scientific_review = conduct_scientific_review(document_content, research_result)
    review_results.append(scientific_review)
    
    # 4. Legal Review
    legal_review = conduct_legal_review(document_content, validation_result)
    review_results.append(legal_review)
    
    return review_results


def conduct_compliance_review(document_content: Dict[str, Any], validation_result: Dict[str, Any]) -> ReviewResult:
    """Conduct compliance and risk assessment"""
    
    findings = []
    recommendations = []
    score = 95
    
    # Check for youth-targeted claims
    youth_claims = check_youth_claims(document_content)
    if not youth_claims['violations']:
        findings.append("✓ No youth-targeted claims detected")
    else:
        findings.extend(youth_claims['violations'])
        score -= 20
        recommendations.append("Remove youth-targeted language")
    
    # Check for appropriate disclaimers
    disclaimers = check_disclaimers(document_content)
    if disclaimers['present']:
        findings.append("✓ Appropriate disclaimers included")
    else:
        findings.append("⚠ Missing required disclaimers")
        score -= 10
        recommendations.append("Add regulatory compliance disclaimers")
    
    # Check for promotional language
    promotional = check_promotional_language(document_content)
    if not promotional['violations']:
        findings.append("✓ Non-promotional tone maintained")
    else:
        findings.extend(promotional['violations'])
        score -= 15
        recommendations.append("Revise promotional language to neutral tone")
    
    status = "pass" if score >= 85 else ("warning" if score >= 70 else "fail")
    
    return ReviewResult(
        category="compliance_risk",
        status=status,
        score=score,
        findings=findings,
        recommendations=recommendations
    )


def conduct_regulatory_review(document_content: Dict[str, Any], validation_result: Dict[str, Any]) -> ReviewResult:
    """Conduct regulatory compliance review"""
    
    findings = []
    recommendations = []
    score = 92
    
    requirements = validation_result.get('document_requirements', {}).get('compliance_requirements', [])
    
    # Check COTPA 2003 compliance
    if "COTPA 2003" in str(requirements):
        cotpa_check = check_cotpa_compliance(document_content)
        if cotpa_check['compliant']:
            findings.append("✓ COTPA 2003 obligations respected")
        else:
            findings.append("⚠ Potential COTPA 2003 compliance issues")
            score -= 15
            recommendations.append("Review COTPA 2003 compliance requirements")
    
    # Check FCTC compliance
    if "FCTC" in str(requirements):
        fctc_check = check_fctc_compliance(document_content)
        if fctc_check['compliant']:
            findings.append("✓ FCTC obligations addressed appropriately")
        else:
            findings.append("⚠ FCTC compliance requires attention")
            score -= 10
            recommendations.append("Align with FCTC Article requirements")
    
    # Check citation accuracy
    citation_check = verify_citations(document_content)
    findings.append(f"✓ Citation accuracy verified ({citation_check['accuracy']}%)")
    
    status = "pass" if score >= 85 else ("warning" if score >= 70 else "fail")
    
    return ReviewResult(
        category="regulatory_compliance",
        status=status,
        score=score,
        findings=findings,
        recommendations=recommendations
    )


def conduct_scientific_review(document_content: Dict[str, Any], research_result: Dict[str, Any]) -> ReviewResult:
    """Conduct scientific accuracy review"""
    
    findings = []
    recommendations = []
    score = 94
    
    # Verify scientific assertions
    assertions = extract_scientific_assertions(document_content)
    verified_count = 0
    
    for assertion in assertions[:5]:  # Review top 5 assertions
        verification = verify_scientific_assertion(assertion, research_result)
        if verification['supported']:
            verified_count += 1
            findings.append(f"✓ Scientific assertion verified: {assertion[:50]}...")
        else:
            findings.append(f"⚠ Requires verification: {assertion[:50]}...")
            score -= 5
            recommendations.append("Provide additional scientific evidence")
    
    # Check evidence quality
    evidence_quality = assess_evidence_quality(research_result)
    findings.append(f"✓ Evidence quality score: {evidence_quality}%")
    
    if evidence_quality < 85:
        score -= 10
        recommendations.append("Strengthen evidence base with peer-reviewed sources")
    
    status = "pass" if score >= 85 else ("warning" if score >= 70 else "fail")
    
    return ReviewResult(
        category="scientific_review",
        status=status,
        score=score,
        findings=findings,
        recommendations=recommendations
    )


def conduct_legal_review(document_content: Dict[str, Any], validation_result: Dict[str, Any]) -> ReviewResult:
    """Conduct legal terminology and format review"""
    
    findings = []
    recommendations = []
    score = 98
    
    # Check legal terminology accuracy
    legal_terms = extract_legal_terms(document_content)
    accuracy_score = verify_legal_terminology(legal_terms)
    findings.append(f"✓ Legal terminology accuracy: {accuracy_score}%")
    
    if accuracy_score < 95:
        score -= 5
        recommendations.append("Review legal terminology for accuracy")
    
    # Check formal tone consistency
    tone_check = assess_formal_tone(document_content)
    if tone_check['consistent']:
        findings.append("✓ Formal tone maintained throughout")
    else:
        findings.append("⚠ Tone consistency requires attention")
        score -= 10
        recommendations.append("Maintain consistent formal tone")
    
    # Check document structure
    structure_check = verify_document_structure(document_content)
    findings.append(f"✓ Document structure compliance: {structure_check['score']}%")
    
    status = "pass" if score >= 90 else ("warning" if score >= 75 else "fail")
    
    return ReviewResult(
        category="legal_review",
        status=status,
        score=score,
        findings=findings,
        recommendations=recommendations
    )


def generate_policy_intelligence(document_content: Dict[str, Any], research_result: Dict[str, Any], validation_result: Dict[str, Any]) -> Dict[str, Any]:
    """Generate policy intelligence insights"""
    
    return {
        "regulatory_trends": [
            "Increasing global adoption of risk-proportionate regulatory frameworks",
            "Growing emphasis on evidence-based policy making in tobacco regulation", 
            "Enhanced focus on harm reduction approaches in public health policy"
        ],
        "risk_factors": [
            "Potential regulatory uncertainty during transition periods",
            "Implementation challenges for complex multi-tiered frameworks"
        ],
        "strategic_opportunities": [
            "Alignment with international regulatory best practices",
            "Enhanced stakeholder engagement through transparent processes",
            "Improved public health outcomes through targeted interventions",
            "Strengthened regulatory certainty for responsible industry participants"
        ],
        "recommendations": [
            "Monitor international regulatory developments for alignment opportunities",
            "Engage proactively in stakeholder consultation processes",
            "Invest in evidence generation to support policy development",
            "Develop implementation readiness for regulatory changes"
        ],
        "confidence_level": 87,
        "generated_at": datetime.now().isoformat()
    }


def calculate_overall_confidence(review_results: List[ReviewResult]) -> int:
    """Calculate overall confidence score from review results"""
    
    if not review_results:
        return 0
    
    # Weight different review categories
    category_weights = {
        'compliance_risk': 0.3,
        'regulatory_compliance': 0.3, 
        'scientific_review': 0.25,
        'legal_review': 0.15
    }
    
    weighted_score = 0
    total_weight = 0
    
    for result in review_results:
        weight = category_weights.get(result.category, 0.2)
        weighted_score += result.score * weight
        total_weight += weight
    
    return int(weighted_score / total_weight) if total_weight > 0 else 0


def determine_final_status(review_results: List[ReviewResult], overall_confidence: int) -> str:
    """Determine final document status based on review results"""
    
    failed_reviews = [r for r in review_results if r.status == 'fail']
    warning_reviews = [r for r in review_results if r.status == 'warning']
    
    if failed_reviews:
        return "requires_revision"
    elif len(warning_reviews) > 2 or overall_confidence < 80:
        return "requires_attention"
    elif overall_confidence >= 95:
        return "approved"
    else:
        return "approved_with_conditions"


# Utility functions for specific checks

def check_youth_claims(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Check for youth-targeted claims"""
    
    youth_keywords = ['young', 'youth', 'teen', 'adolescent', 'student', 'cool', 'trendy', 'hip']
    violations = []
    
    full_text = get_full_document_text(document_content)
    
    for keyword in youth_keywords:
        if keyword.lower() in full_text.lower():
            context = extract_context(full_text, keyword)
            if is_problematic_youth_reference(context):
                violations.append(f"Potential youth-targeted language: '{keyword}' in context")
    
    return {'violations': violations}


def check_disclaimers(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Check for required disclaimers"""
    
    required_disclaimers = [
        'This submission is made in compliance with applicable regulations',
        'PMI does not encourage tobacco use',
        'These products are not risk-free'
    ]
    
    full_text = get_full_document_text(document_content)
    present_disclaimers = []
    
    for disclaimer in required_disclaimers:
        if any(phrase in full_text for phrase in disclaimer.split()):
            present_disclaimers.append(disclaimer)
    
    return {
        'present': len(present_disclaimers) > 0,
        'found': present_disclaimers
    }


def check_promotional_language(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Check for inappropriate promotional language"""
    
    promotional_keywords = ['best', 'superior', 'revolutionary', 'breakthrough', 'amazing', 'fantastic']
    violations = []
    
    full_text = get_full_document_text(document_content)
    
    for keyword in promotional_keywords:
        if keyword.lower() in full_text.lower():
            violations.append(f"Promotional language detected: '{keyword}'")
    
    return {'violations': violations}


def check_cotpa_compliance(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Check COTPA 2003 compliance"""
    
    # Simplified compliance check
    full_text = get_full_document_text(document_content)
    
    cotpa_references = ['COTPA', 'Cigarettes and Other Tobacco Products Act']
    compliance_indicators = ['compliance', 'accordance', 'pursuant to']
    
    has_references = any(ref in full_text for ref in cotpa_references)
    has_compliance_language = any(indicator in full_text for indicator in compliance_indicators)
    
    return {'compliant': has_references and has_compliance_language}


def check_fctc_compliance(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Check FCTC compliance"""
    
    full_text = get_full_document_text(document_content)
    
    fctc_references = ['FCTC', 'Framework Convention on Tobacco Control', 'WHO FCTC']
    
    has_references = any(ref in full_text for ref in fctc_references)
    
    return {'compliant': has_references}


def verify_citations(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Verify citation format and accuracy"""
    
    # Simplified citation verification
    return {'accuracy': 94}


def extract_scientific_assertions(document_content: Dict[str, Any]) -> List[str]:
    """Extract scientific assertions from document"""
    
    # Simplified assertion extraction
    return [
        "Reduced exposure to harmful constituents",
        "Evidence supports harm reduction potential",
        "Scientific consensus on relative risk differences"
    ]


def verify_scientific_assertion(assertion: str, research_result: Dict[str, Any]) -> Dict[str, Any]:
    """Verify scientific assertion against research"""
    
    # Simplified verification - in reality would check against research data
    return {'supported': True, 'confidence': 92}


def assess_evidence_quality(research_result: Dict[str, Any]) -> int:
    """Assess overall evidence quality"""
    
    return 94  # Simplified scoring


def extract_legal_terms(document_content: Dict[str, Any]) -> List[str]:
    """Extract legal terms from document"""
    
    legal_terms = ['regulation', 'compliance', 'statutory', 'pursuant', 'accordance', 'framework']
    return legal_terms


def verify_legal_terminology(legal_terms: List[str]) -> int:
    """Verify legal terminology accuracy"""
    
    return 96  # Simplified verification


def assess_formal_tone(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Assess formal tone consistency"""
    
    return {'consistent': True, 'score': 95}


def verify_document_structure(document_content: Dict[str, Any]) -> Dict[str, Any]:
    """Verify document structure compliance"""
    
    sections = document_content.get('sections', {})
    required_sections = ['executive_summary', 'background']
    
    present_sections = len([s for s in required_sections if s in sections])
    score = (present_sections / len(required_sections)) * 100
    
    return {'score': int(score)}


def get_full_document_text(document_content: Dict[str, Any]) -> str:
    """Get full document text for analysis"""
    
    text_parts = [document_content.get('title', '')]
    
    for section_data in document_content.get('sections', {}).values():
        text_parts.append(section_data.get('content', ''))
    
    return ' '.join(text_parts)


def extract_context(text: str, keyword: str, window: int = 50) -> str:
    """Extract context around a keyword"""
    
    keyword_pos = text.lower().find(keyword.lower())
    if keyword_pos == -1:
        return ""
    
    start = max(0, keyword_pos - window)
    end = min(len(text), keyword_pos + len(keyword) + window)
    
    return text[start:end]


def is_problematic_youth_reference(context: str) -> bool:
    """Check if youth reference is problematic"""
    
    # Simplified check - in reality would use more sophisticated NLP
    problematic_contexts = ['appeal to', 'attract', 'target']
    return any(phrase in context.lower() for phrase in problematic_contexts)


def get_review_status(review_results: List[ReviewResult], category: str) -> str:
    """Get review status for specific category"""
    
    for result in review_results:
        if result.category == category:
            return result.status
    
    return "not_reviewed"


def create_final_document_package(request_id: str, document_content: Dict[str, Any], review_results: List[ReviewResult], policy_intelligence: Dict[str, Any]) -> str:
    """Create final document package with review annotations"""
    
    try:
        bucket_name = 'pmi-agentic-ai-documents'
        s3_key = f"final/{request_id}/final_document_package.json"
        
        package = {
            'request_id': request_id,
            'document_content': document_content,
            'review_results': [
                {
                    'category': r.category,
                    'status': r.status,
                    'score': r.score,
                    'findings': r.findings,
                    'recommendations': r.recommendations
                }
                for r in review_results
            ],
            'policy_intelligence': policy_intelligence,
            'final_approval_status': determine_final_status(review_results, calculate_overall_confidence(review_results)),
            'generated_at': datetime.now().isoformat()
        }
        
        # In real implementation, upload to S3
        # s3.put_object(
        #     Bucket=bucket_name,
        #     Key=s3_key,
        #     Body=json.dumps(package, indent=2)
        # )
        
        return s3_key
        
    except Exception as e:
        logger.error(f"Error creating final document package: {str(e)}")
        return f"final/{request_id}/final_document_package.json"


def update_request_status(request_id: str, status: str, notes: str) -> None:
    """Update request status in DynamoDB"""
    
    try:
        requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression='SET #status = :status, #notes = :notes, #updated_at = :timestamp',
            ExpressionAttributeNames={
                '#status': 'status',
                '#notes': 'processing_notes', 
                '#updated_at': 'updated_at'
            },
            ExpressionAttributeValues={
                ':status': status,
                ':notes': notes,
                ':timestamp': datetime.now().isoformat()
            }
        )
    except Exception as e:
        logger.error(f"Error updating request status: {str(e)}")
