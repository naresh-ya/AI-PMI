"""
Workflow Error Handler Lambda

This Lambda is triggered when Step Functions executions fail to update the 
DynamoDB request status to reflect the failure. This ensures the UI always 
shows the correct status even when workflows fail unexpectedly.

Trigger: Step Functions Error Handler (configured in state machine Catch blocks)
"""

import json
import logging
import os
from datetime import datetime, timezone
from typing import Dict, Any
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
REQUESTS_TABLE = os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests')
requests_table = dynamodb.Table(REQUESTS_TABLE)

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handle Step Functions workflow failures by updating DynamoDB status.
    
    Expected event format from Step Functions error:
    {
        "Error": "States.TaskFailed",
        "Cause": "...",
        "request_id": "req_xxx",
        "current_status": "DRAFTING_IN_PROGRESS" or "RESEARCH_IN_PROGRESS", etc.
    }
    """
    logger.info(f"Workflow error handler triggered: {json.dumps(event)}")
    
    try:
        # Extract request_id from event
        request_id = event.get('request_id')
        if not request_id:
            # Try to extract from nested structure
            request_id = event.get('Input', {}).get('request_id')
        
        if not request_id:
            logger.error(f"No request_id found in event: {json.dumps(event)}")
            return {'statusCode': 400, 'body': 'No request_id provided'}
        
        # Extract error details
        error_type = event.get('Error', 'Unknown')
        cause = event.get('Cause', 'Workflow execution failed')
        current_status = event.get('current_status', '')
        
        # Truncate cause if too long (DynamoDB item size limit)
        if len(cause) > 1000:
            cause = cause[:997] + '...'
        
        # Determine appropriate failure status based on current status
        failure_status = _determine_failure_status(current_status)
        
        logger.info(f"Updating request {request_id} from {current_status} to {failure_status}")
        
        # Update DynamoDB with retry logic
        max_retries = 3
        for attempt in range(max_retries):
            try:
                requests_table.update_item(
                    Key={'request_id': request_id},
                    UpdateExpression='SET #s = :s, #err = :err, #errt = :errt, updated_at = :ts',
                    ExpressionAttributeNames={
                        '#s': 'status',
                        '#err': 'error',
                        '#errt': 'error_type'
                    },
                    ExpressionAttributeValues={
                        ':s': failure_status,
                        ':err': cause,
                        ':errt': error_type,
                        ':ts': datetime.now(timezone.utc).isoformat()
                    }
                )
                logger.info(f"Successfully updated request {request_id} status to {failure_status}")
                break
            except ClientError as e:
                if attempt < max_retries - 1:
                    logger.warning(f"DynamoDB update attempt {attempt + 1} failed, retrying: {str(e)}")
                    continue
                else:
                    logger.error(f"Failed to update DynamoDB after {max_retries} attempts: {str(e)}")
                    raise
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Status updated successfully',
                'request_id': request_id,
                'new_status': failure_status
            })
        }
        
    except Exception as e:
        logger.error(f"Error in workflow error handler: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


def _determine_failure_status(current_status: str) -> str:
    """
    Determine the appropriate failure status based on the current workflow status.
    
    Maps in-progress statuses to their corresponding failure states.
    """
    status_map = {
        'RESEARCH_IN_PROGRESS': 'RESEARCH_FAILED',
        'DRAFTING_IN_PROGRESS': 'DRAFTING_FAILED',
        'RE_RESEARCH_IN_PROGRESS': 'RE_RESEARCH_FAILED',
        'RE_DRAFT_IN_PROGRESS': 'RE_DRAFT_FAILED',
        'REVIEW_IN_PROGRESS': 'REVIEW_FAILED',
        'FINALIZATION_IN_PROGRESS': 'FINALIZATION_FAILED',
    }
    
    return status_map.get(current_status, 'FAILED')
