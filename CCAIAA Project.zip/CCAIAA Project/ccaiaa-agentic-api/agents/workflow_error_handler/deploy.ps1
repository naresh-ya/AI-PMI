# Deploy Workflow Error Handler Lambda

$ErrorActionPreference = "Stop"

$FUNCTION_NAME = "pmi-workflow-error-handler"
$REGION = "eu-west-1"
$PROFILE = "pmi-dev-developer"
$ROLE_ARN = "arn:aws:iam::603433800649:role/pmi-lambda-execution-role"

Write-Host "Deploying Workflow Error Handler Lambda..." -ForegroundColor Cyan

# Create deployment package
Write-Host "Creating deployment package..." -ForegroundColor Yellow
Compress-Archive -Path handler.py -DestinationPath workflow_error_handler.zip -Force

# Check if Lambda exists
$functionExists = $false
try {
    aws lambda get-function --function-name $FUNCTION_NAME --region $REGION --profile $PROFILE 2>$null
    $functionExists = $true
    Write-Host "Lambda function exists, updating code..." -ForegroundColor Yellow
} catch {
    Write-Host "Lambda function does not exist, creating..." -ForegroundColor Yellow
}

if ($functionExists) {
    # Update existing function
    aws lambda update-function-code `
        --function-name $FUNCTION_NAME `
        --zip-file fileb://workflow_error_handler.zip `
        --region $REGION `
        --profile $PROFILE
    
    Write-Host "Waiting for function to be updated..." -ForegroundColor Yellow
    Start-Sleep -Seconds 5
    
    # Update configuration
    aws lambda update-function-configuration `
        --function-name $FUNCTION_NAME `
        --runtime python3.10 `
        --handler handler.lambda_handler `
        --timeout 60 `
        --memory-size 256 `
        --environment "Variables={REQUESTS_TABLE=pmi-agentic-ai-requests,REGION=eu-west-1}" `
        --region $REGION `
        --profile $FUNCTION
_PROFILE
} else {
    # Create new function
    aws lambda create-function `
        --function-name $FUNCTION_NAME `
        --runtime python3.10 `
        --role $ROLE_ARN `
        --handler handler.lambda_handler `
        --zip-file fileb://workflow_error_handler.zip `
        --timeout 60 `
        --memory-size 256 `
        --environment "Variables={REQUESTS_TABLE=pmi-agentic-ai-requests,REGION=eu-west-1}" `
        --region $REGION `
        --profile $PROFILE
}

Write-Host "Lambda deployed successfully!" -ForegroundColor Green

# Clean up
Remove-Item workflow_error_handler.zip -ErrorAction SilentlyContinue
