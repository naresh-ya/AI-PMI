"""
Human-in-the-Loop Web Interface for PMI Agentic AI Platform

Provides web interface for human reviewers to interact with AI agents,
review outputs, provide feedback, and make approval decisions.
"""

import json
import logging
from typing import Dict, Any, List, Optional
import boto3
from datetime import datetime
import os

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

class HITLWebInterface:
    """Web interface for human-in-the-loop interactions"""
    
    def __init__(self):
        self.hitl_table = dynamodb.Table('pmi-agentic-ai-hitl')
        self.requests_table = dynamodb.Table('pmi-agentic-ai-requests')
        
    def lambda_handler(self, event: Dict[str, Any], context: Any) -> Dict[str, Any]:
        """
        Lambda handler for HITL web interface API
        
        Handles:
        - GET /hitl/dashboard - Get reviewer dashboard
        - GET /hitl/review/{hitl_id} - Get specific review details
        - POST /hitl/decision/{hitl_id} - Submit review decision
        - GET /hitl/pending/{reviewer_id} - Get pending reviews for reviewer
        """
        
        try:
            http_method = event.get('httpMethod', 'GET')
            path = event.get('path', '')
            path_params = event.get('pathParameters', {}) or {}
            query_params = event.get('queryStringParameters', {}) or {}
            body = event.get('body')
            
            if body:
                body = json.loads(body)
            
            # Route requests
            if path == '/hitl/dashboard':
                return self.get_dashboard(query_params)
            elif path.startswith('/hitl/review/'):
                hitl_id = path_params.get('hitl_id')
                return self.get_review_details(hitl_id)
            elif path.startswith('/hitl/decision/') and http_method == 'POST':
                hitl_id = path_params.get('hitl_id')
                return self.submit_decision(hitl_id, body)
            elif path.startswith('/hitl/pending/'):
                reviewer_id = path_params.get('reviewer_id')
                return self.get_pending_reviews(reviewer_id)
            else:
                return self.create_response(404, {'error': 'Endpoint not found'})
                
        except Exception as e:
            logger.error(f"Error in HITL web interface: {str(e)}")
            return self.create_response(500, {'error': 'Internal server error'})
    
    def get_dashboard(self, query_params: Dict[str, Any]) -> Dict[str, Any]:
        """Get reviewer dashboard with summary metrics"""
        
        reviewer_id = query_params.get('reviewer_id')
        
        try:
            # Get all pending reviews
            if reviewer_id:
                response = self.hitl_table.scan(
                    FilterExpression='contains(human_reviewers, :reviewer) AND #status = :status',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':reviewer': reviewer_id,
                        ':status': 'pending'
                    }
                )
            else:
                response = self.hitl_table.scan(
                    FilterExpression='#status = :status',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={':status': 'pending'}
                )
            
            pending_reviews = response.get('Items', [])
            
            # Calculate dashboard metrics
            dashboard_data = {
                'total_pending': len(pending_reviews),
                'by_priority': {
                    'urgent': len([r for r in pending_reviews if r['priority'] == 'urgent']),
                    'high': len([r for r in pending_reviews if r['priority'] == 'high']),
                    'medium': len([r for r in pending_reviews if r['priority'] == 'medium']),
                    'low': len([r for r in pending_reviews if r['priority'] == 'low'])
                },
                'by_agent': {},
                'overdue': len([
                    r for r in pending_reviews 
                    if datetime.fromisoformat(r['escalation_time']) < datetime.now()
                ]),
                'recent_reviews': pending_reviews[:10]  # Most recent 10
            }
            
            # Group by agent
            for review in pending_reviews:
                agent = review['agent_name']
                if agent not in dashboard_data['by_agent']:
                    dashboard_data['by_agent'][agent] = 0
                dashboard_data['by_agent'][agent] += 1
            
            return self.create_response(200, dashboard_data)
            
        except Exception as e:
            logger.error(f"Error getting dashboard: {str(e)}")
            return self.create_response(500, {'error': 'Failed to load dashboard'})
    
    def get_review_details(self, hitl_id: str) -> Dict[str, Any]:
        """Get detailed information for a specific review"""
        
        try:
            # Get HITL record
            hitl_response = self.hitl_table.get_item(Key={'hitl_id': hitl_id})
            
            if 'Item' not in hitl_response:
                return self.create_response(404, {'error': 'Review not found'})
            
            hitl_record = hitl_response['Item']
            
            # Get related request details
            request_response = self.requests_table.get_item(
                Key={'request_id': hitl_record['request_id']}
            )
            
            request_details = request_response.get('Item', {})
            
            # Prepare comprehensive review data
            review_data = {
                'hitl_details': hitl_record,
                'request_context': request_details,
                'agent_output': hitl_record.get('agent_output', {}),
                'review_guidelines': self.get_review_guidelines(hitl_record['agent_name']),
                'time_remaining': self.calculate_time_remaining(hitl_record['escalation_time']),
                'review_history': self.get_review_history(hitl_record['request_id'])
            }
            
            return self.create_response(200, review_data)
            
        except Exception as e:
            logger.error(f"Error getting review details: {str(e)}")
            return self.create_response(500, {'error': 'Failed to load review details'})
    
    def submit_decision(self, hitl_id: str, decision_data: Dict[str, Any]) -> Dict[str, Any]:
        """Submit human decision for a review"""
        
        try:
            reviewer_id = decision_data.get('reviewer_id')
            decision = decision_data.get('decision')  # approve/reject/revise
            feedback = decision_data.get('feedback', {})
            rationale = decision_data.get('rationale', '')
            
            # Validate decision
            if decision not in ['approve', 'reject', 'revise']:
                return self.create_response(400, {'error': 'Invalid decision type'})
            
            # Update HITL record
            self.hitl_table.update_item(
                Key={'hitl_id': hitl_id},
                UpdateExpression="""
                    SET #status = :status,
                        decision = :decision,
                        human_feedback = :feedback,
                        decision_rationale = :rationale,
                        completed_at = :completed_at,
                        completed_by = :completed_by
                """,
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':status': 'completed',
                    ':decision': decision,
                    ':feedback': feedback,
                    ':rationale': rationale,
                    ':completed_at': datetime.now().isoformat(),
                    ':completed_by': reviewer_id
                }
            )
            
            # Trigger workflow continuation
            self.trigger_workflow_continuation(hitl_id, decision, feedback)
            
            return self.create_response(200, {
                'message': 'Decision submitted successfully',
                'decision': decision,
                'hitl_id': hitl_id
            })
            
        except Exception as e:
            logger.error(f"Error submitting decision: {str(e)}")
            return self.create_response(500, {'error': 'Failed to submit decision'})
    
    def get_pending_reviews(self, reviewer_id: str) -> Dict[str, Any]:
        """Get all pending reviews for a specific reviewer"""
        
        try:
            response = self.hitl_table.scan(
                FilterExpression='contains(human_reviewers, :reviewer) AND #status = :status',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':reviewer': reviewer_id,
                    ':status': 'pending'
                }
            )
            
            pending_reviews = response.get('Items', [])
            
            # Sort by priority and creation time
            priority_order = {'urgent': 0, 'high': 1, 'medium': 2, 'low': 3}
            pending_reviews.sort(key=lambda x: (
                priority_order.get(x['priority'], 4),
                x['created_at']
            ))
            
            return self.create_response(200, {
                'pending_reviews': pending_reviews,
                'count': len(pending_reviews)
            })
            
        except Exception as e:
            logger.error(f"Error getting pending reviews: {str(e)}")
            return self.create_response(500, {'error': 'Failed to get pending reviews'})
    
    def get_review_guidelines(self, agent_name: str) -> Dict[str, Any]:
        """Get review guidelines specific to each agent type"""
        
        guidelines = {
            'master_researcher': {
                'focus_areas': [
                    'Research strategy comprehensiveness',
                    'Source credibility and relevance',
                    'Compliance with PMI research standards',
                    'Potential access or confidentiality issues'
                ],
                'approval_criteria': [
                    'All required research domains covered',
                    'Realistic timeline and resource allocation', 
                    'No compliance risks identified',
                    'Clear success metrics defined'
                ],
                'common_issues': [
                    'Insufficient government source coverage',
                    'Missing PMI-specific context',
                    'Unrealistic timeline expectations'
                ]
            },
            'master_drafter': {
                'focus_areas': [
                    'Content accuracy and compliance',
                    'Tone and messaging alignment',
                    'Structure and flow',
                    'Evidence integration quality'
                ],
                'approval_criteria': [
                    'Fully compliant with regulations',
                    'Appropriate tone for audience',
                    'Strong evidence-based arguments',
                    'Clear recommendations and actions'
                ],
                'common_issues': [
                    'Promotional language detected',
                    'Insufficient evidence support',
                    'Unclear or weak recommendations'
                ]
            },
            'master_reviewer': {
                'focus_areas': [
                    'Final compliance verification',
                    'Risk assessment accuracy',
                    'Quality assurance completeness',
                    'Stakeholder impact analysis'
                ],
                'approval_criteria': [
                    'Zero compliance violations',
                    'Comprehensive risk mitigation',
                    'Executive-ready quality',
                    'Strategic alignment confirmed'
                ],
                'common_issues': [
                    'Missed compliance requirements',
                    'Inadequate risk assessment',
                    'Quality standards not met'
                ]
            }
        }
        
        return guidelines.get(agent_name, {
            'focus_areas': ['General review required'],
            'approval_criteria': ['Standard quality checks'],
            'common_issues': []
        })
    
    def calculate_time_remaining(self, escalation_time: str) -> Dict[str, Any]:
        """Calculate time remaining until escalation"""
        
        try:
            escalation_dt = datetime.fromisoformat(escalation_time)
            now = datetime.now()
            
            if escalation_dt > now:
                time_diff = escalation_dt - now
                hours_remaining = time_diff.total_seconds() / 3600
                
                return {
                    'hours_remaining': round(hours_remaining, 1),
                    'is_overdue': False,
                    'urgency_level': 'urgent' if hours_remaining < 2 else 'normal'
                }
            else:
                overdue_hours = (now - escalation_dt).total_seconds() / 3600
                return {
                    'hours_remaining': 0,
                    'hours_overdue': round(overdue_hours, 1),
                    'is_overdue': True,
                    'urgency_level': 'critical'
                }
                
        except Exception as e:
            logger.error(f"Error calculating time remaining: {str(e)}")
            return {
                'hours_remaining': 0,
                'is_overdue': True,
                'urgency_level': 'unknown'
            }
    
    def get_review_history(self, request_id: str) -> List[Dict[str, Any]]:
        """Get review history for a request"""
        
        try:
            response = self.hitl_table.scan(
                FilterExpression='request_id = :request_id',
                ExpressionAttributeValues={':request_id': request_id}
            )
            
            history = response.get('Items', [])
            
            # Sort by creation time
            history.sort(key=lambda x: x['created_at'])
            
            return history
            
        except Exception as e:
            logger.error(f"Error getting review history: {str(e)}")
            return []
    
    def trigger_workflow_continuation(self, hitl_id: str, decision: str, feedback: Dict[str, Any]):
        """Trigger continuation of the agentic workflow based on human decision"""
        
        # This would integrate with Step Functions or direct Lambda invocation
        # to continue the workflow with human feedback
        
        logger.info(f"Triggering workflow continuation for HITL {hitl_id} with decision: {decision}")
        
        # Implementation would depend on your orchestration choice
        # Could use Step Functions, SQS, or direct Lambda invocation
        
    def create_response(self, status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
        """Create standardized HTTP response"""
        
        return {
            'statusCode': status_code,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': json.dumps(body)
        }
