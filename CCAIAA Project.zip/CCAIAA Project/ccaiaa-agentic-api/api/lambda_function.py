import json
import boto3
from datetime import datetime
import decimal
from dateutil import parser

dynamodb = boto3.resource('dynamodb', region_name='eu-west-1')
table = dynamodb.Table('pmi-agentic-ai-requests')

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super().default(obj)

# Define all possible request statuses
ALL_STATUSES = {
    'INCOMPLETE_REQUEST': 0,
    'SUBMITTED': 0,
    'VALIDATION_FAILED': 0,
    'VALIDATION_COMPLETED': 0,
    'RESEARCH_IN_PROGRESS': 0,
    'RESEARCH_COMPLETED': 0,
    'RESEARCH_REVIEW_PENDING': 0,
    'RESEARCH_APPROVED': 0,
    'RESEARCH_REJECTED': 0,
    'RESEARCH_FAILED': 0,
    'RE_RESEARCH_IN_PROGRESS': 0,
    'DRAFTING_IN_PROGRESS': 0,
    'DRAFTING_COMPLETED': 0,
    'DRAFTING_FAILED': 0,
    'DRAFT_REVIEW_PENDING': 0,
    'DRAFT_APPROVED': 0,
    'DRAFT_REJECTED_REDRAFT': 0,
    'DRAFT_REJECTED_RERESEARCH': 0,
    'RE_DRAFTING_IN_PROGRESS': 0,
    'COMPLIANCE_REVIEW_IN_PROGRESS': 0,
    'COMPLIANCE_REVIEW_PASSED': 0,
    'COMPLIANCE_REVIEW_FAILED': 0,
    'CA_COMMUNICATION_PENDING': 0,
    'CA_COMMUNICATION_APPROVED': 0,
    'CA_COMMUNICATION_REJECTED': 0,
    'CA_FISCAL_PENDING': 0,
    'CA_FISCAL_APPROVED': 0,
    'CA_FISCAL_REJECTED': 0,
    'CA_REGULATORY_PENDING': 0,
    'CA_REGULATORY_APPROVED': 0,
    'CA_REGULATORY_REJECTED': 0,
    'CA_SCIENTIFIC_PENDING': 0,
    'CA_SCIENTIFIC_APPROVED': 0,
    'CA_SCIENTIFIC_REJECTED': 0,
    'LEGAL_APPROVAL_PENDING': 0,
    'LEGAL_APPROVED': 0,
    'LEGAL_REJECTED': 0,
    'REVIEW_APPROVAL_BY_REQUESTOR': 0,
    'COMPLETED': 0,
    'CANCELLED': 0
}

# Define admin users who can access all requests regardless of user_id
ADMIN_USERS = {'admin', 'system-admin'}


def is_admin_user(user_identifier):
    """Check if the provided user identifier is an admin user"""
    if user_identifier is None:
        return False
    # Normalize to lowercase for case-insensitive comparison
    return user_identifier.lower() in ADMIN_USERS


def lambda_handler(event, context):
    """
    Fetch all records from CURRENT MONTH from DynamoDB requests table
    Returns only specified fields, sorted by updated_at DESC
    Supports optional query parameter: ?user=<user_id> to filter by specific user
    If user=admin, returns all records. Otherwise returns only records for specified user.
    """
    try:
        # STEP 1: Extract user query parameter
        query_params = event.get('queryStringParameters') or {}
        user_filter = query_params.get('user')

        # Handle empty string user parameter (treat as no filter)
        if user_filter == '':
            user_filter = None

        # Check if the requested user is an admin
        is_user_admin = is_admin_user(user_filter)

        # Scan all items from DynamoDB
        # CORRECT approach - loop through ALL pages:
        items = []
        response = table.scan()
        items.extend(response.get('Items', []))

        # Keep fetching until no more pages
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            items.extend(response.get('Items', []))

        #response = table.scan()
        #items = response.get('Items', [])

        # Extract only required fields
        required_fields = [
            'request_id', 'topic', 'status', 'jurisdiction',
            'category', 'deadline', 'updated_at', 'user_id'
        ]

        # Filter records to include only required fields
        filtered_records = []
        for item in items:
            filtered_item = {field: item.get(field) for field in required_fields}
            filtered_records.append(filtered_item)

        # Filter records for CURRENT MONTH ONLY
        current_date = datetime.now()
        current_year = current_date.year
        current_month = current_date.month

        current_month_records = []
        for record in filtered_records:
            updated_at = record.get('updated_at')
            
            if updated_at is None:
                continue  # Skip records with no updated_at
            
            # Parse the date/timestamp
            try:
                if isinstance(updated_at, str):
                    # ISO date string
                    dt = parser.parse(updated_at)
                else:
                    # Unix timestamp
                    dt = datetime.fromtimestamp(updated_at)
                
                # Check if record is from current month
                if dt.year == current_year and dt.month == current_month:
                    current_month_records.append(record)
            except (ValueError, TypeError):
                continue  # Skip invalid dates

        # Use only current month records
        filtered_records = current_month_records

        # STEP 5: Apply user filter if specified and user is NOT admin
        if user_filter is not None and not is_user_admin:
            # Normalize user_filter to lowercase for case-insensitive matching
            user_filter_lower = user_filter.lower()
            filtered_records = [
                record for record in filtered_records
                if (record.get('user_id') or '').lower() == user_filter_lower
            ]

        # STEP 6: Count status occurrences (for filtered records only)
        status_counts = ALL_STATUSES.copy()  # Copy template with all statuses

        for record in filtered_records:
            status = record.get('status')
            if status and status in status_counts:
                status_counts[status] += 1


        # Sort by updated_at (descending - latest first)
        # Handle ISO date strings, timestamps, and None values
        def sort_key(x):
            val = x.get('updated_at')
            if val is None:
                return float('-inf')
            # If it's a string, parse it as ISO date
            if isinstance(val, str):
                try:
                    dt = parser.parse(val)
                    return dt.timestamp()
                except (ValueError, TypeError):
                    try:
                        return float(val)
                    except (ValueError, TypeError):
                        return float('-inf')
            # If it's already a number, use it
            try:
                return float(val)
            except (ValueError, TypeError):
                return float('-inf')

        filtered_records.sort(key=sort_key, reverse=True)

        # Return response with all current month records
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'records': filtered_records,
                'count': len(filtered_records),
                **status_counts,  # This unpacks all status counts into the response
                'month': f"{current_year}-{current_month:02d}"
            }, cls=DecimalEncoder)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e)
            })
        }