"""
CREATE REQUEST API - DynamoDB Only Handler
Database design:
  DynamoDB — ALL data (form fields, workflow, timeline, metadata)
  S3       — File uploads only

Endpoints:
- POST /requests              – Create new document generation request
- GET  /requests/{request_id} – Get request status with full details

All form fields (29 total) stored in DynamoDB requests table:
1-5:   Core IDs (request_id, user_id, category, use_case, status)
6-10:  Document Properties (document_type, topic, jurisdiction, addressed_to, cc_to)
11-15: Content Details (topic_of_letter, deadline, target_audience, background, sources)
16-20: Requirements (stakeholders, tone_requirements, target_language, priority, others)
21-23: Special Data (annexure, uploaded_files, workflow_execution_arn)
24-29: Status & Tracking (status, progress_pct, current_agent, error, timestamps)
"""

import json
import logging
import uuid
import os
from typing import Dict, Any, Optional, List, Union
from datetime import datetime, timedelta, timezone
from enum import Enum
import decimal

import boto3
from botocore.exceptions import ClientError
from pydantic import BaseModel, Field, validator

logger = logging.getLogger()
logger.setLevel(logging.DEBUG if os.getenv('DEBUG_MODE', 'false').lower() == 'true' else logging.INFO)

# AWS Clients
dynamodb = boto3.resource('dynamodb', region_name=os.getenv('AWS_REGION', 'eu-west-1'))
stepfunctions = boto3.client('stepfunctions', region_name=os.getenv('AWS_REGION', 'eu-west-1'))
s3 = boto3.client('s3', region_name=os.getenv('AWS_REGION', 'eu-west-1'))
lambda_client = boto3.client('lambda', region_name=os.getenv('AWS_REGION', 'eu-west-1'))

# Environment variables
REQUESTS_TABLE = os.getenv('DYNAMODB_REQUESTS_TABLE', 'pmi-agentic-ai-requests')
USERS_TABLE = os.getenv('DYNAMODB_USERS_TABLE', 'pmi-agentic-ai-users')
STATE_MACHINE_ARN = os.getenv('STATE_MACHINE_ARN')
DOCUMENT_BUCKET = os.getenv('DOCUMENT_BUCKET')
CORS_ORIGIN = os.getenv('CORS_ORIGIN', '*')

# Safe Duplicate Validation Toggle (controlled via Lambda Environment Variables)
ENABLE_DUPLICATE_CHECK = os.getenv('ENABLE_DUPLICATE_CHECK', 'true').lower() == 'true'

# Re-draft Lambda used by the API-driven post-legal-review redraft loop (Option A).
# This is the SAME redraft function the Step Function's ReDraft state invokes; we call it
# directly (synchronously) since the workflow execution has already ended by review time.
REDRAFT_LAMBDA_NAME = os.getenv('REDRAFT_LAMBDA_NAME', 'pmi-draft-redraft-client-demo2')

# DynamoDB Tables
requests_table = dynamodb.Table(REQUESTS_TABLE)
users_table = dynamodb.Table(USERS_TABLE)

# ============================================================================
# ENUMS
# ============================================================================

class Jurisdiction(str, Enum):
    INDIA = "India"
    THAILAND = "Thailand"
    VIETNAM = "Vietnam"
    BHUTAN = "Bhutan"
    BANGLADESH = "Bangladesh"
    MALDIVES = "Maldives"
    NEPAL = "Nepal"
    CAMBODIA = "Cambodia"

class Priority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class RequestStatus(str, Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    PROCESSING = "processing"
    AWAITING_REVIEW = "awaiting_review"
    IN_REVIEW = "in_review"
    REVISING = "revising"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class Language(str, Enum):
    ENGLISH = "English"
    THAI = "Thai"
    VIETNAMESE = "Vietnamese"
    BENGALI = "Bengali"
    HINDI = "Hindi"

# ============================================================================
# PYDANTIC REQUEST MODELS
# ============================================================================

class CreateRequestModel(BaseModel):
    """Complete request model with all form fields"""

    document_type: str = Field(..., description="Type of document")
    category: str = Field(default="regulatory", description="Request category")
    use_case: str = Field(default="government_engagement", description="Business use case")

    topic: str = Field(..., min_length=5, max_length=500, description="Main topic/subject")
    topic_of_letter: str = Field(default="", description="Letter-specific topic")
    jurisdiction: str = Field(..., description="Geographic jurisdiction")
    background: str = Field(..., min_length=20, max_length=5000, description="Background information")

    target_audience: str = Field(default="", description="Target audience")
    deadline: str = Field(..., description="Completion deadline (ISO format)")

    addressed_to: Optional[Any] = Field(default=None, description="Primary recipient")
    cc_to: Optional[Any] = Field(default=None, description="CC recipients")

    sources: Optional[Any] = Field(default=None, description="Research sources")
    stakeholders: Optional[Any] = Field(default=None, description="Key stakeholders")

    tone_requirements: Optional[Any] = Field(default=None, description="Tone requirements")
    target_language: str = Field(default="English", description="Document language")
    priority: str = Field(default="medium", description="Request priority")

    others: Optional[Any] = Field(default=None, description="Additional requirements")
    annexure: Optional[Any] = Field(default=None, description="Annexures")

    uploaded_files: Optional[List[str]] = Field(default_factory=list, description="S3 file keys")
    reference_urls: Optional[List[str]] = Field(default_factory=list, description="Reference URLs")
    user_id: Optional[str] = Field(default="anonymous", description="User ID")
    
    # Bypass override flag
    bypass_duplicate_check: bool = Field(default=False, description="Forces request creation even if similar topic exists")
    
    # Topic Relevance Check toggle
    enable_topic_relevance_check: bool = Field(default=False, description="Enables LLM-based topic relevance filtering")

    class Config:
        use_enum_values = True

class CreateRequestResponseModel(BaseModel):
    request_id: str
    status: str
    message: str
    execution_arn: str
    created_at: str
    submitted_at: str

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def generate_request_id() -> str:
    """Generate unique request ID with timestamp"""
    timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
    unique_suffix = str(uuid.uuid4())[:8]
    return f"req_{timestamp}_{unique_suffix}"

def calculate_progress(status: str) -> Dict[str, Any]:
    """Calculate progress percentage based on status"""
    progress_map = {
        "draft": 0,
        "submitted": 10,
        "processing": 40,
        "awaiting_review": 60,
        "in_review": 75,
        "revising": 80,
        "completed": 100,
        "failed": 0,
        "cancelled": 0,
    }

    percentage = progress_map.get(status, 0)
    return {
        "percentage": percentage,
        "current_step": status,
        "status_description": f"Current status: {status}",
        "estimated_remaining_minutes": max(0, (100 - percentage) // 10),
    }

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super(DecimalEncoder, self).default(obj)

def _is_truthy(value) -> bool:
    """Case-insensitive truthy check for JSON flags (bool, str, int).
    Handles: true/True/"true"/"True"/"TRUE"/1/"1"/"yes" → True
    Everything else → False
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ('true', '1', 'yes')
    if isinstance(value, (int, float)):
        return bool(value)
    return False


def error_response(
    status_code: int,
    error_code: str,
    message: str,
    details: Optional[Dict] = None,
    request_id: Optional[str] = None
) -> Dict[str, Any]:
    """Standardized error response"""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": CORS_ORIGIN,
            "X-Request-ID": request_id or "unknown",
        },
        "body": json.dumps({
            "error": {
                "code": error_code,
                "message": message,
                "timestamp": datetime.utcnow().isoformat(),
                "details": details or {}
            }
        }, cls=DecimalEncoder)
    }

def success_response(
    status_code: int,
    data: Dict[str, Any],
    request_id: Optional[str] = None
) -> Dict[str, Any]:
    """Standardized success response"""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": CORS_ORIGIN,
            "X-Request-ID": request_id or "unknown",
            "Cache-Control": "no-cache",
        },
        "body": json.dumps(data, cls=DecimalEncoder)
    }

# ============================================================================
# DYNAMODB REPOSITORY - DynamoDB Only
# ============================================================================

class DynamoDBRequestRepository:
    """Handles all DynamoDB operations for requests"""

    @staticmethod
    def create_request(
        request_id: str,
        user_id: str,
        request_data: CreateRequestModel,
        workflow_execution_arn: str,
    ) -> bool:
        """
        Persist ALL request data to DynamoDB:
        - All 29 form fields
        - Metadata (status, timestamps)
        - Workflow tracking
        - File references
        """
        try:
            now_iso = datetime.utcnow().isoformat() + 'Z'
            now_epoch = int(datetime.utcnow().timestamp())

            # Prepare DynamoDB item with ALL form fields
            item = {
                'request_id': request_id,
                'user_id': user_id,
                'status': 'SUBMITTED',
                'progress_pct': 10,
                'progress_step': 'SUBMITTED',
                'current_agent': None,

                # Form fields (all stored in DynamoDB)
                'document_type': request_data.document_type,
                'category': request_data.category,
                'use_case': request_data.use_case,

                'topic': request_data.topic,
                'topic_of_letter': request_data.topic_of_letter,
                'jurisdiction': request_data.jurisdiction,
                'background': request_data.background,

                'target_audience': request_data.target_audience,
                'deadline': request_data.deadline,

                'addressed_to': request_data.addressed_to,
                'cc_to': request_data.cc_to,

                'sources': request_data.sources or [],
                'stakeholders': request_data.stakeholders or [],

                'tone_requirements': request_data.tone_requirements,
                'target_language': request_data.target_language,
                'priority': request_data.priority,

                'others': request_data.others,
                'annexure': request_data.annexure or [],

                'uploaded_files': request_data.uploaded_files or [],
                'reference_urls': request_data.reference_urls or [],

                'workflow_execution_arn': workflow_execution_arn or '',
                'enable_topic_relevance_check': request_data.enable_topic_relevance_check,

                'created_at': int(datetime.utcnow().timestamp()),
                'submitted_at': now_iso,
                'updated_at': now_iso,
                'completed_at': None,
                'error': None,

                'timeline': [
                    {
                        'timestamp': now_iso,
                        'event_type': 'REQUEST_CREATED',
                        'event_data': {
                            'status': 'submitted',
                            'initiated_by': 'API'
                        }
                    }
                ],

                'activity_logs': [
                    {
                        'timestamp': now_epoch,
                        'action': 'CREATE_REQUEST',
                        'user_id': user_id,
                        'details': {
                            'document_type': request_data.document_type,
                            'jurisdiction': request_data.jurisdiction,
                            'priority': request_data.priority,
                        }
                    }
                ]
            }

            # Write to DynamoDB
            requests_table.put_item(Item=item)
            logger.info("Request created in DynamoDB: %s for user: %s", request_id, user_id)
            return True

        except ClientError as e:
            logger.error("DynamoDB write error: %s", e)
            raise

    @staticmethod
    def get_request(request_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve complete request from DynamoDB"""
        try:
            response = requests_table.get_item(Key={'request_id': request_id})
            item = response.get('Item')

            if not item:
                logger.warning("Request not found: %s", request_id)
                return None

            logger.info("Retrieved request from DynamoDB: %s", request_id)
            return item

        except ClientError as e:
            logger.error("DynamoDB read error: %s", e)
            return None

    @staticmethod
    def update_request_status(
        request_id: str,
        status: str,
        progress_pct: int = 0,
        current_agent: Optional[str] = None,
    ) -> bool:
        """Update request status in DynamoDB"""
        try:
            now_iso = datetime.utcnow().isoformat() + 'Z'

            # Update attributes
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression='SET #status = :status, progress_pct = :progress_pct, progress_step = :progress_step, current_agent = :current_agent, updated_at = :updated_at',
                ExpressionAttributeNames={
                    '#status': 'status'
                },
                ExpressionAttributeValues={
                    ':status': status,
                    ':progress_pct': progress_pct,
                    ':progress_step': status,
                    ':current_agent': current_agent,
                    ':updated_at': now_iso,
                }
            )

            logger.info("Updated request status in DynamoDB: %s -> %s", request_id, status)
            return True

        except ClientError as e:
            logger.error("DynamoDB update error: %s", e)
            return False

    @staticmethod
    def append_timeline_event(
        request_id: str,
        event_type: str,
        event_data: Dict[str, Any],
    ) -> bool:
        """Append event to request timeline in DynamoDB"""
        try:
            now_iso = datetime.utcnow().isoformat() + 'Z'

            event = {
                'timestamp': now_iso,
                'event_type': event_type,
                'event_data': event_data
            }

            # Append to timeline list
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression='SET timeline = list_append(timeline, :event)',
                ExpressionAttributeValues={
                    ':event': [event]
                }
            )

            logger.info("Appended timeline event to request: %s", request_id)
            return True

        except ClientError as e:
            logger.error("DynamoDB timeline append error: %s", e)
            return False

# ============================================================================
# DUP MATCHING HELPERS
# ============================================================================

from difflib import SequenceMatcher

def get_existing_requests_by_jurisdiction(jurisdiction: str) -> List[Dict[str, Any]]:
    """
    Retrieves request summaries for a given jurisdiction.
    Uses ProjectionExpression to minimize payload size and read consumption.
    """
    try:
        response = requests_table.scan(
            FilterExpression=boto3.dynamodb.conditions.Attr('jurisdiction').eq(jurisdiction),
            ProjectionExpression="request_id, topic, jurisdiction, #status, created_at, user_id",
            ExpressionAttributeNames={"#status": "status"}
        )
        return response.get('Items', [])
    except ClientError as e:
        logger.error("Error scanning DynamoDB table: %s", e)
        return []

def get_similarity_score(topic_a: str, topic_b: str) -> float:
    """
    Computes similarity score between two topics using standard SequenceMatcher ratio.
    """
    normalized_a = topic_a.strip().lower()
    normalized_b = topic_b.strip().lower()
    
    if normalized_a == normalized_b:
        return 1.0
        
    return SequenceMatcher(None, normalized_a, normalized_b).ratio()

# ============================================================================
# HANDLER - CREATE REQUEST (POST /requests)
# ============================================================================

def handle_create_request(event: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """
    Handle POST /requests - Create new document generation request
    All form fields saved to DynamoDB
    """

    try:
        # 1. Extract and parse request body
        if "body" not in event or not event["body"]:
            return error_response(
                400,
                "EMPTY_REQUEST_BODY",
                "Request body is required",
                request_id=request_id
            )

        try:
            body = json.loads(event["body"])
        except json.JSONDecodeError:
            return error_response(
                400,
                "INVALID_JSON",
                "Request body must be valid JSON",
                request_id=request_id
            )

        # 2. Draft vs Submit Gate (category-agnostic, applies to all 6 categories)
        # UI sends "isDraft": true to save without triggering the pipeline.
        # UI sends "isSubmit": true to trigger the full research + draft pipeline.
        # If neither flag present → default to submit (backward compatibility).
        is_draft = _is_truthy(body.get('isDraft'))
        is_submit = _is_truthy(body.get('isSubmit'))

        if is_draft and not is_submit:
            # Save as draft — persist to DynamoDB but do NOT trigger Step Functions
            generated_request_id = generate_request_id()
            try:
                request_model = CreateRequestModel(**body)
            except Exception as e:
                return error_response(400, "VALIDATION_ERROR",
                                      "Request payload validation failed", details=str(e),
                                      request_id=request_id)
            try:
                DynamoDBRequestRepository.create_request(
                    request_id=generated_request_id,
                    user_id=request_model.user_id or "anonymous",
                    request_data=request_model,
                    workflow_execution_arn="",
                )
                # Override status to DRAFT (create_request sets SUBMITTED by default)
                requests_table.update_item(
                    Key={'request_id': generated_request_id},
                    UpdateExpression='SET #status = :s, progress_pct = :p, progress_step = :ps',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':s': 'DRAFT',
                        ':p': 0,
                        ':ps': 'DRAFT',
                    }
                )
            except Exception as e:
                logger.error("Failed to save draft: %s", e)
                return error_response(500, "DATABASE_ERROR",
                                      f"Failed to save draft: {e}", request_id=request_id)

            logger.info("Request saved as DRAFT: %s (pipeline NOT triggered)", generated_request_id)
            return success_response(201, {
                "request_id": generated_request_id,
                "status": "draft",
                "message": "Request saved as draft. Submit to trigger processing.",
            }, request_id=generated_request_id)

        # 3. Validate request payload using Pydantic model (submit flow)
        try:
            request_model = CreateRequestModel(**body)
        except Exception as e:
            return error_response(
                400,
                "VALIDATION_ERROR",
                "Request payload validation failed",
                details=str(e),
                request_id=request_id
            )

        # 2b. Safe Duplicate Check Block
        if ENABLE_DUPLICATE_CHECK and not request_model.bypass_duplicate_check:
            historical_requests = get_existing_requests_by_jurisdiction(request_model.jurisdiction)
            
            best_match = None
            highest_score = 0.0
            threshold = 0.8
            
            for req in historical_requests:
                score = get_similarity_score(request_model.topic, req.get('topic', ''))
                if score >= threshold and score > highest_score:
                    highest_score = score
                    best_match = {
                        "request_id": req.get("request_id"),
                        "topic": req.get("topic"),
                        "jurisdiction": req.get("jurisdiction"),
                        "status": req.get("status"),
                        "created_at": req.get("created_at"),
                        "user_id": req.get("user_id", "anonymous"),
                        "similarity_score": round(score, 4)
                    }
                    
            if best_match:
                logger.info(
                    "Found similar request %s with score %.4f. Aborting and returning 409 Conflict.",
                    best_match["request_id"], highest_score
                )
                return {
                    "statusCode": 409,
                    "headers": {
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Origin": CORS_ORIGIN,
                    },
                    "body": json.dumps({
                        "status": "SIMILAR_REQUEST_EXISTS",
                        "message": f"Similar requests were found for {request_model.jurisdiction}.",
                        "existing_requests": [best_match]
                    }, cls=DecimalEncoder)
                }

        # 3. Generate system fields
        now_iso = datetime.utcnow().isoformat() + 'Z'
        now_epoch = int(datetime.utcnow().timestamp())
        generated_request_id = generate_request_id()
        status = "SUBMITTED"
        progress = calculate_progress(status)

        # 4. Persist ALL request data to DynamoDB
        try:
            DynamoDBRequestRepository.create_request(
                request_id=generated_request_id,
                user_id=request_model.user_id or "anonymous",
                request_data=request_model,
                workflow_execution_arn="",
            )
        except Exception as db_error:
            logger.error("DynamoDB persist error: %s", db_error)
            return error_response(
                500,
                "DATABASE_ERROR",
                "Failed to persist request to DynamoDB",
                details=str(db_error),
                request_id=request_id
            )

        # 5. Start Step Functions execution (if configured)
        execution_arn = ""
        if STATE_MACHINE_ARN:
            try:
                sf_response = stepfunctions.start_execution(
                    stateMachineArn=STATE_MACHINE_ARN,
                    input=json.dumps({
                        "request_id": generated_request_id,
                        "request_data": body
                    })
                )
                execution_arn = sf_response.get("executionArn")

                # Update DynamoDB with execution ARN
                requests_table.update_item(
                    Key={'request_id': generated_request_id},
                    UpdateExpression='SET workflow_execution_arn = :arn',
                    ExpressionAttributeValues={':arn': execution_arn}
                )

            except ClientError as sf_error:
                logger.error("Step Functions error: %s", sf_error)
                return error_response(
                    500,
                    "WORKFLOW_START_FAILED",
                    "Failed to start workflow execution",
                    details=str(sf_error),
                    request_id=request_id
                )

        # 6. Return success response
        response_model = CreateRequestResponseModel(
            request_id=generated_request_id,
            status=status,
            message="Request created successfully and saved to DynamoDB",
            execution_arn=execution_arn,
            created_at=str(now_epoch),
            submitted_at=str(now_epoch)
        )

        return success_response(
            201,
            response_model.model_dump(),
            request_id=request_id
        )

    except Exception as unexpected_error:
        logger.exception("Unhandled error in handle_create_request")
        return error_response(
            500,
            "INTERNAL_SERVER_ERROR",
            "An unexpected error occurred",
            details=str(unexpected_error),
            request_id=request_id
        )

# ============================================================================
# HANDLER - GET REQUEST STATUS (GET /requests/{request_id})
# ============================================================================

def handle_get_request(request_id: str) -> Dict[str, Any]:
    """
    Handle GET /requests/{request_id} - Get complete request from DynamoDB
    Exposes unique SharePoint references directly at the root for seamless UI integration.
    """
    try:
        if not request_id or not request_id.startswith('req_'):
            return error_response(400, 'INVALID_REQUEST_ID', 'Invalid request ID format', request_id=request_id)

        request_data = DynamoDBRequestRepository.get_request(request_id)
        if not request_data:
            return error_response(404, 'NOT_FOUND', f'Request {request_id} not found', request_id=request_id)

        # ─── INJECTED REFERENCE FILTERING & DEDUPLICATION ───
        research_output = request_data.get('research_output', {})
        citations = research_output.get('citations', []) if isinstance(research_output, dict) else []

        seen_urls = set()
        unique_references = []
        ref_idx = 1

        for citation in citations:
            url = citation.get('url', '').strip()
            title = citation.get('title', '').strip()

            # Include only SharePoint (internal KB document) links
            is_sharepoint = "sharepoint.com" in url.lower() or "pmicloud" in url.lower()

            if url and is_sharepoint:
                normalized_url = url.lower()
                if normalized_url not in seen_urls:
                    seen_urls.add(normalized_url)
                    unique_references.append({
                        "index": ref_idx,
                        "title": title or "SharePoint Document Reference",
                        "url": url,
                        "source": "PMI Internal Knowledge Base"
                    })
                    ref_idx += 1

        # Expose both the unique references list and total count directly at the root
        request_data['references'] = unique_references
        request_data['total_unique_references'] = len(unique_references)
        # ────────────────────────────────────────────────────

        # Calculate progress
        status = request_data.get('status', 'submitted')
        progress = calculate_progress(status)

        # Dynamically inject the UI progress bar percentage
        request_data['progress'] = progress

        logger.info(f"Retrieved request details with {len(unique_references)} references: {request_id}")
        # Return the entire DynamoDB object directly, exposing references, s3_bucket_URL, and all nested maps
        return success_response(200, request_data, request_id=request_id)

    except Exception as e:
        logger.error(f"Error retrieving request {request_id}: {str(e)}", exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Error retrieving request', request_id=request_id)


# ============================================================================
# HANDLER - GET UNIQUE KB CITATIONS (GET /requests/{request_id}/references)
# ============================================================================

def handle_get_request_references(request_id: str) -> Dict[str, Any]:
    """
    Handle GET /requests/{request_id}/references
    Retrieves and filters strictly unique SharePoint citations fetched by the KB researcher.
    """
    try:
        if not request_id or not request_id.startswith('req_'):
            return error_response(400, 'INVALID_REQUEST_ID', 'Invalid request ID format', request_id=request_id)

        # Retrieve request from DynamoDB projecting only research_output to save RCUs
        try:
            response = requests_table.get_item(
                Key={'request_id': request_id},
                ProjectionExpression="research_output"
            )
        except ClientError as db_err:
            logger.error("Failed to query database %s: %s", REQUESTS_TABLE, db_err)
            return error_response(500, 'DATABASE_ERROR', 'Failed to retrieve request records', request_id=request_id)

        item = response.get('Item')
        if not item or 'research_output' not in item:
            return error_response(404, 'REFERENCES_NOT_FOUND', 'References not ready yet for this request', request_id=request_id)

        # Extract nested references list compiled by Master Researcher
        research_output = item.get('research_output', {})
        citations = research_output.get('citations', []) if isinstance(research_output, dict) else []

        # Filter for SharePoint URLs and perform strict deduplication by URL
        seen_urls = set()
        unique_references = []
        ref_idx = 1

        for citation in citations:
            url = citation.get('url', '').strip()
            title = citation.get('title', '').strip()

            # Include only SharePoint (internal KB document) links
            is_sharepoint = "sharepoint.com" in url.lower() or "pmicloud" in url.lower()

            if url and is_sharepoint:
                normalized_url = url.lower()
                if normalized_url not in seen_urls:
                    seen_urls.add(normalized_url)
                    unique_references.append({
                        "index": ref_idx,
                        "title": title or "SharePoint Document Reference",
                        "url": url,
                        "source": "PMI Internal Knowledge Base"
                    })
                    ref_idx += 1

        logger.info("Found %d unique SharePoint references for request %s", len(unique_references), request_id)

        return success_response(200, {
            "request_id": request_id,
            "references": unique_references,
            "total_unique_references": len(unique_references)
        }, request_id=request_id)

    except Exception as e:
        logger.error(f"Error compiling unique references for {request_id}: {str(e)}", exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Error compiling references', request_id=request_id)


# ============================================================================
# HANDLER - CREATE REVIEW (POST /requests/{request_id}/reviews)
# ============================================================================

# The four review configurations the requestor can choose on "Proceed to reviews".
REVIEW_TYPES = {'no_review', 'ca_only', 'legal_only', 'ca_and_legal'}
# CA sub-reviews (user-selectable, run in parallel).
CA_SUBREVIEW_FIELDS = ['scientificReview', 'regulatoryReview', 'communicationReview', 'fiscalReview']


def generate_review_id() -> str:
    """Generate a unique review ID, e.g. rev_20260825120000_ab12cd34."""
    timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
    return f"rev_{timestamp}_{str(uuid.uuid4())[:8]}"


def _review_selected(body: Dict[str, Any], field: str) -> bool:
    """A per-review field counts as 'selected' when the frontend sends an active token
    (pending/waiting/selected/true/yes/in_progress). Empty string / None => not in scope."""
    val = body.get(field)
    if val is None:
        return False
    return str(val).strip().lower() in ('pending', 'waiting', 'selected', 'true', 'yes', 'in_progress')


# Maps a review_type to the users-table `role` responsible for that review.
# Only legal_only is wired up for now; CA cases resolve to None (assigned later,
# once their per-sub-review assignment logic is implemented).
REVIEW_TYPE_TO_ROLE = {
    'legal_only': 'legal_reviewer',
}


def resolve_assigned_reviewer(jurisdiction: Optional[str], review_type: str) -> Optional[str]:
    """Resolve the reviewer name(s) for a review, from the pmi-agentic-ai-users table.

    Matching rule:
      - country (users table) matches request jurisdiction, CASE-INSENSITIVELY
        (the users table stores mixed casing, e.g. 'Vietnam' and 'vietnam'), AND
      - role matches the role mapped from review_type (e.g. legal_only -> legal_reviewer).

    Returns:
      - None                    when review_type isn't mapped, no jurisdiction, or no match.
      - "Name"                  for a single match.
      - "Name A, Name B"        (comma-joined) for multiple matches.

    This enrichment is best-effort: ANY failure returns None so that review creation
    never breaks because of a lookup problem.
    """
    role = REVIEW_TYPE_TO_ROLE.get(review_type)
    if not role or not jurisdiction:
        return None

    target_country = jurisdiction.strip().lower()
    target_role = role.strip().lower()

    try:
        names: List[str] = []
        scan_kwargs = {
            'ProjectionExpression': '#n, country, #r',
            'ExpressionAttributeNames': {'#n': 'name', '#r': 'role'},
        }
        # Paginate defensively in case the users table grows beyond one scan page.
        while True:
            resp = users_table.scan(**scan_kwargs)
            for item in resp.get('Items', []):
                item_country = str(item.get('country', '')).strip().lower()
                item_role = str(item.get('role', '')).strip().lower()
                name = str(item.get('name', '')).strip()
                if item_country == target_country and item_role == target_role and name:
                    names.append(name)
            last_key = resp.get('LastEvaluatedKey')
            if not last_key:
                break
            scan_kwargs['ExclusiveStartKey'] = last_key

        if not names:
            return None
        return ', '.join(names)
    except Exception as e:
        logger.warning("resolve_assigned_reviewer failed (jurisdiction=%s, review_type=%s): %s",
                       jurisdiction, review_type, e)
        return None


# ── Reviewer dropdown (user picks the reviewer) ─────────────────────────────────────────────
# Maps a UI review category to the users-table `role` values it should list. The user selects a
# review type in the UI; the frontend calls GET /reviews/reviewers?review_category=... to fill a
# dropdown, and submits the chosen reviewer email on "Proceed to reviews".
REVIEW_CATEGORY_TO_ROLES = {
    'legal_review': ['legal_reviewer'],
    'ca_review': [
        'ca_scientific_human_reviewer',
        'ca_regulatory_human_reviewer',
        'ca_communication_human_reviewer',
        'ca_fiscal_human_reviewer',
        'ca_regional_focal_point',
    ],
}


def _normalize_review_category(value: str) -> Optional[str]:
    """Accept 'Legal_Review'/'legal'/'legal_only' etc. -> canonical 'legal_review' | 'ca_review'."""
    v = (value or '').strip().lower()
    if v in ('legal_review', 'legal', 'legal_only'):
        return 'legal_review'
    if v in ('ca_review', 'ca', 'ca_only', 'corporate_affairs'):
        return 'ca_review'
    return None


def handle_list_reviewers(review_category: str) -> Dict[str, Any]:
    """GET /reviews/reviewers?review_category=<Legal_Review|CA_Review>

    Populates the requestor's reviewer dropdown. Returns ALL reviewers whose role belongs to the
    given category (name + email + role + country). The list is jurisdiction-independent by
    design (cross-jurisdiction assignment is allowed). Read-only; additive."""
    category = _normalize_review_category(review_category)
    if not category:
        return error_response(400, 'INVALID_REVIEW_CATEGORY',
                              "review_category must be 'Legal_Review' or 'CA_Review'")

    target_roles = set(REVIEW_CATEGORY_TO_ROLES[category])
    reviewers = []
    try:
        scan_kwargs = {
            'ProjectionExpression': '#n, email, country, #r',
            'ExpressionAttributeNames': {'#n': 'name', '#r': 'role'},
        }
        while True:
            resp = users_table.scan(**scan_kwargs)
            for item in resp.get('Items', []):
                role = str(item.get('role', '')).strip().lower()
                email = str(item.get('email', '')).strip()
                name = str(item.get('name', '')).strip()
                if role in target_roles and email:
                    reviewers.append({
                        'name': name or email,
                        'email': email,
                        'role': role,
                        'country': str(item.get('country', '')).strip(),
                    })
            last_key = resp.get('LastEvaluatedKey')
            if not last_key:
                break
            scan_kwargs['ExclusiveStartKey'] = last_key
    except Exception as e:
        logger.error("Error listing reviewers (category=%s): %s", review_category, e, exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Failed to list reviewers')

    # Sort by display name for a stable dropdown order.
    reviewers.sort(key=lambda r: (r.get('name') or '').lower())
    return success_response(200, {
        'review_category': category,
        'count': len(reviewers),
        'reviewers': reviewers,
    })


def handle_create_review(request_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle POST /requests/{request_id}/reviews — the "Proceed to reviews" submit.

    Embeds a `review` object on the request record and advances the request status.
    The review lifecycle beyond submit (reviewer assignment + approve/reject/feedback) is a
    separate, later activity; this endpoint only creates the review and sets the initial state.

    Rules:
      - Request must be DRAFT_APPROVED (else 409).
      - Selection validity per review_type (else 400).
      - regionalFPReview is a backend-forced final CA gate (waits for the CA sub-reviews);
        it is never controlled by the frontend.
      - Per-review value vocabulary: "" (not in scope) | pending | waiting | approved |
        rejected | changes_requested.
    """
    try:
        if not request_id or not request_id.startswith('req_'):
            return error_response(400, 'INVALID_REQUEST_ID', 'Invalid request ID format', request_id=request_id)

        review_type = (body.get('review_type') or '').strip().lower()
        if review_type not in REVIEW_TYPES:
            return error_response(400, 'INVALID_REVIEW_TYPE',
                                  f"review_type must be one of {sorted(REVIEW_TYPES)}",
                                  request_id=request_id)

        requested_by = (body.get('requested_by') or body.get('user_id') or '').strip() or None

        ca_selected = {f: _review_selected(body, f) for f in CA_SUBREVIEW_FIELDS}
        legal_selected = _review_selected(body, 'legalReview')
        any_ca = any(ca_selected.values())

        # ── Validate the selection against the chosen case ──
        if review_type == 'no_review':
            if any_ca or legal_selected:
                return error_response(400, 'INVALID_SELECTION',
                                      "no_review must not select any CA sub-review or legal review",
                                      request_id=request_id)
        elif review_type == 'ca_only':
            if not any_ca:
                return error_response(400, 'INVALID_SELECTION',
                                      "ca_only requires at least one CA sub-review",
                                      request_id=request_id)
            if legal_selected:
                return error_response(400, 'INVALID_SELECTION',
                                      "ca_only must not select legal review",
                                      request_id=request_id)
        elif review_type == 'legal_only':
            if not legal_selected:
                return error_response(400, 'INVALID_SELECTION',
                                      "legal_only requires legal review",
                                      request_id=request_id)
            if any_ca:
                return error_response(400, 'INVALID_SELECTION',
                                      "legal_only must not select CA sub-reviews",
                                      request_id=request_id)
        elif review_type == 'ca_and_legal':
            if not any_ca:
                return error_response(400, 'INVALID_SELECTION',
                                      "ca_and_legal requires at least one CA sub-review",
                                      request_id=request_id)
            legal_selected = True  # legal is implied by the case

        has_ca = review_type in ('ca_only', 'ca_and_legal')

        # ── Derive per-review field statuses (backend is authoritative) ──
        fields = {}
        for f in CA_SUBREVIEW_FIELDS:
            fields[f] = 'pending' if (has_ca and ca_selected[f]) else ''
        # Regional Focal Point: mandatory final CA gate; waits until CA sub-reviews complete.
        fields['regionalFPReview'] = 'waiting' if has_ca else ''
        # Legal: active immediately for legal_only; queued behind CA for ca_and_legal.
        if review_type == 'legal_only':
            fields['legalReview'] = 'pending'
        elif review_type == 'ca_and_legal':
            fields['legalReview'] = 'waiting'
        else:
            fields['legalReview'] = ''

        now_iso = datetime.utcnow().isoformat() + 'Z'

        review_id = (body.get('review_id') or '').strip()
        if not review_id or review_id.upper() == 'NEW':
            review_id = generate_review_id()

        # ── Determine the assigned reviewer ──
        # NEW: the requestor explicitly picks the reviewer in the UI and the frontend sends
        # `reviewer_email` (the chosen dropdown value). When present, that email is the
        # AUTHORITATIVE assignment: we resolve its display name and set assigned_at, and the
        # reviewer queue/decision authorization keys on this email (cross-jurisdiction allowed).
        # When absent (backward-compat / no selection), we fall back to the previous behavior of
        # auto-resolving reviewer name(s) by jurisdiction+role. Both are best-effort: any failure
        # leaves the review creatable (never blocks the "Proceed to reviews" submit).
        # Explicit selection is wired for LEGAL only for now (matches the current flow).
        reviewer_email = (body.get('reviewer_email') or '').strip() or None
        assigned_to = None
        assigned_to_email = None
        assigned_at = None
        try:
            if reviewer_email and review_type == 'legal_only':
                _r_role, _r_country, _r_name = get_user_role_and_country(reviewer_email)
                assigned_to_email = reviewer_email
                assigned_to = _r_name or reviewer_email
                assigned_at = now_iso
            else:
                # Legacy auto-resolve by jurisdiction + role (unchanged behavior).
                req_record = requests_table.get_item(
                    Key={'request_id': request_id},
                    ProjectionExpression='jurisdiction',
                ).get('Item') or {}
                jurisdiction = req_record.get('jurisdiction')
                assigned_to = resolve_assigned_reviewer(jurisdiction, review_type)
        except Exception as lookup_err:
            logger.warning("Assigned-reviewer resolution failed for %s: %s", request_id, lookup_err)

        # ── Overall review status + request status for this case ──
        if review_type == 'no_review':
            review_status = 'completed'
            new_request_status = 'COMPLETED'
            completed_at = now_iso
        elif review_type == 'legal_only':
            review_status = 'in_progress'
            new_request_status = 'LEGAL_REVIEW_IN_PROGRESS'
            completed_at = None
        else:  # ca_only or ca_and_legal
            review_status = 'in_progress'
            new_request_status = 'CA_REVIEW_IN_PROGRESS'
            completed_at = None

        review_obj = {
            'review_id': review_id,
            'request_id': request_id,
            'review_type': review_type,
            'status': review_status,
            'scientificReview': fields['scientificReview'],
            'regulatoryReview': fields['regulatoryReview'],
            'communicationReview': fields['communicationReview'],
            'fiscalReview': fields['fiscalReview'],
            'regionalFPReview': fields['regionalFPReview'],
            'legalReview': fields['legalReview'],
            'requested_by': requested_by,
            'assigned_to': assigned_to,          # reviewer display name (from selected email, or auto-resolved)
            'assigned_to_email': assigned_to_email,  # AUTHORITATIVE assignment when user-selected; else None
            'assigned_at': assigned_at,          # set when the requestor explicitly picks a reviewer
            'started_at': now_iso,
            'completed_at': completed_at,
            'created_at': now_iso,
        }

        # ── Atomic write: only from DRAFT_APPROVED. Embed review + set status + active_review_id ──
        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression=('SET #status = :new, progress_step = :ps, updated_at = :ts, '
                                  '#rv = :review, active_review_id = :rid'),
                ConditionExpression='attribute_exists(request_id) AND #status = :expected',
                ExpressionAttributeNames={'#status': 'status', '#rv': 'review'},
                ExpressionAttributeValues={
                    ':new': new_request_status,
                    ':expected': 'DRAFT_APPROVED',
                    ':ps': new_request_status,
                    ':ts': now_iso,
                    ':review': review_obj,
                    ':rid': review_id,
                },
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                existing = DynamoDBRequestRepository.get_request(request_id)
                if not existing:
                    return error_response(404, 'NOT_FOUND', f'Request {request_id} not found',
                                          request_id=request_id)
                return error_response(409, 'INVALID_STATE_TRANSITION',
                                      f"Request must be in DRAFT_APPROVED to start review "
                                      f"(current: {existing.get('status')})",
                                      details={'current_status': existing.get('status')},
                                      request_id=request_id)
            raise

        # Audit trail (non-fatal)
        try:
            DynamoDBRequestRepository.append_timeline_event(
                request_id=request_id,
                event_type='REVIEW_SUBMITTED',
                event_data={
                    'review_id': review_id,
                    'review_type': review_type,
                    'status': new_request_status,
                    'initiated_by': requested_by or 'API',
                },
            )
        except Exception as timeline_err:
            logger.warning("Failed to append REVIEW_SUBMITTED timeline for %s: %s", request_id, timeline_err)

        logger.info("Review %s created for request %s (type=%s -> %s)",
                    review_id, request_id, review_type, new_request_status)

        response = dict(review_obj)
        response['request_status'] = new_request_status
        response['message'] = 'Review created successfully'
        return success_response(201, response, request_id=request_id)

    except Exception as e:
        logger.error(f"Error creating review for {request_id}: {str(e)}", exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Error creating review', request_id=request_id)


# ============================================================================
# REVIEWER APPROVAL FLOW (legal_only) — Option A (API-driven, no Step Function change)
# ============================================================================
#
# Routes added:
#   GET  /reviews/assigned?reviewer=<email>        — requests actionable by this reviewer
#   POST /requests/{request_id}/reviews/decision   — reviewer "Submit Review" (request_changes only)
#   POST /requests/{request_id}/complete           — requestor final "Proceed" -> COMPLETED
#   POST /requests/{request_id}/legal-redraft       — requestor sends reviewer comments to redraft
#
# State machine (legal_only) — per the finalized approver UI, the reviewer's ONLY action is
# "Submit Review" (request_changes). Approve/Reject were removed by product decision.
#   LEGAL_REVIEW_IN_PROGRESS
#     --request_changes->  REVIEW_CHANGES_REQUESTED --(/legal-redraft, repeatable)-->
#                          RE_DRAFT_IN_PROGRESS -> (redraft lambda) -> DRAFTING_COMPLETED
#                          --(/complete)--> COMPLETED   (legal already done; no re-review)

# Reverse of REVIEW_TYPE_TO_ROLE: a reviewer's role -> the review_type they act on, plus the
# per-review status field that must be actionable, and the request status that must be current.
ROLE_TO_REVIEW = {
    'legal_reviewer': {
        'review_type': 'legal_only',
        'field': 'legalReview',
        'request_status': 'LEGAL_REVIEW_IN_PROGRESS',
        # Per-review feedback attribute stored on the review object. Kept distinct per review so
        # CA reviews can add their own (e.g. fiscal_feedback, communication_feedback) later.
        'feedback_field': 'legal_feedback',
    },
}

# Per the finalized approver UI, the reviewer can ONLY request changes (add comments +
# "Submit Review"). Approve/Reject were removed by product decision. Kept as a set so the
# CA flow can extend it later if needed.
VALID_DECISIONS = {'request_changes'}


def get_user_role_and_country(email: str):
    """Look up a user's (role, country, name) from the users table by email.

    Mirrors the tolerant lookup used elsewhere: exact key first, then a lowercase-normalized
    retry (emails are stored lowercase). Returns (None, None, None) on miss or any error."""
    if not email:
        return None, None, None
    try:
        item = users_table.get_item(Key={'email': email}).get('Item')
        if not item:
            normalized = email.strip().lower()
            if normalized != email:
                item = users_table.get_item(Key={'email': normalized}).get('Item')
        if not item:
            return None, None, None
        role = item.get('role')
        country = item.get('country')
        name = item.get('name')
        return (
            role.strip() if isinstance(role, str) else role,
            country.strip() if isinstance(country, str) else country,
            name.strip() if isinstance(name, str) else name,
        )
    except Exception as e:
        logger.warning("get_user_role_and_country failed for %s: %s", email, e)
        return None, None, None


def _reviewer_can_act(role: Optional[str], country: Optional[str],
                      request_item: Dict[str, Any],
                      reviewer_email: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Return the ROLE_TO_REVIEW spec if this reviewer may act on this request, else None.

    Common gates: role must be a known reviewer role; the embedded review's review_type matches
    the spec; the request is in the expected in-progress status; the per-review field is 'pending'.

    Assignment gate (this is the key change):
      - If the review has an explicit `assigned_to_email` (the requestor picked a reviewer),
        ONLY that exact reviewer (case-insensitive email match) may act — jurisdiction is NOT a
        gate (cross-jurisdiction assignment is allowed).
      - Otherwise (legacy reviews with no explicit assignment), fall back to the previous
        behavior: the reviewer's country must match the request jurisdiction.
    """
    spec = ROLE_TO_REVIEW.get((role or '').strip().lower())
    if not spec:
        return None
    review = request_item.get('review') or {}
    if (review.get('review_type') or '').strip().lower() != spec['review_type']:
        return None
    if (request_item.get('status') or '').strip() != spec['request_status']:
        return None
    if (review.get(spec['field']) or '').strip().lower() != 'pending':
        return None

    assigned_email = (review.get('assigned_to_email') or '').strip().lower()
    if assigned_email:
        # Explicit assignment: only the assigned reviewer, regardless of jurisdiction.
        if (reviewer_email or '').strip().lower() != assigned_email:
            return None
        return spec

    # Legacy path: no explicit assignment -> match on jurisdiction == reviewer country.
    jurisdiction = (request_item.get('jurisdiction') or '').strip().lower()
    if not jurisdiction or jurisdiction != (country or '').strip().lower():
        return None
    return spec


def handle_list_assigned_reviews(reviewer_email: str) -> Dict[str, Any]:
    """GET /reviews/assigned?reviewer=<email> — list requests this reviewer can act on.

    Reviewer-scoped (unlike the requestor list which filters by user_id). Matches the
    reviewer's role->review_type and country->jurisdiction against each request's embedded
    review, and only returns requests with an actionable (pending) per-review field.
    """
    if not reviewer_email:
        return error_response(400, 'MISSING_REVIEWER', 'reviewer query parameter is required')

    role, country, name = get_user_role_and_country(reviewer_email)
    spec = ROLE_TO_REVIEW.get((role or '').strip().lower())
    if not spec:
        # Not a recognized reviewer role -> empty list (not an error; keeps the UI simple).
        return success_response(200, {'reviewer': reviewer_email, 'role': role,
                                       'count': 0, 'requests': []})

    target_country = (country or '').strip().lower()
    projection = ('request_id, topic, jurisdiction, category, deadline, updated_at, '
                  'created_at, user_id, #st, #rv, active_review_id')
    names = {'#st': 'status', '#rv': 'review'}  # #rv projects the whole review (incl. assigned_to_email)

    assigned = []
    try:
        scan_kwargs = {'ProjectionExpression': projection, 'ExpressionAttributeNames': names}
        while True:
            resp = requests_table.scan(**scan_kwargs)
            reviewer_email_lc = (reviewer_email or '').strip().lower()
            for item in resp.get('Items', []):
                review = item.get('review') or {}
                if (review.get('review_type') or '').strip().lower() != spec['review_type']:
                    continue
                if (item.get('status') or '').strip() != spec['request_status']:
                    continue
                if (review.get(spec['field']) or '').strip().lower() != 'pending':
                    continue
                # Assignment gate: if the review was explicitly assigned to a reviewer email,
                # only that reviewer sees it (cross-jurisdiction allowed). Otherwise fall back to
                # the legacy jurisdiction==country match.
                assigned_email = (review.get('assigned_to_email') or '').strip().lower()
                if assigned_email:
                    if assigned_email != reviewer_email_lc:
                        continue
                else:
                    if (item.get('jurisdiction') or '').strip().lower() != target_country:
                        continue
                assigned.append({
                    'request_id': item.get('request_id'),
                    'topic': item.get('topic'),
                    'jurisdiction': item.get('jurisdiction'),
                    'category': item.get('category'),
                    'deadline': item.get('deadline'),
                    'requested_by': review.get('requested_by') or item.get('user_id'),
                    'review_type': review.get('review_type'),
                    'review_id': review.get('review_id') or item.get('active_review_id'),
                    'assigned_to': review.get('assigned_to'),
                    'assigned_to_email': review.get('assigned_to_email'),
                    'status': item.get('status'),
                    'updated_at': item.get('updated_at'),
                    'created_at': item.get('created_at'),
                })
            last_key = resp.get('LastEvaluatedKey')
            if not last_key:
                break
            scan_kwargs['ExclusiveStartKey'] = last_key
    except Exception as e:
        logger.error("Error listing assigned reviews for %s: %s", reviewer_email, e, exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Failed to list assigned reviews')

    # Newest first
    assigned.sort(key=lambda r: r.get('updated_at') or r.get('created_at') or '', reverse=True)
    return success_response(200, {
        'reviewer': reviewer_email,
        'reviewer_name': name,
        'role': role,
        'review_type': spec['review_type'],
        'count': len(assigned),
        'requests': assigned,
    })


def _append_timeline_safe(request_id: str, event_type: str, event_data: Dict[str, Any]) -> None:
    """Append a timeline event, tolerating a missing `timeline` attribute (list_append needs
    the list to exist). Non-fatal."""
    now_iso = datetime.utcnow().isoformat() + 'Z'
    event = {'timestamp': now_iso, 'event_type': event_type, 'event_data': event_data}
    try:
        requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression='SET timeline = list_append(if_not_exists(timeline, :empty), :event)',
            ExpressionAttributeValues={':event': [event], ':empty': []},
        )
    except Exception as e:
        logger.warning("Timeline append (%s) failed for %s: %s", event_type, request_id, e)


def handle_review_decision(request_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """POST /requests/{request_id}/reviews/decision — reviewer submits REQUEST CHANGES only.

    Per the finalized approver UI, the reviewer's only action is "Submit Review" with comments,
    which is a `request_changes`. Approve/Reject were removed by product decision.

    Authorization is by the reviewer's role + country vs the request's review_type + jurisdiction
    (assigned_to is display-only). The write is conditional on the request still being in the
    expected in-progress status AND the per-review field still 'pending', so only the first
    decision lands (no double decisions/races)."""
    try:
        if not request_id or not request_id.startswith('req_'):
            return error_response(400, 'INVALID_REQUEST_ID', 'Invalid request ID format',
                                  request_id=request_id)

        reviewer_email = (body.get('reviewer') or body.get('reviewer_id')
                          or body.get('user_id') or '').strip()
        # decision defaults to 'request_changes' (the only supported action). Any explicit value
        # other than request_changes is rejected.
        decision = (body.get('decision') or 'request_changes').strip().lower()
        feedback = (body.get('feedback') or body.get('comments') or '').strip()

        if not reviewer_email:
            return error_response(400, 'MISSING_REVIEWER', 'reviewer (email) is required',
                                  request_id=request_id)
        if decision not in VALID_DECISIONS:
            return error_response(400, 'INVALID_DECISION',
                                  "decision must be 'request_changes' (approve/reject are not "
                                  "supported)",
                                  request_id=request_id)
        if not feedback:
            return error_response(400, 'MISSING_FEEDBACK',
                                  'feedback (review comments) is required',
                                  request_id=request_id)

        existing = DynamoDBRequestRepository.get_request(request_id)
        if not existing:
            return error_response(404, 'NOT_FOUND', f'Request {request_id} not found',
                                  request_id=request_id)

        role, country, reviewer_name = get_user_role_and_country(reviewer_email)
        spec = _reviewer_can_act(role, country, existing, reviewer_email=reviewer_email)
        if not spec:
            return error_response(403, 'NOT_AUTHORIZED',
                                  'Reviewer is not authorized to act on this request '
                                  '(not the assigned reviewer, or role/state mismatch)',
                                  request_id=request_id)

        field = spec['field']            # e.g. 'legalReview'
        expected_status = spec['request_status']
        now_iso = datetime.utcnow().isoformat() + 'Z'

        # Only outcome: request_changes. Reviewer's task is done; the ball goes back to the user.
        field_value = 'changes_requested'
        new_status = 'REVIEW_CHANGES_REQUESTED'
        review_status = 'completed'

        # Per-review feedback attribute name (e.g. legal_only -> 'legal_feedback'). This keeps
        # each reviewer's comments in their own field so CA reviews can add fiscal_feedback,
        # communication_feedback, etc. later without collisions.
        feedback_field = spec['feedback_field']

        # Conditional atomic update: guard on current status AND the field still 'pending'.
        set_parts = [
            '#status = :new', 'progress_step = :ps', 'updated_at = :ts',
            '#rv.#field = :fval', '#rv.#rstatus = :rstatus', '#rv.completed_at = :ts',
            '#rv.decided_by = :decider', '#rv.decided_by_name = :decider_name',
            '#rv.decided_at = :ts', '#rv.decision = :decision', '#rv.#fbfield = :feedback',
        ]
        expr_names = {
            '#status': 'status', '#rv': 'review', '#field': field, '#rstatus': 'status',
            '#fbfield': feedback_field,
        }
        expr_values = {
            ':new': new_status, ':ps': new_status, ':ts': now_iso,
            ':fval': field_value, ':rstatus': review_status,
            ':decider': reviewer_email, ':decider_name': reviewer_name,
            ':decision': decision, ':feedback': feedback,
            ':expected': expected_status, ':pending': 'pending',
        }

        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression='SET ' + ', '.join(set_parts),
                ConditionExpression=('attribute_exists(request_id) AND #status = :expected '
                                     'AND #rv.#field = :pending'),
                ExpressionAttributeNames=expr_names,
                ExpressionAttributeValues=expr_values,
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                current = DynamoDBRequestRepository.get_request(request_id)
                return error_response(409, 'INVALID_STATE_TRANSITION',
                                      'Review is no longer actionable (already submitted or state '
                                      'changed).',
                                      details={'current_status': (current or {}).get('status')},
                                      request_id=request_id)
            raise

        _append_timeline_safe(request_id, 'REVIEW_DECISION', {
            'decision': decision, 'review_field': field, 'reviewer': reviewer_email,
            'reviewer_name': reviewer_name, 'feedback': feedback, 'new_status': new_status,
        })

        logger.info("Review decision %s on %s by %s -> %s", decision, request_id,
                    reviewer_email, new_status)
        return success_response(200, {
            'request_id': request_id,
            'decision': decision,
            'review_field': field,
            'review_field_value': field_value,
            'request_status': new_status,
            'reviewer': reviewer_email,
            'feedback_field': feedback_field,
            'feedback': feedback,
            'message': 'Review submitted successfully',
        }, request_id=request_id)

    except Exception as e:
        logger.error("Error recording review decision for %s: %s", request_id, e, exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Error recording review decision',
                              request_id=request_id)


def handle_request_complete(request_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """POST /requests/{request_id}/complete — requestor's final "Proceed" button.

    Primary path: after a legal redraft completes (DRAFTING_COMPLETED), the requestor finalizes
    directly -> COMPLETED (legal review already done). REVIEW_APPROVAL_BY_REQUESTOR is also
    accepted for backward compatibility, though the current UI no longer produces it."""
    try:
        if not request_id or not request_id.startswith('req_'):
            return error_response(400, 'INVALID_REQUEST_ID', 'Invalid request ID format',
                                  request_id=request_id)

        allowed_from = {'REVIEW_APPROVAL_BY_REQUESTOR', 'DRAFTING_COMPLETED'}
        now_iso = datetime.utcnow().isoformat() + 'Z'
        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression=('SET #status = :done, progress_step = :done, updated_at = :ts, '
                                  '#rv.#rstatus = :completed, #rv.completed_at = :ts'),
                ConditionExpression='attribute_exists(request_id) AND #status IN (:a1, :a2)',
                ExpressionAttributeNames={'#status': 'status', '#rv': 'review', '#rstatus': 'status'},
                ExpressionAttributeValues={
                    ':done': 'COMPLETED', ':completed': 'completed', ':ts': now_iso,
                    ':a1': 'REVIEW_APPROVAL_BY_REQUESTOR', ':a2': 'DRAFTING_COMPLETED',
                },
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                current = DynamoDBRequestRepository.get_request(request_id)
                if not current:
                    return error_response(404, 'NOT_FOUND', f'Request {request_id} not found',
                                          request_id=request_id)
                return error_response(409, 'INVALID_STATE_TRANSITION',
                                      f"Request cannot be completed from its current state "
                                      f"(must be one of {sorted(allowed_from)})",
                                      details={'current_status': current.get('status')},
                                      request_id=request_id)
            raise

        _append_timeline_safe(request_id, 'REQUEST_COMPLETED', {
            'completed_by': (body.get('user_id') or body.get('requested_by') or 'requestor'),
        })
        return success_response(200, {
            'request_id': request_id, 'request_status': 'COMPLETED',
            'message': 'Request marked as completed',
        }, request_id=request_id)

    except Exception as e:
        logger.error("Error completing request %s: %s", request_id, e, exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Error completing request',
                              request_id=request_id)


def _rehydrate_sections_from_approved_version(request_id: str, approved_version,
                                              sections_s3_key: str) -> None:
    """Copy the approved version's content snapshot into the shared sections artifact so a
    redraft starts from the APPROVED version, not the last-generated one.

    draft_versions/{id}/v{approved}.json holds the document_content object
    ({title, sections, key_recommendations, metadata}); draft_artifacts/{id}/sections.json wraps
    it as {"document_content": {...}}. This makes the assembler-only redraft path faithful to the
    approved version. Best-effort: any issue leaves the existing sections artifact untouched
    (falls back to current behavior) and never blocks the redraft."""
    try:
        if approved_version is None or str(approved_version).strip() == '':
            return
        version = int(approved_version)
        version_json_key = f"draft_versions/{request_id}/v{version}.json"
        try:
            obj = s3.get_object(Bucket=DOCUMENT_BUCKET, Key=version_json_key)
        except Exception:
            logger.info("REHYDRATE | no version snapshot %s; keeping existing sections artifact",
                        version_json_key)
            return
        document_content = json.loads(obj['Body'].read())
        s3.put_object(
            Bucket=DOCUMENT_BUCKET,
            Key=sections_s3_key,
            Body=json.dumps({'document_content': document_content}, indent=2).encode('utf-8'),
            ContentType='application/json',
        )
        logger.info("REHYDRATE | seeded %s from approved v%s (%s) for %s",
                    sections_s3_key, version, version_json_key, request_id)
    except Exception as e:
        logger.warning("REHYDRATE | failed for %s (non-fatal): %s", request_id, e)


def handle_legal_redraft(request_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """POST /requests/{request_id}/legal-redraft — requestor forwards reviewer comments to a
    redraft after a legal 'request_changes'. Repeatable.

    Invokes the existing redraft Lambda synchronously with deterministic draft-artifact keys
    (draft_artifacts/{request_id}/plan.json | sections.json). The redraft's assembler writes a
    new versioned .docx and sets DRAFTING_COMPLETED. Since legal review is already complete, the
    requestor can then call /complete directly (no second review)."""
    try:
        if not request_id or not request_id.startswith('req_'):
            return error_response(400, 'INVALID_REQUEST_ID', 'Invalid request ID format',
                                  request_id=request_id)

        existing = DynamoDBRequestRepository.get_request(request_id)
        if not existing:
            return error_response(404, 'NOT_FOUND', f'Request {request_id} not found',
                                  request_id=request_id)

        current_status = (existing.get('status') or '').strip()
        # Allow starting a redraft from the changes-requested state, or continuing to iterate
        # from a completed redraft (repeatable) before the requestor finalizes.
        if current_status not in ('REVIEW_CHANGES_REQUESTED', 'DRAFTING_COMPLETED'):
            return error_response(409, 'INVALID_STATE_TRANSITION',
                                  "legal-redraft is only allowed after a legal 'request_changes' "
                                  "(REVIEW_CHANGES_REQUESTED) or between redraft iterations "
                                  "(DRAFTING_COMPLETED)",
                                  details={'current_status': current_status},
                                  request_id=request_id)

        review = existing.get('review') or {}
        # Feedback: explicit body override, else the reviewer's stored comments. Prefer the new
        # per-review key (legal_feedback); fall back to the legacy 'feedback' for older records.
        feedback = (body.get('feedback') or review.get('legal_feedback')
                    or review.get('feedback') or '').strip()
        if not feedback:
            return error_response(400, 'MISSING_FEEDBACK',
                                  'No redraft feedback available (reviewer feedback missing and '
                                  'none provided in body)',
                                  request_id=request_id)

        # Deterministic draft-artifact keys (produced by the original drafting run).
        plan_s3_key = f"draft_artifacts/{request_id}/plan.json"
        sections_s3_key = f"draft_artifacts/{request_id}/sections.json"

        # ── Rehydrate the redraft base from the APPROVED version ──
        # The requestor may have generated multiple draft versions and approved a specific one
        # (e.g. approved v3 out of v1..v4). The shared sections artifact only holds the LAST
        # generated version's content, so a redraft would otherwise start from the wrong base.
        # If an approved version exists, copy its snapshot (draft_versions/v{approved}.json ->
        # draft_artifacts/sections.json) so the redraft (assembler-only path) works from the
        # approved content. Then CLEAR approved_version so preview/compare/download all fall back
        # to the newly redrafted (latest) version instead of pinning to the stale approved one.
        approved_version = existing.get('approved_version')
        _rehydrate_sections_from_approved_version(request_id, approved_version, sections_s3_key)

        retry_count = int(body.get('hitl_draft_retry_count') or review.get('redraft_count') or 0)

        redraft_event = {
            'request_id': request_id,
            'draft_hitl_result': {'decision': 'revise', 'feedback': feedback},
            'plan_s3_key': plan_s3_key,
            'sections_s3_key': sections_s3_key,
            'validation_result': {},   # redraft loads validation_result from the plan artifact
            'synthesis_output': {},    # redraft loads research_result from the plan artifact
            'hitl_draft_retry_count': retry_count,
        }

        # Mark in-progress before invoking (best-effort; redraft's assembler will set the final
        # DRAFTING_COMPLETED). Guard so we only move from an allowed state.
        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                # Also REMOVE approved_version: once a redraft starts, the old approved version is
                # obsolete. Clearing it makes preview/compare/download fall back to the latest
                # (the newly redrafted) version, keeping all three views consistent.
                UpdateExpression=('SET #status = :prog, progress_step = :prog, updated_at = :ts, '
                                  'review.redraft_count = :rc REMOVE approved_version'),
                ConditionExpression='attribute_exists(request_id) AND #status IN (:a1, :a2)',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':prog': 'RE_DRAFT_IN_PROGRESS', ':ts': datetime.utcnow().isoformat() + 'Z',
                    ':rc': retry_count + 1,
                    ':a1': 'REVIEW_CHANGES_REQUESTED', ':a2': 'DRAFTING_COMPLETED',
                },
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                current = DynamoDBRequestRepository.get_request(request_id)
                return error_response(409, 'INVALID_STATE_TRANSITION',
                                      'Request state changed; cannot start redraft now.',
                                      details={'current_status': (current or {}).get('status')},
                                      request_id=request_id)
            raise

        # Invoke the redraft Lambda ASYNCHRONOUSLY (InvocationType='Event').
        # The redraft re-runs LLM planner/generator/assembler stages and can take minutes,
        # which exceeds this API Lambda's short (30s) timeout — so we fire-and-forget and let
        # the frontend poll the request status. The redraft's assembler sets DRAFTING_COMPLETED
        # on success; on failure the status stays RE_DRAFT_IN_PROGRESS (surfaced to the user).
        try:
            resp = lambda_client.invoke(
                FunctionName=REDRAFT_LAMBDA_NAME,
                InvocationType='Event',
                Payload=json.dumps(redraft_event).encode('utf-8'),
            )
            accepted = resp.get('StatusCode') in (200, 202)
            if not accepted:
                raise RuntimeError(f"Async invoke returned StatusCode={resp.get('StatusCode')}")
        except Exception as invoke_err:
            logger.error("Redraft async invoke failed for %s: %s", request_id, invoke_err, exc_info=True)
            # Roll back to the changes-requested state so the user can retry.
            try:
                requests_table.update_item(
                    Key={'request_id': request_id},
                    UpdateExpression='SET #status = :back, progress_step = :back, updated_at = :ts',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':back': 'REVIEW_CHANGES_REQUESTED',
                        ':ts': datetime.utcnow().isoformat() + 'Z'},
                )
            except Exception as rb:
                logger.error("Rollback after redraft invoke failure failed for %s: %s", request_id, rb)
            return error_response(502, 'REDRAFT_INVOKE_FAILED', 'Failed to start the redraft',
                                  details={'error': str(invoke_err)}, request_id=request_id)

        _append_timeline_safe(request_id, 'LEGAL_REDRAFT_STARTED', {
            'iteration': retry_count + 1,
            'feedback': feedback,
        })

        # 202 Accepted: redraft is running in the background. Frontend polls status until it
        # becomes DRAFTING_COMPLETED, then the requestor calls /complete (legal already done).
        return success_response(202, {
            'request_id': request_id,
            'request_status': 'RE_DRAFT_IN_PROGRESS',
            'iteration': retry_count + 1,
            'message': ('Redraft started. Poll request status until DRAFTING_COMPLETED, then '
                        'review the new draft and call /complete when satisfied.'),
        }, request_id=request_id)

    except Exception as e:
        logger.error("Error running legal redraft for %s: %s", request_id, e, exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Error running legal redraft',
                              request_id=request_id)


# ============================================================================
# MAIN LAMBDA HANDLER
# ============================================================================

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main Lambda handler for API Gateway events
    Routes to appropriate handler based on HTTP method and path
    """
    try:
        correlation_id = event.get('headers', {}).get('X-Correlation-ID', str(uuid.uuid4()))
        
        # Determine HTTP method and path (support both REST V1, HTTP V2, and Console Tests)
        if 'requestContext' in event and 'http' in event['requestContext']:
            # HTTP API (Payload Version 2.0)
            http_method = event['requestContext']['http']['method']
            path = event.get('rawPath', '')
        else:
            # REST API (Payload Version 1.0) or AWS Console Test
            http_method = event.get('httpMethod', 'POST')
            path = event.get('path', '/requests')

        logger.info(f"Request: {http_method} {path} [ID: {correlation_id}]")

        # Handle CORS preflight
        if http_method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': CORS_ORIGIN,
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, X-Correlation-ID',
                    'Access-Control-Max-Age': '86400',
                },
                'body': ''
            }

        # Route to handlers (supporting API Gateway '/dev' stage prefix)
        if http_method == 'POST' and (path == '/requests' or path == '/dev/requests'):
            return handle_create_request(event, correlation_id)
        elif http_method == 'POST' and (path.endswith('/reviews') or path.endswith('/reviews/')):
            # POST /requests/{request_id}/reviews — "Proceed to reviews" submit
            parts = path.strip('/').split('/')
            if len(parts) >= 2:
                request_id = parts[-2]
                review_body = {}
                if event.get('body'):
                    try:
                        review_body = json.loads(event['body'])
                    except json.JSONDecodeError:
                        return error_response(400, 'INVALID_JSON', 'Request body must be valid JSON',
                                              request_id=correlation_id)
                return handle_create_review(request_id, review_body)
            return error_response(400, 'INVALID_PATH', 'Request ID missing in path', request_id=correlation_id)
        elif http_method == 'GET' and (path.rstrip('/').endswith('/reviews/assigned')):
            # GET /reviews/assigned?reviewer=<email> — reviewer's actionable requests
            qs = event.get('queryStringParameters') or {}
            reviewer_email = (qs.get('reviewer') or qs.get('email') or '').strip()
            return handle_list_assigned_reviews(reviewer_email)
        elif http_method == 'GET' and (path.rstrip('/').endswith('/reviews/reviewers')):
            # GET /reviews/reviewers?review_category=<Legal_Review|CA_Review>
            qs = event.get('queryStringParameters') or {}
            review_category = (qs.get('review_category') or qs.get('category') or '').strip()
            return handle_list_reviewers(review_category)
        elif http_method == 'POST' and (path.rstrip('/').endswith('/reviews/decision')):
            # POST /requests/{request_id}/reviews/decision — reviewer approve/reject/request_changes
            parts = path.rstrip('/').split('/')
            # .../requests/{request_id}/reviews/decision  -> request_id is 3 back from the end
            if len(parts) >= 4:
                request_id = parts[-3]
                decision_body = {}
                if event.get('body'):
                    try:
                        decision_body = json.loads(event['body'])
                    except json.JSONDecodeError:
                        return error_response(400, 'INVALID_JSON', 'Request body must be valid JSON',
                                              request_id=correlation_id)
                return handle_review_decision(request_id, decision_body)
            return error_response(400, 'INVALID_PATH', 'Request ID missing in path', request_id=correlation_id)
        elif http_method == 'POST' and (path.rstrip('/').endswith('/complete')):
            # POST /requests/{request_id}/complete — requestor final "Proceed" -> COMPLETED
            parts = path.rstrip('/').split('/')
            if len(parts) >= 2:
                request_id = parts[-2]
                complete_body = {}
                if event.get('body'):
                    try:
                        complete_body = json.loads(event['body'])
                    except json.JSONDecodeError:
                        return error_response(400, 'INVALID_JSON', 'Request body must be valid JSON',
                                              request_id=correlation_id)
                return handle_request_complete(request_id, complete_body)
            return error_response(400, 'INVALID_PATH', 'Request ID missing in path', request_id=correlation_id)
        elif http_method == 'POST' and (path.rstrip('/').endswith('/legal-redraft')):
            # POST /requests/{request_id}/legal-redraft — requestor sends reviewer comments to redraft
            parts = path.rstrip('/').split('/')
            if len(parts) >= 2:
                request_id = parts[-2]
                redraft_body = {}
                if event.get('body'):
                    try:
                        redraft_body = json.loads(event['body'])
                    except json.JSONDecodeError:
                        return error_response(400, 'INVALID_JSON', 'Request body must be valid JSON',
                                              request_id=correlation_id)
                return handle_legal_redraft(request_id, redraft_body)
            return error_response(400, 'INVALID_PATH', 'Request ID missing in path', request_id=correlation_id)
        elif http_method == 'GET' and (path.endswith('/references') or path.endswith('/references/')):
            parts = path.strip('/').split('/')
            if len(parts) >= 2:
                request_id = parts[-2]
                return handle_get_request_references(request_id)
            return error_response(400, 'INVALID_PATH', 'Request ID missing in path', request_id=correlation_id)
        elif http_method == 'GET' and (path.startswith('/requests/') or path.startswith('/dev/requests/')):
            request_id = path.split('/')[-1]
            return handle_get_request(request_id)
        elif http_method == 'GET' and (path == '/health' or path == '/dev/health'):
            return success_response(200, {'status': 'healthy'}, request_id=correlation_id)
        else:
            return error_response(404, 'NOT_FOUND', f'Endpoint not found: {http_method} {path}', request_id=correlation_id)

    except Exception as e:
        logger.error(f"Unhandled exception: {str(e)}", exc_info=True)
        return error_response(500, 'INTERNAL_ERROR', 'Unexpected server error')

