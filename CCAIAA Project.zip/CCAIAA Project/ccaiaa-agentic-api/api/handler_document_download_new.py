"""
Document Download & Retrieval Handler for PMI Agentic AI Platform

This handler provides endpoints to fetch and serve documents from S3 bucket.

Endpoints:
- GET /documents/{request_id} - Get document metadata and download link
- GET /documents/{request_id}/download - Direct document download (presigned URL)
- GET /documents/list/{request_id} - List all documents for a request
- POST /documents/upload-link - Get presigned URL for document upload
"""

import base64
import json
import logging
import os
from typing import Dict, Any, Optional
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.DEBUG if os.getenv('DEBUG_MODE', 'false').lower() == 'true' else logging.INFO)

# AWS Clients
s3_client = boto3.client('s3', region_name=os.getenv('AWS_REGION', 'eu-west-1'))
dynamodb = boto3.resource('dynamodb', region_name=os.getenv('AWS_REGION', 'eu-west-1'))

# Environment variables
DOCUMENT_BUCKET = os.getenv('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')
REQUESTS_TABLE = os.getenv('DYNAMODB_REQUESTS_TABLE', 'pmi-agentic-ai-requests')
CORS_ORIGIN = os.getenv('CORS_ORIGIN', '*')
PRESIGNED_URL_EXPIRY = int(os.getenv('PRESIGNED_URL_EXPIRY', '86400'))  # 24 hours default

requests_table = dynamodb.Table(REQUESTS_TABLE)

# ============================================================================
# DOCUMENT PATHS MAPPING
# ============================================================================

DOCUMENT_PATHS = {
    'campaigns_output': 's3://pmi-agentic-ai-documents-603433800649-eu-west-1/documents/Adi_20260504101983/campaigns_output.docx',
}

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def create_response(status_code: int, body: Dict[str, Any], headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Create standardized HTTP response"""
    default_headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': CORS_ORIGIN,
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Api-Key'
    }

    if headers:
        default_headers.update(headers)

    return {
        'statusCode': status_code,
        'headers': default_headers,
        'body': json.dumps(body, default=str, ensure_ascii=False)
    }


def parse_s3_uri(s3_uri: str) -> Dict[str, str]:
    """Parse S3 URI and extract bucket and key"""
    # Format: s3://bucket-name/key/to/file
    try:
        if s3_uri.startswith('s3://'):
            s3_uri = s3_uri[5:]  # Remove s3:// prefix

        parts = s3_uri.split('/', 1)
        if len(parts) != 2:
            raise ValueError("Invalid S3 URI format")

        return {
            'bucket': parts[0],
            'key': parts[1]
        }
    except Exception as e:
        logger.error(f"Error parsing S3 URI: {e}")
        raise


def get_s3_object_metadata(bucket: str, key: str) -> Optional[Dict[str, Any]]:
    """Get S3 object metadata"""
    try:
        response = s3_client.head_object(Bucket=bucket, Key=key)
        return {
            'size': response.get('ContentLength', 0),
            'last_modified': response.get('LastModified', '').isoformat() if response.get('LastModified') else '',
            'content_type': response.get('ContentType', 'application/octet-stream'),
            'etag': response.get('ETag', ''),
        }
    except ClientError as e:
        if e.response['Error']['Code'] == '404':
            logger.warning(f"Object not found: s3://{bucket}/{key}")
            return None
        logger.error(f"Error getting object metadata: {e}")
        raise


def generate_presigned_url(bucket: str, key: str, expiration: int = PRESIGNED_URL_EXPIRY) -> str:
    """Generate presigned URL for S3 object"""
    try:
        url = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': bucket, 'Key': key},
            ExpiresIn=expiration
        )
        logger.info(f"Generated presigned URL for: s3://{bucket}/{key}")
        return url
    except ClientError as e:
        logger.error(f"Error generating presigned URL: {e}")
        raise



def download_document_content(bucket: str, key: str) -> Optional[bytes]:
    """Download document content from S3"""
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read()
        logger.info(f"Downloaded {len(content)} bytes from s3://{bucket}/{key}")
        return content
    except ClientError as e:
        logger.error(f"Error downloading document: {e}")
        raise


# ============================================================================
# HANDLER - GET DOCUMENT (GET /documents/{doc_id})
# ============================================================================

def handle_get_document(doc_id: str) -> Dict[str, Any]:
    """
    Handle GET /documents/{doc_id} - Get document metadata and download link

    Args:
        doc_id: Document identifier (e.g., 'campaigns_output')

    Returns:
        Document metadata with presigned download URL (JSON only)
    """
    try:
        if not doc_id:
            return create_response(400, {'error': 'Document ID is required'})

        # Get document S3 path from mapping
        s3_uri = DOCUMENT_PATHS.get(doc_id)
        if not s3_uri:
            logger.warning(f"Document not found in mapping: {doc_id}")
            return create_response(404, {
                'error': 'Document not found',
                'doc_id': doc_id
            })

        # Parse S3 URI
        s3_info = parse_s3_uri(s3_uri)
        bucket = s3_info['bucket']
        key = s3_info['key']

        # Get object metadata
        metadata = get_s3_object_metadata(bucket, key)
        if not metadata:
            return create_response(404, {
                'error': 'Document does not exist in S3',
                'doc_id': doc_id,
                's3_path': s3_uri
            })

        # Generate presigned download URL
        download_url = generate_presigned_url(bucket, key)

        # Prepare response
        response_data = {
            'doc_id': doc_id,
            's3_bucket': bucket,
            's3_key': key,
            'file_name': key.split('/')[-1],
            'metadata': metadata,
            'download_url': download_url,
            'expires_in_seconds': PRESIGNED_URL_EXPIRY,
            'expires_at': (datetime.now(timezone.utc) + timedelta(seconds=PRESIGNED_URL_EXPIRY)).isoformat()
        }

        logger.info(f"Retrieved document: {doc_id}")
        return create_response(200, response_data)

    except Exception as e:
        logger.error(f"Error getting document: {e}")
        return create_response(500, {
            'error': 'Failed to retrieve document',
            'details': str(e)
        })


# ============================================================================
# HANDLER - DOWNLOAD DOCUMENT DIRECT (GET /documents/{doc_id}/download)
# ============================================================================

def handle_download_document_direct(doc_id: str) -> Dict[str, Any]:
    """
    Handle GET /documents/{doc_id}/download - Direct redirect to presigned URL
    Returns a 302 redirect to the presigned S3 URL
    """
    try:
        s3_uri = DOCUMENT_PATHS.get(doc_id)
        if not s3_uri:
            return create_response(404, {'error': 'Document not found'})

        s3_info = parse_s3_uri(s3_uri)
        download_url = generate_presigned_url(s3_info['bucket'], s3_info['key'])

        # Return redirect response (always 302, never HTML)
        return {
            'statusCode': 302,
            'headers': {
                'Location': download_url,
                'Access-Control-Allow-Origin': CORS_ORIGIN
            },
            'body': ''
        }

    except Exception as e:
        logger.error(f"Error downloading document: {e}")
        return create_response(500, {'error': 'Download failed'})


# ============================================================================
# HANDLER - LIST DOCUMENTS FOR REQUEST (GET /documents/list/{request_id})
# ============================================================================

def handle_list_documents(request_id: str) -> Dict[str, Any]:
    """
    Handle GET /documents/list/{request_id} - List all documents for a request

    Gets documents from DynamoDB request record and S3
    """
    try:
        if not request_id:
            return create_response(400, {'error': 'Request ID is required'})

        # Get request from DynamoDB
        response = requests_table.get_item(Key={'request_id': request_id})
        request_data = response.get('Item')

        if not request_data:
            return create_response(404, {
                'error': 'Request not found',
                'request_id': request_id
            })

        # Collect document information
        documents = []

        # 1. Check uploaded files
        uploaded_files = request_data.get('uploaded_files', [])
        for file_key in uploaded_files:
            try:
                metadata = get_s3_object_metadata(DOCUMENT_BUCKET, file_key)
                if metadata:
                    documents.append({
                        'type': 'uploaded',
                        'file_name': file_key.split('/')[-1],
                        's3_key': file_key,
                        'metadata': metadata,
                        'download_url': generate_presigned_url(DOCUMENT_BUCKET, file_key)
                    })
            except Exception as e:
                logger.warning(f"Error getting metadata for {file_key}: {e}")

        # 2. Check final generated document. The drafter writes documents/{request_id}/{Category}.docx
        # (filename is no longer the fixed 'campaigns_output.docx'), so resolve it by prefix.
        final_doc_key = resolve_generated_document_key(request_id)
        if final_doc_key:
            try:
                metadata = get_s3_object_metadata(DOCUMENT_BUCKET, final_doc_key)
                if metadata:
                    documents.append({
                        'type': 'generated',
                        'file_name': final_doc_key.split('/')[-1],
                        's3_key': final_doc_key,
                        'metadata': metadata,
                        'download_url': generate_presigned_url(DOCUMENT_BUCKET, final_doc_key)
                    })
            except Exception as e:
                logger.debug(f"Generated document not found for {request_id}: {str(e)}")

        response_data = {
            'request_id': request_id,
            'document_count': len(documents),
            'documents': documents,
            'request_status': request_data.get('status'),
            'created_at': request_data.get('created_at')
        }

        logger.info(f"Listed {len(documents)} documents for request: {request_id}")
        return create_response(200, response_data)

    except Exception as e:
        logger.error(f"Error listing documents: {e}")
        return create_response(500, {'error': 'Failed to list documents'})


# ============================================================================
# HANDLER - GET PRESIGNED UPLOAD URL (POST /documents/upload-link)
# ============================================================================

def handle_get_upload_url(body: str) -> Dict[str, Any]:
    """
    Handle POST /documents/upload-link - Get presigned URL for document upload

    Request body: {
        "file_name": "document.docx",
        "file_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "request_id": "req_xxx" (optional)
    }
    """
    try:
        if not body:
            return create_response(400, {'error': 'Request body is required'})

        data = json.loads(body)
        file_name = data.get('file_name')
        file_type = data.get('file_type', 'application/octet-stream')
        request_id = data.get('request_id')

        if not file_name:
            return create_response(400, {'error': 'file_name is required'})

        # Generate S3 key
        if request_id:
            s3_key = f"uploads/{request_id}/{file_name}"
        else:
            s3_key = f"uploads/{file_name}"

        # Generate presigned upload URL
        upload_url = s3_client.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': DOCUMENT_BUCKET,
                'Key': s3_key,
                'ContentType': file_type
            },
            ExpiresIn=PRESIGNED_URL_EXPIRY
        )

        response_data = {
            'upload_url': upload_url,
            's3_key': s3_key,
            'bucket': DOCUMENT_BUCKET,
            'file_name': file_name,
            'expires_in_seconds': PRESIGNED_URL_EXPIRY,
            'expires_at': (datetime.now(timezone.utc) + timedelta(seconds=PRESIGNED_URL_EXPIRY)).isoformat(),
            'instructions': 'Use HTTP PUT to upload file to upload_url'
        }

        logger.info(f"Generated upload URL for: {s3_key}")
        return create_response(201, response_data)

    except json.JSONDecodeError:
        return create_response(400, {'error': 'Invalid JSON in request body'})
    except Exception as e:
        logger.error(f"Error generating upload URL: {e}")
        return create_response(500, {'error': 'Failed to generate upload URL'})


# ============================================================================
# HANDLER - GET DOCUMENT CONTENT (GET /documents/content/{request_id})
# ============================================================================

def handle_document_content(request_id: str) -> Dict[str, Any]:
    """
    Handle GET /documents/content/{request_id}
    Reads the generated .docx from S3 and returns it as base64 so the
    frontend can render it with mammoth.js without a separate S3 download.
    """
    try:
        if not request_id:
            return create_response(400, {'error': 'request_id is required'})

        s3_key = resolve_generated_document_key(request_id)
        if not s3_key:
            return create_response(404, {
                'error': 'Document not found',
                'request_id': request_id
            })

        metadata = get_s3_object_metadata(DOCUMENT_BUCKET, s3_key)
        if not metadata:
            return create_response(404, {
                'error': 'Document not found',
                'request_id': request_id,
                's3_key': s3_key
            })

        content_bytes = download_document_content(DOCUMENT_BUCKET, s3_key)
        if not content_bytes:
            return create_response(500, {'error': 'Failed to read document content from S3'})

        content_b64 = base64.b64encode(content_bytes).decode('utf-8')

        response_data = {
            'request_id': request_id,
            'file_name': s3_key.split('/')[-1],
            'content_base64': content_b64,
            'size': metadata['size'],
            'last_modified': metadata['last_modified']
        }

        logger.info(f"Returning content for {s3_key} ({len(content_bytes)} bytes)")
        return create_response(200, response_data)

    except Exception as e:
        logger.error(f"Error fetching document content: {e}")
        return create_response(500, {'error': 'Failed to fetch document content'})


# ============================================================================
# HANDLER - DOCUMENT PREVIEW (GET /documents/preview/{request_id})
# ============================================================================

def handle_document_preview(request_id: str) -> Dict[str, Any]:
    """
    Handle GET /documents/preview/{request_id} - Convert .docx to HTML for browser preview

    Finds the generated .docx file for a request_id, converts it to HTML using mammoth,
    and returns the HTML content with file metadata.
    """
    try:
        if not request_id:
            return create_response(400, {'error': 'request_id is required'})

        # List S3 objects at documents/{request_id}/ to find .docx files
        prefix = f"documents/{request_id}/"
        resp = s3_client.list_objects_v2(Bucket=DOCUMENT_BUCKET, Prefix=prefix)
        objects = resp.get('Contents', [])
        docx_objects = [o for o in objects if o['Key'].endswith('.docx')]

        if not docx_objects:
            return create_response(404, {
                'error': 'No document found for this request',
                'request_id': request_id,
                'prefix': prefix
            })

        # Use most recently modified .docx if multiple exist
        target = max(docx_objects, key=lambda o: o['LastModified'])
        s3_key = target['Key']
        file_name = s3_key.split('/')[-1]

        # Download .docx bytes from S3
        s3_response = s3_client.get_object(Bucket=DOCUMENT_BUCKET, Key=s3_key)
        docx_bytes = s3_response['Body'].read()

        # Convert .docx to HTML using mammoth
        import io
        import mammoth
        with io.BytesIO(docx_bytes) as f:
            result = mammoth.convert_to_html(f)

        html_content = result.value

        response_data = {
            'request_id': request_id,
            'file_name': file_name,
            's3_key': s3_key,
            'html_content': html_content,
            'size_bytes': target['Size'],
            'last_modified': target['LastModified'].isoformat()
        }

        logger.info(f"Generated preview for {s3_key} ({len(docx_bytes)} bytes)")
        return create_response(200, response_data)

    except ClientError as e:
        logger.error(f"S3 error in preview: {e}")
        return create_response(500, {'error': 'Failed to fetch document', 'details': str(e)})
    except Exception as e:
        logger.error(f"Preview error: {e}")
        return create_response(500, {'error': 'Failed to generate preview', 'details': str(e)})


# ============================================================================
# VERSION COMPARE (side-by-side previous vs current draft)
# ============================================================================

def resolve_generated_document_key(request_id: str) -> Optional[str]:
    """Newest .docx directly under documents/{request_id}/ (the served/final document).

    Only considers objects immediately under the prefix (not nested sub-prefixes such as
    draft_versions/), and returns the most recently modified. Returns None if none found.
    """
    prefix = f"documents/{request_id}/"
    resp = s3_client.list_objects_v2(Bucket=DOCUMENT_BUCKET, Prefix=prefix)
    docs = [
        o for o in resp.get('Contents', [])
        if o['Key'].endswith('.docx') and '/' not in o['Key'][len(prefix):]
    ]
    if not docs:
        return None
    return max(docs, key=lambda o: o['LastModified'])['Key']


def _resolve_version_docx_keys(request_id: str):
    """Return sorted [(version:int, key:str)] for draft_versions/{request_id}/v{n}.docx."""
    import re as _re
    prefix = f"draft_versions/{request_id}/"
    out = []
    token = None
    while True:
        kwargs = {'Bucket': DOCUMENT_BUCKET, 'Prefix': prefix}
        if token:
            kwargs['ContinuationToken'] = token
        resp = s3_client.list_objects_v2(**kwargs)
        for obj in resp.get('Contents', []):
            m = _re.search(r'/v(\d+)\.docx$', obj['Key'])
            if m:
                out.append((int(m.group(1)), obj['Key']))
        if resp.get('IsTruncated'):
            token = resp.get('NextContinuationToken')
        else:
            break
    out.sort(key=lambda t: t[0])
    return out


# The reviewer-approved version is written by the HITL API to the demo2 requests table
# (pmi-agentic-ai-requests). This handler's DYNAMODB_REQUESTS_TABLE may point elsewhere,
# so resolve the approval table explicitly (REQUESTS_TABLE env) to read it.
APPROVAL_REQUESTS_TABLE = os.getenv('REQUESTS_TABLE', 'pmi-agentic-ai-requests')
_approval_requests_table = dynamodb.Table(APPROVAL_REQUESTS_TABLE)


def _get_approved_version(request_id: str):
    """Return the reviewer-approved version number for a request (int) or None if not set.
    Non-fatal: any lookup issue returns None (falls back to latest)."""
    try:
        item = _approval_requests_table.get_item(Key={'request_id': request_id}).get('Item') or {}
        av = item.get('approved_version')
        if av is None or (isinstance(av, str) and av.strip() == ''):
            return None
        return int(av)
    except Exception as e:
        logger.warning(f"compare: approved_version lookup failed for {request_id}: {e}")
        return None


def _docx_key_to_html(s3_key: str) -> str:
    """Download a .docx from S3 and convert it to HTML via mammoth (clean, no marks)."""
    import io
    import mammoth
    resp = s3_client.get_object(Bucket=DOCUMENT_BUCKET, Key=s3_key)
    docx_bytes = resp['Body'].read()
    with io.BytesIO(docx_bytes) as f:
        return mammoth.convert_to_html(f).value


def _versions_to_html_parallel(version_pairs):
    """Convert [(version, key), ...] to [{version, html_content, s3_key}, ...] preserving the
    input order, converting each .docx -> HTML concurrently to keep latency low for many
    versions."""
    from concurrent.futures import ThreadPoolExecutor

    results = [None] * len(version_pairs)

    def _one(idx, ver, key):
        return idx, {'version': ver, 'html_content': _docx_key_to_html(key), 's3_key': key}

    max_workers = min(len(version_pairs), 8) or 1
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(_one, i, v, k) for i, (v, k) in enumerate(version_pairs)]
        for fut in futures:
            idx, item = fut.result()
            results[idx] = item
    return results


def handle_document_compare(request_id: str) -> Dict[str, Any]:
    """Handle GET /documents/compare/{request_id}.

    Returns ALL available draft versions as ready-to-render HTML (ascending v1..vN) in a
    `versions` array so the UI can render every revision. For backward compatibility the
    response also includes `current` (latest), `previous` (second latest or null) and
    `is_first_draft`. Legacy requests with no versioned copies fall back to the single
    served document.
    """
    try:
        if not request_id:
            return create_response(400, {'error': 'request_id is required'})

        version_pairs = _resolve_version_docx_keys(request_id)

        if not version_pairs:
            # Legacy fallback: no versioned copies exist — serve the single current doc.
            served = resolve_generated_document_key(request_id)
            if not served:
                return create_response(404, {
                    'error': 'No document found for this request',
                    'request_id': request_id,
                })
            single = {'version': 1, 'html_content': _docx_key_to_html(served), 's3_key': served}
            return create_response(200, {
                'request_id': request_id,
                'version_count': 1,
                'versions': [single],
                'current': single,
                'previous': None,
                'is_first_draft': True,
            })

        # Convert every version to HTML (in parallel), ascending by version number.
        versions = _versions_to_html_parallel(version_pairs)

        # If the reviewer has approved a specific version, that version is the final/current
        # one (matches the served document + download). Otherwise, during review, `current`
        # is the latest version so the side-by-side previous-vs-current view works.
        approved_version = _get_approved_version(request_id)
        current = versions[-1]
        if approved_version is not None:
            match = next((v for v in versions if v['version'] == approved_version), None)
            if match:
                current = match

        idx = versions.index(current)
        previous = versions[idx - 1] if idx >= 1 else None

        logger.info(
            f"Compare for {request_id}: {len(versions)} version(s) "
            f"(v{versions[0]['version']}..v{versions[-1]['version']}); "
            f"approved_version={approved_version}; current=v{current['version']}"
        )
        return create_response(200, {
            'request_id': request_id,
            'version_count': len(versions),
            'versions': versions,
            'current': current,
            'previous': previous,
            'approved_version': approved_version,
            'is_first_draft': previous is None,
        })

    except ClientError as e:
        logger.error(f"S3 error in compare: {e}")
        return create_response(500, {'error': 'Failed to fetch documents', 'details': str(e)})
    except Exception as e:
        logger.error(f"Compare error: {e}")
        return create_response(500, {'error': 'Failed to build comparison', 'details': str(e)})


# ============================================================================
# MAIN LAMBDA HANDLER
# ============================================================================

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main Lambda handler for document operations
    Routes to appropriate handler based on HTTP method and path
    """
    try:
        http_method = event.get('httpMethod', '')
        path = event.get('path', '')
        headers = event.get('headers', {})
        body = event.get('body')
        path_parameters = event.get('pathParameters') or {}

        logger.info(f"Document handler: {http_method} {path} | CORS_ORIGIN={CORS_ORIGIN}")

        # Handle CORS preflight
        if http_method == 'OPTIONS':
            cors_headers = {
                'Access-Control-Allow-Origin': CORS_ORIGIN,
                'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Api-Key',
                'Access-Control-Max-Age': '86400'
            }
            logger.info(f"OPTIONS response headers: {cors_headers}")
            return {
                'statusCode': 200,
                'headers': cors_headers,
                'body': ''
            }

        # Route based on path pattern
        if http_method == 'GET' and path.startswith('/documents/') and path.endswith('/download'):
            # GET /documents/{doc_id}/download
            doc_id = path.replace('/documents/', '').replace('/download', '')
            return handle_download_document_direct(doc_id)

        elif http_method == 'GET' and path.startswith('/documents/list/'):
            # GET /documents/list/{request_id}
            request_id = path.replace('/documents/list/', '')
            return handle_list_documents(request_id)

        elif http_method == 'GET' and path.startswith('/documents/compare/'):
            # GET /documents/compare/{request_id} - side-by-side previous vs current version
            request_id = path.replace('/documents/compare/', '')
            return handle_document_compare(request_id)

        elif http_method == 'GET' and path.startswith('/documents/content/'):
            # GET /documents/content/{request_id}
            request_id = path.replace('/documents/content/', '')
            return handle_document_content(request_id)

        elif http_method == 'GET' and path.startswith('/documents/preview/'):
            # GET /documents/preview/{request_id} - Document HTML preview
            request_id = path.replace('/documents/preview/', '')
            return handle_document_preview(request_id)

        elif http_method == 'GET' and path.startswith('/documents/'):
            # GET /documents/{doc_id}
            doc_id = path.replace('/documents/', '')
            return handle_get_document(doc_id)

        elif http_method == 'POST' and path == '/documents/upload-link':
            # POST /documents/upload-link - Get presigned URL for document upload
            return handle_get_upload_url(body)

        elif http_method == 'GET' and path == '/health':
            return create_response(200, {'status': 'healthy', 'service': 'document-handler'})

        else:
            logger.warning(f"404 - Endpoint not found: {http_method} {path}")
            return create_response(404, {
                'error': 'Endpoint not found',
                'path': path,
                'method': http_method
            })

    except Exception as e:
        logger.error(f"Unhandled error: {e}", exc_info=True)
        return create_response(500, {
            'error': 'Internal server error',
            'details': str(e)
        })
