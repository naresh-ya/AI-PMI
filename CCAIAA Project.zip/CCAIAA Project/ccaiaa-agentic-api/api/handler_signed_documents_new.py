"""
Signed Documents Repository Handler for PMI Agentic AI Platform

A SharePoint-like per-user repository for signed official documents (PDF/PPT/PPTX/DOC/DOCX).
Files are stored in S3 under a per-user prefix and are isolated by the caller's email.

Storage layout (bucket = SIGNED_DOCS_BUCKET):
    signed_documents/<sanitized-email>/<timestamp>__<sanitized-filename>

Endpoints (4):
- POST   /signed-documents/upload-url   -> Get a presigned PUT URL to upload one file
- GET    /signed-documents?user_email=  -> List the caller's uploaded files
- POST   /signed-documents/download     -> Get presigned GET URL(s) for one or many files
- DELETE /signed-documents              -> Delete one or many of the caller's files

Notes:
- Uploads/downloads use presigned URLs so file bytes go browser<->S3 directly
  (avoids API Gateway 10MB / Lambda 6MB payload limits for real signed docs).
- Identity is the user's email passed explicitly in the request. There is NO
  authentication yet (SSO/Cognito pending). Isolation is enforced server-side by
  forcing every S3 key under signed_documents/<sanitized-email>/ and verifying
  ownership before download/delete. The raw email is stored in object metadata so
  a later migration to token-derived identity is clean.
"""

import json
import logging
import os
import re
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta, timezone

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.DEBUG if os.getenv('DEBUG_MODE', 'false').lower() == 'true' else logging.INFO)

# AWS Clients
s3_client = boto3.client('s3', region_name=os.getenv('AWS_REGION', 'eu-west-1'))

# Environment / configuration
SIGNED_DOCS_BUCKET = os.getenv('SIGNED_DOCS_BUCKET', 'pmi-agentic-ai-documents-sandbox-603433800649')
# Base "folder" prefix inside the bucket (already exists in S3). Always kept with a trailing slash.
SIGNED_DOCS_PREFIX = os.getenv('SIGNED_DOCS_PREFIX', 'signed_documents/')
PRESIGNED_URL_EXPIRY = int(os.getenv('PRESIGNED_URL_EXPIRY', '900'))  # 15 minutes default
MAX_UPLOAD_BYTES = int(os.getenv('MAX_UPLOAD_BYTES', str(100 * 1024 * 1024)))  # 100 MB default

# Allowed document types (extension -> canonical content type)
ALLOWED_EXTENSIONS = {
    'pdf': 'application/pdf',
    'doc': 'application/msword',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'ppt': 'application/vnd.ms-powerpoint',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
}

# Dynamic CORS: reflect an allowed request Origin so localhost + Amplify dev + future
# prod URLs all work without code changes. A static list can be provided via
# CORS_ALLOWED_ORIGINS (comma-separated); if unset we reflect any Origin ('*'-like)
# but still echo the specific origin so credentialed requests keep working.
_CONFIGURED_ORIGINS = [
    o.strip() for o in os.getenv('CORS_ALLOWED_ORIGINS', '').split(',') if o.strip()
]


# ============================================================================
# CORS / RESPONSE HELPERS
# ============================================================================

def resolve_cors_origin(event: Dict[str, Any]) -> str:
    """Resolve the Access-Control-Allow-Origin value from the request Origin.

    - If CORS_ALLOWED_ORIGINS is configured, only reflect the Origin when it matches.
    - If not configured, reflect whatever Origin the browser sent (falls back to '*').
    This keeps the APIs from ever failing when the frontend URL changes.
    """
    headers = event.get('headers') or {}
    # Header names are case-insensitive; API Gateway may send 'origin' or 'Origin'.
    origin = None
    for key, value in headers.items():
        if key and key.lower() == 'origin':
            origin = value
            break

    if not origin:
        return '*'

    if _CONFIGURED_ORIGINS:
        return origin if origin in _CONFIGURED_ORIGINS else _CONFIGURED_ORIGINS[0]

    # No allow-list configured: reflect the caller's origin so it never fails.
    return origin


def build_cors_headers(origin: str, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Api-Key',
        'Access-Control-Max-Age': '86400',
        'Vary': 'Origin',
    }
    if extra:
        headers.update(extra)
    return headers


def create_response(status_code: int, body: Dict[str, Any], origin: str = '*',
                    extra_headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Create a standardized HTTP response with dynamic CORS headers."""
    return {
        'statusCode': status_code,
        'headers': build_cors_headers(origin, extra_headers),
        'body': json.dumps(body, default=str, ensure_ascii=False),
    }


# ============================================================================
# SANITIZATION / KEY HELPERS
# ============================================================================

def sanitize_email(email: str) -> str:
    """Convert an email into a safe, reversible-ish S3 folder segment.

    'John.Doe@pmi.com' -> 'john.doe_at_pmi.com'
    Strips anything outside [a-z0-9._-] to prevent path traversal / key injection.
    """
    if not email or not isinstance(email, str):
        raise ValueError('user_email is required')
    e = email.strip().lower()
    # Basic email shape check (kept lenient - real validation happens at auth layer later)
    if '@' not in e or '.' not in e.split('@')[-1]:
        raise ValueError('user_email is not a valid email address')
    e = e.replace('@', '_at_')
    e = re.sub(r'[^a-z0-9._-]', '_', e)
    # Collapse any leading dots to avoid weird prefixes
    e = e.lstrip('.')
    if not e:
        raise ValueError('user_email is not a valid email address')
    return e


def sanitize_filename(file_name: str) -> str:
    """Sanitize an uploaded file name; keep the extension, strip unsafe characters."""
    if not file_name or not isinstance(file_name, str):
        raise ValueError('file_name is required')
    # Keep only the base name (defeat ../ and absolute paths)
    base = file_name.replace('\\', '/').split('/')[-1].strip()
    if not base or base in ('.', '..'):
        raise ValueError('file_name is invalid')
    # Replace unsafe characters, preserve dots/dashes/underscores
    safe = re.sub(r'[^A-Za-z0-9._-]', '_', base)
    safe = safe.strip('.')
    if not safe:
        raise ValueError('file_name is invalid')
    return safe


def get_extension(file_name: str) -> str:
    if '.' not in file_name:
        return ''
    return file_name.rsplit('.', 1)[-1].lower()


def user_prefix(sanitized_email: str) -> str:
    """Return the S3 key prefix that scopes all of a user's files."""
    base = SIGNED_DOCS_PREFIX if SIGNED_DOCS_PREFIX.endswith('/') else SIGNED_DOCS_PREFIX + '/'
    return f"{base}{sanitized_email}/"


def build_object_key(sanitized_email: str, safe_file_name: str) -> str:
    """Build a timestamped, collision-resistant S3 key for a new upload."""
    ts = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    return f"{user_prefix(sanitized_email)}{ts}__{safe_file_name}"


def is_owned_key(key: str, sanitized_email: str) -> bool:
    """Verify a requested key belongs to the caller (prevents cross-user access)."""
    if not key or not isinstance(key, str):
        return False
    return key.startswith(user_prefix(sanitized_email))


def _iso(dt) -> str:
    try:
        return dt.astimezone(timezone.utc).isoformat()
    except Exception:
        return str(dt)


# ============================================================================
# INPUT PARSING
# ============================================================================

def parse_body(body: Any) -> Dict[str, Any]:
    """Parse a JSON request body that may be a str, dict, or None."""
    if body is None:
        return {}
    if isinstance(body, dict):
        return body
    if isinstance(body, (bytes, bytearray)):
        body = body.decode('utf-8', errors='replace')
    if isinstance(body, str):
        body = body.strip()
        if not body:
            return {}
        return json.loads(body)
    return {}


# ============================================================================
# HANDLER 1 - GET PRESIGNED UPLOAD URL (POST /signed-documents/upload-url)
# ============================================================================

def handle_get_upload_url(body: Any, origin: str) -> Dict[str, Any]:
    try:
        try:
            data = parse_body(body)
        except json.JSONDecodeError:
            return create_response(400, {'error': 'Invalid JSON body'}, origin)

        try:
            sanitized_email = sanitize_email(data.get('user_email', ''))
        except ValueError as ve:
            return create_response(400, {'error': str(ve)}, origin)

        file_name_raw = data.get('file_name', '')
        try:
            safe_name = sanitize_filename(file_name_raw)
        except ValueError as ve:
            return create_response(400, {'error': str(ve)}, origin)

        ext = get_extension(safe_name)
        if ext not in ALLOWED_EXTENSIONS:
            return create_response(400, {
                'error': 'Unsupported file type',
                'allowed_extensions': sorted(ALLOWED_EXTENSIONS.keys()),
                'received_extension': ext or None,
            }, origin)

        # Optional size validation (frontend should send file_size)
        file_size = data.get('file_size')
        if file_size is not None:
            try:
                file_size = int(file_size)
            except (TypeError, ValueError):
                return create_response(400, {'error': 'file_size must be a number'}, origin)
            if file_size <= 0:
                return create_response(400, {'error': 'file_size must be greater than 0'}, origin)
            if file_size > MAX_UPLOAD_BYTES:
                return create_response(400, {
                    'error': 'File exceeds maximum allowed size',
                    'max_bytes': MAX_UPLOAD_BYTES,
                }, origin)

        # Content type: trust the extension's canonical type (ignore spoofable client value)
        content_type = ALLOWED_EXTENSIONS[ext]
        s3_key = build_object_key(sanitized_email, safe_name)

        # NOTE: We intentionally do NOT attach S3 object Metadata here. This bucket
        # materializes object metadata into a "<key>.metadata.json" sidecar object,
        # which would pollute listings. The user's email is already encoded in the
        # key prefix (signed_documents/<sanitized-email>/), so no metadata is needed.
        upload_url = s3_client.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': SIGNED_DOCS_BUCKET,
                'Key': s3_key,
                'ContentType': content_type,
            },
            ExpiresIn=PRESIGNED_URL_EXPIRY,
        )

        response_data = {
            'upload_url': upload_url,
            's3_key': s3_key,
            'bucket': SIGNED_DOCS_BUCKET,
            'file_name': safe_name,
            'content_type': content_type,
            'expires_in_seconds': PRESIGNED_URL_EXPIRY,
            'expires_at': (datetime.now(timezone.utc) + timedelta(seconds=PRESIGNED_URL_EXPIRY)).isoformat(),
            'upload_method': 'PUT',
            'required_headers': {'Content-Type': content_type},
            'instructions': 'HTTP PUT the raw file bytes to upload_url with the Content-Type header shown.',
        }
        logger.info(f"Issued upload URL: {s3_key}")
        return create_response(201, response_data, origin)

    except ClientError as e:
        logger.error(f"S3 error generating upload URL: {e}")
        return create_response(500, {'error': 'Failed to generate upload URL', 'details': str(e)}, origin)
    except Exception as e:
        logger.error(f"Unhandled error in upload-url: {e}", exc_info=True)
        return create_response(500, {'error': 'Internal server error', 'details': str(e)}, origin)


# ============================================================================
# HANDLER 2 - LIST DOCUMENTS (GET /signed-documents?user_email=...)
# ============================================================================

def handle_list_documents(query_params: Dict[str, Any], origin: str) -> Dict[str, Any]:
    try:
        query_params = query_params or {}
        try:
            sanitized_email = sanitize_email(query_params.get('user_email', ''))
        except ValueError as ve:
            return create_response(400, {'error': str(ve)}, origin)

        prefix = user_prefix(sanitized_email)

        list_kwargs = {'Bucket': SIGNED_DOCS_BUCKET, 'Prefix': prefix, 'MaxKeys': 1000}
        continuation_token = query_params.get('next_token')
        if continuation_token:
            list_kwargs['ContinuationToken'] = continuation_token

        response = s3_client.list_objects_v2(**list_kwargs)

        files: List[Dict[str, Any]] = []
        for obj in response.get('Contents', []):
            key = obj['Key']
            # Skip the "folder" placeholder object if one exists
            if key == prefix or key.endswith('/'):
                continue
            # Skip sidecar/system files that are not user documents
            if key.endswith('.metadata.json'):
                continue
            stored_name = key[len(prefix):]  # strip the user prefix
            # Strip the timestamp prefix (YYYYMMDDTHHMMSSZ__) for a friendly display name
            display_name = re.sub(r'^\d{8}T\d{6}Z__', '', stored_name)
            files.append({
                's3_key': key,
                'file_name': display_name,
                'stored_name': stored_name,
                'size': obj.get('Size', 0),
                'last_modified': _iso(obj.get('LastModified')) if obj.get('LastModified') else '',
                'etag': (obj.get('ETag') or '').strip('"'),
            })

        # Newest first
        files.sort(key=lambda f: f.get('last_modified', ''), reverse=True)

        result = {
            'user_email': query_params.get('user_email', '').strip(),
            'count': len(files),
            'files': files,
            'next_token': response.get('NextContinuationToken'),
            'is_truncated': response.get('IsTruncated', False),
        }
        logger.info(f"Listed {len(files)} file(s) for prefix {prefix}")
        return create_response(200, result, origin)

    except ClientError as e:
        logger.error(f"S3 error listing documents: {e}")
        return create_response(500, {'error': 'Failed to list documents', 'details': str(e)}, origin)
    except Exception as e:
        logger.error(f"Unhandled error in list: {e}", exc_info=True)
        return create_response(500, {'error': 'Internal server error', 'details': str(e)}, origin)


# ============================================================================
# HANDLER 3 - DOWNLOAD (POST /signed-documents/download)
# ============================================================================

def _extract_keys(data: Dict[str, Any]) -> List[str]:
    """Accept either s3_keys (list) or a single s3_key."""
    keys = data.get('s3_keys')
    if keys is None and data.get('s3_key'):
        keys = [data.get('s3_key')]
    if not isinstance(keys, list):
        return []
    return [k for k in keys if isinstance(k, str) and k]


def handle_download(body: Any, origin: str) -> Dict[str, Any]:
    try:
        try:
            data = parse_body(body)
        except json.JSONDecodeError:
            return create_response(400, {'error': 'Invalid JSON body'}, origin)

        try:
            sanitized_email = sanitize_email(data.get('user_email', ''))
        except ValueError as ve:
            return create_response(400, {'error': str(ve)}, origin)

        keys = _extract_keys(data)
        if not keys:
            return create_response(400, {'error': 's3_keys (or s3_key) is required'}, origin)

        downloads: List[Dict[str, Any]] = []
        failed: List[Dict[str, Any]] = []

        for key in keys:
            # Ownership check first - never leak another user's files
            if not is_owned_key(key, sanitized_email):
                failed.append({'s3_key': key, 'reason': 'forbidden'})
                continue
            try:
                # Confirm the object exists before signing
                s3_client.head_object(Bucket=SIGNED_DOCS_BUCKET, Key=key)
            except ClientError as e:
                code = e.response.get('Error', {}).get('Code', '')
                if code in ('404', 'NoSuchKey', 'NotFound'):
                    failed.append({'s3_key': key, 'reason': 'not_found'})
                    continue
                logger.error(f"head_object failed for {key}: {e}")
                failed.append({'s3_key': key, 'reason': 'error'})
                continue

            file_name = re.sub(r'^\d{8}T\d{6}Z__', '', key.split('/')[-1])
            download_url = s3_client.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': SIGNED_DOCS_BUCKET,
                    'Key': key,
                    'ResponseContentDisposition': f'attachment; filename="{file_name}"',
                },
                ExpiresIn=PRESIGNED_URL_EXPIRY,
            )
            downloads.append({
                's3_key': key,
                'file_name': file_name,
                'download_url': download_url,
                'expires_in_seconds': PRESIGNED_URL_EXPIRY,
            })

        status = 200 if downloads else (404 if failed else 400)
        return create_response(status, {
            'downloads': downloads,
            'failed': failed,
            'expires_at': (datetime.now(timezone.utc) + timedelta(seconds=PRESIGNED_URL_EXPIRY)).isoformat(),
        }, origin)

    except Exception as e:
        logger.error(f"Unhandled error in download: {e}", exc_info=True)
        return create_response(500, {'error': 'Internal server error', 'details': str(e)}, origin)


# ============================================================================
# HANDLER 4 - DELETE (DELETE /signed-documents)
# ============================================================================

def handle_delete(body: Any, origin: str) -> Dict[str, Any]:
    try:
        try:
            data = parse_body(body)
        except json.JSONDecodeError:
            return create_response(400, {'error': 'Invalid JSON body'}, origin)

        try:
            sanitized_email = sanitize_email(data.get('user_email', ''))
        except ValueError as ve:
            return create_response(400, {'error': str(ve)}, origin)

        keys = _extract_keys(data)
        if not keys:
            return create_response(400, {'error': 's3_keys (or s3_key) is required'}, origin)

        owned: List[str] = []
        failed: List[Dict[str, Any]] = []
        for key in keys:
            if is_owned_key(key, sanitized_email):
                owned.append(key)
            else:
                failed.append({'s3_key': key, 'reason': 'forbidden'})

        deleted: List[str] = []
        if owned:
            # S3 delete_objects handles up to 1000 keys per call
            for i in range(0, len(owned), 1000):
                chunk = owned[i:i + 1000]
                resp = s3_client.delete_objects(
                    Bucket=SIGNED_DOCS_BUCKET,
                    Delete={'Objects': [{'Key': k} for k in chunk], 'Quiet': False},
                )
                deleted.extend([d['Key'] for d in resp.get('Deleted', [])])
                for err in resp.get('Errors', []):
                    failed.append({'s3_key': err.get('Key'), 'reason': err.get('Code', 'error')})

        status = 200 if deleted else (400 if failed else 200)
        logger.info(f"Deleted {len(deleted)} file(s), {len(failed)} failed")
        return create_response(status, {'deleted': deleted, 'failed': failed}, origin)

    except ClientError as e:
        logger.error(f"S3 error deleting documents: {e}")
        return create_response(500, {'error': 'Failed to delete documents', 'details': str(e)}, origin)
    except Exception as e:
        logger.error(f"Unhandled error in delete: {e}", exc_info=True)
        return create_response(500, {'error': 'Internal server error', 'details': str(e)}, origin)


# ============================================================================
# EVENT PARSING (REST v1 + HTTP v2 compatible) + MAIN HANDLER
# ============================================================================

def _parse_event(event: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
    """Return (http_method, path, query_params) for both API Gateway REST (v1)
    and HTTP API (v2) event shapes, tolerating a stage prefix like /dev."""
    http_method = event.get('httpMethod')
    path = event.get('path')

    if not http_method:
        rc = event.get('requestContext', {}) or {}
        http_obj = rc.get('http', {}) or {}
        http_method = http_obj.get('method', '')
        path = event.get('rawPath') or http_obj.get('path') or ''

    path = path or ''

    # Strip a leading stage segment (e.g. /dev, /prod) if present so routing is stable
    stage = ((event.get('requestContext') or {}).get('stage'))
    if stage and path.startswith(f'/{stage}/'):
        path = path[len(stage) + 1:]

    query_params = event.get('queryStringParameters') or {}

    return http_method or '', path, query_params


def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """Main Lambda handler for the signed-documents repository."""
    origin = resolve_cors_origin(event)
    try:
        http_method, path, query_params = _parse_event(event)
        body = event.get('body')

        # Normalize trailing slash (keep root '/')
        norm_path = path.rstrip('/') if path != '/' else path

        logger.info(f"Signed-docs handler: {http_method} {path} (origin={origin})")

        # CORS preflight
        if http_method == 'OPTIONS':
            return {'statusCode': 200, 'headers': build_cors_headers(origin), 'body': ''}

        # Health check
        if http_method == 'GET' and norm_path.endswith('/health'):
            return create_response(200, {'status': 'healthy', 'service': 'signed-documents-handler'}, origin)

        # POST /signed-documents/upload-url
        if http_method == 'POST' and norm_path.endswith('/signed-documents/upload-url'):
            return handle_get_upload_url(body, origin)

        # POST /signed-documents/download
        if http_method == 'POST' and norm_path.endswith('/signed-documents/download'):
            return handle_download(body, origin)

        # DELETE /signed-documents
        if http_method == 'DELETE' and norm_path.endswith('/signed-documents'):
            return handle_delete(body, origin)

        # GET /signed-documents  (list)
        if http_method == 'GET' and norm_path.endswith('/signed-documents'):
            return handle_list_documents(query_params, origin)

        logger.warning(f"404 - Endpoint not found: {http_method} {path}")
        return create_response(404, {'error': 'Endpoint not found', 'path': path, 'method': http_method}, origin)

    except Exception as e:
        logger.error(f"Unhandled error: {e}", exc_info=True)
        return create_response(500, {'error': 'Internal server error', 'details': str(e)}, origin)
