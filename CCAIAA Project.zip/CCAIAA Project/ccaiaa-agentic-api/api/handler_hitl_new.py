"""
HITL API Handler — PMI Agentic AI Platform

Unified handler supporting HTTP API Gateway routes (V2 event payloads):
  GET  /requests/research/hitl/{hitl_id}          — fetch checkpoint + sources for review UI
  POST /requests/research/hitl/{hitl_id}           — submit approve / revise decision
"""

import json
import logging
import os
import decimal
from datetime import datetime, timezone
from typing import Dict, Any, List
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
sfn_client = boto3.client('stepfunctions')

# Read tables from environment variables with fallback values
REQUESTS_TABLE = os.environ.get('REQUESTS_TABLE', 'pmi-agentic-ai-requests')
HITL_TABLE = os.environ.get('HITL_TABLE', 'pmi-agentic-ai-hitl')

requests_table = dynamodb.Table(REQUESTS_TABLE)
hitl_table = dynamodb.Table(HITL_TABLE)

_NOW = lambda: datetime.now(timezone.utc).isoformat()


class _DecimalEncoder(json.JSONEncoder):
    """Converts DynamoDB Decimal values to int or float for JSON serialization."""
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            # Preserve int vs float distinction
            return int(obj) if obj % 1 == 0 else float(obj)
        return super().default(obj)

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Unified entrypoint router for API Gateway HTTP proxy events (v2 payload format)."""
    logger.info(f"Received API Gateway event: {json.dumps(event)}")
    try:
        # Extract HTTP method supporting both HTTP API (v2) and REST API (v1) formats
        http_method = event.get('httpMethod')
        if not http_method and 'requestContext' in event and 'http' in event['requestContext']:
            http_method = event['requestContext']['http'].get('method')
        http_method = (http_method or 'GET').upper()

        path_params = event.get('pathParameters') or {}
        hitl_id = path_params.get('hitl_id', '').strip()

        if not hitl_id:
            return _error(400, "hitl_id path parameter is required")

        # Route requests based on HTTP method
        if http_method == 'GET':
            return get_hitl_checkpoint(hitl_id)
        elif http_method == 'POST':
            body = event.get('body') or '{}'
            if isinstance(body, str):
                body = json.loads(body)
            return submit_hitl_decision(hitl_id, body)
        else:
            return _error(405, f"HTTP Method {http_method} not allowed")

    except json.JSONDecodeError:
        return _error(400, "Invalid JSON body format")
    except Exception as e:
        logger.exception("Unexpected error in HITL lambda handler")
        return _error(500, f"Internal Server Error: {str(e)}")

def get_hitl_checkpoint(hitl_id: str) -> Dict[str, Any]:
    """Handles GET /requests/research/hitl/{hitl_id} requests."""
    try:
        item = hitl_table.get_item(Key={'hitl_id': hitl_id}).get('Item')
        if not item:
            return _error(404, f"HITL record not found: {hitl_id}")

        # Security constraint: Strip the task token before returning data to client
        item.pop('task_token', None)
        item.pop('hitl_task_token', None)

        return _success(200, item)
    except Exception as e:
        logger.error(f"Error fetching checkpoint {hitl_id}: {str(e)}")
        return _error(500, f"Database retrieval failure: {str(e)}")

def submit_hitl_decision(hitl_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """Handles POST /requests/research/hitl/{hitl_id} decision submissions."""
    decision = (body.get('decision') or '').strip().lower()
    removed_source_ids = body.get('removed_source_ids') or []
    feedback = (body.get('feedback') or '').strip()
    reviewer_id = (body.get('reviewer_id') or 'anonymous').strip()

    # Optional: reviewer-selected draft version to make final (draft approve only).
    raw_version = body.get('version')
    selected_version = None
    if raw_version is not None and str(raw_version).strip() != '':
        try:
            selected_version = int(raw_version)
        except (TypeError, ValueError):
            return _error(400, "version must be a positive integer")
        if selected_version < 1:
            return _error(400, "version must be a positive integer")

    # 1. Input Validation
    if decision not in ('approve', 'revise', 'reject'):
        return _error(400, "decision must be 'approve', 'revise', or 'reject'")
    if decision == 'revise' and not feedback:
        return _error(400, "feedback is required when decision is 'revise'")

    # 2. Retrieve Checkpoint
    hitl_item = hitl_table.get_item(Key={'hitl_id': hitl_id}).get('Item')
    if not hitl_item:
        return _error(404, f"HITL record not found: {hitl_id}")
    
    if hitl_item.get('status') != 'pending':
        return _error(409, f"HITL record already completed — status: {hitl_item.get('status')}")

    request_id = hitl_item['request_id']
    is_draft_hitl = hitl_item.get('agent_name') == 'master_drafter'
    langsmith_headers = hitl_item.get('langsmith_headers', {})  # Extract tracing headers from checkpoint

    # Version selection (draft approve only): validate the requested version BEFORE claiming
    # the checkpoint, so an invalid version doesn't consume it and the workflow stays paused.
    if decision == 'approve' and is_draft_hitl and selected_version is not None:
        version_key = f"draft_versions/{request_id}/v{selected_version}.docx"
        if not _s3_key_exists(version_key):
            if _has_any_versions(request_id):
                return _error(400, f"version {selected_version} not found for this request")
            # Legacy fallback (option b): no versioned copies exist — keep the latest served doc.
            logger.info(f"VERSION_SELECT | no versioned copies for {request_id}; falling back to latest served doc")
            selected_version = None

    # 3. Retrieve Token from Checkpoint (Binding Isolation Guard)
    task_token = hitl_item.get('task_token')
    if not task_token:
        # Fallback to requests table for backward-compatibility only
        req_item = requests_table.get_item(Key={'request_id': request_id}).get('Item', {})
        task_token = req_item.get('hitl_task_token')
        
    if not task_token:
        return _error(500, f"Task token not found for checkpoint {hitl_id}")

    # 4. Atomic Status Change (Double Submission Guard using DynamoDB Conditional Update)
    try:
        hitl_table.update_item(
            Key={'hitl_id': hitl_id},
            UpdateExpression="""
                SET #s = :completed_status, human_decision = :decision, 
                    human_feedback = :feedback, removed_source_ids = :removed, 
                    completed_at = :completed_at, completed_by = :completed_by
            """,
            ConditionExpression="#s = :pending_status",
            ExpressionAttributeNames={'#s': 'status'},
            ExpressionAttributeValues={
                ':completed_status': 'completed',
                ':pending_status': 'pending',
                ':decision': decision,
                ':feedback': feedback,
                ':removed': removed_source_ids,
                ':completed_at': _NOW(),
                ':completed_by': reviewer_id
            }
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return _error(409, "Decision already processed concurrently")
        raise

    # 4a. Version selection: promote the reviewer-chosen version to the served/final document
    # BEFORE resuming the workflow. Roll back the checkpoint on failure so the user can retry.
    if decision == 'approve' and is_draft_hitl and selected_version is not None:
        if not _promote_selected_version(request_id, selected_version):
            try:
                hitl_table.update_item(
                    Key={'hitl_id': hitl_id},
                    UpdateExpression="SET #s = :pending_status",
                    ExpressionAttributeNames={'#s': 'status'},
                    ExpressionAttributeValues={':pending_status': 'pending'},
                )
            except Exception as rb:
                logger.error(f"Rollback after version promote failure failed: {rb}")
            return _error(500, f"Failed to promote selected version {selected_version}")

    # 5. Resume Step Function Workflow Execution
    all_sources = hitl_item.get('sources', [])
    removed_set = set(removed_source_ids)
    approved_sources = [s for s in all_sources if s.get('source_id') not in removed_set]

    # 5a. On approve with exclusions: update S3 research data to remove excluded sources.
    # Extract the actual URLs/titles of removed sources from the HITL checkpoint
    # (reliable matching keys — not index-based).
    if decision == 'approve' and removed_source_ids:
        removed_sources = [s for s in all_sources if s.get('source_id') in removed_set]
        _apply_source_exclusions_to_s3(request_id, removed_sources)

    task_result = {
        'decision': decision,
        'approved_sources': approved_sources,
        'removed_source_ids': list(removed_set),
        'feedback': feedback,
        'hitl_id': hitl_id,
        'reviewer_id': reviewer_id,
        'version': selected_version,
        'decided_at': _NOW(),
        'langsmith_headers': langsmith_headers,  # Pass through for tracing continuity
    }
    
    try:
        sfn_client.send_task_success(
            taskToken=task_token,
            output=json.dumps(task_result, cls=_DecimalEncoder)
        )
    except ClientError as e:
        logger.error(f"Step function callback failed: {str(e)}")
        # Roll back database update to let the user re-attempt if the step function is temporarily down or failed
        try:
            hitl_table.update_item(
                Key={'hitl_id': hitl_id},
                UpdateExpression="SET #s = :pending_status",
                ExpressionAttributeNames={'#s': 'status'},
                ExpressionAttributeValues={':pending_status': 'pending'}
            )
        except Exception as rollback_err:
            logger.error(f"Rollback database update failed: {rollback_err}")
        return _error(410, f"Workflow callback token has expired or is invalid: {e.response['Error']['Code']}")

    # 6. Synchronize Requests Table Status (is_draft_hitl computed earlier)
    if decision == 'approve':
        new_status = 'DRAFT_APPROVED' if is_draft_hitl else 'RESEARCH_APPROVED'
    elif decision == 'reject':
        new_status = 'CANCELLED'
    else:
        new_status = 'RE_DRAFT_IN_PROGRESS' if is_draft_hitl else 'RE_RESEARCH_IN_PROGRESS'
    
    # CRITICAL: Retry DynamoDB update with exponential backoff - status sync is essential
    max_retries = 3
    for attempt in range(max_retries):
        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression='SET #s = :s, updated_at = :ts',
                ExpressionAttributeNames={'#s': 'status'},
                ExpressionAttributeValues={':s': new_status, ':ts': _NOW()},
            )
            logger.info(f"Successfully updated request {request_id} status to {new_status}")
            break
        except Exception as e:
            if attempt < max_retries - 1:
                import time
                wait_time = (2 ** attempt) * 0.1  # 0.1s, 0.2s, 0.4s
                logger.warning(f"DynamoDB update attempt {attempt + 1} failed, retrying in {wait_time}s: {str(e)}")
                time.sleep(wait_time)
            else:
                logger.error(f"CRITICAL: Failed to update request status after {max_retries} attempts: {str(e)}")
                # Don't fail the callback - Step Functions already succeeded
                # But log prominently for monitoring/alerting
                pass

    return _success(200, {
        'message': 'Decision submitted successfully',
        'hitl_id': hitl_id,
        'request_id': request_id,
        'decision': decision,
        'approved_version': selected_version if (is_draft_hitl and decision == 'approve') else None,
        'next_status': new_status
    })

def _success(status_code: int, body: Any) -> Dict[str, Any]:
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        },
        'body': json.dumps(body, cls=_DecimalEncoder)
    }

def _error(status_code: int, message: str) -> Dict[str, Any]:
    logger.warning(f"HITL Error Response ({status_code}): {message}")
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        },
        'body': json.dumps({'error': message})
    }


# ── HITL Source Exclusion (applied to S3 research data on approve) ─────────────

s3_client = boto3.client('s3')
DOCUMENT_BUCKET = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')


def _s3_key_exists(key: str) -> bool:
    """True if the S3 object exists."""
    try:
        s3_client.head_object(Bucket=DOCUMENT_BUCKET, Key=key)
        return True
    except Exception:
        return False


def _has_any_versions(request_id: str) -> bool:
    """True if any versioned draft copies exist under draft_versions/{request_id}/."""
    try:
        resp = s3_client.list_objects_v2(
            Bucket=DOCUMENT_BUCKET, Prefix=f"draft_versions/{request_id}/", MaxKeys=1
        )
        return bool(resp.get('Contents'))
    except Exception as e:
        logger.warning(f"VERSION_SELECT | list versions failed for {request_id}: {e}")
        return False


def _resolve_served_doc_key(request_id: str):
    """The served/final document key: requests table document_s3_key, else newest top-level
    .docx under documents/{request_id}/. Returns None if not found."""
    req_item = requests_table.get_item(Key={'request_id': request_id}).get('Item', {})
    served_key = req_item.get('document_s3_key')
    if served_key:
        return served_key
    prefix = f"documents/{request_id}/"
    resp = s3_client.list_objects_v2(Bucket=DOCUMENT_BUCKET, Prefix=prefix)
    docx = [
        o['Key'] for o in resp.get('Contents', [])
        if o['Key'].endswith('.docx') and '/' not in o['Key'][len(prefix):]
    ]
    return max(docx) if docx else None


def _promote_selected_version(request_id: str, version: int) -> bool:
    """On draft approval with a reviewer-selected version, copy
    draft_versions/{request_id}/v{version}.docx (+ .json) over the served/final document so
    that the chosen version becomes final. Records approved_version. Returns True on success.
    """
    try:
        served_key = _resolve_served_doc_key(request_id)
        if not served_key:
            logger.warning(f"VERSION_PROMOTE | no served doc key for {request_id}")
            return False

        src_docx = f"draft_versions/{request_id}/v{version}.docx"
        s3_client.copy_object(
            Bucket=DOCUMENT_BUCKET,
            CopySource={'Bucket': DOCUMENT_BUCKET, 'Key': src_docx},
            Key=served_key,
            ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            MetadataDirective='REPLACE',
        )

        # Best-effort: promote the matching content JSON alongside the .docx.
        served_json = served_key[:-5] + '.json' if served_key.endswith('.docx') else None
        src_json = f"draft_versions/{request_id}/v{version}.json"
        if served_json and _s3_key_exists(src_json):
            try:
                s3_client.copy_object(
                    Bucket=DOCUMENT_BUCKET,
                    CopySource={'Bucket': DOCUMENT_BUCKET, 'Key': src_json},
                    Key=served_json,
                    ContentType='application/json',
                    MetadataDirective='REPLACE',
                )
            except Exception as je:
                logger.warning(f"VERSION_PROMOTE | json copy failed (non-fatal): {je}")

        # Audit: record which version was approved (non-fatal).
        try:
            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression='SET approved_version = :v, updated_at = :ts',
                ExpressionAttributeValues={':v': version, ':ts': _NOW()},
            )
        except Exception as ae:
            logger.warning(f"VERSION_PROMOTE | approved_version record failed (non-fatal): {ae}")

        logger.info(f"VERSION_PROMOTE | promoted v{version} -> {served_key} for {request_id}")
        return True
    except Exception as e:
        logger.error(f"VERSION_PROMOTE | failed for {request_id} v{version}: {e}")
        return False


def _apply_source_exclusions_to_s3(request_id: str, removed_sources: List[Dict]) -> None:
    """When user approves with exclusions, update the S3 research_data.json to remove
    excluded sources and citations. Matches by URL and title (reliable keys) — NOT by
    index position, which can drift between the HITL display order and S3 storage order.

    Args:
        request_id: The request ID
        removed_sources: List of source dicts from the HITL checkpoint (each has url, title, source_id)

    Non-fatal: if this fails, drafting proceeds with all sources (fail-open)."""
    try:
        s3_key = f"research/{request_id}/research_data.json"
        resp = s3_client.get_object(Bucket=DOCUMENT_BUCKET, Key=s3_key)
        research_data = json.loads(resp['Body'].read())

        # Build exclusion sets from the actual removed source objects
        removed_urls = set()
        removed_titles = set()
        for src in removed_sources:
            url = (src.get('url') or '').strip().lower()
            title = (src.get('title') or '').strip().lower()
            if url:
                removed_urls.add(url)
            if title:
                removed_titles.add(title)

        if not removed_urls and not removed_titles:
            logger.warning(f"HITL_EXCLUSION | request_id={request_id} | no URLs or titles to match — skipping")
            return

        # Filter all_sources
        original_sources = research_data.get('all_sources', [])
        filtered_sources = []
        for s in original_sources:
            url = (s.get('url') or '').strip().lower()
            title = (s.get('title') or '').strip().lower()
            if url and url in removed_urls:
                continue
            if title and title in removed_titles:
                continue
            filtered_sources.append(s)
        research_data['all_sources'] = filtered_sources

        # Filter formatted_citations
        original_citations = research_data.get('formatted_citations', [])
        filtered_citations = []
        for c in original_citations:
            url = (c.get('url') or '').strip().lower()
            title = (c.get('title') or '').strip().lower()
            if url and url in removed_urls:
                continue
            if title and title in removed_titles:
                continue
            filtered_citations.append(c)
        research_data['formatted_citations'] = filtered_citations

        # Write back to S3
        s3_client.put_object(
            Bucket=DOCUMENT_BUCKET, Key=s3_key,
            Body=json.dumps(research_data, default=str).encode('utf-8'),
            ContentType='application/json',
        )
        logger.info(
            f"HITL_EXCLUSION | request_id={request_id} | removed={len(removed_sources)} "
            f"| urls_matched={removed_urls} "
            f"| sources: {len(original_sources)} -> {len(filtered_sources)} "
            f"| citations: {len(original_citations)} -> {len(filtered_citations)}"
        )

        # Also update DynamoDB requests table so GET /requests/{id} returns filtered citations
        try:
            from decimal import Decimal

            def _float_to_decimal(obj):
                """Recursively convert float to Decimal for DynamoDB compatibility."""
                if isinstance(obj, float):
                    return Decimal(str(obj))
                if isinstance(obj, dict):
                    return {k: _float_to_decimal(v) for k, v in obj.items()}
                if isinstance(obj, list):
                    return [_float_to_decimal(i) for i in obj]
                return obj

            requests_table.update_item(
                Key={'request_id': request_id},
                UpdateExpression='SET #ro.#cit = :cit, #ro.#src = :src',
                ExpressionAttributeNames={
                    '#ro': 'research_output',
                    '#cit': 'citations',
                    '#src': 'sources',
                },
                ExpressionAttributeValues={
                    ':cit': _float_to_decimal(filtered_citations),
                    ':src': _float_to_decimal([{'title': s.get('title', ''), 'url': s.get('url', ''), 'type': s.get('type', '')} for s in filtered_sources if s.get('title')]),
                },
            )
            logger.info(f"HITL_EXCLUSION | DynamoDB research_output updated for {request_id}")
        except Exception as db_err:
            logger.warning(f"HITL_EXCLUSION | DynamoDB update failed (non-fatal): {db_err}")

    except Exception as e:
        logger.warning(f"HITL_EXCLUSION | failed (non-fatal, drafting continues with all sources): {e}")
