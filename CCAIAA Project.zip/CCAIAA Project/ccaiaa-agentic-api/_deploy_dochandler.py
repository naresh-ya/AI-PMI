"""One-off packager/deployer for pmi-document-handler-client-demo1.

This API lambda isn't in deploy_lambdas.py (deployed manually historically). It needs the
resolve-by-prefix fix so it finds the drafter's {Category}.docx instead of the old
hardcoded campaigns_output.docx. Backward-compatible. Bundles mammoth (preview endpoint).
"""
import os, shutil, tempfile, subprocess, zipfile, glob

FN = "pmi-document-handler-client-demo1"
SRC = "api/handler_document_download_new.py"
HANDLER_FILE = "handler_document_download.py"   # must match deployed Handler entry point
ZIP = "pmi-document-handler-client-demo1.zip"

with tempfile.TemporaryDirectory() as td:
    shutil.copy2(SRC, os.path.join(td, HANDLER_FILE))

    pkg = os.path.join(td, "_pkg")
    os.makedirs(pkg)
    print("Downloading mammoth (+deps)...")
    subprocess.run(
        ["pip", "download", "mammoth", "-d", pkg,
         "--platform", "manylinux2014_x86_64", "--python-version", "3.10",
         "--only-binary=:all:"],
        check=True, capture_output=True,
    )
    for whl in glob.glob(os.path.join(pkg, "*.whl")):
        with zipfile.ZipFile(whl) as w:
            w.extractall(td)
    shutil.rmtree(pkg)

    print("Zipping...")
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(td):
            if "__pycache__" in root:
                continue
            for f in files:
                if f.endswith(".pyc"):
                    continue
                fp = os.path.join(root, f)
                zf.write(fp, os.path.relpath(fp, td))

print("Deploying update-function-code...")
subprocess.run(
    ["aws", "lambda", "update-function-code", "--function-name", FN,
     "--zip-file", f"fileb://{ZIP}", "--no-cli-pager",
     "--query", "LastUpdateStatus", "--output", "text"],
    check=True,
)
if os.path.exists(ZIP):
    os.remove(ZIP)
print("DONE")
