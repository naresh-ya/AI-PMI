================================================================================
                    PMI AGENTIC AI PLATFORM - DEVELOPER GUIDE
================================================================================

This guide helps developers clone and set up the PMI Corporate Affairs Agentic 
AI Backend project.

================================================================================
                              PREREQUISITES
================================================================================

Before cloning, ensure you have the following installed:

1. Git                    - https://git-scm.com/downloads
2. Python 3.10+           - https://www.python.org/downloads/
3. AWS CLI                - https://aws.amazon.com/cli/
4. Node.js 18+ (for CDK)  - https://nodejs.org/
5. AWS CDK                - npm install -g aws-cdk

================================================================================
                              CLONE THE REPOSITORY
================================================================================

--------------------------------------------------------------------------------
STEP 1: GENERATE HTTP ACCESS TOKEN
--------------------------------------------------------------------------------

1. Go to Bitbucket: https://source.app.pconnect.biz
2. Click on your Profile icon (top right) -> Manage Account
3. Navigate to HTTP Access Tokens
4. Click "Create token"
5. Enter a token name (e.g., ccaiaa-dev-token)
6. Set permissions:
   - Project permissions: Project read (minimum)
   - Repository permissions: Repository write
7. Click "Create"
8. COPY THE TOKEN IMMEDIATELY - you won't be able to see it again!

--------------------------------------------------------------------------------
STEP 2: CLONE THE REPOSITORY
--------------------------------------------------------------------------------

Replace YOUR_EMAIL and YOUR_TOKEN with your Bitbucket email and the token.

IMPORTANT: Replace @ in your email with %40 and + in token with %2B

Command:
git clone "https://YOUR_EMAIL%40pmintl.net:YOUR_TOKEN@source.app.pconnect.biz/scm/ccaiaa/ccaiaa-agentic-api.git"

Example:
git clone "https://jdoe%40pmintl.net:BBDC-xxxxxxxxxxxx@source.app.pconnect.biz/scm/ccaiaa/ccaiaa-agentic-api.git"

Then navigate to the project:
cd ccaiaa-agentic-api

--------------------------------------------------------------------------------
STEP 3: CONFIGURE GIT USER (FIRST TIME ONLY)
--------------------------------------------------------------------------------

Set your Git identity:
git config user.name "Your Name"
git config user.email "your.email@pmintl.net"

To set globally (for all repositories):
git config --global user.name "Your Name"
git config --global user.email "your.email@pmintl.net"

================================================================================
                              PROJECT SETUP
================================================================================

Step 1: Create Virtual Environment
----------------------------------
python -m venv venv

Step 2: Activate Virtual Environment
------------------------------------
Windows (PowerShell):
    .\venv\Scripts\Activate.ps1

Windows (CMD):
    venv\Scripts\activate.bat

Linux/Mac:
    source venv/bin/activate

Step 3: Install Dependencies
----------------------------
pip install -r requirements.txt

Step 4: Configure Environment Variables
---------------------------------------
Copy the template and fill in your values:
    copy .env.template .env

Edit .env with your AWS credentials and configuration.

Step 5: Configure AWS CLI
-------------------------
aws configure

Enter your:
- AWS Access Key ID
- AWS Secret Access Key
- Default region (e.g., us-east-1)
- Default output format (json)

================================================================================
                              PROJECT STRUCTURE
================================================================================

ccaiaa-agentic-api/
│
├── agents/                 # AI Agent Lambda handlers
│   ├── input_validator/    # Request validation agent
│   ├── master_researcher/  # Research coordination agent
│   ├── master_drafter/     # Document drafting agent
│   └── master_reviewer/    # Compliance review agent
│
├── api/                    # API Gateway handler
├── core/                   # Core business logic
│   ├── hitl_manager.py     # Human-in-the-loop management
│   ├── kb_integration.py   # Knowledge base integration
│   ├── orchestration_engine.py
│   └── system_prompts.py   # AI agent prompts
│
├── hitl/                   # Human-in-the-loop web interface
├── infrastructure/         # AWS CDK infrastructure code
├── knowledge_base/         # Document processing & search
├── scripts/                # Deployment & test scripts
├── tests/                  # Unit tests
│
├── app.py                  # CDK app entry point
├── cdk.json                # CDK configuration
├── requirements.txt        # Python dependencies
└── pyproject.toml          # Project configuration

================================================================================
                              DEPLOYMENT
================================================================================

Step 1: Bootstrap CDK (first time only)
---------------------------------------
cdk bootstrap

Step 2: Deploy to AWS
---------------------
cd scripts
.\deploy.ps1

Or manually:
    cdk deploy --all

================================================================================
                              RUNNING TESTS
================================================================================

Run all tests:
    pytest tests/

Run specific test file:
    pytest tests/test_input_validator.py

Run with verbose output:
    pytest tests/ -v

================================================================================
                              USEFUL SCRIPTS
================================================================================

All scripts are in the /scripts folder:

| Script                      | Description                          |
|-----------------------------|--------------------------------------|
| deploy.ps1                  | Deploy infrastructure to AWS         |
| deploy-enhanced.ps1         | Enhanced deployment with options     |
| test-api.ps1                | Test API endpoints                   |
| test-agentic-workflow.ps1   | Test full agentic workflow           |
| build-knowledge-base.ps1    | Build document knowledge base        |
| test-knowledge-base.ps1     | Test knowledge base functionality    |

================================================================================
                              KEY TECHNOLOGIES
================================================================================

- AWS Bedrock         - AI/LLM services (Claude)
- AWS Lambda          - Serverless compute
- AWS Step Functions  - Workflow orchestration
- AWS DynamoDB        - NoSQL database
- AWS S3              - Document storage
- AWS API Gateway     - REST API
- AWS CDK             - Infrastructure as Code

================================================================================
                              GETTING HELP
================================================================================

1. Read README.md for detailed documentation
2. Read README_AGENTIC.md for agentic workflow details
3. Check KNOWLEDGE_BASE_SUMMARY.md for KB information

================================================================================
                              CONTACT
================================================================================

For questions or issues, contact the PMI Corporate Affairs AI team.

================================================================================
