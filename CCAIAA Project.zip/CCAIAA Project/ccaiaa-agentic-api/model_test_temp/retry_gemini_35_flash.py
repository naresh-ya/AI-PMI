"""
Retry script for gemini-3.5-flash Q05-Q20
Skips Q01-Q04 which already succeeded
"""
import sys
import os
import json
import time
from pathlib import Path
from datetime import datetime
import requests
import urllib3

# Disable SSL warnings for self-signed certs
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Configuration
LITELLM_URL = "https://litellm.aiplat-dev.aws.private-pmideep.biz"
MODEL = "gemini-3.5-flash"
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY")
AWS_TOKEN = os.environ.get("AWS_BEARER_TOKEN_BEDROCK")

# Directories
SCRIPT_DIR = Path(__file__).parent
RESULTS_DIR = SCRIPT_DIR / "results" / "run_20260929_085055" / "gemini-3.5-flash"
QUERIES_FILE = SCRIPT_DIR / "test_queries.json"
CONFIG_FILE = SCRIPT_DIR / "config" / "model_configs.json"

# Load queries
with open(QUERIES_FILE, 'r') as f:
    queries_data = json.load(f)
    queries = queries_data.get("queries", [])

# Load model config
with open(CONFIG_FILE, 'r') as f:
    model_configs = json.load(f)
    
model_config = model_configs.get(MODEL, {})

# Pricing (per million tokens)
INPUT_PRICE = 0.00015  # $0.15 per 1M tokens
OUTPUT_PRICE = 0.0006  # $0.60 per 1M tokens

def calculate_cost(input_tokens, output_tokens):
    """Calculate cost in USD"""
    input_cost = (input_tokens / 1_000_000) * INPUT_PRICE
    output_cost = (output_tokens / 1_000_000) * OUTPUT_PRICE
    return {
        "input_cost_usd": input_cost,
        "output_cost_usd": output_cost,
        "total_cost_usd": input_cost + output_cost
    }

def call_litellm_with_tools(query_text, timeout_seconds=120):
    """
    Call LiteLLM with web search and URL extraction tools
    Timeout set to 2 minutes (120 seconds) to avoid 25-minute hangs
    """
    headers = {
        "Authorization": f"Bearer {AWS_TOKEN}",
        "Content-Type": "application/json"
    }
    
    tools = [
        {
            "type": "function",
            "function": {
                "name": "tavily_web_search",
                "description": "Search the web for current information using Tavily API",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The search query"
                        }
                    },
                    "required": ["query"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "extract_url_context",
                "description": "Extract detailed context from a specific URL",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The URL to extract context from"
                        }
                    },
                    "required": ["url"]
                }
            }
        }
    ]
    
    payload = {
        "model": MODEL,
        "messages": [
            {
                "role": "user",
                "content": query_text
            }
        ],
        "tools": tools,
        "temperature": 0.3,
        "max_tokens": 4096
    }
    
    start_time = time.time()
    
    try:
        # Use timeout parameter to prevent 25-minute hangs
        response = requests.post(
            f"{LITELLM_URL}/chat/completions",
            headers=headers,
            json=payload,
            verify=False,  # Internal PMI endpoint with self-signed cert
            timeout=timeout_seconds  # 2 minute timeout
        )
        
        latency_ms = int((time.time() - start_time) * 1000)
        
        if response.status_code == 200:
            result = response.json()
            
            # Extract content
            message = result.get("choices", [{}])[0].get("message", {})
            content = message.get("content", "")
            
            # Check for tool calls (grounding)
            tool_calls = message.get("tool_calls", [])
            grounding_used = len(tool_calls) > 0
            
            # Extract grounding sources if available
            sources = []
            if grounding_used:
                for tool_call in tool_calls:
                    if tool_call.get("function", {}).get("name") == "tavily_web_search":
                        # In real implementation, sources would come from tool response
                        # For now, just flag that grounding was used
                        pass
            
            # Get usage stats
            usage = result.get("usage", {})
            input_tokens = usage.get("prompt_tokens", 0)
            output_tokens = usage.get("completion_tokens", 0)
            
            return {
                "success": True,
                "error": None,
                "content": content,
                "sources": sources,
                "grounding_used": grounding_used,
                "metrics": {
                    "latency_ms": latency_ms,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "total_tokens": input_tokens + output_tokens
                }
            }
        else:
            return {
                "success": False,
                "error": f"HTTP {response.status_code}: {response.text}",
                "content": "",
                "sources": [],
                "grounding_used": False,
                "metrics": {
                    "latency_ms": latency_ms,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0
                }
            }
            
    except requests.exceptions.Timeout:
        latency_ms = int((time.time() - start_time) * 1000)
        return {
            "success": False,
            "error": f"Request timeout after {timeout_seconds} seconds",
            "content": "",
            "sources": [],
            "grounding_used": False,
            "metrics": {
                "latency_ms": latency_ms,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0
            }
        }
    except Exception as e:
        latency_ms = int((time.time() - start_time) * 1000)
        return {
            "success": False,
            "error": str(e),
            "content": "",
            "sources": [],
            "grounding_used": False,
            "metrics": {
                "latency_ms": latency_ms,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0
            }
        }

def main():
    print(f"=== Retry gemini-3.5-flash Q05-Q20 ===")
    print(f"Model: {MODEL}")
    print(f"Queries to retry: Q05-Q20 (16 queries)")
    print(f"Timeout per query: 120 seconds (2 minutes)")
    print(f"Results directory: {RESULTS_DIR}")
    print()
    
    # Filter to Q05-Q20 only
    queries_to_run = [q for q in queries if int(q["id"].replace("Q", "")) >= 5]
    
    success_count = 0
    fail_count = 0
    
    for idx, query_obj in enumerate(queries_to_run, 1):
        query_id = query_obj["id"]
        query_type = query_obj["type"]
        
        # Handle different query types
        if query_type == "web_search":
            query_text = query_obj["query"]
        elif query_type == "url_extraction":
            query_text = f"Extract key information from this URL: {query_obj['url']}"
        else:
            print(f"⚠ Unknown query type: {query_type}, skipping")
            continue
        
        print(f"\n[{idx}/{len(queries_to_run)}] Testing {query_id} - {query_type}")
        print(f"Query: {query_text}")
        
        # Call model
        result = call_litellm_with_tools(query_text, timeout_seconds=120)
        
        # Calculate costs
        costs = calculate_cost(
            result["metrics"]["input_tokens"],
            result["metrics"]["output_tokens"]
        )
        
        # Save result
        result_file = RESULTS_DIR / f"{query_id}_result.json"
        result_data = {
            "timestamp": datetime.now().isoformat(),
            "query_id": query_id,
            "query_type": query_type,
            "model": MODEL,
            "query": query_text,
            "result": result,
            "costs": costs,
            "model_config": model_config
        }
        
        with open(result_file, 'w') as f:
            json.dump(result_data, f, indent=2)
        
        # Update counts
        if result["success"]:
            success_count += 1
            print(f"✓ Success - Latency: {result['metrics']['latency_ms']:,}ms, Cost: ${costs['total_cost_usd']:.6f}")
        else:
            fail_count += 1
            print(f"✗ Failed - Error: {result['error']}")
        
        # Brief pause between queries
        if idx < len(queries_to_run):
            time.sleep(2)
    
    print(f"\n=== Retry Complete ===")
    print(f"Success: {success_count}/{len(queries_to_run)}")
    print(f"Failed: {fail_count}/{len(queries_to_run)}")
    print(f"\nResults saved to: {RESULTS_DIR}")
    print("\nNote: Run generate_summary.py to regenerate the summary with all results")

if __name__ == "__main__":
    main()
