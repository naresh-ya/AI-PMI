#!/usr/bin/env python3
"""
Simple Model Comparison Test - Dry Run Version
Tests one model with one query to verify setup
"""

import json
import os
import sys
import time
import urllib.request
import ssl
from datetime import datetime
from pathlib import Path

# Add parent directory to path to import from core/agents
sys.path.insert(0, str(Path(__file__).parent.parent))

# Configuration
LITELLM_URL = os.getenv('LITELLM_URL', 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions')
LITELLM_KEY = os.getenv('AWS_BEARER_TOKEN_BEDROCK', '')
TAVILY_API_KEY = os.getenv('TAVILY_API_KEY', '')

# SSL context
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

def load_test_queries():
    """Load test queries from JSON file"""
    with open('test_queries.json', 'r') as f:
        return json.load(f)

def load_model_configs():
    """Load model configurations"""
    with open('config/model_configs.json', 'r') as f:
        return json.load(f)

def test_gemini_web_search(model_id, query):
    """
    Test Gemini web search with native google_search tool
    """
    if not LITELLM_KEY:
        return {
            'success': False,
            'error': 'LITELLM_KEY not set',
            'content': '',
            'sources': [],
            'metrics': {}
        }
    
    start_time = time.time()
    
    body = {
        "model": model_id,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0,
        "max_tokens": 2048,
        "tools": [{"google_search": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    
    try:
        req = urllib.request.Request(
            LITELLM_URL,
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        latency_ms = int((time.time() - start_time) * 1000)
        
        # Extract content
        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        
        # Extract grounding metadata
        grounding_meta = data.get('vertex_ai_grounding_metadata', [])
        grounding_used = any(bool(g) for g in grounding_meta)
        
        # Extract sources
        sources = []
        try:
            for entry in grounding_meta:
                for chunk in (entry.get('groundingChunks') or []):
                    web = chunk.get('web') or {}
                    if web.get('uri'):
                        sources.append({
                            'title': web.get('title', ''),
                            'url': web['uri']
                        })
        except Exception:
            pass
        
        # Extract token usage
        usage = data.get('usage', {})
        input_tokens = usage.get('prompt_tokens', 0)
        output_tokens = usage.get('completion_tokens', 0)
        total_tokens = usage.get('total_tokens', 0)
        
        return {
            'success': True,
            'error': None,
            'content': content.strip(),
            'sources': sources,
            'grounding_used': grounding_used,
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens,
                'total_tokens': total_tokens,
            }
        }
    except urllib.error.HTTPError as e:
        latency_ms = int((time.time() - start_time) * 1000)
        error_body = e.read().decode('utf-8') if e.fp else ''
        error_msg = f"HTTP Error {e.code}: {e.reason}"
        if error_body:
            try:
                error_data = json.loads(error_body)
                error_msg = f"{error_msg} - {json.dumps(error_data, indent=2)}"
            except:
                error_msg = f"{error_msg} - {error_body}"
        return {
            'success': False,
            'error': error_msg,
            'content': '',
            'sources': [],
            'grounding_used': False,
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': 0,
                'output_tokens': 0,
                'total_tokens': 0,
            }
        }
    except Exception as e:
        latency_ms = int((time.time() - start_time) * 1000)
        return {
            'success': False,
            'error': str(e),
            'content': '',
            'sources': [],
            'grounding_used': False,
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': 0,
                'output_tokens': 0,
                'total_tokens': 0,
            }
        }

def calculate_cost(model_config, input_tokens, output_tokens):
    """Calculate cost for a query"""
    input_cost = (input_tokens / 1_000_000) * model_config['input_cost_per_1m']
    output_cost = (output_tokens / 1_000_000) * model_config['output_cost_per_1m']
    tavily_cost = model_config.get('tavily_cost_per_search', 0) if model_config.get('requires_tavily', False) else 0
    total_cost = input_cost + output_cost + tavily_cost
    return {
        'input_cost_usd': input_cost,
        'output_cost_usd': output_cost,
        'tavily_cost_usd': tavily_cost,
        'total_cost_usd': total_cost
    }

def run_dry_run():
    """Run a single test with gemini-1.5-flash and Q01"""
    print("=" * 80)
    print("MODEL COMPARISON TEST - DRY RUN")
    print("=" * 80)
    print()
    
    # Check environment
    print("Environment Check:")
    print(f"  LITELLM_URL: {LITELLM_URL}")
    print(f"  LITELLM_KEY: {'SET' if LITELLM_KEY else 'NOT SET'}")
    print(f"  TAVILY_API_KEY: {'SET' if TAVILY_API_KEY else 'NOT SET'}")
    print()
    
    if not LITELLM_KEY:
        print("ERROR: LITELLM_KEY environment variable not set!")
        print("Please set it before running the test.")
        return
    
    # Load configurations
    print("Loading configurations...")
    test_data = load_test_queries()
    model_configs = load_model_configs()
    print(f"  Loaded {len(test_data['queries'])} queries")
    print(f"  Loaded {len(model_configs['models'])} model configurations")
    print()
    
    # Get first web search query
    query_data = test_data['queries'][0]  # Q01
    model_id = 'gemini-2.5-flash'  # PRIMARY CANDIDATE - 88% cheaper
    model_config = model_configs['models'][model_id]
    
    print(f"Test Query: {query_data['id']}")
    print(f"  Type: {query_data['type']}")
    print(f"  Query: {query_data['query']}")
    print()
    
    print(f"Test Model: {model_id}")
    print(f"  Provider: {model_config['provider']}")
    print(f"  Description: {model_config['description']}")
    print()
    
    # Run test
    print("Running test...")
    print("-" * 80)
    result = test_gemini_web_search(model_id, query_data['query'])
    print()
    
    # Display results
    if result['success']:
        print("✅ TEST SUCCESSFUL")
        print()
        print(f"Latency: {result['metrics']['latency_ms']}ms")
        print(f"Tokens: {result['metrics']['input_tokens']} input + {result['metrics']['output_tokens']} output = {result['metrics']['total_tokens']} total")
        print(f"Grounding used: {result['grounding_used']}")
        print(f"Sources found: {len(result['sources'])}")
        print()
        
        # Calculate cost
        costs = calculate_cost(
            model_config,
            result['metrics']['input_tokens'],
            result['metrics']['output_tokens']
        )
        print(f"Cost: ${costs['total_cost_usd']:.6f}")
        print(f"  Input: ${costs['input_cost_usd']:.6f}")
        print(f"  Output: ${costs['output_cost_usd']:.6f}")
        print()
        
        # Show sources
        if result['sources']:
            print("Sources:")
            for i, source in enumerate(result['sources'][:5], 1):
                print(f"  {i}. {source['title']}")
                print(f"     {source['url']}")
        print()
        
        # Show content preview
        print("Content Preview:")
        content_preview = result['content'][:500] + "..." if len(result['content']) > 500 else result['content']
        print(content_preview)
        print()
        
        # Save result
        output_dir = Path('results/dry_run')
        output_dir.mkdir(parents=True, exist_ok=True)
        
        output_file = output_dir / f"{query_data['id']}_{model_id}_result.json"
        result_data = {
            'query_id': query_data['id'],
            'query': query_data['query'],
            'model': model_id,
            'timestamp': datetime.now().isoformat(),
            'result': result,
            'costs': costs
        }
        
        with open(output_file, 'w') as f:
            json.dump(result_data, f, indent=2)
        
        print(f"Result saved to: {output_file}")
        print()
        print("=" * 80)
        print("DRY RUN COMPLETE - Setup verified!")
        print("=" * 80)
    else:
        print("❌ TEST FAILED")
        print()
        print(f"Error: {result['error']}")
        print()
        print("=" * 80)
        print("DRY RUN FAILED - Please check configuration")
        print("=" * 80)

if __name__ == '__main__':
    run_dry_run()
