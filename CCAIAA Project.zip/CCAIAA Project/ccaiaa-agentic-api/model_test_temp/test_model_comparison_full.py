#!/usr/bin/env python3
"""
Comprehensive Model Comparison Test - Full Execution
Tests 5 models with 20 queries for leadership report
"""

import json
import os
import sys
import time
import urllib.request
import ssl
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# Add parent directory to path to import from core/agents
sys.path.insert(0, str(Path(__file__).parent.parent))

# Configuration
LITELLM_URL = os.getenv('LITELLM_URL', 'https://litellm.aiplat-dev.aws.private-pmideep.biz')
LITELLM_KEY = os.getenv('AWS_BEARER_TOKEN_BEDROCK', '')
TAVILY_API_KEY = os.getenv('TAVILY_API_KEY', '')

# SSL context
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

def load_test_queries():
    """Load test queries from JSON file"""
    with open('test_queries.json', 'r') as f:
        return json.load(f)

def load_model_configs():
    """Load model configurations"""
    with open('config/model_configs.json', 'r') as f:
        return json.load(f)

def test_gemini_web_search(model_id, query, query_id):
    """Test Gemini web search with native google_search tool"""
    if not LITELLM_KEY:
        return {
            'success': False,
            'error': 'LITELLM_KEY not set',
            'content': '',
            'sources': [],
            'metrics': {}
        }
    
    start_time = time.time()
    
    body = {
        "model": model_id,
        "messages": [{"role": "user", "content": query}],
        "temperature": 0,
        "max_tokens": 2048,
        "tools": [{"google_search": {}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    
    try:
        req = urllib.request.Request(
            f"{LITELLM_URL}/chat/completions",
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        latency_ms = int((time.time() - start_time) * 1000)
        
        # Extract content
        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        
        # Extract grounding metadata
        grounding_meta = data.get('vertex_ai_grounding_metadata', [])
        grounding_used = any(bool(g) for g in grounding_meta)
        
        # Extract sources
        sources = []
        try:
            for entry in grounding_meta:
                for chunk in (entry.get('groundingChunks') or []):
                    web = chunk.get('web') or {}
                    if web.get('uri'):
                        sources.append({
                            'title': web.get('title', ''),
                            'url': web['uri']
                        })
        except Exception:
            pass
        
        # Extract token usage
        usage = data.get('usage', {})
        input_tokens = usage.get('prompt_tokens', 0)
        output_tokens = usage.get('completion_tokens', 0)
        total_tokens = usage.get('total_tokens', 0)
        
        return {
            'success': True,
            'error': None,
            'content': content.strip(),
            'sources': sources,
            'grounding_used': grounding_used,
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens,
                'total_tokens': total_tokens,
            }
        }
    except urllib.error.HTTPError as e:
        latency_ms = int((time.time() - start_time) * 1000)
        error_body = e.read().decode('utf-8') if e.fp else ''
        error_msg = f"HTTP {e.code}: {e.reason}"
        if error_body:
            try:
                error_data = json.loads(error_body)
                error_msg = error_data.get('error', {}).get('message', error_msg)
            except:
                pass
        return {
            'success': False,
            'error': error_msg,
            'content': '',
            'sources': [],
            'grounding_used': False,
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': 0,
                'output_tokens': 0,
                'total_tokens': 0,
            }
        }
    except Exception as e:
        latency_ms = int((time.time() - start_time) * 1000)
        return {
            'success': False,
            'error': str(e),
            'content': '',
            'sources': [],
            'grounding_used': False,
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': 0,
                'output_tokens': 0,
                'total_tokens': 0,
            }
        }

def test_gemini_url_extraction(model_id, url, query_id):
    """Test Gemini URL extraction with url_context tool"""
    if not LITELLM_KEY:
        return {
            'success': False,
            'error': 'LITELLM_KEY not set',
            'content': '',
            'metrics': {}
        }
    
    start_time = time.time()
    
    prompt = f"Extract and summarize the key information from this URL: {url}"
    
    body = {
        "model": model_id,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 2048,
        "tools": [{"url_context": {"urls": [url]}}],
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LITELLM_KEY}",
    }
    
    try:
        req = urllib.request.Request(
            f"{LITELLM_URL}/chat/completions",
            data=json.dumps(body).encode('utf-8'),
            headers=headers,
            method='POST',
        )
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=60) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        latency_ms = int((time.time() - start_time) * 1000)
        
        # Extract content
        content = ((data.get('choices') or [{}])[0].get('message') or {}).get('content') or ''
        
        # Extract token usage
        usage = data.get('usage', {})
        input_tokens = usage.get('prompt_tokens', 0)
        output_tokens = usage.get('completion_tokens', 0)
        total_tokens = usage.get('total_tokens', 0)
        
        return {
            'success': True,
            'error': None,
            'content': content.strip(),
            'url': url,
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens,
                'total_tokens': total_tokens,
            }
        }
    except urllib.error.HTTPError as e:
        latency_ms = int((time.time() - start_time) * 1000)
        error_body = e.read().decode('utf-8') if e.fp else ''
        error_msg = f"HTTP {e.code}: {e.reason}"
        if error_body:
            try:
                error_data = json.loads(error_body)
                error_msg = error_data.get('error', {}).get('message', error_msg)
            except:
                pass
        return {
            'success': False,
            'error': error_msg,
            'content': '',
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': 0,
                'output_tokens': 0,
                'total_tokens': 0,
            }
        }
    except Exception as e:
        latency_ms = int((time.time() - start_time) * 1000)
        return {
            'success': False,
            'error': str(e),
            'content': '',
            'metrics': {
                'latency_ms': latency_ms,
                'input_tokens': 0,
                'output_tokens': 0,
                'total_tokens': 0,
            }
        }

def calculate_cost(model_config, input_tokens, output_tokens):
    """Calculate cost for a query"""
    input_cost = (input_tokens / 1_000_000) * model_config['input_cost_per_1m']
    output_cost = (output_tokens / 1_000_000) * model_config['output_cost_per_1m']
    total_cost = input_cost + output_cost
    return {
        'input_cost_usd': input_cost,
        'output_cost_usd': output_cost,
        'total_cost_usd': total_cost
    }

def run_single_test(model_id, model_config, query_data):
    """Run a single test for one model and one query"""
    query_id = query_data['id']
    query_type = query_data['type']
    
    print(f"  Testing {model_id} with {query_id} ({query_type})...", end='', flush=True)
    
    if query_type == 'web_search':
        result = test_gemini_web_search(model_id, query_data['query'], query_id)
    else:  # url_extraction
        result = test_gemini_url_extraction(model_id, query_data['url'], query_id)
    
    # Calculate cost
    costs = calculate_cost(
        model_config,
        result['metrics'].get('input_tokens', 0),
        result['metrics'].get('output_tokens', 0)
    )
    
    # Combine results
    test_result = {
        'timestamp': datetime.now().isoformat(),
        'query_id': query_id,
        'query_type': query_type,
        'model': model_id,
        'query': query_data.get('query') or query_data.get('url'),
        'result': result,
        'costs': costs,
        'model_config': {
            'provider': model_config['provider'],
            'description': model_config['description'],
            'status': model_config.get('status', 'unknown')
        }
    }
    
    status = "✅" if result['success'] else "❌"
    latency = result['metrics'].get('latency_ms', 0)
    cost = costs['total_cost_usd']
    print(f" {status} {latency}ms ${cost:.6f}")
    
    return test_result

def save_result(model_id, query_id, result, output_dir):
    """Save individual test result"""
    model_dir = output_dir / model_id
    model_dir.mkdir(parents=True, exist_ok=True)
    
    output_file = model_dir / f"{query_id}_result.json"
    with open(output_file, 'w') as f:
        json.dump(result, f, indent=2)

def run_all_tests():
    """Run all tests: 5 models × 20 queries = 100 tests"""
    print("=" * 80)
    print("COMPREHENSIVE MODEL COMPARISON TEST - FULL EXECUTION")
    print("=" * 80)
    print()
    
    # Load configurations
    print("Loading configurations...")
    test_data = load_test_queries()
    model_configs = load_model_configs()
    queries = test_data['queries']
    models = model_configs['models']
    
    print(f"  Models: {len(models)}")
    print(f"  Queries: {len(queries)}")
    print(f"  Total tests: {len(models)} × {len(queries)} = {len(models) * len(queries)}")
    print()
    
    # Create output directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path('results') / f'run_{timestamp}'
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir}")
    print()
    
    # Run tests
    all_results = []
    test_count = 0
    total_tests = len(models) * len(queries)
    
    start_time = time.time()
    
    for model_id, model_config in models.items():
        print(f"\n{'=' * 80}")
        print(f"Testing Model: {model_id}")
        print(f"Description: {model_config['description']}")
        print(f"{'=' * 80}\n")
        
        for query_data in queries:
            test_count += 1
            progress = (test_count / total_tests) * 100
            print(f"[{test_count}/{total_tests} - {progress:.1f}%] ", end='')
            
            result = run_single_test(model_id, model_config, query_data)
            all_results.append(result)
            
            # Save individual result
            save_result(model_id, query_data['id'], result, output_dir)
    
    elapsed_time = time.time() - start_time
    
    # Save all results
    print(f"\n{'=' * 80}")
    print("SAVING RESULTS")
    print(f"{'=' * 80}\n")
    
    all_results_file = output_dir / 'all_results.json'
    with open(all_results_file, 'w') as f:
        json.dump(all_results, f, indent=2)
    print(f"All results saved to: {all_results_file}")
    
    # Generate summary
    summary = generate_summary(all_results, models, elapsed_time)
    summary_file = output_dir / 'summary.json'
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"Summary saved to: {summary_file}")
    
    print(f"\n{'=' * 80}")
    print("TEST EXECUTION COMPLETE")
    print(f"{'=' * 80}")
    print(f"Total tests: {test_count}")
    print(f"Duration: {elapsed_time:.1f}s ({elapsed_time/60:.1f} minutes)")
    print(f"Results directory: {output_dir}")
    print()
    
    return output_dir, summary

def generate_summary(all_results, models, elapsed_time):
    """Generate summary statistics"""
    summary = {
        'test_metadata': {
            'timestamp': datetime.now().isoformat(),
            'total_tests': len(all_results),
            'duration_seconds': elapsed_time,
            'models_tested': len(models),
            'queries_tested': len(all_results) // len(models)
        },
        'by_model': {}
    }
    
    for model_id in models.keys():
        model_results = [r for r in all_results if r['model'] == model_id]
        
        successful = [r for r in model_results if r['result']['success']]
        failed = [r for r in model_results if not r['result']['success']]
        
        web_search_results = [r for r in successful if r['query_type'] == 'web_search']
        url_extraction_results = [r for r in successful if r['query_type'] == 'url_extraction']
        
        latencies = [r['result']['metrics']['latency_ms'] for r in successful]
        costs = [r['costs']['total_cost_usd'] for r in successful]
        
        source_counts = [len(r['result'].get('sources', [])) for r in web_search_results]
        
        summary['by_model'][model_id] = {
            'total_tests': len(model_results),
            'successful': len(successful),
            'failed': len(failed),
            'success_rate': (len(successful) / len(model_results) * 100) if model_results else 0,
            'web_search_tests': len(web_search_results),
            'url_extraction_tests': len(url_extraction_results),
            'latency': {
                'avg_ms': sum(latencies) / len(latencies) if latencies else 0,
                'min_ms': min(latencies) if latencies else 0,
                'max_ms': max(latencies) if latencies else 0,
            },
            'cost': {
                'avg_per_query': sum(costs) / len(costs) if costs else 0,
                'total': sum(costs),
                'per_10k_queries': (sum(costs) / len(costs) * 10000) if costs else 0,
            },
            'sources': {
                'avg_per_search': sum(source_counts) / len(source_counts) if source_counts else 0,
                'total': sum(source_counts),
            }
        }
    
    return summary

if __name__ == '__main__':
    run_all_tests()
