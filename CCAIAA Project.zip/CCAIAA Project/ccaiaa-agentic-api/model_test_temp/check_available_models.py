#!/usr/bin/env python3
"""
Check which models are available in the LiteLLM gateway
"""

import json
import os
import urllib.request
import ssl

# Configuration
LITELLM_URL = os.getenv('LITELLM_URL', 'https://litellm.aiplat-dev.aws.private-pmideep.biz')
LITELLM_KEY = os.getenv('AWS_BEARER_TOKEN_BEDROCK', '')

# SSL context
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

def check_models_endpoint():
    """Try to get list of available models from LiteLLM"""
    endpoints_to_try = [
        f"{LITELLM_URL}/models",
        f"{LITELLM_URL}/v1/models",
        f"{LITELLM_URL}/model/info",
    ]
    
    headers = {
        "Authorization": f"Bearer {LITELLM_KEY}",
        "Content-Type": "application/json",
    }
    
    print("Checking for models endpoint...")
    print("-" * 80)
    
    for endpoint in endpoints_to_try:
        print(f"\nTrying: {endpoint}")
        try:
            req = urllib.request.Request(endpoint, headers=headers)
            with urllib.request.urlopen(req, context=_SSL_CTX, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                print(f"✅ SUCCESS!")
                print(json.dumps(data, indent=2))
                return data
        except urllib.error.HTTPError as e:
            print(f"❌ HTTP {e.code}: {e.reason}")
            try:
                error_body = e.read().decode('utf-8')
                print(f"   {error_body[:200]}")
            except:
                pass
        except Exception as e:
            print(f"❌ Error: {e}")
    
    return None

def test_individual_models():
    """Test individual models by trying to call them"""
    
    # Models to test based on the plan
    models_to_test = [
        "gemini-2.5-pro",           # Current (deprecated)
        "gemini-1.5-pro",           # Premium
        "gemini-1.5-flash",         # Primary candidate
        "gemini-1.5-flash-8b",      # Economy
        "gemini-2.0-flash-exp",     # Experimental
        "gpt-4o",                   # OpenAI premium
        "gpt-4o-mini",              # OpenAI balanced
        "claude-3-5-sonnet-20241022", # Anthropic (for reference)
    ]
    
    print("\n" + "=" * 80)
    print("TESTING INDIVIDUAL MODELS")
    print("=" * 80)
    
    available_models = []
    unavailable_models = []
    
    for model in models_to_test:
        print(f"\nTesting: {model}")
        print("-" * 40)
        
        # Simple test call
        body = {
            "model": model,
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 10,
            "temperature": 0,
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {LITELLM_KEY}",
        }
        
        try:
            req = urllib.request.Request(
                f"{LITELLM_URL}/chat/completions",
                data=json.dumps(body).encode('utf-8'),
                headers=headers,
                method='POST',
            )
            with urllib.request.urlopen(req, context=_SSL_CTX, timeout=15) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                print(f"✅ AVAILABLE")
                available_models.append(model)
                
                # Show model info
                if 'model' in data:
                    print(f"   Actual model: {data['model']}")
                if 'usage' in data:
                    print(f"   Usage: {data['usage']}")
                    
        except urllib.error.HTTPError as e:
            try:
                error_body = e.read().decode('utf-8')
                error_data = json.loads(error_body)
                error_msg = error_data.get('error', {}).get('message', '')
                
                if 'no healthy deployments' in error_msg.lower():
                    print(f"❌ NOT AVAILABLE: No healthy deployments")
                    unavailable_models.append((model, "No deployments"))
                elif 'model not found' in error_msg.lower():
                    print(f"❌ NOT AVAILABLE: Model not found")
                    unavailable_models.append((model, "Not found"))
                else:
                    print(f"❌ ERROR: {error_msg[:100]}")
                    unavailable_models.append((model, error_msg[:100]))
            except:
                print(f"❌ HTTP {e.code}: {e.reason}")
                unavailable_models.append((model, f"HTTP {e.code}"))
                
        except Exception as e:
            print(f"❌ ERROR: {str(e)[:100]}")
            unavailable_models.append((model, str(e)[:100]))
    
    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"\n✅ AVAILABLE MODELS ({len(available_models)}):")
    if available_models:
        for model in available_models:
            print(f"  • {model}")
    else:
        print("  None")
    
    print(f"\n❌ UNAVAILABLE MODELS ({len(unavailable_models)}):")
    if unavailable_models:
        for model, reason in unavailable_models:
            print(f"  • {model} - {reason}")
    else:
        print("  None")
    
    return available_models, unavailable_models

def main():
    print("=" * 80)
    print("LITELLM GATEWAY MODEL AVAILABILITY CHECK")
    print("=" * 80)
    print()
    
    if not LITELLM_KEY:
        print("ERROR: AWS_BEARER_TOKEN_BEDROCK not set!")
        return
    
    print(f"Gateway URL: {LITELLM_URL}")
    print(f"Auth Token: {'SET' if LITELLM_KEY else 'NOT SET'}")
    print()
    
    # Try to get models list from API
    models_data = check_models_endpoint()
    
    # Test individual models
    available, unavailable = test_individual_models()
    
    # Save results
    results = {
        'timestamp': '2026-09-28',
        'gateway_url': LITELLM_URL,
        'available_models': available,
        'unavailable_models': [{'model': m, 'reason': r} for m, r in unavailable],
    }
    
    with open('available_models_result.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n" + "=" * 80)
    print(f"Results saved to: available_models_result.json")
    print("=" * 80)

if __name__ == '__main__':
    main()
