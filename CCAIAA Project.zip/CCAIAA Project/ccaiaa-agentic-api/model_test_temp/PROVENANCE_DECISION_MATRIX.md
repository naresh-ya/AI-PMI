# Provenance-First Decision Matrix
## When You Cannot Compromise on Source Count/Quality

**Date:** September 29, 2026  
**Scenario:** Maximum provenance requirement - source count is non-negotiable

---

## 📊 Provenance Rankings (Actual Test Data)

| Rank | Model | Avg Sources | vs Baseline | Cost/10K | Latency | Status |
|------|-------|-------------|-------------|----------|---------|--------|
| 🥇 **1st** | **gemini-2.5-pro** | **19.7** | **100%** (baseline) | $90.40 | 28.7s | ⚠️ **DEPRECATED** |
| 🥈 **2nd** | **gemini-2.5-flash** | **17.2** | **87%** | $8.82 | 13.6s | ✅ Available |
| 🥉 3rd | gemini-2.5-flash-lite | 9.9 | 50% | $0.93 | 6.7s | ✅ Available |
| 4th | gemini-3.5-flash | 7.0 | 36% | $16.46 | 22.5s | ⚠️ Unstable |
| ❌ 5th | gemini-3.1-flash-lite | 0 | 0% | N/A | N/A | ❌ Non-functional |

---

## 🎯 The Provenance Dilemma

### Problem Statement:
**"We need maximum provenance (19.7+ sources), but gemini-2.5-pro is deprecated. What do we do?"**

### Available Options:

---

## Option 1: Accept gemini-2.5-flash (Recommended ✅)

**Provenance:** 17.2 sources (87% of baseline)

### Pros:
- ✅ **Still excellent provenance** (17 sources is comprehensive)
- ✅ **91% cost savings** ($8.82 vs $90.40 per 10K)
- ✅ **52% faster** (13.6s vs 28.7s)
- ✅ **Production-stable** - no deprecation risk
- ✅ **Meets professional standards** (10-20 sources is industry norm)

### Cons:
- ⚠️ 2.5 fewer sources on average (13% reduction)

### When to Choose:
- ✅ Normal business operations
- ✅ Competitive intelligence
- ✅ Regulatory research (non-critical)
- ✅ Executive briefings
- ✅ Cost is a consideration

### Risk Assessment: **LOW**
- 17 sources is still audit-ready
- Quality maintained (same .gov, research firm sources)
- 13% gap is negligible in practice

---

## Option 2: Hybrid Approach (Best of Both Worlds 🎯)

**Strategy:** Use BOTH models based on query criticality

### Implementation:

```python
def select_model(query_criticality, query_type):
    if query_criticality == "HIGH" and query_type == "regulatory_filing":
        # Maximum provenance required
        return "gemini-2.5-pro"  # Keep using until EOL
    else:
        # Normal operations
        return "gemini-2.5-flash"
```

### Tier 1: Use gemini-2.5-pro (High Provenance) ⚠️
**Use cases:**
- Critical regulatory submissions
- Legal compliance documents
- High-stakes audits
- Board-level presentations
- Patent filings

**Volume:** ~10-20% of queries
**Cost:** Pay premium for critical queries only

### Tier 2: Use gemini-2.5-flash (Standard Provenance) ✅
**Use cases:**
- Routine competitive intelligence
- Internal research
- Market analysis
- Weekly briefings
- Exploratory research

**Volume:** ~80-90% of queries
**Cost:** Save 91% on majority of queries

### Pros:
- ✅ **Maximum provenance when needed**
- ✅ **Cost optimization on routine queries**
- ✅ **Risk mitigation** - critical work gets best model
- ✅ **Gradual transition** from Pro to Flash

### Cons:
- ⚠️ More complex implementation (routing logic)
- ⚠️ gemini-2.5-pro still deprecated (limited time)

### Cost Impact:
```
Scenario: 100K queries/year
- 20K high-criticality queries × $0.009 = $180
- 80K standard queries × $0.00088 = $70
Total annual cost: $250 (vs $900 all-Pro or $88 all-Flash)

Savings vs all-Pro: $650 (72% reduction)
Premium vs all-Flash: $162 (but you get max provenance when needed)
```

---

## Option 3: Wait for gemini-3.5-flash Maturity (Future ⏸️)

**Provenance:** 7.0 sources (36% of baseline) - **NOT SUFFICIENT**

### Current Status:
- ❌ Only 7 sources per search (64% reduction vs baseline)
- ⚠️ Only 20% success rate (timeout issues)
- 💰 Cost: $16.46/10K (87% cheaper than Pro, but 87% MORE than Flash)

### Why NOT Recommended Now:
1. ❌ **Provenance is WORSE** than gemini-2.5-flash (7 vs 17.2 sources)
2. ❌ **Reliability issues** (Q05 timeout, 80% failure rate)
3. ❌ **More expensive** than gemini-2.5-flash
4. ❌ **No provenance advantage** - fails your requirement

### When to Reconsider:
- ⏸️ Q1 2027 - if Google improves source count
- ⏸️ If future versions boost provenance to 15+ sources
- ⏸️ If stability improves to 90%+ success rate

**Verdict:** ❌ **NOT a provenance solution** - provides FEWER sources, not more

---

## Option 4: Multi-Model Ensemble (Advanced 🚀)

**Strategy:** Query multiple models and merge sources

### How It Works:
```python
def get_maximum_provenance(query):
    # Query both models
    result_pro = query_model("gemini-2.5-pro", query)
    result_flash = query_model("gemini-2.5-flash", query)
    
    # Merge sources (deduplicate)
    all_sources = deduplicate(
        result_pro.sources + result_flash.sources
    )
    
    # Synthesize response using all sources
    return synthesize(result_pro, result_flash, all_sources)
```

### Expected Outcome:
- **Pro sources:** 19.7 average
- **Flash sources:** 17.2 average
- **Overlap:** ~60-70% (both cite FDA.gov, major research sites)
- **Unique sources:** ~30-40%
- **Combined total:** ~25-30 sources (MAXIMUM provenance!)

### Pros:
- ✅ **MAXIMUM provenance** (25-30 sources)
- ✅ **Cross-validation** - two models verify each other
- ✅ **Best of both worlds** - Pro's breadth + Flash's recency

### Cons:
- ❌ **2x API calls** = 2x latency (28.7s + 13.6s = ~40s total)
- ❌ **2x cost** ($90.40 + $8.82 = $99.22 per 10K queries)
- ❌ **Complex implementation** - need deduplication logic
- ❌ **Over-engineered** for most use cases

### When to Use:
- ⚠️ Only for ULTRA-CRITICAL queries
- Examples: Patent litigation, regulatory challenges, compliance disputes
- Volume: <1% of queries

---

## Option 5: Augment Flash with Manual Research (Pragmatic 💼)

**Strategy:** Use Flash, then add sources manually for critical cases

### Workflow:
1. **Query gemini-2.5-flash** → Get 17.2 sources (fast, cheap)
2. **Review output** → Is 17 sources sufficient?
3. **If critical:** Human researcher adds 3-5 more sources manually
4. **Final output:** 20+ sources with human verification

### Pros:
- ✅ **Cost-effective** - 91% savings on API calls
- ✅ **Human oversight** on critical work
- ✅ **Quality assurance** - researcher validates AI output
- ✅ **Flexible** - add sources only when needed

### Cons:
- ⚠️ Requires human time (15-30 min per critical query)

### Cost Analysis:
```
Scenario: 100K queries/year, 5% require manual augmentation

API costs:
- 100K queries × $0.00088 = $88

Human augmentation:
- 5,000 critical queries × 20 min/query = 1,667 hours
- At $50/hour = $83,350

Total: $83,438

Compare to all-Pro: $900 (API only, but still need human review)
Compare to all-Flash: $88 (API only, but may need review)

Insight: Human review costs dwarf API costs regardless of model choice!
```

### Key Insight:
**For truly critical work, you'll review/augment ANYWAY regardless of model choice.**

So the question becomes:
- Start with 19.7 sources (Pro) and pay $90.40/10K?
- Or start with 17.2 sources (Flash) and pay $8.82/10K?

**Recommendation:** Start with Flash, augment the <5% that truly need it.

---

## 🎯 Decision Framework

### Question 1: "What % of queries are TRULY critical?"

| Criticality | % of Volume | Use Case | Recommended Model |
|-------------|-------------|----------|-------------------|
| **Mission-Critical** | 1-5% | Regulatory filings, legal defense | Hybrid (Pro for now) or Ensemble |
| **High-Importance** | 10-20% | Executive briefings, board reports | gemini-2.5-flash + human review |
| **Standard Operations** | 75-90% | Daily research, CI, analysis | gemini-2.5-flash |

### Question 2: "Can we afford the cost premium for max provenance?"

| Annual Query Volume | Cost: All-Pro | Cost: All-Flash | Cost: Hybrid (20% Pro) | Savings |
|---------------------|---------------|-----------------|------------------------|---------|
| 100K | $900 | $88 | $250 | $650 (72%) |
| 500K | $4,500 | $440 | $1,250 | $3,250 (72%) |
| 1M | $9,000 | $880 | $2,500 | $6,500 (72%) |

### Question 3: "Is gemini-2.5-pro's deprecation date known?"

**Critical Factor:** When is gemini-2.5-pro end-of-life?

If EOL is:
- **< 3 months:** ⚠️ Start migrating NOW to Flash (no hybrid, not worth it)
- **3-6 months:** 🎯 Hybrid approach makes sense (transition period)
- **> 6 months:** ✅ Hybrid approach recommended (gradual migration)

**Action:** Check Google Vertex AI deprecation timeline!

---

## 📋 Final Recommendation Matrix

### Scenario A: "Provenance is absolutely critical, cost is secondary"
**Recommendation:** **Hybrid Approach (Option 2)** 🎯
- Use gemini-2.5-pro for high-stakes queries (10-20%)
- Use gemini-2.5-flash for routine queries (80-90%)
- Save 72% cost while maintaining max provenance when needed
- **Plan migration timeline** based on Pro's EOL date

### Scenario B: "Provenance is important, but 17 sources is acceptable"
**Recommendation:** **gemini-2.5-flash (Option 1)** ✅
- 17.2 sources is still excellent
- 91% cost savings
- No deprecation risk
- Industry-standard provenance

### Scenario C: "Provenance is critical, AND we have budget for human review"
**Recommendation:** **Augmented Flash (Option 5)** 💼
- Use gemini-2.5-flash for all queries
- Human researchers augment critical 5%
- Best ROI (API costs are tiny vs human time)

### Scenario D: "Provenance is critical, ULTRA-high-stakes work only"
**Recommendation:** **Multi-Model Ensemble (Option 4)** 🚀
- For <1% of queries (patent litigation, regulatory disputes)
- 25-30 sources combined
- 2x cost, but maximum defensibility

---

## ⚠️ Important Realities

### Reality Check #1: **Human Review Costs > API Costs**

For critical work:
- Human review: $50-150/hour × 0.5-2 hours = **$25-300 per query**
- API cost difference (Pro vs Flash): **$0.008 per query**

**The API cost difference is NEGLIGIBLE compared to human review time.**

### Reality Check #2: **More Sources ≠ Better Decisions**

Research shows:
- **Diminishing returns** after 15-20 sources
- **Quality > Quantity** - 10 excellent sources > 50 mediocre ones
- **Information overload** - humans can't process 30+ sources effectively

**17.2 sources (Flash) is in the "sweet spot" of comprehensive without overload.**

### Reality Check #3: **gemini-2.5-pro is DEPRECATED**

Timeline implications:
- You WILL need to migrate away from Pro eventually
- Delaying migration = technical debt
- Hybrid approach = temporary, not long-term solution

**Plan your migration now, not when Pro is EOL.**

---

## 🚀 Recommended Action Plan

### Phase 1: Immediate (Week 1-2)
1. ✅ **Check gemini-2.5-pro EOL date** (critical decision input)
2. ✅ **Deploy gemini-2.5-flash to client-demo2** (test environment)
3. ✅ **Run parallel testing** (Pro vs Flash, 100 real queries)
4. ✅ **Measure provenance satisfaction** (do users notice 2.5 fewer sources?)

### Phase 2: Evaluation (Week 3-4)
1. ✅ **User feedback collection** (is 17 sources sufficient?)
2. ✅ **Identify truly critical queries** (what % needs max provenance?)
3. ✅ **Cost-benefit analysis** (is hybrid worth the complexity?)

### Phase 3: Decision (Week 5)
Choose one of:
- **Option 1:** Full cutover to gemini-2.5-flash (simplest, 91% savings)
- **Option 2:** Hybrid approach (max provenance for critical, until Pro EOL)
- **Option 5:** Flash + manual augmentation for critical 5%

### Phase 4: Implementation (Week 6+)
- Deploy chosen strategy
- Monitor quality metrics
- Iterate based on feedback

---

## 💡 My Personal Recommendation

**If you truly cannot compromise on provenance:**

**Go with Hybrid Approach (Option 2) - BUT with a plan:**

### Short-term (0-6 months):
```python
if query.criticality == "CRITICAL":
    model = "gemini-2.5-pro"  # 19.7 sources, until EOL
else:
    model = "gemini-2.5-flash"  # 17.2 sources, 91% cheaper
```

### Long-term (6+ months):
```python
# gemini-2.5-pro will be EOL, so:
model = "gemini-2.5-flash"  # 17.2 sources

# For the rare ULTRA-critical queries:
if query.criticality == "ULTRA_CRITICAL":
    # Option: ensemble or human augmentation
    use_ensemble_or_human_augmentation()
```

### Why This Makes Sense:
1. ✅ **Buys you time** - Use Pro while it's available for critical work
2. ✅ **Saves 72% cost** - Majority of queries use Flash
3. ✅ **Smooth migration** - Gradual transition, not abrupt cutover
4. ✅ **Risk mitigation** - Critical work gets max provenance during transition
5. ✅ **Forces prioritization** - Identify what's TRULY critical (probably <20%)

---

## 📊 Final Provenance Scorecard

| Model | Sources | Cost/10K | Best For | Available? | Verdict |
|-------|---------|----------|----------|-----------|---------|
| **gemini-2.5-pro** | 19.7 | $90.40 | Maximum provenance | ⚠️ Deprecated | Use temporarily |
| **gemini-2.5-flash** | 17.2 | $8.82 | Standard operations | ✅ Yes | **Primary choice** |
| **gemini-2.5-flash-lite** | 9.9 | $0.93 | Low-stakes queries | ✅ Yes | Not for provenance needs |
| **gemini-3.5-flash** | 7.0 | $16.46 | N/A | ⚠️ Unstable | NOT suitable |

---

**Bottom Line:**

If you absolutely need 19.7 sources and can't accept 17.2, then:
1. Use **gemini-2.5-pro** for critical queries until EOL
2. Use **gemini-2.5-flash** for everything else (80-90%)
3. Save 72% cost with hybrid approach
4. **Plan migration** because Pro won't be available forever

But honestly? **17.2 sources is excellent provenance.** The 13% reduction is unlikely to materially impact decision quality. Test it first before committing to the complexity of a hybrid approach.

---

**Next Step:** What's gemini-2.5-pro's EOL date? That drives the decision timeline.
