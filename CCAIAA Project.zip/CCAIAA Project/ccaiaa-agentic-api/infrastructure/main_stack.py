"""
AWS CDK Infrastructure Stack for PMI Agentic AI Platform

This module defines the complete AWS infrastructure including:
- API Gateway for frontend communication
- Lambda functions for the 4 main AI agents
- Step Functions for orchestration
- AWS Bedrock permissions and configurations
- S3 buckets for document storage
- DynamoDB tables for request tracking
"""

from aws_cdk import (
    Stack,
    aws_lambda as _lambda,
    aws_apigateway as apigw,
    aws_stepfunctions as sfn,
    aws_stepfunctions_tasks as tasks,
    aws_iam as iam,
    aws_s3 as s3,
    aws_dynamodb as dynamodb,
    aws_logs as logs,
    Duration,
    RemovalPolicy,
    CfnOutput
)
from constructs import Construct
import aws_cdk as cdk


class PmiAgenticAiStack(Stack):
    """Main CDK Stack for PMI Agentic AI Platform"""

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Create S3 bucket for document storage
        self.document_bucket = s3.Bucket(
            self,
            "DocumentBucket",
            bucket_name=f"pmi-agentic-ai-documents-{self.account}-{self.region}",
            versioned=True,
            encryption=s3.BucketEncryption.S3_MANAGED,
            removal_policy=RemovalPolicy.RETAIN,
            cors=[
                s3.CorsRule(
                    allowed_origins=["*"],
                    allowed_methods=[s3.HttpMethods.GET, s3.HttpMethods.POST],
                    allowed_headers=["*"]
                )
            ]
        )

        # Create DynamoDB table for request tracking
        self.requests_table = dynamodb.Table(
            self,
            "RequestsTable",
            table_name="pmi-agentic-ai-requests",
            partition_key=dynamodb.Attribute(
                name="request_id",
                type=dynamodb.AttributeType.STRING
            ),
            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,
            removal_policy=RemovalPolicy.RETAIN,
            point_in_time_recovery=True
        )

        # Human-in-the-Loop table for agentic interactions
        self.hitl_table = dynamodb.Table(
            self,
            "HITLTable",
            table_name="pmi-agentic-ai-hitl",
            partition_key=dynamodb.Attribute(
                name="hitl_id",
                type=dynamodb.AttributeType.STRING
            ),
            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,
            removal_policy=RemovalPolicy.RETAIN,
            point_in_time_recovery=True
        )
        
        # Add GSI for querying by request_id and status
        self.hitl_table.add_global_secondary_index(
            index_name="RequestIdIndex",
            partition_key=dynamodb.Attribute(
                name="request_id", 
                type=dynamodb.AttributeType.STRING
            ),
            projection_type=dynamodb.ProjectionType.ALL
        )
        
        self.hitl_table.add_global_secondary_index(
            index_name="StatusIndex",
            partition_key=dynamodb.Attribute(
                name="status",
                type=dynamodb.AttributeType.STRING
            ),
            projection_type=dynamodb.ProjectionType.ALL
        )

        # Knowledge Base table for document chunks and embeddings
        self.knowledge_base_table = dynamodb.Table(
            self,
            "KnowledgeBaseTable", 
            table_name="pmi-agentic-ai-knowledge-base",
            partition_key=dynamodb.Attribute(
                name="chunk_id",
                type=dynamodb.AttributeType.STRING
            ),
            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,
            removal_policy=RemovalPolicy.RETAIN,
            point_in_time_recovery=True
        )
        
        # Add GSI for querying by document_id
        self.knowledge_base_table.add_global_secondary_index(
            index_name="DocumentIdIndex",
            partition_key=dynamodb.Attribute(
                name="document_id",
                type=dynamodb.AttributeType.STRING
            ),
            projection_type=dynamodb.ProjectionType.ALL
        )

        # Create IAM role for Lambda functions with Bedrock permissions
        self.lambda_role = iam.Role(
            self,
            "LambdaExecutionRole",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name(
                    "service-role/AWSLambdaBasicExecutionRole"
                )
            ],
            inline_policies={
                "BedrockAccess": iam.PolicyDocument(
                    statements=[
                        iam.PolicyStatement(
                            effect=iam.Effect.ALLOW,
                            actions=[
                                "bedrock:InvokeModel",
                                "bedrock:InvokeModelWithResponseStream",
                                "bedrock:ListFoundationModels",
                                "bedrock:GetFoundationModel"
                            ],
                            resources=["*"]
                        ),
                        iam.PolicyStatement(
                            effect=iam.Effect.ALLOW,
                            actions=[
                                "s3:GetObject",
                                "s3:PutObject",
                                "s3:DeleteObject"
                            ],
                            resources=[f"{self.document_bucket.bucket_arn}/*"]
                        ),
                        iam.PolicyStatement(
                            effect=iam.Effect.ALLOW,
                            actions=[
                                "dynamodb:GetItem",
                                "dynamodb:PutItem",
                                "dynamodb:UpdateItem",
                                "dynamodb:DeleteItem",
                                "dynamodb:Query",
                                "dynamodb:Scan"
                            ],
                            resources=[
                                self.requests_table.table_arn,
                                self.hitl_table.table_arn,
                                self.knowledge_base_table.table_arn,
                                f"{self.requests_table.table_arn}/*",
                                f"{self.hitl_table.table_arn}/*", 
                                f"{self.knowledge_base_table.table_arn}/*"
                            ]
                        )
                    ]
                )
            }
        )

        # Create Lambda functions for the 4 main AI agents
        self.create_lambda_functions()

        # Create Step Functions state machine for orchestration
        self.create_step_function()

        # Create API Gateway
        self.create_api_gateway()

        # Output important values
        self.create_outputs()

    def create_lambda_functions(self) -> None:
        """Create Lambda functions for the 4 main AI agents"""
        
        # Common Lambda configuration
        lambda_props = {
            "runtime": _lambda.Runtime.PYTHON_3_10,
            "role": self.lambda_role,
            "timeout": Duration.minutes(15),
            "memory_size": 1024,
            "environment": {
                "DOCUMENT_BUCKET": self.document_bucket.bucket_name,
                "REQUESTS_TABLE": self.requests_table.table_name,
                "REGION": self.region
            }
        }

        # 1. Input Validator Agent
        self.input_validator = _lambda.Function(
            self,
            "InputValidatorFunction",
            function_name="pmi-input-validator",
            code=_lambda.Code.from_asset("pmi_agentic_ai/agents/input_validator"),
            handler="handler.lambda_handler",
            description="Validates input requests and extracts requirements",
            **lambda_props
        )

        # 2. Master Researcher Agent
        self.master_researcher = _lambda.Function(
            self,
            "MasterResearcherFunction",
            function_name="pmi-master-researcher",
            code=_lambda.Code.from_asset("pmi_agentic_ai/agents/master_researcher"),
            handler="handler.lambda_handler",
            description="Orchestrates research across multiple sources",
            timeout=Duration.minutes(15),
            **lambda_props
        )

        # 3. Master Drafting Agent
        self.master_drafter = _lambda.Function(
            self,
            "MasterDraftingFunction",
            function_name="pmi-master-drafter",
            code=_lambda.Code.from_asset("pmi_agentic_ai/agents/master_drafter"),
            handler="handler.lambda_handler",
            description="Generates comprehensive document drafts",
            **lambda_props
        )

        # 4. Master Review Agent
        self.master_reviewer = _lambda.Function(
            self,
            "MasterReviewFunction",
            function_name="pmi-master-reviewer",
            code=_lambda.Code.from_asset("pmi_agentic_ai/agents/master_reviewer"),
            handler="handler.lambda_handler",
            description="Reviews and validates document for compliance",
            **lambda_props
        )

        # 5. Knowledge Base Builder
        self.kb_builder = _lambda.Function(
            self,
            "KnowledgeBaseBuilderFunction",
            function_name="pmi-kb-builder",
            code=_lambda.Code.from_asset("pmi_agentic_ai/knowledge_base"),
            handler="document_processor.lambda_handler",
            description="Builds and maintains document knowledge base",
            timeout=Duration.minutes(15),
            memory_size=2048,  # Higher memory for document processing
            environment={
                **lambda_props["environment"],
                "KNOWLEDGE_BASE_TABLE": self.knowledge_base_table.table_name
            },
            role=self.lambda_role
        )

        # 6. (Deprecated) Knowledge Base Searcher — removed.
        # Legacy DynamoDB + Titan cosine search replaced by LiteLLM Gateway KB retrieve
        # in core/kb_integration_new.py. No runtime path imports the old kb_searcher.

        # 7. HITL Web Interface
        self.hitl_interface = _lambda.Function(
            self,
            "HITLWebInterfaceFunction", 
            function_name="pmi-hitl-interface",
            code=_lambda.Code.from_asset("pmi_agentic_ai/hitl"),
            handler="web_interface.lambda_handler",
            description="Human-in-the-loop web interface for agent interaction",
            timeout=Duration.minutes(5),
            environment={
                **lambda_props["environment"],
                "HITL_TABLE": self.hitl_table.table_name
            },
            role=self.lambda_role
        )

    def create_step_function(self) -> None:
        """Create Step Functions state machine for agent orchestration"""
        
        # Define tasks for each agent
        input_validation_task = tasks.LambdaInvoke(
            self,
            "InputValidationTask",
            lambda_function=self.input_validator,
            payload_response_only=True,
            result_path="$.validation_result"
        )

        research_task = tasks.LambdaInvoke(
            self,
            "ResearchTask",
            lambda_function=self.master_researcher,
            payload_response_only=True,
            result_path="$.research_result"
        )

        drafting_task = tasks.LambdaInvoke(
            self,
            "DraftingTask",
            lambda_function=self.master_drafter,
            payload_response_only=True,
            result_path="$.draft_result"
        )

        review_task = tasks.LambdaInvoke(
            self,
            "ReviewTask",
            lambda_function=self.master_reviewer,
            payload_response_only=True,
            result_path="$.review_result"
        )

        # Create success and failure states
        success = sfn.Succeed(self, "DocumentGenerationSuccess")
        failure = sfn.Fail(
            self,
            "DocumentGenerationFailure",
            cause="Agent processing failed"
        )

        # Define the workflow chain
        definition = (
            input_validation_task
            .next(sfn.Choice(self, "ValidationChoice")
                .when(
                    sfn.Condition.string_equals("$.validation_result.status", "success"),
                    research_task
                    .next(sfn.Choice(self, "ResearchChoice")
                        .when(
                            sfn.Condition.string_equals("$.research_result.status", "success"),
                            drafting_task
                            .next(sfn.Choice(self, "DraftingChoice")
                                .when(
                                    sfn.Condition.string_equals("$.draft_result.status", "success"),
                                    review_task
                                    .next(sfn.Choice(self, "ReviewChoice")
                                        .when(
                                            sfn.Condition.string_equals("$.review_result.status", "success"),
                                            success
                                        )
                                        .otherwise(failure)
                                    )
                                )
                                .otherwise(failure)
                            )
                        )
                        .otherwise(failure)
                    )
                )
                .otherwise(failure)
            )
        )

        # Create the state machine
        self.state_machine = sfn.StateMachine(
            self,
            "PmiAgenticAiWorkflow",
            state_machine_name="pmi-agentic-ai-workflow",
            definition=definition,
            timeout=Duration.hours(2),
            logs=sfn.LogOptions(
                destination=logs.LogGroup(
                    self,
                    "StepFunctionLogs",
                    log_group_name="/aws/stepfunctions/pmi-agentic-ai-workflow",
                    removal_policy=RemovalPolicy.DESTROY
                ),
                level=sfn.LogLevel.ALL
            )
        )

    def create_api_gateway(self) -> None:
        """Create API Gateway for frontend communication"""
        
        # Create API Gateway
        self.api = apigw.RestApi(
            self,
            "PmiAgenticAiApi",
            rest_api_name="pmi-agentic-ai-api",
            description="API Gateway for PMI Agentic AI Platform",
            default_cors_preflight_options=apigw.CorsOptions(
                allow_origins=apigw.Cors.ALL_ORIGINS,
                allow_methods=apigw.Cors.ALL_METHODS,
                allow_headers=["Content-Type", "X-Amz-Date", "Authorization", "X-Api-Key"]
            )
        )

        # Create Lambda function for API endpoints
        self.api_handler = _lambda.Function(
            self,
            "ApiHandlerFunction",
            function_name="pmi-api-handler",
            runtime=_lambda.Runtime.PYTHON_3_10,
            code=_lambda.Code.from_asset("pmi_agentic_ai/api"),
            handler="handler.lambda_handler",
            role=self.lambda_role,
            timeout=Duration.minutes(5),
            environment={
                "STATE_MACHINE_ARN": self.state_machine.state_machine_arn,
                "DOCUMENT_BUCKET": self.document_bucket.bucket_name,
                "REQUESTS_TABLE": self.requests_table.table_name
            }
        )

        # Grant permissions to start executions
        self.state_machine.grant_start_execution(self.api_handler)

        # Create API resources and methods
        requests_resource = self.api.root.add_resource("requests")
        requests_resource.add_method(
            "POST",
            apigw.LambdaIntegration(self.api_handler),
            method_responses=[
                apigw.MethodResponse(
                    status_code="200",
                    response_headers={"Access-Control-Allow-Origin": True}
                )
            ]
        )
        
        # Add GET method for request status
        request_id_resource = requests_resource.add_resource("{request_id}")
        request_id_resource.add_method(
            "GET",
            apigw.LambdaIntegration(self.api_handler)
        )

        # Add health check endpoint
        health_resource = self.api.root.add_resource("health")
        health_resource.add_method(
            "GET",
            apigw.MockIntegration(
                integration_responses=[
                    apigw.IntegrationResponse(
                        status_code="200",
                        response_templates={
                            "application/json": '{"status": "healthy"}'
                        }
                    )
                ],
                request_templates={
                    "application/json": '{"statusCode": 200}'
                }
            ),
            method_responses=[
                apigw.MethodResponse(status_code="200")
            ]
        )

        # Knowledge Base API endpoints
        kb_resource = self.api.root.add_resource("knowledge-base")
        
        # POST /knowledge-base/build - Build knowledge base
        kb_build_resource = kb_resource.add_resource("build")
        kb_build_resource.add_method(
            "POST",
            apigw.LambdaIntegration(self.kb_builder),
            method_responses=[
                apigw.MethodResponse(
                    status_code="200",
                    response_headers={"Access-Control-Allow-Origin": True}
                )
            ]
        )
        
        # (Deprecated) POST /knowledge-base/search and GET /knowledge-base/stats — removed.
        # These routes fronted the legacy kb_searcher Lambda, which has been deprecated.

        # HITL (Human-in-the-Loop) API endpoints
        hitl_resource = self.api.root.add_resource("hitl")
        
        # GET /hitl/dashboard - Get reviewer dashboard
        hitl_dashboard_resource = hitl_resource.add_resource("dashboard")
        hitl_dashboard_resource.add_method(
            "GET",
            apigw.LambdaIntegration(self.hitl_interface),
            method_responses=[
                apigw.MethodResponse(
                    status_code="200",
                    response_headers={"Access-Control-Allow-Origin": True}
                )
            ]
        )
        
        # GET /hitl/review/{hitl_id} - Get review details
        hitl_review_resource = hitl_resource.add_resource("review")
        hitl_review_id_resource = hitl_review_resource.add_resource("{hitl_id}")
        hitl_review_id_resource.add_method(
            "GET",
            apigw.LambdaIntegration(self.hitl_interface),
            method_responses=[
                apigw.MethodResponse(
                    status_code="200", 
                    response_headers={"Access-Control-Allow-Origin": True}
                )
            ]
        )
        
        # POST /hitl/decision/{hitl_id} - Submit review decision
        hitl_decision_resource = hitl_resource.add_resource("decision")
        hitl_decision_id_resource = hitl_decision_resource.add_resource("{hitl_id}")
        hitl_decision_id_resource.add_method(
            "POST",
            apigw.LambdaIntegration(self.hitl_interface),
            method_responses=[
                apigw.MethodResponse(
                    status_code="200",
                    response_headers={"Access-Control-Allow-Origin": True}
                )
            ]
        )

    def create_outputs(self) -> None:
        """Create CloudFormation outputs for important resources"""
        
        CfnOutput(
            self,
            "ApiGatewayUrl",
            value=self.api.url,
            description="API Gateway endpoint URL"
        )

        CfnOutput(
            self,
            "DocumentBucketName",
            value=self.document_bucket.bucket_name,
            description="S3 bucket for document storage"
        )

        CfnOutput(
            self,
            "RequestsTableName",
            value=self.requests_table.table_name,
            description="DynamoDB table for request tracking"
        )

        CfnOutput(
            self,
            "StateMachineArn",
            value=self.state_machine.state_machine_arn,
            description="Step Functions state machine ARN"
        )
