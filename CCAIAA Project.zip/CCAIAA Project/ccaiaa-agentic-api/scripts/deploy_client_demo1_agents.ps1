# Deploy Agents Script for client-demo1 environment
# Packages and updates: Input Validator, Master Researcher, and Master Drafter Lambdas

param (
    [string]$Region = "eu-west-1",
    [string]$DocumentBucket = "pmi-agentic-ai-documents-603433800649-eu-west-1",
    [string]$RequestsTable = "pmi-agentic-ai-requests"
)

$ErrorActionPreference = "Stop"

# Parse keys from .env file
$AwsBearerToken = ""
$TavilyApiKey = ""
if (Test-Path ".\.env") {
    $envLines = Get-Content ".\.env"
    foreach ($line in $envLines) {
        if ($line -match "^\s*AWS_BEARER_TOKEN_BEDROCK\s*=\s*`"?(.*?)`"?\s*$") {
            $AwsBearerToken = $Matches[1]
        }
        elseif ($line -match "^\s*TAVILY_API_KEY\s*=\s*`"?(.*?)`"?\s*$") {
            $TavilyApiKey = $Matches[1]
        }
    }
}

$Agents = @(
    @{
        Name = "pmi-input-validator-client-demo1"
        SourceDir = "agents\input_validator"
        EnvVars = @{
            DEPLOYMENT_CONTEXT = "client-demo1"
            DOCUMENT_BUCKET = $DocumentBucket
            REQUESTS_TABLE = $RequestsTable
            AWS_BEARER_TOKEN_BEDROCK = $AwsBearerToken
            LITELLM_MODEL = "anthropic.claude-3-haiku-20240307-v1:0"
            NO_PROXY = "169.254.169.254,.aws.private-pmideep.biz,.amazonaws.com"
            HTTPS_PROXY = "http://your-corporate-proxy.com:8080"
            HTTP_PROXY = "http://your-corporate-proxy.com:8080"
        }
    },
    @{
        Name = "pmi-master-researcher-client-demo1"
        SourceDir = "agents\master_researcher"
        EnvVars = @{
            DEPLOYMENT_CONTEXT = "client-demo1"
            DOCUMENT_BUCKET = $DocumentBucket
            REQUESTS_TABLE = $RequestsTable
            AWS_BEARER_TOKEN_BEDROCK = $AwsBearerToken
            LITELLM_MODEL = "anthropic.claude-3-haiku-20240307-v1:0"
            TAVILY_API_KEY = $TavilyApiKey
            KB_SEARCHER_FUNCTION_NAME = "pmi-kb-searcher-client-demo1"
            CURATED_LINKS_TABLE = "pmi-agentic-ai-curated-links"
            NO_PROXY = "169.254.169.254,.aws.private-pmideep.biz,.amazonaws.com"
            HTTPS_PROXY = "http://your-corporate-proxy.com:8080"
            HTTP_PROXY = "http://your-corporate-proxy.com:8080"
        }
    },
    @{
        Name = "pmi-master-drafter-client-demo1"
        SourceDir = "agents\master_drafter"
        EnvVars = @{
            DEPLOYMENT_CONTEXT = "client-demo1"
            DOCUMENT_BUCKET = $DocumentBucket
            REQUESTS_TABLE = $RequestsTable
            AWS_BEARER_TOKEN_BEDROCK = $AwsBearerToken
            LITELLM_MODEL = "anthropic.claude-3-haiku-20240307-v1:0"
        }
    },
    @{
        Name = "pmi-kb-searcher-client-demo1"
        SourceDir = "knowledge_base"
        EnvVars = @{
            DEPLOYMENT_CONTEXT = "client-demo1"
            DOCUMENT_BUCKET = $DocumentBucket
            REQUESTS_TABLE = $RequestsTable
            KNOWLEDGE_BASE_TABLE = "pmi-agentic-ai-knowledge-base"
        }
    }
)

foreach ($agent in $Agents) {
    $FunctionName = $agent.Name
    $SourceDir = $agent.SourceDir
    $EnvVars = $agent.EnvVars
    
    Write-Host "=================================================" -ForegroundColor Cyan
    Write-Host "Packaging and Deploying: $FunctionName..." -ForegroundColor Cyan
    
    $Timestamp = Get-Date -Format "yyyyMMddHHmmss"
    $StagingDir = "$env:TEMP\lambda_staging_${FunctionName}_${Timestamp}"
    $ZipPath = "$env:TEMP\lambda_deploy_${FunctionName}_${Timestamp}.zip"
    
    if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force -ErrorAction SilentlyContinue }
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue }
    
    New-Item -ItemType Directory -Path $StagingDir | Out-Null
    
    # 1. Copy agent-specific source files
    Write-Host "Copying agent files from $SourceDir..." -ForegroundColor Yellow
    Copy-Item -Path ".\$SourceDir\*" -Destination $StagingDir -Recurse -Force
    
    # Rename descriptive handler files to handler.py to match AWS Lambda's configured entrypoint (handler.lambda_handler)
    if ($SourceDir -eq "agents\input_validator") {
        Write-Host "Renaming handler_new_validator.py to handler.py..." -ForegroundColor Yellow
        Rename-Item -Path (Join-Path $StagingDir "handler_new_validator.py") -NewName "handler.py" -Force
    }
    elseif ($SourceDir -eq "agents\master_researcher") {
        Write-Host "Renaming handler_new_advanced.py to handler.py..." -ForegroundColor Yellow
        Rename-Item -Path (Join-Path $StagingDir "handler_new_advanced.py") -NewName "handler.py" -Force
    }
    elseif ($SourceDir -eq "agents\master_drafter") {
        Write-Host "Renaming handler_drafter_new.py to handler.py..." -ForegroundColor Yellow
        Rename-Item -Path (Join-Path $StagingDir "handler_drafter_new.py") -NewName "handler.py" -Force
    }
    
    # 2. Bundle the shared 'core' directory (crucial for kb_integration & prompt registries!)
    if (Test-Path ".\core") {
        Write-Host "Bundling shared core library..." -ForegroundColor Yellow
        $CoreDest = Join-Path $StagingDir "core"
        New-Item -ItemType Directory -Path $CoreDest | Out-Null
        Copy-Item -Path ".\core\*" -Destination $CoreDest -Recurse -Force
    }
    
    # 3. Install dependencies from requirements.txt or requirements-searcher.txt if present (targeting Lambda Linux binary compatibility)
    $ReqFile = ".\$SourceDir\requirements.txt"
    if ($FunctionName -eq "pmi-kb-searcher-client-demo1") {
        $ReqFile = ".\$SourceDir\requirements-searcher.txt"
    }
    if (Test-Path $ReqFile) {
        Write-Host "Installing dependencies for $FunctionName (manylinux2014_x86_64 Python 3.10) from $ReqFile..." -ForegroundColor Yellow
        pip install -r $ReqFile -t $StagingDir --quiet --platform manylinux2014_x86_64 --python-version 3.10 --only-binary=:all:
    }
    
    # 4. Zip the package
    Write-Host "Zipping deployment package..." -ForegroundColor Yellow
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force
    
    # 5. Upload and update Lambda code
    $ZipSizeMB = (Get-Item $ZipPath).Length / 1MB
    if ($ZipSizeMB -gt 45) {
        Write-Host "Zip package size is [$([Math]::Round($ZipSizeMB, 2))] MB (exceeds 45MB). Uploading to S3 bucket $DocumentBucket to bypass AWS direct upload limits..." -ForegroundColor Yellow
        $S3Key = "lambda-deployments/${FunctionName}-$(Get-Date -Format 'yyyyMMddHHmmss').zip"
        aws s3 cp $ZipPath "s3://${DocumentBucket}/${S3Key}" --region $Region | Out-Null
        
        Write-Host "Updating Lambda function code from S3..." -ForegroundColor Yellow
        aws lambda update-function-code `
            --function-name $FunctionName `
            --s3-bucket $DocumentBucket `
            --s3-key $S3Key `
            --region $Region `
            | Out-Null
    } else {
        Write-Host "Zip package size is [$([Math]::Round($ZipSizeMB, 2))] MB. Updating Lambda function code directly in AWS..." -ForegroundColor Yellow
        aws lambda update-function-code `
            --function-name $FunctionName `
            --zip-file fileb://$ZipPath `
            --region $Region `
            | Out-Null
    }
        
    Write-Host "Successfully deployed new code to $FunctionName!" -ForegroundColor Green
    
    # Wait for completion
    aws lambda wait function-updated --function-name $FunctionName --region $Region
    
    # 6. Update environment variables
    if ($EnvVars) {
        Write-Host "Updating environment variables configuration..." -ForegroundColor Yellow
        
        $EnvJson = @{ Variables = $EnvVars } | ConvertTo-Json -Compress
        $TempJsonPath = "$env:TEMP\lambda_env_$FunctionName.json"
        [System.IO.File]::WriteAllText($TempJsonPath, $EnvJson)
        
        aws lambda update-function-configuration `
            --function-name $FunctionName `
            --environment "file://$TempJsonPath" `
            --region $Region `
            | Out-Null
            
        aws lambda wait function-updated --function-name $FunctionName --region $Region
        
        if (Test-Path $TempJsonPath) { Remove-Item $TempJsonPath -Force }
        Write-Host "Successfully configured environment variables for $FunctionName!" -ForegroundColor Green
    }
    
    # Cleanup
    try {
        if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force -ErrorAction SilentlyContinue }
    } catch {
        Write-Host "[-] Non-fatal: Could not clean up temporary staging directory $StagingDir due to file locks." -ForegroundColor Yellow
    }
    try {
        if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue }
    } catch {}
}

Write-Host "=================================================" -ForegroundColor Green
Write-Host "All agent Lambdas updated and configured successfully!" -ForegroundColor Green

