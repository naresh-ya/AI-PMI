import os
import json
import glob
import sys
from datetime import datetime

# Add root to pythonpath
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import core handlers
from agents.input_validator.handler import lambda_handler as validator_handler
from agents.master_researcher.handler import lambda_handler as researcher_handler
from agents.master_drafter.handler import lambda_handler as drafter_handler
from core.system_prompts import MASTER_RESEARCHER_SYSTEM_PROMPT, MASTER_DRAFTER_SYSTEM_PROMPT

def evaluate_all_scenarios():
    report_lines = []
    report_lines.append("# System Prompt Evaluation Report")
    report_lines.append(f"Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append("\nThis report captures the generated outputs from the Master Researcher and Master Drafter across the 5 test scenarios to evaluate system prompt performance.")
    
    report_lines.append("\n## Current System Prompts")
    report_lines.append("### Master Researcher Prompt")
    report_lines.append(f"```text\n{MASTER_RESEARCHER_SYSTEM_PROMPT}\n```")
    report_lines.append("### Master Drafter Prompt")
    report_lines.append(f"```text\n{MASTER_DRAFTER_SYSTEM_PROMPT}\n```")
    
    payloads = glob.glob('test_payloads/new_request_submissions/*.json')
    payloads.sort()
    
    for payload_path in payloads:
        scenario_name = os.path.basename(payload_path)
        print(f"Evaluating scenario: {scenario_name}")
        report_lines.append(f"\n---\n## Scenario: {scenario_name}")
        
        # Load payload
        with open(payload_path, 'r') as f:
            raw_payload = json.load(f)
            
        try:
            # 1. Validate
            validator_out = validator_handler(raw_payload, None)
            
            req_info = validator_out.get('document_requirements', {})
            report_lines.append("\n### Input Requirements")
            report_lines.append(f"- **Document Type**: {req_info.get('document_type', 'N/A')}")
            report_lines.append(f"- **Jurisdiction**: {req_info.get('jurisdiction', 'N/A')}")
            
            # 2. Research
            researcher_out = researcher_handler(validator_out, None)
            key_findings = researcher_out.get('key_findings', [])
            
            report_lines.append("\n### Master Researcher Output (Findings)")
            if key_findings:
                for finding in key_findings:
                    report_lines.append(f"- {finding}")
            else:
                report_lines.append("*(No key findings generated)*")
                
            # 3. Draft
            drafter_event = {**validator_out, **researcher_out}
            drafter_out = drafter_handler(drafter_event, None)
            
            document_summary = drafter_out.get('document_summary')
            if document_summary:
                draft_content = json.dumps(document_summary, indent=2)
            else:
                draft_content = '*(Draft generation failed or not returned in response)*'
                
            report_lines.append("\n### Master Drafter Output (Draft Content)")
            report_lines.append("```json\n" + str(draft_content) + "\n```")
            
            report_lines.append("\n### Prompt Assessment Notes")
            report_lines.append("> [!TIP]\n> Write notes here on what went well and what needs improvement in the prompt for this scenario.")
            
        except Exception as e:
            report_lines.append(f"\n**ERROR PROCESSING SCENARIO**: {str(e)}")
            print(f"Error on {scenario_name}: {str(e)}")
            
    # Write report
    report_path = os.path.join(os.environ.get('APPDATA_DIR', '.'), 'prompt_evaluation_report.md')
    with open('prompt_evaluation_report.md', 'w', encoding='utf-8') as f:
        f.write('\n'.join(report_lines))
        
    print(f"Evaluation complete. Report generated at prompt_evaluation_report.md")

if __name__ == "__main__":
    # Ensure DOCUMENT_BUCKET is set to prevent S3 errors
    os.environ['DOCUMENT_BUCKET'] = 'pmi-agentic-ai-documents-603433800649-eu-west-1'
    evaluate_all_scenarios()
