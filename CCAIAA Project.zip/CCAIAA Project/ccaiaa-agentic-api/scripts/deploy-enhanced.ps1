# Enhanced Deployment Script for PMI Agentic AI Platform with Orchestration

Write-Host "Starting PMI Agentic AI Platform Deployment with Orchestration..." -ForegroundColor Green

# Check prerequisites
Write-Host "Checking prerequisites..." -ForegroundColor Yellow

# Check Python
try {
    $pythonVersion = python --version 2>$null
    if ($pythonVersion -match "3\.([0-9]+)\.") {
        $minorVersion = [int]$Matches[1]
        if ($minorVersion -lt 10) {
            Write-Host "ERROR: Python 3.10 or higher required. Found: $pythonVersion" -ForegroundColor Red
            exit 1
        }
        Write-Host "✓ Python version: $pythonVersion" -ForegroundColor Green
    }
} catch {
    Write-Host "ERROR: Python not found. Please install Python 3.10+" -ForegroundColor Red
    exit 1
}

# Check Node.js for CDK
try {
    $nodeVersion = node --version 2>$null
    Write-Host "✓ Node.js version: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Node.js not found. Please install Node.js" -ForegroundColor Red
    exit 1
}

# Check AWS CLI
try {
    $awsVersion = aws --version 2>$null
    Write-Host "✓ AWS CLI: $awsVersion" -ForegroundColor Green
} catch {
    Write-Host "WARNING: AWS CLI not found. Please configure AWS credentials" -ForegroundColor Yellow
}

# Install CDK if not present
try {
    $cdkVersion = cdk --version 2>$null
    Write-Host "✓ CDK version: $cdkVersion" -ForegroundColor Green
} catch {
    Write-Host "Installing AWS CDK..." -ForegroundColor Yellow
    npm install -g aws-cdk
}

# Create and activate virtual environment
Write-Host "Setting up Python virtual environment..." -ForegroundColor Yellow
if (!(Test-Path ".venv")) {
    python -m venv .venv
}

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Install Python dependencies
Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
pip install -r requirements.txt

# Create shared layer for common components
Write-Host "Creating shared layer for system prompts and HITL manager..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path "layers\shared\python"
Copy-Item -Recurse "pmi_agentic_ai\core" "layers\shared\python\"

# Package layer
Compress-Archive -Path "layers\shared\python\*" -DestinationPath "layers\shared_layer.zip" -Force

# Bootstrap CDK (if needed)
Write-Host "Checking CDK bootstrap status..." -ForegroundColor Yellow
try {
    cdk bootstrap
    Write-Host "✓ CDK bootstrap completed" -ForegroundColor Green
} catch {
    Write-Host "ERROR: CDK bootstrap failed. Please check AWS credentials" -ForegroundColor Red
    exit 1
}

# Validate Step Functions definition
Write-Host "Validating Step Functions state machine definition..." -ForegroundColor Yellow
try {
    python -c "
import json
from pmi_agentic_ai.core.step_functions_definition import create_step_functions_json_definition
definition = create_step_functions_json_definition()
print('✓ Step Functions definition is valid')
"
    Write-Host "✓ Step Functions definition validated" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Step Functions definition validation failed" -ForegroundColor Red
    exit 1
}

# Synthesize CDK app
Write-Host "Synthesizing CDK application with orchestration components..." -ForegroundColor Yellow
cdk synth

# Deploy the enhanced stack
Write-Host "Deploying PMI Agentic AI stack with orchestration..." -ForegroundColor Yellow
Write-Host "This may take 15-20 minutes due to additional components..." -ForegroundColor Cyan

$deployResult = cdk deploy --require-approval never

if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Deployment completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Agentic AI Platform Components Deployed:" -ForegroundColor Yellow
    Write-Host "✓ Input Validator Agent (AI-powered validation)" -ForegroundColor White
    Write-Host "✓ Master Researcher Agent (Strategy + Execution + Revision)" -ForegroundColor White
    Write-Host "✓ Master Drafter Agent (Outline + Content + Revision)" -ForegroundColor White
    Write-Host "✓ Master Reviewer Agent (Compliance + Quality + Final Review)" -ForegroundColor White
    Write-Host "✓ Orchestration Engine (Workflow + Feedback + Transitions)" -ForegroundColor White
    Write-Host "✓ HITL Web Interface (Human Review Dashboard)" -ForegroundColor White
    Write-Host "✓ Step Functions State Machine (Complete Workflow)" -ForegroundColor White
    Write-Host "✓ DynamoDB Tables (Requests + HITL Checkpoints)" -ForegroundColor White
    Write-Host "✓ S3 Buckets (Document Storage + Research Artifacts)" -ForegroundColor White
    Write-Host ""
    
    # Get deployment outputs
    Write-Host "Getting deployment outputs..." -ForegroundColor Yellow
    $outputs = aws cloudformation describe-stacks --stack-name PmiAgenticAiStack --query "Stacks[0].Outputs" 2>$null
    
    if ($outputs) {
        Write-Host "Deployment Outputs:" -ForegroundColor Cyan
        $outputs | ConvertFrom-Json | ForEach-Object {
            Write-Host "  $($_.OutputKey): $($_.OutputValue)" -ForegroundColor White
        }
    }
    
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Yellow
    Write-Host "1. Configure Bedrock model access in AWS Console" -ForegroundColor White
    Write-Host "2. Set up human reviewer accounts and permissions" -ForegroundColor White
    Write-Host "3. Test the complete agentic workflow with HITL" -ForegroundColor White
    Write-Host "4. Configure notification endpoints (SNS topics)" -ForegroundColor White
    Write-Host "5. Access HITL dashboard for human reviewers" -ForegroundColor White
    Write-Host ""
    Write-Host "Testing:" -ForegroundColor Yellow
    Write-Host "Run: .\test-agentic-workflow.ps1" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "HITL Dashboard:" -ForegroundColor Yellow
    Write-Host "URL: [API Gateway URL]/hitl/dashboard" -ForegroundColor Cyan
    
} else {
    Write-Host "ERROR: Deployment failed!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Common issues and solutions:" -ForegroundColor Yellow
    Write-Host "1. Check AWS credentials: aws configure list" -ForegroundColor White
    Write-Host "2. Verify Bedrock service availability in your region" -ForegroundColor White  
    Write-Host "3. Ensure sufficient IAM permissions for Step Functions" -ForegroundColor White
    Write-Host "4. Check CloudFormation console for detailed error messages" -ForegroundColor White
    exit 1
}

Write-Host ""
Write-Host "Agentic AI Platform Architecture Summary:" -ForegroundColor Green
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
Write-Host "Input Request → Input Validator (AI Only)" -ForegroundColor Cyan
Write-Host "    ↓" -ForegroundColor Cyan  
Write-Host "Research Strategy → Master Researcher → HITL Approval" -ForegroundColor Cyan
Write-Host "    ↓" -ForegroundColor Cyan
Write-Host "Execute Research → Research Results" -ForegroundColor Cyan
Write-Host "    ↓" -ForegroundColor Cyan
Write-Host "Document Outline → Master Drafter → HITL Approval" -ForegroundColor Cyan
Write-Host "    ↓" -ForegroundColor Cyan
Write-Host "Generate Content → Draft Document" -ForegroundColor Cyan
Write-Host "    ↓" -ForegroundColor Cyan
Write-Host "Final Review → Master Reviewer → HITL Approval" -ForegroundColor Cyan
Write-Host "    ↓" -ForegroundColor Cyan
Write-Host "Completed Document → Delivery" -ForegroundColor Cyan
Write-Host ""
Write-Host "Human-in-the-Loop Integration Points:" -ForegroundColor Green
Write-Host "• Research Strategy Approval" -ForegroundColor White
Write-Host "• Document Outline Approval" -ForegroundColor White
Write-Host "• Final Compliance Sign-off" -ForegroundColor White
Write-Host "• Revision and Escalation Handling" -ForegroundColor White
Write-Host ""
Write-Host "Orchestration Features:" -ForegroundColor Green
Write-Host "• Feedback Processing & Integration" -ForegroundColor White
Write-Host "• Agent Transition Management" -ForegroundColor White
Write-Host "• Revision Loop Handling" -ForegroundColor White
Write-Host "• Escalation Workflows" -ForegroundColor White
Write-Host "• Complete Audit Trail" -ForegroundColor White
