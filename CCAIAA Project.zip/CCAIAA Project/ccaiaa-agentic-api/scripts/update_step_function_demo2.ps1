# Update the demo2 Step Functions state machine definition.
# Run AFTER aws sso login.
#
# Usage:
#   .\scripts\update_step_function_demo2.ps1
#   .\scripts\update_step_function_demo2.ps1 -StateMachineName "your-custom-name"
#
param(
    [string]$StateMachineName = "",
    [string]$Region = "eu-west-1",
    [string]$AccountId = "603433800649"
)

$ErrorActionPreference = "Stop"

# If no name provided, list state machines and let user pick
if (-not $StateMachineName) {
    Write-Host "Listing state machines in $Region..." -ForegroundColor Cyan
    $machines = aws stepfunctions list-state-machines --region $Region --no-cli-pager --output json | ConvertFrom-Json
    $demo2Machines = $machines.stateMachines | Where-Object { $_.name -match "demo2|client" }
    
    if ($demo2Machines.Count -eq 0) {
        Write-Host "No demo2/client state machines found. Listing all:" -ForegroundColor Yellow
        $machines.stateMachines | ForEach-Object { Write-Host "  $($_.name)" }
        Write-Host "`nSet -StateMachineName explicitly." -ForegroundColor Red
        exit 1
    }
    
    Write-Host "`nFound state machines:" -ForegroundColor Green
    for ($i = 0; $i -lt $demo2Machines.Count; $i++) {
        Write-Host "  [$i] $($demo2Machines[$i].name)"
    }
    
    if ($demo2Machines.Count -eq 1) {
        $StateMachineName = $demo2Machines[0].name
        Write-Host "`nUsing: $StateMachineName" -ForegroundColor Green
    } else {
        $choice = Read-Host "`nEnter number to update"
        $StateMachineName = $demo2Machines[$choice].name
    }
}

$smArn = "arn:aws:states:${Region}:${AccountId}:stateMachine:${StateMachineName}"
$definitionFile = "infrastructure/step_functions_definition_client_demo2.json"

Write-Host "`nUpdating state machine:" -ForegroundColor Cyan
Write-Host "  ARN:        $smArn"
Write-Host "  Definition: $definitionFile"

# Read and validate JSON
$definition = Get-Content $definitionFile -Raw
try {
    $null = $definition | ConvertFrom-Json
} catch {
    Write-Host "ERROR: Invalid JSON in $definitionFile" -ForegroundColor Red
    exit 1
}

# Update the state machine
Write-Host "`nPushing new definition..." -ForegroundColor Yellow
aws stepfunctions update-state-machine `
    --state-machine-arn $smArn `
    --definition $definition `
    --region $Region `
    --no-cli-pager

if ($LASTEXITCODE -eq 0) {
    Write-Host "`nState machine updated successfully!" -ForegroundColor Green
    Write-Host "New states include: HitlCheck, HITLResearchGate, ResearchGateChoice, ReResearch, IncrementRetryCount"
    
    # Also update the SFN role to allow invoking the 2 new Lambdas
    Write-Host "`nUpdating SFN IAM role to include new Lambdas..." -ForegroundColor Yellow
    python deploy_lambdas_demo2.py --setup-sfn-role $StateMachineName
} else {
    Write-Host "`nERROR: State machine update failed!" -ForegroundColor Red
    exit 1
}
