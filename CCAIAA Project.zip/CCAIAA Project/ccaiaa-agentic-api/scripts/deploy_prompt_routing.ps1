$ErrorActionPreference = "Stop"

function Deploy-Lambda {
    param($Name, $Folder, [string[]]$Includes)
    
    Write-Host "Zipping $Name..."
    $StagingDir = "$env:TEMP\lambda_staging_$Name"
    $ZipPath = "$env:TEMP\$Name.zip"
    
    if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
    New-Item -ItemType Directory -Path $StagingDir | Out-Null
    
    # Copy handler files
    if (Test-Path ".\$Folder\*.py") {
        Copy-Item -Path ".\$Folder\*.py" -Destination $StagingDir -Force
    }
    
    # Install dependencies if requirements.txt exists
    $ReqFile = ".\$Folder\requirements.txt"
    if (Test-Path $ReqFile) {
        Write-Host "Installing dependencies for $Name from $ReqFile..."
        pip install -r $ReqFile -t $StagingDir --quiet --platform manylinux2014_x86_64 --python-version 3.10 --only-binary=:all:
        if (Test-Path "$StagingDir\boto3") { Remove-Item "$StagingDir\boto*" -Recurse -Force -ErrorAction SilentlyContinue }
    }
    
    # Copy includes (e.g. core/, knowledge_base/)
    if ($null -ne $Includes) {
        foreach ($inc in $Includes) {
            if (Test-Path ".\$inc") {
                $Dest = Join-Path $StagingDir $inc
                New-Item -ItemType Directory -Path $Dest | Out-Null
                Copy-Item -Path ".\$inc\*" -Destination $Dest -Recurse -Force
            }
        }
    }
    
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force
    
    Write-Host "Updating AWS Lambda: $Name..."
    aws lambda update-function-code --function-name $Name --zip-file "fileb://$ZipPath" | Out-Null
    Write-Host "Done: $Name"
}

Write-Host "=== Deploying Prompt Routing Changes ==="
Write-Host ""

# 1. Input Validator (no core/ needed — doesn't import prompt_registry)
Deploy-Lambda -Name "pmi-input-validator-client-demo1" -Folder "agents\input_validator"

# 2. Master Researcher (needs core/ for prompt_registry + knowledge_base/)
Deploy-Lambda -Name "pmi-master-researcher-client-demo1" -Folder "agents\master_researcher" -Includes @("core", "knowledge_base")

# 3. Master Drafter (needs core/ for prompt_registry + knowledge_base/)
Deploy-Lambda -Name "pmi-master-drafter-client-demo1" -Folder "agents\master_drafter" -Includes @("core", "knowledge_base")

Write-Host ""
Write-Host "=== All 3 Lambdas deployed! Ready to test Step Function. ==="
