# Test script for PMI Agentic AI API endpoints

Write-Host "Testing PMI Agentic AI Backend API..." -ForegroundColor Green

# Get API Gateway URL from CDK outputs or CloudFormation
$API_BASE_URL = Read-Host "Enter your API Gateway URL (e.g., https://xxxxxxxxxx.execute-api.us-east-1.amazonaws.com/prod)"

if (-not $API_BASE_URL) {
    Write-Host "ERROR: API URL is required" -ForegroundColor Red
    exit 1
}

# Test 1: Health Check
Write-Host "`nTesting Health Endpoint..." -ForegroundColor Yellow
try {
    $healthResponse = Invoke-RestMethod -Uri "$API_BASE_URL/health" -Method GET
    Write-Host "✓ Health Check: $($healthResponse.status)" -ForegroundColor Green
    Write-Host "  Timestamp: $($healthResponse.timestamp)" -ForegroundColor Cyan
} catch {
    Write-Host "✗ Health Check Failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: Create Request
Write-Host "`nTesting Create Request Endpoint..." -ForegroundColor Yellow

$requestBody = @{
    description = "Test request for position paper on ESG compliance"
    priority = "high"
    deadline = "2025-02-15"
    requirements = @(
        "Current ESG regulations",
        "Industry best practices",
        "PMI's position on sustainability"
    )
} | ConvertTo-Json

try {
    $createResponse = Invoke-RestMethod -Uri "$API_BASE_URL/requests" -Method POST -Body $requestBody -ContentType "application/json"
    $requestId = $createResponse.request_id
    Write-Host "✓ Request Created: $requestId" -ForegroundColor Green
    Write-Host "  Status: $($createResponse.status)" -ForegroundColor Cyan
    
    # Test 3: Get Request Status
    Write-Host "`nTesting Get Request Status..." -ForegroundColor Yellow
    Start-Sleep -Seconds 2
    
    $statusResponse = Invoke-RestMethod -Uri "$API_BASE_URL/requests/$requestId" -Method GET
    Write-Host "✓ Request Status Retrieved" -ForegroundColor Green
    Write-Host "  Status: $($statusResponse.status)" -ForegroundColor Cyan
    Write-Host "  Progress: $($statusResponse.progress)%" -ForegroundColor Cyan
    
    # Monitor progress
    Write-Host "`nMonitoring request progress..." -ForegroundColor Yellow
    $maxChecks = 10
    $checkCount = 0
    
    do {
        Start-Sleep -Seconds 5
        $checkCount++
        
        try {
            $progressResponse = Invoke-RestMethod -Uri "$API_BASE_URL/requests/$requestId" -Method GET
            Write-Host "Check $checkCount`: Status=$($progressResponse.status), Progress=$($progressResponse.progress)%" -ForegroundColor Cyan
            
            if ($progressResponse.status -eq "completed" -or $progressResponse.status -eq "failed") {
                break
            }
        } catch {
            Write-Host "Progress check failed: $($_.Exception.Message)" -ForegroundColor Yellow
        }
        
    } while ($checkCount -lt $maxChecks -and $progressResponse.status -eq "processing")
    
    if ($progressResponse.status -eq "completed") {
        Write-Host "✓ Request completed successfully!" -ForegroundColor Green
        if ($progressResponse.document_url) {
            Write-Host "  Document URL: $($progressResponse.document_url)" -ForegroundColor Cyan
        }
    } elseif ($progressResponse.status -eq "failed") {
        Write-Host "✗ Request failed" -ForegroundColor Red
        Write-Host "  Error: $($progressResponse.error)" -ForegroundColor Red
    } else {
        Write-Host "⏳ Request still processing after $maxChecks checks" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host "✗ Create Request Failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Response: $($_.ErrorDetails.Message)" -ForegroundColor Red
}

Write-Host "`nAPI Testing Complete!" -ForegroundColor Green
Write-Host "`nNext Steps:" -ForegroundColor Yellow
Write-Host "1. Check AWS CloudWatch Logs for detailed execution logs" -ForegroundColor White
Write-Host "2. Monitor Step Functions execution in AWS Console" -ForegroundColor White
Write-Host "3. Verify S3 bucket for generated documents" -ForegroundColor White
Write-Host "4. Update frontend configuration with this API URL" -ForegroundColor White
