import json
import logging
from pprint import pprint
import sys
import os

# Add the project root to the python path so it can find the knowledge_base module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Set up logging
logging.basicConfig(level=logging.INFO)

# Import the KnowledgeBaseSearcher
from knowledge_base.kb_searcher import KnowledgeBaseSearcher

def main():
    print("Testing Knowledge Base Search with Campaign Payload...")
    
    # Initialize the searcher (it will use the local AWS credentials you just configured)
    searcher = KnowledgeBaseSearcher()
    
    # The payload provided
    payload = {
        "document_type": "Media Releases",
        "topic": "Public Health and Tobacco Regulation Campaign",
        "jurisdiction": "Thailand",
        "deadline": "2026-05-15T23:59:59Z",
        "target_audience": "Ministry of Public Health",
        "background": "Developing a campaign strategy based on historical campaign data in Thailand.",
        "priority": "high",
        "target_language": "English",
        "tone_requirements": "Professional, formal, compliance-first"
    }
    
    # Construct a strong search query based on the payload
    # A combination of topic, background, and jurisdiction works best for semantic embeddings
    query = f"{payload['topic']} in {payload['jurisdiction']}. {payload['background']}"
    
    # Optional filters based on jurisdiction and document type
    filters = {
        # You can add DynamoDB partition/sort key filters here if the table schema requires them
    }
    
    print(f"\nQuerying: '{query}'")
    
    try:
        results = searcher.search_knowledge_base(
            query=query,
            filters=None, # Not applying strict filters to cast a wider semantic net first
            max_results=5
        )
        
        print(f"\n--- Search Complete. Found {len(results)} chunks ---")
        
        for i, chunk in enumerate(results):
            print(f"\n--- Chunk {i+1} ---")
            print(f"Similarity Score: {chunk.get('similarity_score', 'N/A')}")
            print(f"Content Preview: {chunk.get('content', '')[:300]}...")
            print(f"Source Document: {chunk.get('source_document', 'Unknown')}")
            
            if chunk.get('document_metadata'):
                print(f"Metadata: {json.dumps(chunk['document_metadata'], indent=2)}")
                
    except Exception as e:
        print(f"\nError during search: {e}")

if __name__ == "__main__":
    main()
