import os
import shutil
import zipfile
import boto3

def main():
    # Use path resolution relative to script's directory (inside scripts/) to find project root
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    
    staging_dir = os.path.join(script_dir, "staging_api_fix")
    zip_filepath = os.path.join(script_dir, "api_deploy_fix.zip")
    
    # 1. Clean up old staging
    if os.path.exists(staging_dir):
        shutil.rmtree(staging_dir)
    os.makedirs(staging_dir)
    
    # 2. Copy lambda_function_new.py as lambda_function.py
    src_file = os.path.join(project_root, "api", "lambda_function_new.py")
    dest_file = os.path.join(staging_dir, "lambda_function.py")
    
    print(f"Packaging {src_file} as lambda_function.py...")
    try:
        shutil.copy2(src_file, dest_file)
    except Exception as e:
        print(f"ERROR copying file: {e}")
        # Clean up and exit
        if os.path.exists(staging_dir):
            shutil.rmtree(staging_dir)
        return
    
    # 3. Create zip archive
    print(f"Creating zip archive {zip_filepath}...")
    with zipfile.ZipFile(zip_filepath, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(dest_file, arcname="lambda_function.py")
        
    # 4. Upload to AWS Lambda
    lambda_client = boto3.client('lambda', region_name='eu-west-1')
    function_name = 'pmi-api-latest-requests-handler'
    
    print(f"Uploading new zip code to AWS Lambda function '{function_name}'...")
    with open(zip_filepath, 'rb') as f:
        zip_data = f.read()
        
    try:
        response = lambda_client.update_function_code(
            FunctionName=function_name,
            ZipFile=zip_data
        )
        print("SUCCESS: Lambda function code updated successfully!")
        print(f"Version: {response.get('Version')}")
        print(f"CodeSha256: {response.get('CodeSha256')}")
    except Exception as e:
        print(f"ERROR updating Lambda code: {e}")
        
    # 5. Cleanup
    if os.path.exists(staging_dir):
        shutil.rmtree(staging_dir)
    if os.path.exists(zip_filepath):
        os.remove(zip_filepath)

if __name__ == '__main__':
    main()
