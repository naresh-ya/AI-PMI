"""
Test script: Verify AWS Bedrock Knowledge Base retrieval is working.

Tests:
1. List available knowledge bases (confirm KB exists)
2. Retrieve documents with a test query (confirm retrieval works)
3. Test metadata filtering (confirm metadata is indexed)
4. Test multiple queries to assess relevance quality

Prerequisites:
- AWS credentials configured (aws configure)
- Region: eu-west-1
- Knowledge Base must be synced (check console — status: "Complete")

Usage:
    python scripts/test_bedrock_kb.py
"""

import boto3
import json
import sys
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION — Update these values from your AWS console
# ═══════════════════════════════════════════════════════════════════════════════

# Get your KB ID from the Bedrock console:
# Console → Amazon Bedrock → Knowledge bases → pmi-experimental-knowledge-base → ID column
KNOWLEDGE_BASE_ID = "OSJDPJLTNC"  # pmi-experimental-knowledge-base (semantic chunking + Titan v2)

REGION = "eu-west-1"

# ═══════════════════════════════════════════════════════════════════════════════

SEP = "=" * 70

# Initialize clients
bedrock_agent = boto3.client('bedrock-agent', region_name=REGION)
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime', region_name=REGION)


def test_1_list_knowledge_bases():
    """Verify the KB exists and is accessible."""
    print(f"\n{SEP}")
    print("TEST 1: List Knowledge Bases — confirm KB exists")
    print(SEP)

    try:
        response = bedrock_agent.list_knowledge_bases(maxResults=10)
        kbs = response.get('knowledgeBaseSummaries', [])
        print(f"  Found {len(kbs)} knowledge base(s):")
        
        found = False
        for kb in kbs:
            kb_id = kb.get('knowledgeBaseId', '')
            name  = kb.get('name', '')
            status = kb.get('status', '')
            print(f"    ID: {kb_id} | Name: {name} | Status: {status}")
            if kb_id == KNOWLEDGE_BASE_ID or 'experimental' in name.lower() or 'pmi' in name.lower():
                found = True
                print(f"    ✅ FOUND — this is your target KB")
        
        if not found and KNOWLEDGE_BASE_ID == "REPLACE_WITH_YOUR_KB_ID":
            print("\n  ⚠️  You need to update KNOWLEDGE_BASE_ID at the top of this script")
            print("     Use one of the IDs listed above")
            return False
        
        return True
    except Exception as e:
        print(f"  ❌ FAIL: {e}")
        return False


def test_2_basic_retrieval():
    """Test basic document retrieval with a simple query."""
    print(f"\n{SEP}")
    print("TEST 2: Basic Retrieval — confirm documents are searchable")
    print(SEP)

    test_queries = [
        "tobacco regulation Thailand",
        "IQOS heated tobacco products",
        "PMI smoke-free products",
    ]

    for query in test_queries:
        print(f"\n  Query: '{query}'")
        try:
            response = bedrock_agent_runtime.retrieve(
                knowledgeBaseId=KNOWLEDGE_BASE_ID,
                retrievalQuery={'text': query},
                retrievalConfiguration={
                    'vectorSearchConfiguration': {
                        'numberOfResults': 3
                    }
                }
            )

            results = response.get('retrievalResults', [])
            print(f"  Results: {len(results)}")
            
            for i, r in enumerate(results):
                content = r.get('content', {}).get('text', '')[:200]
                score   = r.get('score', 0)
                source  = r.get('location', {}).get('s3Location', {}).get('uri', 'unknown')
                metadata = r.get('metadata', {})
                
                print(f"    [{i+1}] Score: {score:.4f}")
                print(f"         Source: {source}")
                if metadata:
                    print(f"         Metadata: {json.dumps(metadata, default=str)[:150]}")
                print(f"         Content: {content[:150]}...")

            if results:
                print(f"  ✅ Retrieval working for '{query}'")
            else:
                print(f"  ⚠️  No results for '{query}' — KB may need sync or query is too specific")

        except Exception as e:
            print(f"  ❌ FAIL: {e}")
            return False

    return True


def test_3_metadata_filtering():
    """Test retrieval with metadata filters (if configured)."""
    print(f"\n{SEP}")
    print("TEST 3: Metadata Filtering — test filtered retrieval")
    print(SEP)

    query = "tobacco products regulation"
    
    # Test without filter first
    print(f"\n  Query: '{query}' (no filter)")
    try:
        response = bedrock_agent_runtime.retrieve(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            retrievalQuery={'text': query},
            retrievalConfiguration={
                'vectorSearchConfiguration': {
                    'numberOfResults': 5
                }
            }
        )
        results_unfiltered = response.get('retrievalResults', [])
        print(f"  Unfiltered results: {len(results_unfiltered)}")
        
        # Show what metadata fields are available
        if results_unfiltered:
            sample_metadata = results_unfiltered[0].get('metadata', {})
            print(f"  Available metadata fields: {list(sample_metadata.keys())}")
            print(f"  Sample metadata: {json.dumps(sample_metadata, default=str)[:300]}")
            
            # Try to identify useful filter fields
            for r in results_unfiltered[:3]:
                loc = r.get('location', {})
                s3_loc = loc.get('s3Location', {})
                print(f"    Source: {s3_loc.get('uri', 'N/A')}")

    except Exception as e:
        print(f"  ❌ FAIL: {e}")
        if "filter" in str(e).lower():
            print("  Note: Metadata filtering may not be configured for this KB data source.")
            print("  This is OK — filtering can be added later via data source configuration.")

    # Test with filter (may not work depending on KB config)
    print(f"\n  Query: '{query}' (with metadata filter attempt)")
    try:
        response = bedrock_agent_runtime.retrieve(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            retrievalQuery={'text': query},
            retrievalConfiguration={
                'vectorSearchConfiguration': {
                    'numberOfResults': 5,
                    'filter': {
                        'equals': {
                            'key': 'jurisdiction',
                            'value': 'Thailand'
                        }
                    }
                }
            }
        )
        results_filtered = response.get('retrievalResults', [])
        print(f"  Filtered results (Thailand): {len(results_filtered)}")
        if results_filtered:
            print(f"  ✅ Metadata filtering works!")
        else:
            print(f"  ⚠️  No filtered results — metadata key may differ. Check data source metadata config.")
    except Exception as e:
        error_msg = str(e)
        if 'filter' in error_msg.lower() or 'validation' in error_msg.lower():
            print(f"  ⚠️  Filtering not supported or misconfigured: {error_msg[:150]}")
            print("  This is expected if metadata fields weren't defined in the data source config.")
        else:
            print(f"  ❌ FAIL: {e}")

    return True


def test_4_retrieval_quality():
    """Test retrieval quality with domain-specific queries."""
    print(f"\n{SEP}")
    print("TEST 4: Retrieval Quality — domain-specific queries")
    print(SEP)

    quality_queries = [
        {
            "query": "FCTC Article 1(d) harm reduction tobacco",
            "expect_keywords": ["fctc", "harm reduction", "tobacco"],
        },
        {
            "query": "FDA MRTP authorization IQOS 2020",
            "expect_keywords": ["fda", "iqos", "mrtp"],
        },
        {
            "query": "Japan heated tobacco market share cigarette sales decline",
            "expect_keywords": ["japan", "heated tobacco", "market"],
        },
        {
            "query": "Thailand Disease Control Department tobacco regulation",
            "expect_keywords": ["thailand", "tobacco", "regulation"],
        },
    ]

    total = 0
    passed = 0

    for qd in quality_queries:
        query = qd["query"]
        keywords = qd["expect_keywords"]
        total += 1
        
        print(f"\n  Query: '{query}'")
        print(f"  Expected keywords: {keywords}")
        
        try:
            response = bedrock_agent_runtime.retrieve(
                knowledgeBaseId=KNOWLEDGE_BASE_ID,
                retrievalQuery={'text': query},
                retrievalConfiguration={
                    'vectorSearchConfiguration': {
                        'numberOfResults': 3
                    }
                }
            )

            results = response.get('retrievalResults', [])
            if not results:
                print(f"  ⚠️  No results")
                continue

            # Check if top result contains expected keywords
            top_content = results[0].get('content', {}).get('text', '').lower()
            score = results[0].get('score', 0)
            found_keywords = [kw for kw in keywords if kw in top_content]
            
            print(f"  Top result score: {score:.4f}")
            print(f"  Keywords found in top result: {found_keywords} ({len(found_keywords)}/{len(keywords)})")
            print(f"  Content preview: {top_content[:200]}...")
            
            if len(found_keywords) >= len(keywords) // 2:
                print(f"  ✅ GOOD — relevant content retrieved")
                passed += 1
            else:
                print(f"  ⚠️  WEAK — top result may not be relevant enough")
                # Show what we got instead
                source = results[0].get('location', {}).get('s3Location', {}).get('uri', 'unknown')
                print(f"  Source: {source}")

        except Exception as e:
            print(f"  ❌ FAIL: {e}")

    print(f"\n  Quality score: {passed}/{total} queries returned relevant results")
    return passed > 0


def test_5_sync_status():
    """Check the data source sync status."""
    print(f"\n{SEP}")
    print("TEST 5: Data Source Sync Status")
    print(SEP)

    try:
        response = bedrock_agent.list_data_sources(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            maxResults=5
        )
        
        data_sources = response.get('dataSourceSummaries', [])
        print(f"  Data sources: {len(data_sources)}")
        
        for ds in data_sources:
            ds_id   = ds.get('dataSourceId', '')
            name    = ds.get('name', '')
            status  = ds.get('status', '')
            print(f"\n    ID: {ds_id}")
            print(f"    Name: {name}")
            print(f"    Status: {status}")
            
            # Get latest sync job
            try:
                sync_response = bedrock_agent.list_ingestion_jobs(
                    knowledgeBaseId=KNOWLEDGE_BASE_ID,
                    dataSourceId=ds_id,
                    maxResults=1,
                    sortBy={'attribute': 'STARTED_AT', 'order': 'DESCENDING'}
                )
                jobs = sync_response.get('ingestionJobSummaries', [])
                if jobs:
                    latest = jobs[0]
                    print(f"    Latest sync: {latest.get('status', 'unknown')}")
                    print(f"    Started: {latest.get('startedAt', 'N/A')}")
                    print(f"    Updated: {latest.get('updatedAt', 'N/A')}")
                    stats = latest.get('statistics', {})
                    if stats:
                        print(f"    Documents scanned: {stats.get('numberOfDocumentsScanned', 0)}")
                        print(f"    Documents indexed: {stats.get('numberOfNewDocumentsIndexed', 0) + stats.get('numberOfModifiedDocumentsIndexed', 0)}")
                        print(f"    Documents failed: {stats.get('numberOfDocumentsFailed', 0)}")
            except Exception as e:
                print(f"    Could not get sync details: {e}")

        return True
    except Exception as e:
        print(f"  ❌ FAIL: {e}")
        return False


# ═══════════════════════════════════════════════════════════════════════════════
# Run all tests
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print(SEP)
    print("AWS Bedrock Knowledge Base — Retrieval Test")
    print(f"KB ID: {KNOWLEDGE_BASE_ID}")
    print(f"Region: {REGION}")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print(SEP)

    if KNOWLEDGE_BASE_ID == "REPLACE_WITH_YOUR_KB_ID":
        print("\n⚠️  Please update KNOWLEDGE_BASE_ID at the top of this script.")
        print("   Find it in: AWS Console → Bedrock → Knowledge bases → your KB → ID column")
        print("   Then re-run this script.\n")
        # Still run test 1 to list available KBs
        test_1_list_knowledge_bases()
        sys.exit(1)

    results = {}
    results["1_kb_exists"]       = test_1_list_knowledge_bases()
    results["2_basic_retrieval"] = test_2_basic_retrieval()
    results["3_metadata_filter"] = test_3_metadata_filtering()
    results["4_quality"]         = test_4_retrieval_quality()
    results["5_sync_status"]     = test_5_sync_status()

    # Summary
    print(f"\n{SEP}")
    print("SUMMARY")
    print(SEP)
    
    passed = sum(1 for v in results.values() if v)
    failed = sum(1 for v in results.values() if not v)
    
    for test_name, result in results.items():
        tag = "✅" if result else "❌"
        print(f"  {tag} {test_name}")

    print(f"\n  Total: {passed} passed / {failed} failed")
    
    if failed == 0:
        print("\n  ✅ All tests passed — Bedrock KB retrieval is working!")
        print("  Next step: integrate with handler_new_advanced.py to replace custom DynamoDB RAG")
    else:
        print("\n  ⚠️  Some tests failed — check output above for details")

    sys.exit(0 if failed == 0 else 1)
