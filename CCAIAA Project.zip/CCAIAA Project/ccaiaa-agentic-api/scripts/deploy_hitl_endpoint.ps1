# deploy_hitl_endpoint.ps1
# PowerShell script to deploy Researcher HITL endpoints to the existing pmi-hitl-interface Lambda
# and configure API Gateway HTTP API routes.

$ErrorActionPreference = "Stop"

$Region = "eu-west-1"
$ApiId = "y97ca45wk1"
$LambdaName = "pmi-hitl-interface"
$ReferenceLambdaName = "pmi-master-researcher-client-demo1"

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "1. Fetching Configuration from Reference Lambda: $ReferenceLambdaName" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# Fetch VPC configuration from reference Lambda
Write-Host "Fetching VPC config..." -ForegroundColor Yellow
$refConfig = aws lambda get-function-configuration --function-name $ReferenceLambdaName --region $Region --output json | ConvertFrom-Json

$subnetIds = $refConfig.VpcConfig.SubnetIds -join ","
$securityGroupIds = $refConfig.VpcConfig.SecurityGroupIds -join ","

Write-Host "Found Subnets: $subnetIds" -ForegroundColor Green
Write-Host "Found Security Groups: $securityGroupIds" -ForegroundColor Green

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "2. Packaging Lambda function: $LambdaName" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

$Timestamp = Get-Date -Format "yyyyMMddHHmmss"
$StagingDir = "$env:TEMP\lambda_staging_${LambdaName}_${Timestamp}"
$ZipPath = "$env:TEMP\lambda_deploy_${LambdaName}_${Timestamp}.zip"

if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force -ErrorAction SilentlyContinue }
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue }

New-Item -ItemType Directory -Path $StagingDir | Out-Null

# Copy handler_hitl_new.py to staging directory
Write-Host "Copying handler_hitl_new.py..." -ForegroundColor Yellow
Copy-Item -Path ".\api\handler_hitl_new.py" -Destination $StagingDir\handler_hitl_new.py -Force

# Zip the package
Write-Host "Zipping package..." -ForegroundColor Yellow
Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "3. Uploading Lambda code to AWS" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

Write-Host "Updating Lambda function code..." -ForegroundColor Yellow
aws lambda update-function-code `
    --function-name $LambdaName `
    --zip-file fileb://$ZipPath `
    --region $Region `
    | Out-Null

aws lambda wait function-updated --function-name $LambdaName --region $Region

Write-Host "Lambda code updated successfully!" -ForegroundColor Green

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "4. Updating Lambda Configuration" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# Update Handler, VPC config and timeout (Role is already the same)
Write-Host "Updating handler, timeout, and VPC config..." -ForegroundColor Yellow
aws lambda update-function-configuration `
    --function-name $LambdaName `
    --handler "handler_hitl_new.lambda_handler" `
    --timeout 300 `
    --vpc-config "SubnetIds=$subnetIds,SecurityGroupIds=$securityGroupIds" `
    --region $Region `
    | Out-Null

aws lambda wait function-updated --function-name $LambdaName --region $Region

# Update Environment Variables: Copy from reference Lambda + add HITL_TABLE
Write-Host "Updating environment variables..." -ForegroundColor Yellow
$envVars = $refConfig.Environment.Variables
$envVars | Add-Member -NotePropertyName "HITL_TABLE" -NotePropertyValue "pmi-agentic-ai-hitl-dev" -Force

# Convert back to JSON format and update Lambda configuration
$envJson = @{ Variables = $envVars } | ConvertTo-Json -Compress
$TempJsonPath = "$env:TEMP\lambda_env_$LambdaName.json"
[System.IO.File]::WriteAllText($TempJsonPath, $envJson)

aws lambda update-function-configuration `
    --function-name $LambdaName `
    --environment "file://$TempJsonPath" `
    --region $Region `
    | Out-Null

aws lambda wait function-updated --function-name $LambdaName --region $Region

if (Test-Path $TempJsonPath) { Remove-Item $TempJsonPath -Force }
Write-Host "Lambda configuration updated successfully!" -ForegroundColor Green

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "5. Setting up API Gateway HTTP API Route" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# Check if integration already exists
Write-Host "Checking for existing Lambda integration..." -ForegroundColor Yellow
$integrations = aws apigatewayv2 get-integrations --api-id $ApiId --region $Region --output json | ConvertFrom-Json
$integrationId = ""

foreach ($item in $integrations.Items) {
    if ($item.IntegrationUri -like "*$LambdaName*") {
        $integrationId = $item.IntegrationId
        break
    }
}

if ($integrationId -eq "") {
    Write-Host "Integration does not exist. Creating new integration..." -ForegroundColor Yellow
    # Create new integration
    $integrationResult = aws apigatewayv2 create-integration `
        --api-id $ApiId `
        --integration-type AWS_PROXY `
        --integration-method POST `
        --integration-uri "arn:aws:apigateway:${Region}:lambda:path/2015-03-31/functions/arn:aws:lambda:${Region}:603433800649:function:${LambdaName}/invocations" `
        --payload-format-version 2.0 `
        --region $Region `
        --output json | ConvertFrom-Json
    
    $integrationId = $integrationResult.IntegrationId
}

Write-Host "Using Integration ID: $integrationId" -ForegroundColor Green

# Create Routes (GET, POST, OPTIONS) if they don't already exist
$routes = aws apigatewayv2 get-routes --api-id $ApiId --region $Region --output json | ConvertFrom-Json

$getRouteExists = $false
$postRouteExists = $false
$optionsRouteExists = $false

foreach ($route in $routes.Items) {
    if ($route.RouteKey -eq "GET /requests/research/hitl/{hitl_id}") { $getRouteExists = $true }
    elseif ($route.RouteKey -eq "POST /requests/research/hitl/{hitl_id}") { $postRouteExists = $true }
    elseif ($route.RouteKey -eq "OPTIONS /requests/research/hitl/{hitl_id}") { $optionsRouteExists = $true }
}

if (-not $getRouteExists) {
    Write-Host "Creating GET route..." -ForegroundColor Yellow
    aws apigatewayv2 create-route --api-id $ApiId --route-key "GET /requests/research/hitl/{hitl_id}" --target "integrations/$integrationId" --region $Region | Out-Null
}
if (-not $postRouteExists) {
    Write-Host "Creating POST route..." -ForegroundColor Yellow
    aws apigatewayv2 create-route --api-id $ApiId --route-key "POST /requests/research/hitl/{hitl_id}" --target "integrations/$integrationId" --region $Region | Out-Null
}
if (-not $optionsRouteExists) {
    Write-Host "Creating OPTIONS route..." -ForegroundColor Yellow
    aws apigatewayv2 create-route --api-id $ApiId --route-key "OPTIONS /requests/research/hitl/{hitl_id}" --target "integrations/$integrationId" --region $Region | Out-Null
}

Write-Host "API routes configured successfully!" -ForegroundColor Green

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "6. Granting API Gateway Permission to Invoke Lambda" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# Remove old permission if exists to avoid collision
try {
    aws lambda remove-permission --function-name $LambdaName --statement-id apigateway-hitl-research --region $Region 2>$null | Out-Null
} catch {}

Write-Host "Granting invoke permission..." -ForegroundColor Yellow
aws lambda add-permission `
    --function-name $LambdaName `
    --statement-id apigateway-hitl-research `
    --action lambda:InvokeFunction `
    --principal apigateway.amazonaws.com `
    --source-arn "arn:aws:execute-api:${Region}:603433800649:${ApiId}/*/*" `
    --region $Region `
    | Out-Null

Write-Host "Permissions granted successfully!" -ForegroundColor Green

# Cleanup staging files
if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force -ErrorAction SilentlyContinue }
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue }

Write-Host "=============================================" -ForegroundColor Green
Write-Host "DEPLOYMENT COMPLETE!" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
