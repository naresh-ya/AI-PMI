#!/bin/bash
# Fast deploy script for kb_searcher Lambda

LAMBDA_NAME="pmi-kb-searcher-client-demo1"
REGION="eu-west-1"
BUILD_DIR=".build"
STAGING_DIR="$BUILD_DIR/kb-searcher-staging"
ZIP_PATH="$BUILD_DIR/kb_searcher.zip"

echo "Setting up staging directory..."
mkdir -p "$STAGING_DIR"
rm -rf "$STAGING_DIR"/*

echo "Copying files..."
cp knowledge_base/kb_searcher.py "$STAGING_DIR/"
cp -r core "$STAGING_DIR/"

echo "Zipping payload..."
cd "$STAGING_DIR" || exit
zip -q -r "../kb_searcher.zip" .
cd - || exit

echo "Deploying to AWS Lambda: $LAMBDA_NAME ..."
aws lambda update-function-code \
  --function-name "$LAMBDA_NAME" \
  --zip-file "fileb://$ZIP_PATH" \
  --region "$REGION" > /dev/null

if [ $? -eq 0 ]; then
    echo "Waiting for update to complete..."
    aws lambda wait function-updated \
        --function-name "$LAMBDA_NAME" \
        --region "$REGION"
    echo "Deployed successfully!"
else
    echo "Deploy FAILED"
    exit 1
fi
