"""
Local end-to-end driver for the client-demo2 split pipeline.

Runs the EXACT Step Functions sequence in-process, against the real AWS backends:

    InputValidator -> Planner -> [KB, Web, UserSources, Curated] -> Synthesis -> Drafter

It pulls the real environment (LiteLLM key, Tavily key, table names, KB id, model ids,
VPC-independent settings) from the deployed demo1 Lambdas and injects them into os.environ
BEFORE importing the handlers, so the handlers are configured exactly like in AWS.

IMPORTANT — network reachability:
  - KB retrieval, Bedrock embeddings, DynamoDB, S3 use public AWS APIs and work with your
    SSO creds from anywhere.
  - LLM calls (framing/planning/synthesis/drafting) and Tavily web search route through the
    PRIVATE LiteLLM gateway (litellm.aiplat-dev.aws.private-pmideep.biz). Those stages only
    succeed if this machine can reach that host (corporate VPN / VPC). Otherwise they will
    error/return empty — that is an environment limitation, not a pipeline bug.

Usage:
    python scripts/run_demo2_local.py
    python scripts/run_demo2_local.py --request-json my_request.json
    python scripts/run_demo2_local.py --stop-after synthesis
"""

import os
import sys
import json
import time
import argparse
import subprocess
from datetime import datetime

REGION = "eu-west-1"

# Pull env from these demo1 functions (richest first wins on key collisions).
ENV_SOURCES = [
    "pmi-input-validator-client-demo1",
    "pmi-master-drafter-client-demo1",
    "pmi-master-researcher-client-demo1",
]

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(REPO_ROOT, "local_demo2_run")

# A self-contained sample request (no uploaded file / external URLs -> user_sources is
# legitimately empty). Override with --request-json.
SAMPLE_REQUEST_DATA = {
    "category": "White Papers",
    "document_type": "Position Paper",
    "topic": "Science Behind Smoke-Free Alternatives",
    "jurisdiction": "Global",
    "deadline": "2026-07-01",
    "target_language": "English",
    "output_file_type": "Microsoft Word (.docx)",
    "background": "Compilation of clinical and scientific evidence on smoke-free alternatives.",
    "stakeholders": "Scientific Affairs, Medical Experts",
    "priority": "high",
    "tone_requirements": "Scientific, balanced, evidence-based",
    "target_audience": "Healthcare professionals and regulators",
}


def _load_env_from_lambdas():
    """Fetch Environment.Variables from the demo1 source lambdas and inject into os.environ.
    Existing process env (AWS creds, region) is preserved; lambda vars fill the rest."""
    merged = {}
    for fn in ENV_SOURCES:
        try:
            raw = subprocess.run(
                ["aws", "lambda", "get-function-configuration",
                 "--function-name", fn, "--query", "Environment.Variables",
                 "--output", "json", "--region", REGION],
                capture_output=True, text=True, check=True
            ).stdout
            vars_ = json.loads(raw) if raw.strip() else {}
            if isinstance(vars_, dict):
                merged.update(vars_)
                print(f"  env: pulled {len(vars_)} vars from {fn}")
        except subprocess.CalledProcessError as e:
            msg = e.stderr.strip() if e.stderr else str(e)
            print(f"  WARN: could not read env from {fn}: {msg}")
    # Inject without clobbering anything already set in the shell (e.g. AWS_*).
    applied = 0
    for k, v in merged.items():
        if k not in os.environ:
            os.environ[k] = str(v)
            applied += 1
    os.environ.setdefault("AWS_REGION", REGION)
    os.environ.setdefault("AWS_DEFAULT_REGION", REGION)
    print(f"  env: applied {applied} vars into the local process\n")


def _save(stage, obj, request_id):
    d = os.path.join(OUT_DIR, request_id)
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{stage}.json")
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2, default=str)
        print(f"  saved -> {os.path.relpath(path, REPO_ROOT)}")
    except Exception as e:
        print(f"  WARN: could not save {stage}: {e}")


def _count_sources(stage_out):
    if isinstance(stage_out, dict):
        return len(stage_out.get("sources", []) or [])
    return 0


def main():
    parser = argparse.ArgumentParser(description="Run the client-demo2 pipeline locally end-to-end.")
    parser.add_argument("--request-json", help="Path to a JSON file with the request_data fields.", default=None)
    parser.add_argument("--request-id", help="Override the generated request_id.", default=None)
    parser.add_argument(
        "--stop-after",
        choices=["validator", "planner", "parallel", "synthesis", "drafter"],
        default="drafter",
        help="Stop the pipeline after this stage (default: drafter = full run)."
    )
    parser.add_argument(
        "--drafter-from",
        metavar="REQUEST_ID",
        default=None,
        help="Skip research: load saved 01_validation.json + 04_synthesis.json for this "
             "request_id from local_demo2_run/ and run ONLY the drafter (fast fix-verify)."
    )
    args = parser.parse_args()

    # Load real config from demo1 lambdas, THEN import handlers (module-level reads env).
    print("Loading environment from demo1 lambdas...")
    _load_env_from_lambdas()
    if REPO_ROOT not in sys.path:
        sys.path.insert(0, REPO_ROOT)

    # ── Drafter-only fast path (verify drafter fixes without re-running research) ──
    if args.drafter_from:
        rid = args.drafter_from
        d = os.path.join(OUT_DIR, rid)
        with open(os.path.join(d, "01_validation.json"), encoding="utf-8") as f:
            validation = json.load(f)
        with open(os.path.join(d, "04_synthesis.json"), encoding="utf-8") as f:
            synthesis_out = json.load(f)
        from agents.master_drafter import handler_drafter_new as drafter
        print(f"\n======== Drafter (from saved {rid}) ========")
        draft = drafter.lambda_handler({
            "request_id": rid,
            "research_result": synthesis_out,
            "validation_result": validation,
        }, None)
        _save("05_draft", draft, rid)
        print(f"  status={draft.get('status') if isinstance(draft, dict) else draft}")
        if isinstance(draft, dict):
            for k in ("document_s3_key", "s3_key", "document_url", "word_count"):
                if k in draft:
                    print(f"  {k}={draft[k]}")
        return

    from agents.input_validator import handler_new_validator as validator
    from agents.master_researcher import handler_planner as planner
    from agents.master_researcher import handler_kb_search as kb
    from agents.master_researcher import handler_web_search as web
    from agents.master_researcher import handler_user_sources as usersrc
    from agents.master_researcher import handler_curated_links as curated
    from agents.master_researcher import handler_synthesis as synthesis
    from agents.master_drafter import handler_drafter_new as drafter

    # 2. Build the request
    request_data = SAMPLE_REQUEST_DATA
    if args.request_json:
        with open(args.request_json, encoding="utf-8") as f:
            request_data = json.load(f)
    request_id = args.request_id or f"req_{datetime.now():%Y%m%d%H%M%S}_localtest"
    research_start = datetime.now().isoformat()

    print(f"\n=== RUN {request_id} ===")
    print(f"topic='{request_data.get('topic')}' | category='{request_data.get('category')}' "
          f"| jurisdiction='{request_data.get('jurisdiction')}'\n")

    def stage(label):
        print(f"\n======== {label} ========")

    # ── Stage 1: Input Validator ──────────────────────────────────────────────
    stage("InputValidator")
    validation = validator.lambda_handler({"request_id": request_id, "request_data": request_data}, None)
    _save("01_validation", validation, request_id)
    status = validation.get("status")
    print(f"  status={status}")
    if status != "success":
        print(f"  validation did not succeed ({status}); stopping. error={validation.get('error')}")
        return
    requirements = validation.get("document_requirements", {})
    print(f"  document_requirements keys: {sorted(requirements.keys())}")
    if args.stop_after == "validator":
        return

    # ── Stage 2: Planner ──────────────────────────────────────────────────────
    stage("Planner")
    planner_out = planner.lambda_handler({"request_id": request_id, "requirements": requirements}, None)
    enriched = planner_out.get("requirements", requirements)
    _save("02_planner", planner_out, request_id)
    framing = enriched.get("_research_framing", {})
    print(f"  planned_queries={len(enriched.get('_planned_queries', []) or [])} "
          f"| framing.intent='{(framing or {}).get('intent', '')[:60]}' "
          f"| jurisdiction_ctx={'yes' if enriched.get('_jurisdiction_context') else 'no'} "
          f"| output_template={'yes' if enriched.get('_output_template') else 'no'}")
    if args.stop_after == "planner":
        return

    # ── Stage 3: Parallel research (branch order MUST be [KB, Web, UserSources, Curated]) ──
    stage("ParallelResearch")
    parallel_outputs = []
    for label, mod in [("KB", kb), ("Web", web), ("UserSources", usersrc), ("Curated", curated)]:
        try:
            out = mod.lambda_handler({"request_id": request_id, "requirements": enriched}, None)
        except Exception as e:
            out = {"sources": [], "citations": [], "queries": [], "error": f"{type(e).__name__}: {e}"}
        parallel_outputs.append(out)
        err = out.get("error") if isinstance(out, dict) else None
        print(f"  {label:12} sources={_count_sources(out)}" + (f"  ERROR={err}" if err else ""))
    _save("03_parallel_outputs", parallel_outputs, request_id)
    if args.stop_after == "parallel":
        return

    # ── Stage 4: Synthesis (terminal research stage; writes S3 + DDB status) ──
    stage("Synthesis")
    synthesis_out = synthesis.lambda_handler({
        "request_id": request_id,
        "requirements": enriched,
        "parallel_outputs": parallel_outputs,
        "research_start": research_start,
    }, None)
    _save("04_synthesis", synthesis_out, request_id)
    rs = synthesis_out.get("research_summary", {}) if isinstance(synthesis_out, dict) else {}
    print(f"  status={synthesis_out.get('status')} "
          f"| total_sources={rs.get('total_sources')} "
          f"| relevant={rs.get('relevant_sources')} "
          f"| citations={synthesis_out.get('citation_count')} "
          f"| research_s3_key={synthesis_out.get('research_s3_key')}")
    print(f"  key_findings={len(synthesis_out.get('key_findings', []) or [])} "
          f"| policy_insights={len(synthesis_out.get('policy_insights', []) or [])} "
          f"| recommendations={len(synthesis_out.get('recommendations', []) or [])}")
    if args.stop_after == "synthesis":
        return

    # ── Stage 5: Drafter ──────────────────────────────────────────────────────
    stage("Drafter")
    draft = drafter.lambda_handler({
        "request_id": request_id,
        "research_result": synthesis_out,
        "validation_result": validation,
    }, None)
    _save("05_draft", draft, request_id)
    print(f"  status={draft.get('status') if isinstance(draft, dict) else draft}")
    if isinstance(draft, dict):
        for k in ("document_s3_key", "s3_key", "document_url", "word_count"):
            if k in draft:
                print(f"  {k}={draft[k]}")

    print(f"\n=== DONE {request_id} — artifacts in {os.path.relpath(os.path.join(OUT_DIR, request_id), REPO_ROOT)} ===")


if __name__ == "__main__":
    main()
