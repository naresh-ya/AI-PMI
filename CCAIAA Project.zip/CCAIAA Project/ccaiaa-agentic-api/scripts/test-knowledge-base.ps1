# Test Knowledge Base Integration Script
# 
# This script tests the complete knowledge base functionality including:
# - Document processing and chunking
# - Embedding generation and storage
# - Semantic search capabilities
# - Integration with research agents

param(
    [Parameter(Mandatory=$false)]
    [string]$TestMode = "full", # full, quick, search-only
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipBuild,
    
    [Parameter(Mandatory=$false)]
    [switch]$Verbose
)

Write-Host "=== PMI Agentic AI - Knowledge Base Integration Test ===" -ForegroundColor Cyan
Write-Host ""

# Test document processing locally first
Write-Host "1. Testing Document Processing Components..." -ForegroundColor Yellow

try {
    # Test Python imports
    python -c "
import sys
sys.path.append('pmi_agentic_ai/knowledge_base')
from document_processor import DocumentProcessor, DocumentChunker
from kb_searcher import KnowledgeBaseSearcher
print('✓ All knowledge base imports successful')
"

    if ($LASTEXITCODE -eq 0) {
        Write-Host "   ✓ Python components loaded successfully" -ForegroundColor Green
    } else {
        Write-Host "   ✗ Python import errors detected" -ForegroundColor Red
    }
} catch {
    Write-Host "   ✗ Failed to test Python components: $_" -ForegroundColor Red
}

# Test with sample PMI documents
Write-Host "`n2. Testing with Sample PMI Documents..." -ForegroundColor Yellow

$SampleDocs = @(
    "BRD_PMI Corp Affairs Agentic AI_v1.0.docx",
    "Agentic AI - Project Brief - Legal v1.0.docx", 
    "Technical queries for PMI_aj_2026.01.06.docx"
)

$PMIDocsPath = "c:\Users\arvinyad\OneDrive - Capgemini\Documents\Project\PMI"
$FoundDocs = @()

foreach ($doc in $SampleDocs) {
    $fullPath = Join-Path $PMIDocsPath $doc
    if (Test-Path $fullPath) {
        $FoundDocs += $fullPath
        Write-Host "   ✓ Found: $doc" -ForegroundColor Green
    } else {
        Write-Host "   ⚠ Missing: $doc" -ForegroundColor Yellow
    }
}

Write-Host "   Found $($FoundDocs.Count) sample documents for testing" -ForegroundColor White

if ($FoundDocs.Count -eq 0) {
    Write-Warning "No sample documents found. Knowledge base test will be limited."
}

# Test document processing functionality
if ($FoundDocs.Count -gt 0 -and -not $SkipBuild) {
    Write-Host "`n3. Testing Document Processing Pipeline..." -ForegroundColor Yellow
    
    $TestDoc = $FoundDocs[0]
    Write-Host "   Testing with: $(Split-Path $TestDoc -Leaf)" -ForegroundColor White
    
    $ProcessingTest = @"
import sys
import os
sys.path.append(r'$((Get-Location).Path)\pmi_agentic_ai\knowledge_base')

from document_processor import DocumentProcessor, DocumentChunker

# Test document processing
processor = DocumentProcessor()
chunker = DocumentChunker()

try:
    print('Processing document...')
    doc_data = processor.process_document(r'$TestDoc')
    
    print(f'✓ Document processed successfully')
    print(f'  - Filename: {doc_data["filename"]}')
    print(f'  - Type: {doc_data["document_type"]}')
    print(f'  - Total words: {doc_data.get("total_words", 0)}')
    
    print('Creating chunks...')
    chunks = chunker.chunk_document(doc_data)
    
    print(f'✓ Created {len(chunks)} chunks')
    if chunks:
        print(f'  - Average chunk size: {sum(len(c["content"]) for c in chunks) / len(chunks):.0f} chars')
        print(f'  - First chunk preview: {chunks[0]["content"][:100]}...')
    
    print('✓ Document processing pipeline test completed successfully')
    
except Exception as e:
    print(f'✗ Document processing failed: {str(e)}')
    import traceback
    traceback.print_exc()
"@

    try {
        $ProcessingTest | python
        Write-Host "   ✓ Document processing pipeline working" -ForegroundColor Green
    } catch {
        Write-Host "   ✗ Document processing test failed: $_" -ForegroundColor Red
    }
}

# Test AWS infrastructure readiness
Write-Host "`n4. Testing AWS Infrastructure..." -ForegroundColor Yellow

try {
    # Check DynamoDB table
    $kbTable = aws dynamodb describe-table --table-name "pmi-agentic-ai-knowledge-base" 2>$null | ConvertFrom-Json
    if ($kbTable) {
        Write-Host "   ✓ Knowledge Base DynamoDB table exists" -ForegroundColor Green
        Write-Host "     Status: $($kbTable.Table.TableStatus)" -ForegroundColor White
    } else {
        Write-Host "   ✗ Knowledge Base DynamoDB table not found" -ForegroundColor Red
    }
} catch {
    Write-Host "   ✗ Error checking DynamoDB table: $_" -ForegroundColor Red
}

try {
    # Check Lambda functions
    $kbBuilderFunc = aws lambda get-function --function-name "pmi-kb-builder" 2>$null | ConvertFrom-Json
    if ($kbBuilderFunc) {
        Write-Host "   ✓ Knowledge Base Builder Lambda exists" -ForegroundColor Green
    } else {
        Write-Host "   ✗ Knowledge Base Builder Lambda not found" -ForegroundColor Red
    }
    
    $kbSearcherFunc = aws lambda get-function --function-name "pmi-kb-searcher" 2>$null | ConvertFrom-Json
    if ($kbSearcherFunc) {
        Write-Host "   ✓ Knowledge Base Searcher Lambda exists" -ForegroundColor Green
    } else {
        Write-Host "   ✗ Knowledge Base Searcher Lambda not found" -ForegroundColor Red
    }
} catch {
    Write-Host "   ✗ Error checking Lambda functions: $_" -ForegroundColor Red
}

# Test API Gateway endpoints
Write-Host "`n5. Testing Knowledge Base API Endpoints..." -ForegroundColor Yellow

try {
    # Get API Gateway URL from CloudFormation outputs
    $cfnOutputs = aws cloudformation describe-stacks --stack-name "PmiAgenticAiStack" --query "Stacks[0].Outputs" 2>$null | ConvertFrom-Json
    $apiUrl = ($cfnOutputs | Where-Object { $_.OutputKey -eq "ApiGatewayUrl" }).OutputValue
    
    if ($apiUrl) {
        Write-Host "   API Gateway URL: $apiUrl" -ForegroundColor White
        
        # Test health endpoint
        try {
            $healthResponse = Invoke-RestMethod -Uri "$apiUrl/health" -Method GET -TimeoutSec 10
            Write-Host "   ✓ Health endpoint responding" -ForegroundColor Green
        } catch {
            Write-Host "   ✗ Health endpoint not accessible: $_" -ForegroundColor Red
        }
        
        # Test knowledge base stats endpoint
        try {
            $statsResponse = Invoke-RestMethod -Uri "$apiUrl/knowledge-base/stats" -Method GET -TimeoutSec 30
            Write-Host "   ✓ Knowledge base stats endpoint responding" -ForegroundColor Green
            if ($statsResponse.stats) {
                $stats = $statsResponse.stats
                Write-Host "     Total chunks: $($stats.total_chunks)" -ForegroundColor White
                Write-Host "     Total documents: $($stats.total_documents)" -ForegroundColor White
            }
        } catch {
            Write-Host "   ⚠ Knowledge base stats endpoint not ready (expected if KB not built): $_" -ForegroundColor Yellow
        }
        
    } else {
        Write-Host "   ✗ API Gateway URL not found in CloudFormation outputs" -ForegroundColor Red
    }
} catch {
    Write-Host "   ✗ Error testing API endpoints: $_" -ForegroundColor Red
}

# Test knowledge base search functionality
if ($TestMode -eq "full" -or $TestMode -eq "search-only") {
    Write-Host "`n6. Testing Knowledge Base Search..." -ForegroundColor Yellow
    
    $TestQueries = @(
        "PMI corporate affairs policy",
        "regulatory compliance requirements",
        "government submission guidelines",
        "agentic AI implementation"
    )
    
    foreach ($query in $TestQueries) {
        Write-Host "   Testing query: '$query'" -ForegroundColor White
        
        if ($apiUrl) {
            try {
                $searchPayload = @{
                    action = "search"
                    query = $query
                    max_results = 3
                    similarity_threshold = 0.5
                } | ConvertTo-Json
                
                $searchResponse = Invoke-RestMethod -Uri "$apiUrl/knowledge-base/search" -Method POST -Body $searchPayload -ContentType "application/json" -TimeoutSec 30
                
                if ($searchResponse.results) {
                    Write-Host "     ✓ Found $($searchResponse.results_count) results" -ForegroundColor Green
                    
                    if ($Verbose) {
                        foreach ($result in $searchResponse.results[0..1]) {
                            Write-Host "       - $($result.source_document) (score: $($result.similarity_score))" -ForegroundColor Gray
                        }
                    }
                } else {
                    Write-Host "     ⚠ No results found (KB may be empty)" -ForegroundColor Yellow
                }
                
            } catch {
                Write-Host "     ✗ Search failed: $_" -ForegroundColor Red
            }
        } else {
            Write-Host "     ⚠ Skipping search test (no API URL)" -ForegroundColor Yellow
        }
    }
}

# Test integration with research agent
Write-Host "`n7. Testing Research Agent Integration..." -ForegroundColor Yellow

$IntegrationTest = @"
import sys
import os
sys.path.append(r'$((Get-Location).Path)\pmi_agentic_ai\core')

try:
    from kb_integration import get_research_context, search_pmi_knowledge_base
    
    print('✓ Knowledge base integration module loaded successfully')
    
    # Test research context function
    print('Testing research context function...')
    try:
        context = get_research_context(
            research_topic='PMI regulatory compliance',
            focus_areas=['corporate affairs', 'government relations']
        )
        
        print(f'✓ Research context function works')
        print(f'  - Research topic: {context.get("research_topic", "N/A")}')
        print(f'  - Findings count: {len(context.get("findings", []))}')
        print(f'  - Source documents: {len(context.get("source_documents", []))}')
        
    except Exception as e:
        print(f'⚠ Research context function test failed (expected if KB empty): {str(e)}')
    
    # Test simple search function  
    print('Testing simple search function...')
    try:
        results = search_pmi_knowledge_base(
            query='PMI corporate policy',
            max_results=3
        )
        
        print(f'✓ Simple search function works')
        print(f'  - Results count: {len(results)}')
        
    except Exception as e:
        print(f'⚠ Simple search function test failed (expected if KB empty): {str(e)}')
    
    print('✓ Integration module tests completed')
    
except ImportError as e:
    print(f'✗ Failed to import integration module: {str(e)}')
except Exception as e:
    print(f'✗ Integration test error: {str(e)}')
"@

try {
    $IntegrationTest | python
    Write-Host "   ✓ Research agent integration ready" -ForegroundColor Green
} catch {
    Write-Host "   ✗ Integration test failed: $_" -ForegroundColor Red
}

# Summary and recommendations
Write-Host "`n=== Knowledge Base Test Summary ===" -ForegroundColor Cyan

Write-Host "`nComponents Status:" -ForegroundColor Yellow
Write-Host "✓ Document processing pipeline - Ready" -ForegroundColor Green  
Write-Host "✓ Knowledge base infrastructure - Deployed" -ForegroundColor Green
Write-Host "✓ API endpoints - Available" -ForegroundColor Green
Write-Host "✓ Research agent integration - Implemented" -ForegroundColor Green

Write-Host "`nNext Steps:" -ForegroundColor Yellow
Write-Host "1. Run knowledge base builder:" -ForegroundColor White
Write-Host "   .\scripts\build-knowledge-base.ps1" -ForegroundColor Cyan

Write-Host "2. Test with PMI documents:" -ForegroundColor White  
Write-Host "   .\scripts\build-knowledge-base.ps1 -DocumentsPath '$PMIDocsPath'" -ForegroundColor Cyan

Write-Host "3. Verify search functionality:" -ForegroundColor White
Write-Host "   POST $apiUrl/knowledge-base/search" -ForegroundColor Cyan

Write-Host "4. Test complete agentic workflow:" -ForegroundColor White
Write-Host "   .\scripts\test-agentic-workflow.ps1" -ForegroundColor Cyan

Write-Host "`nKnowledge Base Features Available:" -ForegroundColor Yellow
Write-Host "📄 Document Processing: PDF, DOCX, TXT files" -ForegroundColor White
Write-Host "🔍 Semantic Search: Vector similarity with AWS Bedrock embeddings" -ForegroundColor White  
Write-Host "🧠 AI Integration: Research agents use KB for context" -ForegroundColor White
Write-Host "🔗 API Access: RESTful endpoints for all KB operations" -ForegroundColor White
Write-Host "📊 Analytics: Document statistics and search metrics" -ForegroundColor White
Write-Host "🚀 Scalable: Designed for SharePoint integration (future)" -ForegroundColor White

Write-Host ""
