param (
    [string]$RoleArn = "arn:aws:iam::603433800649:role/pmi-lambda-execution-role",
    [string]$Region = "eu-west-1",
    [string]$DocumentBucket = "pmi-agentic-ai-documents-603433800649-eu-west-1",
    [string]$RequestsTable = "pmi-agentic-ai-requests"
)

$ErrorActionPreference = "Stop"

$Functions = @(
    @{
        Name = "pmi-kb-searcher-client-demo1"
        SourceDir = "knowledge_base"
        Handler = "kb_searcher.lambda_handler"
        EnvVars = "Variables={DEPLOYMENT_CONTEXT=client-demo1,DOCUMENT_BUCKET=$DocumentBucket,REQUESTS_TABLE=$RequestsTable,KNOWLEDGE_BASE_TABLE=pmi-agentic-ai-knowledge-base}"
    }
)

foreach ($func in $Functions) {
    $FunctionName = $func.Name
    $SourceDir = $func.SourceDir
    $Handler = $func.Handler
    $EnvVars = $func.EnvVars
    
    Write-Host "=================================================" -ForegroundColor Cyan
    Write-Host "Deploying $FunctionName..." -ForegroundColor Cyan
    
    $StagingDir = "$env:TEMP\lambda_staging_$FunctionName"
    $ZipPath = "$env:TEMP\lambda_deploy_$FunctionName.zip"
    
    if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
    
    New-Item -ItemType Directory -Path $StagingDir | Out-Null
    
    # Copy main lambda code
    Copy-Item -Path ".\$SourceDir\*" -Destination $StagingDir -Recurse -Force
    
    # Always bundle the core directory to ensure kb_integration is available
    if (Test-Path ".\core") {
        $CoreDest = Join-Path $StagingDir "core"
        New-Item -ItemType Directory -Path $CoreDest | Out-Null
        Copy-Item -Path ".\core\*" -Destination $CoreDest -Recurse -Force
    }
    
    # Check if specific requirements file exists for this lambda, otherwise use default
    $ReqFile = ".\$SourceDir\requirements.txt"
    if ($FunctionName -eq "pmi-kb-searcher-client-demo1") {
        $ReqFile = ".\$SourceDir\requirements-searcher.txt"
    }

    if (Test-Path $ReqFile) {
        Write-Host "Installing dependencies for $FunctionName (manylinux2014_x86_64 Python 3.10) from $ReqFile..." -ForegroundColor Yellow
        pip install -r $ReqFile -t $StagingDir --quiet --platform manylinux2014_x86_64 --python-version 3.10 --only-binary=:all:
    }
    
    Write-Host "Zipping deployment package..." -ForegroundColor Yellow
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force
    
    # Check if function exists
    $functionExists = $true
    try {
        aws lambda get-function --function-name $FunctionName --region $Region 2>$null | Out-Null
    } catch {
        $functionExists = $false
    }
    
    if ($functionExists) {
        Write-Host "Uploading deployment package to S3 to bypass 50MB limit..." -ForegroundColor Yellow
        $S3Key = "lambda-deployments/$FunctionName-$(Get-Date -Format 'yyyyMMddHHmmss').zip"
        aws s3 cp $ZipPath "s3://$DocumentBucket/$S3Key" | Out-Null
        
        Write-Host "Updating existing function code and configuration..." -ForegroundColor Yellow
        aws lambda update-function-code --function-name $FunctionName --s3-bucket $DocumentBucket --s3-key $S3Key --region $Region | Out-Null
        aws lambda wait function-updated --function-name $FunctionName --region $Region
        aws lambda update-function-configuration --function-name $FunctionName --environment $EnvVars --region $Region | Out-Null
    } else {
        Write-Host "Uploading deployment package to S3 to bypass 50MB limit..." -ForegroundColor Yellow
        $S3Key = "lambda-deployments/$FunctionName-$(Get-Date -Format 'yyyyMMddHHmmss').zip"
        aws s3 cp $ZipPath "s3://$DocumentBucket/$S3Key" | Out-Null
        
        Write-Host "Creating new function..." -ForegroundColor Yellow
        aws lambda create-function `
            --function-name $FunctionName `
            --runtime python3.10 `
            --role $RoleArn `
            --handler $Handler `
            --code "S3Bucket=$DocumentBucket,S3Key=$S3Key" `
            --environment $EnvVars `
            --timeout 900 `
            --memory-size 1024 `
            --region $Region | Out-Null
    }
    
    Write-Host "Successfully deployed $FunctionName!" -ForegroundColor Green
    
    # Cleanup
    if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
}

Write-Host "All demo lambdas deployed successfully!" -ForegroundColor Green
