"""
One-off DynamoDB table copy utility for the dev-suffix removal migration
(see DYNAMODB_MIGRATION_PLAN.md at the repo root).

DynamoDB has no native rename operation -- the only table-level API
operations are CreateTable, DeleteTable, DescribeTable, ListTables, and
UpdateTable (which does not support renaming). This script performs the
copy step of the standard workaround: scan the source table fully, write
every item to a pre-created destination table via batch_writer(), then
verify item counts match.

Usage:
    python migrate_dynamodb_table_copy.py --source pmi-agentic-ai-requests-dev --dest pmi-agentic-ai-requests
    python migrate_dynamodb_table_copy.py --source pmi-agentic-ai-hitl-dev --dest pmi-agentic-ai-hitl

Requires the destination table to already exist with a schema compatible
with the source data (same/compatible key schema at minimum).

Safe to re-run: batch_writer() put_item calls are idempotent overwrites
keyed on the table's primary key, so re-running after a partial failure
just re-writes the same items again.
"""

import argparse
import sys

import boto3


def copy_table(source_table_name: str, dest_table_name: str, profile: str, region: str) -> None:
    session = boto3.Session(profile_name=profile) if profile else boto3.Session()
    dynamodb = session.resource("dynamodb", region_name=region)

    source_table = dynamodb.Table(source_table_name)
    dest_table = dynamodb.Table(dest_table_name)

    print(f"Scanning {source_table_name} ...")

    items_copied = 0
    scan_kwargs = {}

    with dest_table.batch_writer() as batch:
        while True:
            response = source_table.scan(**scan_kwargs)
            items = response.get("Items", [])

            for item in items:
                batch.put_item(Item=item)
                items_copied += 1

            print(f"  ... copied {items_copied} items so far")

            if "LastEvaluatedKey" not in response:
                break
            scan_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]

    print(f"Done. Copied {items_copied} items from {source_table_name} to {dest_table_name}.")

    # Sanity check: compare item counts. Note DescribeTable's ItemCount is
    # an eventually-consistent, periodically-updated estimate (refreshed
    # roughly every 6 hours by AWS), so immediately after a copy it may
    # still show the old/stale count for the destination table. A live
    # scan-based count (below) is the reliable check right after copying.
    source_count = _live_count(source_table)
    dest_count = _live_count(dest_table)

    print(f"Live item count -- source ({source_table_name}): {source_count}")
    print(f"Live item count -- dest   ({dest_table_name}): {dest_count}")

    if source_count != dest_count:
        print("MISMATCH -- destination item count does not match source. Investigate before proceeding.")
        sys.exit(1)
    else:
        print("Item counts match. Copy verified.")


def _live_count(table) -> int:
    """Full scan-based count (Select=COUNT avoids transferring item data)."""
    count = 0
    scan_kwargs = {"Select": "COUNT"}
    while True:
        response = table.scan(**scan_kwargs)
        count += response.get("Count", 0)
        if "LastEvaluatedKey" not in response:
            break
        scan_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
    return count


def main():
    parser = argparse.ArgumentParser(description="Copy all items from one DynamoDB table to another (pre-created) table.")
    parser.add_argument("--source", required=True, help="Source table name to scan from")
    parser.add_argument("--dest", required=True, help="Destination table name to write to (must already exist)")
    parser.add_argument("--profile", default="pmi-dev-developer", help="AWS CLI profile name (default: pmi-dev-developer)")
    parser.add_argument("--region", default="eu-west-1", help="AWS region (default: eu-west-1)")
    args = parser.parse_args()

    copy_table(args.source, args.dest, args.profile, args.region)


if __name__ == "__main__":
    main()
