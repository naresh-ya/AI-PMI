<#
.SYNOPSIS
    Fast deploy for ingestion Lambdas — NO Terraform required.
#>
param(
    [ValidateSet("ingestion", "kb", "both")]
    [string]$Lambda = "both",
    [string]$Region = "eu-west-1"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ROOT = Split-Path -Parent $PSScriptRoot
$BUILD = "$ROOT\.build"
$INGESTION_SRC = "$ROOT\ingestion"
$KB_SRC = "$ROOT\knowledge_base"

if (-not (Test-Path $BUILD)) { New-Item -ItemType Directory -Path $BUILD | Out-Null }

function Deploy-Lambda ([string]$FunctionName, [string]$SourceDir, [string]$ZipName) {
    $stagingDir = "$BUILD\$ZipName-staging"
    if (Test-Path $stagingDir) { Remove-Item $stagingDir -Recurse -Force }
    New-Item -ItemType Directory -Path $stagingDir | Out-Null
    
    Copy-Item -Path "$SourceDir\*" -Destination $stagingDir -Recurse -Force
    
    if (Test-Path "$SourceDir\requirements.txt") {
        Write-Host "`n[*] Installing dependencies for $FunctionName..." -ForegroundColor Yellow
        if ($FunctionName -eq "pmi-kb-builder") {
            # Only install the pure Python dependencies actually required by build_kb_from_s3.py
            # This avoids C++ compilation errors on Windows for heavy ML libraries like PyMuPDF
            pip install PyPDF2 extract-msg langdetect -t $stagingDir --upgrade --quiet
        } else {
            pip install -r "$SourceDir\requirements.txt" -t $stagingDir --upgrade --quiet
        }
    }
    
    $zipPath = "$BUILD\$ZipName.zip"
    Write-Host "`n[*] Zipping $FunctionName..." -ForegroundColor Yellow
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    Compress-Archive -Path "$stagingDir\*" -DestinationPath $zipPath -CompressionLevel Fastest
    
    Write-Host "[*] Deploying to AWS Lambda: $FunctionName ..." -ForegroundColor Yellow
    $json = aws lambda update-function-code --function-name $FunctionName --zip-file "fileb://$zipPath" --region $Region --output json
    $result = $json | ConvertFrom-Json

    if ($LASTEXITCODE -ne 0) {
        Write-Host "[X] Deploy FAILED for $FunctionName" -ForegroundColor Red
        exit 1
    }

    Write-Host "[+] Deployed: $FunctionName" -ForegroundColor Green
    aws lambda wait function-updated --function-name $FunctionName --region $Region
    Write-Host "[+] Lambda is Active and ready." -ForegroundColor Green
}

switch ($Lambda) {
    "ingestion" { Deploy-Lambda "pmi-sharepoint-ingestion" $INGESTION_SRC "sharepoint_ingestion" }
    "kb"        { Deploy-Lambda "pmi-kb-builder" $KB_SRC "kb_builder" }
    "both"      {
        Deploy-Lambda "pmi-sharepoint-ingestion" $INGESTION_SRC "sharepoint_ingestion"
        Deploy-Lambda "pmi-kb-builder" $KB_SRC "kb_builder"
    }
}
