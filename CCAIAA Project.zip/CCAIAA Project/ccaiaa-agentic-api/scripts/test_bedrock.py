import boto3
import json
import logging

logging.basicConfig(level=logging.INFO)

def test_model(model_id, endpoint_url=None):
    try:
        print(f"Testing {model_id} with endpoint {endpoint_url}...")
        client_kwargs = {'region_name': 'eu-west-1'}
        if endpoint_url:
            client_kwargs['endpoint_url'] = endpoint_url
            
        client = boto3.client('bedrock-runtime', **client_kwargs)
        body = json.dumps({"inputText": "test"})
        client.invoke_model(modelId=model_id, body=body)
        print(f"SUCCESS: {model_id}")
    except Exception as e:
        print(f"FAILED {model_id}: {type(e).__name__} - {e}")

models = ['amazon.titan-embed-text-v1', 'amazon.titan-embed-text-v2:0']
for m in models:
    test_model(m)
    test_model(m, endpoint_url='https://litellm.aiplat-dev.aws.private-pmideep.biz')
