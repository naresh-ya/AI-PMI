$ErrorActionPreference = "Stop"

function Deploy-Lambda {
    param($Name, $Folder, [string[]]$Includes)
    
    Write-Host "Zipping $Name..."
    $StagingDir = "$env:TEMP\lambda_staging_$Name"
    $ZipPath = "$env:TEMP\$Name.zip"
    
    if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
    New-Item -ItemType Directory -Path $StagingDir | Out-Null
    
    # Copy handler
    if (Test-Path ".\$Folder\*.py") {
        Copy-Item -Path ".\$Folder\*.py" -Destination $StagingDir -Force
    }
    
    # Copy includes
    if ($null -ne $Includes) {
        foreach ($inc in $Includes) {
            if (Test-Path ".\$inc") {
                $Dest = Join-Path $StagingDir $inc
                New-Item -ItemType Directory -Path $Dest | Out-Null
                Copy-Item -Path ".\$inc\*" -Destination $Dest -Recurse -Force
            }
        }
    }
    
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force
    
    Write-Host "Updating AWS Lambda: $Name..."
    aws lambda update-function-code --function-name $Name --zip-file "fileb://$ZipPath" | Out-Null
    Write-Host "Done $Name"
}

Deploy-Lambda -Name "pmi-input-validator-client-demo1" -Folder "agents\input_validator"
Deploy-Lambda -Name "pmi-master-researcher-client-demo1" -Folder "agents\master_researcher" -Includes @("core", "knowledge_base")
Deploy-Lambda -Name "pmi-kb-searcher-client-demo1" -Folder "knowledge_base" -Includes @("core")

Write-Host "Fast deployment complete!"
