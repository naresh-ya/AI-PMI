$ErrorActionPreference = "Stop"

function Deploy-Lambda {
    param($Name, $Folder, [string[]]$Includes)
    
    Write-Host "Zipping $Name..."
    $StagingDir = "$env:TEMP\lambda_staging_$Name"
    $ZipPath = "$env:TEMP\$Name.zip"
    
    if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
    New-Item -ItemType Directory -Path $StagingDir | Out-Null
    
    # Copy handler and code
    if (Test-Path ".\$Folder\*.py") {
        Copy-Item -Path ".\$Folder\*.py" -Destination $StagingDir -Force
    }
    
    # Determine correct requirements file
    $ReqFile = ".\$Folder\requirements.txt"
    if ($Name -eq "pmi-kb-searcher-client-demo1") {
        $ReqFile = ".\$Folder\requirements-searcher.txt"
    }
    
    # Install requirements if they exist
    if (Test-Path $ReqFile) {
        Write-Host "Installing dependencies for $Name from $ReqFile..."
        # Use pip install -t to put dependencies directly into the staging directory
        pip install -r $ReqFile -t $StagingDir --quiet --platform manylinux2014_x86_64 --python-version 3.10 --only-binary=:all:
        
        # boto3 and botocore are large and already provided by the AWS Lambda runtime, so we can remove them to save space
        if (Test-Path "$StagingDir\boto3") { Remove-Item "$StagingDir\boto*" -Recurse -Force -ErrorAction SilentlyContinue }
    }
    
    # Copy includes (core, knowledge_base)
    if ($null -ne $Includes) {
        foreach ($inc in $Includes) {
            if (Test-Path ".\$inc") {
                $Dest = Join-Path $StagingDir $inc
                New-Item -ItemType Directory -Path $Dest | Out-Null
                Copy-Item -Path ".\$inc\*" -Destination $Dest -Recurse -Force
            }
        }
    }
    
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force
    
    Write-Host "Updating AWS Lambda: $Name..."
    aws lambda update-function-code --function-name $Name --zip-file "fileb://$ZipPath" | Out-Null
    Write-Host "Done $Name"
}

Deploy-Lambda -Name "pmi-input-validator-client-demo1" -Folder "agents\input_validator"
Deploy-Lambda -Name "pmi-master-researcher-client-demo1" -Folder "agents\master_researcher" -Includes @("core", "knowledge_base")
Deploy-Lambda -Name "pmi-kb-searcher-client-demo1" -Folder "knowledge_base" -Includes @("core")

Write-Host "Deployment with dependencies complete!"
