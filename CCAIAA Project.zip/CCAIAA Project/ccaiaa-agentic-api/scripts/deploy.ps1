# PMI Agentic AI Backend Deployment Script

Write-Host "Starting PMI Agentic AI Backend Deployment..." -ForegroundColor Green

# Check prerequisites
Write-Host "Checking prerequisites..." -ForegroundColor Yellow

# Check Python
try {
    $pythonVersion = python --version 2>$null
    if ($pythonVersion -match "3\.([0-9]+)\.") {
        $minorVersion = [int]$Matches[1]
        if ($minorVersion -lt 10) {
            Write-Host "ERROR: Python 3.10 or higher required. Found: $pythonVersion" -ForegroundColor Red
            exit 1
        }
        Write-Host "✓ Python version: $pythonVersion" -ForegroundColor Green
    }
} catch {
    Write-Host "ERROR: Python not found. Please install Python 3.10+" -ForegroundColor Red
    exit 1
}

# Check Node.js for CDK
try {
    $nodeVersion = node --version 2>$null
    Write-Host "✓ Node.js version: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Node.js not found. Please install Node.js" -ForegroundColor Red
    exit 1
}

# Check AWS CLI
try {
    $awsVersion = aws --version 2>$null
    Write-Host "✓ AWS CLI: $awsVersion" -ForegroundColor Green
} catch {
    Write-Host "WARNING: AWS CLI not found. Please configure AWS credentials" -ForegroundColor Yellow
}

# Install CDK if not present
try {
    $cdkVersion = cdk --version 2>$null
    Write-Host "✓ CDK version: $cdkVersion" -ForegroundColor Green
} catch {
    Write-Host "Installing AWS CDK..." -ForegroundColor Yellow
    npm install -g aws-cdk
}

# Create and activate virtual environment
Write-Host "Setting up Python virtual environment..." -ForegroundColor Yellow
if (!(Test-Path ".venv")) {
    python -m venv .venv
}

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Install Python dependencies
Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
pip install -r requirements.txt

# Bootstrap CDK (if needed)
Write-Host "Checking CDK bootstrap status..." -ForegroundColor Yellow
try {
    cdk bootstrap
    Write-Host "✓ CDK bootstrap completed" -ForegroundColor Green
} catch {
    Write-Host "ERROR: CDK bootstrap failed. Please check AWS credentials" -ForegroundColor Red
    exit 1
}

# Synthesize CDK app
Write-Host "Synthesizing CDK application..." -ForegroundColor Yellow
cdk synth

# Deploy the stack
Write-Host "Deploying PMI Agentic AI stack..." -ForegroundColor Yellow
Write-Host "This may take 10-15 minutes..." -ForegroundColor Cyan

cdk deploy --require-approval never

if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Deployment completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Getting API Gateway URL..." -ForegroundColor Yellow
    
    # Get the API Gateway URL from CDK outputs
    $outputs = cdk list --json | ConvertFrom-Json
    Write-Host "Check AWS Console for API Gateway URL in CloudFormation outputs" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "1. Configure Bedrock model access in AWS Console" -ForegroundColor White
    Write-Host "2. Test API endpoints using the provided URL" -ForegroundColor White
    Write-Host "3. Update frontend configuration with the API URL" -ForegroundColor White
} else {
    Write-Host "ERROR: Deployment failed!" -ForegroundColor Red
    exit 1
}
