import json
import subprocess
import os
import sys

def run_command(command):
    """Executes a shell command and returns the output."""
    print(f"\nRunning Command:\n> {command}")
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"ERROR executing command: {result.stderr}")
        sys.exit(1)
    print("Command executed successfully.\n")

def main():
    # Define file paths
    input_scenario = "test_payloads/new_request_submissions/1_letters_scenario.json"
    
    validator_payload_file = "validator_payload.json"
    validator_out_file = "validator_out.json"
    
    researcher_out_file = "researcher_out.json"
    
    drafter_payload_file = "drafter_payload.json"
    drafter_out_file = "drafter_out.json"

    print(f"=== Starting E2E Lambda Invocation Demo ===")
    print(f"Using Scenario: {input_scenario}")

    # ==========================================
    # 1. INPUT VALIDATOR
    # ==========================================
    print("\n--- STEP 1: Input Validator ---")
    with open(input_scenario, "r", encoding="utf-8") as f:
        raw_data = json.load(f)

    # Wrap the payload
    validator_payload = {
        "request_id": "req_CLI_demo_123",
        "request_data": raw_data
    }
    with open(validator_payload_file, "w", encoding="utf-8") as f:
        json.dump(validator_payload, f, indent=2)

    # Invoke AWS CLI
    validator_cmd = (
        f"aws lambda invoke "
        f"--function-name pmi-input-validator "
        f"--payload fileb://{validator_payload_file} "
        f"--cli-binary-format raw-in-base64-out "
        f"{validator_out_file}"
    )
    run_command(validator_cmd)

    with open(validator_out_file, "r", encoding="utf-8") as f:
        validator_result = json.load(f)
        print(f"Validator Output Status: {validator_result.get('status')}")

    # ==========================================
    # 2. MASTER RESEARCHER
    # ==========================================
    print("\n--- STEP 2: Master Researcher ---")
    
    # The researcher payload is just the validator output
    researcher_cmd = (
        f"aws lambda invoke "
        f"--function-name pmi-master-researcher "
        f"--payload fileb://{validator_out_file} "
        f"--cli-binary-format raw-in-base64-out "
        f"{researcher_out_file}"
    )
    run_command(researcher_cmd)

    with open(researcher_out_file, "r", encoding="utf-8") as f:
        research_result = json.load(f)
        print(f"Researcher Output Status: {research_result.get('status')}")

    # ==========================================
    # 3. MASTER DRAFTER
    # ==========================================
    print("\n--- STEP 3: Master Drafter ---")
    
    # Drafter needs both validation_result and research_result
    drafter_payload = {
        "request_id": validator_result.get("request_id"),
        "validation_result": validator_result,
        "research_result": research_result
    }
    with open(drafter_payload_file, "w", encoding="utf-8") as f:
        json.dump(drafter_payload, f, indent=2)

    drafter_cmd = (
        f"aws lambda invoke "
        f"--function-name pmi-master-drafter "
        f"--payload fileb://{drafter_payload_file} "
        f"--cli-binary-format raw-in-base64-out "
        f"{drafter_out_file}"
    )
    run_command(drafter_cmd)

    with open(drafter_out_file, "r", encoding="utf-8") as f:
        drafter_result = json.load(f)
        print(f"Drafter Output Status: {drafter_result.get('status')}")

    print("\n=== Demo Complete! ===")
    print("Check the following output files for the exact JSON responses:")
    print(f"- {validator_out_file}")
    print(f"- {researcher_out_file}")
    print(f"- {drafter_out_file}")

if __name__ == "__main__":
    main()
