<#
.SYNOPSIS
    Fast deploy script for kb_searcher Lambda
#>
param(
    [string]$LambdaName = "pmi-kb-searcher-client-demo1",
    [string]$Region = "eu-west-1"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ROOT = Split-Path -Parent $PSScriptRoot
$BUILD = "$ROOT\.build"
$STAGING_DIR = "$BUILD\kb-searcher-staging"
$ZIP_PATH = "$BUILD\kb_searcher.zip"

Write-Host "[*] Setting up staging directory..." -ForegroundColor Yellow
if (-not (Test-Path $BUILD)) { New-Item -ItemType Directory -Path $BUILD | Out-Null }
if (Test-Path $STAGING_DIR) { Remove-Item $STAGING_DIR -Recurse -Force }
New-Item -ItemType Directory -Path $STAGING_DIR | Out-Null

Write-Host "[*] Copying files..." -ForegroundColor Yellow
Copy-Item "$ROOT\knowledge_base\kb_searcher.py" -Destination $STAGING_DIR -Force
Copy-Item "$ROOT\core" -Destination "$STAGING_DIR\core" -Recurse -Force

Write-Host "[*] Zipping payload..." -ForegroundColor Yellow
if (Test-Path $ZIP_PATH) { Remove-Item $ZIP_PATH -Force }
Compress-Archive -Path "$STAGING_DIR\*" -DestinationPath $ZIP_PATH -CompressionLevel Fastest

Write-Host "[*] Deploying to AWS Lambda: $LambdaName ..." -ForegroundColor Yellow
$json = aws lambda update-function-code --function-name $LambdaName --zip-file "fileb://$ZIP_PATH" --region $Region --output json
$result = $json | ConvertFrom-Json

if ($LASTEXITCODE -ne 0) {
    Write-Host "[X] Deploy FAILED for $LambdaName" -ForegroundColor Red
    exit 1
}

Write-Host "[+] Waiting for update to complete..." -ForegroundColor Yellow
aws lambda wait function-updated --function-name $LambdaName --region $Region

Write-Host "[+] Deployed successfully: $LambdaName" -ForegroundColor Green
