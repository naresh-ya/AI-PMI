"""
Test script: Verify Claude Haiku model works as a document classifier/parser.

Tests:
1. Confirm LLM gateway is reachable
2. Classify a sample document text into Level 1 + Level 2 taxonomy
3. Verify multi-value classification (document belongs to multiple themes)
4. Verify graceful handling of ambiguous content

Uses the same LiteLLM gateway as the researcher (AWS_BEARER_TOKEN_BEDROCK).

Usage:
    python scripts/test_llm_classifier.py
"""

import json
import os
import ssl
import sys
import time
import urllib.request
import urllib.error

# Load .env
dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
if os.path.exists(dotenv_path):
    for line in open(dotenv_path):
        if line.strip() and not line.startswith('#') and '=' in line:
            k, v = line.strip().split('=', 1)
            os.environ[k.strip()] = v.strip().strip('"')

LITELLM_KEY = os.environ.get('AWS_BEARER_TOKEN_BEDROCK', '')
LITELLM_URL = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions'
MODEL = 'anthropic.claude-3-haiku-20240307-v1:0'

SEP = "=" * 70

# ── Classification taxonomy (injected into the prompt) ──────────────────────────
TAXONOMY = """
LEVEL 1 OPTIONS (select one or more):
- Smoke-free products: Content related to PMI's reduced-risk and smoke-free portfolio (IQOS, HTP, e-vapor). Product science, benefits vs cigarettes, regulatory positioning, commercial narratives.
- Combustible cigarettes: Materials related to traditional cigarette products, market, regulation, taxation, pricing, public positioning. Harm discussions, transition narratives.
- Corporate Equity: Content shaping PMI's corporate reputation, purpose, transformation story, stakeholder perception. Leadership messaging, ESG positioning, company narrative.
- Others: Content not clearly in product-specific or corporate reputation categories. Cross-cutting topics or emerging areas.

LEVEL 2 OPTIONS (select one or more):
- Regulatory: Laws, policies, compliance, government interactions. Submissions, policy advocacy, regulatory frameworks.
- Fiscal and Taxes: Taxation, pricing regulations, excise duties, economic arguments. Affordability, switching incentives, illicit trade economics.
- Illicit Trade: Illegal tobacco markets, counterfeit products, smuggling, enforcement. Economic, regulatory, societal impact.
- Scientific: Research, clinical evidence, scientific validation. Reduced-risk claims, health impact comparisons.
- Youth Access Prevention: Policies and programs preventing underage access. Compliance measures, enforcement, responsible marketing.
- Sustainability: ESG initiatives, supply chain, climate impact, social responsibility. Reporting, stakeholder commitments.
- Others: Niche or uncategorized content. Partnerships, internal processes, cross-functional initiatives.
"""


def classify_document(text_preview: str, filename: str) -> dict:
    """Call Haiku to classify a document into Level 1 + Level 2 taxonomy."""
    
    prompt = f"""You are a document classifier for Philip Morris International's knowledge base.

Classify the following document into the taxonomy below. A document CAN belong to multiple categories at each level.

{TAXONOMY}

DOCUMENT FILENAME: {filename}
DOCUMENT CONTENT (first 3000 chars):
{text_preview[:3000]}

RULES:
- Select 1-3 values for Level 1 (usually 1, max 3)
- Select 1-3 values for Level 2 (usually 1-2, max 3)
- Use EXACT category names from the options above
- If unsure, include "Others" as one of the values
- Return ONLY a JSON object, no explanation

OUTPUT FORMAT:
{{"level_1": ["category1", "category2"], "level_2": ["category1", "category2"]}}
"""

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    data = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 200,
    }
    headers = {
        "Authorization": f"Bearer {LITELLM_KEY}",
        "Content-Type": "application/json",
    }
    req = urllib.request.Request(
        LITELLM_URL,
        data=json.dumps(data).encode('utf-8'),
        headers=headers,
        method='POST',
    )
    with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
        res = json.loads(resp.read().decode('utf-8'))
        raw = res['choices'][0]['message']['content'].strip()
        if raw.startswith('```'):
            raw = '\n'.join(raw.split('\n')[1:-1]).strip()
        return json.loads(raw)


# ── Test Documents ──────────────────────────────────────────────────────────────

TEST_DOCS = [
    {
        "filename": "HTP_Policy_Brief_Thailand_2024.docx",
        "text": """
This policy brief outlines the regulatory landscape for heated tobacco products (HTPs) 
in Thailand. The Disease Control Department under the Ministry of Public Health currently 
maintains a ban on all electronic nicotine delivery systems and heated tobacco products. 
Independent scientific studies have confirmed that HTPs deliver nicotine with 90-95% fewer 
harmful chemicals compared to combustible cigarettes. The WHO FCTC Article 1(d) establishes 
the principle of harm reduction. PMI's IQOS has received FDA Modified Risk Tobacco Product 
(MRTP) authorization in the United States. This brief recommends a risk-proportionate 
regulatory framework that differentiates smoke-free products from combustible cigarettes.
""",
        "expected_level_1": ["Smoke-free products"],
        "expected_level_2": ["Regulatory", "Scientific"],
    },
    {
        "filename": "PMI_ESG_Report_2024.docx",
        "text": """
Philip Morris International's 2024 Environmental, Social, and Governance Report highlights 
the company's progress toward a smoke-free future. Key achievements include: reducing Scope 1 
and 2 emissions by 35% since 2019, achieving 100% renewable electricity in manufacturing, 
investing USD 16 billion in smoke-free R&D, and reaching 38% net revenue from smoke-free 
products. PMI's supply chain sustainability program has engaged over 350,000 tobacco farmers 
in responsible agricultural practices. The company aims to achieve carbon neutrality by 2040.
""",
        "expected_level_1": ["Corporate Equity"],
        "expected_level_2": ["Sustainability"],
    },
    {
        "filename": "India_Excise_Duty_Submission_CBIC_2025.docx",
        "text": """
Submission to the Central Board of Indirect Taxes and Customs regarding excise duty 
revision for tobacco products. The current GST rate of 28% plus compensation cess creates 
a significant price differential between legal and illicit cigarettes. This submission 
recommends a rationalized duty structure that reduces the incentive for illicit trade while 
maintaining government revenue. Data shows that 25% of cigarettes consumed in India are 
illicit, resulting in annual revenue loss of INR 13,000 crore. A risk-proportionate tax 
framework for smoke-free products would incentivize switching from combustible cigarettes.
""",
        "expected_level_1": ["Combustible cigarettes", "Smoke-free products"],
        "expected_level_2": ["Fiscal and Taxes", "Illicit Trade"],
    },
    {
        "filename": "Youth_Prevention_Program_ASEAN_2024.docx",
        "text": """
PMI's Youth Access Prevention (YAP) program across ASEAN markets. This document outlines 
the comprehensive measures implemented to prevent underage access to tobacco and nicotine 
products. Key components include: age verification technology at point of sale, retail 
compliance monitoring, partnership with local enforcement agencies, and educational programs 
in schools. In 2023, PMI conducted over 50,000 retail compliance checks across the region.
""",
        "expected_level_1": ["Smoke-free products", "Combustible cigarettes"],
        "expected_level_2": ["Youth Access Prevention"],
    },
]


# ── Run Tests ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(SEP)
    print("LLM Document Classifier — Haiku Parser Test")
    print(f"Model: {MODEL}")
    print(f"Gateway: {LITELLM_URL}")
    print(SEP)

    if not LITELLM_KEY:
        print("\n❌ AWS_BEARER_TOKEN_BEDROCK not set. Load .env or set it manually.")
        sys.exit(1)

    # Test 1: Gateway connectivity
    print(f"\n{SEP}")
    print("TEST 1: Gateway Connectivity — can we reach Haiku?")
    print(SEP)
    try:
        start = time.time()
        result = classify_document("This is a test document about tobacco regulation.", "test.docx")
        elapsed = round(time.time() - start, 1)
        print(f"  Response time: {elapsed}s")
        print(f"  Result: {json.dumps(result, indent=2)}")
        print(f"  ✅ PASS — Haiku is reachable and returns valid JSON")
    except Exception as e:
        print(f"  ❌ FAIL: {e}")
        sys.exit(1)

    # Test 2-5: Classify test documents
    print(f"\n{SEP}")
    print("TEST 2-5: Document Classification Quality")
    print(SEP)

    passed = 0
    total = len(TEST_DOCS)

    for i, doc in enumerate(TEST_DOCS, 1):
        print(f"\n  [{i}] {doc['filename']}")
        try:
            start = time.time()
            result = classify_document(doc['text'], doc['filename'])
            elapsed = round(time.time() - start, 1)

            level_1 = result.get('level_1', [])
            level_2 = result.get('level_2', [])

            print(f"      Time: {elapsed}s")
            print(f"      Level 1: {level_1}")
            print(f"      Level 2: {level_2}")
            print(f"      Expected L1: {doc['expected_level_1']}")
            print(f"      Expected L2: {doc['expected_level_2']}")

            # Check if at least one expected value matches
            l1_match = any(e in level_1 for e in doc['expected_level_1'])
            l2_match = any(e in level_2 for e in doc['expected_level_2'])

            if l1_match and l2_match:
                print(f"      ✅ PASS")
                passed += 1
            elif l1_match or l2_match:
                print(f"      ⚠️  PARTIAL — {'L1 match' if l1_match else 'L2 match'} only")
                passed += 0.5
            else:
                print(f"      ❌ MISS — classification doesn't match expected")

        except Exception as e:
            print(f"      ❌ ERROR: {e}")

    # Summary
    print(f"\n{SEP}")
    print("SUMMARY")
    print(SEP)
    print(f"  Classification accuracy: {passed}/{total} documents correctly classified")
    print(f"  Model: {MODEL}")
    
    if passed >= total * 0.75:
        print(f"\n  ✅ Haiku classifier is working well — ready to integrate into ingestion pipeline")
    else:
        print(f"\n  ⚠️  Classification quality is below threshold — consider using Sonnet or refining the prompt")
