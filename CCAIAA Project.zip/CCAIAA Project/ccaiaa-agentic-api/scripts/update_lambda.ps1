param (
    [string]$FunctionName = "pmi-input-validator",
    [string]$SourceDir = "agents\input_validator"
)

$ErrorActionPreference = "Stop"

Write-Host "Packaging source directory: $SourceDir" -ForegroundColor Yellow

$StagingDir = "$env:TEMP\lambda_staging_$FunctionName"
$ZipPath = "$env:TEMP\lambda_deploy_$FunctionName.zip"

if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }

New-Item -ItemType Directory -Path $StagingDir | Out-Null
Copy-Item -Path ".\$SourceDir\*" -Destination $StagingDir -Recurse -Force

# Rename descriptive handler files to handler.py to match AWS Lambda's configured entrypoint (handler.lambda_handler)
if ($SourceDir -eq "agents\input_validator") {
    Write-Host "Renaming handler_new_validator.py to handler.py..." -ForegroundColor Yellow
    Rename-Item -Path (Join-Path $StagingDir "handler_new_validator.py") -NewName "handler.py" -Force
}
elseif ($SourceDir -eq "agents\master_researcher") {
    Write-Host "Renaming handler_new_advanced.py to handler.py..." -ForegroundColor Yellow
    Rename-Item -Path (Join-Path $StagingDir "handler_new_advanced.py") -NewName "handler.py" -Force
}
elseif ($SourceDir -eq "agents\master_drafter") {
    Write-Host "Renaming handler_drafter_new.py to handler.py..." -ForegroundColor Yellow
    Rename-Item -Path (Join-Path $StagingDir "handler_drafter_new.py") -NewName "handler.py" -Force
}

if (Test-Path ".\$SourceDir\requirements.txt") {
    Write-Host "Installing dependencies..." -ForegroundColor Yellow
    pip install -r ".\$SourceDir\requirements.txt" -t $StagingDir --quiet
}

Write-Host "Zipping deployment package..." -ForegroundColor Yellow
Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force

Write-Host "Updating AWS Lambda function ($FunctionName) directly via AWS CLI..." -ForegroundColor Yellow
aws lambda update-function-code `
    --function-name $FunctionName `
    --zip-file fileb://$ZipPath `
    | Out-Null

if ($LASTEXITCODE -eq 0) {
    Write-Host "Successfully deployed new code to $FunctionName in AWS!" -ForegroundColor Green
    aws lambda wait function-updated --function-name $FunctionName
    Write-Host "Lambda is Active and ready." -ForegroundColor Green
} else {
    Write-Host "Failed to update $FunctionName. Check your AWS credentials." -ForegroundColor Red
}

# Cleanup
if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
