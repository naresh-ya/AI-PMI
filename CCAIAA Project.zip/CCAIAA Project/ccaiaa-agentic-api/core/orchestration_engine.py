"""
Orchestration Engine for PMI Agentic AI Platform

Handles workflow orchestration, agent transitions, feedback processing,
and Human-in-the-Loop decision integration.
"""

import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime
import boto3
from enum import Enum

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
stepfunctions = boto3.client('stepfunctions')
lambda_client = boto3.client('lambda')
dynamodb = boto3.resource('dynamodb')

class AgentDecision(Enum):
    APPROVE = "approve"
    REJECT = "reject"
    REVISE = "revise"
    ESCALATE = "escalate"

class WorkflowState(Enum):
    INPUT_VALIDATION = "input_validation"
    RESEARCH_STRATEGY = "research_strategy"
    RESEARCH_EXECUTION = "research_execution"
    DRAFT_OUTLINE = "draft_outline"
    DRAFT_CONTENT = "draft_content"
    FINAL_REVIEW = "final_review"
    COMPLETED = "completed"
    FAILED = "failed"

class OrchestrationEngine:
    """Manages workflow orchestration and agent transitions"""
    
    def __init__(self):
        self.requests_table = dynamodb.Table('pmi-agentic-ai-requests')
        self.hitl_table = dynamodb.Table('pmi-agentic-ai-hitl')
        
    def process_hitl_feedback(self, hitl_id: str, decision: AgentDecision, feedback: Dict[str, Any], reviewer_id: str) -> Dict[str, Any]:
        """
        Process human feedback and orchestrate next steps in workflow
        
        Args:
            hitl_id: Human-in-the-loop checkpoint ID
            decision: Human decision (approve/reject/revise)
            feedback: Detailed human feedback
            reviewer_id: ID of the human reviewer
            
        Returns:
            Orchestration result with next steps
        """
        
        try:
            logger.info(f"Processing HITL feedback for {hitl_id}: {decision.value}")
            
            # Get HITL checkpoint details
            hitl_response = self.hitl_table.get_item(Key={'hitl_id': hitl_id})
            if 'Item' not in hitl_response:
                raise Exception(f"HITL checkpoint {hitl_id} not found")
                
            hitl_record = hitl_response['Item']
            request_id = hitl_record['request_id']
            agent_name = hitl_record['agent_name']
            
            # Update HITL record with human decision
            self._update_hitl_record(hitl_id, decision, feedback, reviewer_id)
            
            # Process decision based on agent and decision type
            if decision == AgentDecision.APPROVE:
                return self._handle_approval(request_id, agent_name, hitl_record, feedback)
            elif decision == AgentDecision.REJECT:
                return self._handle_rejection(request_id, agent_name, hitl_record, feedback)
            elif decision == AgentDecision.REVISE:
                return self._handle_revision_request(request_id, agent_name, hitl_record, feedback)
            else:  # ESCALATE
                return self._handle_escalation(request_id, agent_name, hitl_record, feedback)
                
        except Exception as e:
            logger.error(f"Error processing HITL feedback: {str(e)}")
            return {
                "status": "error",
                "error": "Failed to process HITL feedback",
                "details": str(e)
            }
    
    def _handle_approval(self, request_id: str, agent_name: str, hitl_record: Dict[str, Any], feedback: Dict[str, Any]) -> Dict[str, Any]:
        """Handle human approval and continue to next agent"""
        
        logger.info(f"Processing approval for {agent_name} in request {request_id}")
        
        # Agent transition mapping
        next_agent_mapping = {
            "master_researcher": "master_drafter",
            "master_drafter": "master_reviewer", 
            "master_reviewer": "completed"
        }
        
        next_agent = next_agent_mapping.get(agent_name)
        
        if next_agent == "completed":
            return self._complete_workflow(request_id, feedback)
        else:
            return self._trigger_next_agent(request_id, next_agent, hitl_record, feedback)
    
    def _handle_rejection(self, request_id: str, agent_name: str, hitl_record: Dict[str, Any], feedback: Dict[str, Any]) -> Dict[str, Any]:
        """Handle human rejection - stop workflow or restart from beginning"""
        
        logger.info(f"Processing rejection for {agent_name} in request {request_id}")
        
        rejection_reason = feedback.get('rejection_reason', 'No reason provided')
        
        # Update request status to rejected
        self._update_request_status(request_id, f"rejected_at_{agent_name}", {
            'rejection_reason': rejection_reason,
            'rejected_by': feedback.get('reviewer_id', 'unknown'),
            'rejected_at': datetime.now().isoformat(),
            'agent_output': hitl_record.get('agent_output', {})
        })
        
        # Notify stakeholders of rejection
        self._notify_rejection(request_id, agent_name, feedback)
        
        return {
            "status": "rejected",
            "request_id": request_id,
            "agent_name": agent_name,
            "rejection_reason": rejection_reason,
            "workflow_status": "terminated"
        }
    
    def _handle_revision_request(self, request_id: str, agent_name: str, hitl_record: Dict[str, Any], feedback: Dict[str, Any]) -> Dict[str, Any]:
        """Handle human request for agent revision"""
        
        logger.info(f"Processing revision request for {agent_name} in request {request_id}")
        
        revision_instructions = feedback.get('revision_instructions', {})
        
        # Trigger agent revision with human feedback
        revision_result = self._trigger_agent_revision(request_id, agent_name, revision_instructions, hitl_record)
        
        return {
            "status": "revision_in_progress",
            "request_id": request_id,
            "agent_name": agent_name,
            "revision_instructions": revision_instructions,
            "revision_result": revision_result
        }
    
    def _handle_escalation(self, request_id: str, agent_name: str, hitl_record: Dict[str, Any], feedback: Dict[str, Any]) -> Dict[str, Any]:
        """Handle escalation to senior reviewers"""
        
        logger.info(f"Processing escalation for {agent_name} in request {request_id}")
        
        escalation_reason = feedback.get('escalation_reason', 'Complex decision required')
        
        # Create new HITL checkpoint with senior reviewers
        from core.hitl_manager import HITLManager, InterventionType
        hitl_manager = HITLManager()
        
        senior_reviewers = self._get_senior_reviewers(agent_name)
        
        escalation_hitl_id = hitl_manager.create_hitl_checkpoint(
            request_id=request_id,
            agent_name=f"{agent_name}_escalated",
            intervention_type=InterventionType.ESCALATION,
            agent_output=hitl_record.get('agent_output', {}),
            human_reviewers=senior_reviewers,
            priority="urgent"
        )
        
        return {
            "status": "escalated",
            "request_id": request_id,
            "original_agent": agent_name,
            "escalation_hitl_id": escalation_hitl_id,
            "escalation_reason": escalation_reason,
            "senior_reviewers": senior_reviewers
        }
    
    def _trigger_next_agent(self, request_id: str, next_agent: str, previous_hitl: Dict[str, Any], human_feedback: Dict[str, Any]) -> Dict[str, Any]:
        """Trigger the next agent in the workflow with human feedback incorporated"""
        
        logger.info(f"Triggering next agent {next_agent} for request {request_id}")
        
        # Get current request data
        request_response = self.requests_table.get_item(Key={'request_id': request_id})
        request_data = request_response.get('Item', {})
        
        # Prepare agent input with human feedback
        agent_input = {
            "request_id": request_id,
            "request_data": request_data.get('original_request', {}),
            "previous_agent_output": previous_hitl.get('agent_output', {}),
            "human_feedback": human_feedback,
            "workflow_context": {
                "previous_agent": previous_hitl.get('agent_name'),
                "approval_history": self._get_approval_history(request_id),
                "processing_notes": request_data.get('processing_notes', {})
            }
        }
        
        # Invoke next agent Lambda function
        lambda_function_name = f"pmi-agentic-ai-{next_agent.replace('_', '-')}"
        
        try:
            response = lambda_client.invoke(
                FunctionName=lambda_function_name,
                InvocationType='Event',  # Asynchronous invocation
                Payload=json.dumps(agent_input)
            )
            
            # Update request status
            self._update_request_status(request_id, f"processing_{next_agent}", {
                'current_agent': next_agent,
                'triggered_at': datetime.now().isoformat(),
                'human_feedback_incorporated': True
            })
            
            return {
                "status": "next_agent_triggered",
                "request_id": request_id,
                "next_agent": next_agent,
                "lambda_response": response.get('StatusCode'),
                "workflow_status": "continuing"
            }
            
        except Exception as e:
            logger.error(f"Error triggering next agent {next_agent}: {str(e)}")
            return {
                "status": "error",
                "error": f"Failed to trigger {next_agent}",
                "details": str(e)
            }
    
    def _trigger_agent_revision(self, request_id: str, agent_name: str, revision_instructions: Dict[str, Any], hitl_record: Dict[str, Any]) -> Dict[str, Any]:
        """Trigger agent to revise its output based on human feedback"""
        
        logger.info(f"Triggering revision for agent {agent_name} in request {request_id}")
        
        # Prepare revision input
        revision_input = {
            "request_id": request_id,
            "execution_mode": "revision",
            "original_output": hitl_record.get('agent_output', {}),
            "revision_instructions": revision_instructions,
            "human_feedback": revision_instructions,
            "revision_attempt": hitl_record.get('revision_attempt', 0) + 1
        }
        
        # Invoke agent Lambda function for revision
        lambda_function_name = f"pmi-agentic-ai-{agent_name.replace('_', '-')}"
        
        try:
            response = lambda_client.invoke(
                FunctionName=lambda_function_name,
                InvocationType='Event',
                Payload=json.dumps(revision_input)
            )
            
            # Update request status
            self._update_request_status(request_id, f"revising_{agent_name}", {
                'revision_in_progress': True,
                'revision_attempt': revision_input['revision_attempt'],
                'revision_triggered_at': datetime.now().isoformat()
            })
            
            return {
                "status": "revision_triggered",
                "agent_name": agent_name,
                "revision_attempt": revision_input['revision_attempt'],
                "lambda_response": response.get('StatusCode')
            }
            
        except Exception as e:
            logger.error(f"Error triggering agent revision: {str(e)}")
            return {
                "status": "error",
                "error": "Failed to trigger agent revision",
                "details": str(e)
            }
    
    def _complete_workflow(self, request_id: str, final_feedback: Dict[str, Any]) -> Dict[str, Any]:
        """Complete the workflow after final approval"""
        
        logger.info(f"Completing workflow for request {request_id}")
        
        # Update request status to completed
        self._update_request_status(request_id, "completed", {
            'completed_at': datetime.now().isoformat(),
            'final_approval_by': final_feedback.get('reviewer_id', 'unknown'),
            'final_quality_score': final_feedback.get('quality_score', 95),
            'workflow_duration': self._calculate_workflow_duration(request_id)
        })
        
        # Generate final deliverables
        deliverables = self._generate_final_deliverables(request_id)
        
        # Notify stakeholders of completion
        self._notify_completion(request_id, deliverables)
        
        return {
            "status": "workflow_completed",
            "request_id": request_id,
            "deliverables": deliverables,
            "completion_time": datetime.now().isoformat()
        }
    
    def _update_hitl_record(self, hitl_id: str, decision: AgentDecision, feedback: Dict[str, Any], reviewer_id: str):
        """Update HITL record with human decision"""
        
        self.hitl_table.update_item(
            Key={'hitl_id': hitl_id},
            UpdateExpression="""
                SET #status = :status,
                    decision = :decision,
                    human_feedback = :feedback,
                    completed_at = :completed_at,
                    completed_by = :completed_by
            """,
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':status': 'completed',
                ':decision': decision.value,
                ':feedback': feedback,
                ':completed_at': datetime.now().isoformat(),
                ':completed_by': reviewer_id
            }
        )
    
    def _update_request_status(self, request_id: str, status: str, metadata: Dict[str, Any]):
        """Update request status in DynamoDB"""
        
        self.requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression='SET #status = :status, workflow_metadata = :metadata, updated_at = :updated_at',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':status': status,
                ':metadata': metadata,
                ':updated_at': datetime.now().isoformat()
            }
        )
    
    def _get_approval_history(self, request_id: str) -> list:
        """Get history of all approvals for this request"""
        
        response = self.hitl_table.scan(
            FilterExpression='request_id = :request_id AND #status = :status',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':request_id': request_id,
                ':status': 'completed'
            }
        )
        
        return response.get('Items', [])
    
    def _get_senior_reviewers(self, agent_name: str) -> list:
        """Get senior reviewers for escalation"""
        
        senior_reviewers = {
            "master_researcher": ["research.director@pmi.com", "head.regulatory@pmi.com"],
            "master_drafter": ["content.director@pmi.com", "senior.legal@pmi.com"],
            "master_reviewer": ["chief.compliance@pmi.com", "executive.director@pmi.com"]
        }
        
        return senior_reviewers.get(agent_name, ["senior.management@pmi.com"])
    
    def _calculate_workflow_duration(self, request_id: str) -> Dict[str, Any]:
        """Calculate total workflow duration and agent timings"""
        
        # Get request creation time
        request_response = self.requests_table.get_item(Key={'request_id': request_id})
        request_data = request_response.get('Item', {})
        
        created_at = request_data.get('created_at')
        if created_at:
            start_time = datetime.fromisoformat(created_at)
            end_time = datetime.now()
            total_duration = (end_time - start_time).total_seconds() / 3600  # hours
            
            return {
                "total_hours": round(total_duration, 2),
                "start_time": created_at,
                "end_time": end_time.isoformat()
            }
        
        return {"total_hours": 0}
    
    def _generate_final_deliverables(self, request_id: str) -> Dict[str, Any]:
        """Generate final deliverables and URLs"""
        
        # This would generate final document URLs, summaries, etc.
        return {
            "document_url": f"s3://documents/{request_id}/final_document.docx",
            "research_summary_url": f"s3://documents/{request_id}/research_summary.pdf",
            "compliance_report_url": f"s3://documents/{request_id}/compliance_report.pdf"
        }
    
    def _notify_completion(self, request_id: str, deliverables: Dict[str, Any]):
        """Notify stakeholders of workflow completion"""
        
        # Send notifications via SNS, email, etc.
        logger.info(f"Workflow completed for request {request_id}, deliverables: {deliverables}")
    
    def _notify_rejection(self, request_id: str, agent_name: str, feedback: Dict[str, Any]):
        """Notify stakeholders of workflow rejection"""
        
        logger.info(f"Workflow rejected at {agent_name} for request {request_id}")


# Lambda handler for orchestration
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for orchestration engine
    
    Handles HITL feedback processing and workflow orchestration
    """
    
    try:
        orchestrator = OrchestrationEngine()
        
        # Extract event details
        hitl_id = event.get('hitl_id')
        decision = AgentDecision(event.get('decision'))
        feedback = event.get('feedback', {})
        reviewer_id = event.get('reviewer_id')
        
        # Process HITL feedback and orchestrate next steps
        result = orchestrator.process_hitl_feedback(hitl_id, decision, feedback, reviewer_id)
        
        return result
        
    except Exception as e:
        logger.error(f"Error in orchestration engine: {str(e)}")
        return {
            "status": "error",
            "error": "Orchestration failed",
            "details": str(e)
        }
