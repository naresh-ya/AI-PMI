"""
Knowledge Base Integration for PMI Agentic AI Platform

Retrieves from the PMI Bedrock Knowledge Base(s) (OpenSearch Serverless) for
semantic search, entirely through the LiteLLM Gateway.

Phase 2 implementation:
- Primary path: LiteLLM Gateway KB retrieve pass-through endpoint (KB_USE_LITELLM_GATEWAY=true).
- Fallback path: direct AWS Bedrock retrieve API (KB_USE_LITELLM_GATEWAY=false).
- HYBRID retrieval with automatic semantic fallback.

Phase 3 implementation (dual-KB + rerank):
- Optional parallel query of the English (Titan) KB and the Multilingual
  (Cohere embed-multilingual-v3) KB (KB_MULTILINGUAL_ENABLED=true), so a
  single query returns the best matches across BOTH corpora regardless of
  which language the source documents are in.
- Optional inline Cohere rerank (KB_RERANKER_ENABLED=true) of the merged
  candidate chunks via the LiteLLM Gateway /rerank endpoint. Because Titan
  and Cohere embeddings are not on a comparable similarity scale, rerank is
  what lets us safely merge results from both KBs and pick the best chunks
  on one comparable relevance scale, instead of guessing from raw scores.

Every embedding, retrieval, and reranking call in this module goes through
the LiteLLM Gateway — no direct Bedrock/Titan/Cohere SDK calls on the primary
path. The Bedrock KB (behind the gateway) handles:
- Document chunking (automatic)
- Embedding generation (Titan Embed / Cohere embed-multilingual-v3)
- Vector indexing (OpenSearch Serverless)
- Semantic retrieval with metadata filtering
"""

import json
import logging
import os
import ssl
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Any, List, Optional

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def _get_bool_env(name: str, default: bool) -> bool:
    """Parse a boolean environment variable."""
    value = os.environ.get(name)
    if value is None:
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


# ── English KB (Titan embeddings) — default/primary ─────────────────────────
KNOWLEDGE_BASE_ID = os.environ.get('BEDROCK_KB_ID', 'WQURRONWPQ')
REGION = os.environ.get('AWS_REGION', 'us-east-1')

# ── Multilingual KB (Cohere embed-multilingual-v3) — optional, parallel query ─
BEDROCK_KB_ID_MULTILINGUAL = os.environ.get('BEDROCK_KB_ID_MULTILINGUAL', 'LPMWAHDZS8')
KB_MULTILINGUAL_ENABLED = _get_bool_env('KB_MULTILINGUAL_ENABLED', False)

# ── LiteLLM Gateway KB retrieve (primary path) ───────────────────────────────
KB_USE_LITELLM_GATEWAY = _get_bool_env('KB_USE_LITELLM_GATEWAY', True)

LITELLM_KB_RETRIEVE_URL = os.environ.get(
    'LITELLM_KB_RETRIEVE_URL',
    'https://litellm.aiplat-dev.aws.private-pmideep.biz/bedrock/knowledgebases/{kb_id}/retrieve'
)

# Bearer token for the gateway — same source used for LiteLLM chat calls
# (see core/researcher_common.py: LITELLM_KEY = AWS_BEARER_TOKEN_BEDROCK).
LITELLM_TOKEN = (
    os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
    or os.environ.get('LITELLM_TOKEN')
    or os.environ.get('BEDROCK_BEARER_TOKEN')
    or ''
)

# Gateway request timeout (seconds)
_KB_TIMEOUT = int(os.environ.get('KB_LLM_TIMEOUT_SECONDS', '60'))

# ── Cohere rerank via LiteLLM Gateway /rerank (optional, inline on KB chunks) ─
# Same env var names as core/researcher_common.py so both modules share one
# source of truth for the rerank endpoint/model (no config drift).
KB_RERANKER_ENABLED = _get_bool_env('KB_RERANKER_ENABLED', False)
KB_RERANK_TOP_N = int(os.environ.get('KB_RERANK_TOP_N', '10'))
LITELLM_RERANK_URL = os.environ.get(
    'AWS_LITELLM_RERANK_ENDPOINT', 'https://litellm.aiplat-dev.aws.private-pmideep.biz/rerank'
)
LITELLM_RERANK_MODEL = os.environ.get(
    'AWS_LITELLM_RERANK_MODEL',
    'bedrock/arn:aws:bedrock:us-east-1::foundation-model/cohere.rerank-v3-5:0'
)

# Initialize Bedrock Agent Runtime client (used only on the boto3 fallback path)
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime', region_name=REGION)


def _litellm_kb_retrieve(
    kb_id: str,
    query: str,
    retrieval_config: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Retrieve from the Bedrock KB via the LiteLLM Gateway pass-through endpoint.

    The gateway mirrors Bedrock's response shape exactly, so callers do not need
    to change their result-processing logic. Falls back from HYBRID to SEMANTIC
    search on error, matching the boto3 path.

    Returns a Bedrock-shaped dict: {"retrievalResults": [...]}.
    """
    if not LITELLM_TOKEN:
        logger.error("[KB] LiteLLM token not configured — cannot call gateway KB retrieve")
        return {"retrievalResults": []}

    url = LITELLM_KB_RETRIEVE_URL.format(kb_id=kb_id)

    headers = {
        "Authorization": f"Bearer {LITELLM_TOKEN}",
        "Content-Type": "application/json",
    }

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    def _do_request(payload: Dict[str, Any]) -> Dict[str, Any]:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, context=ctx, timeout=_KB_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))

    payload = {
        "retrievalQuery": {"text": query},
        "retrievalConfiguration": retrieval_config,
    }

    try:
        result = _do_request(payload)
        logger.info(
            f"[KB] LiteLLM gateway retrieve | kb_id={kb_id} "
            f"| results={len(result.get('retrievalResults', []))}"
        )
        return result
    except (urllib.error.HTTPError, Exception) as first_error:
        # Retry with SEMANTIC if HYBRID failed
        search_type = retrieval_config.get(
            "vectorSearchConfiguration", {}
        ).get("overrideSearchType")
        if search_type == "HYBRID":
            logger.warning(
                f"[KB] LiteLLM gateway HYBRID retrieve failed ({first_error}); "
                f"retrying with SEMANTIC search"
            )
            fallback_config = json.loads(json.dumps(retrieval_config))
            fallback_config["vectorSearchConfiguration"].pop("overrideSearchType", None)
            try:
                result = _do_request({
                    "retrievalQuery": {"text": query},
                    "retrievalConfiguration": fallback_config,
                })
                logger.info(
                    f"[KB] LiteLLM gateway SEMANTIC fallback | kb_id={kb_id} "
                    f"| results={len(result.get('retrievalResults', []))}"
                )
                return result
            except Exception as fallback_error:
                logger.error(
                    f"[KB] LiteLLM gateway SEMANTIC fallback also failed: {fallback_error}"
                )
                return {"retrievalResults": []}
        logger.error(f"[KB] LiteLLM gateway retrieve failed: {first_error}")
        return {"retrievalResults": []}


def _litellm_rerank(
    query: str,
    documents: List[str],
    top_n: int,
) -> Optional[List[Dict[str, Any]]]:
    """
    Rerank KB chunks via the LiteLLM Gateway /rerank endpoint (Cohere Rerank v3.5).

    Used to merge results from the English (Titan) and Multilingual (Cohere)
    KBs onto one comparable relevance scale — raw Titan vs. Cohere embedding
    similarity scores are NOT directly comparable, but a single cross-encoder
    rerank pass scores both sets of chunks consistently.

    Non-fatal: returns None on any error so the caller keeps the original
    (embedding-similarity-ordered) results rather than failing the request.
    """
    if not documents:
        return None
    if not LITELLM_TOKEN:
        logger.warning("[KB] Rerank skipped — LiteLLM token not configured")
        return None

    try:
        payload = {
            "model": LITELLM_RERANK_MODEL,
            "query": query[:2000],
            "documents": documents,
            "top_n": min(top_n, len(documents)),
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_TOKEN}",
            "Content-Type": "application/json",
        }
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(
            LITELLM_RERANK_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(req, context=ctx, timeout=_KB_TIMEOUT) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        results = result.get("results", []) or []
        if not results:
            logger.warning("[KB] RERANK | empty results; keeping original order")
            return None

        logger.info(
            f"[KB] RERANK | cohere.rerank-v3-5 | scored={len(documents)} docs "
            f"| returned={len(results)} | top_score="
            f"{results[0].get('relevance_score', results[0].get('relevanceScore', 0)):.4f}"
        )
        return results

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:300]
        logger.warning(f"[KB] RERANK | HTTP {e.code}: {body} — keeping original order")
        return None
    except Exception as e:
        logger.warning(f"[KB] RERANK | failed ({type(e).__name__}: {e}) — keeping original order")
        return None


def _transform_kb_results(raw_results: List[Dict[str, Any]], kb_source: str = "") -> List[Dict[str, Any]]:
    """
    Transform Bedrock-shaped retrievalResults into the flat dict shape the
    researcher expects. Shared by both the single-KB and dual-KB code paths so
    the mapping logic (score, title, metadata, sharepoint_url) lives in exactly
    one place.

    Args:
        raw_results: response['retrievalResults'] list (Bedrock-shaped, from
            either the LiteLLM gateway pass-through or direct boto3).
        kb_source:   tag identifying which KB this batch came from (for logging
            / debugging dual-KB merges only — not required by callers).
    """
    transformed = []
    for r in raw_results:
        content = r.get('content', {}).get('text', '')
        score = r.get('score', 0.0)
        location = r.get('location', {})
        s3_location = location.get('s3Location', {})
        s3_uri = s3_location.get('uri', '')
        metadata = r.get('metadata', {})

        # Extract document title from metadata or S3 URI
        doc_title = metadata.get('source-filename', '')
        if not doc_title and s3_uri:
            doc_title = s3_uri.split('/')[-1].rsplit('.', 1)[0].replace('_', ' ').replace('-', ' ')

        # All metadata keys use new format from .metadata.json
        sharepoint_url = metadata.get('url', '') or s3_uri

        transformed.append({
            'content': content,
            'similarity_score': round(float(score), 4),
            'document_title': doc_title,
            'metadata': {
                'file_name': s3_uri.split('/')[-1] if s3_uri else '',
                'sharepoint_url': sharepoint_url,
                's3_uri': s3_uri,
                'jurisdiction': metadata.get('jurisdiction', ''),
                'theme_level_1': metadata.get('theme-level-1', ''),
                'theme_level_2': metadata.get('theme-level-2', ''),
                'language': metadata.get('language', 'English'),
                'file_extension': metadata.get('file-extension', ''),
                'owner': metadata.get('owner', ''),
                'department': metadata.get('department', ''),
                'kb_source': kb_source,
            },
            'sharepoint_url': sharepoint_url,
        })
    return transformed


def search_pmi_knowledge_base(
    query: str,
    max_results: int = 10,
    filters: Optional[Dict[str, Any]] = None,
    jurisdiction: str = "",
    theme_level_1: str = "",
    theme_level_2: str = "",
) -> List[Dict[str, Any]]:
    """
    Search the PMI Knowledge Base using AWS Bedrock retrieve API.

    Args:
        query:         Semantic search query string
        max_results:   Maximum number of results to return (default: 10)
        filters:       Optional metadata filters (legacy dict format)
        jurisdiction:  Optional jurisdiction filter
        theme_level_1: Optional theme level 1 filter (e.g., "Smoke-free products (SFP)/ heated tobacco products (HTP)")
        theme_level_2: Optional theme level 2 filter (e.g., "Regulatory, Product standard system")

    Returns:
        List of result dicts, each containing:
            - content: str (chunk text)
            - similarity_score: float (0-1)
            - document_title: str
            - metadata: dict (all source metadata)
            - sharepoint_url: str
    """
    if not query or not query.strip():
        return []

    try:
        # Build retrieval configuration.
        # Use HYBRID search (semantic vectors + lexical/BM25) rather than pure
        # vector search. Hybrid markedly improves recall/precision for exact terms
        # common in this domain — legislation names, acronyms (COTPA, ENDS, IQOS),
        # authorities, and dates — which pure semantic search can miss.
        retrieval_config = {
            'vectorSearchConfiguration': {
                'numberOfResults': min(max_results, 25),  # Bedrock KB max is 25
                'overrideSearchType': 'HYBRID',
            }
        }

        # Build metadata filters
        jur = jurisdiction or (filters.get('jurisdiction', '') if filters else '')
        filter_conditions = []

        # Jurisdiction filter: match exact jurisdiction OR global
        if jur:
            filter_conditions.append({
                'orAll': [
                    {'equals': {'key': 'jurisdiction', 'value': jur}},
                    {'equals': {'key': 'jurisdiction', 'value': 'global'}},
                    {'equals': {'key': 'jurisdiction', 'value': 'Global'}},
                ]
            })

        # Theme level 1 filter (contains match — metadata value may have multiple comma-separated themes)
        if theme_level_1:
            filter_conditions.append(
                {'stringContains': {'key': 'theme-level-1', 'value': theme_level_1}}
            )

        # Theme level 2 filter
        if theme_level_2:
            filter_conditions.append(
                {'stringContains': {'key': 'theme-level-2', 'value': theme_level_2}}
            )

        # Combine filters with AND logic (all conditions must match)
        if filter_conditions:
            if len(filter_conditions) == 1:
                retrieval_config['vectorSearchConfiguration']['filter'] = filter_conditions[0]
            else:
                retrieval_config['vectorSearchConfiguration']['filter'] = {
                    'andAll': filter_conditions
                }

        # ── PRIMARY PATH: LiteLLM Gateway pass-through ─────────────────────
        # The gateway mirrors Bedrock's response shape, so the transform helper
        # is unchanged. HYBRID→semantic fallback is handled inside the helper.
        if KB_USE_LITELLM_GATEWAY:
            if KB_MULTILINGUAL_ENABLED:
                # Dual-KB: query the English (Titan) and Multilingual (Cohere)
                # KBs IN PARALLEL for the same query, then merge candidates.
                # A single query can then surface the best-matching chunks
                # regardless of which KB / language the source document is in.
                with ThreadPoolExecutor(max_workers=2) as ex:
                    fut_en = ex.submit(_litellm_kb_retrieve, KNOWLEDGE_BASE_ID, query, retrieval_config)
                    fut_ml = ex.submit(_litellm_kb_retrieve, BEDROCK_KB_ID_MULTILINGUAL, query, retrieval_config)
                    resp_en = fut_en.result()
                    resp_ml = fut_ml.result()

                results_en = _transform_kb_results(resp_en.get('retrievalResults', []), kb_source='english_titan')
                results_ml = _transform_kb_results(resp_ml.get('retrievalResults', []), kb_source='multilingual_cohere')

                score_en = max((r['similarity_score'] for r in results_en), default=0.0)
                score_ml = max((r['similarity_score'] for r in results_ml), default=0.0)
                logger.info(
                    f"KB_DUAL | query='{query[:60]}' | english_kb={KNOWLEDGE_BASE_ID} "
                    f"(n={len(results_en)}, max={score_en:.4f}) | "
                    f"multilingual_kb={BEDROCK_KB_ID_MULTILINGUAL} "
                    f"(n={len(results_ml)}, max={score_ml:.4f})"
                )
                # NOTE: without rerank, Titan and Cohere similarity scores are
                # NOT on a comparable scale, so this sort is best-effort only
                # (each KB's own ordering is preserved relative to itself, but
                # cross-KB ordering may not reflect true relevance). Enable
                # KB_RERANKER_ENABLED for a properly comparable merge — see
                # the rerank block below, which is the intended production
                # config when KB_MULTILINGUAL_ENABLED is on.
                merged = sorted(
                    results_en + results_ml,
                    key=lambda r: r.get('similarity_score', 0.0),
                    reverse=True,
                )
            else:
                response = _litellm_kb_retrieve(
                    kb_id=KNOWLEDGE_BASE_ID,
                    query=query,
                    retrieval_config=retrieval_config,
                )
                merged = _transform_kb_results(response.get('retrievalResults', []), kb_source='english_titan')
        # ── FALLBACK PATH: direct Bedrock boto3 (feature flag off) ─────────
        # HYBRID requires a compatible OpenSearch index; if it is not supported,
        # fall back to default (semantic) search rather than failing.
        # (Single-KB only — the multilingual KB is only queried via the gateway.)
        else:
            try:
                response = bedrock_agent_runtime.retrieve(
                    knowledgeBaseId=KNOWLEDGE_BASE_ID,
                    retrievalQuery={'text': query},
                    retrievalConfiguration=retrieval_config,
                )
            except Exception as hybrid_err:
                if retrieval_config['vectorSearchConfiguration'].get('overrideSearchType') == 'HYBRID':
                    logger.warning(
                        f"BEDROCK_KB | HYBRID search unsupported/failed ({hybrid_err}); "
                        f"retrying with default semantic search"
                    )
                    retrieval_config['vectorSearchConfiguration'].pop('overrideSearchType', None)
                    response = bedrock_agent_runtime.retrieve(
                        knowledgeBaseId=KNOWLEDGE_BASE_ID,
                        retrievalQuery={'text': query},
                        retrievalConfiguration=retrieval_config,
                    )
                else:
                    raise
            merged = _transform_kb_results(response.get('retrievalResults', []), kb_source='english_titan')

        if not merged:
            logger.info(f"BEDROCK_KB | query='{query[:60]}' | results=0")
            return []

        # ── Optional inline rerank (Cohere Rerank v3.5 via LiteLLM Gateway) ──
        # Puts English-KB (Titan) and Multilingual-KB (Cohere) chunks on ONE
        # comparable relevance scale before truncating to max_results. Without
        # this, dual-KB merges would be ordered by two different, non-comparable
        # embedding similarity scores.
        if KB_RERANKER_ENABLED:
            rerank_candidates = merged[:max(KB_RERANK_TOP_N, max_results)]
            reranked = _litellm_rerank(
                query=query,
                documents=[r['content'] for r in rerank_candidates],
                top_n=min(KB_RERANK_TOP_N, len(rerank_candidates)),
            )
            if reranked:
                out = []
                for item in reranked:
                    idx = item.get('index')
                    rel = item.get('relevance_score', item.get('relevanceScore', 0))
                    if idx is not None and 0 <= idx < len(rerank_candidates):
                        r = dict(rerank_candidates[idx])
                        r['original_score'] = r['similarity_score']
                        r['similarity_score'] = round(float(rel), 4)
                        out.append(r)
                if out:
                    merged = out  # already ordered by rerank relevance, desc

        transformed = merged[:max_results]

        logger.info(
            f"BEDROCK_KB | query='{query[:60]}' | results={len(transformed)} "
            f"| max_score={transformed[0]['similarity_score'] if transformed else 0} "
            f"| dual_kb={KB_MULTILINGUAL_ENABLED} | reranked={KB_RERANKER_ENABLED}"
        )
        return transformed

    except Exception as e:
        logger.error(f"Bedrock KB search failed: {e}")
        return []
