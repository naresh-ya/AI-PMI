"""
Step Functions State Machine Definition for PMI Agentic AI Platform

Defines the complete workflow orchestration including Human-in-the-Loop checkpoints
and feedback processing for the agentic AI system.
"""

import json
from aws_cdk import (
    aws_stepfunctions as sfn,
    aws_stepfunctions_tasks as tasks,
    aws_lambda as _lambda,
    Duration
)

def create_agentic_workflow_definition(
    input_validator_function: _lambda.Function,
    master_researcher_function: _lambda.Function,
    master_drafter_function: _lambda.Function,
    master_reviewer_function: _lambda.Function,
    orchestration_function: _lambda.Function,
    hitl_web_function: _lambda.Function
) -> sfn.StateMachine:
    """
    Create Step Functions state machine for agentic AI workflow with HITL integration
    
    Args:
        input_validator_function: Input validation Lambda
        master_researcher_function: Research agent Lambda
        master_drafter_function: Drafting agent Lambda  
        master_reviewer_function: Review agent Lambda
        orchestration_function: Orchestration engine Lambda
        hitl_web_function: HITL web interface Lambda
        
    Returns:
        Step Functions state machine
    """
    
    # Input Validation Task
    input_validation_task = tasks.LambdaInvoke(
        scope=None,
        id="InputValidation",
        lambda_function=input_validator_function,
        payload=sfn.TaskInput.from_json_path_at("$"),
        result_path="$.validation_result"
    )
    
    # Check if validation succeeded
    validation_choice = sfn.Choice(
        scope=None,
        id="ValidationChoice"
    )
    
    validation_failed = sfn.Fail(
        scope=None,
        id="ValidationFailed",
        cause="Input validation failed",
        error="VALIDATION_ERROR"
    )
    
    # Research Strategy Creation Task
    research_strategy_task = tasks.LambdaInvoke(
        scope=None,
        id="CreateResearchStrategy",
        lambda_function=master_researcher_function,
        payload=sfn.TaskInput.from_object({
            "request_id": sfn.JsonPath.string_at("$.request_id"),
            "document_requirements": sfn.JsonPath.string_at("$.validation_result.document_requirements"),
            "processing_notes": sfn.JsonPath.string_at("$.validation_result.processing_notes"),
            "execution_mode": "strategy_creation"
        }),
        result_path="$.research_strategy_result"
    )
    
    # Wait for Human Approval of Research Strategy
    research_approval_wait = sfn.Wait(
        scope=None,
        id="WaitForResearchApproval",
        time=sfn.WaitTime.duration(Duration.hours(24))  # Max wait time
    )
    
    # Check Research Strategy Approval Status
    check_research_approval = tasks.LambdaInvoke(
        scope=None,
        id="CheckResearchApproval", 
        lambda_function=hitl_web_function,
        payload=sfn.TaskInput.from_object({
            "action": "check_approval_status",
            "hitl_id": sfn.JsonPath.string_at("$.research_strategy_result.hitl_id")
        }),
        result_path="$.research_approval_status"
    )
    
    # Research Strategy Decision Choice
    research_decision_choice = sfn.Choice(
        scope=None,
        id="ResearchDecisionChoice"
    )
    
    # Execute Approved Research
    execute_research_task = tasks.LambdaInvoke(
        scope=None,
        id="ExecuteResearch",
        lambda_function=master_researcher_function,
        payload=sfn.TaskInput.from_object({
            "request_id": sfn.JsonPath.string_at("$.request_id"),
            "document_requirements": sfn.JsonPath.string_at("$.validation_result.document_requirements"),
            "human_feedback": sfn.JsonPath.string_at("$.research_approval_status.human_feedback"),
            "execution_mode": "execute_research"
        }),
        result_path="$.research_execution_result"
    )
    
    # Draft Document Outline Task
    draft_outline_task = tasks.LambdaInvoke(
        scope=None,
        id="CreateDocumentOutline",
        lambda_function=master_drafter_function,
        payload=sfn.TaskInput.from_object({
            "request_id": sfn.JsonPath.string_at("$.request_id"),
            "document_requirements": sfn.JsonPath.string_at("$.validation_result.document_requirements"),
            "research_results": sfn.JsonPath.string_at("$.research_execution_result.research_synthesis"),
            "execution_mode": "create_outline"
        }),
        result_path="$.draft_outline_result"
    )
    
    # Wait for Document Outline Approval
    outline_approval_wait = sfn.Wait(
        scope=None,
        id="WaitForOutlineApproval",
        time=sfn.WaitTime.duration(Duration.hours(12))
    )
    
    # Check Outline Approval
    check_outline_approval = tasks.LambdaInvoke(
        scope=None,
        id="CheckOutlineApproval",
        lambda_function=hitl_web_function,
        payload=sfn.TaskInput.from_object({
            "action": "check_approval_status",
            "hitl_id": sfn.JsonPath.string_at("$.draft_outline_result.hitl_id")
        }),
        result_path="$.outline_approval_status"
    )
    
    # Outline Decision Choice
    outline_decision_choice = sfn.Choice(
        scope=None,
        id="OutlineDecisionChoice"
    )
    
    # Generate Full Document Content
    generate_document_task = tasks.LambdaInvoke(
        scope=None,
        id="GenerateDocument",
        lambda_function=master_drafter_function,
        payload=sfn.TaskInput.from_object({
            "request_id": sfn.JsonPath.string_at("$.request_id"),
            "document_requirements": sfn.JsonPath.string_at("$.validation_result.document_requirements"),
            "research_results": sfn.JsonPath.string_at("$.research_execution_result.research_synthesis"),
            "approved_outline": sfn.JsonPath.string_at("$.outline_approval_status.approved_outline"),
            "human_feedback": sfn.JsonPath.string_at("$.outline_approval_status.human_feedback"),
            "execution_mode": "generate_content"
        }),
        result_path="$.document_generation_result"
    )
    
    # Final Compliance Review
    final_review_task = tasks.LambdaInvoke(
        scope=None,
        id="FinalComplianceReview",
        lambda_function=master_reviewer_function,
        payload=sfn.TaskInput.from_object({
            "request_id": sfn.JsonPath.string_at("$.request_id"),
            "document_content": sfn.JsonPath.string_at("$.document_generation_result.final_document"),
            "research_context": sfn.JsonPath.string_at("$.research_execution_result.research_synthesis"),
            "execution_mode": "comprehensive_review"
        }),
        result_path="$.final_review_result"
    )
    
    # Wait for Final Review Approval
    final_approval_wait = sfn.Wait(
        scope=None,
        id="WaitForFinalApproval",
        time=sfn.WaitTime.duration(Duration.hours(8))
    )
    
    # Check Final Approval
    check_final_approval = tasks.LambdaInvoke(
        scope=None,
        id="CheckFinalApproval",
        lambda_function=hitl_web_function,
        payload=sfn.TaskInput.from_object({
            "action": "check_approval_status",
            "hitl_id": sfn.JsonPath.string_at("$.final_review_result.hitl_id")
        }),
        result_path="$.final_approval_status"
    )
    
    # Final Decision Choice
    final_decision_choice = sfn.Choice(
        scope=None,
        id="FinalDecisionChoice"
    )
    
    # Workflow Completion
    workflow_completed = sfn.Succeed(
        scope=None,
        id="WorkflowCompleted",
        comment="Document generation workflow completed successfully"
    )
    
    # Handle Revisions Task
    handle_revision_task = tasks.LambdaInvoke(
        scope=None,
        id="HandleRevision",
        lambda_function=orchestration_function,
        payload=sfn.TaskInput.from_object({
            "action": "handle_revision",
            "hitl_id": sfn.JsonPath.string_at("$.hitl_id"),
            "revision_feedback": sfn.JsonPath.string_at("$.revision_feedback")
        }),
        result_path="$.revision_result"
    )
    
    # Handle Rejection
    handle_rejection = sfn.Fail(
        scope=None,
        id="WorkflowRejected",
        cause="Human reviewer rejected the output",
        error="HUMAN_REJECTION"
    )
    
    # Escalation Handler
    escalation_task = tasks.LambdaInvoke(
        scope=None,
        id="HandleEscalation",
        lambda_function=orchestration_function,
        payload=sfn.TaskInput.from_object({
            "action": "handle_escalation",
            "hitl_id": sfn.JsonPath.string_at("$.hitl_id"),
            "escalation_reason": sfn.JsonPath.string_at("$.escalation_reason")
        }),
        result_path="$.escalation_result"
    )
    
    # Build the workflow definition
    definition = (
        input_validation_task
        .next(
            validation_choice
            .when(
                sfn.Condition.string_equals("$.validation_result.status", "error"),
                validation_failed
            )
            .otherwise(
                research_strategy_task
                .next(research_approval_wait)
                .next(check_research_approval)
                .next(
                    research_decision_choice
                    .when(
                        sfn.Condition.string_equals("$.research_approval_status.decision", "approve"),
                        execute_research_task
                        .next(draft_outline_task)
                        .next(outline_approval_wait)
                        .next(check_outline_approval)
                        .next(
                            outline_decision_choice
                            .when(
                                sfn.Condition.string_equals("$.outline_approval_status.decision", "approve"),
                                generate_document_task
                                .next(final_review_task)
                                .next(final_approval_wait)
                                .next(check_final_approval)
                                .next(
                                    final_decision_choice
                                    .when(
                                        sfn.Condition.string_equals("$.final_approval_status.decision", "approve"),
                                        workflow_completed
                                    )
                                    .when(
                                        sfn.Condition.string_equals("$.final_approval_status.decision", "revise"),
                                        handle_revision_task.next(final_review_task)  # Loop back
                                    )
                                    .when(
                                        sfn.Condition.string_equals("$.final_approval_status.decision", "escalate"),
                                        escalation_task.next(final_approval_wait)  # Loop back after escalation
                                    )
                                    .otherwise(handle_rejection)
                                )
                            )
                            .when(
                                sfn.Condition.string_equals("$.outline_approval_status.decision", "revise"),
                                handle_revision_task.next(draft_outline_task)  # Loop back
                            )
                            .when(
                                sfn.Condition.string_equals("$.outline_approval_status.decision", "escalate"),
                                escalation_task.next(outline_approval_wait)  # Loop back after escalation
                            )
                            .otherwise(handle_rejection)
                        )
                    )
                    .when(
                        sfn.Condition.string_equals("$.research_approval_status.decision", "revise"),
                        handle_revision_task.next(research_strategy_task)  # Loop back
                    )
                    .when(
                        sfn.Condition.string_equals("$.research_approval_status.decision", "escalate"),
                        escalation_task.next(research_approval_wait)  # Loop back after escalation
                    )
                    .otherwise(handle_rejection)
                )
            )
        )
    )
    
    return definition


def create_step_functions_json_definition() -> dict:
    """
    Create JSON definition for Step Functions state machine
    (Alternative to CDK definition for direct deployment)
    """
    
    return {
        "Comment": "PMI Agentic AI Workflow with Human-in-the-Loop",
        "StartAt": "InputValidation",
        "States": {
            "InputValidation": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-input-validator",
                    "Payload.$": "$"
                },
                "ResultPath": "$.validation_result",
                "Next": "ValidationChoice",
                "Retry": [
                    {
                        "ErrorEquals": ["Lambda.ServiceException", "Lambda.AWSLambdaException"],
                        "IntervalSeconds": 2,
                        "MaxAttempts": 3,
                        "BackoffRate": 2.0
                    }
                ]
            },
            "ValidationChoice": {
                "Type": "Choice",
                "Choices": [
                    {
                        "Variable": "$.validation_result.status",
                        "StringEquals": "error",
                        "Next": "ValidationFailed"
                    }
                ],
                "Default": "CreateResearchStrategy"
            },
            "ValidationFailed": {
                "Type": "Fail",
                "Cause": "Input validation failed",
                "Error": "VALIDATION_ERROR"
            },
            "CreateResearchStrategy": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-master-researcher",
                    "Payload": {
                        "request_id.$": "$.request_id",
                        "document_requirements.$": "$.validation_result.document_requirements",
                        "processing_notes.$": "$.validation_result.processing_notes",
                        "execution_mode": "strategy_creation"
                    }
                },
                "ResultPath": "$.research_strategy_result",
                "Next": "WaitForResearchApproval"
            },
            "WaitForResearchApproval": {
                "Type": "Wait",
                "Seconds": 3600,  # 1 hour initial wait
                "Next": "CheckResearchApproval"
            },
            "CheckResearchApproval": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-hitl-web",
                    "Payload": {
                        "action": "check_approval_status",
                        "hitl_id.$": "$.research_strategy_result.hitl_id"
                    }
                },
                "ResultPath": "$.research_approval_status",
                "Next": "ResearchDecisionChoice"
            },
            "ResearchDecisionChoice": {
                "Type": "Choice",
                "Choices": [
                    {
                        "Variable": "$.research_approval_status.decision",
                        "StringEquals": "approve",
                        "Next": "ExecuteResearch"
                    },
                    {
                        "Variable": "$.research_approval_status.decision", 
                        "StringEquals": "revise",
                        "Next": "HandleRevision"
                    },
                    {
                        "Variable": "$.research_approval_status.decision",
                        "StringEquals": "escalate",
                        "Next": "HandleEscalation"
                    },
                    {
                        "Variable": "$.research_approval_status.decision",
                        "StringEquals": "pending",
                        "Next": "WaitForResearchApproval"
                    }
                ],
                "Default": "WorkflowRejected"
            },
            "ExecuteResearch": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-master-researcher",
                    "Payload": {
                        "request_id.$": "$.request_id",
                        "document_requirements.$": "$.validation_result.document_requirements",
                        "human_feedback.$": "$.research_approval_status.human_feedback",
                        "execution_mode": "execute_research"
                    }
                },
                "ResultPath": "$.research_execution_result",
                "Next": "CreateDocumentOutline"
            },
            "CreateDocumentOutline": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-master-drafter",
                    "Payload": {
                        "request_id.$": "$.request_id",
                        "document_requirements.$": "$.validation_result.document_requirements",
                        "research_results.$": "$.research_execution_result.research_synthesis",
                        "execution_mode": "create_outline"
                    }
                },
                "ResultPath": "$.draft_outline_result",
                "Next": "WaitForOutlineApproval"
            },
            "WaitForOutlineApproval": {
                "Type": "Wait",
                "Seconds": 1800,  # 30 minutes
                "Next": "CheckOutlineApproval"
            },
            "CheckOutlineApproval": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-hitl-web",
                    "Payload": {
                        "action": "check_approval_status",
                        "hitl_id.$": "$.draft_outline_result.hitl_id"
                    }
                },
                "ResultPath": "$.outline_approval_status",
                "Next": "OutlineDecisionChoice"
            },
            "OutlineDecisionChoice": {
                "Type": "Choice",
                "Choices": [
                    {
                        "Variable": "$.outline_approval_status.decision",
                        "StringEquals": "approve",
                        "Next": "GenerateDocument"
                    },
                    {
                        "Variable": "$.outline_approval_status.decision",
                        "StringEquals": "revise", 
                        "Next": "HandleRevision"
                    },
                    {
                        "Variable": "$.outline_approval_status.decision",
                        "StringEquals": "pending",
                        "Next": "WaitForOutlineApproval"
                    }
                ],
                "Default": "WorkflowRejected"
            },
            "GenerateDocument": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-master-drafter",
                    "Payload": {
                        "request_id.$": "$.request_id",
                        "document_requirements.$": "$.validation_result.document_requirements",
                        "research_results.$": "$.research_execution_result.research_synthesis",
                        "approved_outline.$": "$.outline_approval_status.approved_outline",
                        "human_feedback.$": "$.outline_approval_status.human_feedback",
                        "execution_mode": "generate_content"
                    }
                },
                "ResultPath": "$.document_generation_result",
                "Next": "FinalComplianceReview"
            },
            "FinalComplianceReview": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-master-reviewer",
                    "Payload": {
                        "request_id.$": "$.request_id",
                        "document_content.$": "$.document_generation_result.final_document",
                        "research_context.$": "$.research_execution_result.research_synthesis",
                        "execution_mode": "comprehensive_review"
                    }
                },
                "ResultPath": "$.final_review_result",
                "Next": "WaitForFinalApproval"
            },
            "WaitForFinalApproval": {
                "Type": "Wait",
                "Seconds": 1800,  # 30 minutes
                "Next": "CheckFinalApproval"
            },
            "CheckFinalApproval": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-hitl-web",
                    "Payload": {
                        "action": "check_approval_status",
                        "hitl_id.$": "$.final_review_result.hitl_id"
                    }
                },
                "ResultPath": "$.final_approval_status",
                "Next": "FinalDecisionChoice"
            },
            "FinalDecisionChoice": {
                "Type": "Choice",
                "Choices": [
                    {
                        "Variable": "$.final_approval_status.decision",
                        "StringEquals": "approve",
                        "Next": "WorkflowCompleted"
                    },
                    {
                        "Variable": "$.final_approval_status.decision",
                        "StringEquals": "revise",
                        "Next": "HandleRevision"
                    },
                    {
                        "Variable": "$.final_approval_status.decision",
                        "StringEquals": "pending",
                        "Next": "WaitForFinalApproval"
                    }
                ],
                "Default": "WorkflowRejected"
            },
            "HandleRevision": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-orchestration",
                    "Payload": {
                        "action": "handle_revision",
                        "hitl_id.$": "$.hitl_id",
                        "revision_feedback.$": "$.revision_feedback"
                    }
                },
                "ResultPath": "$.revision_result",
                "Next": "CreateResearchStrategy"  # Could be smarter routing
            },
            "HandleEscalation": {
                "Type": "Task",
                "Resource": "arn:aws:states:::lambda:invoke",
                "Parameters": {
                    "FunctionName": "pmi-agentic-ai-orchestration",
                    "Payload": {
                        "action": "handle_escalation",
                        "hitl_id.$": "$.hitl_id",
                        "escalation_reason.$": "$.escalation_reason"
                    }
                },
                "ResultPath": "$.escalation_result",
                "Next": "WaitForResearchApproval"
            },
            "WorkflowCompleted": {
                "Type": "Succeed",
                "Comment": "Document generation completed successfully"
            },
            "WorkflowRejected": {
                "Type": "Fail",
                "Cause": "Human reviewer rejected the workflow",
                "Error": "HUMAN_REJECTION"
            }
        }
    }
