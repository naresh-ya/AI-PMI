"""
Draft Redline renderer (self-contained).

Produces a "revision review copy" .docx that visually marks the differences
between a previous draft and a new draft:
  - additions are highlighted (bright green)
  - deletions are struck-through and highlighted (yellow)

Also exposes compute_document_diff() for a structured, section-level diff summary.

Imports only python-docx + stdlib so it loads cleanly in any drafter runtime.
The approved/delivered document is always the CLEAN copy; this module only
builds the review artifact.
"""
import io
import re
import difflib
import logging

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_COLOR_INDEX

logger = logging.getLogger()

ADD_HIGHLIGHT = WD_COLOR_INDEX.BRIGHT_GREEN
DEL_HIGHLIGHT = WD_COLOR_INDEX.YELLOW


def _norm(s):
    return (s or "").strip()


def _wc(sec):
    """Word count for a section dict; guards against non-dict inputs."""
    if not isinstance(sec, dict):
        return 0
    wc = sec.get('word_count')
    if wc:
        try:
            return int(wc)
        except (TypeError, ValueError):
            pass
    return len((sec.get('content') or '').split())


def compute_document_diff(prev_content, new_content):
    """Return a structured, section-level diff summary between two draft contents.

    Never raises on empty/missing sections. Comparison is case-sensitive after strip.
    """
    prev_secs = (prev_content or {}).get('sections', {}) or {}
    new_secs = (new_content or {}).get('sections', {}) or {}

    prev_title = _norm((prev_content or {}).get('title'))
    new_title = _norm((new_content or {}).get('title'))

    sections = {}
    counts = {'added': 0, 'removed': 0, 'modified': 0, 'unchanged': 0}

    all_keys = list(new_secs.keys()) + [k for k in prev_secs.keys() if k not in new_secs]
    for key in all_keys:
        prev_sec = prev_secs.get(key)
        new_sec = new_secs.get(key)
        if new_sec is not None and prev_sec is None:
            status = 'added'
        elif new_sec is None and prev_sec is not None:
            status = 'removed'
        else:
            prev_c = _norm((prev_sec or {}).get('content'))
            new_c = _norm((new_sec or {}).get('content'))
            prev_t = _norm((prev_sec or {}).get('title'))
            new_t = _norm((new_sec or {}).get('title'))
            if prev_c != new_c or prev_t != new_t:
                status = 'modified'
            else:
                status = 'unchanged'
        counts[status] += 1
        sections[key] = {
            'status': status,
            'word_delta': _wc(new_sec) - _wc(prev_sec),
        }

    total_word_delta = (
        sum(_wc(s) for s in new_secs.values())
        - sum(_wc(s) for s in prev_secs.values())
    )

    return {
        'title_changed': bool(prev_title != new_title),
        'prev_title': prev_title,
        'new_title': new_title,
        'sections': sections,
        'total_word_delta': total_word_delta,
        'counts': counts,
    }


def _add_word_diff_runs(paragraph, prev_text, new_text):
    """Inline word-level diff between prev_text and new_text into a single paragraph."""
    prev_tokens = (prev_text or '').split()
    new_tokens = (new_text or '').split()
    sm = difflib.SequenceMatcher(None, prev_tokens, new_tokens)

    def _emit(tokens, style):
        for tok in tokens:
            run = paragraph.add_run(tok)
            if style == 'add':
                run.font.highlight_color = ADD_HIGHLIGHT
            elif style == 'del':
                run.font.strike = True
                run.font.highlight_color = DEL_HIGHLIGHT
            paragraph.add_run(' ')  # readability spacer

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            _emit(new_tokens[j1:j2], 'equal')
        elif tag == 'insert':
            _emit(new_tokens[j1:j2], 'add')
        elif tag == 'delete':
            _emit(prev_tokens[i1:i2], 'del')
        elif tag == 'replace':
            _emit(prev_tokens[i1:i2], 'del')
            _emit(new_tokens[j1:j2], 'add')


def _add_marked_line(doc, text, kind):
    """Add a whole line as a paragraph rendered in the style for `kind`.

    kind in {'equal','add','del'}. A leading markdown bullet/heading marker is
    stripped for readability but the text is preserved.
    """
    clean = re.sub(r'^\s*(#{1,6}\s+|[-*\u2022]\s+)', '', text or '')
    p = doc.add_paragraph()
    run = p.add_run(clean)
    if kind == 'add':
        run.font.highlight_color = ADD_HIGHLIGHT
    elif kind == 'del':
        run.font.strike = True
        run.font.highlight_color = DEL_HIGHLIGHT
    return p


def _render_section_body(doc, prev_content_str, new_content_str):
    """Render a line-level (with inline word diff on replaced lines) diff of section bodies."""
    prev_lines = (prev_content_str or '').splitlines()
    new_lines = (new_content_str or '').splitlines()
    sm = difflib.SequenceMatcher(None, prev_lines, new_lines)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            for line in new_lines[j1:j2]:
                _add_marked_line(doc, line, 'equal')
        elif tag == 'insert':
            for line in new_lines[j1:j2]:
                _add_marked_line(doc, line, 'add')
        elif tag == 'delete':
            for line in prev_lines[i1:i2]:
                _add_marked_line(doc, line, 'del')
        elif tag == 'replace':
            prev_block = prev_lines[i1:i2]
            new_block = new_lines[j1:j2]
            overlap = min(len(prev_block), len(new_block))
            for idx in range(overlap):
                p = doc.add_paragraph()
                _add_word_diff_runs(p, prev_block[idx], new_block[idx])
            for line in prev_block[overlap:]:
                _add_marked_line(doc, line, 'del')
            for line in new_block[overlap:]:
                _add_marked_line(doc, line, 'add')


def render_redlined_docx(prev_content, new_content):
    """Build a redlined review .docx and return its bytes.

    Any exception is raised to the caller, which is responsible for the clean-draft fallback.
    """
    doc = Document()

    legend = doc.add_paragraph()
    legend_run = legend.add_run(
        "Revision review copy — additions are highlighted; deletions are struck "
        "through. The approved document will be clean."
    )
    legend_run.font.size = Pt(8)
    legend_run.font.color.rgb = RGBColor(0x80, 0x80, 0x80)

    prev_title = _norm((prev_content or {}).get('title'))
    new_title = _norm((new_content or {}).get('title'))
    h = doc.add_heading('', level=0)
    if prev_title != new_title and prev_title:
        _add_word_diff_runs(h, prev_title, new_title)
    else:
        h.add_run(new_title)

    prev_secs = (prev_content or {}).get('sections', {}) or {}
    new_secs = (new_content or {}).get('sections', {}) or {}

    for key, sec in new_secs.items():
        prev_sec = prev_secs.get(key)
        heading = doc.add_heading('', level=1)
        if prev_sec is None:
            # Added section — body all 'add'
            heading.add_run(_norm(sec.get('title')))
            for line in (sec.get('content') or '').splitlines():
                _add_marked_line(doc, line, 'add')
        else:
            if _norm(prev_sec.get('title')) != _norm(sec.get('title')):
                _add_word_diff_runs(heading, _norm(prev_sec.get('title')), _norm(sec.get('title')))
            else:
                heading.add_run(_norm(sec.get('title')))
            _render_section_body(doc, prev_sec.get('content'), sec.get('content'))

    # Removed sections (present in prev but not in new)
    for key, sec in prev_secs.items():
        if key in new_secs:
            continue
        heading = doc.add_heading('', level=1)
        del_run = heading.add_run(_norm(sec.get('title')))
        del_run.font.strike = True
        del_run.font.highlight_color = DEL_HIGHLIGHT
        for line in (sec.get('content') or '').splitlines():
            _add_marked_line(doc, line, 'del')

    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()
