"""
SSL Bootstrap for LangSmith -- ccaiaa-agentic-api

The internal self-hosted LangSmith endpoint
(langsmith.aiplat-dev.aws.private-pmideep.biz) uses a self-signed
certificate that Lambda base images do not trust by default. Without this
bootstrap, every langsmith SDK call fails with:
    SSLError([SSL: CERTIFICATE_VERIFY_FAILED] self-signed certificate ...)

MUST be imported and executed BEFORE `langsmith` (or anything that imports
it, e.g. llm_usage.py / tracing_helpers.py) is imported anywhere in the
process -- import this module first, at the very top of the Lambda handler
file, before any other project imports.

Independent copy of the equivalent bootstrap in the CA Workbench codebase
(Proxy_lambda/lambda_scripts/langsmith_tracer.py / lambda_function.py).
Only requests/httpx sessions used by the langsmith SDK are affected;
boto3/botocore (DynamoDB, S3, Bedrock) keep normal TLS verification.
"""

import warnings

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    warnings.filterwarnings("ignore", message="Unverified HTTPS request")
except Exception:
    pass

try:
    import requests

    _ls_original_requests_request = requests.Session.request

    def _ls_patched_requests_request(self, *args, **kwargs):
        kwargs["verify"] = False
        return _ls_original_requests_request(self, *args, **kwargs)

    requests.Session.request = _ls_patched_requests_request
except ImportError:
    pass

try:
    import httpx

    _ls_original_httpx_client_init = httpx.Client.__init__

    def _ls_patched_httpx_client_init(self, *args, **kwargs):
        kwargs["verify"] = False
        return _ls_original_httpx_client_init(self, *args, **kwargs)

    httpx.Client.__init__ = _ls_patched_httpx_client_init

    _ls_original_httpx_async_client_init = httpx.AsyncClient.__init__

    def _ls_patched_httpx_async_client_init(self, *args, **kwargs):
        kwargs["verify"] = False
        return _ls_original_httpx_async_client_init(self, *args, **kwargs)

    httpx.AsyncClient.__init__ = _ls_patched_httpx_async_client_init
except ImportError:
    pass
