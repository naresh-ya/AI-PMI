"""
LangSmith LLM Usage Recording -- ccaiaa-agentic-api

Independent copy of the equivalent helper used in the CA Workbench codebase
(core/llm_usage.py there). Deliberately NOT imported cross-repo -- this repo
has its own isolated core/langsmith_tracing/ folder per design decision.

Reads token usage and cost directly off a LiteLLM proxy HTTP response and
attaches them as a child LangSmith span under the current run tree. This
is a pure passthrough of what LiteLLM already computed -- no local pricing
math, no token counting of our own.

Requires an active LangSmith run tree (see tracing_helpers.py) -- if
get_current_run_tree() returns None, this is a silent no-op (fail-open),
so a missing/broken trace context never breaks the underlying LLM call.
"""

import logging

logger = logging.getLogger(__name__)


def record_llm_usage(response_json, name="litellm_call", response=None):
    """
    Record token usage + cost for one LiteLLM call as a LangSmith child span.

    Args:
        response_json: parsed JSON body of the LiteLLM response (dict).
        name: span name -- should identify the call site (e.g.
            "planner_llm", "kb_llm", "drafter_section_llm").
        response: the raw http.client/urllib response object, used only to
            read the "x-litellm-response-cost" header. Optional -- if not
            provided, cost is simply omitted from the span.
    """
    try:
        from langsmith import get_current_run_tree
        usage = (response_json or {}).get("usage") or {}
        pt = int(usage.get("prompt_tokens") or 0)
        ct = int(usage.get("completion_tokens") or 0)
        tt = int(usage.get("total_tokens") or (pt + ct))

        # Cost comes back in the LiteLLM response header (no pricing math)
        cost = None
        if response is not None:
            try:
                c = response.headers.get("x-litellm-response-cost")
                cost = float(c) if c is not None else None
            except Exception:
                cost = None

        parent = get_current_run_tree()
        if parent is None:
            return
        child = parent.create_child(
            name=name, run_type="llm",
            inputs={"model": (response_json or {}).get("model")},
        )
        child.add_outputs({"usage_metadata": {
            "input_tokens": pt, "output_tokens": ct, "total_tokens": tt,
        }})
        if cost is not None:
            child.add_metadata({"litellm_cost_usd": cost})
        child.end(); child.post(); child.patch()
    except Exception as e:
        logger.warning(f"record_llm_usage skipped: {e}")
