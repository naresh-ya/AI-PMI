"""
LangSmith Tracing Helpers -- ccaiaa-agentic-api Step Functions Workflow

Provides a single, consistent convention every Lambda stage in the Step
Functions pipeline uses to propagate one LangSmith trace across process
boundaries -- Step Functions itself has no concept of a trace, so each
stage must explicitly export/import the trace context via its own JSON
payload, the same "to_headers() -> tracing_context(parent=...)" pattern
already used for the Lambda -> AgentCore hop in the CA Workbench codebase.

Usage (typical Lambda handler):

    import core.langsmith_tracing.ssl_bootstrap  # noqa: F401  (import first!)
    from langsmith import traceable
    from langsmith.run_helpers import tracing_context
    from core.langsmith_tracing.tracing_helpers import (
        get_incoming_langsmith_headers, attach_outgoing_langsmith_headers,
    )

    @traceable(name="master_researcher", run_type="chain")
    def _traced_research(event, run_tree=None):
        if run_tree:
            run_tree.add_metadata({
                "request_id": event.get("request_id"),
                "user_id": event.get("request_data", {}).get("user_id"),
            })
        result = do_research(event)
        attach_outgoing_langsmith_headers(result, run_tree)
        return result

    def lambda_handler(event, context):
        incoming_headers = get_incoming_langsmith_headers(event)
        with tracing_context(parent=incoming_headers):
            return _traced_research(event)
"""

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# The single field name every stage reads/writes. Kept as one constant so
# every handler across the pipeline agrees on the exact key -- a typo here
# in any one stage silently breaks propagation from that point onward.
LANGSMITH_HEADERS_FIELD = "langsmith_headers"


def get_incoming_langsmith_headers(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Read the propagated trace context from an incoming Step Functions/Lambda
    event payload. Returns {} if absent (e.g. this is the very first stage,
    or an upstream state failed to forward it) -- tracing_context(parent={})
    is safe and simply starts a fresh, unparented trace rather than erroring.
    """
    try:
        headers = event.get(LANGSMITH_HEADERS_FIELD) or {}
        logger.info(
            f"[TRACING] Incoming langsmith_headers present={bool(headers)} "
            f"keys={list(headers.keys())}"
        )
        return headers
    except Exception as e:
        logger.warning(f"[TRACING] Failed to read incoming langsmith_headers (non-fatal): {e}")
        return {}


def attach_outgoing_langsmith_headers(result: Dict[str, Any], run_tree: Optional[Any]) -> Dict[str, Any]:
    """
    Export the current trace context onto this stage's OWN output dict, so
    the NEXT Step Functions state -- whichever Lambda it invokes -- can pick
    up get_incoming_langsmith_headers() and continue the same trace.

    MUST be called at the end of every traced stage, even ones that don't
    do anything else with the run_tree, or the chain breaks at that hop.

    Mutates and returns `result` for convenient chaining:
        return attach_outgoing_langsmith_headers(result, run_tree)
    """
    try:
        if run_tree is not None:
            result[LANGSMITH_HEADERS_FIELD] = run_tree.to_headers()
        else:
            result[LANGSMITH_HEADERS_FIELD] = {}
    except Exception as e:
        logger.warning(f"[TRACING] Failed to attach outgoing langsmith_headers (non-fatal): {e}")
        result[LANGSMITH_HEADERS_FIELD] = {}
    return result
