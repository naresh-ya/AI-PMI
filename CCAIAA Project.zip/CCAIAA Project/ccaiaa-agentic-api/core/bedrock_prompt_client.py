"""
Bedrock Prompt Management resolver — runtime client for the CCAIAA pipeline.

Design goals (see .kiro/specs/aws-prompt-management/design.md):
  - boto3-only (no requests/dotenv) so it is Lambda-bundle friendly.
  - FETCHES PROMPT TEXT ONLY. It does NOT call any model — the existing handlers
    keep their own LiteLLM invocation, model tiering, temperatures and guardrails.
  - FAIL-OPEN: every failure path returns None so callers fall back to the
    in-code prompt. It never raises.
  - Caches resolved text per execution environment (module-level dict), plus a
    name->id map, so at most one GetPrompt call per prompt name per warm Lambda.

This module is imported lazily by core.prompt_registry_new.get_agent_prompt only
when the PROMPT_MGMT_ENABLED feature flag is on. With the flag off it is never
touched, so importing prompt_registry_new stays cheap and behavior is unchanged.
"""
import logging
import os
import threading

logger = logging.getLogger(__name__)

# ── Configuration (LITELLM_*-style env vars) ─────────────────────────────────
PROMPT_MGMT_ENABLED = os.environ.get("PROMPT_MGMT_ENABLED", "false").strip().lower() == "true"
PROMPT_MGMT_REGION = os.environ.get("PROMPT_MGMT_REGION", os.environ.get("AWS_REGION", "eu-west-1"))
PROMPT_MGMT_VERSION = os.environ.get("PROMPT_MGMT_VERSION", "").strip()  # "" => DRAFT/latest
PROMPT_MGMT_TIMEOUT_S = float(os.environ.get("PROMPT_MGMT_TIMEOUT_S", "2"))

# ── Module-level caches (per warm execution environment) ─────────────────────
_client = None
_client_lock = threading.Lock()
_name_to_id: dict = {}
_text_cache: dict = {}
_name_map_loaded = False


def is_enabled() -> bool:
    return PROMPT_MGMT_ENABLED


def _get_client():
    """Lazily build a bedrock-agent client with a short timeout. Returns None on failure."""
    global _client
    if _client is not None:
        return _client
    with _client_lock:
        if _client is None:
            try:
                import boto3
                from botocore.config import Config
                cfg = Config(
                    region_name=PROMPT_MGMT_REGION,
                    connect_timeout=PROMPT_MGMT_TIMEOUT_S,
                    read_timeout=PROMPT_MGMT_TIMEOUT_S,
                    retries={"max_attempts": 1, "mode": "standard"},
                )
                _client = boto3.client("bedrock-agent", config=cfg)
            except Exception as e:  # pragma: no cover - defensive
                logger.warning("PROMPT_MGMT | client init failed: %s", e)
                _client = None
    return _client


def _load_name_map(client) -> None:
    """Populate _name_to_id once per warm environment (handles pagination)."""
    global _name_map_loaded
    if _name_map_loaded:
        return
    token = None
    while True:
        kwargs = {"maxResults": 100}
        if token:
            kwargs["nextToken"] = token
        resp = client.list_prompts(**kwargs)
        for p in resp.get("promptSummaries", []):
            _name_to_id[p["name"]] = p["id"]
        token = resp.get("nextToken")
        if not token:
            break
    _name_map_loaded = True


def get_prompt_text(name: str):
    """Return the prompt's variant text for `name`, or None on ANY failure.

    Never raises. Cached per warm environment. Respects PROMPT_MGMT_VERSION
    (empty => DRAFT/latest).
    """
    if not name:
        return None
    if name in _text_cache:
        return _text_cache[name]

    client = _get_client()
    if client is None:
        return None

    try:
        _load_name_map(client)
        prompt_id = _name_to_id.get(name)
        if not prompt_id:
            logger.warning("PROMPT_MGMT_FALLBACK | name=%s | reason=not_found", name)
            return None

        kwargs = {"promptIdentifier": prompt_id}
        if PROMPT_MGMT_VERSION:
            kwargs["promptVersion"] = PROMPT_MGMT_VERSION
        detail = client.get_prompt(**kwargs)

        variants = detail.get("variants", []) or []
        text = ""
        if variants:
            text = (variants[0].get("templateConfiguration", {})
                               .get("text", {})
                               .get("text", "")) or ""
        if not text:
            logger.warning("PROMPT_MGMT_FALLBACK | name=%s | reason=empty_text", name)
            return None

        _text_cache[name] = text
        logger.info("PROMPT_MGMT_RESOLVED | name=%s | chars=%d", name, len(text))
        return text

    except Exception as e:
        logger.warning("PROMPT_MGMT_FALLBACK | name=%s | reason=%s", name, e)
        return None


def clear_cache() -> None:
    """Test helper — reset caches so the next call re-fetches."""
    global _name_map_loaded
    _name_to_id.clear()
    _text_cache.clear()
    _name_map_loaded = False
