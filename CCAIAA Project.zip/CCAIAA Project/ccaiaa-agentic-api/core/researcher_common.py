"""
Shared utilities for the researcher stage lambdas.

This module contains configuration constants, the core LiteLLM caller, the Cohere
reranker, token estimation, and other utility functions used by multiple researcher
stages. It lives in core/ (bundled into every lambda via _RESEARCH_INCLUDES) so
per-stage modules import only what they need from here.

Design rules:
  - NO business logic lives here — only infrastructure/utility functions.
  - Every function is fail-safe (returns None or the input on error, never raises).
  - Configuration is sourced from env vars with sensible defaults.
"""

import json
import logging
import os
import re
import ssl
import urllib.request
import urllib.error
from typing import Dict, Any, List, Optional

import boto3

# ── Logging ───────────────────────────────────────────────────────────────────
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ── LiteLLM / Model configuration ────────────────────────────────────────────
LITELLM_KEY = os.environ.get('AWS_BEARER_TOKEN_BEDROCK')
LITELLM_URL = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions'

LITELLM_MODEL = (
    os.environ.get('LLM_MODEL_DEFAULT')
    or os.environ.get('LITELLM_MODEL')
    or 'bedrock/us.anthropic.claude-sonnet-4-6'
)
LLM_MODEL_REASONING = os.environ.get('LLM_MODEL_REASONING', 'bedrock/us.anthropic.claude-opus-4-8')
LLM_MODEL_FAST = os.environ.get('LLM_MODEL_FAST', 'bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0')

# Reranker (Cohere Rerank v3.5 via LiteLLM /rerank)
LITELLM_RERANK_URL = os.environ.get(
    'AWS_LITELLM_RERANK_ENDPOINT', 'https://litellm.aiplat-dev.aws.private-pmideep.biz/rerank'
)
LITELLM_RERANK_MODEL = os.environ.get(
    'AWS_LITELLM_RERANK_MODEL',
    'bedrock/arn:aws:bedrock:us-east-1::foundation-model/cohere.rerank-v3-5:0'
)
RERANK_MIN_SCORE = float(os.environ.get('RERANK_MIN_SCORE', '0.02'))

# Gemini model for URL extraction and web search comparison
GEMINI_MODEL = os.environ.get('GEMINI_MODEL', 'gemini-2.5-pro')

# ── AWS / infra configuration ─────────────────────────────────────────────────
DOCUMENT_BUCKET = os.environ.get('DOCUMENT_BUCKET', 'pmi-agentic-ai-documents-603433800649-eu-west-1')
TAVILY_API_KEY = os.environ.get('TAVILY_API_KEY', '')

# Token budget observability
PROMPT_SOFT_BUDGET_TOKENS = int(os.environ.get('PROMPT_SOFT_BUDGET_TOKENS', '150000'))

# Jurisdiction context cap (shared with drafter)
JURISDICTION_CTX_MAX = 8000

# Default tone when request omits tone_requirements
DEFAULT_TONE = "formal, neutral, compliance-first, fact-based and non-promotional"

# Gemini comparison toggle (evaluation-only, off by default)
ENABLE_GEMINI_COMPARISON = os.environ.get('ENABLE_GEMINI_COMPARISON', 'false').strip().lower() in ('1', 'true', 'yes', 'on')

# ── Lazy-initialized AWS clients ─────────────────────────────────────────────
_s3_client = None
_dynamodb_resource = None


def get_s3_client():
    global _s3_client
    if _s3_client is None:
        _s3_client = boto3.client('s3')
    return _s3_client


def get_dynamodb_resource():
    global _dynamodb_resource
    if _dynamodb_resource is None:
        _dynamodb_resource = boto3.resource('dynamodb')
    return _dynamodb_resource


# ── Token estimation ──────────────────────────────────────────────────────────

def _estimate_tokens(text: str) -> int:
    """Rough, model-agnostic token estimate (~4 chars/token). For logging only."""
    return (len(text) // 4) if text else 0


def _preflight_prompt_budget(system_prompt: str, user_prompt: str, label: str,
                             request_id: str = 'unknown') -> int:
    """Log a WARN if combined input approaches the soft token budget."""
    est = _estimate_tokens(system_prompt) + _estimate_tokens(user_prompt)
    if est >= PROMPT_SOFT_BUDGET_TOKENS:
        logger.warning(
            f"[{request_id}] TOKEN_PREFLIGHT | label='{label}' | est_input_tokens=~{est} "
            f">= soft_budget={PROMPT_SOFT_BUDGET_TOKENS} | consider trimming injected sources."
        )
    else:
        logger.info(f"[{request_id}] TOKEN_PREFLIGHT | label='{label}' | est_input_tokens=~{est}")
    return est


def _check_response_truncation(res: Dict[str, Any], label: str, request_id: str = 'unknown') -> bool:
    """Detect OUTPUT truncation (hit max_tokens) from the OpenAI-compatible response."""
    try:
        finish_reason = None
        choices = res.get('choices') or []
        if choices and isinstance(choices[0], dict):
            finish_reason = choices[0].get('finish_reason')
        native_stop = res.get('stop_reason')
        truncated = (finish_reason == 'length') or (native_stop in ('max_tokens', 'length'))
        if truncated:
            logger.warning(
                f"[{request_id}] TOKEN_POSTFLIGHT | label='{label}' | OUTPUT TRUNCATED "
                f"(finish_reason={finish_reason!r}, stop_reason={native_stop!r}) — response is "
                f"incomplete (hit max_tokens). Raise max_tokens or reduce input."
            )
        return truncated
    except Exception as e:
        logger.warning(f"[{request_id}] TOKEN_POSTFLIGHT | label='{label}' | truncation check failed: {e}")
        return False


# ── Relevance tokenization ────────────────────────────────────────────────────

_RELEVANCE_STOPWORDS = {
    'the', 'and', 'for', 'with', 'this', 'that', 'from', 'into', 'about', 'are',
    'was', 'were', 'has', 'have', 'had', 'will', 'would', 'should', 'could', 'its',
    'their', 'our', 'your', 'his', 'her', 'they', 'them', 'these', 'those', 'such',
    'any', 'all', 'new', 'use', 'used', 'using', 'via', 'per', 'over', 'under',
    'launch', 'update', 'comments', 'input', 'response', 'initiative', 'proposed',
}


def _tokenize_relevance(text: str) -> List[str]:
    """Lowercase content tokens (len>2, stopwords removed) for overlap scoring."""
    return [
        w for w in re.split(r'[^a-z0-9]+', (text or '').lower())
        if len(w) > 2 and w not in _RELEVANCE_STOPWORDS
    ]


# ── Core LiteLLM caller (JSON response) ──────────────────────────────────────

def _llm_call_json(prompt: str, max_tokens: int = 400, timeout: int = 15,
                   model: str = None, temperature: float = 0.1,
                   name: str = 'researcher_llm_call_json') -> Optional[Any]:
    """Minimal LiteLLM call that returns parsed JSON (dict/list) or None.

    Robust to markdown fences and leading/trailing prose. Non-fatal: returns None on
    any error so callers can fall back to deterministic behavior.

    `name` identifies the call site in LangSmith traces (e.g. "planner_query_enrichment") --
    override it at each call site so different callers of this shared helper are
    distinguishable in the trace instead of all showing up under one generic name.
    """
    if not LITELLM_KEY:
        return None
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        data = {
            "model": model or LITELLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        headers = {
            "Authorization": f"Bearer {LITELLM_KEY}",
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(
            LITELLM_URL, data=json.dumps(data).encode('utf-8'),
            headers=headers, method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=timeout) as resp:
            res = json.loads(resp.read().decode('utf-8'))
            try:
                from core.langsmith_tracing.llm_usage import record_llm_usage
                record_llm_usage(res, name=name, response=resp)
            except Exception:
                pass
            raw = res['choices'][0]['message']['content'].strip()
            if raw.startswith('```'):
                raw = '\n'.join(raw.split('\n')[1:-1]).strip()
            try:
                return json.loads(raw)
            except Exception:
                # Salvage the outermost JSON object/array from surrounding prose.
                for open_c, close_c in (('{', '}'), ('[', ']')):
                    a, b = raw.find(open_c), raw.rfind(close_c)
                    if a != -1 and b != -1 and b > a:
                        try:
                            return json.loads(raw[a:b + 1])
                        except Exception:
                            continue
            return None
    except Exception as e:
        logger.warning(f"LLM JSON call failed (non-fatal): {e}")
        return None


# ── Cohere Reranker ───────────────────────────────────────────────────────────

def _rerank_sources(query: str, sources: List[Dict], top_n: int = None) -> List[Dict]:
    """Cross-encoder rerank (Cohere Rerank v3.5 via LiteLLM /rerank).

    Attaches a normalized 0-1 'rerank_score' to each source (in place) and returns the
    sources ordered by that score. Non-fatal: on ANY error the original list is returned
    unchanged.

    - uploaded_file sources are kept but exempt from any rerank-based drop downstream.
    """
    if not sources or not query or not LITELLM_KEY:
        return sources

    docs = []
    for s in sources:
        text = f"{s.get('title', '')}\n{s.get('summary', '')}".strip()
        docs.append(text or (s.get('title') or s.get('url') or 'source'))

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        payload = {
            "model": LITELLM_RERANK_MODEL,
            "query": query[:2000],
            "documents": docs,
            "top_n": top_n or len(docs),
        }
        req = urllib.request.Request(
            LITELLM_RERANK_URL,
            data=json.dumps(payload).encode('utf-8'),
            headers={"Authorization": f"Bearer {LITELLM_KEY}", "Content-Type": "application/json"},
            method='POST',
        )
        with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
            res = json.loads(resp.read().decode('utf-8'))
        try:
            # Rerank calls carry no prompt/completion token usage (no `choices`/`usage`
            # in the response), so record_llm_usage doesn't apply here -- give this
            # call its own lightweight span instead so it's still visible in the trace.
            from langsmith import get_current_run_tree
            _parent = get_current_run_tree()
            if _parent is not None:
                _child = _parent.create_child(
                    name='researcher_rerank_sources', run_type='tool',
                    inputs={'model': LITELLM_RERANK_MODEL, 'doc_count': len(docs)},
                )
                _child.add_outputs({'result_count': len(res.get('results', []) or [])})
                _child.end(); _child.post(); _child.patch()
        except Exception:
            pass
        results = res.get('results', []) or []
        if not results:
            logger.warning("RERANK | empty results; keeping original order")
            return sources

        for item in results:
            idx = item.get('index')
            score = item.get('relevance_score', item.get('relevanceScore'))
            if idx is not None and 0 <= idx < len(sources) and score is not None:
                sources[idx]['rerank_score'] = round(float(score), 4)

        ordered = sorted(
            sources,
            key=lambda s: s.get('rerank_score') if s.get('rerank_score') is not None else -1.0,
            reverse=True,
        )
        top = [s.get('rerank_score') for s in ordered[:3]]
        logger.info(f"RERANK | scored={len(results)} sources | top3_scores={top}")
        return ordered
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='ignore')[:200]
        logger.warning(f"RERANK | HTTP {e.code}: {body} — falling back to original ranking")
        return sources
    except Exception as e:
        logger.warning(f"RERANK | failed ({type(e).__name__}: {str(e)[:150]}) — falling back")
        return sources
