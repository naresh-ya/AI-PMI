"""
Human-in-the-Loop (HITL) Manager for PMI Agentic AI Platform

Manages human intervention points, approvals, and collaboration workflows
between AI agents and human experts.
"""

import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import boto3
from enum import Enum

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')
ses = boto3.client('ses')

class InterventionType(Enum):
    APPROVAL_REQUIRED = "approval_required"
    REVIEW_REQUESTED = "review_requested"
    EXPERT_CONSULTATION = "expert_consultation"
    ESCALATION = "escalation"
    QUALITY_GATE = "quality_gate"

class HITLManager:
    """Manages human-in-the-loop interactions and workflows"""
    
    def __init__(self):
        self.hitl_table = dynamodb.Table('pmi-agentic-ai-hitl')
        self.requests_table = dynamodb.Table('pmi-agentic-ai-requests')
        
    def create_hitl_checkpoint(
        self, 
        request_id: str,
        agent_name: str,
        intervention_type: InterventionType,
        agent_output: Dict[str, Any],
        human_reviewers: List[str],
        priority: str = "medium",
        timeout_hours: int = 24
    ) -> str:
        """
        Create a human-in-the-loop checkpoint
        
        Args:
            request_id: The parent request ID
            agent_name: Name of the agent requesting human intervention
            intervention_type: Type of human intervention needed
            agent_output: The agent's output requiring review
            human_reviewers: List of human reviewer IDs/emails
            priority: Priority level (low/medium/high/urgent)
            timeout_hours: Hours before escalation
            
        Returns:
            HITL checkpoint ID
        """
        
        hitl_id = f"hitl_{request_id}_{agent_name}_{int(datetime.now().timestamp())}"
        
        # Determine escalation timeline based on priority
        timeout_mapping = {
            "urgent": 4,    # 4 hours
            "high": 8,      # 8 hours  
            "medium": 24,   # 24 hours
            "low": 48       # 48 hours
        }
        
        actual_timeout = timeout_mapping.get(priority, timeout_hours)
        escalation_time = datetime.now() + timedelta(hours=actual_timeout)
        
        hitl_record = {
            'hitl_id': hitl_id,
            'request_id': request_id,
            'agent_name': agent_name,
            'intervention_type': intervention_type.value,
            'status': 'pending',
            'created_at': datetime.now().isoformat(),
            'escalation_time': escalation_time.isoformat(),
            'priority': priority,
            'human_reviewers': human_reviewers,
            'agent_output': agent_output,
            'human_feedback': {},
            'decision': None,
            'decision_rationale': None,
            'completed_at': None,
            'completed_by': None
        }
        
        self.hitl_table.put_item(Item=hitl_record)
        
        # Update main request status
        self._update_request_status(request_id, f"awaiting_human_{agent_name}")
        
        # Notify human reviewers
        self._notify_reviewers(hitl_record)
        
        logger.info(f"Created HITL checkpoint {hitl_id} for request {request_id}")
        
        return hitl_id
        
    def get_pending_reviews(self, reviewer_id: str) -> List[Dict[str, Any]]:
        """Get all pending reviews for a specific reviewer"""
        
        # Query DynamoDB for pending reviews assigned to this reviewer
        response = self.hitl_table.scan(
            FilterExpression='contains(human_reviewers, :reviewer) AND #status = :status',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':reviewer': reviewer_id,
                ':status': 'pending'
            }
        )
        
        return response.get('Items', [])
        
    def submit_human_decision(
        self,
        hitl_id: str,
        reviewer_id: str,
        decision: str,  # "approve", "reject", "revise"
        feedback: Dict[str, Any],
        rationale: str
    ) -> bool:
        """
        Submit human decision for a HITL checkpoint
        
        Args:
            hitl_id: The HITL checkpoint ID
            reviewer_id: ID of the reviewer making the decision
            decision: The decision (approve/reject/revise)
            feedback: Detailed feedback and suggestions
            rationale: Explanation of the decision
            
        Returns:
            Success status
        """
        
        try:
            # Update HITL record
            self.hitl_table.update_item(
                Key={'hitl_id': hitl_id},
                UpdateExpression="""
                    SET #status = :status,
                        decision = :decision,
                        human_feedback = :feedback,
                        decision_rationale = :rationale,
                        completed_at = :completed_at,
                        completed_by = :completed_by
                """,
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':status': 'completed',
                    ':decision': decision,
                    ':feedback': feedback,
                    ':rationale': rationale,
                    ':completed_at': datetime.now().isoformat(),
                    ':completed_by': reviewer_id
                }
            )
            
            # Get the HITL record to extract request info
            hitl_record = self.hitl_table.get_item(Key={'hitl_id': hitl_id})['Item']
            request_id = hitl_record['request_id']
            agent_name = hitl_record['agent_name']
            
            # Update request status and trigger next step
            if decision == "approve":
                self._continue_workflow(request_id, agent_name, feedback)
            elif decision == "reject":
                self._handle_rejection(request_id, agent_name, feedback, rationale)
            else:  # revise
                self._handle_revision_request(request_id, agent_name, feedback, rationale)
                
            logger.info(f"Human decision submitted for HITL {hitl_id}: {decision}")
            return True
            
        except Exception as e:
            logger.error(f"Error submitting human decision: {str(e)}")
            return False
            
    def get_hitl_dashboard_data(self, reviewer_id: Optional[str] = None) -> Dict[str, Any]:
        """Get dashboard data for HITL management"""
        
        # Get pending reviews
        if reviewer_id:
            pending_reviews = self.get_pending_reviews(reviewer_id)
        else:
            # Get all pending reviews (for admin view)
            response = self.hitl_table.scan(
                FilterExpression='#status = :status',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={':status': 'pending'}
            )
            pending_reviews = response.get('Items', [])
        
        # Calculate metrics
        urgent_count = len([r for r in pending_reviews if r['priority'] == 'urgent'])
        high_count = len([r for r in pending_reviews if r['priority'] == 'high'])
        overdue_count = len([
            r for r in pending_reviews 
            if datetime.fromisoformat(r['escalation_time']) < datetime.now()
        ])
        
        # Group by agent
        by_agent = {}
        for review in pending_reviews:
            agent = review['agent_name']
            if agent not in by_agent:
                by_agent[agent] = []
            by_agent[agent].append(review)
            
        return {
            'total_pending': len(pending_reviews),
            'urgent_count': urgent_count,
            'high_count': high_count,
            'overdue_count': overdue_count,
            'by_agent': by_agent,
            'pending_reviews': pending_reviews[:10]  # Recent 10 for dashboard
        }
        
    def _update_request_status(self, request_id: str, status: str):
        """Update the main request status"""
        self.requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression='SET #status = :status, updated_at = :updated_at',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':status': status,
                ':updated_at': datetime.now().isoformat()
            }
        )
        
    def _notify_reviewers(self, hitl_record: Dict[str, Any]):
        """Notify human reviewers about pending review"""
        
        notification_message = {
            "hitl_id": hitl_record['hitl_id'],
            "request_id": hitl_record['request_id'],
            "agent_name": hitl_record['agent_name'],
            "intervention_type": hitl_record['intervention_type'],
            "priority": hitl_record['priority'],
            "escalation_time": hitl_record['escalation_time'],
            "review_url": f"https://pmi-agentic-ai.com/hitl/{hitl_record['hitl_id']}"
        }
        
        # Send notifications (SNS, email, etc.)
        try:
            # SNS notification for real-time alerts
            sns.publish(
                TopicArn='arn:aws:sns:region:account:pmi-agentic-ai-notifications',
                Message=json.dumps(notification_message),
                Subject=f"PMI Agentic AI: {hitl_record['intervention_type']} required"
            )
            
            # Email notifications
            for reviewer in hitl_record['human_reviewers']:
                self._send_email_notification(reviewer, notification_message)
                
        except Exception as e:
            logger.error(f"Error sending notifications: {str(e)}")
            
    def _send_email_notification(self, reviewer_email: str, notification: Dict[str, Any]):
        """Send email notification to reviewer"""
        
        email_body = f"""
        PMI Agentic AI Platform - Human Review Required
        
        Request ID: {notification['request_id']}
        Agent: {notification['agent_name']}
        Type: {notification['intervention_type']}
        Priority: {notification['priority']}
        
        Please review at: {notification['review_url']}
        
        Escalation Time: {notification['escalation_time']}
        """
        
        try:
            ses.send_email(
                Source='noreply@pmi-agentic-ai.com',
                Destination={'ToAddresses': [reviewer_email]},
                Message={
                    'Subject': {
                        'Data': f"PMI Agentic AI: Review Required - {notification['priority'].upper()} Priority"
                    },
                    'Body': {
                        'Text': {'Data': email_body}
                    }
                }
            )
        except Exception as e:
            logger.error(f"Error sending email to {reviewer_email}: {str(e)}")
            
    def _continue_workflow(self, request_id: str, agent_name: str, human_feedback: Dict[str, Any]):
        """Continue workflow after human approval"""
        
        # Trigger next agent in the pipeline
        next_agent_mapping = {
            "master_researcher": "master_drafter",
            "master_drafter": "master_reviewer",
            "master_reviewer": "completed"
        }
        
        next_agent = next_agent_mapping.get(agent_name)
        
        if next_agent == "completed":
            self._update_request_status(request_id, "completed")
        else:
            # Trigger next agent with human feedback incorporated
            self._trigger_next_agent(request_id, next_agent, human_feedback)
            
    def _handle_rejection(self, request_id: str, agent_name: str, feedback: Dict[str, Any], rationale: str):
        """Handle human rejection of agent output"""
        
        self._update_request_status(request_id, f"rejected_at_{agent_name}")
        
        # Log rejection details
        logger.info(f"Request {request_id} rejected at {agent_name}: {rationale}")
        
    def _handle_revision_request(self, request_id: str, agent_name: str, feedback: Dict[str, Any], rationale: str):
        """Handle human request for agent to revise output"""
        
        # Trigger agent to revise with human feedback
        self._trigger_agent_revision(request_id, agent_name, feedback, rationale)
        
    def _trigger_next_agent(self, request_id: str, agent_name: str, human_feedback: Dict[str, Any]):
        """Trigger the next agent in the workflow"""
        
        # This would integrate with Step Functions or direct Lambda invocation
        # Implementation depends on your orchestration choice
        pass
        
    def _trigger_agent_revision(self, request_id: str, agent_name: str, feedback: Dict[str, Any], rationale: str):
        """Trigger agent to revise its output based on human feedback"""
        
        # Implementation for agent revision workflow
        pass
