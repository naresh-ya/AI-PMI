"""
Pytest configuration and fixtures for PMI Agentic AI Platform tests
"""

import pytest
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


@pytest.fixture
def sample_request():
    """Sample document generation request for testing"""
    return {
        "description": "Create position paper on India excise taxation policy",
        "document_type": "Government Advocacy Letter",
        "topic": "Excise taxation framework for tobacco products",
        "jurisdiction": "India",
        "deadline": "2025-02-28",
        "target_audience": "Ministry of Finance, CBIC",
        "priority": "high"
    }


@pytest.fixture
def sample_research_output():
    """Sample research output for testing"""
    return {
        "research_strategy": {
            "primary_sources": ["CBIC notifications", "Budget documents"],
            "secondary_sources": ["Industry reports"],
            "research_domains": ["taxation", "regulatory compliance"]
        },
        "findings": [
            {
                "source": "CBIC Notification 2025",
                "content": "Sample finding content",
                "relevance_score": 0.95
            }
        ],
        "confidence_score": 85
    }


@pytest.fixture
def sample_hitl_checkpoint():
    """Sample HITL checkpoint for testing"""
    return {
        "hitl_id": "hitl_test_123",
        "request_id": "req_test_456",
        "agent_name": "master_researcher",
        "intervention_type": "approval_required",
        "status": "pending",
        "priority": "high",
        "human_reviewers": ["test.reviewer@pmi.com"]
    }


@pytest.fixture
def mock_bedrock_response():
    """Mock AWS Bedrock response for testing"""
    return {
        "completion": "This is a mock AI response for testing purposes.",
        "stop_reason": "end_turn"
    }
