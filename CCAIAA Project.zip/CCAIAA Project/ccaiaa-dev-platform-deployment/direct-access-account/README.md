# Direct Access Account

Deployment reference for application infrastructure in the tenant's **Direct Access** AWS account — Lambda, S3, Amplify, IAM, and related services.

**Status: placeholder.** No content has been migrated here yet. This file exists to reserve the folder's place in the repo structure; it does not yet describe real deployment steps.

---

## Scope (planned)

| Service | Purpose |
|---|---|
| Lambda | (to be documented) |
| S3 | (to be documented) |
| Amplify | (to be documented) |
| IAM | Role/policy definitions used by the above |

---

## Access

Access to this account is via AWS IAM role assumption (Direct Access), the same mechanism used in `litellm-account/guardrails/` — see that folder's `DEPLOYMENT_GUIDE.md` for the general pattern (personal AWS profile locally, role assumption for CI/CD) until this folder has its own documented setup.

---

## Next Steps

- [ ] Identify what deployment scripts/IaC already exist for Lambda, S3, and Amplify in this account
- [ ] Decide on a per-service subfolder structure (mirroring `litellm-account/guardrails/`'s numbered step-script pattern where it fits)
- [ ] Document account ID, region, and required IAM role/profile for this account
- [ ] Add a setup guide equivalent to `litellm-account/guardrails/DEPLOYMENT_GUIDE.md`
