# ccaiaa-dev-platform-deployment

Deployment reference code and setup guides for the AWS services behind the **ccaiaa-dev** tenant.

This is a **deployment/infra reference repo**, not application code. The application/agent codebase lives in a separate Bitbucket repository. What belongs here: scripts, configuration, and guides for creating and managing the AWS-side resources the application depends on.

---

## Scope

This repo covers two separate AWS accounts, each with its own access model:

| Account | Used for | Access mechanism |
|---|---|---|
| **Direct Access** | Lambda, S3, Amplify, and other application infrastructure | AWS IAM role assumption |
| **LiteLLM** | LLM Gateway configuration, guardrails | OAuth2 client credentials (Vault-sourced) |

Out of scope: application/agent source code (separate repo), guardrail *policy* decisions (tracked with InfoSec separately, not here).

---

## Structure

```
ccaiaa-dev-platform-deployment/
├── README.md                        <- this file
├── docs/                            <- architecture notes, access request process
├── direct-access-account/           <- Lambda, S3, Amplify, IAM, etc.
└── litellm-account/                 <- LLM Gateway config, guardrails
```

Each subfolder is expected to have its own `README.md` scoped to that account, and its own setup guide for whatever it deploys (e.g. `litellm-account/guardrails/DEPLOYMENT_GUIDE.md`).

---

## Before You Start

- Scripts in this repo assume you already have AWS access granted for the relevant account/role — this repo does not grant access, see `docs/` for the request process once populated.
- Secrets (Vault credentials, API keys) are never committed here. Every script that needs one reads from a local `.env`, created from an `.env.template` checked into the relevant subfolder.
- This repo will move to a CI/CD pipeline in the future; scripts are written so that only the AWS profile/credential resolution needs to change for that transition, not the deployment logic itself.

---

## Status

Structure and content are being populated incrementally. Currently in progress: `litellm-account/guardrails/`.
