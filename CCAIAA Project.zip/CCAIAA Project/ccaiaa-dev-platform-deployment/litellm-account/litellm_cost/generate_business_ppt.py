"""
Combined Business Cost PPT - CCAIAA & MMIANA
Platform AWS (LiteLLM) + Local AWS accounts
June - August 2026
"""
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

OUTPUT_DIR = os.path.dirname(__file__)

# Colors
DARK_BLUE = RGBColor(0x1B, 0x2A, 0x4A)
MID_BLUE = RGBColor(0x2C, 0x5F, 0x8A)
LIGHT_BLUE = RGBColor(0x3D, 0x8B, 0xD4)
ACCENT_ORANGE = RGBColor(0xF5, 0x7C, 0x00)
ACCENT_GREEN = RGBColor(0x2E, 0x7D, 0x32)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY = RGBColor(0xF5, 0xF5, 0xF5)
DARK_GRAY = RGBColor(0x42, 0x42, 0x42)
MEDIUM_GRAY = RGBColor(0x75, 0x75, 0x75)
CCAIAA_COLOR = "#2196F3"
MMIANA_COLOR = "#F57C00"

# ============================================================================
# DATA
# ============================================================================

# Platform AWS (LiteLLM) - from Cost API
platform = {
    "CCAIAA": {"June 2026": 491.28, "July 2026": 1089.28, "August 2026": 494.27},
    "MMIANA": {"June 2026": 760.90, "July 2026": 1020.21, "August 2026": 1274.37},
}

# Local AWS accounts - from AWS Cost Explorer
local = {
    "CCAIAA": {"June 2026": 386.27, "July 2026": 1058.47, "August 2026": 373.99},
    "MMIANA": {"June 2026": 2312.52, "July 2026": 542.05, "August 2026": 467.75},
}

# Local AWS service breakdown (top services, 3-month approx)
local_services = {
    "CCAIAA": {
        "Bedrock (Claude direct)": 1225.0,
        "OpenSearch Service": 286.7,
        "VPC": 119.9,
        "Security Hub": 36.0,
        "DynamoDB": 18.8,
        "WAF": 30.0,
        "Lambda + AgentCore": 14.0,
        "Other + Tax": 88.3,
    },
    "MMIANA": {
        "Bedrock (Claude direct)": 2461.5,
        "Bedrock AgentCore": 400.0,
        "VPC": 110.9,
        "Load Balancing": 42.6,
        "Security Hub": 39.5,
        "Inspector": 23.5,
        "Lambda + Amplify": 25.6,
        "Other + Tax": 158.7,
    },
}

# August daily LiteLLM (platform) cost - excluding licence - FULL MONTH (Aug 1-31)
daily_aug = {
    "CCAIAA": [6.22, 2.82, 6.36, 7.97, 9.10, 28.78, 18.68, 2.99, 2.80, 14.89,
               19.45, 15.52, 9.51, 18.09, 2.80, 2.80, 9.57, 10.10, 7.32, 66.61,
               5.19, 0.46, 2.80, 16.06, 7.39, 0.52, 7.02, 3.07, 3.08, 2.80, 2.80],
    "MMIANA": [6.22, 2.85, 61.00, 79.56, 23.53, 101.78, 42.24, 2.79, 3.55, 14.26,
               165.91, 87.76, 169.18, 27.69, 2.87, 2.87, 8.33, 3.01, 46.30, 26.01,
               58.32, 80.87, 2.87, 19.67, 17.96, 16.96, 24.91, 4.32, 2.79, 2.87, 3.90],
}
daily_labels = [f"Aug {i}" for i in range(1, 32)]

months = ["June 2026", "July 2026", "August 2026"]

# Compute totals
def total(d, product):
    return sum(d[product].values())

ccaiaa_platform_total = total(platform, "CCAIAA")
ccaiaa_local_total = total(local, "CCAIAA")
mmiana_platform_total = total(platform, "MMIANA")
mmiana_local_total = total(local, "MMIANA")

ccaiaa_grand = ccaiaa_platform_total + ccaiaa_local_total
mmiana_grand = mmiana_platform_total + mmiana_local_total


# ============================================================================
# CHARTS
# ============================================================================

def chart_grand_total():
    """Overall: Platform vs Local for both products"""
    fig, ax = plt.subplots(figsize=(10, 6))
    products = ["CCAIAA", "MMIANA"]
    platform_vals = [ccaiaa_platform_total, mmiana_platform_total]
    local_vals = [ccaiaa_local_total, mmiana_local_total]
    x = np.arange(len(products))
    width = 0.5
    b1 = ax.bar(x, platform_vals, width, label="Platform AWS (LiteLLM)", color="#2196F3")
    b2 = ax.bar(x, local_vals, width, bottom=platform_vals, label="Local AWS Account", color="#F57C00")
    ax.set_ylabel("Cost (USD)")
    ax.set_title("Total 3-Month Cost by Product (Jun-Aug 2026)")
    ax.set_xticks(x)
    ax.set_xticklabels(products)
    ax.legend()
    for i, p in enumerate(products):
        grand = platform_vals[i] + local_vals[i]
        ax.text(i, grand + 50, f"${grand:,.0f}", ha="center", fontweight="bold", fontsize=13)
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/biz_chart_grand_total.png"
    plt.savefig(path, dpi=150); plt.close()
    print(f"Chart: {path}")


def chart_monthly_combined(product, color2):
    """Monthly Platform + Local stacked for one product"""
    fig, ax = plt.subplots(figsize=(9, 5.5))
    plat = [platform[product][m] for m in months]
    loc = [local[product][m] for m in months]
    x = np.arange(len(months))
    width = 0.5
    ax.bar(x, plat, width, label="Platform AWS (LiteLLM)", color="#2196F3")
    ax.bar(x, loc, width, bottom=plat, label="Local AWS", color=color2)
    ax.set_ylabel("Cost (USD)")
    ax.set_title(f"{product} - Monthly Cost (Platform + Local)")
    ax.set_xticks(x)
    ax.set_xticklabels([m.replace(" 2026", "") for m in months])
    ax.legend()
    for i in range(len(months)):
        t = plat[i] + loc[i]
        ax.text(i, t + 20, f"${t:,.0f}", ha="center", fontweight="bold")
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/biz_chart_monthly_{product.lower()}.png"
    plt.savefig(path, dpi=150); plt.close()
    print(f"Chart: {path}")


def chart_local_services(product):
    """Local AWS service breakdown pie"""
    fig, ax = plt.subplots(figsize=(8, 6))
    svc = local_services[product]
    labels = list(svc.keys())
    values = list(svc.values())
    colors = plt.cm.tab20(np.linspace(0, 1, len(labels)))
    ax.pie(values, labels=labels, autopct=lambda p: f"${p*sum(values)/100:.0f}",
           colors=colors, startangle=90, textprops={"fontsize": 9})
    ax.set_title(f"{product} - Local AWS Cost by Service (3-Month)", fontsize=12)
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/biz_chart_services_{product.lower()}.png"
    plt.savefig(path, dpi=150); plt.close()
    print(f"Chart: {path}")


def chart_daily_litellm():
    """August daily LiteLLM cost - both products"""
    fig, ax = plt.subplots(figsize=(13, 5.5))
    x = np.arange(len(daily_labels))
    width = 0.4
    ax.bar(x - width/2, daily_aug["CCAIAA"], width, label="CCAIAA", color="#2196F3")
    ax.bar(x + width/2, daily_aug["MMIANA"], width, label="MMIANA", color="#F57C00")
    ax.set_ylabel("Cost (USD)")
    ax.set_xlabel("Day (August 2026)")
    ax.set_title("Daily LiteLLM Cost - August 2026 (excludes fixed licence)")
    ax.set_xticks(x)
    ax.set_xticklabels([str(i) for i in range(1, 32)])
    ax.legend()
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/biz_chart_daily_litellm.png"
    plt.savefig(path, dpi=150); plt.close()
    print(f"Chart: {path}")


# ============================================================================
# PPT HELPERS
# ============================================================================

def add_text(slide, l, t, w, h, text, size=18, bold=False, color=DARK_GRAY, align=PP_ALIGN.LEFT):
    tb = slide.shapes.add_textbox(l, t, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.font.name = "Segoe UI"
    p.alignment = align
    return tb

def accent(slide, l, t, w):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, l, t, w, Pt(4))
    s.fill.solid(); s.fill.fore_color.rgb = ACCENT_ORANGE; s.line.fill.background()

def add_table(slide, l, t, w, h, data, highlight_last=False):
    rows, cols = len(data), len(data[0])
    ts = slide.shapes.add_table(rows, cols, l, t, w, h)
    table = ts.table
    for ri, row in enumerate(data):
        for ci, val in enumerate(row):
            cell = table.cell(ri, ci)
            cell.text = str(val)
            p = cell.text_frame.paragraphs[0]
            p.font.size = Pt(11)
            p.font.name = "Segoe UI"
            if ri == 0:
                p.font.bold = True; p.font.color.rgb = WHITE
                cell.fill.solid(); cell.fill.fore_color.rgb = MID_BLUE
            elif highlight_last and ri == rows - 1:
                p.font.bold = True; p.font.color.rgb = DARK_BLUE
                cell.fill.solid(); cell.fill.fore_color.rgb = RGBColor(0xE3, 0xF2, 0xFD)
            else:
                p.font.color.rgb = DARK_GRAY
                if ri % 2 == 0:
                    cell.fill.solid(); cell.fill.fore_color.rgb = LIGHT_GRAY
            p.alignment = PP_ALIGN.CENTER if ci > 0 else PP_ALIGN.LEFT
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
    return ts


# ============================================================================
# BUILD PPT
# ============================================================================

def build():
    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    def dark(s):
        s.background.fill.solid(); s.background.fill.fore_color.rgb = DARK_BLUE
    def light(s):
        s.background.fill.solid(); s.background.fill.fore_color.rgb = WHITE

    # ---- Slide 1: Title ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); dark(s)
    add_text(s, Inches(1), Inches(1.8), Inches(11.3), Inches(1.2),
             "GenAI Platform Cost Review", size=42, bold=True, color=WHITE)
    add_text(s, Inches(1), Inches(3.0), Inches(11.3), Inches(0.8),
             "CCAIAA & MMIANA - Platform and Local AWS Costs", size=24, color=LIGHT_BLUE)
    accent(s, Inches(1), Inches(2.9), Inches(3))
    add_text(s, Inches(1), Inches(4.0), Inches(11.3), Inches(0.6),
             "Reporting Period: June - August 2026", size=16, color=MEDIUM_GRAY)
    add_text(s, Inches(1), Inches(6.5), Inches(11.3), Inches(0.4),
             "Confidential | Prepared for Business Review", size=11, color=MEDIUM_GRAY)

    # ---- Slide 2: Executive Summary ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Executive Summary", size=28, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))

    grand_all = ccaiaa_grand + mmiana_grand
    kpis = [
        (f"${grand_all:,.0f}", "Total (Both Products)"),
        (f"${ccaiaa_grand:,.0f}", "CCAIAA Total"),
        (f"${mmiana_grand:,.0f}", "MMIANA Total"),
    ]
    for i, (v, lbl) in enumerate(kpis):
        left = Inches(0.7 + i * 4.15)
        box = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, Inches(1.35), Inches(3.9), Inches(1.5))
        box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0xF0, 0xF4, 0xF8)
        box.line.color.rgb = RGBColor(0xE0, 0xE0, 0xE0)
        add_text(s, left, Inches(1.5), Inches(3.9), Inches(0.8), v, size=30, bold=True, color=DARK_BLUE, align=PP_ALIGN.CENTER)
        add_text(s, left, Inches(2.25), Inches(3.9), Inches(0.5), lbl, size=13, color=MEDIUM_GRAY, align=PP_ALIGN.CENTER)

    summary_table = [
        ["Product", "Platform AWS", "Local AWS", "Total"],
        ["CCAIAA", f"${ccaiaa_platform_total:,.0f}", f"${ccaiaa_local_total:,.0f}", f"${ccaiaa_grand:,.0f}"],
        ["MMIANA", f"${mmiana_platform_total:,.0f}", f"${mmiana_local_total:,.0f}", f"${mmiana_grand:,.0f}"],
        ["TOTAL", f"${ccaiaa_platform_total+mmiana_platform_total:,.0f}",
         f"${ccaiaa_local_total+mmiana_local_total:,.0f}", f"${grand_all:,.0f}"],
    ]
    add_table(s, Inches(0.7), Inches(3.2), Inches(12), Inches(1.8), summary_table, highlight_last=True)

    add_text(s, Inches(0.7), Inches(5.3), Inches(12), Inches(1.8),
             "Key Points:\n"
             "  - Total spend across both products and both AWS environments: "
             f"${grand_all:,.0f} over 3 months\n"
             "  - 'Platform AWS' = LLM Gateway (LiteLLM) usage; 'Local AWS' = application infrastructure per product\n"
             "  - Direct Bedrock (Claude) calls in local accounts are the single largest cost driver for both products\n"
             "  - MMIANA has higher overall spend, driven by higher token volume and direct Bedrock usage",
             size=12, color=DARK_GRAY)

    # ---- Slide 3: Grand Total Chart ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Total Cost: Platform vs Local AWS", size=28, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
    s.shapes.add_picture(f"{OUTPUT_DIR}/biz_chart_grand_total.png", Inches(0.6), Inches(1.3), Inches(7.5), Inches(4.6))
    tbl = [
        ["", "CCAIAA", "MMIANA"],
        ["Platform AWS", f"${ccaiaa_platform_total:,.0f}", f"${mmiana_platform_total:,.0f}"],
        ["Local AWS", f"${ccaiaa_local_total:,.0f}", f"${mmiana_local_total:,.0f}"],
        ["Total", f"${ccaiaa_grand:,.0f}", f"${mmiana_grand:,.0f}"],
    ]
    add_table(s, Inches(8.4), Inches(1.6), Inches(4.5), Inches(2.2), tbl, highlight_last=True)
    add_text(s, Inches(8.4), Inches(4.2), Inches(4.4), Inches(2.5),
             "Platform AWS costs are similar between products. The gap in total cost "
             "comes mainly from Local AWS - specifically direct Amazon Bedrock (Claude) "
             "usage, which is billed in each product's own account separately from the "
             "LiteLLM Gateway.", size=11, color=DARK_GRAY)

    # ---- Slide 4: CCAIAA Monthly ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "CCAIAA - Monthly Cost Breakdown", size=28, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
    s.shapes.add_picture(f"{OUTPUT_DIR}/biz_chart_monthly_ccaiaa.png", Inches(0.6), Inches(1.3), Inches(7.2), Inches(4.4))
    tbl = [
        ["Month", "Platform", "Local", "Total"],
        ["June", f"${platform['CCAIAA']['June 2026']:,.0f}", f"${local['CCAIAA']['June 2026']:,.0f}",
         f"${platform['CCAIAA']['June 2026']+local['CCAIAA']['June 2026']:,.0f}"],
        ["July", f"${platform['CCAIAA']['July 2026']:,.0f}", f"${local['CCAIAA']['July 2026']:,.0f}",
         f"${platform['CCAIAA']['July 2026']+local['CCAIAA']['July 2026']:,.0f}"],
        ["August", f"${platform['CCAIAA']['August 2026']:,.0f}", f"${local['CCAIAA']['August 2026']:,.0f}",
         f"${platform['CCAIAA']['August 2026']+local['CCAIAA']['August 2026']:,.0f}"],
        ["Total", f"${ccaiaa_platform_total:,.0f}", f"${ccaiaa_local_total:,.0f}", f"${ccaiaa_grand:,.0f}"],
    ]
    add_table(s, Inches(8.1), Inches(1.6), Inches(4.8), Inches(2.6), tbl, highlight_last=True)
    add_text(s, Inches(8.1), Inches(4.6), Inches(4.6), Inches(2),
             "July peaked on both fronts due to intensive development. "
             "August normalized. Local AWS account: 603433800649.",
             size=11, color=DARK_GRAY)

    # ---- Slide 5: MMIANA Monthly ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "MMIANA - Monthly Cost Breakdown", size=28, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
    s.shapes.add_picture(f"{OUTPUT_DIR}/biz_chart_monthly_mmiana.png", Inches(0.6), Inches(1.3), Inches(7.2), Inches(4.4))
    tbl = [
        ["Month", "Platform", "Local", "Total"],
        ["June", f"${platform['MMIANA']['June 2026']:,.0f}", f"${local['MMIANA']['June 2026']:,.0f}",
         f"${platform['MMIANA']['June 2026']+local['MMIANA']['June 2026']:,.0f}"],
        ["July", f"${platform['MMIANA']['July 2026']:,.0f}", f"${local['MMIANA']['July 2026']:,.0f}",
         f"${platform['MMIANA']['July 2026']+local['MMIANA']['July 2026']:,.0f}"],
        ["August", f"${platform['MMIANA']['August 2026']:,.0f}", f"${local['MMIANA']['August 2026']:,.0f}",
         f"${platform['MMIANA']['August 2026']+local['MMIANA']['August 2026']:,.0f}"],
        ["Total", f"${mmiana_platform_total:,.0f}", f"${mmiana_local_total:,.0f}", f"${mmiana_grand:,.0f}"],
    ]
    add_table(s, Inches(8.1), Inches(1.6), Inches(4.8), Inches(2.6), tbl, highlight_last=True)
    add_text(s, Inches(8.1), Inches(4.6), Inches(4.6), Inches(2),
             "June local AWS was very high ($2,313) due to heavy direct Bedrock usage. "
             "Costs decreased over the following months. Local AWS account: 986995923613.",
             size=11, color=DARK_GRAY)

    # ---- Slide 6: CCAIAA Local Services ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "CCAIAA - Local AWS Service Breakdown", size=28, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
    s.shapes.add_picture(f"{OUTPUT_DIR}/biz_chart_services_ccaiaa.png", Inches(0.6), Inches(1.4), Inches(6.8), Inches(5.2))
    svc = local_services["CCAIAA"]
    rows = [["Service", "3-Mo Cost"]] + [[k, f"${v:,.0f}"] for k, v in svc.items()]
    add_table(s, Inches(7.8), Inches(1.5), Inches(5.0), Inches(4.2), rows)

    # ---- Slide 7: MMIANA Local Services ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "MMIANA - Local AWS Service Breakdown", size=28, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
    s.shapes.add_picture(f"{OUTPUT_DIR}/biz_chart_services_mmiana.png", Inches(0.6), Inches(1.4), Inches(6.8), Inches(5.2))
    svc = local_services["MMIANA"]
    rows = [["Service", "3-Mo Cost"]] + [[k, f"${v:,.0f}"] for k, v in svc.items()]
    add_table(s, Inches(7.8), Inches(1.5), Inches(5.0), Inches(4.2), rows)

    # ---- Slide 8: Daily LiteLLM ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Daily LiteLLM (Platform) Cost - August 2026", size=26, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
    s.shapes.add_picture(f"{OUTPUT_DIR}/biz_chart_daily_litellm.png", Inches(0.4), Inches(1.3), Inches(12.6), Inches(4.4))
    add_text(s, Inches(0.7), Inches(5.9), Inches(12), Inches(1.3),
             "Full-month daily platform cost (Aug 1-31, excludes the fixed $200/month licence billed on the 1st). "
             "MMIANA shows several high-usage days (Aug 11, 13, 22) reflecting heavier Claude Sonnet 4 traffic. "
             "CCAIAA maintains a steadier, lower daily profile with an occasional spike (Aug 20). "
             "Both taper off toward month-end.",
             size=12, color=DARK_GRAY)

    # ---- Slide 9: Observations & Recommendations ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); light(s)
    add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Observations & Recommendations", size=28, bold=True, color=DARK_BLUE)
    accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
    add_text(s, Inches(0.7), Inches(1.3), Inches(12), Inches(0.5), "Observations", size=16, bold=True, color=DARK_BLUE)
    obs = [
        "Direct Amazon Bedrock (Claude) usage in local accounts is the top cost for both products",
        "This is separate from LiteLLM Gateway cost - both channels invoke Claude models",
        "OpenSearch (CCAIAA) and AgentCore/Load Balancing (MMIANA) are notable fixed infrastructure costs",
        "MMIANA's higher total is driven by token volume (168M/month vs 24M/month for CCAIAA)",
    ]
    for i, o in enumerate(obs):
        add_text(s, Inches(1.0), Inches(1.75 + i*0.45), Inches(11.5), Inches(0.4), f"  {o}", size=12, color=DARK_GRAY)

    add_text(s, Inches(0.7), Inches(3.7), Inches(12), Inches(0.5), "Recommendations", size=16, bold=True, color=ACCENT_GREEN)
    recs = [
        "Consolidate LLM traffic through a single channel (LiteLLM Gateway) for unified cost tracking & guardrails",
        "Enable Bedrock prompt caching - can reduce input token cost by 50-90%",
        "Offload simpler tasks to Claude Haiku (approx. 10x cheaper than Sonnet)",
        "Review OpenSearch and Load Balancer sizing against actual utilization",
        "Disable LangSmith tracing in production once systems are stable",
    ]
    for i, r in enumerate(recs):
        add_text(s, Inches(1.0), Inches(4.15 + i*0.45), Inches(11.5), Inches(0.4), f"  {r}", size=12, color=DARK_GRAY)

    # ---- Slide 10: Thank You ----
    s = prs.slides.add_slide(prs.slide_layouts[6]); dark(s)
    add_text(s, Inches(1), Inches(2.5), Inches(11.3), Inches(1.2), "Thank You", size=44, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    accent(s, Inches(5.5), Inches(3.5), Inches(2.5))
    add_text(s, Inches(1), Inches(4.0), Inches(11.3), Inches(0.8), "Questions & Discussion", size=22, color=LIGHT_BLUE, align=PP_ALIGN.CENTER)
    add_text(s, Inches(1), Inches(5.5), Inches(11.3), Inches(1),
             "CCAIAA & MMIANA | GenAI Platform Cost Review\nReporting Period: June - August 2026",
             size=12, color=MEDIUM_GRAY, align=PP_ALIGN.CENTER)

    out = f"{OUTPUT_DIR}/Business_Cost_Review_CCAIAA_MMIANA_Jun_Aug_2026.pptx"
    prs.save(out)
    print(f"\nPPT saved: {out}")
    print(f"Slides: {len(prs.slides)}")


if __name__ == "__main__":
    print("Generating combined business cost PPT...\n")
    chart_grand_total()
    chart_monthly_combined("CCAIAA", MMIANA_COLOR)
    chart_monthly_combined("MMIANA", MMIANA_COLOR)
    chart_local_services("CCAIAA")
    chart_local_services("MMIANA")
    chart_daily_litellm()
    build()
    print("\nDone!")
