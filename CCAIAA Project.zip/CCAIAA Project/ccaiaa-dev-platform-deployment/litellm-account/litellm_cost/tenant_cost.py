"""
tenant_cost.py

Query the GenAI Platform's Unified Cost API for your tenant's aggregate
spend - the tenant-scoped equivalent of AWS Cost Explorer for this platform.

Docs:
- https://docs.aiplat.aws.private-pmideep.biz/features/observability/cost-api
- https://docs.aiplat.aws.private-pmideep.biz/features/llm-model-access/monitor-model-cost-api

Endpoints used (Custom API, JWT auth):
    GET /api/cost/v1/tenants/{tenant_id}/daily?date=YYYY-MM-DD
    GET /api/cost/v1/tenants/{tenant_id}/range?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD

IMPORTANT - coverage of this API (per the docs, as of this writing):
    LiteLLM LLM calls      -> Yes, tracked
    Custom API LLM calls   -> Yes, tracked
    Direct Access LLM calls-> Yes, tracked
    Batch Inference        -> NOT tracked (billed retroactively via AWS CUR)
    Knowledge Bases        -> In progress (not yet available)
    LangSmith              -> In progress (not yet available)
    Guardrails             -> In progress (not yet available)

So today this gives you accurate LLM-call cost for the tenant, but NOT yet
the Knowledge Base (OpenSearch) portion of your spend. There is currently no
tenant-facing way to isolate KB cost - watch the Cost Dashboards
(https://docs.aiplat.aws.private-pmideep.biz/features/observability/cost-dashboards)
page, the platform team is actively adding this coverage.

Usage:
    python tenant_cost.py daily 2026-08-11
    python tenant_cost.py daily                      # defaults to today (UTC)
    python tenant_cost.py range 2026-08-01 2026-08-11
    python tenant_cost.py range                       # defaults to last 7 days
"""

import json
import os
import sys
from datetime import date, timedelta

import requests
import urllib3

from auth import get_access_token, TENANT_NAME

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# This matches the base URL used in the platform docs' own curl examples for
# this endpoint. Override with COST_API_BASE_URL in .env if your tenant has
# migrated to the private-domain equivalent (see Endpoints Guide).
COST_API_BASE_URL = os.environ.get(
    "COST_API_BASE_URL", "https://aiplat-dev.aws.pmicloud.biz/api/cost/v1"
)


def _get(path: str, params: dict) -> dict:
    token = get_access_token()
    url = f"{COST_API_BASE_URL}/tenants/{TENANT_NAME}/{path}"
    resp = requests.get(
        url,
        headers={"Authorization": f"Bearer {token}"},
        params=params,
        verify=False,
        timeout=30,
    )
    if not resp.ok:
        print(f"Request failed: GET {resp.url}")
        print(f"HTTP {resp.status_code}: {resp.text}")
        resp.raise_for_status()
    return resp.json()


def daily_cost(day: str) -> dict:
    """GET /tenants/{tenant}/daily?date=YYYY-MM-DD"""
    return _get("daily", {"date": day})


def range_cost(start: str, end: str) -> dict:
    """GET /tenants/{tenant}/range?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD"""
    return _get("range", {"start_date": start, "end_date": end})


def _pretty_print(label: str, data: dict):
    print("-" * 70)
    print(label)
    print("-" * 70)
    print(json.dumps(data, indent=2, default=str))


def main():
    args = sys.argv[1:]
    mode = args[0] if args else "daily"

    print(f"Tenant       : {TENANT_NAME}")
    print(f"Cost API base: {COST_API_BASE_URL}\n")

    try:
        if mode == "daily":
            day = args[1] if len(args) > 1 else date.today().isoformat()
            data = daily_cost(day)
            _pretty_print(f"DAILY COST for {TENANT_NAME} on {day}", data)

        elif mode == "range":
            if len(args) >= 3:
                start, end = args[1], args[2]
            else:
                end_d = date.today()
                start_d = end_d - timedelta(days=7)
                start, end = start_d.isoformat(), end_d.isoformat()
            data = range_cost(start, end)
            _pretty_print(f"RANGE COST for {TENANT_NAME} ({start} -> {end})", data)

        else:
            print(f"Unknown mode '{mode}'. Use 'daily' or 'range'.")
            sys.exit(1)

    except requests.HTTPError:
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
