"""
monthly_model_cost.py

All-model cost breakdown for a full calendar month, using the platform's
Unified Cost API (/range endpoint). Answers: "for August 2026, what did
each model cost, and what's the total?"

Docs:
- https://docs.aiplat.aws.private-pmideep.biz/features/observability/cost-api

Verified live against tenant ccaiaa-dev for 2026-08-01 -> 2026-08-31:
  total_cost:          $486.88
  total_cost_litellm:  $157.36  (all LLM + Tavily model calls through the gateway)
  total_cost_langsmith:$55.69
  total_cost_infra:    $68.64   (EC2 + OpenSearch)
  10 distinct models, e.g. bedrock/us.anthropic.claude-opus-4-8 ($65.07),
  bedrock/us.anthropic.claude-sonnet-4-6 ($60.74), gemini-2.5-pro ($28.02), ...

Usage:
    python monthly_model_cost.py                  # current calendar month
    python monthly_model_cost.py 2026-08           # a specific month (YYYY-MM)
    python monthly_model_cost.py 2026-08 --csv     # also write a CSV breakdown
    python monthly_model_cost.py 2026-08 --json out.json   # save raw JSON too
"""

import argparse
import calendar
import csv
import json
import sys
from datetime import date

import requests

from auth import get_access_token, TENANT_NAME, MGMT_API_BASE_URL  # noqa: F401  (MGMT_API_BASE_URL re-exported for sibling scripts)
from tenant_cost import range_cost


def month_bounds(yyyymm: str) -> tuple[str, str]:
    """'2026-08' -> ('2026-08-01', '2026-08-31')."""
    year, month = (int(x) for x in yyyymm.split("-"))
    last_day = calendar.monthrange(year, month)[1]
    return f"{year:04d}-{month:02d}-01", f"{year:04d}-{month:02d}-{last_day:02d}"


def fetch_month(yyyymm: str) -> dict:
    start, end = month_bounds(yyyymm)
    print(f"Tenant : {TENANT_NAME}")
    print(f"Month  : {yyyymm}  ({start} -> {end})\n")
    return range_cost(start, end)


def print_summary(data: dict, yyyymm: str):
    print("=" * 72)
    print(f"MONTHLY COST SUMMARY - {yyyymm} - tenant {data.get('tenant_id')}")
    print("=" * 72)
    print(f"  TOTAL COST (all sources)     : ${data.get('total_cost', 0):.4f}")
    print(f"    - LiteLLM (LLM + Tavily)   : ${data.get('total_cost_litellm', 0):.4f}")
    print(f"    - LangSmith (agents/traces): ${data.get('total_cost_langsmith', 0):.4f}")
    print(f"    - Tavily (web search)      : ${data.get('total_cost_tavily', 0):.4f}")
    print(f"    - Infra (EC2/OpenSearch)   : ${data.get('total_cost_infra', 0):.4f}")
    print(f"    - AWS Direct Access        : ${data.get('total_cost_aws', 0):.4f}")
    print(f"    - Azure OpenAI             : ${data.get('total_cost_azure', 0):.4f}")

    models = data.get("models", {})
    print(f"\n  ALL MODELS ({len(models)} distinct) - sorted by cost desc:")
    print(f"  {'MODEL':<62} {'COST ($)':>12} {'IN TOK':>12} {'OUT TOK':>12}")
    print("  " + "-" * 100)
    rows = sorted(models.items(), key=lambda kv: kv[1].get("total_cost", 0), reverse=True)
    for model_name, m in rows:
        print(
            f"  {model_name:<62} {m.get('total_cost', 0):>12.4f} "
            f"{int(m.get('total_input_tokens', 0)):>12,} {int(m.get('total_output_tokens', 0)):>12,}"
        )

    infra = data.get("infra", {})
    if infra:
        print(f"\n  INFRA BREAKDOWN:")
        for k, v in infra.items():
            cost = v.get("cost", v.get("storage_cost", 0))
            print(f"    {k:<20}: ${cost:.6f}")

    langsmith = data.get("langsmith", {})
    if langsmith:
        print(f"\n  LANGSMITH BREAKDOWN:")
        print(f"    total_traces          : {int(langsmith.get('total_traces', 0)):,}")
        print(f"    total_deployment_runs  : {int(langsmith.get('total_deployment_runs', 0)):,}")

    search = data.get("search", {}).get("tavily", {})
    if search:
        print(f"\n  TAVILY BREAKDOWN:")
        print(f"    request_count          : {int(search.get('request_count', 0)):,}")
        print(f"    total_credits          : {int(search.get('total_credits', 0)):,}")


def write_csv(data: dict, path: str):
    models = data.get("models", {})
    rows = sorted(models.items(), key=lambda kv: kv[1].get("total_cost", 0), reverse=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["model", "cost_usd", "input_tokens", "output_tokens", "cache_read_tokens", "cache_write_tokens"])
        for model_name, m in rows:
            writer.writerow([
                model_name,
                f"{m.get('total_cost', 0):.8f}",
                int(m.get("total_input_tokens", 0)),
                int(m.get("total_output_tokens", 0)),
                int(m.get("total_cache_read_tokens", 0)),
                int(m.get("total_cache_write_tokens", 0)),
            ])
    print(f"\nCSV written: {path}")


def main():
    parser = argparse.ArgumentParser(description="All-model cost breakdown for a calendar month")
    parser.add_argument("month", nargs="?", default=date.today().strftime("%Y-%m"), help="YYYY-MM, default: current month")
    parser.add_argument("--csv", nargs="?", const="", default=None, help="Write a CSV breakdown (optional path, default: model_cost_<month>.csv)")
    parser.add_argument("--json", default=None, help="Also save the raw JSON response to this path")
    args = parser.parse_args()

    try:
        data = fetch_month(args.month)
    except requests.HTTPError as e:
        print(f"Request failed: {e}")
        sys.exit(1)

    print_summary(data, args.month)

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(f"\nRaw JSON written: {args.json}")

    if args.csv is not None:
        csv_path = args.csv or f"model_cost_{args.month}.csv"
        write_csv(data, csv_path)


if __name__ == "__main__":
    main()
