"""
auth.py

Shared helper to get a JWT access token for the GenAI Platform's Custom API
(the same API surface the Unified Cost API lives under).

This mirrors the OAuth client-credentials flow already used elsewhere in this
repo (see ../get_mgmt_api_token.py), extracted here so the cost scripts in
this folder don't need Vault access every run - just the OAUTH_CLIENT_ID /
OAUTH_CLIENT_SECRET already saved in genai-platform/.env.

Docs:
- https://docs.aiplat.aws.private-pmideep.biz/features/self-service/custom-api
  (Programmatic Access / JWT Authentication section)

Flow:
    1. Base64-encode "client_id:client_secret" -> Basic auth header
    2. POST to the Cognito token endpoint with grant_type=client_credentials
       and scope=https://<domain>/tenant
    3. Receive a JWT access_token, valid for 1 hour
    4. Send it as "Authorization: Bearer <token>" on Cost API / Custom API calls

Note: this token is DIFFERENT from the LiteLLM API key (AWS_BEARER_TOKEN_BEDROCK)
used in single_request_cost.py. The LiteLLM key talks to the LLM Gateway;
this JWT talks to the platform's Custom/Management API (which is what the
Unified Cost API is part of).
"""

import base64
import os
from pathlib import Path

import requests
import urllib3
from dotenv import load_dotenv

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Load the parent genai-platform/.env first as a base (so unrelated secrets
# used by other scripts in that folder are still available), then load a
# local litellm_cost/.env on top so this folder is self-contained - only the
# 3 keys below are actually required here (see .env / README.md):
#   LITELLM_TENANT_NAME, OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET
PARENT_ENV_PATH = Path(__file__).resolve().parent.parent / ".env"
LOCAL_ENV_PATH = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=PARENT_ENV_PATH, override=False)
load_dotenv(dotenv_path=LOCAL_ENV_PATH, override=True)

# Same DEV endpoint used by ../get_mgmt_api_token.py. Override via env vars
# if you need QA/PRD - see the Endpoint URLs Guide for those values.
COGNITO_TOKEN_ENDPOINT = os.environ.get(
    "COGNITO_TOKEN_ENDPOINT",
    "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token",
)
# Per the platform docs, only the shared "/tenant" scope is required -
# the tenant is identified automatically from the client credentials.
COST_API_SCOPE = os.environ.get("COST_API_SCOPE", "https://aiplat-dev.aws.pmicloud.biz/tenant")

CLIENT_ID = os.environ.get("OAUTH_CLIENT_ID") or os.environ.get("CUSTOM_API_CLIENT_ID")
CLIENT_SECRET = os.environ.get("OAUTH_CLIENT_SECRET") or os.environ.get("CUSTOM_API_CLIENT_SECRET")

TENANT_NAME = os.environ.get("LITELLM_TENANT_NAME", "ccaiaa-dev")

# Management API base (key creation/update, team budget, guardrails, callbacks).
# Same host as the Cost API, different path prefix - see Endpoint URLs Guide.
MGMT_API_BASE_URL = os.environ.get(
    "MGMT_API_BASE_URL", "https://aiplat-dev.aws.pmicloud.biz/api/litellm-mgmt"
)


def get_access_token() -> str:
    """
    Exchange OAUTH_CLIENT_ID / OAUTH_CLIENT_SECRET (from .env) for a fresh
    JWT access token. Tokens expire after 1 hour, so this is called fresh
    on every script run rather than being cached to disk.
    """
    if not CLIENT_ID or not CLIENT_SECRET:
        raise ValueError(
            "Missing OAuth client credentials.\n"
            "Set OAUTH_CLIENT_ID and OAUTH_CLIENT_SECRET in genai-platform/.env\n"
            "(same values used by ../get_mgmt_api_token.py - retrieved from Vault\n"
            "at static-secret/genai-dev/custom-api/<your-tenant-name>)."
        )

    credentials = f"{CLIENT_ID}:{CLIENT_SECRET}"
    auth_header = base64.b64encode(credentials.encode()).decode()

    response = requests.post(
        COGNITO_TOKEN_ENDPOINT,
        headers={
            "Authorization": f"Basic {auth_header}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data={
            "grant_type": "client_credentials",
            "scope": COST_API_SCOPE,
        },
        verify=False,  # PMI private CA - see "Trust PMI Certificates" guide for a permanent fix
        timeout=30,
    )
    response.raise_for_status()
    return response.json()["access_token"]


if __name__ == "__main__":
    # Quick standalone check: `python auth.py`
    try:
        token = get_access_token()
        print(f"Got token for tenant '{TENANT_NAME}': {token[:40]}...{token[-10:]}")
    except Exception as e:
        print(f"Failed to get token: {e}")
