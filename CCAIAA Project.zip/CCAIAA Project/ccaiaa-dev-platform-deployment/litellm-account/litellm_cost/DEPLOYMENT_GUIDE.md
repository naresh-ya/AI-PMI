# LiteLLM Cost Tracking

Quick reference for generating cost reports from the Platform Cost API.

---

## What This Does

- Generate detailed CSV reports for any date range (daily/weekly/monthly/yearly)
- Get quick monthly cost summaries
- Track LLM usage, tokens, and costs per model
- Analyze infrastructure and service costs

---

## Prerequisites

**1. Tools**
- Python 3.x and pip
- Access to Vault for credentials

**2. Install Python dependencies**
```bash
pip install -r requirements.txt
```

---

## Setup

**1. Copy the environment template**
```bash
cp .env.template .env
```

**2. Fill in credentials from Vault**

Edit `.env` and add your credentials:
- `OAUTH_CLIENT_ID` and `OAUTH_CLIENT_SECRET` from Vault: `static-secret/genai-dev/custom-api/<tenant>`
- `LITELLM_TENANT_NAME` is already set to `ccaiaa-dev`

**3. Run your first report**
```bash
python detail_cost_report.py 2026-08-01 2026-08-31
```

---

## Scripts

### `detail_cost_report.py` - Full CSV Report

Generates comprehensive CSV with all cost details, timestamps, and model breakdowns.

**Usage:**
```bash
# Generate report for a date range
python detail_cost_report.py 2026-08-01 2026-08-31

# Specify custom output file
python detail_cost_report.py 2026-08-01 2026-08-31 --out my_report.csv

# Single day report
python detail_cost_report.py 2026-08-15 2026-08-15

# Weekly report
python detail_cost_report.py 2026-08-01 2026-08-07

# Yearly report (takes several minutes)
python detail_cost_report.py 2026-01-01 2026-12-31
```

**Output:** CSV file with ~50-1500 rows depending on date range

**What's included:**
- Daily cost breakdowns by model, role, and service
- Token counts (input, output, cache read/write)
- Infrastructure costs (EC2, OpenSearch storage)
- LangSmith tracing costs
- Tavily web search costs
- Full timestamps (when data was created, updated, retrieved)
- Range summary for cross-checking

**See `CSV_GUIDE.md` for detailed instructions on reading and filtering the report.**

---

### `monthly_model_cost.py` - Quick Summary

Fast console summary showing total cost and top models for a month.

**Usage:**
```bash
# Current month
python monthly_model_cost.py

# Specific month
python monthly_model_cost.py 2026-08

# Export to CSV
python monthly_model_cost.py 2026-08 --csv

# Export to JSON
python monthly_model_cost.py 2026-08 --json output.json
```

**Output:** Console text or optional CSV/JSON

**Example output:**
```
TOTAL COST (all sources)     : $1089.28
  - LiteLLM (LLM + Tavily)   : $324.15
  - LangSmith (agents/traces): $112.50
  - Tavily (web search)      : $8.45
  - Infra (EC2/OpenSearch)   : $144.18

10 models, top 3 by cost:
  bedrock/us.anthropic.claude-opus-4-8     $142.35
  bedrock/us.anthropic.claude-sonnet-4-6   $128.67
  gemini-2.5-pro                            $48.92
```

---

## Understanding the Reports

### Cost Components

The platform tracks 7 cost sources:

1. **`total_cost_litellm`** - LLM model calls through the gateway
2. **`total_cost_tavily`** - Web search costs
3. **`total_cost_infra`** - Infrastructure (EC2 + OpenSearch storage)
4. **`total_cost_langsmith`** - Tracing and agent observability
5. **`total_cost_licence`** - Flat $200/month LiteLLM platform fee
6. **`total_cost_aws`** - AWS Direct Access (usually $0)
7. **`total_cost_azure`** - Azure models (usually $0)

**Important:** The $200 licence fee appears on the 1st of each billing month in daily reports. In range reports, it's calculated separately because the platform API doesn't expose it directly.

### Reading CSV Reports

The CSV has 5 main columns:
- **`date`** - Either a single day (2026-08-15) or range label (2026-08-01_to_2026-08-31)
- **`category`** - Type of data (total, model, role, infra, etc.)
- **`item`** - Specific thing being measured (model name, cost field, etc.)
- **`metric`** - What's being measured (cost_usd, input_tokens, etc.)
- **`value`** - The actual number

**Common filtering scenarios:**

1. **Total cost for the period:**
   - Filter: `category = range_total` AND `item = total_cost`

2. **Cost by model:**
   - Filter: `category = range_model` AND `metric = cost_usd`

3. **Daily cost trend:**
   - Filter: `category = total` AND `item = total_cost`

4. **Token usage per model:**
   - Filter: `category = model` AND `metric = input_tokens` (or `output_tokens`)

**See `CSV_GUIDE.md` for comprehensive filtering examples and detailed column explanations.**

---

## Known Limitations

These costs are **NOT tracked** by the Platform Cost API:

1. **Guardrails execution cost** - Guardrails are applied but their cost isn't exposed
2. **Knowledge Base OpenSearch compute** - Only storage cost is tracked, not retrieval/indexing compute
3. **Batch Inference cost** - Bypasses this API, billed separately via AWS

These gaps are documented in every CSV report as `coverage_gap` rows.

### Data Availability

- **Same-day data:** Not available until the next day (~1am UTC)
- **Historical gaps:** Days with zero activity may return 404 (no record created)
- **Updates:** The platform may revise past days' costs (check `record_updated_at_utc` timestamp)

---

## Production Readiness Gaps

This is a **reference implementation** for generating cost reports. For production use, consider adding:

- ❌ **Retry logic** - HTTP failures aren't retried automatically
- ❌ **Rate limiting** - Large date ranges (365 days) could hit API limits
- ❌ **Resume capability** - Failed long-running reports must restart from scratch
- ❌ **Scheduling/automation** - No cron or automated execution
- ❌ **Database storage** - CSV only, no persistent database
- ❌ **Budget alerts** - No threshold monitoring or notifications
- ❌ **Multi-tenant support** - Hardcoded to single tenant

**Recommendation:** Use a code assistant (Claude, ChatGPT, etc.) with this folder as context to add these features as needed.

---

## Troubleshooting

### "Module not found" errors
```bash
pip install -r requirements.txt
```

### "Authentication failed" errors
- Verify `.env` file exists and has correct credentials
- Check Vault for latest OAuth credentials
- Ensure `LITELLM_TENANT_NAME` matches your tenant

### "404 Not Found" for recent dates
- Same-day data isn't available until the next day
- Re-run the report tomorrow

### "404 Not Found" for old dates
- Days with zero activity may have no cost record
- This is expected behavior, not a bug

### Reports are slow for large date ranges
- Each day requires a separate API call
- A full year (365 days) takes 5-10 minutes
- Consider breaking into smaller ranges

---

## Sample Reports

The `sample_reports/` folder contains example CSV files:
- `monthly_july_2026.csv` - Clean monthly report with no errors (1,900 rows)

Use these to understand the output format before generating your own reports.

---

## Support

- **For API issues or platform questions:** Contact the GenAI Platform team
- **For script modifications or new features:** Use a code assistant (Claude, ChatGPT, etc.) with this folder as context
- **For report interpretation:** See `CSV_GUIDE.md`

---

## Related Documentation

- `CSV_GUIDE.md` - Comprehensive guide to reading and filtering CSV reports (715 lines)
- `.env.template` - Configuration template with Vault paths
- `sample_reports/` - Example CSV outputs
