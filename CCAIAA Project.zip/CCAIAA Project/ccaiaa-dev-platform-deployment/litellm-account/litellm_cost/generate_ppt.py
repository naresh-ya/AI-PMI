"""
Professional PowerPoint Presentation Generator
CCAIAA Workbench - GenAI Platform Cost Report (Jun-Aug 2026)
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.chart import XL_CHART_TYPE
from pptx.chart.data import CategoryChartData
import os

# Colors
DARK_BLUE = RGBColor(0x1B, 0x2A, 0x4A)
MID_BLUE = RGBColor(0x2C, 0x5F, 0x8A)
LIGHT_BLUE = RGBColor(0x3D, 0x8B, 0xD4)
ACCENT_ORANGE = RGBColor(0xF5, 0x7C, 0x00)
ACCENT_GREEN = RGBColor(0x2E, 0x7D, 0x32)
ACCENT_PURPLE = RGBColor(0x6A, 0x1B, 0x9A)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY = RGBColor(0xF5, 0xF5, 0xF5)
DARK_GRAY = RGBColor(0x42, 0x42, 0x42)
MEDIUM_GRAY = RGBColor(0x75, 0x75, 0x75)

prs = Presentation()
prs.slide_width = Inches(13.33)
prs.slide_height = Inches(7.5)


def add_dark_background(slide):
    """Add dark blue background"""
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = DARK_BLUE


def add_light_background(slide):
    """Add light background"""
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = WHITE


def add_text_box(slide, left, top, width, height, text, font_size=18,
                 bold=False, color=DARK_GRAY, alignment=PP_ALIGN.LEFT, font_name="Segoe UI"):
    """Helper to add a text box"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.font.name = font_name
    p.alignment = alignment
    return txBox


def add_accent_line(slide, left, top, width):
    """Add colored accent line"""
    shape = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, left, top, width, Pt(4)
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT_ORANGE
    shape.line.fill.background()


def add_table(slide, left, top, width, height, data, col_widths=None):
    """Add formatted table"""
    rows = len(data)
    cols = len(data[0])
    table_shape = slide.shapes.add_table(rows, cols, left, top, width, height)
    table = table_shape.table

    if col_widths:
        for i, w in enumerate(col_widths):
            table.columns[i].width = w

    for row_idx, row_data in enumerate(data):
        for col_idx, cell_text in enumerate(row_data):
            cell = table.cell(row_idx, col_idx)
            cell.text = str(cell_text)

            paragraph = cell.text_frame.paragraphs[0]
            paragraph.font.size = Pt(11)
            paragraph.font.name = "Segoe UI"

            if row_idx == 0:
                paragraph.font.bold = True
                paragraph.font.color.rgb = WHITE
                paragraph.font.size = Pt(11)
                cell.fill.solid()
                cell.fill.fore_color.rgb = MID_BLUE
            else:
                paragraph.font.color.rgb = DARK_GRAY
                if row_idx % 2 == 0:
                    cell.fill.solid()
                    cell.fill.fore_color.rgb = LIGHT_GRAY

            paragraph.alignment = PP_ALIGN.CENTER if col_idx > 0 else PP_ALIGN.LEFT
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE

    return table_shape


# ============================================================================
# SLIDE 1: Title Slide
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank
add_dark_background(slide)

# Title
add_text_box(slide, Inches(1), Inches(2), Inches(11), Inches(1.2),
             "CCAIAA Workbench", font_size=44, bold=True, color=WHITE)

# Subtitle
add_text_box(slide, Inches(1), Inches(3.2), Inches(11), Inches(0.8),
             "GenAI Platform Cost Analysis", font_size=28, color=LIGHT_BLUE)

# Date range
add_text_box(slide, Inches(1), Inches(4.2), Inches(11), Inches(0.6),
             "June - August 2026 | Tenant: ccaiaa-dev", font_size=16, color=MEDIUM_GRAY)

# Accent line
add_accent_line(slide, Inches(1), Inches(3.1), Inches(3))

# Footer
add_text_box(slide, Inches(1), Inches(6.5), Inches(11), Inches(0.4),
             "Confidential | Prepared for Business Review", font_size=11, color=MEDIUM_GRAY)


# ============================================================================
# SLIDE 2: Executive Summary
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Executive Summary", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

# KPI boxes
kpi_data = [
    ("$2,075", "3-Month Total"),
    ("$995", "LLM Usage (48%)"),
    ("$600", "Platform Licence (29%)"),
    ("$219", "Infrastructure (11%)"),
]

for i, (value, label) in enumerate(kpi_data):
    left = Inches(0.7 + i * 3.15)
    # KPI box
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, Inches(1.4), Inches(2.9), Inches(1.5))
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(0xF0, 0xF4, 0xF8)
    shape.line.color.rgb = RGBColor(0xE0, 0xE0, 0xE0)

    add_text_box(slide, left + Inches(0.2), Inches(1.5), Inches(2.5), Inches(0.8),
                 value, font_size=32, bold=True, color=DARK_BLUE, alignment=PP_ALIGN.CENTER)
    add_text_box(slide, left + Inches(0.2), Inches(2.2), Inches(2.5), Inches(0.5),
                 label, font_size=12, color=MEDIUM_GRAY, alignment=PP_ALIGN.CENTER)

# Key findings
findings = [
    "July was the peak spend month ($1,089) driven by intensive development and testing",
    "LLM model calls represent 48% of total cost - primary optimization lever",
    "August shows 55% cost reduction vs July as usage patterns stabilize",
    "Platform licence ($200/mo fixed) represents 29% of total - efficiency improves with scale",
    "Claude Opus 4 + Claude Sonnet 4 + Gemini 2.5 Pro account for 95% of LLM spend",
]

add_text_box(slide, Inches(0.7), Inches(3.2), Inches(12), Inches(0.5),
             "Key Findings", font_size=16, bold=True, color=DARK_BLUE)

for i, finding in enumerate(findings):
    add_text_box(slide, Inches(1.0), Inches(3.7 + i * 0.55), Inches(11.5), Inches(0.5),
                 f"  {finding}", font_size=12, color=DARK_GRAY)


# ============================================================================
# SLIDE 3: Monthly Cost Overview (with chart image)
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Monthly Cost by Service", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

# Insert chart image
chart_path = os.path.join(os.path.dirname(__file__), "chart_monthly_service_cost.png")
if os.path.exists(chart_path):
    slide.shapes.add_picture(chart_path, Inches(0.5), Inches(1.3), Inches(7.5), Inches(4.5))

# Side table
table_data = [
    ["Month", "Total", "LLM", "Infra", "LangSmith"],
    ["June", "$491", "$277", "$12", "$0"],
    ["July", "$1,089", "$558", "$135", "$172"],
    ["August", "$494", "$161", "$71", "$57"],
]
add_table(slide, Inches(8.3), Inches(1.5), Inches(4.7), Inches(1.8), table_data)

# Insight callout
add_text_box(slide, Inches(8.3), Inches(3.8), Inches(4.5), Inches(2.5),
             "Insight: July spike was due to intensive development testing with 22,915 "
             "LangSmith traces and 1,548 web searches. August normalized to ~$26/day "
             "operational run rate (excluding licence).",
             font_size=11, color=DARK_GRAY)


# ============================================================================
# SLIDE 4: Model Cost Breakdown
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Cost by AI Model", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

# Insert chart image
chart_path = os.path.join(os.path.dirname(__file__), "chart_monthly_model_cost.png")
if os.path.exists(chart_path):
    slide.shapes.add_picture(chart_path, Inches(0.3), Inches(1.3), Inches(8.0), Inches(4.2))

# Model details table
model_table = [
    ["Model", "3-Mo Cost", "Role in System"],
    ["Claude Opus 4", "$302", "Planner LLM (intent classification)"],
    ["Claude Sonnet 4", "$335", "Synthesis (answer generation)"],
    ["Gemini 2.5 Pro", "$302", "Web content extraction fallback"],
    ["Tavily Search", "$33", "Web URL discovery (330 searches/mo)"],
    ["Cohere Rerank", "$2", "KB result reranking"],
    ["Claude 3 Haiku", "$7", "Legacy (phased out in July)"],
]
add_table(slide, Inches(8.5), Inches(1.5), Inches(4.5), Inches(3.2), model_table)

add_text_box(slide, Inches(8.5), Inches(5.0), Inches(4.3), Inches(1.5),
             "Note: Claude 3 Haiku ($7/3mo) was replaced by Claude Sonnet 4 "
             "in late June. Gemini cost reflects web content extraction with "
             "high output token usage (17.7M tokens in July).",
             font_size=10, color=MEDIUM_GRAY)


# ============================================================================
# SLIDE 5: Weekly Trend
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Weekly Cost Trend", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

# Insert chart image
chart_path = os.path.join(os.path.dirname(__file__), "chart_weekly_cost_trend.png")
if os.path.exists(chart_path):
    slide.shapes.add_picture(chart_path, Inches(0.3), Inches(1.2), Inches(12.7), Inches(4.0))

# Timeline annotations
add_text_box(slide, Inches(0.7), Inches(5.5), Inches(12), Inches(1.5),
             "Timeline:\n"
             "  Jun 1-14: Early development, minimal usage ($2-5/week)\n"
             "  Jun 15-30: Architecture established, LLM integration active ($67-217/week)\n"
             "  Jul 1-14: Peak development + LangSmith enabled ($283-338/week)\n"
             "  Jul 15 - Aug 19: Stabilization and optimization ($33-173/week)",
             font_size=11, color=DARK_GRAY)


# ============================================================================
# SLIDE 6: Cost Breakdown Pie
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "3-Month Cost Allocation", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

# Insert pie chart
chart_path = os.path.join(os.path.dirname(__file__), "chart_total_cost_breakdown.png")
if os.path.exists(chart_path):
    slide.shapes.add_picture(chart_path, Inches(0.5), Inches(1.2), Inches(6.5), Inches(6.0))

# Cost categories explanation
categories = [
    ("LLM Calls — $995 (48%)", "Claude Opus (Planner), Claude Sonnet (Synthesis), Gemini Pro (Web extraction)"),
    ("Platform Licence — $600 (29%)", "Fixed $200/month fee for LiteLLM Gateway access"),
    ("LangSmith — $228 (11%)", "Observability and tracing (7,539 traces in August)"),
    ("Infrastructure — $219 (11%)", "EC2 compute for AgentCore Runtime container"),
    ("Tavily — $32 (1.5%)", "Web search API (330 searches/month average)"),
]

y_pos = 1.4
for title, desc in categories:
    add_text_box(slide, Inches(7.3), Inches(y_pos), Inches(5.5), Inches(0.4),
                 title, font_size=13, bold=True, color=DARK_BLUE)
    add_text_box(slide, Inches(7.3), Inches(y_pos + 0.35), Inches(5.5), Inches(0.4),
                 desc, font_size=10, color=MEDIUM_GRAY)
    y_pos += 0.95


# ============================================================================
# SLIDE 7: Token Usage Analysis
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Token Usage Analysis", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

# Token table
token_table = [
    ["Model", "Jun Input", "Jun Output", "Jul Input", "Jul Output", "Aug Input", "Aug Output"],
    ["Claude Opus 4", "6.3M", "798K", "28.6M", "2.6M", "7.9M", "866K"],
    ["Claude Sonnet 4", "11.4M", "2.9M", "29.0M", "5.8M", "15.1M", "1.0M"],
    ["Gemini 2.5 Pro", "817K", "9.6M", "1.5M", "17.7M", "765K", "2.9M"],
    ["Claude 3 Haiku", "19.3M", "2.0M", "226K", "19K", "15K", "3K"],
    ["Tavily Search", "143 req", "—", "1,548 req", "—", "330 req", "—"],
]
add_table(slide, Inches(0.7), Inches(1.4), Inches(12.0), Inches(2.8), token_table)

# Observations
add_text_box(slide, Inches(0.7), Inches(4.5), Inches(12), Inches(2.5),
             "Observations:\n\n"
             "  1. Gemini 2.5 Pro has unusually high output tokens (9.6M-17.7M) because it's used\n"
             "     for web content extraction — it generates full page summaries, not short answers\n\n"
             "  2. Claude Opus 4 (Planner) has high input but low output — it reads full context\n"
             "     but produces only a short JSON planning decision\n\n"
             "  3. Claude Sonnet 4 (Synthesis) has balanced I/O — it reads research results\n"
             "     and generates comprehensive answers with citations",
             font_size=11, color=DARK_GRAY)


# ============================================================================
# SLIDE 8: Cost Optimization Opportunities
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Cost Optimization Opportunities", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

opt_table = [
    ["Opportunity", "Current Cost", "Potential Savings", "Effort"],
    ["Replace Opus with Sonnet for Planner", "$67/mo (Opus)", "~40% ($27/mo)", "Low"],
    ["Cache frequent KB queries", "$29/mo (KB calls)", "~30% ($9/mo)", "Medium"],
    ["Reduce Gemini output token limit", "$29/mo (Gemini)", "~20% ($6/mo)", "Low"],
    ["Batch similar web searches", "$5/mo (Tavily)", "~50% ($2.5/mo)", "Medium"],
    ["Optimize prompt lengths (Planner)", "7.9M input tokens", "~25% ($17/mo)", "Medium"],
    ["Disable LangSmith in production", "$57/mo", "100% ($57/mo)", "Low"],
]
add_table(slide, Inches(0.7), Inches(1.4), Inches(12.0), Inches(3.0), opt_table)

add_text_box(slide, Inches(0.7), Inches(4.7), Inches(12), Inches(2.2),
             "Estimated monthly savings potential: $100-120/month (35-40% of variable costs)\n\n"
             "Priority recommendation:\n"
             "  1. Evaluate Claude Sonnet 4 as Planner model (lowest effort, highest impact)\n"
             "  2. Disable LangSmith tracing in production (instant $57/mo savings)\n"
             "  3. Implement prompt caching for repeated planner prompts (Bedrock supports this)",
             font_size=12, color=DARK_GRAY)


# ============================================================================
# SLIDE 9: Forecast
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_light_background(slide)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
             "Cost Forecast & Projections", font_size=28, bold=True, color=DARK_BLUE)
add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))

forecast_table = [
    ["Scenario", "Monthly Cost", "Annual Projection", "Notes"],
    ["Current (Aug rate)", "$294/mo", "$3,528/yr", "Based on Aug 2026 run rate"],
    ["With optimizations", "$175-200/mo", "$2,100-2,400/yr", "After recommended changes"],
    ["Scaled (2x users)", "$400-500/mo", "$4,800-6,000/yr", "Doubling active usage"],
    ["Scaled (5x users)", "$800-1,000/mo", "$9,600-12,000/yr", "Enterprise scale-up"],
]
add_table(slide, Inches(0.7), Inches(1.4), Inches(12.0), Inches(2.4), forecast_table)

add_text_box(slide, Inches(0.7), Inches(4.2), Inches(12), Inches(2.8),
             "Assumptions:\n\n"
             "  - Current rate excludes the July development spike (non-recurring)\n"
             "  - $200/month licence is fixed regardless of user count\n"
             "  - EC2 infra (~$71/mo) can support 2-3x current load before scaling needed\n"
             "  - LLM cost scales linearly with query volume\n"
             "  - Prompt caching (when enabled) can reduce input token cost by 50-90%\n\n"
             "  Note: August is only 19 days into the month. Full-month projection: ~$494.",
             font_size=11, color=DARK_GRAY)


# ============================================================================
# SLIDE 10: Thank You / Q&A
# ============================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_dark_background(slide)

add_text_box(slide, Inches(1), Inches(2.5), Inches(11), Inches(1.2),
             "Thank You", font_size=44, bold=True, color=WHITE, alignment=PP_ALIGN.CENTER)

add_accent_line(slide, Inches(5.5), Inches(3.5), Inches(2.5))

add_text_box(slide, Inches(1), Inches(4.0), Inches(11), Inches(0.8),
             "Questions & Discussion", font_size=22, color=LIGHT_BLUE, alignment=PP_ALIGN.CENTER)

add_text_box(slide, Inches(1), Inches(5.5), Inches(11), Inches(1),
             "CCAIAA Workbench | GenAI Platform | Tenant: ccaiaa-dev\n"
             "Report generated: August 19, 2026",
             font_size=12, color=MEDIUM_GRAY, alignment=PP_ALIGN.CENTER)


# ============================================================================
# SAVE
# ============================================================================
output_path = os.path.join(os.path.dirname(__file__), "CCAIAA_Cost_Report_Jun_Aug_2026.pptx")
prs.save(output_path)
print(f"\nPresentation saved: {output_path}")
print(f"Slides: {len(prs.slides)}")
print("\nSlide breakdown:")
print("  1. Title")
print("  2. Executive Summary")
print("  3. Monthly Cost by Service (with chart)")
print("  4. Cost by AI Model (with chart)")
print("  5. Weekly Cost Trend (with chart)")
print("  6. 3-Month Cost Allocation (pie chart)")
print("  7. Token Usage Analysis")
print("  8. Cost Optimization Opportunities")
print("  9. Cost Forecast & Projections")
print(" 10. Thank You / Q&A")
