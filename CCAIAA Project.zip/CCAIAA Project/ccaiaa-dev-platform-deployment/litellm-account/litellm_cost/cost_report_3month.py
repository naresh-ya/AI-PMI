"""
3-Month Cost Report with CSV + Bar Charts
Generates: CSV file + 4 PNG bar charts
"""
import csv
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
import numpy as np

OUTPUT_DIR = "."

# ============================================================================
# DATA (pulled from Cost API)
# ============================================================================

# Monthly totals by service
monthly_service = {
    "June 2026": {
        "LLM Calls": 276.60,
        "Infrastructure": 12.44,
        "LangSmith": 0.00,
        "Tavily": 2.24,
        "Licence": 200.00,
    },
    "July 2026": {
        "LLM Calls": 557.63,
        "Infrastructure": 134.91,
        "LangSmith": 171.86,
        "Tavily": 24.54,
        "Licence": 200.00,
    },
    "August 2026": {
        "LLM Calls": 161.03,
        "Infrastructure": 71.43,
        "LangSmith": 56.54,
        "Tavily": 5.27,
        "Licence": 200.00,
    },
}

# Monthly model costs
monthly_models = {
    "June 2026": {
        "Claude Opus 4": 56.56,
        "Claude Sonnet 4": 83.73,
        "Gemini 2.5 Pro": 97.38,
        "Claude 3 Haiku": 6.96,
        "Gemini 3.5 Flash": 12.47,
        "Tavily Search": 19.13,
        "Cohere Rerank": 0.36,
    },
    "July 2026": {
        "Claude Opus 4": 178.47,
        "Claude Sonnet 4": 189.36,
        "Gemini 2.5 Pro": 175.74,
        "Claude 3 Haiku": 0.08,
        "Gemini 3.5 Flash": 0.00,
        "Tavily Search": 10.83,
        "Cohere Rerank": 1.05,
    },
    "August 2026": {
        "Claude Opus 4": 67.07,
        "Claude Sonnet 4": 61.52,
        "Gemini 2.5 Pro": 28.87,
        "Claude 3 Haiku": 0.01,
        "Gemini 3.5 Flash": 0.00,
        "Tavily Search": 2.62,
        "Cohere Rerank": 0.09,
    },
}

# Weekly breakdown
weekly_data = [
    # (week_label, total, llm, infra, langsmith, tavily)
    ("Jun 1-7", 202.00, 1.98, 0.00, 0.00, 0.00),
    ("Jun 8-14", 4.98, 4.98, 0.00, 0.00, 0.00),
    ("Jun 15-21", 67.43, 67.41, 0.00, 0.00, 0.02),
    ("Jun 22-30", 216.90, 202.24, 12.44, 0.00, 2.22),
    ("Jul 1-7", 537.74, 224.69, 36.48, 67.04, 9.53),
    ("Jul 8-14", 282.82, 191.19, 26.19, 58.13, 7.31),
    ("Jul 15-21", 173.02, 106.54, 27.33, 34.85, 4.30),
    ("Jul 22-31", 95.71, 35.21, 44.90, 11.85, 3.40),
    ("Aug 1-7", 279.94, 41.58, 23.11, 13.55, 1.69),
    ("Aug 8-14", 83.24, 49.06, 19.89, 12.40, 1.89),
    ("Aug 15-19", 32.58, 13.79, 13.98, 3.96, 0.85),
]


# ============================================================================
# CSV REPORT
# ============================================================================

def write_csv():
    path = f"{OUTPUT_DIR}/ccaiaa_cost_report_jun_aug_2026.csv"
    
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        
        # Section 1: Monthly Summary by Service
        writer.writerow(["MONTHLY SUMMARY BY SERVICE"])
        writer.writerow(["Month", "Total", "LLM Calls", "Infrastructure", "LangSmith", "Tavily", "Licence"])
        for month, services in monthly_service.items():
            total = sum(services.values())
            writer.writerow([
                month, f"{total:.2f}",
                f"{services['LLM Calls']:.2f}",
                f"{services['Infrastructure']:.2f}",
                f"{services['LangSmith']:.2f}",
                f"{services['Tavily']:.2f}",
                f"{services['Licence']:.2f}",
            ])
        writer.writerow([])
        
        # Section 2: Monthly Model Breakdown
        writer.writerow(["MONTHLY MODEL BREAKDOWN"])
        all_models = sorted(set(m for month_models in monthly_models.values() for m in month_models))
        writer.writerow(["Month"] + all_models)
        for month, models in monthly_models.items():
            row = [month] + [f"{models.get(m, 0):.2f}" for m in all_models]
            writer.writerow(row)
        writer.writerow([])
        
        # Section 3: Weekly Breakdown
        writer.writerow(["WEEKLY BREAKDOWN"])
        writer.writerow(["Week", "Total", "LLM Calls", "Infrastructure", "LangSmith", "Tavily"])
        for week in weekly_data:
            writer.writerow([week[0], f"{week[1]:.2f}", f"{week[2]:.2f}", f"{week[3]:.2f}", f"{week[4]:.2f}", f"{week[5]:.2f}"])
    
    print(f"CSV written: {path}")
    return path


# ============================================================================
# BAR CHARTS
# ============================================================================

def chart_monthly_total():
    """Chart 1: Monthly total cost by service (stacked bar)"""
    fig, ax = plt.subplots(figsize=(10, 6))
    
    months = list(monthly_service.keys())
    services = ["LLM Calls", "Infrastructure", "LangSmith", "Tavily", "Licence"]
    colors = ["#2196F3", "#FF9800", "#4CAF50", "#9C27B0", "#607D8B"]
    
    x = np.arange(len(months))
    width = 0.5
    bottom = np.zeros(len(months))
    
    for service, color in zip(services, colors):
        values = [monthly_service[m][service] for m in months]
        ax.bar(x, values, width, label=service, bottom=bottom, color=color)
        bottom += np.array(values)
    
    ax.set_xlabel("Month")
    ax.set_ylabel("Cost (USD)")
    ax.set_title("CCAIAA-Dev Monthly Cost by Service (Jun-Aug 2026)")
    ax.set_xticks(x)
    ax.set_xticklabels(months)
    ax.legend(loc="upper right")
    ax.set_ylim(0, 1200)
    
    # Add total labels on top
    for i, month in enumerate(months):
        total = sum(monthly_service[month].values())
        ax.text(i, total + 15, f"${total:.0f}", ha="center", fontweight="bold")
    
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/chart_monthly_service_cost.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart saved: {path}")


def chart_monthly_models():
    """Chart 2: Monthly cost by model (grouped bar)"""
    fig, ax = plt.subplots(figsize=(12, 6))
    
    months = list(monthly_models.keys())
    top_models = ["Claude Opus 4", "Claude Sonnet 4", "Gemini 2.5 Pro", "Tavily Search"]
    colors = ["#E91E63", "#3F51B5", "#009688", "#FF5722"]
    
    x = np.arange(len(months))
    width = 0.18
    
    for i, (model, color) in enumerate(zip(top_models, colors)):
        values = [monthly_models[m].get(model, 0) for m in months]
        offset = (i - len(top_models)/2 + 0.5) * width
        bars = ax.bar(x + offset, values, width, label=model, color=color)
        
        # Add value labels
        for bar, val in zip(bars, values):
            if val > 5:
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                       f"${val:.0f}", ha="center", va="bottom", fontsize=8)
    
    ax.set_xlabel("Month")
    ax.set_ylabel("Cost (USD)")
    ax.set_title("CCAIAA-Dev Monthly Cost by Model (Jun-Aug 2026)")
    ax.set_xticks(x)
    ax.set_xticklabels(months)
    ax.legend(loc="upper right")
    
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/chart_monthly_model_cost.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart saved: {path}")


def chart_weekly_trend():
    """Chart 3: Weekly cost trend (stacked bar)"""
    fig, ax = plt.subplots(figsize=(14, 6))
    
    weeks = [w[0] for w in weekly_data]
    llm = [w[2] for w in weekly_data]
    infra = [w[3] for w in weekly_data]
    langsmith = [w[4] for w in weekly_data]
    tavily = [w[5] for w in weekly_data]
    
    x = np.arange(len(weeks))
    width = 0.6
    
    ax.bar(x, llm, width, label="LLM Calls", color="#2196F3")
    ax.bar(x, infra, width, bottom=llm, label="Infrastructure", color="#FF9800")
    ax.bar(x, langsmith, width, bottom=np.array(llm)+np.array(infra), label="LangSmith", color="#4CAF50")
    ax.bar(x, tavily, width, bottom=np.array(llm)+np.array(infra)+np.array(langsmith), label="Tavily", color="#9C27B0")
    
    ax.set_xlabel("Week")
    ax.set_ylabel("Cost (USD)")
    ax.set_title("CCAIAA-Dev Weekly Cost Trend (Jun-Aug 2026) — Excludes $200 Licence")
    ax.set_xticks(x)
    ax.set_xticklabels(weeks, rotation=45, ha="right")
    ax.legend(loc="upper right")
    
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/chart_weekly_cost_trend.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart saved: {path}")


def chart_service_pie():
    """Chart 4: 3-month total cost breakdown (pie chart)"""
    fig, ax = plt.subplots(figsize=(8, 8))
    
    totals = {}
    for month_data in monthly_service.values():
        for service, cost in month_data.items():
            totals[service] = totals.get(service, 0) + cost
    
    labels = list(totals.keys())
    values = list(totals.values())
    colors = ["#2196F3", "#FF9800", "#4CAF50", "#9C27B0", "#607D8B"]
    
    wedges, texts, autotexts = ax.pie(
        values, labels=labels, autopct=lambda p: f"${p*sum(values)/100:.0f}\n({p:.1f}%)",
        colors=colors, startangle=90, textprops={"fontsize": 10}
    )
    
    ax.set_title("CCAIAA-Dev 3-Month Total Cost Breakdown (Jun-Aug 2026)\nTotal: $2,075", fontsize=12)
    
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/chart_total_cost_breakdown.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart saved: {path}")


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print("Generating CCAIAA-Dev 3-Month Cost Report...\n")
    
    write_csv()
    print()
    
    chart_monthly_total()
    chart_monthly_models()
    chart_weekly_trend()
    chart_service_pie()
    
    print("\nDone! Files generated:")
    print("  - ccaiaa_cost_report_jun_aug_2026.csv")
    print("  - chart_monthly_service_cost.png")
    print("  - chart_monthly_model_cost.png")
    print("  - chart_weekly_cost_trend.png")
    print("  - chart_total_cost_breakdown.png")
