"""
Fetch daily LiteLLM cost for a date range and print as JSON list.
Usage: python fetch_daily.py 2026-06-01 2026-08-19
"""
import sys
import json
from datetime import date, timedelta
from tenant_cost import daily_cost
from auth import TENANT_NAME

start = date.fromisoformat(sys.argv[1])
end = date.fromisoformat(sys.argv[2])

results = []
d = start
while d <= end:
    day_str = d.isoformat()
    try:
        data = daily_cost(day_str)
        total = float(data.get("total_cost", 0) or 0)
        # Exclude the licence fee for daily view (it's a lump on the 1st)
        licence = float(data.get("total_cost_licence", 0) or 0)
        results.append({"date": day_str, "total": round(total, 2), "total_ex_licence": round(total - licence, 2)})
    except Exception as e:
        results.append({"date": day_str, "total": 0, "total_ex_licence": 0, "error": str(e)[:50]})
    d += timedelta(days=1)

print(f"TENANT={TENANT_NAME}")
print(json.dumps(results))
