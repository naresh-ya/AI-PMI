"""
Generate per-day LiteLLM cost charts for June, July, August (both tenants)
and a combined CSV. Also produces a PPT with one slide per month.
"""
import os
import json
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

DIR = os.path.dirname(__file__)

DARK_BLUE = RGBColor(0x1B, 0x2A, 0x4A)
ACCENT_ORANGE = RGBColor(0xF5, 0x7C, 0x00)
LIGHT_BLUE = RGBColor(0x3D, 0x8B, 0xD4)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
DARK_GRAY = RGBColor(0x42, 0x42, 0x42)
MEDIUM_GRAY = RGBColor(0x75, 0x75, 0x75)


def load(fname):
    with open(os.path.join(DIR, fname)) as f:
        return json.load(f)["days"]


months = {
    "June": ("ccaiaa_june.json", "mmiana_june.json", 30),
    "July": ("ccaiaa_july.json", "mmiana_july.json", 31),
    "August": ("ccaiaa_august.json", "mmiana_august.json", 31),
}


def make_chart(month, ccaiaa_file, mmiana_file, ndays):
    cc = load(ccaiaa_file)
    mm = load(mmiana_file)
    cc_vals = [d["total_ex_licence"] for d in cc]
    mm_vals = [d["total_ex_licence"] for d in mm]
    x = np.arange(ndays)
    width = 0.4
    fig, ax = plt.subplots(figsize=(13, 5.5))
    ax.bar(x - width/2, cc_vals, width, label="CCAIAA", color="#2196F3")
    ax.bar(x + width/2, mm_vals, width, label="MMIANA", color="#F57C00")
    ax.set_ylabel("Cost (USD)")
    ax.set_xlabel(f"Day ({month} 2026)")
    ax.set_title(f"Daily LiteLLM Cost - {month} 2026 (excludes fixed licence)")
    ax.set_xticks(x)
    ax.set_xticklabels([str(i) for i in range(1, ndays + 1)])
    ax.legend()
    plt.tight_layout()
    path = os.path.join(DIR, f"daily_{month.lower()}.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart: {path}")
    return cc_vals, mm_vals


def write_csv():
    path = os.path.join(DIR, "daily_cost_jun_jul_aug.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Month", "Date", "CCAIAA (ex-licence)", "MMIANA (ex-licence)"])
        for month, (cf, mf, nd) in months.items():
            cc = load(cf)
            mm = load(mf)
            for i in range(len(cc)):
                w.writerow([month, cc[i]["date"], f"{cc[i]['total_ex_licence']:.2f}",
                            f"{mm[i]['total_ex_licence']:.2f}"])
    print(f"CSV: {path}")


def add_text(slide, l, t, w, h, text, size=18, bold=False, color=DARK_GRAY, align=PP_ALIGN.LEFT):
    tb = slide.shapes.add_textbox(l, t, w, h)
    tf = tb.text_frame; tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text; p.font.size = Pt(size); p.font.bold = bold
    p.font.color.rgb = color; p.font.name = "Segoe UI"; p.alignment = align
    return tb


def accent(slide, l, t, w):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, l, t, w, Pt(4))
    s.fill.solid(); s.fill.fore_color.rgb = ACCENT_ORANGE; s.line.fill.background()


def build_ppt(totals):
    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    # Title
    s = prs.slides.add_slide(prs.slide_layouts[6])
    s.background.fill.solid(); s.background.fill.fore_color.rgb = DARK_BLUE
    add_text(s, Inches(1), Inches(2.2), Inches(11.3), Inches(1.2),
             "Daily LiteLLM Cost Breakdown", size=40, bold=True, color=WHITE)
    add_text(s, Inches(1), Inches(3.4), Inches(11.3), Inches(0.8),
             "CCAIAA & MMIANA - Per-Day Detail", size=24, color=LIGHT_BLUE)
    accent(s, Inches(1), Inches(3.3), Inches(3))
    add_text(s, Inches(1), Inches(4.3), Inches(11.3), Inches(0.6),
             "June, July, August 2026 (excludes fixed $200/month licence)", size=16, color=MEDIUM_GRAY)

    # One slide per month
    for month in ["June", "July", "August"]:
        s = prs.slides.add_slide(prs.slide_layouts[6])
        s.background.fill.solid(); s.background.fill.fore_color.rgb = WHITE
        add_text(s, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7),
                 f"Daily LiteLLM Cost - {month} 2026", size=28, bold=True, color=DARK_BLUE)
        accent(s, Inches(0.7), Inches(1.0), Inches(2.5))
        s.shapes.add_picture(os.path.join(DIR, f"daily_{month.lower()}.png"),
                             Inches(0.3), Inches(1.3), Inches(12.7), Inches(4.6))
        cc_tot, mm_tot = totals[month]
        add_text(s, Inches(0.7), Inches(6.1), Inches(12), Inches(1.0),
                 f"{month} total (usage, ex-licence):  CCAIAA ${cc_tot:,.0f}   |   MMIANA ${mm_tot:,.0f}. "
                 f"Add $200 fixed licence per tenant for the full billed platform total.",
                 size=13, bold=True, color=DARK_GRAY)

    out = os.path.join(DIR, "Daily_LiteLLM_Cost_Jun_Jul_Aug_2026.pptx")
    prs.save(out)
    print(f"\nPPT: {out}")


if __name__ == "__main__":
    print("Generating daily charts...\n")
    totals = {}
    for month, (cf, mf, nd) in months.items():
        cc_vals, mm_vals = make_chart(month, cf, mf, nd)
        totals[month] = (sum(cc_vals), sum(mm_vals))
    write_csv()
    build_ppt(totals)
    print("\nDone!")
