"""
MMIANA-Dev Cost Report - Charts + CSV + PPT
"""
import csv
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

OUTPUT_DIR = os.path.dirname(__file__)

# Colors
DARK_BLUE = RGBColor(0x1B, 0x2A, 0x4A)
MID_BLUE = RGBColor(0x2C, 0x5F, 0x8A)
LIGHT_BLUE = RGBColor(0x3D, 0x8B, 0xD4)
ACCENT_ORANGE = RGBColor(0xF5, 0x7C, 0x00)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY = RGBColor(0xF5, 0xF5, 0xF5)
DARK_GRAY = RGBColor(0x42, 0x42, 0x42)
MEDIUM_GRAY = RGBColor(0x75, 0x75, 0x75)

# ============================================================================
# DATA
# ============================================================================

monthly_service = {
    "June 2026": {"LLM Calls": 548.45, "Infrastructure": 12.44, "LangSmith": 0.00, "Tavily": 0.00, "Licence": 200.00},
    "July 2026": {"LLM Calls": 568.93, "Infrastructure": 135.77, "LangSmith": 115.52, "Tavily": 0.00, "Licence": 200.00},
    "August 2026": {"LLM Calls": 876.83, "Infrastructure": 72.45, "LangSmith": 125.09, "Tavily": 0.00, "Licence": 200.00},
}

monthly_models = {
    "June 2026": {"Claude Sonnet 4": 493.99, "Claude Sonnet 4 (older)": 46.78, "Claude Haiku 4.5": 7.68, "Claude Opus 4": 0.00},
    "July 2026": {"Claude Sonnet 4": 533.41, "Claude Sonnet 4 (older)": 3.28, "Claude Haiku 4.5": 32.23, "Claude Opus 4": 0.00},
    "August 2026": {"Claude Sonnet 4": 846.61, "Claude Sonnet 4 (older)": 1.63, "Claude Haiku 4.5": 28.59, "Claude Opus 4": 0.00},
}

weekly_data = [
    ("Jun 1-7", 307.80, 107.80, 0.00, 0.00, 0.00),
    ("Jun 8-14", 111.04, 111.04, 0.00, 0.00, 0.00),
    ("Jun 15-21", 195.95, 195.95, 0.00, 0.00, 0.00),
    ("Jun 22-30", 146.11, 133.66, 12.44, 0.00, 0.00),
    ("Jul 1-7", 411.13, 141.29, 36.71, 33.14, 0.00),
    ("Jul 8-14", 216.18, 158.30, 26.30, 31.58, 0.00),
    ("Jul 15-21", 133.96, 87.95, 27.65, 18.36, 0.00),
    ("Jul 22-31", 258.94, 181.39, 45.11, 32.44, 0.00),
    ("Aug 1-7", 517.20, 252.40, 23.21, 41.58, 0.00),
    ("Aug 8-14", 471.14, 388.74, 20.04, 62.36, 0.00),
    ("Aug 15-19", 63.38, 46.41, 14.15, 2.82, 0.00),
]


# ============================================================================
# CHARTS
# ============================================================================

def chart_monthly_total():
    fig, ax = plt.subplots(figsize=(10, 6))
    months = list(monthly_service.keys())
    services = ["LLM Calls", "Infrastructure", "LangSmith", "Licence"]
    colors = ["#2196F3", "#FF9800", "#4CAF50", "#607D8B"]
    x = np.arange(len(months))
    width = 0.5
    bottom = np.zeros(len(months))
    for service, color in zip(services, colors):
        values = [monthly_service[m][service] for m in months]
        ax.bar(x, values, width, label=service, bottom=bottom, color=color)
        bottom += np.array(values)
    ax.set_xlabel("Month")
    ax.set_ylabel("Cost (USD)")
    ax.set_title("MMIANA-Dev Monthly Cost by Service (Jun-Aug 2026)")
    ax.set_xticks(x)
    ax.set_xticklabels(months)
    ax.legend(loc="upper left")
    ax.set_ylim(0, 1400)
    for i, month in enumerate(months):
        total = sum(monthly_service[month].values())
        ax.text(i, total + 15, f"${total:.0f}", ha="center", fontweight="bold")
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/mmiana_chart_monthly_service.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart: {path}")

def chart_monthly_models():
    fig, ax = plt.subplots(figsize=(12, 6))
    months = list(monthly_models.keys())
    models = ["Claude Sonnet 4", "Claude Haiku 4.5", "Claude Sonnet 4 (older)"]
    colors = ["#3F51B5", "#009688", "#FF5722"]
    x = np.arange(len(months))
    width = 0.22
    for i, (model, color) in enumerate(zip(models, colors)):
        values = [monthly_models[m].get(model, 0) for m in months]
        offset = (i - len(models)/2 + 0.5) * width
        bars = ax.bar(x + offset, values, width, label=model, color=color)
        for bar, val in zip(bars, values):
            if val > 5:
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5, f"${val:.0f}", ha="center", va="bottom", fontsize=9)
    ax.set_xlabel("Month")
    ax.set_ylabel("Cost (USD)")
    ax.set_title("MMIANA-Dev Monthly Cost by Model (Jun-Aug 2026)")
    ax.set_xticks(x)
    ax.set_xticklabels(months)
    ax.legend(loc="upper left")
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/mmiana_chart_monthly_model.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart: {path}")

def chart_weekly_trend():
    fig, ax = plt.subplots(figsize=(14, 6))
    weeks = [w[0] for w in weekly_data]
    llm = [w[2] for w in weekly_data]
    infra = [w[3] for w in weekly_data]
    langsmith = [w[4] for w in weekly_data]
    x = np.arange(len(weeks))
    width = 0.6
    ax.bar(x, llm, width, label="LLM Calls", color="#2196F3")
    ax.bar(x, infra, width, bottom=llm, label="Infrastructure", color="#FF9800")
    ax.bar(x, langsmith, width, bottom=np.array(llm)+np.array(infra), label="LangSmith", color="#4CAF50")
    ax.set_xlabel("Week")
    ax.set_ylabel("Cost (USD)")
    ax.set_title("MMIANA-Dev Weekly Cost Trend (Jun-Aug 2026) - Excludes $200 Licence")
    ax.set_xticks(x)
    ax.set_xticklabels(weeks, rotation=45, ha="right")
    ax.legend(loc="upper left")
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/mmiana_chart_weekly_trend.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart: {path}")

def chart_pie():
    fig, ax = plt.subplots(figsize=(8, 8))
    totals = {}
    for month_data in monthly_service.values():
        for service, cost in month_data.items():
            totals[service] = totals.get(service, 0) + cost
    labels = list(totals.keys())
    values = list(totals.values())
    colors = ["#2196F3", "#FF9800", "#4CAF50", "#9C27B0", "#607D8B"]
    wedges, texts, autotexts = ax.pie(values, labels=labels, autopct=lambda p: f"${p*sum(values)/100:.0f}\n({p:.1f}%)", colors=colors, startangle=90, textprops={"fontsize": 10})
    ax.set_title(f"MMIANA-Dev 3-Month Total Cost Breakdown (Jun-Aug 2026)\nTotal: ${sum(values):,.0f}", fontsize=12)
    plt.tight_layout()
    path = f"{OUTPUT_DIR}/mmiana_chart_pie.png"
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Chart: {path}")


# ============================================================================
# CSV
# ============================================================================

def write_csv():
    path = f"{OUTPUT_DIR}/mmiana_cost_report_jun_aug_2026.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["MONTHLY SUMMARY BY SERVICE"])
        writer.writerow(["Month", "Total", "LLM Calls", "Infrastructure", "LangSmith", "Tavily", "Licence"])
        for month, services in monthly_service.items():
            total = sum(services.values())
            writer.writerow([month, f"{total:.2f}", f"{services['LLM Calls']:.2f}", f"{services['Infrastructure']:.2f}", f"{services['LangSmith']:.2f}", f"{services['Tavily']:.2f}", f"{services['Licence']:.2f}"])
        writer.writerow([])
        writer.writerow(["WEEKLY BREAKDOWN"])
        writer.writerow(["Week", "Total", "LLM Calls", "Infrastructure", "LangSmith", "Tavily"])
        for week in weekly_data:
            writer.writerow([week[0], f"{week[1]:.2f}", f"{week[2]:.2f}", f"{week[3]:.2f}", f"{week[4]:.2f}", f"{week[5]:.2f}"])
    print(f"CSV: {path}")


# ============================================================================
# PPT
# ============================================================================

def add_text_box(slide, left, top, width, height, text, font_size=18, bold=False, color=DARK_GRAY, alignment=PP_ALIGN.LEFT):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.font.name = "Segoe UI"
    p.alignment = alignment
    return txBox

def add_accent_line(slide, left, top, width):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, Pt(4))
    shape.fill.solid()
    shape.fill.fore_color.rgb = ACCENT_ORANGE
    shape.line.fill.background()

def add_table(slide, left, top, width, height, data):
    rows, cols = len(data), len(data[0])
    table_shape = slide.shapes.add_table(rows, cols, left, top, width, height)
    table = table_shape.table
    for row_idx, row_data in enumerate(data):
        for col_idx, cell_text in enumerate(row_data):
            cell = table.cell(row_idx, col_idx)
            cell.text = str(cell_text)
            p = cell.text_frame.paragraphs[0]
            p.font.size = Pt(11)
            p.font.name = "Segoe UI"
            if row_idx == 0:
                p.font.bold = True
                p.font.color.rgb = WHITE
                cell.fill.solid()
                cell.fill.fore_color.rgb = MID_BLUE
            else:
                p.font.color.rgb = DARK_GRAY
                if row_idx % 2 == 0:
                    cell.fill.solid()
                    cell.fill.fore_color.rgb = LIGHT_GRAY
            p.alignment = PP_ALIGN.CENTER if col_idx > 0 else PP_ALIGN.LEFT
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE

def generate_ppt():
    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    def dark_bg(slide):
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = DARK_BLUE
    def light_bg(slide):
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = WHITE

    # Slide 1: Title
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    dark_bg(slide)
    add_text_box(slide, Inches(1), Inches(2), Inches(11), Inches(1.2), "MMIANA Workbench", font_size=44, bold=True, color=WHITE)
    add_text_box(slide, Inches(1), Inches(3.2), Inches(11), Inches(0.8), "GenAI Platform Cost Analysis", font_size=28, color=LIGHT_BLUE)
    add_accent_line(slide, Inches(1), Inches(3.1), Inches(3))
    add_text_box(slide, Inches(1), Inches(4.2), Inches(11), Inches(0.6), "June - August 2026 | Tenant: mmiana-dev", font_size=16, color=MEDIUM_GRAY)
    add_text_box(slide, Inches(1), Inches(6.5), Inches(11), Inches(0.4), "Confidential | Prepared for Business Review", font_size=11, color=MEDIUM_GRAY)

    # Slide 2: Executive Summary
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "Executive Summary", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    kpis = [("$3,055", "3-Month Total"), ("$1,994", "LLM Usage (65%)"), ("$600", "Platform Licence (20%)"), ("$241", "LangSmith (8%)")]
    for i, (val, label) in enumerate(kpis):
        left = Inches(0.7 + i * 3.15)
        shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, Inches(1.4), Inches(2.9), Inches(1.5))
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor(0xF0, 0xF4, 0xF8)
        shape.line.color.rgb = RGBColor(0xE0, 0xE0, 0xE0)
        add_text_box(slide, left + Inches(0.2), Inches(1.5), Inches(2.5), Inches(0.8), val, font_size=32, bold=True, color=DARK_BLUE, alignment=PP_ALIGN.CENTER)
        add_text_box(slide, left + Inches(0.2), Inches(2.2), Inches(2.5), Inches(0.5), label, font_size=12, color=MEDIUM_GRAY, alignment=PP_ALIGN.CENTER)
    findings = [
        "August shows highest LLM spend ($877) driven by intensive Claude Sonnet 4 usage (145M input tokens)",
        "Claude Sonnet 4 dominates at 96% of all LLM cost - single model dependency",
        "No Tavily/web search usage - system relies purely on LLM reasoning without external data",
        "LangSmith tracing activated in July (16,679 traces in August)",
        "Infrastructure cost stabilized at $72/mo after July scaling ($136)",
    ]
    add_text_box(slide, Inches(0.7), Inches(3.2), Inches(12), Inches(0.5), "Key Findings", font_size=16, bold=True, color=DARK_BLUE)
    for i, f in enumerate(findings):
        add_text_box(slide, Inches(1.0), Inches(3.7 + i*0.55), Inches(11.5), Inches(0.5), f"  {f}", font_size=12, color=DARK_GRAY)

    # Slide 3: Monthly by Service
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "Monthly Cost by Service", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    chart_path = f"{OUTPUT_DIR}/mmiana_chart_monthly_service.png"
    if os.path.exists(chart_path):
        slide.shapes.add_picture(chart_path, Inches(0.5), Inches(1.3), Inches(7.5), Inches(4.5))
    table_data = [["Month", "Total", "LLM", "Infra", "LangSmith"],
                  ["June", "$761", "$548", "$12", "$0"],
                  ["July", "$1,020", "$569", "$136", "$116"],
                  ["August", "$1,274", "$877", "$72", "$125"]]
    add_table(slide, Inches(8.3), Inches(1.5), Inches(4.7), Inches(1.8), table_data)
    add_text_box(slide, Inches(8.3), Inches(3.8), Inches(4.5), Inches(2.5), "Insight: Unlike CCAIAA, MMIANA shows an upward cost trend - August is the most expensive month. This is driven by increasing Claude Sonnet 4 usage (145M input tokens in Aug vs 84M in Jun).", font_size=11, color=DARK_GRAY)

    # Slide 4: Model Breakdown
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "Cost by AI Model", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    chart_path = f"{OUTPUT_DIR}/mmiana_chart_monthly_model.png"
    if os.path.exists(chart_path):
        slide.shapes.add_picture(chart_path, Inches(0.3), Inches(1.3), Inches(8.0), Inches(4.2))
    model_table = [["Model", "3-Mo Cost", "% of LLM"],
                   ["Claude Sonnet 4", "$1,874", "96.5%"],
                   ["Claude Haiku 4.5", "$68", "3.5%"],
                   ["Claude Sonnet 4 (old)", "$52", "2.7%"],
                   ["Claude Opus 4", "$0.00", "0%"]]
    add_table(slide, Inches(8.5), Inches(1.5), Inches(4.5), Inches(2.4), model_table)
    add_text_box(slide, Inches(8.5), Inches(4.3), Inches(4.3), Inches(2), "Key difference vs CCAIAA:\nMMAINA uses a single primary model (Claude Sonnet 4) for almost everything. No Gemini, no Tavily web search, no Cohere rerank. Simpler architecture but higher concentration risk.", font_size=10, color=MEDIUM_GRAY)

    # Slide 5: Weekly Trend
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "Weekly Cost Trend", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    chart_path = f"{OUTPUT_DIR}/mmiana_chart_weekly_trend.png"
    if os.path.exists(chart_path):
        slide.shapes.add_picture(chart_path, Inches(0.3), Inches(1.2), Inches(12.7), Inches(4.0))
    add_text_box(slide, Inches(0.7), Inches(5.5), Inches(12), Inches(1.5), "Timeline:\n  Jun 1-21: Steady high usage ($100-196/week LLM) even before infra was provisioned\n  Jun 22 - Jul 7: Infrastructure added ($12-37/week EC2)\n  Jul 8 - Aug 7: Consistent pattern (~$140-250/week LLM)\n  Aug 8-14: Peak week at $389 LLM (65M input tokens to Claude Sonnet 4)", font_size=11, color=DARK_GRAY)

    # Slide 6: Pie Chart
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "3-Month Cost Allocation", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    chart_path = f"{OUTPUT_DIR}/mmiana_chart_pie.png"
    if os.path.exists(chart_path):
        slide.shapes.add_picture(chart_path, Inches(0.5), Inches(1.2), Inches(6.5), Inches(6.0))
    categories = [
        ("LLM Calls - $1,994 (65%)", "Almost entirely Claude Sonnet 4 (bedrock/us.anthropic.claude-sonnet-4-6)"),
        ("Platform Licence - $600 (20%)", "Fixed $200/month fee for LiteLLM Gateway access"),
        ("LangSmith - $241 (8%)", "Observability - 16,679 traces in August alone"),
        ("Infrastructure - $221 (7%)", "EC2 compute (scaled up in July, stabilized in August)"),
    ]
    y = 1.4
    for title, desc in categories:
        add_text_box(slide, Inches(7.3), Inches(y), Inches(5.5), Inches(0.4), title, font_size=13, bold=True, color=DARK_BLUE)
        add_text_box(slide, Inches(7.3), Inches(y+0.35), Inches(5.5), Inches(0.4), desc, font_size=10, color=MEDIUM_GRAY)
        y += 0.95

    # Slide 7: Token Analysis
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "Token Usage Analysis", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    token_table = [
        ["Model", "Jun Input", "Jun Output", "Jul Input", "Jul Output", "Aug Input", "Aug Output"],
        ["Claude Sonnet 4", "83.7M", "13.5M", "95.0M", "13.3M", "144.8M", "22.3M"],
        ["Claude Haiku 4.5", "4.6M", "474K", "21.9M", "1.5M", "19.7M", "1.2M"],
        ["Claude Sonnet 4 (old)", "6.6M", "1.8M", "612K", "96K", "301K", "48K"],
    ]
    add_table(slide, Inches(0.7), Inches(1.4), Inches(12.0), Inches(2.0), token_table)
    add_text_box(slide, Inches(0.7), Inches(3.8), Inches(12), Inches(3), "Observations:\n\n  1. Claude Sonnet 4 input tokens grew 73% from June to August (83.7M -> 144.8M)\n     This is the primary cost driver\n\n  2. Claude Haiku 4.5 handles 20M+ input tokens monthly at much lower cost ($28/mo vs $847/mo)\n     Good candidate for offloading simpler tasks\n\n  3. Claude Sonnet 4 (older version) is being phased out - usage dropped 95% from Jun to Aug\n\n  4. Total token volume: ~168M input + 24M output per month in August\n     This is 3-4x higher than CCAIAA's volume", font_size=11, color=DARK_GRAY)

    # Slide 8: Optimization
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "Cost Optimization Opportunities", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    opt_table = [
        ["Opportunity", "Current Cost", "Potential Savings", "Effort"],
        ["Move more tasks to Haiku 4.5", "$847/mo (Sonnet)", "~30% ($250/mo)", "Medium"],
        ["Enable prompt caching", "145M input tokens", "50-90% on cached ($200-400/mo)", "Low"],
        ["Reduce context window size", "145M input tokens", "~20% ($170/mo)", "Medium"],
        ["Disable LangSmith in prod", "$125/mo", "100% ($125/mo)", "Low"],
        ["Batch similar requests", "16,679 traces", "~15% ($130/mo)", "High"],
    ]
    add_table(slide, Inches(0.7), Inches(1.4), Inches(12.0), Inches(2.6), opt_table)
    add_text_box(slide, Inches(0.7), Inches(4.3), Inches(12), Inches(2.5), "Estimated monthly savings potential: $400-600/month (37-56% of variable costs)\n\nPriority recommendations:\n  1. Enable Bedrock prompt caching (biggest bang, lowest effort - saves $200-400/mo)\n  2. Offload classification/routing tasks to Claude Haiku 4.5 (saves $250/mo)\n  3. Audit context window usage - 145M input tokens suggests large prompts\n  4. Disable LangSmith in production once stable (instant $125/mo)", font_size=12, color=DARK_GRAY)

    # Slide 9: Forecast
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    light_bg(slide)
    add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.7), "Cost Forecast & Projections", font_size=28, bold=True, color=DARK_BLUE)
    add_accent_line(slide, Inches(0.7), Inches(1.0), Inches(2.5))
    forecast_table = [
        ["Scenario", "Monthly Cost", "Annual Projection", "Notes"],
        ["Current (Aug rate)", "$1,074/mo", "$12,888/yr", "Based on Aug 2026 run rate"],
        ["With optimizations", "$475-675/mo", "$5,700-8,100/yr", "After prompt caching + Haiku offload"],
        ["Scaled (2x users)", "$1,600-2,000/mo", "$19,200-24,000/yr", "Doubling active usage"],
        ["Scaled (5x users)", "$3,500-4,500/mo", "$42,000-54,000/yr", "Enterprise scale-up"],
    ]
    add_table(slide, Inches(0.7), Inches(1.4), Inches(12.0), Inches(2.4), forecast_table)
    add_text_box(slide, Inches(0.7), Inches(4.2), Inches(12), Inches(2.5), "Assumptions:\n\n  - August rate ($1,074/mo) excludes the $200 licence already built in\n  - Prompt caching can reduce repeated input tokens by 50-90% (Bedrock native feature)\n  - Claude Haiku 4.5 is ~10x cheaper per token than Claude Sonnet 4\n  - Infrastructure ($72/mo) can support 3-4x current load before needing to scale\n  - MMIANA processes significantly more tokens than CCAIAA (168M vs 24M/month)", font_size=11, color=DARK_GRAY)

    # Slide 10: Thank You
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    dark_bg(slide)
    add_text_box(slide, Inches(1), Inches(2.5), Inches(11), Inches(1.2), "Thank You", font_size=44, bold=True, color=WHITE, alignment=PP_ALIGN.CENTER)
    add_accent_line(slide, Inches(5.5), Inches(3.5), Inches(2.5))
    add_text_box(slide, Inches(1), Inches(4.0), Inches(11), Inches(0.8), "Questions & Discussion", font_size=22, color=LIGHT_BLUE, alignment=PP_ALIGN.CENTER)
    add_text_box(slide, Inches(1), Inches(5.5), Inches(11), Inches(1), "MMIANA Workbench | GenAI Platform | Tenant: mmiana-dev\nReport generated: August 19, 2026", font_size=12, color=MEDIUM_GRAY, alignment=PP_ALIGN.CENTER)

    ppt_path = f"{OUTPUT_DIR}/MMIANA_Cost_Report_Jun_Aug_2026.pptx"
    prs.save(ppt_path)
    print(f"\nPPT: {ppt_path}")
    print(f"Slides: {len(prs.slides)}")


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print("Generating MMIANA-Dev 3-Month Cost Report...\n")
    write_csv()
    chart_monthly_total()
    chart_monthly_models()
    chart_weekly_trend()
    chart_pie()
    generate_ppt()
    print("\nDone!")
