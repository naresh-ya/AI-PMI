"""
Fetch daily LiteLLM cost for a date range and save to a JSON file.
Usage: python fetch_daily_to_file.py 2026-06-01 2026-06-30 june_ccaiaa.json
"""
import sys
import json
from datetime import date, timedelta
from tenant_cost import daily_cost
from auth import TENANT_NAME

start = date.fromisoformat(sys.argv[1])
end = date.fromisoformat(sys.argv[2])
outfile = sys.argv[3]

results = []
d = start
while d <= end:
    day_str = d.isoformat()
    try:
        data = daily_cost(day_str)
        total = float(data.get("total_cost", 0) or 0)
        licence = float(data.get("total_cost_licence", 0) or 0)
        results.append({"date": day_str, "total": round(total, 2), "total_ex_licence": round(total - licence, 2)})
        print(f"{day_str}: {round(total - licence, 2)}")
    except Exception as e:
        results.append({"date": day_str, "total": 0, "total_ex_licence": 0, "error": str(e)[:50]})
        print(f"{day_str}: ERROR {str(e)[:40]}")
    d += timedelta(days=1)

with open(outfile, "w") as f:
    json.dump({"tenant": TENANT_NAME, "days": results}, f, indent=2)

print(f"\nSaved {len(results)} days to {outfile}")
