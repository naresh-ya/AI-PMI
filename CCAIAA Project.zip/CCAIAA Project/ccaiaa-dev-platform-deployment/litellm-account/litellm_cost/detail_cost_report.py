"""
detail_cost_report.py

Full detail cost report for any date range - daily, weekly, monthly, or
yearly are all just "give it a start_date and end_date"; there's no separate
mode because the Cost API itself only has two endpoints (/daily and /range),
see tenant_cost.py and README.md for why.

For every single day in [start_date, end_date], this pulls GET /daily (the
only endpoint that carries real timestamps: log_date, created_at, updated_at)
and flattens every field it returns into one row per metric. Nothing is
rounded away or hidden - a value of exactly 0 or 0.0000145 is written to the
CSV exactly as the API returned it. One additional GET /range call for the
whole period is included as a cross-check summary block.

Known coverage gaps (confirmed live + against platform docs, see README.md)
are written into the CSV itself as explicit rows, so the report is self
-explanatory about what it does and does not include:
  - Guardrails execution cost        -> NOT tracked by this API
  - Knowledge Base OpenSearch COMPUTE cost -> NOT tracked (only storage is)
  - Batch Inference cost             -> NOT tracked (billed via AWS CUR later)

Usage:
    python detail_cost_report.py 2026-08-11 2026-08-11      # a single day
    python detail_cost_report.py 2026-08-01 2026-08-07      # a week
    python detail_cost_report.py 2026-08-01 2026-08-31      # a month
    python detail_cost_report.py 2026-01-01 2026-12-31      # a year
    python detail_cost_report.py 2026-08-01 2026-08-07 --out my_report.csv

Output:
    cost_report_<start_date>_to_<end_date>.csv   (in this folder, unless --out)
"""

import argparse
import csv
import sys
from datetime import date, datetime, timedelta, timezone

import requests

from auth import TENANT_NAME
from tenant_cost import daily_cost, range_cost

FIELDNAMES = [
    "tenant", "date", "category", "item", "metric", "value",
    "log_date", "record_created_at_utc", "record_updated_at_utc",
    "retrieved_at_utc", "notes",
]


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def daterange(start: date, end: date):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)


def _row(date_, category, item, metric, value, retrieved_at, log_date="", created="", updated="", notes=""):
    return {
        "tenant": TENANT_NAME,
        "date": date_,
        "category": category,
        "item": item,
        "metric": metric,
        "value": value,
        "log_date": log_date,
        "record_created_at_utc": created,
        "record_updated_at_utc": updated,
        "retrieved_at_utc": retrieved_at,
        "notes": notes,
    }


def flatten_daily(day_str: str, data: dict) -> list[dict]:
    """One row per metric for a single day's /daily response. Every field
    the API returns becomes its own row, including exact zeros."""
    retrieved_at = now_utc_iso()
    log_date = data.get("log_date", day_str)
    created = data.get("created_at", "")
    updated = data.get("updated_at", "")
    rows = []

    def r(category, item, metric, value, notes=""):
        rows.append(_row(day_str, category, item, metric, value, retrieved_at, log_date, created, updated, notes))

    # Top-level totals - written exactly as returned, zero or not
    for field in [
        "total_cost", "total_cost_litellm", "total_cost_aws", "total_cost_azure",
        "total_cost_tavily", "total_cost_infra", "total_cost_langsmith", "total_cost_licence",
    ]:
        if field in data:
            r("total", field, "cost_usd", data[field])

    r("metadata", "unique_models_count", "count", data.get("unique_models_count", 0))
    r("metadata", "unique_roles_count", "count", data.get("unique_roles_count", 0))

    # Per-model, tenant-wide (deduplicated across roles/keys) - the top-level
    # "models" dict uses "total_" prefixed keys, verified against a live pull
    for model_name, m in data.get("models", {}).items():
        r("model", model_name, "cost_usd", m.get("total_cost", 0))
        r("model", model_name, "input_tokens", m.get("total_input_tokens", 0))
        r("model", model_name, "output_tokens", m.get("total_output_tokens", 0))
        r("model", model_name, "cache_read_tokens", m.get("total_cache_read_tokens", 0))
        r("model", model_name, "cache_write_tokens", m.get("total_cache_write_tokens", 0))

    # Per-role (cost source: LiteLLM / LangSmith / Tavily / backend-access / licence),
    # plus each role's own per-model breakdown (non-prefixed keys here)
    for role_name, role_data in data.get("roles", {}).items():
        role_type = role_data.get("role_type", "")
        r("role", role_name, "cost_usd", role_data.get("total_cost", 0), notes=f"role_type={role_type}")
        for model_name, m in role_data.get("models", {}).items():
            item = f"{role_name} / {model_name}"
            r("role_model", item, "cost_usd", m.get("cost", 0))
            r("role_model", item, "input_tokens", m.get("input_tokens", 0))
            r("role_model", item, "output_tokens", m.get("output_tokens", 0))
            r("role_model", item, "cache_read_tokens", m.get("cache_read_tokens", 0))
            r("role_model", item, "cache_write_tokens", m.get("cache_write_tokens", 0))

    # Infra
    infra = data.get("infra", {})
    if "ec2" in infra:
        r("infra", "ec2", "cost_usd", infra["ec2"].get("cost", 0))
    if "opensearch" in infra:
        r(
            "infra", "opensearch", "storage_cost_usd", infra["opensearch"].get("storage_cost", 0),
            notes="Storage only. OpenSearch COMPUTE cost for Knowledge Base retrieval is NOT tracked - see coverage_gap rows below.",
        )

    # LangSmith (agents / traces)
    ls = data.get("langsmith", {})
    if ls:
        r("langsmith", "ALL_PROJECTS", "cost_usd", ls.get("total_cost", 0))
        r("langsmith", "ALL_PROJECTS", "trace_cost_usd", ls.get("trace_cost", 0))
        r("langsmith", "ALL_PROJECTS", "deployment_run_cost_usd", ls.get("deployment_run_cost", 0))
        r("langsmith", "ALL_PROJECTS", "total_traces", ls.get("total_traces", 0))
        r("langsmith", "ALL_PROJECTS", "total_deployment_runs", ls.get("total_deployment_runs", 0))
        for proj_name, proj in ls.get("projects", {}).items():
            r("langsmith_project", proj_name, "cost_usd", proj.get("cost", 0))
            r("langsmith_project", proj_name, "traces", proj.get("traces", 0))

    # Tavily / web search
    tavily = data.get("search", {}).get("tavily", {})
    if tavily:
        r("tavily", "ALL_OPERATIONS", "cost_usd", tavily.get("total_cost", 0))
        r("tavily", "ALL_OPERATIONS", "credits", tavily.get("total_credits", 0))
        r("tavily", "ALL_OPERATIONS", "requests", tavily.get("request_count", 0))
        for op_name, op in tavily.get("operations", {}).items():
            r("tavily_operation", op_name, "cost_usd", op.get("cost", 0))
            r("tavily_operation", op_name, "credits", op.get("credits", 0))
            r("tavily_operation", op_name, "requests", op.get("requests", 0))

    return rows


def flatten_range_summary(
    start: str, end: str, data: dict, licence_accumulator: float = 0.0, day_fetch_errors: list[str] | None = None
) -> list[dict]:
    """Whole-period aggregate from /range, as a cross-check block. /range
    does not return log_date/created_at/updated_at (it isn't one day's
    record), so those columns are intentionally left blank for these rows.

    Confirmed live: the platform's /range response has NO total_cost_licence
    field at all (checked raw JSON keys directly - it's genuinely absent, not
    just unread). It IS folded into /range's total_cost though, which is why
    total_cost previously didn't match the sum of the other 6 sub-fields (a
    $200 gap on a range that included the 1st of a billing month).

    Fix: total_cost_licence is derived here by summing total_cost_licence from
    each day's /daily record within this same range - the exact same
    underlying daily values /range itself aggregates over - so the derived
    number is consistent with total_cost, not a separate guess. This also
    means it correctly comes out to 0 for ranges that don't include the 1st
    of a billing month (e.g. week 3-4 of a month), since no daily record in
    that window carries a nonzero licence fee.
    """
    retrieved_at = now_utc_iso()
    label = f"{start}_to_{end}"
    rows = []

    def r(category, item, metric, value, notes=""):
        rows.append(_row(label, category, item, metric, value, retrieved_at, notes=notes))

    for field in [
        "total_cost", "total_cost_litellm", "total_cost_aws", "total_cost_azure",
        "total_cost_tavily", "total_cost_infra", "total_cost_langsmith",
    ]:
        if field in data:
            r(
                "range_total", field, "cost_usd", data[field],
                notes="Whole-period aggregate from GET /range - cross-check against summing the daily rows above.",
            )

    r(
        "range_total", "total_cost_licence", "cost_usd", licence_accumulator,
        notes="NOT returned by the platform's /range endpoint (confirmed - the field is absent from the raw "
              "response). Derived by this script by summing total_cost_licence across each day's /daily "
              "record within this range, so it is included in total_cost above even though /range doesn't "
              "expose it as its own field.",
    )

    # Self-check: total_cost should equal the sum of the 6 /range fields plus
    # the derived licence value. Written as its own row so the check result
    # is visible directly in the CSV, not just in console output.
    day_fetch_errors = day_fetch_errors or []
    sub_items_sum = licence_accumulator + sum(
        float(data.get(f, 0) or 0)
        for f in [
            "total_cost_litellm", "total_cost_aws", "total_cost_azure",
            "total_cost_tavily", "total_cost_infra", "total_cost_langsmith",
        ]
    )
    reported_total = float(data.get("total_cost", 0) or 0)
    diff = round(reported_total - sub_items_sum, 6)

    if day_fetch_errors:
        check_notes = (
            f"Cross-check SKIPPED (not reliable): {len(day_fetch_errors)} day(s) in this range failed to "
            f"fetch ({', '.join(day_fetch_errors)}), so the derived total_cost_licence above may be "
            f"incomplete. See the 'error' rows for those dates."
        )
    elif abs(diff) < 0.000001:
        check_notes = "PASSED: total_cost equals the sum of all 7 sub-items (litellm+aws+azure+tavily+infra+langsmith+licence)."
    else:
        check_notes = (
            f"FAILED: total_cost ({reported_total}) does not equal the sum of all 7 sub-items "
            f"({sub_items_sum}). This is unexpected - see CSV_GUIDE.md for known caveats, or flag to the "
            f"platform team if this persists."
        )
    r("range_total", "cross_check_total_vs_sum_of_parts", "cost_usd", diff, notes=check_notes)

    for model_name, m in data.get("models", {}).items():
        r("range_model", model_name, "cost_usd", m.get("total_cost", 0))
        r("range_model", model_name, "input_tokens", m.get("total_input_tokens", 0))
        r("range_model", model_name, "output_tokens", m.get("total_output_tokens", 0))

    return rows


def coverage_gap_rows(start: str, end: str) -> list[dict]:
    """Explicit rows for the 3 known gaps in this API, confirmed live +
    against platform docs (see README.md 'User-ID level cost' /
    'Known platform limitations' sections). value is the literal string
    NOT_TRACKED_BY_API - distinct from a real zero, since these aren't
    known to cost nothing, they simply aren't exposed by this API at all."""
    retrieved_at = now_utc_iso()
    label = f"{start}_to_{end}"
    gaps = [
        (
            "guardrails",
            "Guardrails execution cost is NOT exposed anywhere in this API (platform docs list it as "
            "'in progress'). Guardrails ARE actively applied on calls (confirmed via the LiteLLM "
            "x-litellm-applied-guardrails response header) but no cost line exists for them here.",
        ),
        (
            "knowledge_base_opensearch_compute",
            "OpenSearch COMPUTE cost (the indexing/retrieval work behind Knowledge Base queries) is NOT "
            "tracked or charged back yet. Only OpenSearch STORAGE cost is visible - see the "
            "'infra / opensearch / storage_cost_usd' rows above.",
        ),
        (
            "batch_inference",
            "Batch Inference cost bypasses LiteLLM entirely and is billed retroactively via the AWS Cost "
            "and Usage Report days after the fact. It never appears in this API.",
        ),
    ]
    return [
        _row(label, "coverage_gap", item, "cost_usd", "NOT_TRACKED_BY_API", retrieved_at, notes=notes)
        for item, notes in gaps
    ]


def build_report(start_date: str, end_date: str) -> list[dict]:
    start = date.fromisoformat(start_date)
    end = date.fromisoformat(end_date)
    if start > end:
        raise ValueError(f"start_date {start_date} is after end_date {end_date}")

    total_days = (end - start).days + 1
    print(f"Tenant: {TENANT_NAME}")
    print(f"Range : {start_date} -> {end_date}  ({total_days} day(s))")
    if total_days > 31:
        print(
            f"Note: this pulls one API call per day ({total_days} calls) plus 1 summary call - "
            f"large ranges (e.g. a full year) can take several minutes.\n"
        )
    else:
        print()

    all_rows = []
    daily_rows = []
    licence_accumulator = 0.0
    day_fetch_errors = []

    # Daily rows are fetched FIRST now, because the range summary needs the
    # sum of each day's total_cost_licence to fill the gap described in
    # flatten_range_summary() above (the platform's /range response has no
    # licence field of its own).
    for i, day in enumerate(daterange(start, end), 1):
        day_str = day.isoformat()
        print(f"Fetching day {i}/{total_days}: {day_str}...")
        try:
            day_data = daily_cost(day_str)
            daily_rows.extend(flatten_daily(day_str, day_data))
            licence_accumulator += float(day_data.get("total_cost_licence", 0) or 0)
        except requests.HTTPError as e:
            print(f"  WARNING: {day_str} fetch failed: {e}")
            day_fetch_errors.append(day_str)
            daily_rows.append(
                _row(day_str, "error", "fetch_failed", "cost_usd", "ERROR", now_utc_iso(), notes=str(e))
            )

    # The platform's /range endpoint rejects start_date == end_date (HTTP 400
    # "Start date is greater than or equal to end date") - confirmed live.
    # For a single-day report, the per-day /daily rows above are already the
    # full picture, so the range cross-check is skipped rather than logged as
    # a false-alarm warning.
    if start == end:
        print("Single-day report - skipping /range cross-check (not applicable for one day).")
    else:
        print("Fetching whole-range summary (cross-check)...")
        try:
            range_data = range_cost(start_date, end_date)
            all_rows.extend(
                flatten_range_summary(start_date, end_date, range_data, licence_accumulator, day_fetch_errors)
            )
        except requests.HTTPError as e:
            print(f"  WARNING: range summary fetch failed: {e}")

    all_rows.extend(daily_rows)
    all_rows.extend(coverage_gap_rows(start_date, end_date))
    return all_rows


def format_value(metric: str, value) -> str:
    """Preserve exact precision - no rounding to 2 decimals, no scientific
    notation (which can visually vanish or confuse in a spreadsheet). Costs
    get fixed high-precision decimals so near-zero values stay visible;
    counts/tokens print as plain integers."""
    if isinstance(value, str):
        return value  # sentinels: NOT_TRACKED_BY_API, ERROR
    if value is None:
        return ""
    if "cost" in metric:
        return f"{float(value):.10f}"
    try:
        return str(int(round(float(value))))
    except (TypeError, ValueError):
        return str(value)


def write_csv(rows: list[dict], start_date: str, end_date: str, out_path: str = None) -> str:
    if out_path is None:
        out_path = f"cost_report_{start_date}_to_{end_date}.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        for r in rows:
            row_out = dict(r)
            row_out["value"] = format_value(r["metric"], r["value"])
            writer.writerow(row_out)
    return out_path


def main():
    parser = argparse.ArgumentParser(description="Detailed, fully timestamped cost report (CSV) for any date range")
    parser.add_argument("start_date", help="YYYY-MM-DD")
    parser.add_argument("end_date", help="YYYY-MM-DD")
    parser.add_argument("--out", default=None, help="Output CSV path (default: cost_report_<start>_to_<end>.csv)")
    args = parser.parse_args()

    try:
        rows = build_report(args.start_date, args.end_date)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)

    out_path = write_csv(rows, args.start_date, args.end_date, args.out)
    print(f"\nDone. {len(rows)} rows written to: {out_path}")
    print(
        "\nReminder - this report does NOT include: Guardrails execution cost, Knowledge Base "
        "OpenSearch compute cost, or Batch Inference cost. See the 'coverage_gap' rows in the "
        "CSV itself, or README.md, for details."
    )


if __name__ == "__main__":
    main()
