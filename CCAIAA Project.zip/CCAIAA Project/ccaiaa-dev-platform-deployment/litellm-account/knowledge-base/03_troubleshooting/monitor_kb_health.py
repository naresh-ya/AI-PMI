#!/usr/bin/env python3
"""
Troubleshooting utility - Knowledge Base Health Check
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, or wired into a CI/CD pipeline / scheduled job as a
    lightweight health probe. Checks KB status, data source count, and
    ingestion success rate in one pass, and exits with a non-zero code if
    anything looks unhealthy - suitable for scripting:

        python monitor_kb_health.py && echo "healthy" || echo "issues found"

    Set KB_NAME in .env to whichever KB you want to check.

Destructive? No - read-only.

Usage:
    python monitor_kb_health.py
"""

import os
from datetime import datetime
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def check_kb_health(token, kb_name):
    print("=" * 80)
    print("KNOWLEDGE BASE HEALTH CHECK")
    print("=" * 80)
    print(f"Tenant:  {TENANT}")
    print(f"KB Name: {kb_name}")
    print(f"Time:    {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80 + "\n")

    health = {
        "kb_status": "UNKNOWN", "data_sources": 0, "ingestion_jobs": 0,
        "total_documents": 0, "failed_documents": 0, "success_rate": 0.0, "issues": [],
    }
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    print("1. Checking KB status...")
    try:
        url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{kb_name}"
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            status = data.get("status_metadata", {}).get("status", "UNKNOWN")
            health["kb_status"] = status
            print(f"   KB Status: {status}")
            if status != "CREATED":
                health["issues"].append(f"KB status is {status}, not CREATED")

            data_sources = data.get("object_metadata", {}).get("data_sources", {})
            health["data_sources"] = len(data_sources)
            print(f"   Data Sources: {len(data_sources)}")
            if not data_sources:
                health["issues"].append("No data sources configured")
        else:
            health["issues"].append("Failed to retrieve KB status")
            print(f"   Failed to get KB status (HTTP {response.status_code})")
    except Exception as e:
        health["issues"].append(f"KB status check error: {e}")
        print(f"   Error: {e}")

    print("\n2. Checking ingestion jobs...")
    try:
        url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{kb_name}/sync"
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            jobs_data = response.json().get("ingestion_jobs", {})
            jobs = list(jobs_data.values()) if isinstance(jobs_data, dict) else jobs_data
            health["ingestion_jobs"] = len(jobs)
            print(f"   Total Jobs: {len(jobs)}")

            for job in jobs:
                if not isinstance(job, dict):
                    continue
                stats = job.get("statistics", {})
                health["total_documents"] += stats.get("numberOfDocumentsScanned", 0)
                health["failed_documents"] += stats.get("numberOfDocumentsFailed", 0)
                if job.get("status", "UNKNOWN") != "COMPLETE":
                    health["issues"].append(f"Job status: {job.get('status', 'UNKNOWN')}")

            if health["total_documents"] > 0:
                health["success_rate"] = (
                    (health["total_documents"] - health["failed_documents"]) / health["total_documents"] * 100
                )
                print(f"   Documents Scanned: {health['total_documents']:,}")
                print(f"   Documents Failed:  {health['failed_documents']:,}")
                print(f"   Success Rate:      {health['success_rate']:.1f}%")
                if health["success_rate"] < 95:
                    health["issues"].append(f"Success rate below 95%: {health['success_rate']:.1f}%")
        else:
            print("   Could not retrieve ingestion jobs")
    except Exception as e:
        health["issues"].append(f"Ingestion jobs check error: {e}")
        print(f"   Error: {e}")

    print("\n" + "=" * 80)
    print("HEALTH ASSESSMENT")
    print("=" * 80 + "\n")

    if not health["issues"]:
        print("HEALTHY - no issues detected")
    else:
        print(f"ISSUES DETECTED ({len(health['issues'])}):")
        for i, issue in enumerate(health["issues"], 1):
            print(f"  {i}. {issue}")

    print(f"\nSummary: kb_status={health['kb_status']} data_sources={health['data_sources']} "
          f"documents={health['total_documents']:,} success_rate={health['success_rate']:.1f}%")
    print("=" * 80 + "\n")

    return health


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    try:
        token = get_access_token()
        health = check_kb_health(token, KB_NAME)
        raise SystemExit(1 if health["issues"] else 0)
    except SystemExit:
        raise
    except Exception as e:
        print(f"Error: {e}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
