#!/usr/bin/env python3
"""
Troubleshooting utility - Delete a Data Source from a Knowledge Base
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, to remove a data source's connection to a KB (e.g. an old
    test data source that add_data_source.py created).

    [!] This does NOT delete anything in S3 - only the KB's connection to
    that bucket/prefix is removed. Files remain in S3 untouched.

    Set KB_NAME in .env to whichever KB the data source belongs to.

Destructive? Yes for the KB<->data-source link (not reversible through
this script - you'd need to re-run add_data_source.py). S3 files are
NOT affected. Requires typing "DELETE" to confirm.

Usage:
    python delete_data_source.py
"""

import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def delete_data_source(token, kb_name, ds_name):
    print("=" * 80)
    print("DELETING DATA SOURCE")
    print("=" * 80)
    print(f"Tenant:      {TENANT}")
    print(f"KB Name:     {kb_name}")
    print(f"Data Source: {ds_name}")
    print("=" * 80 + "\n")
    print("This removes the KB's connection to this data source.")
    print("The underlying S3 bucket/files are NOT deleted.\n")

    if input("Type 'DELETE' to confirm: ") != "DELETE":
        print("Cancelled. Data source was NOT deleted.")
        return False

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases/{kb_name}/datasources/{ds_name}"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    response = requests.delete(url, headers=headers)

    if response.status_code not in (200, 202, 204):
        print(f"Failed to delete data source! Status {response.status_code}: {response.text}")
        return False

    print("Data source deleted successfully.")
    try:
        print(json.dumps(response.json(), indent=2))
    except Exception:
        pass
    return True


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    ds_name = input("Data Source Name to delete: ").strip()
    if not ds_name:
        print("ERROR: data source name cannot be empty")
        raise SystemExit(1)

    print(f"\nAbout to delete '{ds_name}' from KB '{KB_NAME}' (tenant {TENANT}).\n")

    token = get_access_token()
    if delete_data_source(token, KB_NAME, ds_name):
        print("\nVerify with: python list_data_sources.py")


if __name__ == "__main__":
    main()
