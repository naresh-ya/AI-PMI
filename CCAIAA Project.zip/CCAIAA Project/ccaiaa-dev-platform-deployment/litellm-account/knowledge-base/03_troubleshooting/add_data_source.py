#!/usr/bin/env python3
"""
Troubleshooting utility - Add a Data Source to an Existing Knowledge Base
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, when a KB needs an ADDITIONAL S3 bucket/prefix beyond what
    it already has (both English and multilingual KBs currently have
    exactly one data source each - this is for when that changes).

    [!] The KB must already be in CREATED status before adding a data
    source - this is not part of initial KB creation.

    Set KB_NAME in .env to whichever KB you want to add a source to.

Destructive? No deletion involved, but it does modify the KB's
configuration - review the printed config before confirming.

Usage:
    python add_data_source.py
"""

import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def add_data_source(token, kb_name, ds_config):
    print("=" * 80)
    print("ADDING DATA SOURCE")
    print("=" * 80)
    print(f"Tenant:  {TENANT}")
    print(f"KB Name: {kb_name}")
    print("=" * 80)
    print(json.dumps(ds_config, indent=2))
    print()

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases/{kb_name}/datasources"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    response = requests.post(url, headers=headers, json=ds_config)

    if response.status_code not in (200, 201, 202):
        print(f"Failed to add data source! Status {response.status_code}: {response.text}")
        return None

    print("Data source added successfully.\n")
    return response.json()


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    print("This adds a NEW data source to the KB configured in .env (KB_NAME).\n")

    ds_name = input("Data Source Name (3-30 chars): ").strip()
    if not ds_name:
        print("ERROR: data source name is required")
        raise SystemExit(1)

    bucket_name = input("S3 Bucket Name: ").strip()
    if not bucket_name:
        print("ERROR: bucket name is required")
        raise SystemExit(1)

    bucket_prefix = input("S3 Bucket Prefix (optional, e.g. 'documents/'): ").strip()

    print("\nChunking strategy:")
    print("  1. SEMANTIC (recommended - matches both existing KBs)")
    print("  2. FIXED_SIZE")
    choice = input("Choose (1 or 2): ").strip()

    if choice == "1":
        max_tokens = input("Max Tokens (default 512): ").strip() or "512"
        buffer_size = input("Buffer Size (default 1): ").strip() or "1"
        threshold = input("Breakpoint Threshold (default 95): ").strip() or "95"
        ds_config = {
            "data_source_name": ds_name,
            "create_bucket": False,
            "bucket_name": bucket_name,
            "chunking_strategy": "SEMANTIC",
            "semantic_config": {
                "maxTokens": int(max_tokens),
                "bufferSize": int(buffer_size),
                "breakpointPercentileThreshold": int(threshold),
            },
        }
    else:
        max_tokens = input("Max Tokens (default 300): ").strip() or "300"
        overlap = input("Overlap Percentage (default 20): ").strip() or "20"
        ds_config = {
            "data_source_name": ds_name,
            "create_bucket": False,
            "bucket_name": bucket_name,
            "chunking_strategy": "FIXED_SIZE",
            "fixed_size_config": {"maxTokens": int(max_tokens), "overlapPercentage": int(overlap)},
        }

    if bucket_prefix:
        ds_config["bucket_inclusion_prefixes"] = [bucket_prefix]

    print("\n" + "=" * 80)
    print("REVIEW CONFIGURATION")
    print("=" * 80)
    print(json.dumps(ds_config, indent=2))
    print("=" * 80 + "\n")

    if input("Proceed with adding this data source? (yes/no): ").strip().lower() != "yes":
        print("Cancelled.")
        return

    token = get_access_token()
    result = add_data_source(token, KB_NAME, ds_config)

    if result:
        print("\nNext steps:")
        print("  1. Upload documents to the S3 bucket/prefix above")
        print("  2. Run the KB's step2_sync script to ingest them")


if __name__ == "__main__":
    main()
