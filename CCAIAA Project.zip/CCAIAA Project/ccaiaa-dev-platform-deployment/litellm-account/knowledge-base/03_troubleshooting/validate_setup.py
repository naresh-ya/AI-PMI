#!/usr/bin/env python3
"""
Troubleshooting utility - Pre-Deployment Validation Checklist
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, before treating a KB as production-ready, or wired into
    CI/CD as a gate. Validates env configuration, authentication, KB
    status, ingestion success rate, and retrieval - all in one pass - and
    exits non-zero if anything fails:

        python validate_setup.py && echo "ready" || echo "not ready"

    Set KB_NAME / KB_ID in .env to whichever KB you're validating.

Destructive? No - read-only checks.

Usage:
    python validate_setup.py
"""

import os
from pathlib import Path

import requests
import urllib3
from dotenv import load_dotenv

# The LiteLLM Gateway retrieve endpoint (used only in validate_retrieval)
# is an internal PMI host reached with a self-signed certificate - same as
# step3_retrieve_from_kb.py / step3_retrieve_multilingual.py. Silence the
# resulting warning; the Management API calls elsewhere in this script use
# normal certificate verification.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT")
KB_ID = os.environ.get("KB_ID")
KB_NAME = os.environ.get("KB_NAME")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")
LITELLM_TOKEN = os.environ.get("LITELLM_TOKEN")


def _check(name, passed, message=""):
    print(f"{'PASS' if passed else 'FAIL'}  {name}" + (f" - {message}" if message else ""))
    return passed


def validate_env():
    print("=" * 80)
    print("VALIDATING .ENV CONFIGURATION")
    print("=" * 80 + "\n")

    checks = [
        _check("CLIENT_ID", bool(CLIENT_ID)),
        _check("CLIENT_SECRET", bool(CLIENT_SECRET)),
        _check("TENANT", bool(TENANT), TENANT or "missing"),
        _check("KB_ID", bool(KB_ID), KB_ID or "missing"),
        _check("KB_NAME", bool(KB_NAME), KB_NAME or "missing"),
        _check("LITELLM_TOKEN", bool(LITELLM_TOKEN), "required for the retrieval check below"),
    ]
    print()
    return all(checks)


def validate_authentication():
    print("=" * 80)
    print("VALIDATING AUTHENTICATION")
    print("=" * 80 + "\n")

    try:
        response = requests.post(
            COGNITO_ENDPOINT,
            data={
                "grant_type": "client_credentials",
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if response.status_code == 200:
            _check("Authentication", True, "token obtained")
            print()
            return response.json()["access_token"], True
        _check("Authentication", False, f"HTTP {response.status_code}")
        print()
        return None, False
    except Exception as e:
        _check("Authentication", False, str(e))
        print()
        return None, False


def validate_kb_configuration(token):
    print("=" * 80)
    print("VALIDATING KB CONFIGURATION")
    print("=" * 80 + "\n")

    try:
        url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}"
        response = requests.get(url, headers={"Authorization": f"Bearer {token}"})

        if response.status_code != 200:
            _check("KB Exists", False, f"HTTP {response.status_code}")
            print()
            return False

        data = response.json()
        status = data.get("status_metadata", {}).get("status", "UNKNOWN")
        _check("KB Status", status == "CREATED", f"status={status}")

        kb_config = data.get("object_metadata", {}).get("knowledge_base", {}).get("knowledge_base_configuration", {})
        embedding = kb_config.get("embedding_model", "Unknown")
        _check("Embedding Model", bool(embedding), embedding)

        data_sources = data.get("object_metadata", {}).get("data_sources", {})
        _check("Data Sources", len(data_sources) > 0, f"{len(data_sources)} configured")

        print()
        return status == "CREATED" and len(data_sources) > 0
    except Exception as e:
        _check("KB Configuration", False, str(e))
        print()
        return False


def validate_ingestion(token):
    print("=" * 80)
    print("VALIDATING DOCUMENT INGESTION")
    print("=" * 80 + "\n")

    try:
        url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
        response = requests.get(url, headers={"Authorization": f"Bearer {token}"})

        if response.status_code != 200:
            _check("Ingestion Jobs", False, "cannot access ingestion data")
            print()
            return False

        jobs_data = response.json().get("ingestion_jobs", {})
        # The API returns ingestion_jobs as a dict keyed by data source name,
        # not a list - normalize it (same handling as check_ingestion_jobs.py).
        jobs = list(jobs_data.values()) if isinstance(jobs_data, dict) else jobs_data

        if not jobs:
            _check("Ingestion Jobs", False, "no ingestion jobs found")
            print()
            return False

        total_scanned = sum(j.get("statistics", {}).get("numberOfDocumentsScanned", 0) for j in jobs if isinstance(j, dict))
        total_failed = sum(j.get("statistics", {}).get("numberOfDocumentsFailed", 0) for j in jobs if isinstance(j, dict))

        _check("Documents Ingested", total_scanned > 0, f"{total_scanned:,} documents")

        success_rate = 0
        if total_scanned > 0:
            success_rate = (total_scanned - total_failed) / total_scanned * 100
            _check("Success Rate", success_rate >= 95, f"{success_rate:.1f}%")

        print()
        return total_scanned > 0 and success_rate >= 95
    except Exception as e:
        _check("Ingestion Validation", False, str(e))
        print()
        return False


def validate_retrieval(token):
    print("=" * 80)
    print("VALIDATING RETRIEVAL")
    print("=" * 80 + "\n")

    if not LITELLM_TOKEN:
        _check("Retrieval API", False, "LITELLM_TOKEN not set - this check uses the LiteLLM Gateway, not the Management API")
        print()
        return False

    try:
        # NOTE: this is the LiteLLM Gateway's retrieve pass-through endpoint,
        # a DIFFERENT host/path/token than the Management API used everywhere
        # else in this script - see step3_retrieve_from_kb.py for the same
        # endpoint. Do not swap this back to the Management API token.
        url = f"https://litellm.aiplat-dev.aws.private-pmideep.biz/bedrock/knowledgebases/{KB_ID}/retrieve"
        headers = {"Authorization": f"Bearer {LITELLM_TOKEN}", "Content-Type": "application/json"}
        payload = {
            "retrievalQuery": {"text": "test query"},
            "retrievalConfiguration": {"vectorSearchConfiguration": {"numberOfResults": 5}},
        }
        # verify=False: internal PMI endpoint, self-signed cert - see note
        # at the top of this file and step3_retrieve_from_kb.py.
        response = requests.post(url, headers=headers, json=payload, verify=False)

        if response.status_code == 200:
            results = response.json().get("retrievalResults", [])
            _check("Retrieval API", True, f"{len(results)} results")
            _check("Results Returned", len(results) > 0, "KB has searchable content")
            print()
            return True

        _check("Retrieval API", False, f"HTTP {response.status_code}")
        print()
        return False
    except Exception as e:
        _check("Retrieval Validation", False, str(e))
        print()
        return False


def main():
    print("=" * 80)
    print("SETUP VALIDATION - PRE-DEPLOYMENT CHECKLIST")
    print("=" * 80 + "\n")

    results = {}

    results["Environment Configuration"] = validate_env()
    if not results["Environment Configuration"]:
        print("Cannot proceed without complete .env configuration.\n")
        raise SystemExit(1)

    token, auth_ok = validate_authentication()
    results["Authentication"] = auth_ok
    if not auth_ok:
        print("Cannot proceed without authentication.\n")
        raise SystemExit(1)

    results["KB Configuration"] = validate_kb_configuration(token)
    results["Document Ingestion"] = validate_ingestion(token)
    results["Retrieval"] = validate_retrieval(token)

    print("=" * 80)
    print("VALIDATION REPORT")
    print("=" * 80 + "\n")

    passed = sum(1 for r in results.values() if r)
    print(f"Results: {passed}/{len(results)} checks passed\n")
    for check, status in results.items():
        print(f"  {'PASS' if status else 'FAIL'}  {check}")

    print()
    if passed == len(results):
        print("PRODUCTION READY - all validations passed.\n")
        raise SystemExit(0)

    print("NOT READY - fix the failed checks above before deploying.\n")
    raise SystemExit(1)


if __name__ == "__main__":
    main()
