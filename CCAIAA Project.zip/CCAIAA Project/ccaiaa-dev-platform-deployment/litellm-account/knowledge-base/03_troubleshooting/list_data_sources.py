#!/usr/bin/env python3
"""
Troubleshooting utility - List Data Sources in a Knowledge Base
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand. Use this to see the data source(s) configured on a KB - S3
    bucket, prefix, and chunking configuration - without the rest of
    get_kb_details.py's output. Useful when you just need to confirm which
    S3 prefix a KB is watching.

    Set KB_NAME in .env to whichever KB you want to inspect.

Destructive? No - read-only.

Usage:
    python list_data_sources.py
"""

import os
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def list_data_sources(token, kb_name):
    print("=" * 80)
    print("KNOWLEDGE BASE DATA SOURCES")
    print("=" * 80)
    print(f"Tenant:  {TENANT}")
    print(f"KB Name: {kb_name}")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{kb_name}"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"Failed to get KB details! Status {response.status_code}: {response.text}")
        return None

    data_sources = response.json().get("object_metadata", {}).get("data_sources", {})

    if not data_sources:
        print("No data sources found in this KB.")
        return None

    print(f"Found {len(data_sources)} data source(s):\n")

    for i, (ds_name, ds_info) in enumerate(data_sources.items(), 1):
        ds_config = ds_info.get("data_source_configuration", {})
        ds_data = ds_info.get("data_source_data", {})

        print(f"DATA SOURCE #{i}: {ds_name}")
        print(f"  Bucket:   {ds_config.get('bucket_name', 'N/A')}")
        print(f"  Chunking: {ds_config.get('chunking_strategy', 'N/A')}")

        prefixes = ds_config.get("bucket_inclusion_prefixes", [])
        if prefixes:
            print(f"  Prefixes: {', '.join(prefixes)}")

        if ds_config.get("chunking_strategy") == "SEMANTIC":
            sc = ds_config.get("semantic_config", {})
            print(f"  Semantic config: max_tokens={sc.get('maxTokens', 'N/A')} "
                  f"buffer={sc.get('bufferSize', 'N/A')} threshold={sc.get('breakpointPercentileThreshold', 'N/A')}")
        elif ds_config.get("chunking_strategy") == "FIXED_SIZE":
            fc = ds_config.get("fixed_size_config", {})
            print(f"  Fixed-size config: max_tokens={fc.get('maxTokens', 'N/A')} overlap={fc.get('overlapPercentage', 'N/A')}%")

        print(f"  Data Source ID: {ds_data.get('data_source_id', 'N/A')}\n")

    print("=" * 80)
    print(f"TOTAL: {len(data_sources)} Data Source(s)")
    print("=" * 80 + "\n")

    return data_sources


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()
    list_data_sources(token, KB_NAME)


if __name__ == "__main__":
    main()
