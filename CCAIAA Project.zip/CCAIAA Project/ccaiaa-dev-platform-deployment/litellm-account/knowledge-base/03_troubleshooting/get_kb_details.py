#!/usr/bin/env python3
"""
Troubleshooting utility - Get Full Knowledge Base Details
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand. Use this to see a single KB's complete configuration:
    embedding model, chunking strategy, S3 data sources, OpenSearch
    collection, and resource-level status. This is the script to reach for
    when you need a KB's ID/ARN, or when diagnosing why a KB isn't behaving
    as expected.

    Set KB_NAME in .env to whichever KB you want to inspect (English or
    multilingual).

Destructive? No - read-only. Optionally offers to save the full response
to a local JSON file for inspection.

Usage:
    python get_kb_details.py
"""

import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def get_kb_details(token, kb_name):
    print("=" * 80)
    print("KNOWLEDGE BASE DETAILS")
    print("=" * 80)
    print(f"Tenant:  {TENANT}")
    print(f"KB Name: {kb_name}")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{kb_name}"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"Failed to get KB details! Status {response.status_code}: {response.text}")
        return None

    data = response.json()

    print("BASIC INFORMATION")
    print(f"  Object ID:    {data.get('object_id', 'N/A')}")
    print(f"  Product Code: {data.get('product_code', 'N/A')}")
    print(f"  Environment:  {data.get('env', 'N/A')}")

    status_meta = data.get("status_metadata", {})
    print("\nSTATUS")
    print(f"  Status:    {status_meta.get('status', 'N/A')}")
    print(f"  Timestamp: {status_meta.get('timestamp', 'N/A')}")

    obj_meta = data.get("object_metadata", {})
    kb_info = obj_meta.get("knowledge_base", {})
    kb_config = kb_info.get("knowledge_base_configuration", {})
    kb_data = kb_info.get("knowledge_base_data", {})

    print("\nKNOWLEDGE BASE CONFIGURATION")
    print(f"  Description: {kb_info.get('description', 'N/A')}")
    print(f"  KB ID:       {kb_data.get('kb_id', 'N/A')}")
    print(f"  KB ARN:      {kb_data.get('kb_arn', 'N/A')}")
    print(f"  Embedding:   {kb_config.get('embedding_model', 'N/A')}")
    print(f"  Dimensions:  {kb_config.get('embedding_model_dimension', 'N/A')}")

    collection_data = obj_meta.get("collection_data", {})
    print("\nOPENSEARCH COLLECTION")
    print(f"  Name: {collection_data.get('collection_name', 'N/A')}")
    print(f"  ID:   {collection_data.get('collection_id', 'N/A')}")

    data_sources = obj_meta.get("data_sources", {})
    print(f"\nDATA SOURCES ({len(data_sources)})")
    for ds_name, ds_info in data_sources.items():
        ds_config = ds_info.get("data_source_configuration", {})
        ds_data = ds_info.get("data_source_data", {})
        print(f"  - {ds_name}")
        print(f"      Bucket:         {ds_config.get('bucket_name', 'N/A')}")
        print(f"      Chunking:       {ds_config.get('chunking_strategy', 'N/A')}")
        print(f"      Data Source ID: {ds_data.get('data_source_id', 'N/A')}")
        prefixes = ds_config.get("bucket_inclusion_prefixes", [])
        if prefixes:
            print(f"      Prefixes:       {', '.join(prefixes)}")

    resource_status = data.get("resource_status", [])
    if resource_status:
        print("\nRESOURCE STATUS")
        for resource in resource_status:
            key = resource.get("key", "N/A")
            value = resource.get("value", {})
            print(f"  {key:30} {value.get('status', 'N/A'):15} {value.get('timestamp', 'N/A')}")

    print("\n" + "=" * 80 + "\n")
    return data


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()
    kb_details = get_kb_details(token, KB_NAME)

    if kb_details:
        save = input("Save full details to a JSON file? (yes/no): ").strip().lower()
        if save == "yes":
            filename = f"{KB_NAME}_details.json"
            with open(filename, "w") as f:
                json.dump(kb_details, f, indent=2)
            print(f"Saved to: {filename}")


if __name__ == "__main__":
    main()
