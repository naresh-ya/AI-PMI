#!/usr/bin/env python3
"""
Troubleshooting utility - Retry Failed Document Ingestion
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, after check_ingestion_jobs.py shows documents with a
    non-zero failed count. This re-triggers a sync, which retries any
    documents that failed on the previous pass.

    Set KB_NAME in .env to whichever KB you want to retry.

Destructive? No destructive AWS action, but it does trigger a real
ingestion job (billable/consumes quota) - asks for confirmation before
retrying.

Usage:
    python fix_failed_ingestion.py
"""

import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def check_failed_documents(token):
    print("=" * 80)
    print("CHECKING FOR FAILED DOCUMENTS")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"Failed to get ingestion jobs: {response.text}")
        return None

    jobs_data = response.json().get("ingestion_jobs", {})
    # The API returns ingestion_jobs as a dict keyed by data source name,
    # not a list - normalize it (same handling as check_ingestion_jobs.py).
    jobs = list(jobs_data.values()) if isinstance(jobs_data, dict) else jobs_data
    total_failed = 0
    failed_jobs = []

    for job in jobs:
        if not isinstance(job, dict):
            continue
        failed = job.get("statistics", {}).get("numberOfDocumentsFailed", 0)
        if failed > 0:
            total_failed += failed
            failed_jobs.append({
                "data_source": job.get("dataSourceName", "Unknown"),
                "job_id": job.get("ingestionJobId", "Unknown"),
                "failed_count": failed,
            })

    if total_failed == 0:
        print("No failed documents found. All documents ingested successfully.\n")
        return None

    print(f"Found {total_failed} failed document(s) across {len(failed_jobs)} job(s):\n")
    for i, job in enumerate(failed_jobs, 1):
        print(f"  Job #{i}: data_source={job['data_source']} job_id={job['job_id']} failed={job['failed_count']}")
    print()

    return failed_jobs


def retry_ingestion(token):
    print("=" * 80)
    print("RETRYING INGESTION")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    response = requests.post(url, headers=headers)

    if response.status_code not in (200, 202):
        print(f"Failed to trigger sync: {response.text}")
        return False

    print("Sync triggered successfully.\n")
    return True


def monitor_sync(token, duration=60):
    print(f"Monitoring for {duration} seconds...\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    start_time = time.time()

    while time.time() - start_time < duration:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            jobs_data = response.json().get("ingestion_jobs", {})
            jobs = list(jobs_data.values()) if isinstance(jobs_data, dict) else jobs_data
            in_progress = False
            for job in jobs:
                if not isinstance(job, dict):
                    continue
                if job.get("status") == "IN_PROGRESS":
                    in_progress = True
                    stats = job.get("statistics", {})
                    print(f"  {job.get('dataSourceName', 'Unknown')}: "
                          f"scanned={stats.get('numberOfDocumentsScanned', 0)} "
                          f"failed={stats.get('numberOfDocumentsFailed', 0)}")
            if not in_progress:
                print("\nAll jobs completed.")
                break
        time.sleep(10)


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()
    failed_jobs = check_failed_documents(token)

    if failed_jobs is None:
        return

    confirm = input("Retry ingestion for the failed documents above? Type 'YES' to proceed: ").strip()
    if confirm != "YES":
        print("Retry cancelled.")
        return

    if retry_ingestion(token):
        monitor_sync(token, duration=60)
        print("\nRetry initiated. If it's still failing after this, check document")
        print("format/size, or run check_ingestion_jobs.py again for updated stats.")


if __name__ == "__main__":
    main()
