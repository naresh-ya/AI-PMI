#!/usr/bin/env python3
"""
Troubleshooting utility - Verify Metadata Filtering Actually Works
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, when retrieval results seem unaffected by a metadata filter
    you're passing (e.g. jurisdiction or theme). Runs the same query with
    and without filters and compares result counts/metadata to confirm
    whether filtering is actually narrowing results.

    Set KB_ID in .env to whichever KB you're testing (note: this script
    talks to the LiteLLM Gateway retrieve endpoint directly, using
    LITELLM_TOKEN - not the Management API used by the other scripts here).

Destructive? No - read-only queries against the KB.

Usage:
    python test_metadata_filtering.py
"""

import json
import os
import ssl
import urllib.request
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

LITELLM_TOKEN = os.environ.get("LITELLM_TOKEN")
KB_ID = os.environ.get("KB_ID")
KB_RETRIEVE_URL = f"https://litellm.aiplat-dev.aws.private-pmideep.biz/bedrock/knowledgebases/{KB_ID}/retrieve"


def _ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def retrieve_with_filters(query, filters=None, test_name="Test"):
    print(f"\n{'=' * 80}")
    print(test_name)
    print("=" * 80)
    print(f"Query: {query}")
    print(f"Filters: {json.dumps(filters, indent=2) if filters else 'None'}")

    payload = {
        "retrievalQuery": {"text": query},
        "retrievalConfiguration": {
            "vectorSearchConfiguration": {"numberOfResults": 10, "overrideSearchType": "HYBRID"}
        },
    }
    if filters:
        payload["retrievalConfiguration"]["vectorSearchConfiguration"]["filter"] = filters

    headers = {"Authorization": f"Bearer {LITELLM_TOKEN}", "Content-Type": "application/json"}
    req = urllib.request.Request(
        KB_RETRIEVE_URL, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
    )

    try:
        with urllib.request.urlopen(req, context=_ssl_context(), timeout=60) as response:
            result = json.loads(response.read().decode("utf-8"))

        raw_results = result.get("retrievalResults", [])
        print(f"\nRetrieved {len(raw_results)} results")

        metadata_summary = {}
        for i, item in enumerate(raw_results[:5], 1):
            metadata = item.get("metadata", {}) or {}
            jurisdiction = metadata.get("jurisdiction", "N/A")
            theme1 = metadata.get("theme-level-1", "N/A")
            theme2 = metadata.get("theme-level-2", "N/A")

            metadata_summary.setdefault("jurisdictions", set()).add(jurisdiction)
            metadata_summary.setdefault("theme_level_1", set()).add(theme1)
            metadata_summary.setdefault("theme_level_2", set()).add(theme2)

            print(f"  Result {i}: score={item.get('score', 0):.4f} jurisdiction={jurisdiction} theme_l1={theme1}")

        return raw_results, metadata_summary

    except Exception as e:
        print(f"Error: {e}")
        return [], {}


def main():
    if not LITELLM_TOKEN or not KB_ID:
        print("ERROR: LITELLM_TOKEN and KB_ID must be set in .env")
        raise SystemExit(1)

    print("=" * 80)
    print("METADATA FILTERING TEST")
    print("=" * 80)
    print(f"KB ID: {KB_ID}")

    query = "heated tobacco products regulations"

    results_no_filter, _ = retrieve_with_filters(query, None, "TEST 1: NO FILTERS (baseline)")

    results_jurisdiction, _ = retrieve_with_filters(
        query, {"equals": {"key": "jurisdiction", "value": "India"}},
        "TEST 2: FILTER BY JURISDICTION = 'India'",
    )

    results_theme, _ = retrieve_with_filters(
        query, {"stringContains": {"key": "theme-level-1", "value": "Smoke-free"}},
        "TEST 3: FILTER BY THEME-LEVEL-1 contains 'Smoke-free'",
    )

    results_combined, _ = retrieve_with_filters(
        query,
        {"andAll": [
            {"equals": {"key": "jurisdiction", "value": "India"}},
            {"stringContains": {"key": "theme-level-1", "value": "Smoke-free"}},
        ]},
        "TEST 4: COMBINED FILTERS",
    )

    print("\n" + "=" * 80)
    print("COMPARISON")
    print("=" * 80)
    print(f"No filter:    {len(results_no_filter)} results")
    print(f"Jurisdiction: {len(results_jurisdiction)} results")
    print(f"Theme L1:     {len(results_theme)} results")
    print(f"Combined:     {len(results_combined)} results")

    print("\n" + "=" * 80)
    print("VERDICT")
    print("=" * 80)

    filtering_works = False
    if len(results_jurisdiction) < len(results_no_filter):
        print("Jurisdiction filtering appears to work (fewer results with filter).")
        filtering_works = True
    elif len(results_jurisdiction) == 0:
        print("Jurisdiction filter returned 0 results - may need a different value.")
    else:
        print("Jurisdiction filtering unclear (same result count with/without filter).")

    if len(results_theme) < len(results_no_filter):
        print("Theme filtering appears to work (fewer results with filter).")
        filtering_works = True
    elif len(results_theme) == 0:
        print("Theme filter returned 0 results - may need a different value.")
    else:
        print("Theme filtering unclear (same result count with/without filter).")

    if not filtering_works:
        print("\n[!] Metadata filtering may not be narrowing results as expected.")
        print("    Possible causes: all documents share the same metadata values,")
        print("    the filter value doesn't match any indexed document, or the")
        print("    field wasn't indexed at ingestion time.")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
