#!/usr/bin/env python3
"""
Troubleshooting utility - Delete a Knowledge Base
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, to permanently remove a KB that is no longer needed (e.g. a
    test KB created while experimenting with settings). NOT for routine
    use against the live English or multilingual KBs.

WHAT THIS SCRIPT DOES:
    Deletes the named KB, its OpenSearch collection, and all indexed
    documents, then polls until the deletion is confirmed (or a 5-minute
    timeout is reached).

Destructive? Yes - PERMANENT. Deletes the KB, its OpenSearch collection,
and all indexed content. Cannot be undone. Requires typing "DELETE" to
confirm. Does NOT touch the underlying S3 documents.

Usage:
    python delete_kb.py
    (you will be prompted for the KB name to delete - this script does
    NOT read KB_NAME from .env, specifically to avoid deleting the wrong
    KB by an unnoticed stale .env value)
"""

import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def delete_knowledge_base(token, kb_name):
    print("=" * 80)
    print("DELETING KNOWLEDGE BASE")
    print("=" * 80)
    print("[!] This will PERMANENTLY delete the KB, its OpenSearch collection,")
    print("    and all indexed documents. This cannot be undone.")
    print("=" * 80)
    print(f"Tenant:  {TENANT}")
    print(f"KB Name: {kb_name}")
    print("=" * 80 + "\n")

    if input("Type 'DELETE' to confirm deletion: ") != "DELETE":
        print("Cancelled. KB was NOT deleted.")
        return False

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases/{kb_name}"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    response = requests.delete(url, headers=headers)

    if response.status_code not in (200, 202, 204):
        print(f"Failed to delete KB! Status {response.status_code}: {response.text}")
        return False

    print("Delete request submitted. Deletion is asynchronous and may take a few minutes.")
    return True


def verify_deletion(token, kb_name, max_wait_minutes=5):
    print("\nVerifying deletion...\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{kb_name}"
    headers = {"Authorization": f"Bearer {token}"}
    start_time = time.time()
    check_count = 0

    while time.time() - start_time < max_wait_minutes * 60:
        check_count += 1
        elapsed = (time.time() - start_time) / 60
        print(f"Check #{check_count} (elapsed {elapsed:.1f} min)")

        try:
            response = requests.get(url, headers=headers)
            if response.status_code == 404:
                print("KB has been deleted successfully.")
                return True
            if response.status_code == 200:
                status = response.json().get("status_metadata", {}).get("status", "UNKNOWN")
                print(f"  Status: {status}")
                if status == "DELETED":
                    return True
        except Exception as e:
            print(f"  Error checking status: {e}")

        if check_count < 20:
            time.sleep(15)
        else:
            break

    print(f"\nTimeout reached ({max_wait_minutes} min). Deletion may still be in progress.")
    return False


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    print("Enter the KB name to delete (full name, e.g. ccaiaa-dev-ccaiaa-kb-eng):\n")
    kb_name = input("KB Name: ").strip()
    if not kb_name:
        print("ERROR: KB name cannot be empty")
        raise SystemExit(1)

    print(f"\nAbout to delete: {kb_name}  (tenant: {TENANT})\n")

    token = get_access_token()
    if not delete_knowledge_base(token, kb_name):
        return

    verified = verify_deletion(token, kb_name)

    print("\n" + "=" * 80)
    if verified:
        print(f"SUCCESSFULLY DELETED: {kb_name}")
    else:
        print(f"DELETION IN PROGRESS: {kb_name} - check again in a few minutes")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
