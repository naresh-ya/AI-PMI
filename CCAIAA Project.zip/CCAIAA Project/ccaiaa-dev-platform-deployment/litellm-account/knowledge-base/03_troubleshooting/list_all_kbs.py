#!/usr/bin/env python3
"""
Troubleshooting utility - List All Knowledge Bases in the Tenant
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand - not part of any numbered flow. Use this to see every KB
    that exists for the tenant, with its KB ID, status, and embedding
    model. Handy before creating a new KB (check nothing with that name
    already exists) or when you've forgotten a KB's exact ID.

Destructive? No - read-only.

Usage:
    python list_all_kbs.py
"""

import os
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def list_knowledge_bases(token):
    print("=" * 80)
    print("LISTING ALL KNOWLEDGE BASES")
    print("=" * 80)
    print(f"Tenant: {TENANT}")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"Failed to list KBs! Status {response.status_code}: {response.text}")
        return []

    data = response.json()
    kbs = data if isinstance(data, list) else data.get("knowledge_bases", [])

    if not kbs:
        print("No Knowledge Bases found in this tenant.")
        return []

    print(f"Found {len(kbs)} Knowledge Base(s):\n")

    for i, kb in enumerate(kbs, 1):
        if not isinstance(kb, dict):
            continue

        kb_name = kb.get("object_id", "N/A")
        status = kb.get("status_metadata", {}).get("status", "N/A")
        created = kb.get("status_metadata", {}).get("timestamp", "N/A")

        kb_info = kb.get("object_metadata", {}).get("knowledge_base", {})
        kb_id = kb_info.get("knowledge_base_data", {}).get("kb_id", "N/A")
        description = kb_info.get("description", "N/A")
        embedding_model = kb_info.get("knowledge_base_configuration", {}).get("embedding_model", "N/A")

        print(f"KB #{i}")
        print(f"  Name:        {kb_name}")
        print(f"  KB ID:       {kb_id}")
        print(f"  Status:      {status}")
        print(f"  Description: {description}")
        print(f"  Created:     {created}")
        print(f"  Embedding:   {embedding_model}\n")

    print("=" * 80)
    print(f"TOTAL: {len(kbs)} Knowledge Base(s)")
    print("=" * 80 + "\n")

    return kbs


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()
    list_knowledge_bases(token)


if __name__ == "__main__":
    main()
