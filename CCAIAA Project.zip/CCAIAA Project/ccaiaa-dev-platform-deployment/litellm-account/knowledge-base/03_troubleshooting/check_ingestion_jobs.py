#!/usr/bin/env python3
"""
Troubleshooting utility - Check Ingestion Job History
================================================================================

WHEN TO USE THIS SCRIPT:
    On demand, most often right after a sync script (step2_sync_kb.py /
    step2_sync_kb_multilingual.py) reports failures. Shows every ingestion
    job for the KB with per-job statistics and, if available, the actual
    failure reasons AWS returned for any failed documents.

    Set KB_NAME in .env to whichever KB you want to inspect.

Destructive? No - read-only.

Usage:
    python check_ingestion_jobs.py
"""

import json
import os
from datetime import datetime
from pathlib import Path

import requests
from dotenv import load_dotenv

API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def get_access_token():
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def check_ingestion_jobs(token, kb_name):
    print("=" * 80)
    print("INGESTION JOBS HISTORY")
    print("=" * 80)
    print(f"Tenant:  {TENANT}")
    print(f"KB Name: {kb_name}")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{kb_name}/sync"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"Failed to get ingestion jobs! Status {response.status_code}: {response.text}")
        return None

    jobs_data = response.json().get("ingestion_jobs", {})

    if isinstance(jobs_data, dict):
        jobs = []
        for ds_name, job_info in jobs_data.items():
            job_info["data_source_name"] = ds_name
            jobs.append(job_info)
    else:
        jobs = jobs_data

    if not jobs:
        print("No ingestion jobs found.")
        return None

    print(f"Found {len(jobs)} ingestion job(s):\n")

    total_scanned = total_failed = total_chunks = 0

    for i, job in enumerate(jobs, 1):
        print(f"JOB #{i}")
        print(f"  Data Source: {job.get('data_source_name', 'N/A')}")
        print(f"  Job ID:      {job.get('job_id', 'N/A')}")
        print(f"  Status:      {job.get('status', 'N/A')}")

        start_time = job.get("start_time", "N/A")
        if start_time != "N/A":
            try:
                dt = datetime.fromisoformat(start_time.replace("Z", "+00:00"))
                print(f"  Start Time:  {dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
            except Exception:
                print(f"  Start Time:  {start_time}")

        stats = job.get("statistics", {})
        scanned = stats.get("numberOfDocumentsScanned", 0)
        failed = stats.get("numberOfDocumentsFailed", 0)
        chunks = stats.get("numberOfChunksIngested", 0)
        total_scanned += scanned
        total_failed += failed
        total_chunks += chunks

        if stats:
            print(f"  Scanned: {scanned:,}  Failed: {failed:,}  Chunks Ingested: {chunks:,}")
            if scanned > 0:
                print(f"  Success Rate: {((scanned - failed) / scanned) * 100:.1f}%")

        failure_reasons = job.get("failureReasons") or job.get("failure_reasons") or []
        if failure_reasons:
            print("  Failure Reasons:")
            for reason in failure_reasons:
                if isinstance(reason, str):
                    try:
                        parsed = json.loads(reason)
                        items = parsed if isinstance(parsed, list) else [parsed]
                        for item in items:
                            print(f"    - {item}")
                    except Exception:
                        print(f"    - {reason}")
                else:
                    print(f"    - {reason}")
        print()

    print("=" * 80)
    print("OVERALL STATISTICS")
    print(f"  Total Documents Scanned: {total_scanned:,}")
    print(f"  Total Documents Failed:  {total_failed:,}")
    print(f"  Total Chunks Ingested:   {total_chunks:,}")
    if total_scanned > 0:
        print(f"  Overall Success Rate:    {((total_scanned - total_failed) / total_scanned) * 100:.1f}%")
    print("=" * 80 + "\n")

    return jobs


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()
    check_ingestion_jobs(token, KB_NAME)


if __name__ == "__main__":
    main()
