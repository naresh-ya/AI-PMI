#!/usr/bin/env python3
"""
STEP 2 of 3 - Sync the English Knowledge Base After S3 Upload
================================================================================

WHEN TO USE THIS SCRIPT:
    Run AFTER you have uploaded new/updated documents to S3 (and after
    step1_create_kb.py has finished, for a brand-new KB). This triggers an
    ingestion job that scans the configured S3 prefix and indexes any new
    or changed documents.

    [!] DO NOT run this before the S3 upload finishes - it syncs whatever
    is in S3 at the moment it runs.

WHAT THIS SCRIPT DOES:
    1. Obtains an OAuth2 access token.
    2. Triggers a sync/ingestion job for KB_NAME.
    3. Polls progress every 15 seconds, printing documents scanned/failed
       per data source, until all jobs reach a terminal state.

NEXT STEP AFTER THIS SCRIPT:
    ./step3_retrieve_from_kb.py (to confirm the new documents are queryable)

    If any documents failed to ingest, see
    ../03_troubleshooting/check_ingestion_jobs.py (view failure reasons) and
    ../03_troubleshooting/fix_failed_ingestion.py (retry them).

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
OAuth2 client credentials from .env (see .env.template) - same Vault-sourced,
tenant-scoped credentials as step1. Nothing personal to one developer.
--------------------------------------------------------------------------------

Usage:
    python step2_sync_kb.py
"""

import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

# ==============================================================================
# CONFIGURATION
# ==============================================================================
API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"
POLL_INTERVAL_SECONDS = 15
MAX_WAIT_MINUTES = 60

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")
KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")


def get_access_token():
    """Get OAuth2 access token from Cognito (client credentials grant)."""
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    return response.json()["access_token"]


def trigger_sync(token):
    """Trigger a KB sync/ingestion job."""
    print("=" * 80)
    print("TRIGGERING SYNC")
    print("=" * 80)
    print(f"Tenant:  {TENANT}")
    print(f"KB Name: {KB_NAME}")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    response = requests.post(url, headers=headers)
    if response.status_code != 200:
        print(f"Failed to trigger sync! Status {response.status_code}: {response.text}")
        return False

    print("Sync triggered successfully.\n")
    return True


def monitor_sync_progress():
    """Poll sync status until all ingestion jobs reach a terminal state."""
    print("=" * 80)
    print("MONITORING SYNC PROGRESS")
    print("=" * 80 + "\n")

    start_time = time.time()
    max_wait_seconds = MAX_WAIT_MINUTES * 60
    iteration = 0

    while True:
        iteration += 1
        elapsed_minutes = (time.time() - start_time) / 60

        if time.time() - start_time > max_wait_seconds:
            print(f"\nTimeout reached ({MAX_WAIT_MINUTES} minutes). Sync may still be")
            print("running in the background - check status manually later.")
            return False

        # Tokens expire; fetch a fresh one each polling loop.
        try:
            token = get_access_token()
        except Exception as e:
            print(f"Failed to refresh token: {e}")
            return False

        url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print(f"Warning: error checking status ({response.status_code}). Retrying...")
            time.sleep(POLL_INTERVAL_SECONDS)
            continue

        jobs = response.json().get("ingestion_jobs", [])
        if not jobs:
            print("No ingestion jobs found yet. This can mean sync hasn't started,")
            print("no data source is configured, or a previous sync already completed.")
            return False

        print(f"\n--- Check #{iteration} (elapsed {elapsed_minutes:.1f} min) ---")
        all_complete = True
        any_failed = False

        for job in jobs:
            if not isinstance(job, dict):
                continue

            status = job.get("status", "UNKNOWN")
            ds_name = job.get("data_source_name", "Unknown")
            stats = job.get("statistics", {})
            scanned = stats.get("numberOfDocumentsScanned", 0)
            ingested = stats.get("numberOfChunksIngested", 0)
            failed = stats.get("numberOfDocumentsFailed", 0)

            print(f"  {ds_name}: status={status} scanned={scanned} chunks_ingested={ingested} failed={failed}")

            if status not in ("COMPLETE", "FAILED"):
                all_complete = False
            if status == "FAILED":
                any_failed = True

        if all_complete:
            print("\n" + "=" * 80)
            if any_failed:
                print("SYNC COMPLETED WITH FAILURES")
                print("=" * 80)
                print("\nSee ../03_troubleshooting/check_ingestion_jobs.py for details,")
                print("and ../03_troubleshooting/fix_failed_ingestion.py to retry.")
                return False

            print("SYNC COMPLETED SUCCESSFULLY")
            print("=" * 80)
            return True

        time.sleep(POLL_INTERVAL_SECONDS)


def main():
    print("=" * 80)
    print("STEP 2 of 3: SYNC ENGLISH KNOWLEDGE BASE")
    print("=" * 80)
    print("\n[!] Run this ONLY after the S3 document upload has finished.\n")

    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()

    if not trigger_sync(token):
        raise SystemExit(1)

    success = monitor_sync_progress()

    print("\nNext: ./step3_retrieve_from_kb.py" if success else "\nResolve failures, then re-run this script.")


if __name__ == "__main__":
    main()
