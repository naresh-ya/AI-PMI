#!/usr/bin/env python3
"""
STEP 3 of 3 - Retrieve / Query the English Knowledge Base
================================================================================

WHEN TO USE THIS SCRIPT:
    Run after step2_sync_kb.py has completed successfully, to confirm the
    KB returns relevant results. Also importable as a module - the
    retrieve_from_kb() function is what an application would call at
    runtime to do RAG retrieval against this KB.

WHAT THIS SCRIPT DOES (retrieve_from_kb):
    1. Extracts semantic search signals from the raw query using an LLM
       call (topic, background) - falls back to simple keyword stripping
       if the LLM call fails or LITELLM_TOKEN is not set.
    2. Maps the query to the KB's theme metadata (theme-level-1/2) via LLM,
       to narrow retrieval with metadata filters when possible.
    3. Builds several query variations (deterministic + LLM-enriched) and
       tries each against the KB (HYBRID search, falling back to SEMANTIC)
       until one clears KB_MIN_SCORE.
    4. Retries once without theme filters if the filtered pass found
       nothing above KB_MIN_SCORE.
    5. Reranks the surviving results with Cohere rerank (optional, via
       KB_RERANKER_ENABLED) and returns the top KB_FINAL_MAX_RESULTS as
       sources + citations.

Running this file directly executes one example query and prints the
sources/citations/metadata returned.

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Uses LITELLM_TOKEN (see .env.template) for all three calls this script
makes to the LLM Gateway: chat completions (query enhancement + theme
mapping), rerank, and the Bedrock KB retrieve pass-through endpoint. This
is a different token than CLIENT_ID/CLIENT_SECRET used in step1/step2 -
those are Management API credentials, this is the LLM Gateway API key.
--------------------------------------------------------------------------------

Usage:
    python step3_retrieve_from_kb.py

    # or, imported:
    from step3_retrieve_from_kb import retrieve_from_kb
    result = retrieve_from_kb("What are the regulations for heated tobacco products?")
"""

import json
import os
import re
import ssl
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

# ==============================================================================
# CONFIGURATION
# ==============================================================================
load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

LITELLM_CHAT_URL = os.environ.get(
    "LITELLM_CHAT_URL", "https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions"
)
LITELLM_RERANK_URL = os.environ.get(
    "LITELLM_RERANK_URL", "https://litellm.aiplat-dev.aws.private-pmideep.biz/rerank"
)
LITELLM_KB_RETRIEVE_URL = os.environ.get(
    "LITELLM_KB_RETRIEVE_URL",
    "https://litellm.aiplat-dev.aws.private-pmideep.biz/bedrock/knowledgebases/{kb_id}/retrieve",
)

LITELLM_TOKEN = os.environ.get("LITELLM_TOKEN")
TENANT = os.environ.get("TENANT", "ccaiaa-dev")
# Defaults to the English KB that already exists for ccaiaa-dev.
KB_ID = os.environ.get("KB_ID", "WQURRONWPQ")

LITELLM_CHAT_MODEL = os.environ.get("LITELLM_CHAT_MODEL", "bedrock/us.anthropic.claude-sonnet-4-6")
LITELLM_RERANK_MODEL = os.environ.get(
    "LITELLM_RERANK_MODEL", "bedrock/arn:aws:bedrock:us-east-1::foundation-model/cohere.rerank-v3-5:0"
)

KB_VECTOR_MAX_RESULTS = int(os.environ.get("KB_VECTOR_MAX_RESULTS", "15"))
KB_FINAL_MAX_RESULTS = int(os.environ.get("KB_FINAL_MAX_RESULTS", "5"))
KB_MIN_SCORE = float(os.environ.get("KB_MIN_SCORE", "0.50"))
KB_SOURCE_MAX_CHARS = int(os.environ.get("KB_SOURCE_MAX_CHARS", "12000"))
KB_MAX_QUERIES = int(os.environ.get("KB_MAX_QUERIES", "8"))

KB_LLM_TIMEOUT_SECONDS = int(os.environ.get("KB_LLM_TIMEOUT_SECONDS", "60"))
KB_SIGNAL_MAX_TOKENS = int(os.environ.get("KB_SIGNAL_MAX_TOKENS", "300"))
KB_QUERY_ENRICH_MAX_TOKENS = int(os.environ.get("KB_QUERY_ENRICH_MAX_TOKENS", "300"))
KB_THEME_MAX_TOKENS = int(os.environ.get("KB_THEME_MAX_TOKENS", "150"))

KB_THEME_MAPPING_ENABLED = os.environ.get("KB_THEME_MAPPING_ENABLED", "true").lower() in ("1", "true", "yes")
KB_RERANKER_ENABLED = os.environ.get("KB_RERANKER_ENABLED", "true").lower() in ("1", "true", "yes")
KB_RERANK_TOP_N = int(os.environ.get("KB_RERANK_TOP_N", "5"))


# ==============================================================================
# Helpers
# ==============================================================================

def _ssl_context():
    """SSL context for PMI's internal endpoints (verification intentionally
    disabled to match how these internal hosts are reached in this
    environment - see DEPLOYMENT_GUIDE.md)."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _clean_source_url(value: Any) -> str:
    url = str(value or "").strip()
    if not url:
        return ""
    return re.split(r"\s+", url)[0].strip()


def _extract_json_from_llm_response(raw: str) -> Optional[Any]:
    if not raw:
        return None
    text = raw.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].strip().startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    for open_char, close_char in (("{", "}"), ("[", "]")):
        start = text.find(open_char)
        end = text.rfind(close_char)
        if start != -1 and end != -1 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except Exception:
                continue
    return None


# ==============================================================================
# LiteLLM Gateway calls
# ==============================================================================

def call_litellm_chat(prompt: str, max_tokens: int, timeout_seconds: int, temperature: float = 0.0) -> Optional[Any]:
    """Call the LiteLLM chat endpoint and parse a JSON object/array out of the reply."""
    if not LITELLM_TOKEN:
        print("LiteLLM token not configured - skipping LLM call")
        return None
    try:
        payload = {
            "model": LITELLM_CHAT_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        headers = {"Authorization": f"Bearer {LITELLM_TOKEN}", "Content-Type": "application/json"}
        req = urllib.request.Request(
            LITELLM_CHAT_URL, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
        )
        with urllib.request.urlopen(req, context=_ssl_context(), timeout=timeout_seconds) as response:
            result = json.loads(response.read().decode("utf-8"))
        raw = result.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
        return _extract_json_from_llm_response(raw)
    except urllib.error.HTTPError as e:
        print(f"LiteLLM chat HTTP error {e.code}: {e.read().decode('utf-8', errors='replace')[:500]}")
        return None
    except Exception as e:
        print(f"LiteLLM chat call failed: {e}")
        return None


def call_litellm_rerank(query: str, documents: List[str], top_n: int) -> Optional[List[Dict[str, Any]]]:
    """Call the LiteLLM rerank endpoint (Cohere rerank model)."""
    if not LITELLM_TOKEN or not documents:
        return None
    try:
        payload = {"model": LITELLM_RERANK_MODEL, "query": query, "documents": documents, "top_n": top_n}
        headers = {"Authorization": f"Bearer {LITELLM_TOKEN}", "Content-Type": "application/json"}
        req = urllib.request.Request(
            LITELLM_RERANK_URL, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
        )
        with urllib.request.urlopen(req, context=_ssl_context(), timeout=300) as response:
            result = json.loads(response.read().decode("utf-8"))
        return result.get("results", [])
    except urllib.error.HTTPError as e:
        print(f"LiteLLM rerank HTTP error {e.code}: {e.read().decode('utf-8', errors='replace')[:500]}")
        return None
    except Exception as e:
        print(f"LiteLLM rerank call failed: {e}")
        return None


def retrieve_from_litellm_kb(
    query: str, max_results: int = 15, filters: Optional[Dict[str, Any]] = None
) -> List[Dict[str, Any]]:
    """Call the Bedrock KB retrieve pass-through endpoint via the LiteLLM Gateway."""
    if not query or not query.strip() or not LITELLM_TOKEN or not KB_ID:
        return []

    try:
        url = LITELLM_KB_RETRIEVE_URL.format(tenant=TENANT, kb_id=KB_ID)
        payload = {
            "retrievalQuery": {"text": query},
            "retrievalConfiguration": {
                "vectorSearchConfiguration": {
                    "numberOfResults": min(max_results, 25),
                    "overrideSearchType": "HYBRID",
                }
            },
        }

        if filters:
            conditions = []
            if filters.get("jurisdiction"):
                jur = filters["jurisdiction"]
                conditions.append({
                    "orAll": [
                        {"equals": {"key": "jurisdiction", "value": jur}},
                        {"equals": {"key": "jurisdiction", "value": "global"}},
                        {"equals": {"key": "jurisdiction", "value": "Global"}},
                    ]
                })
            if filters.get("theme_level_1"):
                conditions.append({"stringContains": {"key": "theme-level-1", "value": filters["theme_level_1"]}})
            if filters.get("theme_level_2"):
                conditions.append({"stringContains": {"key": "theme-level-2", "value": filters["theme_level_2"]}})

            if len(conditions) == 1:
                payload["retrievalConfiguration"]["vectorSearchConfiguration"]["filter"] = conditions[0]
            elif conditions:
                payload["retrievalConfiguration"]["vectorSearchConfiguration"]["filter"] = {"andAll": conditions}

        headers = {"Authorization": f"Bearer {LITELLM_TOKEN}", "Content-Type": "application/json"}
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
        )

        try:
            with urllib.request.urlopen(req, context=_ssl_context(), timeout=60) as response:
                result = json.loads(response.read().decode("utf-8"))
        except Exception as hybrid_error:
            print(f"HYBRID search failed ({hybrid_error}), retrying with SEMANTIC")
            payload["retrievalConfiguration"]["vectorSearchConfiguration"].pop("overrideSearchType", None)
            req = urllib.request.Request(
                url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
            )
            with urllib.request.urlopen(req, context=_ssl_context(), timeout=60) as response:
                result = json.loads(response.read().decode("utf-8"))

        transformed = []
        for item in result.get("retrievalResults", []):
            content = item.get("content", {}).get("text", "")
            score = item.get("score", 0.0)
            s3_uri = item.get("location", {}).get("s3Location", {}).get("uri", "")
            metadata = item.get("metadata", {}) or {}

            doc_title = metadata.get("source-filename", "")
            if not doc_title and s3_uri:
                doc_title = s3_uri.split("/")[-1].rsplit(".", 1)[0].replace("_", " ").replace("-", " ")

            sharepoint_url = _clean_source_url(metadata.get("url", "") or s3_uri)

            transformed.append({
                "content": content,
                "similarity_score": round(float(score), 4),
                "document_title": doc_title,
                "metadata": {
                    "file_name": s3_uri.split("/")[-1] if s3_uri else "",
                    "sharepoint_url": sharepoint_url,
                    "s3_uri": s3_uri,
                    "jurisdiction": metadata.get("jurisdiction", ""),
                    "theme_level_1": metadata.get("theme-level-1", ""),
                    "theme_level_2": metadata.get("theme-level-2", ""),
                    "language": metadata.get("language", "English"),
                    "file_extension": metadata.get("file-extension", ""),
                    "department": metadata.get("department", ""),
                },
                "sharepoint_url": sharepoint_url,
            })

        return transformed

    except urllib.error.HTTPError as e:
        print(f"KB retrieval HTTP error {e.code}: {e.read().decode('utf-8', errors='replace')[:500]}")
        return []
    except Exception as e:
        print(f"KB retrieval failed: {e}")
        return []


# ==============================================================================
# Query enhancement
# ==============================================================================

def extract_semantic_signals(topic: str, background: str, use_case: str, category: str, jurisdiction: str = "") -> Dict[str, str]:
    """Extract search-relevant signal from raw query text. Tries an LLM call
    first; falls back to simple stopword stripping if that fails."""
    if not (topic or background):
        return {"topic_core": "", "background_signal": ""}

    prompt = f"""
You are a semantic signal extractor for a document vector retrieval system.

Given the raw user/research input below, extract only the domain-relevant semantic content that would help retrieve matching documents from a knowledge base.

Topic:
{topic or "N/A"}

Background:
{background or "N/A"}

Jurisdiction:
{jurisdiction or "N/A"}

Use case:
{use_case or "N/A"}

Category:
{category or "N/A"}

Extract:
1. topic_core: 3 to 12 words capturing the core subject. Preserve compound domain concepts.
2. background_signal: up to 150 characters of domain-relevant facts from the background.

Rules:
- Remove generic words like tell me, explain, current, latest, details, document, submission, about.
- Keep company names, regulation names, authorities, product names, policy terms, key acronyms, and domain concepts.
- Return ONLY JSON with exactly these keys:
  {{
    "topic_core": "...",
    "background_signal": "..."
  }}
"""
    result = call_litellm_chat(prompt, KB_SIGNAL_MAX_TOKENS, KB_LLM_TIMEOUT_SECONDS)

    if isinstance(result, dict) and result.get("topic_core"):
        return {
            "topic_core": str(result.get("topic_core", "")).strip(),
            "background_signal": str(result.get("background_signal", "")).strip(),
        }

    # Fallback: strip common stopwords instead of failing the whole query.
    stopwords = {
        "a", "an", "the", "for", "of", "in", "on", "at", "to", "with", "and", "or",
        "but", "is", "are", "was", "were", "be", "been", "about", "regarding",
        "related", "concerning", "tell", "me", "explain", "current", "latest",
        "details", "add", "also",
    }
    tokens = re.split(r"[\s,;:()\-_/]+", (topic or "").lower())
    topic_core = " ".join(t for t in tokens if t and t not in stopwords and len(t) > 2)
    background_signal = re.sub(r"\s+", " ", background or "").strip()[:150]
    return {"topic_core": topic_core, "background_signal": background_signal}


def derive_intent(use_case: str, category: str) -> str:
    intent_map = {
        "submission": "regulatory submission compliance",
        "report": "policy analysis report",
        "communication": "stakeholder communication",
        "response": "regulatory response",
        "application": "regulatory application",
        "representation": "industry representation",
        "briefing": "policy briefing",
        "comment": "public comment regulatory",
        "appeal": "regulatory appeal",
        "petition": "regulatory petition",
        "answer": "research answer",
        "chat_research": "research answer",
    }
    combined = f"{use_case} {category}".lower()
    for key, value in intent_map.items():
        if key in combined:
            return value
    return (use_case or category or "research answer").strip()


def derive_entity(target_audience: str) -> str:
    entity_map = {
        "cbic": "customs excise authority",
        "gst": "goods services tax authority",
        "mohfw": "health ministry regulator",
        "ministry of health": "health ministry regulator",
        "who": "world health organization international",
        "cpcb": "environment pollution control authority",
        "fssai": "food safety standards authority",
        "sebi": "securities exchange board regulator",
        "rbi": "reserve bank central authority",
        "parliament": "legislative authority",
        "committee": "parliamentary standing committee",
        "ministry": "government ministry authority",
        "department": "government department",
        "tribunal": "judicial regulatory tribunal",
    }
    lower_value = (target_audience or "").lower()
    for key, value in entity_map.items():
        if key in lower_value:
            return value
    return (target_audience or "").strip()


def llm_enrich_queries(topic_core: str, intent: str, entity: str, jurisdiction: str, background_signal: str) -> List[str]:
    """Ask the LLM for 2 additional phrasing variants of the query."""
    if not topic_core:
        return []

    prompt = f"""
Generate exactly 2 short semantic search queries for a vector database retrieval task.

Structured input:
- Topic: {topic_core}
- Intent: {intent or "N/A"}
- Target entity: {entity or "N/A"}
- Jurisdiction: {jurisdiction or "N/A"}
- Domain context: {background_signal or "N/A"}

Rules:
- Each query must be 5 to 14 words.
- Reflect domain document meaning, not casual user phrasing.
- Query 1 should be generic and not mention jurisdiction unless essential.
- Query 2 can include jurisdiction/entity if useful.
- Output ONLY a JSON array of 2 strings.
"""
    result = call_litellm_chat(prompt, KB_QUERY_ENRICH_MAX_TOKENS, KB_LLM_TIMEOUT_SECONDS)
    if isinstance(result, list):
        return [str(item).strip() for item in result if isinstance(item, str) and item.strip()][:2]
    return []


def map_kb_theme(topic_core: str, background_signal: str, jurisdiction: str) -> Dict[str, str]:
    """Classify the query against the KB's theme-level-1/2 metadata taxonomy."""
    if not KB_THEME_MAPPING_ENABLED or not topic_core:
        return {"level_1": "", "level_2": ""}

    prompt = f"""
You are classifying a research query for a knowledge base metadata filter.

Topic:
{topic_core}

Background:
{background_signal[:300]}

Jurisdiction:
{jurisdiction or "N/A"}

LEVEL 1 OPTIONS, pick the single best match:
- Smoke-free products (SFP)/ heated tobacco products (HTP)
- Combustible cigarettes
- Corporate Equity

LEVEL 2 OPTIONS, pick the single best match:
- Regulatory, Product standard system
- Fiscal and Taxes
- Illicit Trade
- Scientific
- Youth Access Prevention
- Sustainability
- Others

Return ONLY JSON:
{{
  "level_1": "...",
  "level_2": "..."
}}

If the topic does not clearly fit, use "Others".
"""
    result = call_litellm_chat(prompt, KB_THEME_MAX_TOKENS, KB_LLM_TIMEOUT_SECONDS)
    if not isinstance(result, dict):
        return {"level_1": "", "level_2": ""}

    level_1 = str(result.get("level_1", "")).strip()
    level_2 = str(result.get("level_2", "")).strip()
    if level_1.lower() == "others":
        level_1 = ""
    if level_2.lower() == "others":
        level_2 = ""
    return {"level_1": level_1, "level_2": level_2}


def build_query_candidates(requirements: Dict[str, Any], signals: Dict[str, str]) -> List[str]:
    """Combine deterministic phrasing + LLM-enriched + caller-supplied queries, deduplicated."""
    topic_core = signals.get("topic_core", "")
    background_signal = signals.get("background_signal", "")
    jurisdiction = requirements.get("jurisdiction", "")
    category = requirements.get("category", "")
    intent = derive_intent(requirements.get("use_case", ""), category)
    entity = derive_entity(requirements.get("target_audience", ""))

    deterministic_queries = [
        " ".join(x for x in [jurisdiction, topic_core, background_signal, intent, entity] if x).strip(),
        " ".join(x for x in [jurisdiction, topic_core, background_signal, intent] if x).strip(),
        " ".join(x for x in [entity, jurisdiction, topic_core, background_signal] if x).strip(),
        " ".join(x for x in [category, intent, jurisdiction, topic_core, background_signal] if x).strip(),
        " ".join(x for x in [topic_core, background_signal, intent] if x).strip(),
        " ".join(x for x in [topic_core, intent, entity, background_signal] if x).strip(),
    ]

    llm_queries = llm_enrich_queries(topic_core, intent, entity, jurisdiction, background_signal)
    planned_queries = requirements.get("_planned_queries", []) or []
    if isinstance(planned_queries, str):
        planned_queries = [planned_queries]

    seen = set()
    deduped = []
    for query in deterministic_queries + llm_queries + planned_queries:
        if not query:
            continue
        key = str(query).strip().lower()
        if key and key not in seen:
            seen.add(key)
            deduped.append(str(query).strip())

    return deduped[:KB_MAX_QUERIES]


# ==============================================================================
# Main retrieval function
# ==============================================================================

def build_requirements_from_query(query: str) -> Dict[str, Any]:
    clean_query = (query or "").strip()
    return {
        "topic": clean_query,
        "background": clean_query,
        "jurisdiction": "",
        "category": "chat_research",
        "use_case": "answer",
        "target_audience": "",
        "_planned_queries": [clean_query] if clean_query else [],
    }


def retrieve_from_kb(query: str, max_results: int = 5) -> Dict[str, Any]:
    """
    Main entry point: retrieve documents from the English KB for a query.

    Args:
        query: user query or research question
        max_results: maximum number of final results to return

    Returns:
        dict with status, results/sources, citations, queries tried, and metadata
    """
    try:
        if not query or not query.strip():
            return {
                "status": "success", "query": query, "results": [], "sources": [],
                "citations": [], "queries": [],
                "metadata": {"tool": "litellm_kb_retrieval", "message": "Empty query"},
            }

        print("\n" + "=" * 80)
        print("ENGLISH KB RETRIEVAL")
        print("=" * 80)
        print(f"Query:  {query}")
        print(f"KB ID:  {KB_ID}")
        print(f"Tenant: {TENANT}")
        print("=" * 80 + "\n")

        final_limit = max(1, min(max_results, KB_FINAL_MAX_RESULTS))
        requirements = build_requirements_from_query(query)

        signals = extract_semantic_signals(
            topic=requirements.get("topic", ""),
            background=requirements.get("background", ""),
            use_case=requirements.get("use_case", ""),
            category=requirements.get("category", ""),
            jurisdiction=requirements.get("jurisdiction", ""),
        )
        theme = map_kb_theme(
            topic_core=signals.get("topic_core", ""),
            background_signal=signals.get("background_signal", ""),
            jurisdiction=requirements.get("jurisdiction", ""),
        )
        query_candidates = build_query_candidates(requirements, signals) or [query]

        jurisdiction = requirements.get("jurisdiction", "")
        filters = {}
        if jurisdiction:
            filters["jurisdiction"] = jurisdiction
        if theme.get("level_1"):
            filters["theme_level_1"] = theme["level_1"]
        if theme.get("level_2"):
            filters["theme_level_2"] = theme["level_2"]

        used_query = query_candidates[0]
        kb_results: List[Dict[str, Any]] = []

        # Pass 1: with theme filters (if any)
        for candidate_query in query_candidates:
            results = retrieve_from_litellm_kb(candidate_query, KB_VECTOR_MAX_RESULTS, filters or None)
            if not results:
                continue
            max_score = max((r.get("similarity_score", 0) for r in results), default=0)
            if max_score >= KB_MIN_SCORE:
                kb_results, used_query = results, candidate_query
                break

        # Pass 2: retry without theme filters if pass 1 found nothing usable
        if not kb_results and (theme.get("level_1") or theme.get("level_2")):
            filters_no_theme = {"jurisdiction": jurisdiction} if jurisdiction else {}
            for candidate_query in query_candidates:
                results = retrieve_from_litellm_kb(candidate_query, KB_VECTOR_MAX_RESULTS, filters_no_theme or None)
                if not results:
                    continue
                max_score = max((r.get("similarity_score", 0) for r in results), default=0)
                if max_score >= KB_MIN_SCORE:
                    kb_results, used_query = results, candidate_query
                    break

        # Reranking (optional)
        if KB_RERANKER_ENABLED and kb_results:
            documents = [r.get("content", "") for r in kb_results]
            rerank_results = call_litellm_rerank(used_query, documents, min(KB_RERANK_TOP_N, len(documents)))
            if rerank_results:
                reranked = []
                for item in rerank_results:
                    idx = item.get("index")
                    relevance = item.get("relevance_score", item.get("relevanceScore", 0))
                    if idx is not None and idx < len(kb_results):
                        r = kb_results[idx].copy()
                        r["rerank_score"] = round(float(relevance), 4)
                        r["original_score"] = r["similarity_score"]
                        r["similarity_score"] = round(float(relevance), 4)
                        reranked.append(r)
                if reranked:
                    kb_results = reranked

        # Build final sources/citations
        sources, citations, seen_titles = [], [], set()
        for index, result in enumerate(kb_results):
            score = float(result.get("similarity_score", 0))
            if score < KB_MIN_SCORE:
                continue

            doc_name = result.get("document_title") or result.get("metadata", {}).get("file_name") or f"Document_{index + 1}"
            metadata = result.get("metadata", {}) or {}
            sharepoint_url = _clean_source_url(
                result.get("sharepoint_url") or metadata.get("sharepoint_url") or metadata.get("s3_uri") or ""
            )

            if "metadata.json" in str(doc_name).lower() or "metadata.json" in str(sharepoint_url).lower():
                continue

            content = result.get("content", "") or ""
            if KB_SOURCE_MAX_CHARS > 0 and len(content) > KB_SOURCE_MAX_CHARS:
                content = content[:KB_SOURCE_MAX_CHARS] + "\n\n...[truncated]"

            source = {
                "title": doc_name,
                "source": "LiteLLM Knowledge Base",
                "type": "internal_knowledge",
                "date": datetime.now().strftime("%Y-%m-%d"),
                "relevance_score": round(score, 4),
                "summary": content,
                "url": sharepoint_url,
            }
            if "rerank_score" in result:
                source["rerank_score"] = result["rerank_score"]
                source["original_score"] = result["original_score"]

            sources.append(source)
            if doc_name not in seen_titles:
                seen_titles.add(doc_name)
                citations.append({"title": doc_name, "url": sharepoint_url, "source_type": "knowledge_base"})

            if len(sources) >= final_limit:
                break

        max_score_final = max((s.get("relevance_score", 0) for s in sources), default=0)
        print(f"Retrieval completed: {len(sources)} sources, max_score={max_score_final}")
        print("=" * 80 + "\n")

        return {
            "status": "success",
            "query": query,
            "results": sources,
            "sources": sources,
            "citations": citations,
            "queries": [used_query] + [q for q in query_candidates if q != used_query],
            "metadata": {
                "tool": "litellm_kb_retrieval",
                "kb_id": KB_ID,
                "tenant": TENANT,
                "used_query": used_query,
                "query_count": len(query_candidates),
                "results_count": len(sources),
                "citations_count": len(citations),
                "max_score": max_score_final,
                "min_score": KB_MIN_SCORE,
                "theme_level_1": theme.get("level_1", ""),
                "theme_level_2": theme.get("level_2", ""),
                "theme_mapping_enabled": KB_THEME_MAPPING_ENABLED,
                "reranker_enabled": KB_RERANKER_ENABLED,
                "vector_max_results": KB_VECTOR_MAX_RESULTS,
                "final_max_results": final_limit,
            },
        }

    except Exception as e:
        print(f"Retrieval failed: {e}")
        return {
            "status": "error", "query": query, "results": [], "sources": [],
            "citations": [], "queries": [], "error": str(e),
            "metadata": {"tool": "litellm_kb_retrieval", "error": str(e)},
        }


if __name__ == "__main__":
    if not LITELLM_TOKEN:
        print("ERROR: LITELLM_TOKEN must be set in .env")
        raise SystemExit(1)
    if not KB_ID:
        print("ERROR: KB_ID must be set in .env (see step1_create_kb.py output)")
        raise SystemExit(1)

    test_query = "What are the regulations for heated tobacco products in India?"

    print("=" * 80)
    print("STEP 3 of 3: RETRIEVE FROM ENGLISH KNOWLEDGE BASE (example query)")
    print("=" * 80)
    print(f"Test query: {test_query}")
    print("=" * 80)

    result = retrieve_from_kb(test_query, max_results=5)

    print("\n" + "=" * 80)
    print("RESULTS")
    print("=" * 80)
    print(f"Status: {result['status']}")
    print(f"Sources found: {len(result['sources'])}")
    print(f"Citations: {len(result['citations'])}")

    for i, source in enumerate(result["sources"], 1):
        print(f"\n--- Source {i} ---")
        print(f"Title: {source['title']}")
        print(f"Score: {source['relevance_score']}")
        if "rerank_score" in source:
            print(f"Rerank Score: {source['rerank_score']} (original: {source['original_score']})")
        print(f"URL: {source['url']}")
        print(f"Content: {source['summary'][:200]}...")

    print("\n" + "=" * 80)
    print("Metadata:")
    print(json.dumps(result["metadata"], indent=2))
    print("=" * 80 + "\n")
