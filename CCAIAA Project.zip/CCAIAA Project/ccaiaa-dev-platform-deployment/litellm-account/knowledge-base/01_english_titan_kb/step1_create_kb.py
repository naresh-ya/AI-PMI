#!/usr/bin/env python3
"""
STEP 1 of 3 - Create the English Knowledge Base (Titan embeddings)
================================================================================

WHEN TO USE THIS SCRIPT:
    Run once to create the KB resource for this tenant. If a KB named
    KB_NAME already exists (checked automatically before creating anything),
    the script exits without creating a duplicate.

WHAT THIS SCRIPT DOES:
    1. Obtains an OAuth2 access token (client credentials grant) for the
       KB Management API.
    2. Checks whether a KB named KB_NAME already exists for this tenant.
    3. Creates the KB with Titan embeddings + SEMANTIC chunking, backed by
       the S3 bucket/prefix configured below.
    4. Polls status every 30 seconds until the KB reaches CREATED (or a
       terminal failure state). A fresh OpenSearch collection can take
       15-30 minutes to provision.

NEXT STEP AFTER THIS SCRIPT:
    1. Upload documents to S3 (see "AUTHENTICATION" note below - this is a
       DIFFERENT credential/profile than the one this script uses).
    2. ./step2_sync_kb.py - triggers ingestion of the uploaded documents.

--------------------------------------------------------------------------------
AUTHENTICATION (READ BEFORE RUNNING)
--------------------------------------------------------------------------------
This script authenticates to the KB Management API via OAuth2 client
credentials (Cognito), loaded from a .env file per .env.template in this
folder. CLIENT_ID / CLIENT_SECRET are Vault-sourced, tenant-scoped
credentials - see .env.template for the exact Vault path. Nothing here is
personal to one developer.

    [!] UPLOADING DOCUMENTS TO S3 IS A SEPARATE STEP, SEPARATE CREDENTIAL
    This script only creates the KB resource - it does NOT upload any
    documents. Document upload (`aws s3 cp ...`) uses the tenant's AWS
    Direct Access CLI profile (the same profile family the guardrails/
    package uses for its AWS-side scripts), NOT the CLIENT_ID/CLIENT_SECRET
    above. Two separate auth mechanisms in one workflow - see
    DEPLOYMENT_GUIDE.md, section "Two Separate Credential Contexts".
--------------------------------------------------------------------------------

Usage:
    python step1_create_kb.py
"""

import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

# ==============================================================================
# CONFIGURATION
# ==============================================================================
API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

# Load .env from this same folder
load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")

KB_NAME = os.environ.get("KB_NAME", "ccaiaa-dev-ccaiaa-kb-eng")
# The Management API wants the name WITHOUT the tenant prefix at creation time,
# but every other script in this package refers to the KB by its full name
# (tenant-prefixed) - KB_NAME above stays full, this strips the prefix once.
KB_NAME_SUFFIX = KB_NAME[len(TENANT) + 1:] if KB_NAME.startswith(f"{TENANT}-") else KB_NAME

DATA_SOURCE_NAME = os.environ.get("DATA_SOURCE_NAME", "sharepoint-docs")
S3_BUCKET = os.environ.get("S3_BUCKET", "ccaiaa-kb-dev")
S3_PREFIX = os.environ.get("S3_PREFIX", "English/SAICDIAandCapgeminiTeam-DIA-India/")
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")
EMBEDDING_DIMENSION = int(os.environ.get("EMBEDDING_DIMENSION", "1024"))
MAX_TOKENS = int(os.environ.get("MAX_TOKENS", "512"))
BUFFER_SIZE = int(os.environ.get("BUFFER_SIZE", "1"))
BREAKPOINT_THRESHOLD = int(os.environ.get("BREAKPOINT_THRESHOLD", "95"))


def get_access_token():
    """Get OAuth2 access token from Cognito (client credentials grant)."""
    print("Getting access token...")

    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")

    print("Access token obtained.\n")
    return response.json()["access_token"]


def kb_already_exists(token):
    """Check whether a KB named KB_NAME already exists for this tenant."""
    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases"
    headers = {"Authorization": f"Bearer {token}"}

    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        # Can't confirm either way - don't block creation on a listing failure.
        print(f"Warning: could not list existing KBs (HTTP {response.status_code}). Proceeding.")
        return False

    data = response.json()
    kbs = data if isinstance(data, list) else data.get("knowledge_bases", [])

    return any(isinstance(kb, dict) and kb.get("object_id") == KB_NAME for kb in kbs)


def create_kb(token):
    """Create the English KB with Titan embeddings + SEMANTIC chunking."""
    print("=" * 80)
    print("CREATING ENGLISH KNOWLEDGE BASE (Titan)")
    print("=" * 80)
    print(f"KB Name:         {KB_NAME}")
    print(f"Embedding Model: {EMBEDDING_MODEL}")
    print(f"Dimensions:      {EMBEDDING_DIMENSION}")
    print(f"S3 Bucket:       {S3_BUCKET}")
    print(f"S3 Prefix:       {S3_PREFIX}")
    print(f"Chunking:        SEMANTIC ({MAX_TOKENS} tokens, buffer {BUFFER_SIZE}, threshold {BREAKPOINT_THRESHOLD})")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    payload = {
        "name": KB_NAME_SUFFIX,
        "description": f"{TENANT} English knowledge base",
        "dataSourceName": DATA_SOURCE_NAME,
        "create_bucket": False,
        "bucket_name": S3_BUCKET,
        "bucket_inclusion_prefixes": [S3_PREFIX],
        "embedding_model": EMBEDDING_MODEL,
        "embedding_model_dimension": EMBEDDING_DIMENSION,
        "chunking_strategy": "SEMANTIC",
        "semantic_config": {
            "maxTokens": MAX_TOKENS,
            "bufferSize": BUFFER_SIZE,
            "breakpointPercentileThreshold": BREAKPOINT_THRESHOLD,
        },
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code not in (200, 201, 202):
        print(f"Failed to create KB! Status {response.status_code}: {response.text}")
        raise SystemExit(1)

    print("KB creation request submitted successfully.\n")
    return response.json()


def monitor_creation(token, poll_interval=30):
    """Poll KB status until CREATED (or a terminal failure state)."""
    print("Monitoring KB creation - this can take 15-30 minutes for a new")
    print(f"OpenSearch collection. Checking every {poll_interval} seconds.\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}"
    headers = {"Authorization": f"Bearer {token}"}

    check_count = 0
    while True:
        check_count += 1
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print(f"[Check #{check_count}] Cannot get status (HTTP {response.status_code})")
            time.sleep(poll_interval)
            continue

        data = response.json()
        status = data.get("status_metadata", {}).get("status", "UNKNOWN")
        print(f"[Check #{check_count}] Status: {status}")

        if status == "CREATED":
            kb_data = (
                data.get("object_metadata", {})
                .get("knowledge_base", {})
                .get("knowledge_base_data", {})
            )
            kb_id = kb_data.get("kb_id", "NOT_FOUND")

            print("\nKB created successfully.")
            print(f"  KB Name: {KB_NAME}")
            print(f"  KB ID:   {kb_id}")
            return kb_id

        if status in ("FAILED", "ROLLED_BACK", "ROLLBACK_FAILED"):
            print(f"\nKB creation failed with status: {status}")
            print(data)
            raise SystemExit(1)

        time.sleep(poll_interval)


def main():
    print("=" * 80)
    print("STEP 1 of 3: CREATE ENGLISH KNOWLEDGE BASE")
    print("=" * 80)

    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()

    print(f"Checking whether '{KB_NAME}' already exists...")
    if kb_already_exists(token):
        print(f"\nA KB named '{KB_NAME}' already exists for tenant '{TENANT}'.")
        print("Refusing to create a duplicate.")
        print("If you need its KB_ID, run: ../03_troubleshooting/get_kb_details.py")
        raise SystemExit(1)
    print("No existing KB with this name. Proceeding.\n")

    create_kb(token)
    kb_id = monitor_creation(token)

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)
    print(f"KB_NAME: {KB_NAME}")
    print(f"KB_ID:   {kb_id}")
    print("\nRecord KB_ID in your .env file - step3 (retrieval) needs it:")
    print(f"  KB_ID={kb_id}")
    print("\nNext steps:")
    print("  1. Upload documents to S3 (separate AWS CLI profile - see")
    print("     DEPLOYMENT_GUIDE.md, 'Two Separate Credential Contexts'):")
    print(f"       aws s3 cp <file> s3://{S3_BUCKET}/{S3_PREFIX}")
    print(f"       aws s3 cp <file>.metadata.json s3://{S3_BUCKET}/{S3_PREFIX}")
    print("  2. Run: ./step2_sync_kb.py")


if __name__ == "__main__":
    main()
