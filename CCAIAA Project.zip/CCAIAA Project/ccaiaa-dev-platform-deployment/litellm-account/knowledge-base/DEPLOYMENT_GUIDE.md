# Knowledge Base Deployment Guide

Scope: creating and deploying AWS Bedrock Knowledge Bases for the **ccaiaa-dev** tenant, and querying them through the LiteLLM Gateway. Two KBs are covered: an English KB (Titan embeddings) and a multilingual KB (Cohere embeddings).

This directory contains setup and troubleshooting scripts only. Golden-dataset generation, evaluation harnesses, and one-off debugging scripts from the original development work are not included here.

This is a separate service from the tenant's LiteLLM content guardrail (`../guardrails/`) — different scripts, different .env files, no shared code between the two.

---

## Directory Structure

```
knowledge-base/
├── DEPLOYMENT_GUIDE.md                        <- this file
├── requirements.txt
│
├── 01_english_titan_kb/                       <- primary, actively used
│   ├── .env.template
│   ├── step1_create_kb.py
│   ├── step2_sync_kb.py
│   └── step3_retrieve_from_kb.py
│
├── 02_multilingual_cohere_kb/                 <- REFERENCE ONLY - see its README.md
│   ├── .env.template
│   ├── README.md
│   ├── step1_create_kb_multilingual.py
│   ├── step2_sync_kb_multilingual.py
│   └── step3_retrieve_multilingual.py
│
└── 03_troubleshooting/                        <- shared by both KBs, on-demand
    ├── .env.template
    ├── list_all_kbs.py
    ├── get_kb_details.py
    ├── list_data_sources.py
    ├── add_data_source.py
    ├── delete_data_source.py
    ├── check_ingestion_jobs.py
    ├── fix_failed_ingestion.py
    ├── monitor_kb_health.py
    ├── validate_setup.py
    ├── test_metadata_filtering.py
    └── delete_kb.py
```

Each of the three folders has its **own** `.env`/`.env.template` — they are not shared. `03_troubleshooting/` works against whichever KB you point it at by setting `KB_NAME` (and `KB_ID` where needed) in its own `.env`.

---

## Prerequisites (First-Time Setup)

**1. Tools**
- Python 3.x and pip
- AWS CLI v2 (only needed for the document-upload step — see "Two Separate Credential Contexts" below)

**2. Install Python dependencies**
```bash
pip install -r requirements.txt
```

**3. Get Vault credentials**
- Vault UI: `https://vault-dev-dev.aws.private-pmideep.biz:8200`
- Log in with PMI OIDC / corporate credentials
- Path: `static-secret/genai-dev/custom-api/ccaiaa-dev`
- Copy `client_id` / `client_secret` into `CLIENT_ID` / `CLIENT_SECRET` in whichever folder's `.env` you're using

This is the same Vault path and the same OAuth client the guardrails package uses — the KB Management API and the guardrail-registration Management API sit behind the same "Custom API" credential.

**4. Get a LiteLLM Gateway API key** (needed for retrieval scripts, and for `test_metadata_filtering.py`)
- Same key the production application uses for chat completions
- Set as `LITELLM_TOKEN` in the relevant `.env`

**5. Get access to upload documents to S3** — see "Two Separate Credential Contexts" immediately below. This is a distinct step from Vault credentials above.

---

## Two Separate Credential Contexts (read before running step2 on either KB)

Every KB workflow has two halves that use **completely different authentication**:

| | KB Management API scripts (step1, step2, step3, troubleshooting) | S3 document upload |
|---|---|---|
| What it does | Create/sync/query the KB resource itself | Puts the actual document files where the KB can ingest them |
| Auth mechanism | OAuth2 client credentials (Cognito), from Vault | AWS CLI profile assuming the tenant's Direct Access IAM role |
| Credential source | `CLIENT_ID`/`CLIENT_SECRET` in `.env` | `~/.aws/config` profile — same family of profile the `../guardrails/` package uses for its AWS-side scripts |
| Where it's used | `step1_create_kb*.py`, `step2_sync_kb*.py`, `step3_retrieve*.py`, everything in `03_troubleshooting/` | The `aws s3 cp ...` command you run manually between step1 and step2 |

None of the Python scripts in this package touch S3 directly — `step1` only tells the KB Management API which bucket/prefix to *watch*. Uploading the files there is a separate manual step using your AWS CLI profile, done between `step1` and `step2`:

```bash
aws s3 cp document.pdf s3://ccaiaa-kb-dev/English/SAICDIAandCapgeminiTeam-DIA-India/
aws s3 cp document.pdf.metadata.json s3://ccaiaa-kb-dev/English/SAICDIAandCapgeminiTeam-DIA-India/
```

If your `aws s3 cp` fails with an access-denied error, check you've assumed the correct Direct Access role for this tenant — it is not the same login as your Vault/Cognito credentials above.

---

## Run Order — English KB (`01_english_titan_kb/`)

1. **`step1_create_kb.py`** — creates the KB (Titan embeddings, SEMANTIC chunking). Skips creation if a KB with the same name already exists. Prints `KB_ID` when done.
2. Upload documents + paired `.metadata.json` files to S3 (see credential note above).
3. **`step2_sync_kb.py`** — triggers ingestion, polls until complete, reports success rate.
4. **`step3_retrieve_from_kb.py`** — run directly for an example query, or import `retrieve_from_kb()` into your application for real RAG retrieval. This one does more than a plain vector search: it enriches the query with an LLM pass, maps it to the KB's theme metadata, tries several phrasings, and reranks results with Cohere rerank.

This is the KB in active use. Steps 1–3 are idempotent enough to be CI/CD candidates; step1 explicitly checks for an existing KB before creating, so re-running it is safe.

---

## Run Order — Multilingual KB (`02_multilingual_cohere_kb/`)

**[!] This folder is a reference, not a routine flow.** The multilingual KB already exists for ccaiaa-dev. Read `02_multilingual_cohere_kb/README.md` first — it explains why the same S3 bucket is used for both KBs, why language filtering is deliberately not applied on retrieval, and a known first-run KMS permission issue with a documented fix.

If you do need to create a new one (different tenant, or a genuine rebuild): same 3-step shape as the English KB (create → upload to S3 → sync → retrieve), using that folder's own `.env`.

---

## Troubleshooting Scripts (`03_troubleshooting/`)

Not tied to either KB — point `KB_NAME` (and `KB_ID` where relevant) in this folder's `.env` at whichever KB you're working on.

| Script | Purpose | Destructive? |
|---|---|---|
| `list_all_kbs.py` | List every KB in the tenant with ID/status/embedding model | No |
| `get_kb_details.py` | Full config dump for one KB — embedding, chunking, data sources, OpenSearch collection, resource status | No |
| `list_data_sources.py` | List just the data source(s) on a KB — bucket, prefix, chunking config | No |
| `add_data_source.py` | Add an additional S3 bucket/prefix to an existing KB | Modifies KB config (not deletion) |
| `delete_data_source.py` | Remove a data source's connection to a KB | Yes for the KB↔S3 link; S3 files untouched. Requires typing `DELETE` |
| `check_ingestion_jobs.py` | Full ingestion job history with per-job stats and AWS's actual failure reasons | No |
| `fix_failed_ingestion.py` | Detect failed documents and retrigger a sync to retry them | Triggers a real ingestion job (consumes quota) |
| `monitor_kb_health.py` | One-shot health check (status + data sources + ingestion rate), exit code 0/1 for scripting | No |
| `validate_setup.py` | Fuller pre-deployment checklist (env vars + auth + config + ingestion + retrieval), exit code 0/1 | No |
| `test_metadata_filtering.py` | Confirms whether a metadata filter (jurisdiction/theme) is actually narrowing results | No |
| `delete_kb.py` | Permanently delete a KB, its OpenSearch collection, and all indexed content | **Yes — irreversible.** Requires typing `DELETE`. Does not delete underlying S3 documents |

`get_kb_details.py` replaces an earlier `check_kb_status.py` variant from the original scripts that had a hardcoded KB-name bug (ignored the configured `KB_NAME`, always looked up `{tenant}-ccaiaa-kb-eng`) and used an older response shape — dropped in favor of this one, which is fully env-driven and works for either KB.

---

## Known Issues (carry these forward, don't silently "fix" without re-testing)

1. **Metadata filtering effectiveness varies by field/value.** `test_metadata_filtering.py` exists specifically because filter behavior isn't always obvious from a single test — always compare filtered vs. unfiltered result counts for the same query rather than trusting one pass/fail observation, and if a filter looks like it's not narrowing anything, confirm the field was actually populated in the document's `.metadata.json` at ingestion time before assuming the platform is at fault.

2. **Multilingual KB: KMS cross-account permission on first sync.** See `02_multilingual_cohere_kb/README.md`, "KMS Cross-Account Permission" — a brand-new multilingual (or any new) KB's first ingestion can fail on a decrypt/access-denied error if the tenant's KMS key policy doesn't yet grant the platform's ingestion roles. Documented fix included there; not a bug in these scripts.

3. **Retrieval quality is a moving target, not a fixed guarantee.** The English KB's `step3_retrieve_from_kb.py` relies on an LLM call to enrich queries and map themes — if that LLM call fails or `LITELLM_TOKEN` isn't set, it silently falls back to simpler keyword-based signal extraction rather than erroring out. Results will still return, just with less enrichment. Don't assume identical retrieval quality between a run with a working LLM call and one without.

---

## Environments Beyond ccaiaa-dev / dev

This guide currently only covers the `ccaiaa-dev` tenant in the dev environment. QA and PRD will need their own tenant name, Vault path, and (for the English KB) possibly different S3 bucket/prefix values — not documented here yet.
