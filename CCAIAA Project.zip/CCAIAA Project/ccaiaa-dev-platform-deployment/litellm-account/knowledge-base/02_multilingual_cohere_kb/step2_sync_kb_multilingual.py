#!/usr/bin/env python3
"""
STEP 2 of 3 - Sync the Multilingual Knowledge Base After S3 Upload
================================================================================

WHEN TO USE THIS SCRIPT:
    Run after uploading new/updated documents (+ paired .metadata.json
    files) to S3. Triggers an ingestion job that scans the configured S3
    prefix and indexes any new or changed documents.

    [!] If this fails with a decrypt/access-denied error on first run for a
    brand-new multilingual KB, see README.md "KMS Cross-Account Permission"
    - this KB's ingestion role needs an explicit KMS key policy grant that
    the English KB's ingestion role already had configured.

WHAT THIS SCRIPT DOES:
    1. Obtains an OAuth2 access token.
    2. Triggers a sync/ingestion job for KB_NAME_MULTILINGUAL.
    3. Polls progress every 15 seconds until all jobs reach a terminal state.

NEXT STEP AFTER THIS SCRIPT:
    ./step3_retrieve_multilingual.py

    If documents failed to ingest, the shared troubleshooting scripts work
    here too - just point KB_NAME at KB_NAME_MULTILINGUAL in that folder's
    .env: ../03_troubleshooting/check_ingestion_jobs.py and
    ../03_troubleshooting/fix_failed_ingestion.py

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Same OAuth2 client credentials as step1 - see .env.template in this folder.
--------------------------------------------------------------------------------

Usage:
    python step2_sync_kb_multilingual.py
"""

import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

# ==============================================================================
# CONFIGURATION
# ==============================================================================
API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"
POLL_INTERVAL_SECONDS = 15

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")
KB_NAME = os.environ.get("KB_NAME_MULTILINGUAL", "ccaiaa-dev-ccaiaa-kb-multi")


def get_access_token():
    """Get OAuth2 access token from Cognito (client credentials grant)."""
    print("Getting access token...")
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    print("Access token obtained.\n")
    return response.json()["access_token"]


def trigger_sync(token):
    """Trigger a KB sync/ingestion job."""
    print("=" * 80)
    print("TRIGGERING SYNC FOR MULTILINGUAL KB")
    print("=" * 80)
    print(f"KB Name: {KB_NAME}")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    response = requests.post(url, headers=headers)
    if response.status_code not in (200, 202):
        print(f"Failed to trigger sync! Status {response.status_code}: {response.text}")
        print("\n[!] If this looks like a decrypt/access-denied error, see")
        print("    README.md 'KMS Cross-Account Permission' in this folder.")
        return False

    print("Sync triggered successfully.\n")
    return True


def monitor_sync(token):
    """Poll sync status until all ingestion jobs reach a terminal state."""
    print("=" * 80)
    print("MONITORING SYNC PROGRESS")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}/sync"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    check_count = 0

    while True:
        check_count += 1
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print(f"[Check #{check_count}] Cannot get sync status (HTTP {response.status_code})")
            time.sleep(POLL_INTERVAL_SECONDS)
            continue

        jobs = response.json().get("ingestion_jobs", [])
        if not jobs:
            print(f"[Check #{check_count}] No ingestion jobs found yet...")
            time.sleep(POLL_INTERVAL_SECONDS)
            continue

        print(f"\n[Check #{check_count}]")
        all_complete = True
        total_scanned = total_failed = 0

        for job in jobs:
            ds_name = job.get("dataSourceName", "Unknown")
            status = job.get("status", "UNKNOWN")
            stats = job.get("statistics", {})
            scanned = stats.get("numberOfDocumentsScanned", 0)
            failed = stats.get("numberOfDocumentsFailed", 0)
            total_scanned += scanned
            total_failed += failed

            print(f"  {ds_name}: status={status} scanned={scanned} failed={failed}")

            if status not in ("COMPLETE", "FAILED"):
                all_complete = False

        if all_complete:
            success_rate = ((total_scanned - total_failed) / total_scanned * 100) if total_scanned else 0
            print("\n" + "=" * 80)
            print("SYNC COMPLETE")
            print("=" * 80)
            print(f"Documents scanned: {total_scanned}")
            print(f"Documents failed:  {total_failed}")
            print(f"Success rate:      {success_rate:.1f}%")
            if total_failed:
                print("\nSee ../03_troubleshooting/check_ingestion_jobs.py for failure reasons")
                print("(set KB_NAME=ccaiaa-dev-ccaiaa-kb-multi in that folder's .env first).")
            return

        time.sleep(POLL_INTERVAL_SECONDS)


def main():
    print("=" * 80)
    print("STEP 2 of 3: SYNC MULTILINGUAL KNOWLEDGE BASE")
    print("=" * 80)
    print("\n[!] Run this ONLY after the S3 document upload has finished.\n")

    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()

    if not trigger_sync(token):
        raise SystemExit(1)

    try:
        monitor_sync(token)
    except KeyboardInterrupt:
        print("\nMonitoring stopped by user. Sync continues in the background.")

    print("\nNext: ./step3_retrieve_multilingual.py")


if __name__ == "__main__":
    main()
