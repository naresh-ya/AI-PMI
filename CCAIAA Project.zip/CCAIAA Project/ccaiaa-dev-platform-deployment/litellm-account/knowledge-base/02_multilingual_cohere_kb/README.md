# Multilingual Knowledge Base (Cohere) — Reference Folder

**[!] This folder is a reference, not a routine deployment flow.**

The multilingual KB for `ccaiaa-dev` already exists (`ccaiaa-dev-ccaiaa-kb-multi`). Most of what a developer needs day-to-day — checking status, listing data sources, checking ingestion — is already covered by the **shared** `../03_troubleshooting/` scripts (just point `KB_NAME` at the multilingual KB in that folder's `.env`).

These 3 numbered scripts exist so a developer can see exactly how the multilingual KB was built and how it differs from the English one, and so a *new* multilingual KB (a different tenant, or a genuinely new one for this tenant) can be created without starting from scratch.

---

## How this differs from the English KB

| | English KB | Multilingual KB |
|---|---|---|
| Embedding model | `amazon.titan-embed-text-v2:0` | `cohere.embed-multilingual-v3` |
| Max input tokens | 8192 | 512 |
| Chunk size | 512 tokens | 450 tokens (safe margin under Cohere's limit) |
| Breakpoint threshold | 95 | 90 |
| S3 prefix | `English/SAICDIAandCapgeminiTeam-DIA-India/` | `Multilingual/sharepoint/` |
| OpenSearch collection | existing (shared with nothing else) | separate, dedicated collection |
| Language filtering on retrieval | N/A | **Not used** — see below |

### Why the same S3 bucket
Both KBs use `ccaiaa-kb-dev`, split only by prefix. This was a deliberate choice over a second bucket: one bucket to manage/secure, no duplicate bucket policies, and the platform already supports multiple KBs pointing at prefixes within the same bucket. The two KBs still get **separate OpenSearch collections** — that part is not optional, since Titan and Cohere embeddings are different vector spaces despite both being 1024-dimensional. Mixing them in one collection would silently corrupt similarity search.

### Why no language filter on retrieval
Cohere's multilingual embeddings support cross-lingual retrieval — an English query can surface a Vietnamese document. Filtering by `language` would throw away valid matches. The intended pattern is: query **both** KBs (English + multilingual) for every request and merge/rerank the combined results, rather than routing a query to one KB based on its language.

### Metadata schema (per-document, in the paired `.metadata.json`)
```json
{
  "metadataAttributes": {
    "language": "Thai",
    "jurisdiction": "South Africa",
    "theme-level-1": "Smoke-free products (SFP)/ heated tobacco products (HTP)",
    "theme-level-2": "Scientific, Fiscal and Taxes, Illicit Trade",
    "department": "Corporate Affairs",
    "valid-till": "2031-05-11T11:00:00Z"
  }
}
```
Every document needs a paired `<filename>.metadata.json` uploaded alongside it — same convention as the English KB.

---

## KMS Cross-Account Permission (read this if step2 fails on first run)

If you're creating a **brand-new** multilingual KB and `step2_sync_kb_multilingual.py` fails with a decrypt/access-denied error, this is a known, already-solved issue — not a bug in these scripts.

**Root cause:** the S3 bucket's KMS key lives in the tenant's own AWS account, but ingestion runs under GenAI Platform account roles. The English KB's ingestion role already had the necessary KMS key policy grant (added at some point during its setup); a brand-new data source can hit this because a new ingestion job session isn't automatically covered by an existing grant.

**Fix:** the tenant account's KMS key policy needs an explicit `Allow` statement for the platform's ingestion roles:
```json
{
  "Sid": "AllowGenAIPlatformToUseKey",
  "Effect": "Allow",
  "Principal": {
    "AWS": [
      "arn:aws:iam::<platform_account_id>:role/tenant-<tenant-name>",
      "arn:aws:iam::<platform_account_id>:role/eks-bedrock-management-api"
    ]
  },
  "Action": ["kms:Encrypt", "kms:Decrypt", "kms:ReEncrypt*", "kms:GenerateDataKey*", "kms:DescribeKey"],
  "Resource": "*"
}
```
Apply via AWS Console (KMS → Customer managed keys → key policy → edit) or `aws kms put-key-policy`, using the tenant's own AWS CLI profile (not the KB Management API credentials this folder's scripts use). Check the existing policy first — it may already be there from the English KB's setup, in which case there's nothing to do.

After fixing the policy, just re-run `step2_sync_kb_multilingual.py`.

---

## Run order (only if actually creating a new multilingual KB)

1. `step1_create_kb_multilingual.py` — creates the KB, prints `KB_ID_MULTILINGUAL`
2. Upload documents + `.metadata.json` pairs to S3 (separate AWS CLI credential — see `../01_english_titan_kb/step1_create_kb.py`'s authentication note)
3. `step2_sync_kb_multilingual.py` — ingests what's in S3
4. `step3_retrieve_multilingual.py` — confirm retrieval works

For anything else (status checks, listing data sources, fixing failed ingestion, deleting), use `../03_troubleshooting/` with `KB_NAME` set to the multilingual KB's name in that folder's `.env`.
