#!/usr/bin/env python3
"""
STEP 3 of 3 - Retrieve / Query the Multilingual Knowledge Base
================================================================================

WHEN TO USE THIS SCRIPT:
    Run after step2_sync_kb_multilingual.py has completed, to confirm the
    KB returns relevant results. Also importable - retrieve_from_kb() is
    what an application would call at runtime.

WHAT THIS SCRIPT DOES:
    Sends the query directly to the KB retrieve endpoint (HYBRID search)
    with optional metadata filters (jurisdiction, theme-level-1,
    theme-level-2). Unlike the English KB's step3 (see
    ../01_english_titan_kb/step3_retrieve_from_kb.py), this does NOT run an
    LLM query-enhancement pass first - it queries as-is. Add that layer
    yourself if your use case needs it; it was intentionally kept simple
    here since this folder is a reference implementation.

    [!] Language filtering is deliberately NOT used. Cohere's multilingual
    embeddings support cross-lingual retrieval (an English query can match
    a Vietnamese document), so filtering by language would throw away
    valid results. If your application needs both English and multilingual
    results, query BOTH KBs (this one and ../01_english_titan_kb/) and
    merge/rerank the combined results yourself.

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Uses LITELLM_TOKEN (see .env.template) against the LiteLLM Gateway's
Bedrock KB retrieve pass-through endpoint. Different token than
CLIENT_ID/CLIENT_SECRET used in step1/step2.
--------------------------------------------------------------------------------

Usage:
    python step3_retrieve_multilingual.py

    # or, imported:
    from step3_retrieve_multilingual import retrieve_from_kb
    results = retrieve_from_kb("What are the regulations for tobacco products?")
"""

import json
import os
from pathlib import Path

import requests
import urllib3
from dotenv import load_dotenv

# Internal PMI endpoint reached with verification disabled - see
# ../01_english_titan_kb/step3_retrieve_from_kb.py for the equivalent note.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================================================================
# CONFIGURATION
# ==============================================================================
load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
# Defaults to the multilingual KB that already exists for ccaiaa-dev.
KB_ID = os.environ.get("KB_ID_MULTILINGUAL", "LPMWAHDZS8")
KB_NAME = os.environ.get("KB_NAME_MULTILINGUAL", "ccaiaa-dev-ccaiaa-kb-multi")
LITELLM_TOKEN = os.environ.get("LITELLM_TOKEN")

KB_RETRIEVE_URL_TEMPLATE = "https://litellm.aiplat-dev.aws.private-pmideep.biz/bedrock/knowledgebases/{kb_id}/retrieve"


def retrieve_from_kb(query, filters=None, max_results=5):
    """
    Retrieve documents from the multilingual KB.

    Args:
        query: search text
        filters: optional metadata filter dict, e.g.
            {"equals": {"key": "jurisdiction", "value": "South Africa"}}
        max_results: number of results to return

    Returns:
        list of result dicts (score, content, metadata)
    """
    print("\n" + "=" * 80)
    print("RETRIEVING FROM MULTILINGUAL KB")
    print("=" * 80)
    print(f"Query: {query}")
    print(f"Max Results: {max_results}")
    if filters:
        print(f"Filters: {json.dumps(filters, indent=2)}")
    print("=" * 80 + "\n")

    if not KB_ID:
        raise Exception("KB_ID_MULTILINGUAL not set in .env - run step1_create_kb_multilingual.py first, or fetch it via ../03_troubleshooting/get_kb_details.py")
    if not LITELLM_TOKEN:
        raise Exception("LITELLM_TOKEN not set in .env")

    url = KB_RETRIEVE_URL_TEMPLATE.format(kb_id=KB_ID)
    headers = {"Authorization": f"Bearer {LITELLM_TOKEN}", "Content-Type": "application/json"}
    payload = {
        "retrievalQuery": {"text": query},
        "retrievalConfiguration": {"vectorSearchConfiguration": {"numberOfResults": max_results}},
    }
    if filters:
        payload["retrievalConfiguration"]["vectorSearchConfiguration"]["filter"] = filters

    response = requests.post(url, headers=headers, json=payload, verify=False)

    if response.status_code != 200:
        print(f"Retrieval failed! Status {response.status_code}: {response.text}")
        return []

    results = response.json().get("retrievalResults", [])
    print(f"Found {len(results)} results.\n")

    for i, doc in enumerate(results, 1):
        score = doc.get("score", 0)
        content = doc.get("content", {}).get("text", "")
        metadata = doc.get("metadata", {}) or {}

        print(f"Result #{i} (score={score:.3f})")
        if metadata:
            print(f"  Language:     {metadata.get('language', 'N/A')}")
            print(f"  Jurisdiction: {metadata.get('jurisdiction', 'N/A')}")
            print(f"  Theme L1:     {metadata.get('theme-level-1', 'N/A')}")
            print(f"  Theme L2:     {metadata.get('theme-level-2', 'N/A')}")
        preview = content[:300] + "..." if len(content) > 300 else content
        print(f"  Content: {preview}\n")

    return results


def main():
    """Example queries demonstrating unfiltered and filtered retrieval."""
    print("=" * 80)
    print("STEP 3 of 3: RETRIEVE FROM MULTILINGUAL KNOWLEDGE BASE (examples)")
    print("=" * 80)
    print(f"KB: {KB_NAME}  (KB_ID: {KB_ID})")
    print("=" * 80)

    if not LITELLM_TOKEN:
        print("ERROR: LITELLM_TOKEN must be set in .env")
        raise SystemExit(1)
    if not KB_ID:
        print("ERROR: KB_ID_MULTILINGUAL must be set in .env")
        raise SystemExit(1)

    print("\n--- Example 1: simple query, no filters ---")
    retrieve_from_kb("What are the regulations for tobacco products?", max_results=3)

    print("\n--- Example 2: filter by jurisdiction ---")
    retrieve_from_kb(
        "health regulations",
        filters={"equals": {"key": "jurisdiction", "value": "South Africa"}},
        max_results=3,
    )

    print("\n--- Example 3: filter by theme-level-2 ---")
    retrieve_from_kb(
        "taxation policy",
        filters={"stringContains": {"key": "theme-level-2", "value": "Fiscal and Taxes"}},
        max_results=3,
    )

    print("\n--- Example 4: combined filters (jurisdiction AND theme) ---")
    retrieve_from_kb(
        "smoke-free products",
        filters={
            "andAll": [
                {"equals": {"key": "jurisdiction", "value": "United States"}},
                {"stringContains": {"key": "theme-level-1", "value": "Smoke-free products"}},
            ]
        },
        max_results=3,
    )

    print("\n" + "=" * 80)
    print("Available metadata filters: jurisdiction, theme-level-1, theme-level-2")
    print("Language filtering is intentionally not used - see docstring above.")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
