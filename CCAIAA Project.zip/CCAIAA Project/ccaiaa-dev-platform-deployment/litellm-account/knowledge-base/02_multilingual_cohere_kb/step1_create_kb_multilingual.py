#!/usr/bin/env python3
"""
STEP 1 of 3 - Create the Multilingual Knowledge Base (Cohere embeddings)
================================================================================

[!] REFERENCE SCRIPT - READ THIS BEFORE RUNNING
    The multilingual KB already exists for ccaiaa-dev (KB_NAME_MULTILINGUAL
    below). This script is kept as a working reference for how it was
    built - most developers will never need to run it again. Only run this
    if you are deliberately creating a NEW multilingual KB (e.g. a
    different tenant/environment). See README.md in this folder for the
    full context on why this is reference-only and what's different from
    the English KB flow.

WHAT THIS SCRIPT DOES:
    1. Obtains an OAuth2 access token for the KB Management API.
    2. Creates a KB using Cohere multilingual embeddings (cross-lingual -
       a single English query can retrieve non-English documents and vice
       versa) with SEMANTIC chunking sized for Cohere's smaller 512-token
       input limit.
    3. Polls status every 30 seconds until CREATED (or a terminal failure).

NEXT STEP AFTER THIS SCRIPT:
    1. Upload documents + paired .metadata.json files to S3 (separate AWS
       CLI credential - see ../01_english_titan_kb/step1_create_kb.py's
       AUTHENTICATION note, same applies here).
    2. ./step2_sync_kb_multilingual.py

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Same OAuth2 client credentials (CLIENT_ID/CLIENT_SECRET from Vault) as the
English KB scripts - see .env.template in this folder.
--------------------------------------------------------------------------------

Usage:
    python step1_create_kb_multilingual.py
"""

import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

# ==============================================================================
# CONFIGURATION
# ==============================================================================
API_BASE = "https://aiplat-dev.aws.pmicloud.biz/api"
COGNITO_ENDPOINT = "https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT = os.environ.get("TENANT", "ccaiaa-dev")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")

KB_NAME = os.environ.get("KB_NAME_MULTILINGUAL", "ccaiaa-dev-ccaiaa-kb-multi")
KB_NAME_SUFFIX = KB_NAME[len(TENANT) + 1:] if KB_NAME.startswith(f"{TENANT}-") else KB_NAME

S3_BUCKET = os.environ.get("S3_BUCKET", "ccaiaa-kb-dev")
S3_PREFIX = os.environ.get("S3_PREFIX", "Multilingual/sharepoint/")
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "cohere.embed-multilingual-v3")
EMBEDDING_DIMENSION = int(os.environ.get("EMBEDDING_DIMENSION", "1024"))
MAX_TOKENS = int(os.environ.get("MAX_TOKENS", "450"))
BUFFER_SIZE = int(os.environ.get("BUFFER_SIZE", "1"))
BREAKPOINT_THRESHOLD = int(os.environ.get("BREAKPOINT_THRESHOLD", "90"))


def get_access_token():
    """Get OAuth2 access token from Cognito (client credentials grant)."""
    print("Getting access token...")
    response = requests.post(
        COGNITO_ENDPOINT,
        data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scope": f"https://aiplat-dev.aws.pmicloud.biz/tenant https://aiplat-dev.aws.pmicloud.biz/{TENANT}",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if response.status_code != 200:
        raise Exception(f"Failed to get token: {response.text}")
    print("Access token obtained.\n")
    return response.json()["access_token"]


def create_kb(token):
    """Create the multilingual KB with Cohere embeddings + SEMANTIC chunking."""
    print("=" * 80)
    print("CREATING MULTILINGUAL KNOWLEDGE BASE (Cohere)")
    print("=" * 80)
    print(f"KB Name:         {KB_NAME}")
    print(f"Embedding Model: {EMBEDDING_MODEL}")
    print(f"Dimensions:      {EMBEDDING_DIMENSION}")
    print(f"S3 Bucket:       {S3_BUCKET}")
    print(f"S3 Prefix:       {S3_PREFIX}")
    print(f"Chunking:        SEMANTIC ({MAX_TOKENS} tokens, buffer {BUFFER_SIZE}, threshold {BREAKPOINT_THRESHOLD})")
    print("=" * 80 + "\n")

    url = f"{API_BASE}/mgmt/v1/tenants/{TENANT}/knowledge-bases"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload = {
        "name": KB_NAME_SUFFIX,
        "description": "Multilingual knowledge base for non-English and English documents",
        "embedding_model": EMBEDDING_MODEL,
        "embedding_model_dimension": EMBEDDING_DIMENSION,
        "dataSourceName": "multilingual-docs",
        "create_bucket": False,
        "bucket_name": S3_BUCKET,
        "bucket_inclusion_prefixes": [S3_PREFIX],
        "chunking_strategy": "SEMANTIC",
        "semantic_config": {
            "maxTokens": MAX_TOKENS,
            "bufferSize": BUFFER_SIZE,
            "breakpointPercentileThreshold": BREAKPOINT_THRESHOLD,
        },
    }

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code not in (200, 201, 202):
        print(f"Failed to create KB! Status {response.status_code}: {response.text}")
        raise SystemExit(1)

    print("KB creation request submitted successfully.\n")
    return response.json()


def monitor_creation(token, poll_interval=30):
    """Poll KB status until CREATED (or a terminal failure state)."""
    print("Monitoring KB creation - this can take 15-30 minutes for a new")
    print(f"OpenSearch collection. Checking every {poll_interval} seconds.\n")

    url = f"{API_BASE}/mgmt/v2/tenants/{TENANT}/knowledge-bases/{KB_NAME}"
    headers = {"Authorization": f"Bearer {token}"}

    check_count = 0
    while True:
        check_count += 1
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print(f"[Check #{check_count}] Cannot get status (HTTP {response.status_code})")
            time.sleep(poll_interval)
            continue

        data = response.json()
        status = data.get("status", data.get("status_metadata", {}).get("status", "UNKNOWN"))
        print(f"[Check #{check_count}] Status: {status}")

        if status == "CREATED":
            kb_data = data.get("object_metadata", {}).get("knowledge_base", {}).get("knowledge_base_data", {})
            kb_id = kb_data.get("kb_id", "NOT_FOUND")

            print("\nKB created successfully.")
            print(f"  KB Name: {KB_NAME}")
            print(f"  KB ID:   {kb_id}")

            collection_data = data.get("object_metadata", {}).get("collection_data", {})
            if collection_data:
                print(f"  OpenSearch Collection: {collection_data.get('collection_name', 'N/A')}")

            return kb_id

        if status in ("FAILED", "ROLLED_BACK", "ROLLBACK_FAILED"):
            print(f"\nKB creation failed with status: {status}")
            print(data)
            raise SystemExit(1)

        time.sleep(poll_interval)


def main():
    print("=" * 80)
    print("STEP 1 of 3: CREATE MULTILINGUAL KNOWLEDGE BASE")
    print("=" * 80)
    print("\n[!] This is a reference script - see README.md before running.\n")

    if not CLIENT_ID or not CLIENT_SECRET:
        print("ERROR: CLIENT_ID and CLIENT_SECRET must be set in .env")
        raise SystemExit(1)

    token = get_access_token()
    create_kb(token)
    kb_id = monitor_creation(token)

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)
    print(f"KB_NAME_MULTILINGUAL: {KB_NAME}")
    print(f"KB_ID_MULTILINGUAL:   {kb_id}")
    print("\nRecord KB_ID_MULTILINGUAL in your .env file - step3 needs it.")
    print("\nNext steps:")
    print("  1. Upload documents + paired .metadata.json files to S3:")
    print(f"       aws s3 cp <file> s3://{S3_BUCKET}/{S3_PREFIX}")
    print(f"       aws s3 cp <file>.metadata.json s3://{S3_BUCKET}/{S3_PREFIX}")
    print("  2. Run: ./step2_sync_kb_multilingual.py")


if __name__ == "__main__":
    main()
