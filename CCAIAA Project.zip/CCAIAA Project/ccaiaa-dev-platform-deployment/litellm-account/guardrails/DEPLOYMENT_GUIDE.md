# Guardrail Deployment Guide

Scope: creating and deploying a custom content guardrail for the **ccaiaa-dev** tenant, and attaching it to that tenant's LiteLLM API key.

This directory contains the setup scripts only. Testing/validation scripts and past debugging history are not included here.

---

## Directory Structure

```
GUARDRAIL_DEPLOYMENT/
├── DEPLOYMENT_GUIDE.md                  <- this file
├── 01_bedrock_guardrail/
│   ├── step1_create_guardrail.py               (run once, to create the guardrail)
│   └── maintenance_update_guardrail_config.py  (run whenever the policy needs to change later)
├── 02_litellm_registration/
│   ├── .env.template                     (copy to .env and fill in)
│   ├── step2_register_guardrail_in_litellm.py
│   └── step3_manage_key_guardrail.py     (--check / --attach / --rollback)
└── 03_troubleshooting/                   (on-demand utilities, not part of the 1-2-3 flow)
    ├── fetch_guardrail_config.py          (read-only: show a guardrail's full config)
    ├── list_all_guardrails.py             (read-only: find guardrail IDs / list versions)
    ├── update_guardrail_name_or_tier.py   (rename and/or switch CLASSIC <-> STANDARD)
    └── delete_guardrail.py                (destructive: permanently deletes a guardrail)
```

Two subfolders for the required deployment flow, plus one for on-demand troubleshooting. The first two are governed by two different systems with two different identities:

| | `01_bedrock_guardrail/` | `02_litellm_registration/` |
|---|---|---|
| System | AWS Bedrock | PMI LiteLLM Management API |
| Auth | AWS IAM role assumption | OAuth2 client credentials (Vault) |
| Changes what | The guardrail policy itself | Which guardrail a LiteLLM key uses |

`03_troubleshooting/` scripts all operate on the AWS Bedrock side (same auth as `01_bedrock_guardrail/`) and are meant to be run individually, as needed, not in sequence.

---

## Prerequisites (First-Time Setup)

Do this once, before running any script.

**1. Tools**
- Python 3.x (tested with 3.14) and pip
- AWS CLI v2 (required for SSO-based profiles — v1 does not support `sso_session` config)

**2. Install Python dependencies**
```bash
pip install -r requirements.txt
```

**3. Get access to the tenant's AWS Direct Access role**
Configuring the `ccaiaa-dev-direct-access` profile (see "AWS Authentication" below) only works if your AWS SSO identity is already permitted to assume `arn:aws:iam::767398044071:role/tenant-ccaiaa-dev-direct-access`. If you don't have this yet, request it through your standard PMI AWS access request process before continuing — this guide does not grant access, it only assumes you already have it.

**4. Get Vault credentials**
- Vault UI: `https://vault-dev-dev.aws.private-pmideep.biz:8200`
- Log in with PMI OIDC / corporate credentials
- Path: `static-secret/genai-dev/custom-api/ccaiaa-dev`
- Copy `client_id` / `client_secret` into your `.env` (see `02_litellm_registration/.env.template`)

**5. If you get `TokenRetrievalError: Token has expired and refresh failed`**
Your AWS SSO session timed out. Re-run:
```bash
aws sso login --profile pmi-dev-pgaur
```
(substitute your own underlying SSO profile name if different from the example in this guide). Then retry the script.

**6. About `verify=False` in the LiteLLM scripts**
The `step2`/`step3` scripts disable SSL certificate verification (`urllib3.disable_warnings(...)`, `verify=False`) when calling PMI's internal Management API. This is intentional — matches how these internal endpoints are reached in this environment — not a shortcut to "fix" by re-enabling. Leave it as-is.

---

## Run Order

1. `01_bedrock_guardrail/step1_create_guardrail.py` — creates the guardrail in AWS Bedrock, prints `guardrailId` + `version`.
2. `02_litellm_registration/step2_register_guardrail_in_litellm.py` — set the `GUARDRAIL_ID`/`GUARDRAIL_VERSION` from step 1, run it. Prints a `GUARDRAIL_NAME` string.
3. `02_litellm_registration/step3_manage_key_guardrail.py --attach` — set `GUARDRAIL_NAME` from step 2, run with `--attach`. **This is the step that changes live behavior.**

To change the guardrail's policy later (add a filter, adjust a threshold, etc.), do **not** re-run step1. Use `01_bedrock_guardrail/maintenance_update_guardrail_config.py`, which produces a new version — then repeat steps 2 and 3 for that new version.

To revert a bad attach: `step3_manage_key_guardrail.py --rollback`.

---

## Troubleshooting Scripts (`03_troubleshooting/`)

Not part of the required flow above — run any of these on demand:

| Script | Purpose | Destructive? |
|---|---|---|
| `fetch_guardrail_config.py` | Print a guardrail's full live configuration (filters, PII, tags, tier) | No — read-only |
| `list_all_guardrails.py` | Find a guardrail's ID by name, or list all its versions | No — read-only |
| `update_guardrail_name_or_tier.py` | Rename a guardrail and/or switch CLASSIC ↔ STANDARD tier, without touching its actual policy (filters/PII/words carried forward unchanged) | Creates a new version (non-destructive, old versions remain) |
| `delete_guardrail.py` | Permanently delete a guardrail and all its versions | **Yes — irreversible.** Includes safety checks (blocks platform-defined and other-tenant guardrails) but does **not** check whether the guardrail is still referenced by LiteLLM — verify that manually first (see the script's docstring) |

[!] `list_all_guardrails.py` and `delete_guardrail.py`'s tenant check both matter because this AWS account is shared across many tenants — `list_guardrails` returns everyone's guardrails, not just this tenant's.

---

## AWS Authentication — Local vs. CI/CD

`step1` and `maintenance_update_guardrail_config.py` authenticate to AWS via an AWS CLI profile:

```ini
[profile ccaiaa-dev-direct-access]
role_arn = arn:aws:iam::767398044071:role/tenant-ccaiaa-dev-direct-access
source_profile = pmi-dev-pgaur
region = us-east-1
```

**`source_profile = pmi-dev-pgaur` is one developer's personal AWS SSO login.** This profile, as configured today, only works on that one machine. It is flagged with `[!]` at the top of both scripts.

**For CI/CD:** the pipeline needs its own way to assume `role_arn` above (`arn:aws:iam::767398044071:role/tenant-ccaiaa-dev-direct-access`) — for example, OIDC federation from the CI provider directly into that role, or an execution role already attached to the pipeline's compute. Once the pipeline has valid credentials for that role, either:
- point `AWS_PROFILE` (the constant at the top of each script) at whatever profile the pipeline sets up, or
- remove `profile_name=` from the `boto3.Session(...)` call entirely and let boto3 pick up the pipeline's ambient credentials (its default resolution chain).

No other code change is required — the role and its permissions are the same either way, only *how* you arrive at that role changes.

---

## Secrets and Config — Where Each Value Actually Comes From

`step2` and `step3` (the LiteLLM side) authenticate with OAuth2 client credentials, loaded from a `.env` file per `.env.template`. Not all six variables below are secrets — two are fixed, non-secret platform values:

| Variable | Purpose | Source |
|---|---|---|
| `CUSTOM_API_CLIENT_ID` | OAuth client ID for the Management API | **Vault** — `static-secret/genai-dev/custom-api/ccaiaa-dev`, key `client_id` |
| `CUSTOM_API_CLIENT_SECRET` | OAuth client secret | **Vault** — same path, key `client_secret` |
| `COGNITO_TOKEN_ENDPOINT` | Token endpoint to exchange the above for a bearer token | **Not a secret** — fixed platform URL: `https://cognito-auth.aiplat-dev.aws.pmicloud.biz/oauth2/token` (dev). Copy in directly, no Vault lookup. |
| `CUSTOM_API_SCOPES` | OAuth scope string | **Not a secret** — fixed platform value: `https://aiplat-dev.aws.pmicloud.biz/tenant` (dev). Copy in directly, no Vault lookup. |
| `LITELLM_TENANT_NAME` | `ccaiaa-dev` | Not a secret — the tenant name itself |
| `AWS_BEARER_TOKEN_BEDROCK` | The LiteLLM Gateway API key (only needed if you run a live verification call after attaching — not required for register/attach themselves) | **Vault** — `genai-dev/litellm/ccaiaa-dev`, key `password` |

**Only `CUSTOM_API_CLIENT_ID`, `CUSTOM_API_CLIENT_SECRET`, and `AWS_BEARER_TOKEN_BEDROCK` require a Vault lookup.** `COGNITO_TOKEN_ENDPOINT` and `CUSTOM_API_SCOPES` are fixed per-environment values published in the platform documentation — hardcoding them is intentional, not a placeholder waiting to be filled.

None of these are personal. The same values work for any developer, and the same values should be used by the CI/CD pipeline — ideally fetched directly from Vault at deploy time rather than stored as static pipeline secrets.

---

## Approval Requirements

Every tenant gets a platform-provided default guardrail automatically. Any custom guardrail that lowers a protection **below** that default's setting requires InfoSec sign-off before `--attach` is run against a shared/production key.

Currently, this tenant's guardrail lowers exactly one setting below the platform default:

| Filter | Platform default | This guardrail |
|---|---|---|
| PROMPT_ATTACK | HIGH | MEDIUM |

That change was approved for this tenant. If the policy changes again in a way that lowers any other filter below the platform default's value, re-confirm whether new approval is needed before attaching.

---

## Known Issues (carry these forward, do not silently "fix" without re-testing)

1. **INSULTS at LOW/LOW is unstable.** Repeated testing showed the identical profanity-containing prompt pass through undetected roughly 1 in 2-3 calls at LOW/LOW, while the same prompt was consistently blocked at MEDIUM/MEDIUM across every repeat test. The guardrail config in `step1_create_guardrail.py` currently reflects LOW/LOW (matching what's live in ccaiaa-dev at time of writing) — this is flagged in that script with `[!]`. If you are deploying a new tenant/environment from scratch, consider defaulting to MEDIUM/MEDIUM instead unless there's a specific reason to match ccaiaa-dev's current (known-unstable) setting.

2. **EMAIL/PHONE/ADDRESS anonymization does not work.** Confirmed via AWS Bedrock's own `outputScope=FULL` debug parameter: these three PII entity types are not evaluated at all by `apply_guardrail`, while every `BLOCK`-type PII entity (SSN, credit cards, passwords, AWS keys) works correctly. This appears to be an AWS Bedrock-level issue, not specific to this tenant's configuration. Unresolved as of time of writing — if this matters for a given use case, treat it as a gap, not a configuration bug to chase further here.

3. **Guardrails are non-deterministic at decision boundaries.** A single test run can give a different result than a second run on the exact same input, specifically for prompts that sit close to a filter's threshold. Any tuning decision should be validated with several repeated calls on the same input, not a single pass/fail observation.

---

## Environments Beyond ccaiaa-dev / dev

This guide currently only covers the `ccaiaa-dev` tenant. QA and PRD will need their own tenant name, AWS role, and Vault path — not documented here yet.
