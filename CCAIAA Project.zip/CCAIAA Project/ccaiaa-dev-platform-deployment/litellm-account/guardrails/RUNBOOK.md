# Guardrail Runbook (ccaiaa-dev)

Step-by-step reference for creating, maintaining, and registering the Bedrock
content guardrail for the **ccaiaa-dev** tenant, based on the scripts in this
folder. Keep alongside `DEPLOYMENT_GUIDE.md`.

## Key facts

| Item | Value |
|---|---|
| AWS account (tenant) | `767398044071` |
| Region | `us-east-1` |
| AWS profile | `ccaiaa-dev-direct-access` |
| Assumed role | `arn:aws:iam::767398044071:role/tenant-ccaiaa-dev-direct-access` |
| Custom guardrail name | `ccaiaa-dev-content-guardrail` |
| Custom guardrail id | `p0c2cq2nfpvd` |
| Platform default (rollback target) | `ccaiaa-dev` (`w1vr75ui9jqn`) |
| LiteLLM Mgmt API | `https://aiplat-dev.aws.pmicloud.biz/api/litellm-mgmt` |
| Vault path (LiteLLM secrets) | `static-secret/genai-dev/custom-api/ccaiaa-dev` |

> DRAFT is mutable and must never be used in production. Always deploy a
> numbered version.

---

## 0. One-time setup

### AWS profile (`~/.aws/config`, i.e. `C:\Users\<you>\.aws\config`)
Add a profile that assumes the tenant role, chaining from your own SSO profile:

```ini
[profile ccaiaa-dev-direct-access]
role_arn = arn:aws:iam::767398044071:role/tenant-ccaiaa-dev-direct-access
source_profile = pmi-dev-developer      ; <- your SSO profile
region = us-east-1
```

Log in and verify (must print account `767398044071`):

```powershell
aws sso login --profile pmi-dev-developer
aws sts get-caller-identity --profile ccaiaa-dev-direct-access
```

If SSO expired later: `aws sso login --profile pmi-dev-developer`.

### LiteLLM `.env` (only for register/attach, steps in section 4-5)
Copy `02_litellm_registration/.env.template` to `02_litellm_registration/.env`
and fill the four OAuth fields from Vault (`client_id`, `client_secret`, token
endpoint, scopes). `LITELLM_TENANT_NAME=ccaiaa-dev`. **Never commit `.env`.**

---

## 1. Find a guardrail's id / versions (read-only)

```powershell
cd litellm-account\guardrails\03_troubleshooting
python list_all_guardrails.py
```

Direct AWS CLI equivalent:

```powershell
aws bedrock list-guardrails --profile ccaiaa-dev-direct-access --region us-east-1 `
  --query "guardrails[?name=='ccaiaa-dev-content-guardrail'].{name:name,id:id,status:status}" --output table
```

---

## 2. Inspect current config (read-only)

Show the content filters for the working DRAFT:

```powershell
aws bedrock get-guardrail --guardrail-identifier p0c2cq2nfpvd --guardrail-version DRAFT `
  --profile ccaiaa-dev-direct-access --region us-east-1 `
  --query "contentPolicy.filters[*].{type:type,in:inputStrength,out:outputStrength}" --output table
```

Swap `DRAFT` for a number (e.g. `7`) to inspect a published version.
Or use the script: set `GUARDRAIL_ID` in `03_troubleshooting/fetch_guardrail_config.py`, then `python fetch_guardrail_config.py`.

---

## 3. Create a NEW guardrail (first time only)

Only if the guardrail does not already exist. `step1` refuses to run if a
guardrail with the same name exists.

```powershell
cd litellm-account\guardrails\01_bedrock_guardrail
python step1_create_guardrail.py
```

Record the printed `guardrailId` and `version`. Continue at section 4.

---

## 4. Maintain / change an EXISTING guardrail's policy

Use this to change filters (e.g. MISCONDUCT LOW -> NONE), never re-run step1.

1. Edit `01_bedrock_guardrail/maintenance_update_guardrail_config.py`:
   - `GUARDRAIL_ID = "p0c2cq2nfpvd"`
   - edit the relevant line(s) in `NEW_CONTENT_FILTERS` (keep all filters listed;
     `update_guardrail` replaces the whole content policy)
   - set a meaningful `VERSION_DESCRIPTION`
2. Run it (updates DRAFT, then cuts a new numbered version):

```powershell
cd litellm-account\guardrails\01_bedrock_guardrail
python maintenance_update_guardrail_config.py
```

3. Record the **new version number** it prints, then verify:

```powershell
aws bedrock get-guardrail --guardrail-identifier p0c2cq2nfpvd --guardrail-version <NEW_VERSION> `
  --profile ccaiaa-dev-direct-access --region us-east-1 `
  --query "contentPolicy.filters[*].{type:type,in:inputStrength,out:outputStrength}" --output table
```

> NOTE: this creates a version but does NOT change live behavior. Continue to
> sections 5 and 6.

> APPROVAL: if the change lowers any filter below the platform default, get
> InfoSec sign-off before the attach in section 6.

---

## 5. Register the version in LiteLLM (additive, not live)

Requires `02_litellm_registration/.env` populated (section 0).

1. Edit `02_litellm_registration/step2_register_guardrail_in_litellm.py`:
   - `GUARDRAIL_ID = "p0c2cq2nfpvd"`
   - `GUARDRAIL_VERSION = "<NEW_VERSION>"`
2. Run:

```powershell
cd litellm-account\guardrails\02_litellm_registration
python step2_register_guardrail_in_litellm.py
```

Record the printed **guardrail name** (e.g. `ccaiaa-dev-p0c2cq2nfpvd-8`).

---

## 6. Attach to the key -- THIS GOES LIVE

Every caller on the key is affected immediately. Get approval first (section 4).

1. Edit `02_litellm_registration/step3_manage_key_guardrail.py`:
   - `GUARDRAIL_NAME = "<name from section 5>"`
2. Check current state, then attach:

```powershell
cd litellm-account\guardrails\02_litellm_registration
python step3_manage_key_guardrail.py --check
python step3_manage_key_guardrail.py --attach     # type ATTACH to confirm
```

`--attach` saves a timestamped `key_backup_*.json` before changing anything.

---

## 7. Verify live behavior

Make a real chat-completions call through the LiteLLM gateway and inspect the
`x-litellm-applied-guardrails` response header (authoritative signal). Test a
prompt that exercises the changed filter.

---

## 8. Rollback

Reverts the key to the platform default guardrail (`ccaiaa-dev`):

```powershell
python step3_manage_key_guardrail.py --rollback   # type ROLLBACK to confirm
```

---

## Quick reference: full change flow

```
list_all_guardrails.py            -> get id / versions
(get-guardrail)                   -> confirm current filters
maintenance_update_...config.py   -> new numbered version (edit filters first)
step2_register_...litellm.py      -> register version in LiteLLM
step3_manage_key_guardrail.py --attach   -> GO LIVE (after approval)
(verify via x-litellm-applied-guardrails header)
step3 --rollback                  -> revert if needed
```

## Git

Work on a branch, commit the edited scripts (never `.env`), open a PR:

```powershell
git checkout -b guardrail/<change>
git add litellm-account/guardrails/01_bedrock_guardrail/*.py
git commit -m "<describe the guardrail change>"
git push -u origin guardrail/<change>
```
