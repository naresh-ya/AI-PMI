#!/usr/bin/env python3
"""
MAINTENANCE SCRIPT (not part of the numbered 1-2-3 setup flow)
================================================================================

WHEN TO USE THIS SCRIPT:
    Only after the guardrail already exists (step1 has run at least once).
    Use this whenever the guardrail's CONTENT POLICY needs to change later -
    for example, adjusting a filter's strength, or migrating tier. Do NOT
    use step1_create_guardrail.py for this - it will refuse to run if the
    guardrail already exists, by design.

WHAT THIS SCRIPT DOES:
    1. Fetches the guardrail's current DRAFT configuration.
    2. Overwrites ONLY contentPolicyConfig with NEW_CONTENT_FILTERS below.
       PII policy, word policy, and messaging are carried forward UNCHANGED
       from the current DRAFT (read from AWS, not hardcoded here) - this
       script will not silently drop them.
    3. Cuts a new immutable numbered version from the updated DRAFT.

IMPORTANT - update_guardrail REQUIRES THE FULL CONFIG ON EVERY CALL:
    Amazon Bedrock's update_guardrail API replaces whatever policy block you
    pass, it does not merge/patch. This script fetches the current DRAFT
    first specifically so PII/word policy survive unchanged - if you copy
    this script, keep that fetch-then-carry-forward pattern.

AFTER RUNNING THIS SCRIPT:
    The new version is NOT registered in LiteLLM and NOT attached to any
    key automatically. Re-run:
      ../02_litellm_registration/step2_register_guardrail_in_litellm.py
      (with the new version number)
      ../02_litellm_registration/step3_manage_key_guardrail.py --attach
      (to make the new version live)

AUTHENTICATION:
    Same as step1_create_guardrail.py - see the authentication note in that
    file. [!] AWS_PROFILE below is a PERSONAL profile, replace for CI/CD.

Usage:
    python maintenance_update_guardrail_config.py
"""

import boto3

# ==============================================================================
# CONFIGURATION
# ==============================================================================
AWS_PROFILE = "ccaiaa-dev-direct-access"   # [!] PERSONAL - see step1 for details
AWS_REGION = "us-east-1"
EXPECTED_ACCOUNT_ID = "767398044071"

GUARDRAIL_ID = "p0c2cq2nfpvd"  # ccaiaa-dev-content-guardrail (from list_all_guardrails.py)

# Edit these values to whatever the new policy should be, then run this script.
NEW_CONTENT_FILTERS = [
    {"type": "VIOLENCE",      "inputStrength": "LOW",    "outputStrength": "LOW"},
    {"type": "PROMPT_ATTACK", "inputStrength": "MEDIUM", "outputStrength": "NONE"},
    {"type": "MISCONDUCT",    "inputStrength": "NONE",   "outputStrength": "NONE"},
    {"type": "HATE",          "inputStrength": "LOW",    "outputStrength": "LOW"},
    {"type": "SEXUAL",        "inputStrength": "LOW",    "outputStrength": "LOW"},
    {"type": "INSULTS",       "inputStrength": "LOW",    "outputStrength": "LOW"},
]
NEW_TIER = "STANDARD"  # "STANDARD" or "CLASSIC" - STANDARD requires cross-region config below
CROSS_REGION_PROFILE_ID = "us.guardrail.v1:0"  # only used if NEW_TIER == "STANDARD"

VERSION_DESCRIPTION = "Disable MISCONDUCT filter (NONE/NONE) - unblock false-positive blockage"


def main():
    print("=" * 80)
    print("MAINTENANCE: UPDATE GUARDRAIL CONTENT POLICY")
    print("=" * 80)

    if GUARDRAIL_ID == "REPLACE_WITH_REAL_GUARDRAIL_ID":
        print("ERROR: set GUARDRAIL_ID at the top of this script before running.")
        raise SystemExit(1)

    session = boto3.Session(profile_name=AWS_PROFILE)
    sts = session.client("sts")
    identity = sts.get_caller_identity()
    print(f"AWS identity: {identity['Arn']}")
    if identity["Account"] != EXPECTED_ACCOUNT_ID:
        print(f"ERROR: wrong AWS account. Expected {EXPECTED_ACCOUNT_ID}, got {identity['Account']}.")
        raise SystemExit(1)

    bedrock = session.client("bedrock", region_name=AWS_REGION)

    print(f"\nFetching current DRAFT for {GUARDRAIL_ID}...")
    current = bedrock.get_guardrail(guardrailIdentifier=GUARDRAIL_ID, guardrailVersion="DRAFT")
    print(f"Current name: {current['name']}")
    print(f"Current tier: {current['contentPolicy'].get('tier', {}).get('tierName')}")

    # Carry forward PII policy unchanged
    pii_entities = [
        {"type": p["type"], "action": p["action"]}
        for p in current.get("sensitiveInformationPolicy", {}).get("piiEntities", [])
    ]

    # Carry forward word policy unchanged (guard against empty wordsConfig,
    # which the API rejects with a min-length validation error if present)
    word_policy_config = {}
    custom_words = current.get("wordPolicy", {}).get("words", [])
    managed_lists = current.get("wordPolicy", {}).get("managedWordLists", [])
    if custom_words:
        word_policy_config["wordsConfig"] = [{"text": w["text"]} for w in custom_words]
    if managed_lists:
        word_policy_config["managedWordListsConfig"] = [{"type": w["type"]} for w in managed_lists]

    update_kwargs = dict(
        guardrailIdentifier=GUARDRAIL_ID,
        name=current["name"],
        description=f"Updated: {VERSION_DESCRIPTION}",
        contentPolicyConfig={
            "filtersConfig": NEW_CONTENT_FILTERS,
            "tierConfig": {"tierName": NEW_TIER},
        },
        sensitiveInformationPolicyConfig={"piiEntitiesConfig": pii_entities},
        blockedInputMessaging=current["blockedInputMessaging"],
        blockedOutputsMessaging=current["blockedOutputsMessaging"],
    )
    if NEW_TIER == "STANDARD":
        update_kwargs["crossRegionConfig"] = {"guardrailProfileIdentifier": CROSS_REGION_PROFILE_ID}
    if word_policy_config:
        update_kwargs["wordPolicyConfig"] = word_policy_config

    print("\nUpdating DRAFT...")
    bedrock.update_guardrail(**update_kwargs)
    print("DRAFT updated.")

    print("\nCreating new numbered version...")
    version_response = bedrock.create_guardrail_version(
        guardrailIdentifier=GUARDRAIL_ID,
        description=VERSION_DESCRIPTION,
    )
    new_version = version_response["version"]

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)
    print(f"New version: {new_version}")
    print(f"\nThis version is NOT yet registered in LiteLLM or attached to any key.")
    print(f"Next: ../02_litellm_registration/step2_register_guardrail_in_litellm.py")
    print(f"      (set GUARDRAIL_VERSION = \"{new_version}\")")


if __name__ == "__main__":
    main()
