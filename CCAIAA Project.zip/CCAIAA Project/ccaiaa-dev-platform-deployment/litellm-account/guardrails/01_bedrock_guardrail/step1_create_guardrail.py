#!/usr/bin/env python3
"""
STEP 1 of 3 - Create the AWS Bedrock Guardrail
================================================================================

WHEN TO USE THIS SCRIPT:
    Run once to create the guardrail resource in AWS Bedrock for a tenant.
    If a guardrail with this name already exists (checked automatically
    before creating anything), the script exits without creating a
    duplicate. To change an EXISTING guardrail's policy, use
    ../01_bedrock_guardrail/maintenance_update_guardrail_config.py instead
    of re-running this script.

WHAT THIS SCRIPT DOES:
    1. Verifies the AWS identity is the expected tenant account.
    2. Checks whether a guardrail with GUARDRAIL_NAME already exists.
    3. Creates the guardrail with the content filter / PII / word policy
       configuration below, on STANDARD tier.
    4. Cuts version 1 (guardrails are created in DRAFT; DRAFT is mutable
       and must never be used in production).

NEXT STEP AFTER THIS SCRIPT:
    ../02_litellm_registration/step2_register_guardrail_in_litellm.py
    (needs the guardrailId and version printed at the end of this script)

--------------------------------------------------------------------------------
AUTHENTICATION (READ BEFORE RUNNING)
--------------------------------------------------------------------------------
This script authenticates to AWS via an AWS CLI profile that assumes the
tenant's Bedrock "Direct Access" IAM role. It does NOT use any secret from
Vault or any value in a .env file - AWS access is entirely through the
profile named in AWS_PROFILE below.

    [!] PERSONAL CONFIGURATION - DOES NOT WORK AS-IS FOR OTHER USERS OR CI/CD
    The AWS_PROFILE value below ("ccaiaa-dev-direct-access") is a LOCAL
    profile that was configured on one developer's machine as:

        [profile ccaiaa-dev-direct-access]
        role_arn = arn:aws:iam::767398044071:role/tenant-ccaiaa-dev-direct-access
        source_profile = pmi-dev-pgaur      <-- THIS IS A PERSONAL SSO PROFILE
        region = us-east-1

    "pmi-dev-pgaur" is one developer's individual AWS SSO login. It will
    NOT exist on any other machine, and it MUST NOT be used in a CI/CD
    pipeline. For CI/CD, replace this entire authentication mechanism with
    a pipeline-native way to assume role_arn above (e.g. GitHub/GitLab OIDC
    federation into that role, or an execution role already attached to
    the pipeline's runtime). See DEPLOYMENT_GUIDE.md, section
    "AWS Authentication - Local vs CI/CD" for details.

    No code change is needed here to run this in CI/CD - only the AWS_PROFILE
    constant needs to become whatever profile/role your pipeline's AWS
    credentials resolve to (or remove `profile_name=` entirely and let
    boto3 pick up the pipeline's default credentials/role).
--------------------------------------------------------------------------------

REQUIRED TAGS (DO NOT REMOVE ANY OF THE THREE):
    Bedrock's IAM policy for this role enforces these three tags as a
    condition on guardrail creation. Removing any one of them causes
    bedrock:CreateGuardrail to fail with AccessDeniedException.

Usage:
    python step1_create_guardrail.py
"""

import boto3

# ==============================================================================
# CONFIGURATION - update these when deploying to a different tenant/environment
# ==============================================================================
AWS_PROFILE = "ccaiaa-dev-direct-access"   # [!] PERSONAL - see auth note above
AWS_REGION = "us-east-1"                   # Bedrock guardrails currently require us-east-1
EXPECTED_ACCOUNT_ID = "767398044071"       # tenant's AWS account (ccaiaa-dev)

TENANT_NAME = "ccaiaa-dev"
GUARDRAIL_NAME = "ccaiaa-dev-content-guardrail"
GUARDRAIL_DESCRIPTION = "Corporate Affairs content guardrail for ccaiaa-dev"

# Cross-region inference profile required by STANDARD tier. This is the same
# profile the platform's default guardrail (per tenant) already uses.
CROSS_REGION_PROFILE_ID = "us.guardrail.v1:0"

# --- Content filters -------------------------------------------------------
# [!] KNOWN ISSUE: INSULTS at LOW/LOW has a CONFIRMED, reproduced instability
#     in production - the same profanity-containing prompt was observed to
#     pass through undetected in ~1 of every 2-3 calls (verified via repeated
#     testing, not a one-off). If you are deploying this fresh, consider
#     using MEDIUM/MEDIUM for INSULTS (and VIOLENCE/HATE/SEXUAL, which were
#     validated as stable at MEDIUM/MEDIUM) instead of the LOW/LOW values
#     below, which reflect what is CURRENTLY LIVE in ccaiaa-dev at time of
#     writing. See DEPLOYMENT_GUIDE.md, section "Known Issues" before deciding.
CONTENT_FILTERS = [
    {"type": "VIOLENCE",      "inputStrength": "LOW",    "outputStrength": "LOW"},
    {"type": "PROMPT_ATTACK", "inputStrength": "MEDIUM", "outputStrength": "NONE"},
    {"type": "MISCONDUCT",    "inputStrength": "NONE",   "outputStrength": "NONE"},
    {"type": "HATE",          "inputStrength": "LOW",    "outputStrength": "LOW"},
    {"type": "SEXUAL",        "inputStrength": "LOW",    "outputStrength": "LOW"},
    {"type": "INSULTS",       "inputStrength": "LOW",    "outputStrength": "LOW"},  # [!] see note above
]

# --- PII entities ------------------------------------------------------------
# NOTE: EMAIL/PHONE/ADDRESS are configured as ANONYMIZE, but this has a
# CONFIRMED AWS Bedrock-level bug (not specific to this guardrail or this
# tenant) where these three entity types are not being evaluated at all by
# apply_guardrail - confirmed via AWS's own outputScope=FULL debug parameter,
# which showed these three types absent even as non-detections, while every
# BLOCK-type entity below works correctly. This has not been fixed as of
# time of writing. See DEPLOYMENT_GUIDE.md, section "Known Issues".
PII_ENTITIES = [
    {"type": "EMAIL", "action": "ANONYMIZE"},
    {"type": "PHONE", "action": "ANONYMIZE"},
    {"type": "ADDRESS", "action": "ANONYMIZE"},
    {"type": "CREDIT_DEBIT_CARD_NUMBER", "action": "BLOCK"},
    {"type": "CREDIT_DEBIT_CARD_CVV", "action": "BLOCK"},
    {"type": "CREDIT_DEBIT_CARD_EXPIRY", "action": "BLOCK"},
    {"type": "US_SOCIAL_SECURITY_NUMBER", "action": "BLOCK"},
    {"type": "US_PASSPORT_NUMBER", "action": "BLOCK"},
    {"type": "DRIVER_ID", "action": "BLOCK"},
    {"type": "US_BANK_ACCOUNT_NUMBER", "action": "BLOCK"},
    {"type": "INTERNATIONAL_BANK_ACCOUNT_NUMBER", "action": "BLOCK"},
    {"type": "SWIFT_CODE", "action": "BLOCK"},
    {"type": "PASSWORD", "action": "BLOCK"},
    {"type": "AWS_ACCESS_KEY", "action": "BLOCK"},
    {"type": "AWS_SECRET_KEY", "action": "BLOCK"},
    # NAME is intentionally NOT configured - this allows the guardrail to
    # pass through references to public officials, regulators, journalists,
    # and executives by name, which Corporate Affairs documents require.
]

MANAGED_WORD_LISTS = [{"type": "PROFANITY"}]

BLOCKED_INPUT_MESSAGE = "This content is blocked by guardrail policy. Please rephrase your question or contact Corporate Affairs."
BLOCKED_OUTPUT_MESSAGE = "This response is blocked by guardrail policy. Please consult official PMI resources."

# Required tags - creation FAILS with AccessDeniedException if any is missing.
REQUIRED_TAGS = [
    {"key": "aiplat-tenant", "value": TENANT_NAME},
    {"key": "project", "value": TENANT_NAME},
    {"key": "itpf-compliant", "value": "true"},
]


def main():
    print("=" * 80)
    print("STEP 1 of 3: CREATE BEDROCK GUARDRAIL")
    print("=" * 80)

    session = boto3.Session(profile_name=AWS_PROFILE)
    sts = session.client("sts")
    identity = sts.get_caller_identity()
    print(f"AWS identity: {identity['Arn']}")

    if identity["Account"] != EXPECTED_ACCOUNT_ID:
        print(f"ERROR: wrong AWS account. Expected {EXPECTED_ACCOUNT_ID}, got {identity['Account']}.")
        print("Check the AWS_PROFILE constant and your ~/.aws/config.")
        raise SystemExit(1)
    print(f"Account confirmed: {identity['Account']}")

    bedrock = session.client("bedrock", region_name=AWS_REGION)

    print(f"\nChecking whether '{GUARDRAIL_NAME}' already exists...")
    existing = bedrock.list_guardrails(maxResults=100)
    for g in existing.get("guardrails", []):
        if g.get("name") == GUARDRAIL_NAME:
            print(f"\nA guardrail named '{GUARDRAIL_NAME}' already exists:")
            print(f"  guardrailId: {g['id']}")
            print(f"  arn: {g['arn']}")
            print("\nRefusing to create a duplicate. If you need to change its policy,")
            print("use maintenance_update_guardrail_config.py instead.")
            raise SystemExit(1)
    print("No existing guardrail with this name. Proceeding.")

    print("\nCreating guardrail...")
    response = bedrock.create_guardrail(
        name=GUARDRAIL_NAME,
        description=GUARDRAIL_DESCRIPTION,
        contentPolicyConfig={
            "filtersConfig": CONTENT_FILTERS,
            "tierConfig": {"tierName": "STANDARD"},
        },
        sensitiveInformationPolicyConfig={"piiEntitiesConfig": PII_ENTITIES},
        wordPolicyConfig={"managedWordListsConfig": MANAGED_WORD_LISTS},
        crossRegionConfig={"guardrailProfileIdentifier": CROSS_REGION_PROFILE_ID},
        blockedInputMessaging=BLOCKED_INPUT_MESSAGE,
        blockedOutputsMessaging=BLOCKED_OUTPUT_MESSAGE,
        tags=REQUIRED_TAGS,
    )
    guardrail_id = response["guardrailId"]
    guardrail_arn = response["guardrailArn"]
    print(f"Created. guardrailId={guardrail_id}")

    print("\nCreating version 1 (immutable, safe to use in production)...")
    version_response = bedrock.create_guardrail_version(
        guardrailIdentifier=guardrail_id,
        description="v1 - initial deployment",
    )
    version = version_response["version"]

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)
    print(f"guardrailId:      {guardrail_id}")
    print(f"guardrailArn:     {guardrail_arn}")
    print(f"version:          {version}")
    print(f"\nRecord these two values - step2 needs them:")
    print(f"  GUARDRAIL_ID = \"{guardrail_id}\"")
    print(f"  GUARDRAIL_VERSION = \"{version}\"")
    print("\nNext: ../02_litellm_registration/step2_register_guardrail_in_litellm.py")


if __name__ == "__main__":
    main()
