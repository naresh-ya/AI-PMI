#!/usr/bin/env python3
"""
TROUBLESHOOTING - List Guardrails in the AWS Account
================================================================================

WHEN TO USE THIS SCRIPT:
    - To find a guardrail's ID when you only know its name.
    - To see every version that exists for a given guardrail.
    - To confirm a guardrail was actually created/deleted.

    This is READ-ONLY.

[!] IMPORTANT - THIS AWS ACCOUNT IS SHARED ACROSS MANY TENANTS:
    list_guardrails returns EVERY guardrail in the account, not just this
    tenant's. This account has been observed to contain guardrails for
    dozens of unrelated tenants. By default this script filters the
    results to names starting with NAME_FILTER_PREFIX (fast, no extra API
    calls) so you only see this tenant's guardrails. Set NAME_FILTER_PREFIX
    to an empty string to see everything in the account - be prepared for
    a long list, and be careful not to act on (rename/update/delete) a
    guardrail that doesn't belong to this tenant.

WHAT THIS SCRIPT DOES:
    1. Lists all guardrails in the account (paginated automatically).
    2. Filters to names starting with NAME_FILTER_PREFIX.
    3. For each match, also lists every version that exists for it.

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Same AWS profile pattern as ../01_bedrock_guardrail/step1_create_guardrail.py.
[!] AWS_PROFILE below is a PERSONAL profile - see that script's docstring.
--------------------------------------------------------------------------------

Usage:
    python list_all_guardrails.py
"""

import boto3

# ==============================================================================
# CONFIGURATION - edit before running
# ==============================================================================
AWS_PROFILE = "ccaiaa-dev-direct-access"   # [!] PERSONAL - see step1_create_guardrail.py
AWS_REGION = "us-east-1"
EXPECTED_ACCOUNT_ID = "767398044071"

# Only guardrails whose name starts with this are shown. Set to "" to see
# every guardrail in the account (see the [!] warning above before doing that).
NAME_FILTER_PREFIX = "ccaiaa-dev"


def main():
    print("=" * 80)
    print("LIST GUARDRAILS (read-only)")
    print("=" * 80)

    session = boto3.Session(profile_name=AWS_PROFILE)
    sts = session.client("sts")
    identity = sts.get_caller_identity()
    print(f"AWS identity: {identity['Arn']}")
    if identity["Account"] != EXPECTED_ACCOUNT_ID:
        print(f"ERROR: wrong AWS account. Expected {EXPECTED_ACCOUNT_ID}, got {identity['Account']}.")
        raise SystemExit(1)

    bedrock = session.client("bedrock", region_name=AWS_REGION)

    print(f"\nFilter: name starts with '{NAME_FILTER_PREFIX}' "
          f"{'(showing ALL guardrails in the account)' if NAME_FILTER_PREFIX == '' else ''}\n")

    # list_guardrails without a guardrailIdentifier returns the latest version
    # of every distinct guardrail (paginated) - collect all pages first.
    all_guardrails = []
    next_token = None
    while True:
        kwargs = {"maxResults": 100}
        if next_token:
            kwargs["nextToken"] = next_token
        resp = bedrock.list_guardrails(**kwargs)
        all_guardrails.extend(resp.get("guardrails", []))
        next_token = resp.get("nextToken")
        if not next_token:
            break

    matches = [g for g in all_guardrails if g.get("name", "").startswith(NAME_FILTER_PREFIX)]

    print(f"Total guardrails in account: {len(all_guardrails)}")
    print(f"Matching '{NAME_FILTER_PREFIX}': {len(matches)}\n")

    for g in matches:
        print(f"- name: {g['name']}")
        print(f"  id:     {g['id']}")
        print(f"  status: {g.get('status')}")
        print(f"  arn:    {g['arn']}")

        # Show every version of this specific guardrail
        versions_resp = bedrock.list_guardrails(guardrailIdentifier=g["id"], maxResults=100)
        versions = sorted(
            versions_resp.get("guardrails", []),
            key=lambda v: (v["version"] != "DRAFT", v["version"]),
        )
        print(f"  versions: {[v['version'] for v in versions]}")
        print()

    if not matches:
        print("No matches. If you expected results, check NAME_FILTER_PREFIX,")
        print("or set it to \"\" to see every guardrail in the account.")


if __name__ == "__main__":
    main()
