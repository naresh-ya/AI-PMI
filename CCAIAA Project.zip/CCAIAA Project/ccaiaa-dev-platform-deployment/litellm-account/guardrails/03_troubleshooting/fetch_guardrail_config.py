#!/usr/bin/env python3
"""
TROUBLESHOOTING - Fetch and Display a Guardrail's Full Configuration
================================================================================

WHEN TO USE THIS SCRIPT:
    Whenever you need to see EXACTLY what a guardrail is currently
    configured to do - content filters and their strengths, PII rules, word
    policy, tier, tags, messaging - without going through the AWS Console.
    Useful for confirming "what is actually live right now" before making a
    change, or for comparing two versions of the same guardrail.

    This is READ-ONLY. It cannot break anything.

WHAT THIS SCRIPT DOES:
    1. Fetches the guardrail's configuration for the version you specify
       (a number, or "DRAFT" for the mutable working copy).
    2. Fetches its tags in a separate call (tags are not included in
       get_guardrail's response).
    3. Prints everything in a readable format.

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Same AWS profile pattern as ../01_bedrock_guardrail/step1_create_guardrail.py.
[!] AWS_PROFILE below is a PERSONAL profile - see that script's docstring
for the full explanation and what to change for CI/CD.
--------------------------------------------------------------------------------

Usage:
    python fetch_guardrail_config.py
"""

import json

import boto3

# ==============================================================================
# CONFIGURATION - edit before running
# ==============================================================================
AWS_PROFILE = "ccaiaa-dev-direct-access"   # [!] PERSONAL - see step1_create_guardrail.py
AWS_REGION = "us-east-1"
EXPECTED_ACCOUNT_ID = "767398044071"

GUARDRAIL_ID = "REPLACE_WITH_REAL_GUARDRAIL_ID"
GUARDRAIL_VERSION = "DRAFT"   # a number like "1", or "DRAFT" for the mutable working copy


def main():
    print("=" * 80)
    print("FETCH GUARDRAIL CONFIGURATION (read-only)")
    print("=" * 80)

    if GUARDRAIL_ID == "REPLACE_WITH_REAL_GUARDRAIL_ID":
        print("ERROR: set GUARDRAIL_ID at the top of this script before running.")
        raise SystemExit(1)

    session = boto3.Session(profile_name=AWS_PROFILE)
    sts = session.client("sts")
    identity = sts.get_caller_identity()
    print(f"AWS identity: {identity['Arn']}")
    if identity["Account"] != EXPECTED_ACCOUNT_ID:
        print(f"ERROR: wrong AWS account. Expected {EXPECTED_ACCOUNT_ID}, got {identity['Account']}.")
        raise SystemExit(1)

    bedrock = session.client("bedrock", region_name=AWS_REGION)

    print(f"\nFetching guardrail {GUARDRAIL_ID}, version {GUARDRAIL_VERSION}...\n")
    details = bedrock.get_guardrail(guardrailIdentifier=GUARDRAIL_ID, guardrailVersion=GUARDRAIL_VERSION)
    details.pop("ResponseMetadata", None)

    print("=" * 80)
    print("FULL CONFIGURATION (raw)")
    print("=" * 80)
    print(json.dumps(details, indent=2, default=str))

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"Name:    {details.get('name')}")
    print(f"Version: {details.get('version')}")
    print(f"Status:  {details.get('status')}")
    print(f"Tier:    {details.get('contentPolicy', {}).get('tier', {}).get('tierName')}")

    filters = details.get("contentPolicy", {}).get("filters", [])
    if filters:
        print("\nContent filters:")
        for f in filters:
            print(f"  - {f['type']}: input={f['inputStrength']}, output={f['outputStrength']}")
    else:
        print("\nContent filters: none configured")

    topics = details.get("topicPolicy", {}).get("topics", [])
    print(f"\nDenied topics: {len(topics)} configured")
    for t in topics:
        print(f"  - {t['name']}")

    pii = details.get("sensitiveInformationPolicy", {}).get("piiEntities", [])
    print(f"\nPII entities: {len(pii)} configured")
    for p in pii:
        print(f"  - {p['type']}: {p['action']}")

    managed_words = details.get("wordPolicy", {}).get("managedWordLists", [])
    custom_words = details.get("wordPolicy", {}).get("words", [])
    print(f"\nManaged word lists: {[w['type'] for w in managed_words]}")
    print(f"Custom blocked words: {[w['text'] for w in custom_words]}")

    print("\n" + "=" * 80)
    print("TAGS")
    print("=" * 80)
    tags_resp = bedrock.list_tags_for_resource(resourceARN=details["guardrailArn"])
    for t in tags_resp.get("tags", []):
        print(f"  {t['key']} = {t['value']}")


if __name__ == "__main__":
    main()
