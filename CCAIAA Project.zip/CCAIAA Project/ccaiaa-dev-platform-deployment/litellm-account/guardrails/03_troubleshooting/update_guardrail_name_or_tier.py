#!/usr/bin/env python3
"""
TROUBLESHOOTING - Rename a Guardrail and/or Change its Tier (CLASSIC/STANDARD)
================================================================================

WHEN TO USE THIS SCRIPT:
    For administrative changes only - renaming the guardrail's display name,
    or migrating between CLASSIC and STANDARD tier - WITHOUT touching what
    the guardrail actually blocks (content filters, PII rules, word policy
    are all read from AWS and carried forward completely unchanged).

    This is DIFFERENT from
    ../01_bedrock_guardrail/maintenance_update_guardrail_config.py, which is
    for changing WHAT gets blocked (filter strengths). Use that script
    instead if you need to change actual policy behavior. Use THIS script
    if you only need to rename it or flip its tier.

    Note: tier affects content filters and denied topics specifically (per
    AWS's own guardrail tier documentation) - switching tier can change
    real-world blocking behavior even though no filter *value* changes here.
    Re-test after switching tier, don't assume it's purely cosmetic.

WHAT THIS SCRIPT DOES:
    1. Fetches the current DRAFT configuration.
    2. Applies NEW_NAME and/or NEW_TIER (leave either as None to keep the
       current value unchanged).
    3. Carries forward content filters, PII policy, and word policy exactly
       as they currently are - nothing else changes.
    4. Cuts a new immutable numbered version.

AFTER RUNNING THIS SCRIPT:
    The new version is NOT registered in LiteLLM and NOT attached to any
    key. If this guardrail is currently live (attached to a key), you need
    to register + attach the new version for the rename/tier change to take
    effect for real traffic - see ../02_litellm_registration/.

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Same AWS profile pattern as ../01_bedrock_guardrail/step1_create_guardrail.py.
[!] AWS_PROFILE below is a PERSONAL profile - see that script's docstring.
--------------------------------------------------------------------------------

Usage:
    python update_guardrail_name_or_tier.py
"""

import boto3

# ==============================================================================
# CONFIGURATION - edit before running
# ==============================================================================
AWS_PROFILE = "ccaiaa-dev-direct-access"   # [!] PERSONAL - see step1_create_guardrail.py
AWS_REGION = "us-east-1"
EXPECTED_ACCOUNT_ID = "767398044071"

GUARDRAIL_ID = "REPLACE_WITH_REAL_GUARDRAIL_ID"

NEW_NAME = None      # e.g. "ccaiaa-dev-content-guardrail-v2", or None to leave unchanged
NEW_TIER = None      # "STANDARD", "CLASSIC", or None to leave unchanged

# Only used if NEW_TIER == "STANDARD" (STANDARD tier requires cross-region config)
CROSS_REGION_PROFILE_ID = "us.guardrail.v1:0"

VERSION_DESCRIPTION = "Renamed / tier change (see NEW_NAME / NEW_TIER at top of script)"


def main():
    print("=" * 80)
    print("UPDATE GUARDRAIL NAME / TIER (content policy untouched)")
    print("=" * 80)

    if GUARDRAIL_ID == "REPLACE_WITH_REAL_GUARDRAIL_ID":
        print("ERROR: set GUARDRAIL_ID at the top of this script before running.")
        raise SystemExit(1)
    if NEW_NAME is None and NEW_TIER is None:
        print("ERROR: set NEW_NAME and/or NEW_TIER - both are currently None, nothing to do.")
        raise SystemExit(1)

    session = boto3.Session(profile_name=AWS_PROFILE)
    sts = session.client("sts")
    identity = sts.get_caller_identity()
    print(f"AWS identity: {identity['Arn']}")
    if identity["Account"] != EXPECTED_ACCOUNT_ID:
        print(f"ERROR: wrong AWS account. Expected {EXPECTED_ACCOUNT_ID}, got {identity['Account']}.")
        raise SystemExit(1)

    bedrock = session.client("bedrock", region_name=AWS_REGION)

    print(f"\nFetching current DRAFT for {GUARDRAIL_ID}...")
    current = bedrock.get_guardrail(guardrailIdentifier=GUARDRAIL_ID, guardrailVersion="DRAFT")

    current_name = current["name"]
    current_tier = current.get("contentPolicy", {}).get("tier", {}).get("tierName", "CLASSIC")
    final_name = NEW_NAME if NEW_NAME is not None else current_name
    final_tier = NEW_TIER if NEW_TIER is not None else current_tier

    print(f"Name: {current_name!r} -> {final_name!r}")
    print(f"Tier: {current_tier!r} -> {final_tier!r}")

    # Carry forward content filters, PII policy, word policy UNCHANGED
    content_filters = [
        {"type": f["type"], "inputStrength": f["inputStrength"], "outputStrength": f["outputStrength"]}
        for f in current["contentPolicy"]["filters"]
    ]
    pii_entities = [
        {"type": p["type"], "action": p["action"]}
        for p in current.get("sensitiveInformationPolicy", {}).get("piiEntities", [])
    ]
    word_policy_config = {}
    custom_words = current.get("wordPolicy", {}).get("words", [])
    managed_lists = current.get("wordPolicy", {}).get("managedWordLists", [])
    if custom_words:
        word_policy_config["wordsConfig"] = [{"text": w["text"]} for w in custom_words]
    if managed_lists:
        word_policy_config["managedWordListsConfig"] = [{"type": w["type"]} for w in managed_lists]

    update_kwargs = dict(
        guardrailIdentifier=GUARDRAIL_ID,
        name=final_name,
        description=f"{current.get('description', '')} - {VERSION_DESCRIPTION}",
        contentPolicyConfig={
            "filtersConfig": content_filters,
            "tierConfig": {"tierName": final_tier},
        },
        sensitiveInformationPolicyConfig={"piiEntitiesConfig": pii_entities},
        blockedInputMessaging=current["blockedInputMessaging"],
        blockedOutputsMessaging=current["blockedOutputsMessaging"],
    )
    if final_tier == "STANDARD":
        update_kwargs["crossRegionConfig"] = {"guardrailProfileIdentifier": CROSS_REGION_PROFILE_ID}
    if word_policy_config:
        update_kwargs["wordPolicyConfig"] = word_policy_config

    print("\nUpdating DRAFT...")
    bedrock.update_guardrail(**update_kwargs)
    print("DRAFT updated.")

    print("\nCreating new numbered version...")
    version_response = bedrock.create_guardrail_version(
        guardrailIdentifier=GUARDRAIL_ID,
        description=VERSION_DESCRIPTION,
    )
    new_version = version_response["version"]

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)
    print(f"New version: {new_version}")
    print(f"Name: {final_name}")
    print(f"Tier: {final_tier}")
    print(f"\nNot yet live anywhere. To make it live:")
    print(f"  ../02_litellm_registration/step2_register_guardrail_in_litellm.py "
          f"(GUARDRAIL_VERSION = \"{new_version}\")")
    print(f"  ../02_litellm_registration/step3_manage_key_guardrail.py --attach")


if __name__ == "__main__":
    main()
