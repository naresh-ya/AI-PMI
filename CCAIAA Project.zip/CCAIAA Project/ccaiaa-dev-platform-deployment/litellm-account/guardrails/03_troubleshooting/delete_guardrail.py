#!/usr/bin/env python3
"""
TROUBLESHOOTING - Delete a Tenant-Managed Guardrail
================================================================================
[!] DESTRUCTIVE AND IRREVERSIBLE. Deletion removes ALL versions of the
    guardrail permanently. There is no undo. Read this entire docstring
    before running.

WHEN TO USE THIS SCRIPT:
    Only to permanently remove a custom guardrail that is no longer needed
    (e.g. an old experimental version). This is NOT part of the normal
    deployment flow - most cleanup should just involve leaving old numbered
    versions alone (they're immutable and cost nothing extra) rather than
    deleting the whole guardrail resource.

SAFETY CHECKS THIS SCRIPT PERFORMS BEFORE DELETING:
    1. Confirms the guardrail is NOT platform-defined. Platform-defined
       guardrails (tag platform-defined=true) cannot be deleted by tenants
       at all - AWS's IAM policy enforces this independently, but this
       script checks first so you get a clear message instead of a raw
       AccessDeniedException.
    2. Confirms the guardrail's aiplat-tenant tag matches EXPECTED_TENANT_TAG.
       [!] This AWS account contains guardrails belonging to many other
       tenants (confirmed via list_all_guardrails.py) - this check exists
       specifically to stop you from deleting a guardrail that isn't this
       tenant's, by mistake.
    3. Requires typing the guardrail's exact name to confirm (not just
       "yes" - this is deliberately more friction than the attach/rollback
       confirmations elsewhere in this project, because deletion cannot be
       undone).

[!] WHAT THIS SCRIPT DOES NOT CHECK (verify manually first):
    Whether this guardrail is currently registered in LiteLLM or attached
    to a live API key. AWS's delete_guardrail API has NOT been confirmed
    (in this project) to block deletion of a guardrail that LiteLLM still
    references - if it doesn't block it, deleting an in-use guardrail will
    break every LLM call using that key. Before running this script:
      1. Check ../02_litellm_registration/step3_manage_key_guardrail.py --check
         to see what the key currently uses.
      2. If this guardrail is attached, roll back to the default guardrail
         first (--rollback), and consider de-registering it from LiteLLM
         (DELETE /v2/litellm/{tenant}/guardrails/{name} via the Management
         API - not implemented as a script here) before deleting the
         underlying AWS resource.

Usage:
    python delete_guardrail.py
"""

import boto3

# ==============================================================================
# CONFIGURATION - edit before running
# ==============================================================================
AWS_PROFILE = "ccaiaa-dev-direct-access"   # [!] PERSONAL - see step1_create_guardrail.py
AWS_REGION = "us-east-1"
EXPECTED_ACCOUNT_ID = "767398044071"
EXPECTED_TENANT_TAG = "ccaiaa-dev"

GUARDRAIL_ID = "REPLACE_WITH_REAL_GUARDRAIL_ID"


def main():
    print("=" * 80)
    print("DELETE GUARDRAIL - DESTRUCTIVE, IRREVERSIBLE")
    print("=" * 80)

    if GUARDRAIL_ID == "REPLACE_WITH_REAL_GUARDRAIL_ID":
        print("ERROR: set GUARDRAIL_ID at the top of this script before running.")
        raise SystemExit(1)

    session = boto3.Session(profile_name=AWS_PROFILE)
    sts = session.client("sts")
    identity = sts.get_caller_identity()
    print(f"AWS identity: {identity['Arn']}")
    if identity["Account"] != EXPECTED_ACCOUNT_ID:
        print(f"ERROR: wrong AWS account. Expected {EXPECTED_ACCOUNT_ID}, got {identity['Account']}.")
        raise SystemExit(1)

    bedrock = session.client("bedrock", region_name=AWS_REGION)

    print(f"\nFetching guardrail {GUARDRAIL_ID}...")
    details = bedrock.get_guardrail(guardrailIdentifier=GUARDRAIL_ID, guardrailVersion="DRAFT")
    guardrail_name = details["name"]
    guardrail_arn = details["guardrailArn"]
    print(f"Name: {guardrail_name}")
    print(f"ARN: {guardrail_arn}")

    tags_resp = bedrock.list_tags_for_resource(resourceARN=guardrail_arn)
    tags = {t["key"]: t["value"] for t in tags_resp.get("tags", [])}
    print(f"Tags: {tags}")

    print("\nSafety checks:")
    if tags.get("platform-defined") == "true":
        print("  FAILED: this guardrail is platform-defined and cannot be deleted.")
        raise SystemExit(1)
    print("  OK: not platform-defined.")

    if tags.get("aiplat-tenant") != EXPECTED_TENANT_TAG:
        print(f"  FAILED: aiplat-tenant tag is {tags.get('aiplat-tenant')!r}, "
              f"expected {EXPECTED_TENANT_TAG!r}. Refusing to delete a guardrail "
              f"that does not belong to this tenant.")
        raise SystemExit(1)
    print(f"  OK: belongs to tenant '{EXPECTED_TENANT_TAG}'.")

    versions_resp = bedrock.list_guardrails(guardrailIdentifier=GUARDRAIL_ID, maxResults=100)
    versions = [v["version"] for v in versions_resp.get("guardrails", [])]
    print(f"\nThis will permanently delete ALL {len(versions)} version(s): {versions}")
    print("\n[!] Have you confirmed this guardrail is NOT currently registered in")
    print("    LiteLLM or attached to any API key? See the docstring at the top")
    print("    of this file for how to check. This script does not check for you.")

    print(f"\nTo confirm deletion, type the guardrail's exact name ({guardrail_name!r}):")
    confirmation = input("  > ").strip()
    if confirmation != guardrail_name:
        print("\nCancelled - name did not match. No changes made.")
        return

    bedrock.delete_guardrail(guardrailIdentifier=GUARDRAIL_ID)

    print("\n" + "=" * 80)
    print("DELETED")
    print("=" * 80)
    print(f"Guardrail {GUARDRAIL_ID} ({guardrail_name}) has been permanently deleted.")


if __name__ == "__main__":
    main()
