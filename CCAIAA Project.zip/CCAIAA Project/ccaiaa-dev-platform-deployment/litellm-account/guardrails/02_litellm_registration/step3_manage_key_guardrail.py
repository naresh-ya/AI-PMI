#!/usr/bin/env python3
"""
STEP 3 of 3 - Attach / Check / Rollback the Guardrail on the LiteLLM API Key
================================================================================

WHEN TO USE THIS SCRIPT:
    Run after step2_register_guardrail_in_litellm.py. This is the step that
    ACTUALLY CHANGES LIVE BEHAVIOR - every application call using this key
    starts using whatever guardrail this script attaches, immediately and
    for every caller sharing the key, with no gradual rollout.

[!] BEFORE RUNNING --attach IN A SHARED/PRODUCTION TENANT:
    Confirm required sign-off has been obtained if the new guardrail lowers
    protection below the platform default in any category (e.g. this
    tenant's guardrail intentionally runs PROMPT_ATTACK at MEDIUM instead of
    the platform default's HIGH - that reduction required InfoSec approval
    before it was attached). See DEPLOYMENT_GUIDE.md, section "Approval
    Requirements".

MODES:
    --check      Read-only. Shows the key's current guardrail assignment.
                 Makes no changes. Safe to run anytime.
    --attach     REPLACES the key's guardrail list with GUARDRAIL_NAME below.
                 Requires typing ATTACH to confirm. Saves a backup of the
                 prior state to a timestamped JSON file before changing
                 anything.
    --rollback   Reverts the key to DEFAULT_GUARDRAIL_NAME below (the
                 platform-provided baseline guardrail). Requires typing
                 ROLLBACK to confirm. Use this immediately if something goes
                 wrong after --attach.

IMPORTANT - ATTACH REPLACES, IT DOES NOT ADD:
    PUT-ing a guardrail list here replaces the key's guardrails entirely.
    If you need to run two guardrails on the same key deliberately, list
    both names in the payload - see the platform's "Register Guardrail"
    documentation for multi-guardrail keys. This script attaches exactly
    one guardrail at a time by design (kept simple deliberately).

AFTER RUNNING --attach:
    Verify with a real call through the actual LiteLLM chat completions
    endpoint (not just --check) - the response header
    "x-litellm-applied-guardrails" is the authoritative signal of what is
    actually running, not the Management API's stored config alone.

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
Same OAuth2 client credentials as step2, from Vault. See .env.template in
this folder. Not personal to any developer - safe for CI/CD as-is once the
.env values are populated from Vault at deploy time.
--------------------------------------------------------------------------------

Usage:
    python step3_manage_key_guardrail.py --check
    python step3_manage_key_guardrail.py --attach
    python step3_manage_key_guardrail.py --rollback
"""

import base64
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import requests
import urllib3
from dotenv import load_dotenv

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================================================================
# CONFIGURATION
# ==============================================================================
# The exact LiteLLM guardrail name printed by step2 (e.g. "ccaiaa-dev-abc123-1")
GUARDRAIL_NAME = "REPLACE_WITH_REAL_GUARDRAIL_NAME"

# The platform-provided baseline guardrail for this tenant. Used by --rollback.
# Naming convention: exactly the tenant name.
DEFAULT_GUARDRAIL_NAME = "ccaiaa-dev"

MGMT_API_BASE_URL = "https://aiplat-dev.aws.pmicloud.biz/api/litellm-mgmt"

load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT_NAME = os.environ["LITELLM_TENANT_NAME"]
KEY_ALIAS = TENANT_NAME  # the tenant's default key alias equals the tenant name
CLIENT_ID = os.environ["CUSTOM_API_CLIENT_ID"]
CLIENT_SECRET = os.environ["CUSTOM_API_CLIENT_SECRET"]
TOKEN_ENDPOINT = os.environ["COGNITO_TOKEN_ENDPOINT"]
SCOPES = os.environ["CUSTOM_API_SCOPES"]


def get_access_token() -> str:
    creds = base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode()
    resp = requests.post(
        TOKEN_ENDPOINT,
        headers={"Authorization": f"Basic {creds}", "Content-Type": "application/x-www-form-urlencoded"},
        data={"grant_type": "client_credentials", "scope": SCOPES},
        verify=False,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_key_info(headers) -> dict:
    resp = requests.get(
        f"{MGMT_API_BASE_URL}/v4/litellm/{TENANT_NAME}/keys/{KEY_ALIAS}",
        headers=headers, verify=False, timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def set_key_guardrails(headers, guardrail_names: list) -> requests.Response:
    return requests.put(
        f"{MGMT_API_BASE_URL}/v3/litellm/{TENANT_NAME}/keys/{KEY_ALIAS}",
        headers=headers, json={"guardrails": guardrail_names}, verify=False, timeout=30,
    )


def save_backup(key_info: dict, label: str) -> str:
    filename = f"key_backup_{label}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(filename, "w") as f:
        json.dump(key_info, f, indent=2)
    return filename


def do_check(headers):
    print("Mode: --check (read-only)\n")
    info = get_key_info(headers)
    print(json.dumps(info, indent=2))


def do_attach(headers):
    if "REPLACE_WITH_REAL" in GUARDRAIL_NAME:
        print("ERROR: set GUARDRAIL_NAME at the top of this script before running --attach.")
        raise SystemExit(1)

    print("Mode: --attach\n")
    before = get_key_info(headers)
    print(f"Current guardrails on key '{KEY_ALIAS}': {before.get('guardrails')}")
    backup_file = save_backup(before, "before_attach")
    print(f"Backup saved: {backup_file}")

    print(f"\nThis will REPLACE the key's guardrails with: ['{GUARDRAIL_NAME}']")
    print("This affects every caller using this key, immediately.")
    if input("Type ATTACH to confirm: ").strip() != "ATTACH":
        print("Cancelled - no changes made.")
        return

    resp = set_key_guardrails(headers, [GUARDRAIL_NAME])
    if resp.status_code != 200:
        print(f"\nERROR: attach failed with status {resp.status_code}")
        print(resp.text)
        raise SystemExit(1)

    after = get_key_info(headers)
    print("\nAttach succeeded. New key state:")
    print(json.dumps(after, indent=2))
    print(f"\nRollback if needed: python {Path(__file__).name} --rollback")


def do_rollback(headers):
    print("Mode: --rollback\n")
    before = get_key_info(headers)
    print(f"Current guardrails on key '{KEY_ALIAS}': {before.get('guardrails')}")
    backup_file = save_backup(before, "before_rollback")
    print(f"Backup saved: {backup_file}")

    print(f"\nThis will revert the key's guardrails to: ['{DEFAULT_GUARDRAIL_NAME}']")
    if input("Type ROLLBACK to confirm: ").strip() != "ROLLBACK":
        print("Cancelled - no changes made.")
        return

    resp = set_key_guardrails(headers, [DEFAULT_GUARDRAIL_NAME])
    if resp.status_code != 200:
        print(f"\nERROR: rollback failed with status {resp.status_code}")
        print(resp.text)
        raise SystemExit(1)

    after = get_key_info(headers)
    print("\nRollback succeeded. New key state:")
    print(json.dumps(after, indent=2))


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else None
    if mode not in ("--check", "--attach", "--rollback"):
        print(__doc__)
        raise SystemExit(1)

    print("=" * 80)
    print("STEP 3 of 3: MANAGE KEY GUARDRAIL ATTACHMENT")
    print("=" * 80)
    print(f"Tenant: {TENANT_NAME} | Key alias: {KEY_ALIAS}\n")

    token = get_access_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    {"--check": do_check, "--attach": do_attach, "--rollback": do_rollback}[mode](headers)


if __name__ == "__main__":
    main()
