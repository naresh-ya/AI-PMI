#!/usr/bin/env python3
"""
STEP 2 of 3 - Register the Bedrock Guardrail in LiteLLM
================================================================================

WHEN TO USE THIS SCRIPT:
    Run after step1_create_guardrail.py (or after
    ../01_bedrock_guardrail/maintenance_update_guardrail_config.py has
    produced a new version). Registration is purely additive - it creates a
    named reference inside LiteLLM pointing at a specific Bedrock guardrail
    ID + version. It does NOT change what any API key actually uses; that
    only happens in step3.

WHAT THIS SCRIPT DOES:
    1. Obtains an OAuth2 access token (client credentials grant) for the
       LiteLLM Management API.
    2. Registers GUARDRAIL_ID + GUARDRAIL_VERSION under a new name following
       the platform's required convention: {tenant}-{guardrail_id}-{version}
    3. Prints the resulting LiteLLM guardrail name - you need this exact
       string for step3.

MODE:
    Registered in "pre_call" mode, meaning the guardrail evaluates the
    INPUT prompt before it reaches the model. It does not evaluate model
    OUTPUT. This is the platform's recommended default (cheaper, faster -
    blocked content never reaches the model).

NEXT STEP AFTER THIS SCRIPT:
    step3_manage_key_guardrail.py --attach

--------------------------------------------------------------------------------
AUTHENTICATION
--------------------------------------------------------------------------------
This script authenticates via OAuth2 client credentials, using secrets from
Vault (see .env.template in this folder). These are TENANT-SCOPED credentials,
not personal to any one developer - the same .env values work in CI/CD as on
a developer's machine. Nothing in this script needs to change for CI/CD
except how the .env values are populated (Vault fetch at deploy time
instead of a local .env file).
--------------------------------------------------------------------------------

Usage:
    python step2_register_guardrail_in_litellm.py
"""

import base64
import os
from pathlib import Path

import requests
import urllib3
from dotenv import load_dotenv

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================================================================
# CONFIGURATION - set these to the guardrail you want to register
# ==============================================================================
GUARDRAIL_ID = "REPLACE_WITH_REAL_GUARDRAIL_ID"     # from step1's output
GUARDRAIL_VERSION = "REPLACE_WITH_REAL_VERSION"     # e.g. "1"
GUARDRAIL_MODE = "pre_call"                          # pre_call | during_call | post_call

MGMT_API_BASE_URL = "https://aiplat-dev.aws.pmicloud.biz/api/litellm-mgmt"

# Load .env from this same folder
load_dotenv(dotenv_path=Path(__file__).parent / ".env", override=True)

TENANT_NAME = os.environ["LITELLM_TENANT_NAME"]
CLIENT_ID = os.environ["CUSTOM_API_CLIENT_ID"]
CLIENT_SECRET = os.environ["CUSTOM_API_CLIENT_SECRET"]
TOKEN_ENDPOINT = os.environ["COGNITO_TOKEN_ENDPOINT"]
SCOPES = os.environ["CUSTOM_API_SCOPES"]


def get_access_token() -> str:
    creds = base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode()
    resp = requests.post(
        TOKEN_ENDPOINT,
        headers={"Authorization": f"Basic {creds}", "Content-Type": "application/x-www-form-urlencoded"},
        data={"grant_type": "client_credentials", "scope": SCOPES},
        verify=False,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def main():
    print("=" * 80)
    print("STEP 2 of 3: REGISTER GUARDRAIL IN LITELLM")
    print("=" * 80)

    if "REPLACE_WITH_REAL" in GUARDRAIL_ID or "REPLACE_WITH_REAL" in GUARDRAIL_VERSION:
        print("ERROR: set GUARDRAIL_ID and GUARDRAIL_VERSION at the top of this script.")
        raise SystemExit(1)

    print(f"Tenant: {TENANT_NAME}")
    print(f"Guardrail ID: {GUARDRAIL_ID}")
    print(f"Version: {GUARDRAIL_VERSION}")
    print(f"Mode: {GUARDRAIL_MODE}")

    token = get_access_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    body = {
        "guardrail_id": GUARDRAIL_ID,
        "guardrail_version": GUARDRAIL_VERSION,
        "guardrail_mode": GUARDRAIL_MODE,
    }
    resp = requests.post(
        f"{MGMT_API_BASE_URL}/v2/litellm/{TENANT_NAME}/guardrails",
        headers=headers,
        json=body,
        verify=False,
        timeout=30,
    )

    if resp.status_code != 200:
        print(f"\nERROR: registration failed with status {resp.status_code}")
        print(resp.text)
        raise SystemExit(1)

    result = resp.json()
    litellm_name = result["guardrail_name"]

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)
    print(f"Registered as: {litellm_name}")
    print(f"\nThis is NOT yet attached to any key. Record this name - step3 needs it:")
    print(f"  GUARDRAIL_NAME = \"{litellm_name}\"")
    print("\nNext: step3_manage_key_guardrail.py --attach")


if __name__ == "__main__":
    main()
