# LiteLLM Account

Deployment reference for everything LLM-related on the tenant's **LiteLLM** side — the LLM Gateway configuration, content guardrails, and knowledge bases.

---

## Scope

| Folder | Purpose |
|---|---|
| `guardrails/` | Creating, configuring, and attaching AWS Bedrock content guardrails to the tenant's LiteLLM API key |
| `knowledge-base/` | Creating and syncing AWS Bedrock Knowledge Bases (English/Titan and multilingual/Cohere) and querying them through the LiteLLM Gateway for RAG |
| `litellm_cost/` | Cost tracking and reporting for LiteLLM usage via the Platform Cost API |

These are two independent services — separate scripts, separate `.env` files, no shared code between them.

---

## Access

Multiple identities are involved here, not one:

| System | Auth mechanism |
|---|---|
| AWS Bedrock (guardrail resource, KB's OpenSearch collection) | AWS IAM role assumption (Direct Access role) |
| LiteLLM / KB Management API (register/attach guardrails, create/sync KBs) | OAuth2 client credentials, sourced from Vault |
| S3 document upload (knowledge-base only) | AWS IAM role assumption (Direct Access role) — same family of profile as above, but a distinct step from the Management API calls |

See `guardrails/DEPLOYMENT_GUIDE.md` and `knowledge-base/DEPLOYMENT_GUIDE.md` for the full breakdown of each, including what's personal-machine-specific vs. safe to run in CI/CD.

---

## Status

`guardrails/` and `knowledge-base/` content added.
