"""
CCAIAA Dev Account (603433800649) - Security & Performance Audit Workbook
Generates a multi-sheet Excel report.
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

OUT = r"c:\code\CCAIAA Project\CCAIAA_Dev_Security_Audit_603433800649.xlsx"

# ---- Styles ----
HEADER_FILL = PatternFill("solid", fgColor="1B2A4A")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11, name="Calibri")
TITLE_FONT = Font(color="1B2A4A", bold=True, size=16, name="Calibri")
SUB_FONT = Font(color="555555", size=10, italic=True, name="Calibri")
CELL_FONT = Font(size=10, name="Calibri")
WRAP = Alignment(wrap_text=True, vertical="top", horizontal="left")
CENTER = Alignment(horizontal="center", vertical="center")
THIN = Side(style="thin", color="D0D0D0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

SEV_FILL = {
    "HIGH": PatternFill("solid", fgColor="F8CBAD"),
    "MEDIUM": PatternFill("solid", fgColor="FFE699"),
    "LOW": PatternFill("solid", fgColor="C6E0B4"),
    "INFO": PatternFill("solid", fgColor="DDEBF7"),
}
STATUS_FILL = {
    "Open": PatternFill("solid", fgColor="F8CBAD"),
    "To Verify": PatternFill("solid", fgColor="FFE699"),
    "No Action": PatternFill("solid", fgColor="C6E0B4"),
}
ALT_FILL = PatternFill("solid", fgColor="F5F7FA")

wb = openpyxl.Workbook()


def style_header_row(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        cell.border = BORDER


def write_sheet(ws, title, subtitle, headers, rows, widths, sev_col=None, status_col=None):
    ws.sheet_view.showGridLines = False
    # Title
    ws.cell(row=1, column=1, value=title).font = TITLE_FONT
    ws.cell(row=2, column=1, value=subtitle).font = SUB_FONT
    header_row = 4
    for i, h in enumerate(headers, 1):
        ws.cell(row=header_row, column=i, value=h)
    style_header_row(ws, header_row, len(headers))
    # Data
    r = header_row + 1
    for ridx, row in enumerate(rows):
        for i, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=i, value=val)
            cell.font = CELL_FONT
            cell.alignment = WRAP
            cell.border = BORDER
            if ridx % 2 == 1:
                cell.fill = ALT_FILL
        if sev_col:
            sv = ws.cell(row=r, column=sev_col).value
            if sv in SEV_FILL:
                ws.cell(row=r, column=sev_col).fill = SEV_FILL[sv]
                ws.cell(row=r, column=sev_col).alignment = CENTER
                ws.cell(row=r, column=sev_col).font = Font(bold=True, size=10)
        if status_col:
            stv = ws.cell(row=r, column=status_col).value
            if stv in STATUS_FILL:
                ws.cell(row=r, column=status_col).fill = STATUS_FILL[stv]
                ws.cell(row=r, column=status_col).alignment = CENTER
        r += 1
    for i, w in enumerate(widths, 1):
        ws.column_letter = get_column_letter(i)
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)


# ============================================================
# SHEET 1: Overview
# ============================================================
ws = wb.active
ws.title = "Overview"
ws.sheet_view.showGridLines = False
ws.cell(row=1, column=1, value="CCAIAA Dev Account — Security & Performance Audit").font = TITLE_FONT
ws.cell(row=2, column=1, value="AWS Account: 603433800649 (ccaiaa-dev / local)  |  Region: eu-west-1").font = SUB_FONT
ws.cell(row=3, column=1, value=f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}  |  Access: tlz_developer (read-only)").font = SUB_FONT

overview = [
    ["Audit Scope", "IAM roles, inline/managed policies, IAM users, access keys, account password policy for CCAIAA application resources."],
    ["Explicitly Excluded", "Centrally-managed landing-zone & security tooling: DEEP-*, tlz_*, deep-*, csr-*, CspmMonitorAws, tenableio-connector, PAN-OS-*, flexnet_*, snow_*, AWS service-linked roles. DO NOT modify these."],
    ["Total findings", "4 High, 4 Medium, 5 Low/Info"],
    ["Top risk", "Static long-lived admin access key (terraform_svc) + AmazonS3FullAccess on production Lambda role."],
    ["Important caveat", "Many roles are likely Terraform-managed (created by terraform_svc). Fix in IaC code, not console, to avoid drift & recreation."],
    ["Sheets in this workbook", "1) Overview  2) Security Findings  3) IAM Roles Inventory  4) Policies to Fix/Remove  5) IAM Users & Keys  6) Performance Improvements  7) Action Plan"],
]
r = 5
for k, v in overview:
    ws.cell(row=r, column=1, value=k).font = Font(bold=True, size=10, color="1B2A4A")
    c = ws.cell(row=r, column=2, value=v)
    c.font = CELL_FONT
    c.alignment = WRAP
    r += 1
ws.column_dimensions["A"].width = 26
ws.column_dimensions["B"].width = 110
for rr in range(5, r):
    ws.row_dimensions[rr].height = 42


# ============================================================
# SHEET 2: Security Findings
# ============================================================
ws2 = wb.create_sheet("Security Findings")
headers = ["ID", "Severity", "Area", "Resource", "Finding", "Risk / Impact", "Recommended Fix", "Status"]
rows = [
    ["H1", "HIGH", "IAM Policy", "ca-workbench-api-lambda-role",
     "Production API Lambda role has AmazonS3FullAccess (all buckets, all actions). Last used 2026-10-29 (active).",
     "Lambda can read/delete/modify EVERY bucket in the account. Blast radius far exceeds need (only needs ccaiaa-workbench-dev/chat-messages/).",
     "Replace AmazonS3FullAccess with scoped inline policy: s3:GetObject/s3:PutObject on arn:aws:s3:::ccaiaa-workbench-dev/chat-messages/*",
     "Open"],
    ["H2", "HIGH", "IAM Role", "AgentCoreExecutiveRole",
     "Four FullAccess policies: CloudWatchLogsFullAccess, AmazonS3FullAccess, AmazonBedrockFullAccess, BedrockAgentCoreFullAccess. Last used 2026-05-01 (6 months stale).",
     "Massively over-privileged AND likely orphaned. A compromised use = near-full access to logs, S3, Bedrock.",
     "Confirm unused -> delete. If needed, scope to specific model ARNs + one memory resource + one log group (mirror ca-workbench-agent-runtime-policy).",
     "To Verify"],
    ["H3", "HIGH", "IAM User / Key", "terraform_svc",
     "IAM user with AdministratorAccess + static access keys. Active key AKIA...OCNM (2026-10-14). Inactive key AKIA...OCNM (2026-08-25) still present.",
     "Static long-lived admin credential = highest-value target in the account. Inactive key is still a latent liability.",
     "Delete the inactive key now. Rotate the active key. Long-term: migrate Terraform to OIDC / assumable role instead of static admin key.",
     "Open"],
    ["H4", "HIGH", "IAM Key", "vault_svc",
     "Access key AKIA...JXTP created 2026-03-26 (~7 months old, never rotated). Oldest active key in account.",
     "Static keys older than 90 days violate rotation best practice; increases window for credential compromise.",
     "Rotate the key. Confirm Vault still needs static key; if moved to role-assumption, delete the user.",
     "Open"],
    ["M1", "MEDIUM", "IAM Role", "AmazonBedrockExecutionRoleForKnowledgeBase_* (7 roles)",
     "7 KB execution roles exist but only 2 KBs are live (English WQURRONWPQ, multilingual LPMWAHDZS8). Roles _7d8iq, _7fwvr, _bm65p last used Jun; _Experimental May.",
     "Orphaned roles from repeated KB create/delete. Each is an unnecessary trust relationship and audit noise.",
     "Map each role to a live KB. Delete the 4-5 roles no longer backing an existing KB (the Jun/May ones).",
     "To Verify"],
    ["M2", "MEDIUM", "IAM Role", "Test/Experimental roles",
     "Stale test roles: Testcode-role-mfb5096o (Mar 31), pmi-test-sharepoint-role-wefcnmzf (Apr 7), AmazonBedrockExecutionRoleForKB_Experimental (May 18), terraform-demo-lambda-role (Jul 2), KB-retrieval-testing-role-g874f4xf (Jun 15), AmazonBedrockExecutionRoleForAgents_6VJ4K4SRR8K (May 9).",
     "Abandoned test/demo roles accumulate privileges and expand attack surface.",
     "Confirm no live resource uses them -> delete. Consolidate the duplicate pmi-sharepoint-ingest-* and pmi-ingestion-* roles.",
     "To Verify"],
    ["M3", "MEDIUM", "IAM User", "RepoUser",
     "IAM user with AWSCodeCommitFullAccess, no access keys, password never used. Project uses Bitbucket, not CodeCommit.",
     "Abandoned user + unused CodeCommit permission = unnecessary identity.",
     "Delete RepoUser. Also delete AmplifyCodeCommitRole if CodeCommit is not used anywhere.",
     "To Verify"],
    ["M4", "MEDIUM", "IAM Key", "bitbucket-amplify-deployer",
     "Access key AKIA...KOGB created 2026-04-20, never rotated. Used by Jenkins -> Amplify deploy.",
     "Long-lived deploy key; if leaked, allows Amplify deployments.",
     "Rotate key. Scope AmplifyDeploymentPolicy to the single Amplify app drp6k4av42dyw if not already.",
     "Open"],
    ["L1", "LOW", "Account", "Password Policy",
     "Password policy is strong: 16 chars, symbols/numbers/upper/lower required, 90-day expiry, 24 reuse prevention.",
     "No risk — this is compliant.",
     "No action required.",
     "No Action"],
    ["L2", "INFO", "IAM Policy", "ca-workbench-agent-runtime-policy",
     "Inline policy is exemplary least-privilege: scoped to specific Claude model ARNs, one memory resource, one log group.",
     "No risk — use as the template for fixing H1 and H2.",
     "No action required — reference pattern for other roles.",
     "No Action"],
    ["L3", "LOW", "IAM Role", "CAWorkbenchGatewayRole",
     "Two scoped invoke policies (GatewayRuntimeInvokePolicy, InvokeAgentRuntimePolicy). Last used 2026-07-20.",
     "Low — clean policy but stale 3+ months.",
     "Verify still needed; if gateway path deprecated, delete.",
     "To Verify"],
    ["L4", "LOW", "IAM Role", "codebuild-ca-workbench-build-service-role",
     "Active (2026-10-30), scoped CodeBuild VPC + base policies.",
     "Low — correctly scoped and in use.",
     "No action required.",
     "No Action"],
    ["L5", "LOW", "IAM Policy", "62 customer-managed policies",
     "Account has 62 local managed policies; likely many detached/orphaned.",
     "Policy sprawl complicates audits; orphaned policies may contain stale broad permissions.",
     "Run a cleanup: list policies with zero attachments -> review -> delete unused.",
     "To Verify"],
]
write_sheet(ws2, "Security Findings", "Prioritized IAM & account findings for the CCAIAA application layer.",
            headers, rows, [6, 10, 14, 34, 50, 50, 55, 11], sev_col=2, status_col=8)
for rr in range(5, 5 + len(rows)):
    ws2.row_dimensions[rr].height = 68


# ============================================================
# SHEET 3: IAM Roles Inventory
# ============================================================
ws3 = wb.create_sheet("IAM Roles Inventory")
headers = ["Role Name", "Purpose (inferred)", "Last Used", "Attached / Inline Policies", "Over-Privileged?", "Verdict"]
rows = [
    ["ca-workbench-api-lambda-role", "Proxy Lambda execution (API)", "2026-10-29 (ACTIVE)", "AWSLambdaVPCAccessExecutionRole, AWSLambdaBasicExecutionRole, AmazonS3FullAccess", "YES - S3FullAccess", "KEEP but scope S3 (H1)"],
    ["ca-workbench-agent-runtime-role", "AgentCore runtime (older)", "2026-07-08 (stale 4mo)", "inline: ca-workbench-agent-runtime-policy (well-scoped)", "No", "VERIFY - superseded by AgentCore runtime?"],
    ["AgentCoreExecutiveRole", "AgentCore (early/manual)", "2026-05-01 (stale 6mo)", "CloudWatchLogsFullAccess, AmazonS3FullAccess, AmazonBedrockFullAccess, BedrockAgentCoreFullAccess", "YES - 4x FullAccess", "DELETE or heavily scope (H2)"],
    ["CAWorkbenchGatewayRole", "Gateway -> runtime invoke", "2026-07-20 (stale)", "GatewayRuntimeInvokePolicy, InvokeAgentRuntimePolicy", "No", "VERIFY still needed"],
    ["codebuild-ca-workbench-build-service-role", "CodeBuild image builds", "2026-10-30 (ACTIVE)", "CodeBuildVpcPolicy-..., CodeBuildBasePolicy-...", "No", "KEEP"],
    ["AmazonBedrockAgentCoreRuntimeDefaultServiceRole-xwsqu", "AgentCore runtime default", "n/a", "(AgentCore managed)", "Review", "VERIFY"],
    ["AmazonBedrockExecutionRoleForKnowledgeBase_y62sx", "KB execution", "2026-09-16", "(KB service role)", "Review", "KEEP (maps to a live KB?)"],
    ["AmazonBedrockExecutionRoleForKnowledgeBase_40c4v", "KB execution", "2026-09-03", "(KB service role)", "Review", "VERIFY"],
    ["AmazonBedrockExecutionRoleForKnowledgeBase_7x4vd", "KB execution", "2026-09-03", "(KB service role)", "Review", "VERIFY"],
    ["AmazonBedrockExecutionRoleForKnowledgeBase_7d8iq", "KB execution", "2026-06-16 (stale)", "(KB service role)", "Review", "LIKELY DELETE"],
    ["AmazonBedrockExecutionRoleForKnowledgeBase_7fwvr", "KB execution", "2026-06-22 (stale)", "(KB service role)", "Review", "LIKELY DELETE"],
    ["AmazonBedrockExecutionRoleForKnowledgeBase_bm65p", "KB execution", "2026-06-22 (stale)", "(KB service role)", "Review", "LIKELY DELETE"],
    ["AmazonBedrockExecutionRoleForKB_Experimental", "KB experiment", "2026-05-18 (stale)", "(KB service role)", "Review", "DELETE"],
    ["AmazonBedrockExecutionRoleForAgents_6VJ4K4SRR8K", "Bedrock Agents", "2026-05-09 (stale)", "(agent service role)", "Review", "VERIFY + DELETE"],
    ["KB-retrieval-testing-role-g874f4xf", "KB retrieval test", "2026-06-15 (stale)", "(test)", "Review", "DELETE"],
    ["ccaiaa-agent-test-fn-role", "Agent test function", "2026-10-13", "(test)", "Review", "VERIFY (recent)"],
    ["lambda-langsmith-test-role", "LangSmith test", "2026-10-11", "(test)", "Review", "VERIFY (recent)"],
    ["langsmith-agent-lambda-role", "LangSmith agent", "n/a", "(lambda)", "Review", "VERIFY"],
    ["LangsmithExportLambdaRole", "LangSmith export", "n/a", "(lambda)", "Review", "VERIFY"],
    ["QueryCostJoinLambdaRole", "Cost query join", "n/a", "(lambda)", "Review", "VERIFY"],
    ["terraform-demo-lambda-role", "Terraform demo", "2026-07-02 (stale)", "(demo)", "Review", "DELETE"],
    ["Testcode-role-mfb5096o", "Test code", "2026-03-31 (stale 7mo)", "(test)", "Review", "DELETE"],
    ["pmi-test-sharepoint-role-wefcnmzf", "SharePoint test", "2026-04-07 (stale)", "(test)", "Review", "DELETE"],
    ["pmi-sharepoint-ingest-role-* (3)", "SharePoint ingestion (dup)", "various", "(ingestion)", "Review", "CONSOLIDATE"],
    ["pmi-ingestion-* (3)", "Ingestion (dup)", "various", "(ingestion)", "Review", "CONSOLIDATE"],
    ["amplify-login-lambda-228803b5", "Amplify login lambda", "n/a", "(lambda)", "Review", "VERIFY"],
    ["AmplifyCodeCommitRole-...", "Amplify + CodeCommit", "n/a", "(amplify)", "Review", "DELETE if no CodeCommit"],
]
write_sheet(ws3, "IAM Roles Inventory (CCAIAA application roles)",
            "Baseline landing-zone roles (DEEP-*, tlz_*, deep-*, etc.) excluded - centrally managed, do not modify.",
            headers, rows, [46, 30, 20, 52, 16, 34], status_col=None)
for rr in range(5, 5 + len(rows)):
    ws3.row_dimensions[rr].height = 30


# ============================================================
# SHEET 4: Policies to Fix / Remove
# ============================================================
ws4 = wb.create_sheet("Policies to Fix or Remove")
headers = ["Target", "Policy", "Type", "Current Permission", "Problem", "Action", "Replacement / Scoped Policy"]
rows = [
    ["ca-workbench-api-lambda-role", "AmazonS3FullAccess", "AWS Managed", "s3:* on *",
     "Full access to all buckets", "DETACH + replace",
     "Inline: Allow s3:GetObject,s3:PutObject on arn:aws:s3:::ccaiaa-workbench-dev/chat-messages/*"],
    ["AgentCoreExecutiveRole", "AmazonBedrockFullAccess", "AWS Managed", "bedrock:* on *",
     "Full Bedrock access", "DETACH + replace (or delete role)",
     "Allow bedrock:InvokeModel on specific anthropic.claude-* model ARNs only"],
    ["AgentCoreExecutiveRole", "AmazonS3FullAccess", "AWS Managed", "s3:* on *",
     "Full S3 access", "DETACH",
     "Scope to specific bucket/prefix if role retained"],
    ["AgentCoreExecutiveRole", "CloudWatchLogsFullAccess", "AWS Managed", "logs:* on *",
     "Full CloudWatch Logs access", "DETACH + replace",
     "Allow logs:CreateLogGroup/Stream,PutLogEvents on the role's own log group ARN only"],
    ["AgentCoreExecutiveRole", "BedrockAgentCoreFullAccess", "AWS Managed", "bedrock-agentcore:* on *",
     "Full AgentCore access", "DETACH",
     "Scope to the specific runtime/memory ARN"],
    ["terraform_svc (user)", "AdministratorAccess", "AWS Managed", "* on *",
     "Full admin on static key", "REVIEW - keep only if Terraform truly needs full admin; migrate to OIDC role",
     "If retained, add permissions boundary; otherwise scope to services Terraform actually manages"],
    ["RepoUser (user)", "AWSCodeCommitFullAccess", "AWS Managed", "codecommit:* on *",
     "Unused (Bitbucket used, not CodeCommit)", "DETACH + delete user", "n/a - remove"],
    ["bitbucket-amplify-deployer (user)", "AmplifyDeploymentPolicy", "Customer Managed", "amplify deploy actions",
     "Verify scoped to one app", "REVIEW + scope",
     "Allow amplify:CreateDeployment,StartDeployment,GetApp,GetBranch on app drp6k4av42dyw only"],
    ["(account-wide)", "62 customer-managed policies", "Customer Managed", "various",
     "Likely orphaned/detached", "CLEANUP",
     "Identify policies with 0 attachments -> review -> delete"],
]
write_sheet(ws4, "Policies to Fix or Remove",
            "Over-privileged or unused policies. Prefer fixing in Terraform/IaC where applicable.",
            headers, rows, [34, 28, 16, 22, 34, 40, 55])
for rr in range(5, 5 + len(rows)):
    ws4.row_dimensions[rr].height = 58


# ============================================================
# SHEET 5: IAM Users & Keys
# ============================================================
ws5 = wb.create_sheet("IAM Users & Keys")
headers = ["User", "Access Key", "Key Status", "Key Created", "Age Concern", "Attached Policy", "Action"]
rows = [
    ["terraform_svc", "AKIA...YVBJWPZW", "Active", "2026-10-14", "Rotate on schedule", "AdministratorAccess, app_account_restrictions", "Rotate + migrate to OIDC"],
    ["terraform_svc", "AKIA...U4ZZOCNM", "Inactive", "2026-08-25", "Disabled but not deleted", "(same user)", "DELETE key now"],
    ["vault_svc", "AKIA...SB64JXTP", "Active", "2026-03-26", "~7 months - oldest key", "terraform-2026032615...", "Rotate; verify still needed"],
    ["bitbucket-amplify-deployer", "AKIA...RW33KOGB", "Active", "2026-04-20", "~6 months, never rotated", "AmplifyDeploymentPolicy", "Rotate + scope policy"],
    ["RepoUser", "(none)", "n/a", "n/a", "Unused user", "AWSCodeCommitFullAccess", "DELETE user"],
]
write_sheet(ws5, "IAM Users & Access Keys",
            "Static long-lived credentials. Prefer role-assumption / OIDC over static keys.",
            headers, rows, [28, 22, 12, 14, 24, 42, 30])
for rr in range(5, 5 + len(rows)):
    ws5.row_dimensions[rr].height = 32


# ============================================================
# SHEET 6: Performance Improvements
# ============================================================
ws6 = wb.create_sheet("Performance Improvements")
headers = ["ID", "Area", "Observation", "Improvement", "Benefit", "Effort"]
rows = [
    ["P1", "LLM Cost/Perf", "Planner & synthesis use Claude Opus/Sonnet; high input-token volume.", "Enable Bedrock prompt caching for repeated planner/system prompts.", "50-90% input-token cost reduction; lower latency.", "Low"],
    ["P2", "LLM Routing", "Simple classification/routing uses large models.", "Route low-complexity steps to Claude Haiku.", "~10x cheaper per token for those calls.", "Medium"],
    ["P3", "KB Retrieval", "Multi-query (up to 8) + rerank per request.", "Cache frequent KB query results; tune KB_MAX_QUERIES.", "Lower Bedrock/OpenSearch load & latency.", "Medium"],
    ["P4", "Observability Cost", "LangSmith tracing active in dev (thousands of traces/mo).", "Disable/ sample LangSmith in non-debug runs.", "Removes LangSmith trace cost.", "Low"],
    ["P5", "Lambda", "Proxy Lambda in VPC (adds cold-start ENI latency).", "Right-size memory; confirm VPC needed; consider provisioned concurrency for hot paths.", "Lower cold-start latency.", "Medium"],
    ["P6", "DynamoDB", "Chat tables - verify on-demand vs provisioned.", "Confirm on-demand billing; add TTL on ChatJobs to auto-expire old jobs.", "Cost control + smaller tables.", "Low"],
    ["P7", "S3", "Chat content stored indefinitely.", "Add S3 lifecycle rules (transition to IA / expire old chat content).", "Storage cost reduction.", "Low"],
    ["P8", "OpenSearch (KB)", "OpenSearch is a large fixed monthly cost.", "Review collection sizing vs document volume; right-size.", "Infra cost reduction.", "Medium"],
    ["P9", "Web Search", "Gemini used for web extraction with high output tokens.", "Cap WEB_GEMINI_MAX_OUTPUT_TOKENS; tune WEB_MAX_USABLE_SOURCES.", "Lower per-call cost.", "Low"],
    ["P10", "CI/CD", "Jenkins polls SCM every 2 min; archiver import may be fragile.", "Switch to webhook triggers; pin & verify archiver API in Package stage.", "Faster, more reliable builds.", "Low"],
    ["P11", "Supply Chain", "Some requirements use version ranges (boto3, tavily, scrapling).", "Pin exact versions + image digests (per LiteLLM incident guidance).", "Reproducible, safer builds.", "Low"],
]
write_sheet(ws6, "Performance & Cost Improvements",
            "Application and infrastructure efficiency opportunities.",
            headers, rows, [6, 20, 46, 50, 40, 10])
for rr in range(5, 5 + len(rows)):
    ws6.row_dimensions[rr].height = 44


# ============================================================
# SHEET 7: Action Plan
# ============================================================
ws7 = wb.create_sheet("Action Plan")
headers = ["Priority", "Task", "Related ID", "Owner", "Pre-req / Caution", "Status"]
rows = [
    ["1 - Now", "Delete terraform_svc inactive access key", "H3", "Platform/DevOps", "Confirm not referenced anywhere", "Open"],
    ["1 - Now", "Rotate terraform_svc, vault_svc, bitbucket-amplify-deployer keys", "H3,H4,M4", "Platform/DevOps", "Update consumers (Vault, Jenkins) with new keys", "Open"],
    ["1 - Now", "Replace AmazonS3FullAccess on ca-workbench-api-lambda-role with scoped policy", "H1", "App team", "Test chat upload/retrieval after change; fix in Terraform if IaC-managed", "Open"],
    ["2 - Soon", "Delete or scope AgentCoreExecutiveRole", "H2", "App team", "Confirm no live AgentCore resource uses it", "To Verify"],
    ["2 - Soon", "Map & delete orphaned KB execution roles (Jun/May ones)", "M1", "App team", "Cross-ref against live KBs WQURRONWPQ, LPMWAHDZS8", "To Verify"],
    ["2 - Soon", "Delete stale test/demo roles", "M2", "App team", "Confirm no live Lambda/resource uses them", "To Verify"],
    ["2 - Soon", "Delete RepoUser + AmplifyCodeCommitRole (CodeCommit unused)", "M3", "Platform/DevOps", "Confirm CodeCommit not used", "To Verify"],
    ["3 - Hygiene", "Clean up orphaned customer-managed policies (0 attachments)", "L5", "Platform/DevOps", "Review each before delete", "To Verify"],
    ["3 - Hygiene", "Migrate static service keys to OIDC / assumable roles", "H3,H4", "Platform/DevOps", "Design + test OIDC trust", "Open"],
    ["Perf-1", "Enable Bedrock prompt caching", "P1", "App team", "Validate caching compatibility", "Open"],
    ["Perf-2", "Disable/sample LangSmith in production", "P4", "App team", "Keep in dev/debug only", "Open"],
    ["Perf-3", "Add S3 lifecycle + DynamoDB TTL", "P6,P7", "App team", "Agree retention period with business", "Open"],
    ["Perf-4", "Pin dependency versions + image digests", "P11", "App team", "Test build after pinning", "Open"],
]
write_sheet(ws7, "Action Plan",
            "Prioritized tasks. '1-Now' = security risk; '2-Soon' = least-privilege cleanup; 'Perf' = efficiency.",
            headers, rows, [12, 56, 14, 18, 44, 11], status_col=6)
for rr in range(5, 5 + len(rows)):
    ws7.row_dimensions[rr].height = 40

wb.save(OUT)
print(f"Saved: {OUT}")
print(f"Sheets: {wb.sheetnames}")
