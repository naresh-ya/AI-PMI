# Variables for generic IAM users (QA)
#
# Each entry:
#   managed_policy_arns - list of AWS/customer managed policy ARNs to attach
#   inline_policy_json  - optional inline policy JSON (empty = none)
#   create_access_key   - whether to generate an access key (secret goes to state)
#
# Current users:
#   bitbucket-amplify-deployer - used by the Bitbucket/Jenkins pipeline to deploy
#     the frontend to Amplify. MULTI-APP deployer: scoped to apps/* so this ONE
#     user can deploy to ANY Amplify app in the QA account (not a single app).
#     Actions stay Amplify-deploy only (service + action scoped), matching dev's
#     AmplifyDeploymentPolicy. Same user name is reused in dev/qa/prod.

variable "iam_users" {
  description = "Map of IAM users to create, with their policies and access-key flag"
  type = map(object({
    managed_policy_arns = optional(list(string), [])
    inline_policy_json  = optional(string, "")
    create_access_key   = optional(bool, false)
  }))
  default = {
    "bitbucket-amplify-deployer" = {
      managed_policy_arns = []
      create_access_key   = true
      inline_policy_json  = <<-EOT
        {
          "Version": "2012-10-17",
          "Statement": [
            {
              "Sid": "AmplifyDeployAllAppsInAccount",
              "Effect": "Allow",
              "Action": [
                "amplify:CreateDeployment",
                "amplify:StartDeployment",
                "amplify:GetApp",
                "amplify:GetBranch",
                "amplify:GetJob",
                "amplify:ListApps",
                "amplify:ListBranches"
              ],
              "Resource": "arn:aws:amplify:eu-west-1:793012896927:apps/*"
            }
          ]
        }
      EOT
    }
  }
}
