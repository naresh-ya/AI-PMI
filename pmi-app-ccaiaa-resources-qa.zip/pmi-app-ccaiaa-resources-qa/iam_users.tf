# IAM Users - generic, reusable (QA)
#
# A single, map-driven place to manage IAM users for this account. Add a user
# by adding an entry to var.iam_users (see iam_users_variables.tf). Each user
# can have: attached managed policy ARNs, an inline policy (JSON), and an
# optional access key.
#
# SECURITY NOTE: when create_access_key = true, the generated SECRET access key
# is stored in Terraform STATE and exposed as a sensitive output. Retrieve it
# once, store it securely (e.g. Jenkins/K8s secret), and rotate per policy.
# Prefer IAM roles / OIDC over long-lived access keys where possible.

resource "aws_iam_user" "this" {
  for_each = var.iam_users
  name     = each.key
  tags     = merge(local.common_tags, { Name = each.key })
}

# Attach managed policy ARNs (flattened user x policy pairs)
locals {
  iam_user_policy_pairs = merge([
    for uname, u in var.iam_users : {
      for arn in u.managed_policy_arns : "${uname}::${arn}" => {
        user = uname
        arn  = arn
      }
    }
  ]...)
}

resource "aws_iam_user_policy_attachment" "this" {
  for_each   = local.iam_user_policy_pairs
  user       = aws_iam_user.this[each.value.user].name
  policy_arn = each.value.arn
}

# Optional per-user inline policy
resource "aws_iam_user_policy" "this" {
  for_each = { for uname, u in var.iam_users : uname => u if u.inline_policy_json != "" }
  name     = "${each.key}-policy"
  user     = aws_iam_user.this[each.key].name
  policy   = each.value.inline_policy_json
}

# Optional per-user access key
resource "aws_iam_access_key" "this" {
  for_each = { for uname, u in var.iam_users : uname => u if u.create_access_key }
  user     = aws_iam_user.this[each.key].name
}
