# S3 Buckets - Phase 1 (Stateful data stores)
#
# Bucket configurations captured from the live dev-ca AWS account
# (603433800649, eu-west-1). S3 is a regional service - these buckets do NOT
# require VPC/subnets or any baseline networking.
#
# Secure defaults applied to all buckets for QA:
#   - Versioning ENABLED
#   - Server-side encryption (per-bucket: AES256 or KMS, matching source) + bucket key
#   - Full public access block (all four settings true)
#   - prevent_destroy lifecycle guard
#
# NOTE: Terraform creates EMPTY buckets. It does not copy objects/data.
#       Cross-account data copy (dev -> QA) is a separate out-of-band step.

locals {
  # App data buckets. The value is the bucket NAME (kept as-is from source).
  s3_buckets = {
    documents         = var.s3_bucket_name_documents
    documents_sandbox = var.s3_bucket_name_documents_sandbox
    kb                = var.s3_bucket_name_kb
  }

  # Buckets that use KMS SSE (others default to AES256)
  s3_kms_buckets = ["kb"]
}

resource "aws_s3_bucket" "this" {
  for_each = local.s3_buckets

  bucket = each.value

  tags = merge(local.common_tags, { Name = each.value })

  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_s3_bucket_versioning" "this" {
  for_each = aws_s3_bucket.this

  bucket = each.value.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "this" {
  for_each = aws_s3_bucket.this

  bucket = each.value.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = contains(local.s3_kms_buckets, each.key) ? "aws:kms" : "AES256"
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "this" {
  for_each = aws_s3_bucket.this

  bucket = each.value.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
