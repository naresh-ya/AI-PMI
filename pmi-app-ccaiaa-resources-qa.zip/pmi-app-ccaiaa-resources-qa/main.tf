# AWS provider and region
data "aws_caller_identity" "current" {}

locals {
  baseline_version = "v0.0.2"
  common_tags = {
    project                   = var.name
    stack_env                 = var.environment
    security_data_sensitivity = "protected"
    stack                     = var.name
    stack_version             = "0.1.0"
    stack_lifecycle           = "perm"
    ProductCode               = upper(var.short_name)
    Environment               = upper(var.environment)
    EnvironmentFamily         = upper(var.environment_family)
  }
}

data "terraform_remote_state" "app-baseline" {
  backend = "remote"

  config = {
    organization = var.tfe_org_name
    hostname     = var.tfe_host_name

    workspaces = {
      name = var.baseline_workspace_name
    }
  }
}

provider "aws" {
  region = data.terraform_remote_state.app-baseline.outputs.region
}
