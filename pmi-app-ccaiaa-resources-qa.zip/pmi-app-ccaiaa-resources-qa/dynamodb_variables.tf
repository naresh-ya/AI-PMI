# Variables for DynamoDB tables (Phase 1)
#
# Defaults match the table names the application already references today
# (fixed names, not env-suffixed), so QA works without any code changes.
# Override in the TFE workspace only if a different name is required.

###############################################################################
# Table name overrides
###############################################################################
variable "dynamodb_table_name_hitl" {
  description = "Name of the HITL table"
  type        = string
  default     = "pmi-agentic-ai-hitl"
}

variable "dynamodb_table_name_knowledge_base" {
  description = "Name of the knowledge base table"
  type        = string
  default     = "pmi-agentic-ai-knowledge-base"
}

variable "dynamodb_table_name_curated_links" {
  description = "Name of the curated links table"
  type        = string
  default     = "pmi-agentic-ai-curated-links"
}

variable "dynamodb_table_name_policy_updates" {
  description = "Name of the policy updates table"
  type        = string
  default     = "pmi-agentic-ai-policy-updates"
}

variable "dynamodb_table_name_policy_updates_output" {
  description = "Name of the policy updates output table"
  type        = string
  default     = "pmi-agentic-ai-policy-updates-output"
}

variable "dynamodb_table_name_users" {
  description = "Name of the users table"
  type        = string
  default     = "pmi-agentic-ai-users"
}

###############################################################################
# Optional customer-managed KMS key for DynamoDB encryption at rest.
# Empty string => use AWS-managed key. Set to a CMK ARN to enable
# customer-managed encryption across all tables in this file.
###############################################################################
variable "dynamodb_kms_key_arn" {
  description = "Optional CMK ARN for DynamoDB SSE. Empty = AWS-managed key."
  type        = string
  default     = ""
}

###############################################################################
# Point-in-time recovery toggles (per table).
# Default = true (recommended for QA/prod). Dev had these mixed; QA enables all.
###############################################################################
variable "dynamodb_hitl_pitr" {
  description = "Enable PITR on the HITL table"
  type        = bool
  default     = true
}

variable "dynamodb_knowledge_base_pitr" {
  description = "Enable PITR on the knowledge base table"
  type        = bool
  default     = true
}

variable "dynamodb_curated_links_pitr" {
  description = "Enable PITR on the curated links table"
  type        = bool
  default     = true
}

variable "dynamodb_policy_updates_pitr" {
  description = "Enable PITR on the policy updates table"
  type        = bool
  default     = true
}

variable "dynamodb_policy_updates_output_pitr" {
  description = "Enable PITR on the policy updates output table"
  type        = bool
  default     = true
}

variable "dynamodb_users_pitr" {
  description = "Enable PITR on the users table"
  type        = bool
  default     = true
}
