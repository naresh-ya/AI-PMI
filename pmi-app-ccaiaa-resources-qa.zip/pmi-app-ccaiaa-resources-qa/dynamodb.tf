# DynamoDB Tables - Phase 1 (Stateful data stores)
#
# Schemas captured from the dev-ca account (603433800649, eu-west-1) and
# parameterized for multi-environment use. Table names default to the same
# names the application code references today (see lambda.tf / lambda_iam_policies.tf),
# so no code changes are required. Names are exposed as variables in case a
# future environment needs a different value.
#
# All tables use PAY_PER_REQUEST (on-demand) billing, matching dev.
# Point-in-time recovery (PITR) is enabled by default for QA/prod safety even
# where it was disabled in dev; override per table via the *_pitr variables.
#
# NOTE: Terraform manages table STRUCTURE only. It does not copy data.
#       Data migration (if required) is a separate, out-of-band step.

locals {
  # Server-side encryption is always enabled (matches team convention in the
  # baseline/backup modules). With an empty kms_key_arn, DynamoDB uses an
  # AWS-managed KMS key. Set var.dynamodb_kms_key_arn to a CMK to use a
  # customer-managed key instead.
  dynamodb_kms_key_arn = var.dynamodb_kms_key_arn != "" ? var.dynamodb_kms_key_arn : null
}

###############################################################################
# pmi-agentic-ai-hitl
# Hash: hitl_id (S) | GSIs: StatusIndex(status), RequestIdIndex(request_id)
###############################################################################
resource "aws_dynamodb_table" "hitl" {
  name         = var.dynamodb_table_name_hitl
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "hitl_id"

  attribute {
    name = "hitl_id"
    type = "S"
  }
  attribute {
    name = "status"
    type = "S"
  }
  attribute {
    name = "request_id"
    type = "S"
  }

  global_secondary_index {
    name            = "StatusIndex"
    hash_key        = "status"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "RequestIdIndex"
    hash_key        = "request_id"
    projection_type = "ALL"
  }

  point_in_time_recovery {
    enabled = var.dynamodb_hitl_pitr
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = local.dynamodb_kms_key_arn
  }

  tags = merge(local.common_tags, { Name = var.dynamodb_table_name_hitl })

  lifecycle {
    prevent_destroy = true
  }
}

###############################################################################
# pmi-agentic-ai-knowledge-base
# Hash: chunk_id (S) | GSI: DocumentIdIndex(document_id)
###############################################################################
resource "aws_dynamodb_table" "knowledge_base" {
  name         = var.dynamodb_table_name_knowledge_base
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "chunk_id"

  attribute {
    name = "chunk_id"
    type = "S"
  }
  attribute {
    name = "document_id"
    type = "S"
  }

  global_secondary_index {
    name            = "DocumentIdIndex"
    hash_key        = "document_id"
    projection_type = "ALL"
  }

  point_in_time_recovery {
    enabled = var.dynamodb_knowledge_base_pitr
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = local.dynamodb_kms_key_arn
  }

  tags = merge(local.common_tags, { Name = var.dynamodb_table_name_knowledge_base })

  lifecycle {
    prevent_destroy = true
  }
}

###############################################################################
# pmi-agentic-ai-curated-links
# Hash: id (S) | no GSIs
###############################################################################
resource "aws_dynamodb_table" "curated_links" {
  name         = var.dynamodb_table_name_curated_links
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "id"

  attribute {
    name = "id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = var.dynamodb_curated_links_pitr
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = local.dynamodb_kms_key_arn
  }

  tags = merge(local.common_tags, { Name = var.dynamodb_table_name_curated_links })

  lifecycle {
    prevent_destroy = true
  }
}

###############################################################################
# pmi-agentic-ai-policy-updates
# Hash: url_id (S) | no GSIs
###############################################################################
resource "aws_dynamodb_table" "policy_updates" {
  name         = var.dynamodb_table_name_policy_updates
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "url_id"

  attribute {
    name = "url_id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = var.dynamodb_policy_updates_pitr
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = local.dynamodb_kms_key_arn
  }

  tags = merge(local.common_tags, { Name = var.dynamodb_table_name_policy_updates })

  lifecycle {
    prevent_destroy = true
  }
}

###############################################################################
# pmi-agentic-ai-policy-updates-output
# Hash: id (S) | no GSIs
###############################################################################
resource "aws_dynamodb_table" "policy_updates_output" {
  name         = var.dynamodb_table_name_policy_updates_output
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "id"

  attribute {
    name = "id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = var.dynamodb_policy_updates_output_pitr
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = local.dynamodb_kms_key_arn
  }

  tags = merge(local.common_tags, { Name = var.dynamodb_table_name_policy_updates_output })

  lifecycle {
    prevent_destroy = true
  }
}

###############################################################################
# pmi-agentic-ai-users
# Hash: email (S) | no GSIs
###############################################################################
resource "aws_dynamodb_table" "users" {
  name         = var.dynamodb_table_name_users
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"

  attribute {
    name = "email"
    type = "S"
  }

  point_in_time_recovery {
    enabled = var.dynamodb_users_pitr
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = local.dynamodb_kms_key_arn
  }

  tags = merge(local.common_tags, { Name = var.dynamodb_table_name_users })

  lifecycle {
    prevent_destroy = true
  }
}

# document_metadata was REMOVED - it no longer exists in dev-ca (deleted/renamed).
# If it is reinstated in dev, re-add it here.
