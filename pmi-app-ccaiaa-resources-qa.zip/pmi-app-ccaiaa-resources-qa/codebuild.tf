# CodeBuild - ca-workbench-lambda-build (QA)
#
# Based on the live dev-ca project `ca-workbench-lambda-build`.
# PURPOSE: primarily a CONNECTIVITY TEST - proves whether QA CodeBuild can
# reach and authenticate to Bitbucket (source.app.pconnect.biz).
#
# Design notes (matching dev):
#  - source type = NO_SOURCE. The buildspec clones Bitbucket manually using
#    git + embedded credentials (BITBUCKET_USERNAME / BITBUCKET_TOKEN), so NO
#    CodeStar/CodeConnections source connection is required.
#  - privilegedMode = true (Docker build), Amazon Linux standard 6.0, SMALL.
#  - No VPC config in dev => runs with AWS-managed egress. To test in-VPC
#    reachability instead, set var.codebuild_vpc_enabled = true.
#
# SECURITY: dev stored BITBUCKET_USERNAME/TOKEN as PLAINTEXT in the project.
# Here they are injected via variables (set as SENSITIVE in the TFE workspace),
# never hardcoded in the repo.

resource "aws_iam_role" "codebuild_ca_workbench" {
  name = "codebuild-ca-workbench-lambda-build-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "codebuild.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = merge(local.common_tags, { Name = "codebuild-ca-workbench-lambda-build-role" })
}

resource "aws_iam_role_policy" "codebuild_ca_workbench" {
  name = "codebuild-ca-workbench-lambda-build-policy"
  role = aws_iam_role.codebuild_ca_workbench.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "CloudWatchLogs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "arn:aws:logs:${data.terraform_remote_state.app-baseline.outputs.region}:${data.aws_caller_identity.current.account_id}:log-group:/aws/codebuild/*"
      },
      {
        Sid    = "EcrPushPull"
        Effect = "Allow"
        Action = [
          "ecr:GetAuthorizationToken",
          "ecr:BatchCheckLayerAvailability",
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage",
          "ecr:PutImage",
          "ecr:InitiateLayerUpload",
          "ecr:UploadLayerPart",
          "ecr:CompleteLayerUpload"
        ]
        Resource = "*"
      },
      {
        Sid    = "VpcEniForVpcBuilds"
        Effect = "Allow"
        Action = [
          "ec2:CreateNetworkInterface",
          "ec2:DescribeNetworkInterfaces",
          "ec2:DeleteNetworkInterface",
          "ec2:DescribeSubnets",
          "ec2:DescribeSecurityGroups",
          "ec2:DescribeVpcs",
          "ec2:DescribeDhcpOptions",
          "ec2:DescribeNetworkInterfacePermissions",
          "ec2:DescribeAvailabilityZones",
          "ec2:CreateNetworkInterfacePermission"
        ]
        Resource = "*"
      }
    ]
  })
}

# Security group for CodeBuild when running in-VPC (only created if VPC mode on).
# Matches the dev "Lambda-LLM" SG: egress HTTPS (443) only, no ingress.
# Running in-VPC via private subnets (with NAT egress) is what made the build
# reach Bitbucket successfully in dev.
resource "aws_security_group" "codebuild_sg" {
  count       = var.codebuild_vpc_enabled ? 1 : 0
  name        = "ca-workbench-lambda-build-sg"
  description = "SG for ca-workbench-lambda-build CodeBuild (VPC mode) - HTTPS egress only"
  vpc_id      = data.terraform_remote_state.app-baseline.outputs.vpc_id_primary

  egress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTPS outbound (Bitbucket, ECR, AWS APIs)"
  }

  tags = merge(local.common_tags, { Name = "ca-workbench-lambda-build-sg" })
}

resource "aws_codebuild_project" "ca_workbench_lambda_build" {
  name          = "ca-workbench-lambda-build"
  description   = "Builds CA Workbench Lambda Docker image and pushes it to Amazon ECR. (QA connectivity test)"
  service_role  = aws_iam_role.codebuild_ca_workbench.arn
  build_timeout = 60

  artifacts {
    type = "NO_ARTIFACTS"
  }

  environment {
    type                        = "LINUX_CONTAINER"
    image                       = "aws/codebuild/amazonlinux-x86_64-standard:6.0"
    compute_type                = "BUILD_GENERAL1_SMALL"
    privileged_mode             = true
    image_pull_credentials_type = "CODEBUILD"

    environment_variable {
      name  = "BITBUCKET_USERNAME"
      value = var.codebuild_bitbucket_username
    }
    environment_variable {
      name  = "BITBUCKET_TOKEN"
      value = var.codebuild_bitbucket_token
    }
    environment_variable {
      name  = "AWS_REGION"
      value = data.terraform_remote_state.app-baseline.outputs.region
    }
    environment_variable {
      name  = "AWS_ACCOUNT_ID"
      value = data.aws_caller_identity.current.account_id
    }
    environment_variable {
      name  = "ECR_REPOSITORY_NAME"
      value = var.codebuild_ecr_repository_name
    }
    environment_variable {
      name  = "IMAGE_TAG"
      value = var.codebuild_image_tag
    }
  }

  source {
    type      = "NO_SOURCE"
    buildspec = var.codebuild_buildspec
  }

  dynamic "vpc_config" {
    for_each = var.codebuild_vpc_enabled ? [1] : []
    content {
      vpc_id             = data.terraform_remote_state.app-baseline.outputs.vpc_id_primary
      subnets            = slice(data.terraform_remote_state.app-baseline.outputs.private_subnets_primary, 0, 2)
      security_group_ids = [aws_security_group.codebuild_sg[0].id]
    }
  }

  logs_config {
    cloudwatch_logs {
      status = "ENABLED"
    }
  }

  tags = merge(local.common_tags, { Name = "ca-workbench-lambda-build" })
}
