# Variables for the caaiaa_agentic_app Amplify app (QA)

variable "amplify_app_name" {
  description = "Name of the Amplify app"
  type        = string
  default     = "caaiaa_agentic_app"
}

variable "amplify_branch_name" {
  description = "Amplify branch (hosting slot) the Jenkins QA pipeline deploys to"
  type        = string
  default     = "qa"
}
