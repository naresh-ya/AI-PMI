# Outputs for S3 buckets (Phase 1)
# Exposed so later phases (IAM policies, Lambda env vars, S3 notifications)
# can reference the bucket names/ARNs.

output "s3_bucket_names" {
  description = "Map of logical name => S3 bucket name"
  value       = { for k, b in aws_s3_bucket.this : k => b.id }
}

output "s3_bucket_arns" {
  description = "Map of logical name => S3 bucket ARN"
  value       = { for k, b in aws_s3_bucket.this : k => b.arn }
}
