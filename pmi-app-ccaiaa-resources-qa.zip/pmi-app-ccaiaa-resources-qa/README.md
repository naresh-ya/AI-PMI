# Application Resources

The following resource outputs can be read from BASELINE via the following variable path:

data.terraform_remote_state.app-baseline.outputs.

account = 
account_short_name = 
baseline_version = v2.0.0
route53_zone_id = 
route53_zone_name = 
vpc_cidr_block_primary = 
vpc_id = 
vpc_intra_subnets_cidr_blocks_primary = [
]
vpc_intra_subnets_primary = [
]
vpc_private_subnets_cidr_blocks_primary = [
]
vpc_private_subnets_primary = [
]
vpc_rtb_id = 

output "region" {
output "vpc_id_primary" {
output "baseline_version" {
output "vpc_cidr_block_primary" {
output "vpc_secondary_cidr_blocks" {
output "private_subnets_cidr_blocks_primary" {
output "private_subnets_primary" {
output "public_subnets_primary" {
output "public_subnets_cidr_blocks_primary" {
output "eks_subnets_primary" {
output "eks_subnets_cidr_blocks" {
output "database_subnets_primary" {
output "database_subnets_cidr_blocks" {
output "database_subnet_group_id" {
output "route53_acn_zone_name" {
output "route53_acn_zone_id" {
output "route53_vpc_zone_name" {
output "route53_vpc_zone_id" {
output "route53_acn_pvt_zone_name" {
output "route53_acn_pvt_zone_id" {
output "route53_vpc_pvt_zone_name" {
output "route53_vpc_pvt_zone_id" {
output "nat_public_ips_primary" {
output "account_short_name" {
output "alb_id" {
output "alb_arn" {
output "alb_dns_name" {
output "alb_zone_id" {
output "alb_alb_sg_id" {

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

