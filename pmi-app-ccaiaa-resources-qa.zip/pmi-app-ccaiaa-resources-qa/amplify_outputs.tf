# Outputs for the caaiaa_agentic_app Amplify app (QA)
# The Jenkins QA pipeline needs the app_id + branch to run start-deployment.

output "amplify_app_id" {
  description = "Amplify app ID (for Jenkins start-deployment)"
  value       = aws_amplify_app.caaiaa_agentic.id
}

output "amplify_app_arn" {
  description = "Amplify app ARN"
  value       = aws_amplify_app.caaiaa_agentic.arn
}

output "amplify_default_domain" {
  description = "Amplify default domain for the app"
  value       = aws_amplify_app.caaiaa_agentic.default_domain
}

output "amplify_branch_name" {
  description = "QA branch name (hosting slot)"
  value       = aws_amplify_branch.qa.branch_name
}

output "amplify_branch_url" {
  description = "QA branch hosted URL (https://<branch>.<default_domain>)"
  value       = "https://${aws_amplify_branch.qa.branch_name}.${aws_amplify_app.caaiaa_agentic.default_domain}"
}
