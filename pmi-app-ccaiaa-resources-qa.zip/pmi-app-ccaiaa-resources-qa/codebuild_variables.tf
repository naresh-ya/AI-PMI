# Variables for the ca-workbench-lambda-build CodeBuild project (QA)

###############################################################################
# Bitbucket credentials (SENSITIVE)
# Set these as SENSITIVE variables in the TFE workspace - NEVER commit real
# values. The buildspec uses them to git clone from source.app.pconnect.biz.
###############################################################################
variable "codebuild_bitbucket_username" {
  description = "Bitbucket username for git clone (set as sensitive TFE var)"
  type        = string
  default     = ""
  sensitive   = true
}

variable "codebuild_bitbucket_token" {
  description = "Bitbucket HTTP access token for git clone (set as sensitive TFE var)"
  type        = string
  default     = ""
  sensitive   = true
}

###############################################################################
# ECR / image settings
###############################################################################
variable "codebuild_ecr_repository_name" {
  description = "ECR repository the build pushes to"
  type        = string
  default     = "ca-lambda-workbench"
}

variable "codebuild_image_tag" {
  description = "Image tag to push"
  type        = string
  default     = "lambda-latest"
}

###############################################################################
# VPC toggle
# false = run with AWS-managed egress (matches dev). Set true to test whether
# an IN-VPC QA CodeBuild can reach Bitbucket (uses baseline subnets + lambda SG).
###############################################################################
variable "codebuild_vpc_enabled" {
  description = "Run CodeBuild inside the VPC. Required for Bitbucket access - the build reaches Bitbucket via private subnets + NAT egress (confirmed working in dev)."
  type        = bool
  default     = true
}

###############################################################################
# Buildspec - clones Bitbucket with embedded credentials (NO_SOURCE pattern).
# Branch/repo match the dev project. Override via TFE if the QA branch differs.
###############################################################################
variable "codebuild_bitbucket_repo_url" {
  description = "Bitbucket repo host/path (without credentials)"
  type        = string
  default     = "source.app.pconnect.biz/scm/ccaiaa/ccaiaa-workbench.git"
}

variable "codebuild_bitbucket_branch" {
  description = "Branch to clone"
  type        = string
  default     = "feature/langsmith-s3-export"
}

variable "codebuild_buildspec" {
  description = "Buildspec YAML. Defaults to the Bitbucket connectivity-test + Docker build from dev."
  type        = string
  default     = <<-EOT
    version: 0.2
    phases:
      install:
        commands:
          - echo "Checking installed tools"
          - git --version
          - docker --version
          - aws --version
          - python3 --version
      pre_build:
        commands:
          - echo "Checking Bitbucket environment variables"
          - echo "BITBUCKET_USERNAME=$BITBUCKET_USERNAME"
          - echo "BITBUCKET_TOKEN length=$${#BITBUCKET_TOKEN}"
          - |
            set -e
            if [ -z "$BITBUCKET_USERNAME" ]; then
              echo "ERROR: BITBUCKET_USERNAME is empty"
              exit 1
            fi
            if [ -z "$BITBUCKET_TOKEN" ]; then
              echo "ERROR: BITBUCKET_TOKEN is empty"
              exit 1
            fi
            export GIT_TERMINAL_PROMPT=0
            # Provide credentials via GIT_ASKPASS (no credentials embedded in the URL,
            # so the repo URL stays clean and avoids secret-in-URL scanners).
            export GIT_USERNAME="$BITBUCKET_USERNAME"
            export GIT_PASSWORD="$BITBUCKET_TOKEN"
            cat > /tmp/git-askpass.sh <<'ASKPASS'
            #!/bin/sh
            case "$1" in
              Username*) printf '%s' "$GIT_USERNAME" ;;
              Password*) printf '%s' "$GIT_PASSWORD" ;;
            esac
            ASKPASS
            chmod +x /tmp/git-askpass.sh
            export GIT_ASKPASS=/tmp/git-askpass.sh
            REPO_URL="https://${"source.app.pconnect.biz/scm/ccaiaa/ccaiaa-workbench.git"}"
            echo "Testing Bitbucket branch access (credentials via GIT_ASKPASS)"
            git ls-remote --heads "$REPO_URL" feature/langsmith-s3-export
            echo "Cloning Bitbucket repository"
            git clone --branch feature/langsmith-s3-export "$REPO_URL" repo
          - echo "Repository cloned successfully"
          - ls -la repo
      build:
        commands:
          - echo "Connectivity test build - repo cloned OK"
      post_build:
        commands:
          - echo "CodeBuild completed"
  EOT
}
