# Amplify - caaiaa_agentic_app (QA)
#
# Captured from the live dev-ca Amplify app (drp6k4av42dyw).
# This is a hosted SPA with NO Git repo connection - the frontend build is
# deployed into it by Jenkins (not Amplify's Git CI). So Terraform only creates
# the app SHELL + the qa branch + the SPA redirect rule. The actual frontend
# package is deployed by the Jenkins pipeline (separate workstream).
#
# The custom_rule is the standard SPA rewrite: any path that is NOT a static
# asset is served /index.html (status 200) so client-side routing works.

resource "aws_amplify_app" "caaiaa_agentic" {
  name     = var.amplify_app_name
  platform = "WEB"

  # SPA redirect rule (matches dev)
  custom_rule {
    source = "</^[^.]+$|\\.(?!(css|gif|ico|jpg|js|png|txt|svg|woff|ttf|map|json)$)([^.]+$)/>"
    target = "/index.html"
    status = "200"
  }

  tags = merge(local.common_tags, { Name = var.amplify_app_name })
}

# QA branch - the hosting slot the Jenkins QA pipeline deploys the build into.
resource "aws_amplify_branch" "qa" {
  app_id      = aws_amplify_app.caaiaa_agentic.id
  branch_name = var.amplify_branch_name
  stage       = "PRODUCTION"

  # Matches dev (auto-build enabled). With no Git repo this has no effect on
  # Jenkins deploys, but kept for parity.
  enable_auto_build = true

  tags = merge(local.common_tags, { Name = "${var.amplify_app_name}-${var.amplify_branch_name}" })
}
