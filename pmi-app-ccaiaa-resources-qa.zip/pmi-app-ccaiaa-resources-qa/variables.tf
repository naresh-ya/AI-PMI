variable "environment" {
  description = "Environment name - e.g. dev/qa/prd/dev1/qa1 etc"
}

variable "environment_family" {
  description = "Environment Family - e.g. dev/qa/prd"
}

variable "name" {
  description = "name of environment"
}

variable "short_name" {
  description = "Short name of the account taken from account creation request"
}

## TFE variables
variable "tfe_org_name" {
  description = "Terraform Enterprise variable"
}

variable "tfe_host_name" {
  description = "Terraform Enterprise variable"
}

variable "role_name" {
  description = "AWS role name to assume"
  default     = "TLZOrgAdmin"
}

variable "account_id" {
  description = "The ID of the working account"
}

variable "owner" {
  description = "owner - this could be a tag"
}

variable "baseline_workspace_name" {
  description = "Baseline workspace to read the outputs"
}

### Tags
variable "tags" {
  description = "A map of tags to add to all resources"
  default     = {}
}

variable "region_primary" {
  default = "eu-west-1"
}

variable "region_secondary" {
  default = "eu-west-2"
}

