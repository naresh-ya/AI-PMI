# Outputs for generic IAM users (QA)
#
# Access key ID + secret are exposed so you can retrieve them ONCE after apply
# (e.g. `terraform output -raw iam_user_access_key_secrets`) and store them
# securely for the pipeline. The secret is sensitive and lives in state.

output "iam_user_names" {
  description = "Map of created IAM user names"
  value       = { for k, u in aws_iam_user.this : k => u.name }
}

output "iam_user_access_key_ids" {
  description = "Map of user => access key ID (AKIA...)"
  value       = { for k, ak in aws_iam_access_key.this : k => ak.id }
}

output "iam_user_access_key_secrets" {
  description = "Map of user => secret access key (retrieve once, store securely)"
  value       = { for k, ak in aws_iam_access_key.this : k => ak.secret }
  sensitive   = true
}
