# Outputs for the ca-workbench-lambda-build CodeBuild project (QA)

output "codebuild_project_name" {
  description = "Name of the CodeBuild project"
  value       = aws_codebuild_project.ca_workbench_lambda_build.name
}

output "codebuild_project_arn" {
  description = "ARN of the CodeBuild project"
  value       = aws_codebuild_project.ca_workbench_lambda_build.arn
}

output "codebuild_service_role_arn" {
  description = "Service role ARN used by the CodeBuild project"
  value       = aws_iam_role.codebuild_ca_workbench.arn
}
