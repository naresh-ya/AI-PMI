# Outputs for DynamoDB tables (Phase 1)
# Exposed so later phases (IAM policies, Lambda env vars) can reference the
# table names/ARNs via remote state instead of hardcoding.

output "dynamodb_table_names" {
  description = "Map of logical name => DynamoDB table name"
  value = {
    hitl                  = aws_dynamodb_table.hitl.name
    knowledge_base        = aws_dynamodb_table.knowledge_base.name
    curated_links         = aws_dynamodb_table.curated_links.name
    policy_updates        = aws_dynamodb_table.policy_updates.name
    policy_updates_output = aws_dynamodb_table.policy_updates_output.name
    users                 = aws_dynamodb_table.users.name
  }
}

output "dynamodb_table_arns" {
  description = "Map of logical name => DynamoDB table ARN"
  value = {
    hitl                  = aws_dynamodb_table.hitl.arn
    knowledge_base        = aws_dynamodb_table.knowledge_base.arn
    curated_links         = aws_dynamodb_table.curated_links.arn
    policy_updates        = aws_dynamodb_table.policy_updates.arn
    policy_updates_output = aws_dynamodb_table.policy_updates_output.arn
    users                 = aws_dynamodb_table.users.arn
  }
}
