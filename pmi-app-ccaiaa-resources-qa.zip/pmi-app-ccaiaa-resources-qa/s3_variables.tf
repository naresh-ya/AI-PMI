# Variables for S3 buckets (Phase 1)
#
# Defaults match the live dev-ca bucket names, kept as-is. Bucket names are
# GLOBALLY unique across all AWS accounts, so if QA cannot reuse a dev name you
# MUST override these (e.g. a -qa suffix / QA account id) in the TFE workspace.

variable "s3_bucket_name_documents" {
  description = "Primary agentic AI documents bucket"
  type        = string
  default     = "pmi-agentic-ai-documents-603433800649-eu-west-1"
}

variable "s3_bucket_name_documents_sandbox" {
  description = "Sandbox/ingestion documents bucket"
  type        = string
  default     = "pmi-agentic-ai-documents-sandbox-603433800649"
}

variable "s3_bucket_name_kb" {
  description = "Knowledge base source bucket"
  type        = string
  default     = "ccaiaa-kb-dev"
}
