# AWS Bedrock Guardrail Configuration Overview  
## PMI Corporate Affairs Chatbot

This document explains the current AWS Bedrock Guardrail script category-wise and lists the additional configuration options available in AWS Bedrock Guardrails.

---

# 1. Current Guardrail Script Overview

The current script creates one AWS Bedrock Guardrail resource using `boto3`.

```python
import boto3

bedrock = boto3.client('bedrock', region_name='us-east-1')

tenant_id = 'YOUR_TENANT_ID'

response = bedrock.create_guardrail(
    name=f"{tenant_id}-pmi-corporate-affairs-v2",
    description="Refined guardrail for PMI Corporate Affairs - allows legitimate research queries",
    ...
)
```

Amazon Bedrock Guardrails can be configured with safeguards such as content filters, denied topics, word filters, sensitive information filters, contextual grounding checks, and custom blocked messages. 【1-829812】【2-79fde2】

---

# 2. Top-Level Guardrail Metadata

## What It Does

Top-level metadata defines the guardrail identity, description, ownership, and governance information.

## Fields Used

| Field | Purpose | Current Script Value |
|---|---|---|
| `name` | Unique guardrail name | `{tenant_id}-pmi-corporate-affairs-v2` |
| `description` | Human-readable purpose of the guardrail | `Refined guardrail for PMI Corporate Affairs - allows legitimate research queries` |
| `tags` | Metadata for ownership, governance, environment, project, compliance, and tracking | Tenant, project, client, environment, team, version, owner |

## Why It Matters

This helps developers, platform teams, security teams, and governance teams identify the guardrail and understand where it is used.

---

# 3. `contentPolicyConfig`

## What It Is

`contentPolicyConfig` defines Bedrock’s built-in harmful content filters.

These filters detect and filter harmful content in user input and model output. Bedrock supports predefined content categories such as `HATE`, `INSULTS`, `SEXUAL`, `VIOLENCE`, `MISCONDUCT`, and `PROMPT_ATTACK`. 【1-829812】【3-86ba44】

---

## Current Script

```python
contentPolicyConfig={
    'filtersConfig': [
        {'type': 'HATE', 'inputStrength': 'HIGH', 'outputStrength': 'HIGH'},
        {'type': 'SEXUAL', 'inputStrength': 'HIGH', 'outputStrength': 'HIGH'},
        {'type': 'VIOLENCE', 'inputStrength': 'MEDIUM', 'outputStrength': 'MEDIUM'},
        {'type': 'INSULTS', 'inputStrength': 'MEDIUM', 'outputStrength': 'MEDIUM'},
        {'type': 'MISCONDUCT', 'inputStrength': 'LOW', 'outputStrength': 'MEDIUM'},
        {'type': 'PROMPT_ATTACK', 'inputStrength': 'MEDIUM', 'outputStrength': 'NONE'}
    ]
}
```

---

## Configuration Explanation

| Filter | Input Strength | Output Strength | Explanation |
|---|---:|---:|---|
| `HATE` | HIGH | HIGH | Strictly blocks hate-related content in user input and model output. |
| `SEXUAL` | HIGH | HIGH | Strictly blocks sexual content in a professional corporate environment. |
| `VIOLENCE` | MEDIUM | MEDIUM | Allows legitimate health, enforcement, and regulatory discussion while blocking stronger violent content. |
| `INSULTS` | MEDIUM | MEDIUM | Allows critical business discussion but blocks abusive or insulting content. |
| `MISCONDUCT` | LOW | MEDIUM | Allows legitimate Corporate Affairs questions about illicit trade, smuggling, sanctions, tax evasion, anti-corruption, and enforcement while keeping generated answers safer. |
| `PROMPT_ATTACK` | MEDIUM | NONE | Detects prompt injection, jailbreak, and instruction override attempts in user input. Output filtering is not required for this category. |

---

## Available Strength Values

Content filter strengths can be configured independently for input and output.

```text
NONE
LOW
MEDIUM
HIGH
```

The API supports `inputStrength` and `outputStrength` values such as `NONE`, `LOW`, `MEDIUM`, and `HIGH`. 【3-86ba44】

---

# 4. `topicPolicyConfig`

## What It Is

`topicPolicyConfig` defines custom denied topics.

These are business-specific topics that should be blocked when detected in user prompts or model responses. Denied topics allow an application to define topics that are undesirable in its specific business context. 【1-829812】【4-6b65a1】

---

## Current Script

```python
topicPolicyConfig={
    'topicsConfig': [
        {
            'name': 'False or Misleading Competitor Claims',
            'definition': 'Making false, misleading, promotional, defamatory, or unsupported claims about competitors. Does NOT block neutral, sourced, factual comparisons.',
            'examples': [
                'Our competitors products are deadly poison',
                'Company X executives are criminals'
            ],
            'type': 'DENY'
        },
        {
            'name': 'Unsubstantiated Safety or Health Benefit Claims',
            'definition': 'Claims that products are safe, risk-free, or disease-preventing unless quoted from approved source. Does NOT block harm reduction or regulatory discussions.',
            'examples': [
                'Our cigarettes are completely safe',
                'Smoking prevents cancer'
            ],
            'type': 'DENY'
        },
        {
            'name': 'Marketing Strategy Targeting Minors',
            'definition': 'Marketing strategies targeting underage individuals. Does NOT block youth prevention policy analysis.',
            'examples': [
                'Create campaign to attract teenagers',
                'Marketing for high school students'
            ],
            'type': 'DENY'
        },
        {
            'name': 'Confidential Business Information',
            'definition': 'Confidential strategies, unreleased products, or proprietary information.',
            'examples': [
                'Share confidential product formula',
                'Internal-only financial projections'
            ],
            'type': 'DENY'
        }
    ]
}
```

---

## Configuration Explanation

| Topic | Type | Purpose |
|---|---|---|
| False or Misleading Competitor Claims | DENY | Blocks false, misleading, defamatory, promotional, or unsupported claims about competitors. |
| Unsubstantiated Safety or Health Benefit Claims | DENY | Blocks unsupported claims that tobacco or nicotine products are safe, risk-free, disease-preventing, or medically beneficial. |
| Marketing Strategy Targeting Minors | DENY | Blocks tobacco or nicotine marketing strategy targeting underage individuals. |
| Confidential Business Information | DENY | Blocks confidential strategy, unreleased products, proprietary research, and internal-only information. |

---

## Topic Fields

| Field | Meaning |
|---|---|
| `name` | Short name of the denied topic. |
| `definition` | Business definition of what should be blocked. |
| `examples` | Example prompts that represent the denied topic. |
| `type` | Topic behavior. In this script, all are set to `DENY`. |

Topics contain fields such as `name`, `definition`, `examples`, and `type`, where `type` specifies the denied topic behavior. 【4-6b65a1】

---

# 5. `sensitiveInformationPolicyConfig`

## What It Is

`sensitiveInformationPolicyConfig` controls PII and sensitive data handling.

Sensitive information filters can block or mask personally identifiable information and other sensitive data in user input and model output. Bedrock supports actions such as `BLOCK` and `ANONYMIZE`. 【1-829812】

---

## Current Script

```python
sensitiveInformationPolicyConfig={
    'piiEntitiesConfig': [
        {'type': 'EMAIL', 'action': 'ANONYMIZE'},
        {'type': 'PHONE', 'action': 'ANONYMIZE'},
        {'type': 'ADDRESS', 'action': 'ANONYMIZE'},

        # NAME intentionally removed to allow public officials, regulators,
        # journalists, executives, researchers, NGOs, and institutions.

        {'type': 'CREDIT_DEBIT_CARD_NUMBER', 'action': 'BLOCK'},
        {'type': 'CREDIT_DEBIT_CARD_CVV', 'action': 'BLOCK'},
        {'type': 'CREDIT_DEBIT_CARD_EXPIRY', 'action': 'BLOCK'},
        {'type': 'US_SOCIAL_SECURITY_NUMBER', 'action': 'BLOCK'},
        {'type': 'US_PASSPORT_NUMBER', 'action': 'BLOCK'},
        {'type': 'DRIVER_ID', 'action': 'BLOCK'},
        {'type': 'US_BANK_ACCOUNT_NUMBER', 'action': 'BLOCK'},
        {'type': 'INTERNATIONAL_BANK_ACCOUNT_NUMBER', 'action': 'BLOCK'},
        {'type': 'SWIFT_CODE', 'action': 'BLOCK'},
        {'type': 'PASSWORD', 'action': 'BLOCK'},
        {'type': 'AWS_ACCESS_KEY', 'action': 'BLOCK'},
        {'type': 'AWS_SECRET_KEY', 'action': 'BLOCK'}
    ]
}
```

---

## Configuration Explanation

| Entity | Action | Explanation |
|---|---|---|
| `EMAIL` | ANONYMIZE | Masks email addresses. |
| `PHONE` | ANONYMIZE | Masks phone numbers. |
| `ADDRESS` | ANONYMIZE | Masks physical addresses. |
| `NAME` | Not configured | Names are allowed because Corporate Affairs needs to reference public officials, regulators, journalists, executives, researchers, NGOs, and institutions. |
| `CREDIT_DEBIT_CARD_NUMBER` | BLOCK | Blocks payment card numbers. |
| `CREDIT_DEBIT_CARD_CVV` | BLOCK | Blocks card security codes. |
| `CREDIT_DEBIT_CARD_EXPIRY` | BLOCK | Blocks card expiry details. |
| `US_SOCIAL_SECURITY_NUMBER` | BLOCK | Blocks US Social Security Numbers. |
| `US_PASSPORT_NUMBER` | BLOCK | Blocks US passport numbers. |
| `DRIVER_ID` | BLOCK | Blocks driver identification numbers. |
| `US_BANK_ACCOUNT_NUMBER` | BLOCK | Blocks US bank account numbers. |
| `INTERNATIONAL_BANK_ACCOUNT_NUMBER` | BLOCK | Blocks international bank account numbers. |
| `SWIFT_CODE` | BLOCK | Blocks banking SWIFT codes. |
| `PASSWORD` | BLOCK | Blocks passwords. |
| `AWS_ACCESS_KEY` | BLOCK | Blocks AWS access keys. |
| `AWS_SECRET_KEY` | BLOCK | Blocks AWS secret keys. |

---

## Supported PII Examples

Bedrock supports many PII entity types, including `ADDRESS`, `AGE`, `AWS_ACCESS_KEY`, `AWS_SECRET_KEY`, `CREDIT_DEBIT_CARD_NUMBER`, `EMAIL`, `NAME`, `PHONE`, `PASSWORD`, `URL`, `US_SOCIAL_SECURITY_NUMBER`, `US_PASSPORT_NUMBER`, and bank-account-related identifiers. 【5-1f6913】

---

# 6. `wordPolicyConfig`

## What It Is

`wordPolicyConfig` controls exact word or phrase blocking and managed word lists.

Word filters can block configured words, phrases, profanity, and custom terms. 【1-829812】【4-6b65a1】

---

## Current Script

```python
wordPolicyConfig={
    'wordsConfig': [
        {'text': 'CONFIDENTIAL-INTERNAL'},
        {'text': 'PMI-PROPRIETARY'},
        {'text': 'ATTORNEY-CLIENT-PRIVILEGED'},
        {'text': 'INTERNAL-USE-ONLY'}
    ],
    'managedWordListsConfig': [
        {'type': 'PROFANITY'}
    ]
}
```

---

## Configuration Explanation

| Word / List | Action | Explanation |
|---|---|---|
| `CONFIDENTIAL-INTERNAL` | BLOCK | Blocks internal confidentiality marker. |
| `PMI-PROPRIETARY` | BLOCK | Blocks PMI proprietary marker. |
| `ATTORNEY-CLIENT-PRIVILEGED` | BLOCK | Blocks legally privileged content marker. |
| `INTERNAL-USE-ONLY` | BLOCK | Blocks internal-use-only marker. |
| `PROFANITY` | BLOCK | Uses AWS managed profanity list. |

---

# 7. Blocked Messages

## What It Is

Blocked messages are the user-facing responses returned when guardrail intervention happens.

Bedrock allows configuring messages returned when a user input or model output violates guardrail policies. 【4-6b65a1】

---

## Current Script

```python
blockedInputMessaging='I cannot process that request. Please rephrase your question or contact the Corporate Affairs team directly for guidance.',

blockedOutputsMessaging='I cannot provide that information. Please consult official PMI resources or contact the Corporate Affairs team.'
```

---

## Configuration Explanation

| Field | Used When | Purpose |
|---|---|---|
| `blockedInputMessaging` | User input is blocked | Shows a safe message when the user asks something that violates the guardrail. |
| `blockedOutputsMessaging` | Model output is blocked | Shows a safe message when the generated response violates the guardrail. |

---

# 8. `tags`

## What It Is

Tags are metadata used for governance, tracking, ownership, compliance, environment separation, and cost attribution.

---

## Current Script

```python
tags=[
    {'key': 'aiplat-tenant', 'value': tenant_id},
    {'key': 'project', 'value': 'pmi-corporate-affairs'},
    {'key': 'itpf-compliant', 'value': 'true'},
    {'key': 'environment', 'value': 'production'},
    {'key': 'client', 'value': 'philip-morris-international'},
    {'key': 'team', 'value': 'corporate-affairs'},
    {'key': 'use-case', 'value': 'chatbot-kb-websearch'},
    {'key': 'version', 'value': 'v2.0-refined'},
    {'key': 'owner', 'value': 'your-email@pmi.com'}
]
```

---

## Configuration Explanation

| Tag | Purpose |
|---|---|
| `aiplat-tenant` | Identifies the AI platform tenant. |
| `project` | Identifies the project. |
| `itpf-compliant` | Marks the guardrail as ITPF-compliant. |
| `environment` | Identifies whether this is production, staging, dev, etc. |
| `client` | Identifies the client. |
| `team` | Identifies the business team. |
| `use-case` | Identifies the chatbot use case. |
| `version` | Tracks guardrail version. |
| `owner` | Identifies the responsible owner. |

---

# 9. Other AWS Bedrock Guardrail Configurations Available

Apart from the configurations currently used in the script, AWS Bedrock Guardrails supports additional configuration options.

---

## 9.1 `contextualGroundingPolicyConfig`

## What It Does

Checks whether the model response is grounded in the provided source and relevant to the user query.

Bedrock contextual grounding checks can evaluate `GROUNDING` and `RELEVANCE` with configurable thresholds. 【1-829812】

## Example

```python
contextualGroundingPolicyConfig={
    'filtersConfig': [
        {'type': 'GROUNDING', 'threshold': 0.7},
        {'type': 'RELEVANCE', 'threshold': 0.7}
    ]
}
```

## When To Use

Useful for RAG-style flows where the model answer should be checked against retrieved source content.

For the PMI chatbot, this is optional because the pipeline already has KB search, web search, and reranking. It can still be added as an extra validation layer if needed.

---

## 9.2 `regexesConfig`

## What It Does

Allows custom regex-based detection for internal IDs, project codes, document labels, or organization-specific confidential patterns.

The CreateGuardrail API supports `regexesConfig` inside `sensitiveInformationPolicyConfig`, with actions such as `BLOCK` and `ANONYMIZE`. 【1-829812】

## Example

```python
sensitiveInformationPolicyConfig={
    'piiEntitiesConfig': [
        ...
    ],
    'regexesConfig': [
        {
            'name': 'PMI Internal Project Code',
            'description': 'Blocks internal PMI project code patterns',
            'pattern': 'PMI-[A-Z]{2,}-[0-9]{3,}',
            'action': 'BLOCK'
        }
    ]
}
```

## When To Use

Useful if PMI has internal project codes, document IDs, legal labels, confidential labels, or proprietary naming patterns that should be blocked.

---

# 10. What We Are Using vs What Else Exists

| Configuration | Used in Current v2 Script? | Purpose |
|---|---:|---|
| `name` | Yes | Guardrail name |
| `description` | Yes | Guardrail description |
| `contentPolicyConfig` | Yes | Built-in harmful content filters |
| `topicPolicyConfig` | Yes | Business-specific denied topics |
| `sensitiveInformationPolicyConfig` | Yes | PII and sensitive data handling |
| `wordPolicyConfig` | Yes | Custom words and profanity |
| `blockedInputMessaging` | Yes | Message when user input is blocked |
| `blockedOutputsMessaging` | Yes | Message when model output is blocked |
| `tags` | Yes | Governance and ownership metadata |
| `regexesConfig` | No | Custom regex-based sensitive data detection |
| `contextualGroundingPolicyConfig` | No | Grounding and relevance checks |
| `kmsKeyId` | No | Customer-managed encryption key |
| `clientRequestToken` | No | Idempotency for create requests |
| `tierConfig` | No | Classic or Standard guardrail tier control |
| `inputAction` / `outputAction` | No | Explicit action control |
| `inputEnabled` / `outputEnabled` | No | Enable or disable filtering per direction |
| `inputModalities` / `outputModalities` | No | Text/image modality control |
| `crossRegionConfig` | No | Cross-region guardrail profile |
| `automatedReasoningPolicyConfig` | No | Automated reasoning policy integration |



