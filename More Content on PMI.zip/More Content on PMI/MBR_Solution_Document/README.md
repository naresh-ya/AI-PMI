# MBR Solution Document generator

Builds `MBR_Solution_Architecture_Reference.docx` from a read-only AWS inventory, the repository findings and four diagrams.

## Re-run

```powershell
aws sso login --profile dev-mbr
Remove-Item Env:AWS_PROFILE -ErrorAction SilentlyContinue
.\.venv\Scripts\python.exe inventory_aws.py      # writes inventory\aws_inventory.json (names only, no secret values)
.\.venv\Scripts\python.exe summarize_inventory.py # optional: inventory\summary.txt
.\.venv\Scripts\python.exe diagrams.py            # writes diagrams\*.png
.\.venv\Scripts\python.exe build_doc.py           # writes the .docx
.\.venv\Scripts\python.exe verify_doc.py          # counts headings, tables, images; checks TOC and secret-like text
```

First time: `python -m venv .venv` then `.\.venv\Scripts\pip install -r requirements.txt`.

In Word, open the file and press F9 (or right-click the table of contents, Update Field) to fill the contents page.

## Files

| File | Role |
|---|---|
| inventory_aws.py | Read-only AWS calls (List/Describe/Get). Never reads env-var values or secret values |
| diagrams.py | Four matplotlib diagrams |
| docx_helpers.py | python-docx helpers (tables, captions, landscape figures, TOC) |
| sec_front.py, sec_arch.py, sec_ai.py, sec_ops.py | Document text. Code-derived facts are written here; live facts come from the inventory JSON |
| build_doc.py | Assembles the document |

Code-derived statements ([Code]) are typed in the `sec_*.py` files. Update them when the repositories change.
