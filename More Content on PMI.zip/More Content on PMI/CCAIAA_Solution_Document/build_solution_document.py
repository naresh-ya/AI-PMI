"""
Builds the CCAIAA Solution & Architecture Reference document (Word .docx)
plus the diagrams it embeds.

Sources: code in the four repos (ccaiaa-agentic-api, ccaiaa-agentic-ui,
ccaiaa-workbench, ccaiaa-dev-platform-deployment) and a read-only inventory
of AWS account 603433800649 (eu-west-1). Run:  python build_solution_document.py
"""
import os
import datetime
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

HERE = os.path.dirname(os.path.abspath(__file__))
IMG = os.path.join(HERE, "diagrams")
os.makedirs(IMG, exist_ok=True)
OUT = os.path.join(HERE, "CCAIAA_Solution_Architecture_Reference.docx")
# Platform mapping diagram: drawn by ../generate_ai_platform_diagram.py. A copy is kept in diagrams/
# so the document still builds if the original is moved.
PLATFORM_PNG = os.path.join(IMG, "00_enterprise_platform_mapping.png")
_platform_src = os.path.join(os.path.dirname(HERE), "Enterprise_AI_Platform_Architecture.png")
if os.path.exists(_platform_src):
    import shutil
    shutil.copyfile(_platform_src, PLATFORM_PNG)

NAVY = "#12355B"
TODAY = datetime.date.today().strftime("%d %B %Y")

# =============================================================================
# DIAGRAMS
# =============================================================================

def _box(ax, x, y, w, h, text, fc, ec="#333333", fs=8.5, bold=False, color="#111111"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.2,rounding_size=0.6",
                                fc=fc, ec=ec, lw=1.1))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
            fontweight="bold" if bold else "normal", color=color, linespacing=1.3)


def _arrow(ax, x1, y1, x2, y2, label="", color="#444444", ls="-", rad=0.0, lx=None, ly=None):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=1.2, linestyle=ls,
                                connectionstyle=f"arc3,rad={rad}"))
    if label:
        ax.text(lx if lx is not None else (x1 + x2) / 2, ly if ly is not None else (y1 + y2) / 2,
                label, fontsize=7, color="#333333", ha="center", va="center", backgroundcolor="white")


def _canvas(w, h, title):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")
    ax.text(50, 97.5, title, ha="center", va="center", fontsize=13, fontweight="bold", color=NAVY)
    return fig, ax


def _save(fig, name):
    path = os.path.join(IMG, name)
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def diagram_context():
    fig, ax = _canvas(15, 10, "CCAIAA - Solution Context (dev, account 603433800649, eu-west-1)")
    # zones
    _box(ax, 1, 77, 98, 16, "", "#F3F7FB", ec="#9DB4CC")
    ax.text(2, 91.5, "USERS & FRONT END", fontsize=8, color="#4A6A8A", fontweight="bold")
    _box(ax, 1, 37, 98, 38, "", "#FFF7EF", ec="#E0B98F")
    ax.text(2, 73.5, "CCAIAA APPLICATION (603433800649)", fontsize=8, color="#9A6A3A", fontweight="bold")
    _box(ax, 1, 1, 98, 34, "", "#F2F8F1", ec="#9CC49A")
    ax.text(2, 3, "PMI GENAI PLATFORM (shared account 767398044071) + external services", fontsize=8, color="#4D7A4A", fontweight="bold")

    _box(ax, 3, 80, 16, 9, "Corporate Affairs users\n(requestors, CA & Legal\nreviewers)", "#FFFFFF")
    _box(ax, 25, 80, 22, 9, "React SPA (ccaiaa-agentic-ui)\nAWS Amplify hosting\napp drp6k4av42dyw", "#DCEBFA", bold=True)
    _box(ax, 53, 80, 18, 9, "Amazon Cognito\nccaiaa-authentication\n(Hosted UI, OAuth code)", "#DCEBFA")
    _box(ax, 77, 80, 20, 9, "Jenkins (CloudBees)\nBitbucket source\nCodeBuild / ECR", "#EEEEEE")
    _arrow(ax, 19, 84.5, 25, 84.5)
    _arrow(ax, 47, 86, 53, 86, "login")

    # API layer
    _box(ax, 3, 61, 30, 9, "API Gateway (HTTP) y97ca45wk1\nrequests, HITL, reviews, uploads\nl0xhkyycki latest-records", "#FBE3DA")
    _box(ax, 35, 61, 30, 9, "API Gateway (REST) p3e6nk579c\ndocuments, compare, signed docs\nx790ajq294 policy updates", "#FBE3DA")
    _box(ax, 67, 61, 30, 9, "API Gateway (REST) cxb47goss9\nCA Workbench chat + drafts\n(conversations, messages, jobs)", "#FBE3DA")
    _arrow(ax, 30, 80, 30, 70)
    _arrow(ax, 42, 80, 42, 70)
    _arrow(ax, 46, 80, 76, 70)

    # compute
    _box(ax, 3, 40, 30, 17, "Request-to-Document workflow\nLambda pmi-api-handler-client-demo1\n-> Step Functions\npmi-research-workflow-client-demo2\n(14 agent Lambdas, 2 HITL gates)", "#F8D6C9", bold=True)
    _box(ax, 35, 48, 30, 9, "Document / signed-docs Lambdas\nHITL interface, presigned uploads", "#F8D6C9")
    _box(ax, 35, 40, 30, 6.5, "DynamoDB + S3 (requests, HITL,\nusers, chats, documents, KB source)", "#FFFFFF")
    _box(ax, 67, 40, 30, 17, "CA Workbench\nProxy Lambda ca-workbench-api-proxy\n-> Bedrock AgentCore Runtime\n(LangGraph orchestrator, ARM64)\n+ AgentCore Memory", "#F8D6C9", bold=True)
    _arrow(ax, 18, 61, 18, 57)
    _arrow(ax, 50, 61, 50, 57)
    _arrow(ax, 82, 61, 82, 57)

    # platform
    _box(ax, 3, 6, 22, 19, "LiteLLM AI Gateway\n(private, per-tenant key)\nchat / rerank / KB retrieve\nTavily search\n+ tenant guardrail", "#D7EBD4", bold=True)
    _box(ax, 27, 6, 22, 19, "Amazon Bedrock models\nClaude Opus / Sonnet / Haiku\nTitan + Cohere embeddings\nCohere Rerank v3.5", "#D7EBD4")
    _box(ax, 51, 6, 22, 19, "Bedrock Knowledge Bases\nEnglish (Titan) WQURRONWPQ\nMultilingual (Cohere) LPMWAHDZS8\nOpenSearch Serverless", "#D7EBD4")
    _box(ax, 75, 6, 22, 19, "External / shared\nLangSmith tracing\nGemini (web fallback)\nSharePoint (MS Graph)\nVault (secrets)", "#EEEEEE")
    _arrow(ax, 14, 40, 14, 25.5, "LLM calls")
    _arrow(ax, 76, 40, 22, 25.5, "LLM calls", lx=68, ly=37.8)
    _arrow(ax, 25, 15.5, 27, 15.5)
    _arrow(ax, 20, 25.5, 60, 25.5, rad=-0.3)
    return _save(fig, "01_solution_context.png")


def diagram_workflow():
    fig, ax = _canvas(15, 11, "Request-to-Document workflow - Step Functions pmi-research-workflow-client-demo2")
    W = 15
    def b(x, y, t, c="#DCEBFA", w=W, h=6.5, bold=False):
        _box(ax, x, y, w, h, t, c, bold=bold, fs=8)

    b(2, 85, "1. InputValidation\nschema + required fields\n+ LLM topic relevance", bold=True)
    b(21, 85, "2. FileProcessor\n(only if a file was\nuploaded)", "#EEEEEE")
    b(40, 85, "3. Planner\nresearch plan + queries", bold=True)
    _arrow(ax, 17, 88, 21, 88)
    _arrow(ax, 36, 88, 40, 88)
    _box(ax, 59, 72, 39, 20, "", "#FFF7EF", ec="#E0B98F")
    ax.text(60, 90.5, "4. ParallelResearch (branch order fixed: KB, Web, User, Curated)", fontsize=7.5, color="#9A6A3A", fontweight="bold")
    b(60, 81, "KB search\n(Bedrock KB via gateway)", "#FBE3DA", w=18.5)
    b(79, 81, "Web search\n(Tavily via gateway)", "#FBE3DA", w=18.5)
    b(60, 73.5, "User sources\n(files + URLs)", "#FBE3DA", w=18.5)
    b(79, 73.5, "Curated links\n(DynamoDB list)", "#FBE3DA", w=18.5)
    _arrow(ax, 55, 88, 59, 85)
    b(40, 62, "5. Synthesis\nmerge, rerank, summarise\nresearch_data.json -> S3", bold=True)
    _arrow(ax, 70, 72, 52, 68.5)

    _box(ax, 2, 47, 34, 20, "", "#F2F8F1", ec="#9CC49A")
    ax.text(3, 65.5, "HITL gate 1 - research review (if enable_hitl)", fontsize=7.5, color="#4D7A4A", fontweight="bold")
    b(3, 53, "HITLResearchGate\nwaitForTaskToken\n(up to 14 days)", "#D7EBD4", w=14)
    b(21, 53, "ReResearch\nselective re-run\n(max 3 cycles)", "#D7EBD4", w=14)
    _arrow(ax, 40, 65, 36, 60)
    _arrow(ax, 12, 59.5, 26, 59.5, "revise", rad=-0.45, lx=19, ly=62.6)
    _arrow(ax, 26, 53, 12, 53, "loop back", rad=-0.45, lx=19, ly=49.6)

    b(40, 40, "6. DraftPlanner\ndocument structure\n+ source exclusions", bold=True)
    b(59, 40, "7. DraftGenerator\nsection-by-section\n+ dedup review", bold=True)
    b(78, 40, "8. DraftAssembler\ntranslate + .docx\n-> S3", bold=True)
    _arrow(ax, 36, 52, 40, 45, "approve", lx=41.5, ly=50)
    _arrow(ax, 55, 43, 59, 43)
    _arrow(ax, 74, 43, 78, 43)

    _box(ax, 40, 15, 58, 20, "", "#F2F8F1", ec="#9CC49A")
    ax.text(41, 33.2, "HITL gate 2 - draft review (if enable_hitl)", fontsize=7.5, color="#4D7A4A", fontweight="bold")
    b(79, 24, "DraftHITLGate\nwaitForTaskToken", "#D7EBD4", w=17)
    b(59, 24, "Document\nGenerationSuccess", "#C8E6C9", w=15, bold=True)
    b(42, 24, "ReDraft (no cap)\nselective re-draft\n-> back to gate", "#D7EBD4", w=14)
    _arrow(ax, 87, 40, 87, 30.5)
    _arrow(ax, 79, 27.5, 74, 27.5)
    ax.text(76.5, 31.2, "approve", fontsize=7, ha="center", color="#333333")
    _arrow(ax, 85, 24, 49, 24, "revise", rad=-0.35, lx=67, ly=18.7)

    _box(ax, 2, 18, 34, 26, "Downstream (outside the state machine)\n\nRequestor assigns CA reviewers\n(Scientific, Regulatory,\nCommunication, Fiscal) and Legal\n-> reviewer decisions via API\n-> REVIEW_CHANGES_REQUESTED\n-> accept (legal re-draft) or reject\n-> COMPLETED", "#EEEEEE", fs=8)
    ax.text(50, 10, "Every task: Lambda retries with back-off, timeout, and Catch -> named Fail state "
            "(ValidationFailed, PlannerFailed, SynthesisFailed, DraftingFailed).\n"
            "A failed research branch returns an empty result instead of failing the run. "
            "Reject at either gate -> RequestCancelled.", ha="center", fontsize=8, color="#444444")
    return _save(fig, "02_research_workflow.png")


def diagram_workbench():
    fig, ax = _canvas(15, 9, "CA Workbench - asynchronous chat on AgentCore + LangGraph")
    _box(ax, 2, 78, 14, 9, "UI (AskCA)\nPOST /messages\npoll GET /jobs/{id}", "#DCEBFA", fs=8)
    _box(ax, 20, 78, 18, 9, "Proxy Lambda\nsaves message + job\n(DynamoDB, S3)\nreturns 202 job_id", "#FBE3DA", fs=8)
    _box(ax, 42, 78, 18, 9, "AgentCore Runtime\nFastAPI /invocations\nbackground task", "#FBE3DA", fs=8, bold=True)
    _arrow(ax, 16, 82.5, 20, 82.5)
    _arrow(ax, 38, 82.5, 42, 82.5, "invoke")
    _box(ax, 64, 78, 34, 9, "Result written back:\nChatMessages (preview) + S3 (full text)\nChatJobs status COMPLETED / FAILED", "#EEEEEE", fs=8)
    _arrow(ax, 60, 82.5, 64, 82.5)

    _box(ax, 2, 6, 96, 66, "", "#FFF7EF", ec="#E0B98F")
    ax.text(3, 70.5, "LangGraph orchestrator (memory_aware_graph.py)", fontsize=8, color="#9A6A3A", fontweight="bold")
    _box(ax, 5, 56, 18, 9, "memory_retrieval\nAgentCore Memory:\nshort-term, facts,\npreferences, summaries", "#DCEBFA", fs=7.5)
    _box(ax, 28, 56, 20, 9, "planner (Claude Opus)\nPrompt Mgmt 6SXZARKDW9\nintent + research query", "#DCEBFA", fs=7.5, bold=True)
    _box(ax, 53, 56, 20, 9, "memory_context_selection\npicks memory types\nper planner scope", "#DCEBFA", fs=7.5)
    _box(ax, 78, 56, 18, 9, "planner_error_response\n(controlled failure)", "#F8D6C9", fs=7.5)
    _arrow(ax, 23, 60.5, 28, 60.5)
    _arrow(ax, 48, 60.5, 53, 60.5)
    _arrow(ax, 40, 65, 86, 65, "on error", rad=-0.18, lx=63, ly=68.6)

    _box(ax, 5, 33, 60, 17, "", "#FFFFFF", ec="#BBBBBB")
    ax.text(6, 48.5, "Research tools in parallel (only when requires_research = true)", fontsize=7.5, color="#555555")
    _box(ax, 7, 36, 18, 10, "web_search\nTavily -> Scrapling\n-> Gemini fallback", "#FBE3DA", fs=7.5)
    _box(ax, 27, 36, 18, 10, "kb_retrieval\nBedrock KB hybrid\ntheme filters", "#FBE3DA", fs=7.5)
    _box(ax, 47, 36, 16, 10, "curated_processor\n(stub - 'coming\nsoon')", "#EEEEEE", fs=7.5)
    _arrow(ax, 58, 56, 40, 50, "research")
    _box(ax, 5, 9, 27, 17, "Intent routing\n\nnew_question -> fresh research\nfollowup_research -> memory\n   + new research\nfollowup_format_only -> reformat\n   previous answer (no tools)", "#EEEEEE", fs=7.5)

    _box(ax, 68, 11, 28, 14, "synthesis_node (Claude Sonnet)\nPrompt Mgmt 26AXASKSFB\n[Source N] citations\n+ deterministic Sources list", "#DCEBFA", fs=7.5, bold=True)
    _box(ax, 37, 11, 25, 14, "memory_storage\nwrites user + assistant\nturn to AgentCore Memory\n(long-term extraction automatic)", "#DCEBFA", fs=7.5)
    _arrow(ax, 50, 33, 72, 25, "aggregate", lx=57, ly=30.5)
    _arrow(ax, 68, 18, 62, 18)
    _arrow(ax, 71, 56, 71, 25, "no research", lx=71, ly=42)
    return _save(fig, "03_workbench_langgraph.png")


def diagram_kb():
    fig, ax = _canvas(15, 6.5, "Knowledge pipeline - SharePoint to Bedrock Knowledge Base to retrieval")
    steps = [
        ("SharePoint\n(MS Graph API)\nCA artefacts library", "#EEEEEE"),
        ("Ingestion Lambda\npmi-sharepoint-ingestion\nfile filter + S3 metadata", "#FBE3DA"),
        ("S3 bucket\nsharepoint/<site>/<file>\n(+ ccaiaa-kb-dev)", "#FFFFFF"),
        ("KB builder Lambda\nLLM classifier ->\ntheme / jurisdiction /\nlanguage .metadata.json", "#FBE3DA"),
        ("Bedrock KB ingestion\nchunk + embed\n(Titan / Cohere)\nOpenSearch Serverless", "#D7EBD4"),
        ("Retrieval\nhybrid search + metadata\nfilters + Cohere rerank\nvia LiteLLM gateway", "#D7EBD4"),
    ]
    x = 1.5
    for i, (t, c) in enumerate(steps):
        _box(ax, x, 50, 14.5, 30, t, c, fs=8, bold=(i in (3, 5)))
        if i < len(steps) - 1:
            _arrow(ax, x + 14.5, 65, x + 16.5, 65)
        x += 16.5
    _box(ax, 51, 12, 30, 22, "Failure path: EventBridge on ingestion\njob completion -> sync-failure handler\nmoves failed files + metadata to\nException_docs/", "#F8D6C9", fs=8)
    _arrow(ax, 72, 50, 68, 34)
    _box(ax, 4, 12, 40, 22, "Two KBs queried in parallel for every request:\nEnglish (Titan v2, 1024-d) and Multilingual\n(Cohere embed-multilingual-v3). Scores are not\ncomparable, so merged results are reranked.", "#EEEEEE", fs=8)
    return _save(fig, "04_knowledge_pipeline.png")


# =============================================================================
# WORD HELPERS
# =============================================================================

def set_cell_bg(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color.replace("#", ""))
    tcPr.append(shd)


def table(doc, header, rows, widths=None, font=8.5):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        r = c.paragraphs[0].add_run(h)
        r.bold = True
        r.font.size = Pt(font)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_bg(c, NAVY)
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            run = p.add_run(str(v))
            run.font.size = Pt(font)
            if ri % 2 == 1:
                set_cell_bg(cells[i], "#F2F5F9")
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Cm(w)
    doc.add_paragraph()
    return t


def para(doc, text, bold=False, italic=False, size=10, color=None, space_after=4):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    r.italic = italic
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor.from_string(color.replace("#", ""))
    p.paragraph_format.space_after = Pt(space_after)
    return p


def bullets(doc, items, style="List Bullet"):
    for it in items:
        p = doc.add_paragraph(style=style)
        if isinstance(it, tuple):
            r = p.add_run(it[0])
            r.bold = True
            p.add_run(" " + it[1])
        else:
            p.add_run(it)
        p.paragraph_format.space_after = Pt(2)


def figure(doc, path, caption, width_cm=16.5):
    if os.path.exists(path):
        doc.add_picture(path, width=Cm(width_cm))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        c = para(doc, caption, italic=True, size=8.5, color="#555555")
        c.alignment = WD_ALIGN_PARAGRAPH.CENTER


def note(doc, text):
    t = doc.add_table(rows=1, cols=1)
    t.style = "Table Grid"
    c = t.rows[0].cells[0]
    set_cell_bg(c, "#FFF4E5")
    c.text = ""
    r = c.paragraphs[0].add_run(text)
    r.font.size = Pt(9)
    doc.add_paragraph()


def add_toc(doc):
    p = doc.add_paragraph()
    run = p.add_run()
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), 'TOC \\o "1-2" \\h \\z \\u')
    r = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = "Right-click here and choose 'Update Field' to build the table of contents."
    r.append(t)
    fld.append(r)
    run._r.append(fld)


# =============================================================================
# DOCUMENT CONTENT
# =============================================================================

def build():
    d1, d2, d3, d4 = diagram_context(), diagram_workflow(), diagram_workbench(), diagram_kb()

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(10)
    for s, sz in (("Heading 1", 16), ("Heading 2", 13), ("Heading 3", 11)):
        doc.styles[s].font.color.rgb = RGBColor(0x12, 0x35, 0x5B)
        doc.styles[s].font.size = Pt(sz)
    for sec in doc.sections:
        sec.left_margin = sec.right_margin = Cm(2)
        sec.top_margin = sec.bottom_margin = Cm(1.8)

    # ---------------------------------------------------------------- cover
    for _ in range(5):
        doc.add_paragraph()
    t = para(doc, "CCAIAA", bold=True, size=34, color=NAVY)
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t = para(doc, "Corporate Affairs Agentic AI Assistant", bold=True, size=20, color=NAVY)
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t = para(doc, "Solution & Architecture Reference", size=16, color="#B5472B")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph()
    t = para(doc, "Requirements  |  Architecture  |  Agents & Prompts  |  Guardrails  |  AWS Services  |  "
                  "Data  |  Security  |  CI/CD  |  Operations  |  Risks", size=10, color="#555555")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for _ in range(8):
        doc.add_paragraph()
    table(doc, ["Item", "Value"], [
        ["Document version", "1.0 (draft for review)"],
        ["Date", TODAY],
        ["Scope", "dev environment - AWS account 603433800649 (eu-west-1) and the PMI GenAI platform tenant ccaiaa-dev"],
        ["Repositories", "ccaiaa-agentic-api, ccaiaa-agentic-ui, ccaiaa-workbench, ccaiaa-dev-platform-deployment (Bitbucket, project CCAIAA)"],
        ["Audience", "Business stakeholders, architects, engineers, security and operations"],
        ["Classification", "PMI internal"],
    ], widths=[4, 13])
    doc.add_page_break()

    # ------------------------------------------------------------ how to read
    doc.add_heading("How to read this document", 1)
    para(doc, "Sections 1-3 are written for business stakeholders. Sections 4 onwards are technical. "
              "Section 13 lists the gaps and recommended actions in priority order.")
    para(doc, "Every technical fact was taken from one of three sources. Where it matters, the source is marked:", bold=True)
    table(doc, ["Marker", "Meaning"], [
        ["[Live]", "Confirmed by a read-only call against AWS account 603433800649 when this document was written."],
        ["[Code]", "Read in the source code of one of the four repositories."],
        ["[Inferred]", "Concluded from code or naming, but not confirmed. Verify before relying on it."],
    ], widths=[3, 14])
    note(doc, "This is a snapshot. The project is under active development, and several parallel generations of the "
              "code are deployed at once (see section 10.4). Model names, prompt versions and counts will change. "
              "Re-run build_solution_document.py and the inventory commands to refresh it.")
    doc.add_heading("Contents", 2)
    add_toc(doc)
    doc.add_page_break()

    # --------------------------------------------------------------- 1. exec
    doc.add_heading("1. Executive summary", 1)
    para(doc, "CCAIAA is PMI's Corporate Affairs agentic AI assistant. It helps Corporate Affairs teams produce "
              "regulatory and public-policy documents faster, with sources, and with human review built in.")
    para(doc, "It has two user-facing capabilities:", bold=True)
    bullets(doc, [
        ("Request-to-Document workflow.", "A user describes a document they need (for example a submission to a "
         "regulator in Thailand on heated tobacco products). A pipeline of AI agents validates the request, "
         "researches it across the PMI knowledge base, the web, the user's own files and a curated link list, and "
         "drafts a Word document. People approve the research and the draft at two checkpoints. CA and Legal "
         "reviewers then sign it off."),
        ("CA Workbench.", "A research chat assistant. Users ask questions and get answers grounded in the knowledge "
         "base and the web, with numbered citations. It remembers the conversation and learns user preferences over time. "
         "It can also generate a draft document from the chat."),
    ])
    para(doc, "Supporting capabilities: a signed/official document library, a policy-intelligence feed, and a "
              "pipeline that pulls PMI documents from SharePoint into the knowledge base.")
    para(doc, "How it is built, in one paragraph:", bold=True)
    para(doc, "A React web app on AWS Amplify, signed in through Amazon Cognito, calls API Gateway endpoints backed by "
              "AWS Lambda. Document requests run as an AWS Step Functions workflow of 14 agent Lambdas. The Workbench "
              "runs a LangGraph agent inside Amazon Bedrock AgentCore. All large-language-model calls, knowledge-base "
              "retrieval, reranking and web search go through PMI's shared GenAI platform: a LiteLLM gateway in front "
              "of Amazon Bedrock (Claude, Titan, Cohere) with a tenant guardrail. Prompts are managed centrally in "
              "Amazon Bedrock Prompt Management (44 prompts). Data lives in DynamoDB and S3.")
    para(doc, "Current state and the main gaps:", bold=True)
    bullets(doc, [
        "The dev environment is working end to end. Recent Step Functions runs succeed. QA is being set up "
        "(the front-end QA pipeline is built). PROD does not exist yet.",
        "The most important gap: none of the APIs has an authorizer [Live]. User identity is taken from "
        "values the browser sends. This must be fixed before QA or PROD holds real data.",
        "Other gaps: no infrastructure-as-code for the live deployment, hard-coded dev endpoints in the UI, "
        "logging switched off on the workflows, no automated tests, and several deployed generations of the "
        "same Lambdas. Section 13 gives the prioritised list.",
    ])
    doc.add_page_break()

    # --------------------------------------------------------- 2. business
    doc.add_heading("2. Business context and requirements", 1)
    doc.add_heading("2.1 Problem and goal", 2)
    para(doc, "Corporate Affairs teams write formal, regulated documents for governments, regulators, media and "
              "internal audiences. Each needs current research on regulation in a specific country, accurate "
              "citations, a consistent PMI tone, and sign-off from several reviewers. Doing this by hand is slow and "
              "uneven. CCAIAA automates the research and first draft, and keeps people in control of every decision "
              "that matters.")
    doc.add_heading("2.2 Users and roles", 2)
    table(doc, ["Role", "What they do in CCAIAA", "Where in the UI"], [
        ["Requestor (CA user)", "Creates requests, reviews research and drafts, assigns reviewers, accepts or "
         "rejects requested changes, uses the Workbench chat", "Dashboard, New Request, Request Detail, CA Workbench"],
        ["CA reviewers - Scientific, Regulatory, Communication, Fiscal",
         "Review the final draft in their area; mark 'no review required' or 'changes requested'", "Approvals queue"],
        ["Legal reviewer", "Legal review and approval of the final draft", "Approvals queue"],
        ["Regional focal point", "Regional review step (status REGIONAL_FP_REVIEW_PENDING) [Code]", "Approvals queue"],
        ["Admin / system-admin", "Sees all users' requests in the list API (role in table pmi-agentic-ai-users) [Code]", "Dashboard"],
    ], widths=[4, 8.5, 4.5])
    para(doc, "Reviewer roles in the UI are numeric codes: 1001 user, 1003 scientific, 1004 regulatory, "
              "1005 communication, 1006 fiscal, 1007 legal [Code]. They are not yet driven by Cognito groups (see 11.2).",
         italic=True, size=9)

    doc.add_heading("2.3 Functional requirements (as implemented)", 2)
    table(doc, ["ID", "Requirement", "Implemented by"], [
        ["FR-01", "Create a document request with category, topic, jurisdiction, audience, deadline, background, "
         "stakeholders, sources, URLs and uploaded files", "NewRequest 4-step wizard; POST /requests"],
        ["FR-02", "Reject incomplete or off-topic requests", "Input Validator agent (schema, required fields, LLM relevance check)"],
        ["FR-03", "Detect duplicate requests, with an option to bypass", "create-request handler (ENABLE_DUPLICATE_CHECK) [Code]"],
        ["FR-04", "Research the topic across 4 sources in parallel: PMI knowledge base, web, user files/URLs, curated links",
         "ParallelResearch state, 4 research Lambdas"],
        ["FR-05", "Let the requestor approve, revise (with feedback) or reject the research, and exclude sources",
         "HITL gate 1 + HITLResearchReview screen"],
        ["FR-06", "Draft a Word document following a category template and jurisdiction rules, in the requested language",
         "DraftPlanner, DraftGenerator, DraftAssembler (translate + .docx)"],
        ["FR-07", "Let the requestor approve, revise or reject the draft; compare versions", "HITL gate 2, ReDraft, /documents/compare"],
        ["FR-08", "Route the final draft to CA and Legal reviewers and collect decisions", "Reviews API, HITLFinalReview, Approvals"],
        ["FR-09", "Incorporate reviewer changes (legal re-draft) or close the request", "/legal-redraft, /complete"],
        ["FR-10", "Track status of every request on a dashboard", "GET /requests/latest, ~40 status values"],
        ["FR-11", "Research chat with citations, conversation history and memory", "CA Workbench (AgentCore + LangGraph)"],
        ["FR-12", "Generate a draft document from the Workbench", "/chat/draft-form-check, /chat/generate-draft"],
        ["FR-13", "Store and retrieve signed/official documents", "Signed Documents page + API"],
        ["FR-14", "Keep the knowledge base in sync with SharePoint and classify documents by theme, jurisdiction and language",
         "Ingestion + KB builder Lambdas"],
        ["FR-15", "Show a policy-intelligence feed", "pmi-agentic-ai-policy-updates (not analysed in detail)"],
    ], widths=[1.6, 9.5, 5.9])

    doc.add_heading("2.4 Document categories", 2)
    para(doc, "Six categories are supported. Each has its own template, a researcher prompt and a drafter prompt [Code, Live]:")
    table(doc, ["Category", "Typical use", "Category-specific fields"], [
        ["Official PMI Submission", "Formal submission from PMI to a government or regulator", "addressed_to, cc_to, annexure"],
        ["Third Party Submission", "Submission prepared for or with a third party", "addressed_to, cc_to"],
        ["White Papers", "Long-form position paper (template targets ~2,600 words)", "target_audience"],
        ["Internal Communications", "Communication to PMI internal audiences", "target_audience"],
        ["Media Releases", "Press release / media statement", "target_audience"],
        ["Narrative Builder", "Narrative and key messages on a topic", "target_audience"],
    ], widths=[4.5, 8, 4.5])
    doc.add_heading("2.5 Jurisdictions", 2)
    para(doc, "Jurisdiction rules ('regulatory ground truth': who regulates what, what claims are allowed) exist for "
              "India, Thailand, Vietnam, Bangladesh, Bhutan and Nepal as both code templates and Bedrock prompts "
              "[Code, Live]. Maldives and Cambodia have in-code context only. Example rule: in Thailand, the Thai FDA "
              "does not regulate heated tobacco products [Code].")
    doc.add_heading("2.6 Non-functional requirements and current position", 2)
    table(doc, ["Area", "Expectation", "Current position"], [
        ["Accuracy", "Grounded, cited content; no invented facts", "Citations enforced in synthesis; grounding-audit prompt exists; humans approve at 2 gates"],
        ["Compliance", "Formal, neutral, non-promotional tone; regulatory correctness",
         "Default tone in request schema; shared quality rules prompt; jurisdiction rules; CA + Legal review"],
        ["Safety", "Block harmful content, PII leakage, prompt attacks", "LiteLLM tenant guardrail on the gateway path; see section 7"],
        ["Latency", "Research in minutes, not hours", "Research budget 180 s; Lambda timeouts up to 900 s; HITL waits up to 14 days"],
        ["Availability", "Business-hours internal tool", "Serverless, no single server; no formal SLA defined"],
        ["Security", "Only authenticated PMI users; least privilege", "Cognito login exists, but APIs have no authorizer [Live] - gap"],
        ["Auditability", "Who did what, and on which sources", "HITL records and status history in DynamoDB; LangSmith traces; SFN logging OFF - gap"],
        ["Cost", "Visible per tenant", "Platform Cost API + cost reports; direct Bedrock calls billed in tenant account"],
    ], widths=[2.8, 6, 8.2])
    doc.add_page_break()

    # ------------------------------------------------------- 3. overview
    doc.add_heading("3. Solution overview", 1)
    figure(doc, d1, "Figure 1 - Solution context. Arrows show the main call paths.")
    doc.add_heading("3.1 End-to-end user journey (document request)", 2)
    bullets(doc, [
        "Sign in through the PMI Cognito Hosted UI.",
        "Create a request in the 4-step wizard (category, details, context, review) and optionally upload files.",
        "The workflow validates the request. Off-topic requests are cancelled with a reason.",
        "Research runs in parallel and is synthesised into a source list and summary.",
        "Research review: approve, ask for changes (up to 3 automatic re-research cycles), or reject.",
        "The draft is planned, written section by section, translated if needed and saved as .docx.",
        "Draft review: approve, ask for changes (re-draft), or reject. Versions can be compared.",
        "The requestor assigns CA and Legal reviewers. Reviewers approve or request changes.",
        "The requestor accepts the changes (legal re-draft) or closes the request. Status becomes COMPLETED.",
    ], style="List Number")
    doc.add_heading("3.2 The two runtimes and why they differ", 2)
    table(doc, ["", "Request-to-Document", "CA Workbench"], [
        ["Interaction", "Long-running job with human approvals", "Conversational, answer in under a few minutes"],
        ["Orchestration", "AWS Step Functions (Standard)", "LangGraph inside Bedrock AgentCore Runtime"],
        ["Compute", "14 Lambda functions (container images)", "One ARM64 container (FastAPI + LangGraph)"],
        ["State", "DynamoDB request + HITL records, S3 artefacts", "DynamoDB chats/jobs + S3 + AgentCore Memory"],
        ["Human in the loop", "Two task-token gates + reviewer workflow", "None (the user is in the conversation)"],
        ["Output", "Word document", "Markdown answer with citations (optional draft)"],
    ], widths=[3, 7, 7])
    para(doc, "Step Functions fits the document flow because it can pause for days at a human gate without paying for "
              "idle compute, and gives each step retries and a visual history. AgentCore fits the chat because it "
              "keeps a warm session and has built-in conversation memory.")
    doc.add_page_break()

    # --------------------------------------------------- 4. architecture
    doc.add_heading("4. Architecture", 1)
    doc.add_heading("4.1 Layered view", 2)
    table(doc, ["Layer", "CCAIAA components"], [
        ["Experience", "React 18 SPA (Vite, Tailwind) on Amplify; Cognito Hosted UI"],
        ["API", "API Gateway: 4 HTTP APIs and 3 REST APIs used by the UI [Live]"],
        ["Orchestration", "Step Functions pmi-research-workflow-client-demo2; LangGraph graph in AgentCore"],
        ["Agents", "14 workflow Lambdas; Workbench planner, tools and synthesizer nodes"],
        ["Knowledge", "2 Bedrock KBs (English Titan, Multilingual Cohere) on OpenSearch Serverless; SharePoint ingestion"],
        ["AI gateway", "PMI LiteLLM gateway (private): chat, rerank, KB retrieve, Tavily; tenant guardrail"],
        ["Models", "Bedrock Claude Opus / Sonnet / Haiku, Titan and Cohere embeddings, Cohere Rerank v3.5; Gemini for web fallback"],
        ["Prompts", "Bedrock Prompt Management (44 prompts) with in-code fallback"],
        ["Data", "DynamoDB (requests, HITL, users, curated links, chats, jobs), S3 (documents, KB source, chat content)"],
        ["Observability", "LangSmith tracing (daily export to S3), CloudWatch Logs"],
        ["Delivery", "Bitbucket, Jenkins (UI to Amplify), CodeBuild + ECR (containers), Python deploy scripts (Lambdas)"],
    ], widths=[3.2, 13.8])
    doc.add_heading("4.2 Accounts and environments", 2)
    table(doc, ["Account", "ID", "Role"], [
        ["CCAIAA dev (tenant)", "603433800649", "All CCAIAA application resources described here"],
        ["PMI GenAI platform", "767398044071", "LiteLLM gateway, Management API, guardrails, platform KBs, tenant roles"],
        ["CCAIAA QA", "793012896927", "QA environment - front-end pipeline being built (Amplify app d10bktbssu5hye)"],
        ["CCAIAA PROD", "685053544341", "Not yet built"],
    ], widths=[4, 3, 10])
    doc.add_heading("4.3 Relationship with the PMI GenAI platform", 2)
    para(doc, "CCAIAA is a tenant (ccaiaa-dev) of the shared PMI GenAI platform. The platform gives CCAIAA governed "
              "access to models, guardrails, knowledge bases and web search, and reports cost per tenant. Three "
              "credentials are involved:")
    table(doc, ["Credential", "Used for", "Source"], [
        ["LiteLLM API key", "Every LLM, rerank, KB-retrieve and Tavily call made by the agents", "Vault genai-dev/litellm/ccaiaa-dev"],
        ["OAuth2 client credentials", "Platform Management API: create/sync KBs, register and attach guardrails", "Vault static-secret/genai-dev/custom-api/ccaiaa-dev"],
        ["Direct-access IAM role", "Engineers calling Bedrock in the platform account (e.g. guardrail scripts)", "SSO -> tenant-ccaiaa-dev-direct-access"],
    ], widths=[4, 8, 5])
    figure(doc, PLATFORM_PNG, "Figure 2 - Enterprise AI platform reference layers mapped to the PMI platform.")
    doc.add_page_break()

    # ------------------------------------------------------ 5. workflow
    doc.add_heading("5. Request-to-Document workflow (agents)", 1)
    figure(doc, d2, "Figure 3 - The live state machine pmi-research-workflow-client-demo2 [Live].")
    para(doc, "The UI calls POST /requests on API y97ca45wk1. That route invokes pmi-api-handler-client-demo1, which "
              "writes the request to DynamoDB and starts the state machine above [Live]. Each state is a Lambda "
              "(the -dev container-image functions) [Live].")
    doc.add_heading("5.1 Agent catalogue", 2)
    table(doc, ["#", "Agent (Lambda)", "What it does", "Models / services", "Key settings"], [
        ["1", "Input Validator\npmi-input-validator-dev",
         "Pydantic schema check; required-field check (VALIDATION_FAILED); LLM check that the topic is in the corporate "
         "affairs / policy / tobacco-regulation domain (CANCELLED 'Irrelevant topic'); priority, complexity, "
         "document_requirements; valid-till = +5 years",
         "LiteLLM chat; prompt ccaiaa-validator-topic-relevance; DynamoDB",
         "temperature 0, 512 tokens, 15 s timeout; can be disabled per request"],
        ["2", "File Processor\npmi-research-file-processor-dev",
         "Reads and summarises an uploaded file so the planner has its facts, structure and intent. Runs only when a file key exists",
         "LiteLLM; prompt ccaiaa-file-processor-summarizer; S3", "Failure falls back to the plain planner"],
        ["3", "Planner\npmi-research-planner-dev",
         "Builds the research strategy and the queries for each source", "LiteLLM (Claude)", "180 s timeout"],
        ["4a", "KB Search\npmi-research-kb-search-dev",
         "Queries the English and Multilingual KBs in parallel, merges and reranks; theme and jurisdiction filters",
         "LiteLLM KB retrieve + /rerank; prompts ccaiaa-kb-*", "rerank top 10; HYBRID search"],
        ["4b", "Web Search\npmi-research-web-search-dev", "Tavily web search through the gateway, page extraction and summarisation",
         "LiteLLM Tavily route; prompts ccaiaa-web-*", "870 s timeout"],
        ["4c", "User Sources\npmi-research-user-sources-dev", "Processes the user's uploaded files and external URLs", "S3, HTTP fetch", "300 s timeout"],
        ["4d", "Curated Links\npmi-research-curated-links-dev", "Fetches the curated internal link list", "DynamoDB pmi-agentic-ai-curated-links", "600 s timeout"],
        ["5", "Synthesis\npmi-research-synthesis-dev",
         "Aggregates the 4 branches, ranks top-k, writes the research summary; saves research_data.json to S3; status RESEARCH_COMPLETED",
         "LiteLLM (Claude); category researcher prompt + shared quality rules", "research budget 180 s"],
        ["6", "HITL Gate\npmi-hitl-gate-dev", "Stores the task token, creates the HITL record, sets *_REVIEW_PENDING, pauses the workflow",
         "DynamoDB pmi-agentic-ai-hitl", "waits up to 14 days"],
        ["7", "Re-Research\npmi-research-reresearch-dev", "Reads the reviewer's feedback, re-runs only the stages that need it, merges with approved sources",
         "LiteLLM; prompt ccaiaa-reresearch-intent-classifier", "confidence 0.7, max 3 cycles"],
        ["8", "Draft Planner\npmi-draft-planner-dev", "Loads research, builds the document structure from the category template, applies source exclusions",
         "LiteLLM; prompts ccaiaa-planner-document-architect, ccaiaa-template-*", "300 s"],
        ["9", "Draft Generator\npmi-draft-generator-dev", "Writes sections one after another, then an internal review/dedup pass; letters in a single call",
         "LiteLLM; category drafter prompt, ccaiaa-generator-dedup-refinement, jurisdiction prompts", "DRAFT_WAVE_SIZE 1; 870 s"],
        ["10", "Draft Assembler\npmi-draft-assembler-dev", "Translates if requested, formats the .docx, stores it in S3, sets DRAFTING_COMPLETED",
         "LiteLLM; prompts ccaiaa-translator-system, ccaiaa-assembler-grounding-audit; S3", "600 s"],
        ["11", "Re-Draft\npmi-draft-redraft-dev", "Selective re-draft based on the intent of the reviewer's feedback; also used for the legal re-draft",
         "LiteLLM; prompt ccaiaa-redraft-intent-classifier", "confidence 0.7; citation-removal fuzzy match 0.62"],
        ["-", "Workflow error handler\npmi-workflow-error-handler-dev", "Maps an in-progress status to the matching *_FAILED status after a failure",
         "DynamoDB", "3 retries"],
    ], widths=[0.8, 3.4, 6, 3.8, 3], font=7.5)
    note(doc, "Not in the live flow: a 'Master Reviewer' compliance agent exists in code (agents/master_reviewer) and "
              "is deployed as pmi-master-reviewer, but no live state machine calls it. Compliance review is done by "
              "people (CA and Legal reviewers) instead [Code, Live].")
    doc.add_heading("5.2 Models", 2)
    table(doc, ["Purpose", "Default model (via LiteLLM)", "Set by"], [
        ["General drafting / synthesis", "bedrock/us.anthropic.claude-sonnet-4-6", "LLM_MODEL_DEFAULT / LITELLM_MODEL"],
        ["Reasoning-heavy steps", "bedrock/us.anthropic.claude-opus-4-8", "LLM_MODEL_REASONING"],
        ["Fast / cheap steps", "bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0", "LLM_MODEL_FAST"],
        ["Reranking", "Cohere Rerank v3.5 (us-east-1)", "AWS_LITELLM_RERANK_MODEL"],
        ["Embeddings (KB)", "amazon.titan-embed-text-v2:0 / cohere.embed-multilingual-v3", "KB configuration"],
        ["Optional comparison", "gemini-2.5-pro", "ENABLE_GEMINI_COMPARISON (default off)"],
    ], widths=[4.5, 7.5, 5])
    para(doc, "The 'us.' prefix means a cross-region inference profile: calls can be served from US regions.", italic=True, size=9)

    doc.add_heading("5.3 Human-in-the-loop (HITL) design", 2)
    bullets(doc, [
        ("Pause.", "The gate uses Step Functions 'waitForTaskToken'. The HITL Lambda saves the token and a record "
         "(hitl_id = hitl_<request_id>_<agent>_<epoch>) with the sources and their counts by type, then returns. The "
         "workflow stays paused at no compute cost."),
        ("Decide.", "The UI posts approve / revise / reject to /requests/{research|draft}/hitl/{hitl_id}. Feedback is "
         "required for 'revise'. A second decision on the same checkpoint returns HTTP 409."),
        ("Resume.", "pmi-hitl-interface updates the record and resumes the workflow with the stored token. Approved "
         "source exclusions are applied to the research artefacts in S3. For drafts, the chosen version is promoted."),
        ("Limits.", "Research revisions stop after 3 cycles and drafting continues. Draft revisions have no cap. No "
         "auto-approval or timeout escalation."),
        ("Notification.", "The gate can publish to SNS (HITL_SNS_TOPIC_ARN), but no SNS topic exists in the account "
         "[Live], so users are not notified today."),
    ])
    doc.add_heading("5.4 Request status lifecycle", 2)
    para(doc, "Main path: SUBMITTED -> RESEARCH_IN_PROGRESS -> RESEARCH_REVIEW_PENDING -> RESEARCH_APPROVED -> "
              "DRAFTING_IN_PROGRESS -> DRAFT_REVIEW_PENDING -> DRAFT_APPROVED -> CA_REVIEW_IN_PROGRESS / "
              "LEGAL_REVIEW_IN_PROGRESS -> REVIEW_CHANGES_REQUESTED (optional) -> COMPLETED.")
    para(doc, "Other states: INCOMPLETE_REQUEST, VALIDATION_FAILED, CANCELLED, RE_RESEARCH_IN_PROGRESS, "
              "RE_DRAFTING_IN_PROGRESS, per-reviewer CA_<area>_PENDING/APPROVED/REJECTED, LEGAL_APPROVAL_*, "
              "REGIONAL_FP_REVIEW_PENDING, and *_FAILED states. About 40 in total [Code].")
    doc.add_page_break()

    # ------------------------------------------------------ 6. workbench
    doc.add_heading("6. CA Workbench (AgentCore + LangGraph)", 1)
    figure(doc, d3, "Figure 4 - Workbench request path and LangGraph graph [Code].")
    doc.add_heading("6.1 Request path", 2)
    bullets(doc, [
        "The UI posts a message to API cxb47goss9 (/messages). The proxy Lambda saves the user message (preview in "
        "DynamoDB, full text in S3), creates an assistant placeholder and a job, invokes the AgentCore runtime and "
        "returns HTTP 202 with a job_id.",
        "The runtime (FastAPI /invocations) accepts the job and runs the LangGraph workflow as a background task.",
        "When finished it writes the answer and citations back and marks the job COMPLETED or FAILED. The UI polls "
        "GET /jobs/{job_id}.",
    ])
    doc.add_heading("6.2 Graph nodes", 2)
    table(doc, ["Node", "Purpose", "Model / prompt"], [
        ["memory_retrieval", "Loads short-term turns, long-term facts, preferences and summaries for the user and conversation", "AgentCore Memory (no LLM)"],
        ["planner", "Classifies intent, chooses memory scope, decides if research is needed, rewrites the research query",
         "Claude Opus (default), temperature 0; Prompt CAWorkBench_Planner_Prompt 6SXZARKDW9"],
        ["memory_context_selection", "Keeps only the memory types the planner asked for", "none"],
        ["web_search", "Tavily candidates, then page text via Scrapling, with Gemini as fallback; up to 5 usable sources", "Tavily via LiteLLM; Gemini 2.5 Pro"],
        ["kb_retrieval", "Theme mapping and query variants (up to 8), hybrid Bedrock KB search with soft theme filters, min score 0.50",
         "Claude Sonnet helper calls; Bedrock KB"],
        ["curated_processor", "Placeholder - returns 'coming soon' today", "none"],
        ["synthesis_node", "Writes the answer from sources and memory with [Source N] citations; appends a deterministic Sources list",
         "Claude Sonnet, temperature 0.3, up to 32k tokens; Prompt CAWorkbenchSynthesizerPrompt 26AXASKSFB"],
        ["memory_storage", "Saves the turn to AgentCore Memory; long-term facts and preferences are extracted automatically", "AgentCore Memory"],
    ], widths=[3.3, 8.2, 5.5])
    doc.add_heading("6.3 Intents", 2)
    table(doc, ["Intent", "Research?", "Synthesis mode"], [
        ["new_question", "Yes", "fresh_research_answer"],
        ["followup_research", "Yes, plus recent conversation", "combine_previous_context_with_new_research"],
        ["followup_format_only", "No (reformats the last answer)", "reformat_previous_response"],
    ], widths=[4, 5, 8])
    doc.add_heading("6.4 Memory", 2)
    para(doc, "AgentCore Memory CA_Workbench_Memory-62CKDsBH4r with three long-term strategies: FactExtractor "
              "(/facts/{user}/), PreferenceLearner (/preferences/{user}/) and SessionSummarizer (/summaries/{user}/). "
              "Short-term memory is per conversation. By default the planner sees the last 5 turns and the synthesizer "
              "up to 5 facts and 5 preferences [Code]. AgentCore listing APIs are blocked by an organisation SCP for "
              "developer roles, so the live runtime and memory could not be inspected [Live].")
    doc.add_page_break()

    # ------------------------------------------------------- 7. AI design
    doc.add_heading("7. Prompts, guardrails and AI safety", 1)
    doc.add_heading("7.1 How prompts are managed", 2)
    bullets(doc, [
        ("Central store.", "Prompts live in Amazon Bedrock Prompt Management in the dev account: 44 prompts, of "
         "which 42 belong to CCAIAA and 2 are tests [Live]."),
        ("Resolution.", "When PROMPT_MGMT_ENABLED is on, an agent loads ccaiaa-<category>-<researcher|drafter> "
         "(or ccaiaa-default-<agent>). If loading fails, it falls back to the prompt in code (fail-open). "
         "The shared quality rules are always appended [Code]."),
        ("Versions.", "The Workbench loads the latest published numeric version and never DRAFT [Code]."),
        ("Layering.", "A drafting call combines: base role prompt + category prompt + template + jurisdiction rules + "
         "shared quality rules + the request's own fields."),
    ])
    table(doc, ["Group", "Prompts in Bedrock Prompt Management [Live]"], [
        ["Category researchers (6)", "ccaiaa-{official-pmi-submission, third-party-submission, white-papers, internal-communications, media-releases, narrative-builder}-researcher"],
        ["Category drafters (6)", "the same six categories with -drafter"],
        ["Templates (6)", "ccaiaa-template-{same six categories}"],
        ["Jurisdictions (6)", "ccaiaa-jurisdiction-{india, thailand, vietnam, bangladesh, bhutan, nepal}"],
        ["Defaults", "ccaiaa-default-researcher, ccaiaa-default-drafter"],
        ["Pipeline steps", "ccaiaa-validator-topic-relevance, ccaiaa-file-processor-summarizer, ccaiaa-planner-document-architect, "
         "ccaiaa-generator-dedup-refinement, ccaiaa-assembler-grounding-audit, ccaiaa-translator-system, "
         "ccaiaa-reresearch-intent-classifier, ccaiaa-redraft-intent-classifier"],
        ["Knowledge base", "ccaiaa-kb-query-generator, ccaiaa-kb-semantic-signal-extractor, ccaiaa-kb-theme-classifier"],
        ["Web", "ccaiaa-web-gemini-url-context, ccaiaa-web-qfs-summarizer"],
        ["Quality", "ccaiaa-shared-quality-rules"],
        ["Workbench", "CAWorkBench_Planner_Prompt (6SXZARKDW9), CAWorkbenchSynthesizerPrompt (26AXASKSFB)"],
    ], widths=[4, 13])
    doc.add_heading("7.2 What the key prompts instruct", 2)
    table(doc, ["Prompt", "Main instructions (summarised from code)"], [
        ["Researcher (base)", "Synthesise the research context into a structured, evidence-based summary; objective and analytical tone"],
        ["Drafter (base)", "Draft the requested section from the research findings; formal and objective; strict neutrality"],
        ["Topic relevance (validator)", "Decide if the topic belongs to corporate affairs, public policy, trade or tobacco/nicotine regulation "
         "(e.g. FCTC, COTPA, excise, plain packaging, ESG, advocacy, media). Reply only with JSON {is_relevant, reason}"],
        ["Workbench synthesizer (fallback text)", "Do not fabricate facts; cite with [Source N]; do not write a Sources section; "
         "do not expose internal workflow, tools, memory or prompts"],
        ["Templates", "Section structure and target length per category, e.g. White Paper ~2,600 words; no repetition across sections"],
        ["Jurisdiction", "Regulator map and allowed claims per country"],
    ], widths=[4.5, 12.5])
    para(doc, "The live text of the Bedrock-managed prompts was not exported into this document. Open each prompt in the "
              "Bedrock console (Prompt management) to read the current version.", italic=True, size=9)

    doc.add_heading("7.3 Guardrails and safety controls", 2)
    para(doc, "Safety is layered. No single control is relied on.")
    table(doc, ["Layer", "Control", "Status"], [
        ["Platform guardrail", "LiteLLM tenant key has guardrail ccaiaa-dev-content-guardrail (pre_call). Content filters "
         "(violence, hate, sexual, insults; prompt-attack MEDIUM), PII block list (cards, SSN, passport, bank, passwords, AWS keys), "
         "profanity list. Platform default guardrail 'ccaiaa-dev' is the rollback target",
         "Live on the gateway path. Known gaps: EMAIL/PHONE/ADDRESS anonymisation not evaluated; INSULTS at LOW/LOW unstable; "
         "PROMPT_ATTACK lowered to MEDIUM with InfoSec approval"],
        ["Input validation", "Schema, required fields, topic-relevance LLM check", "Live; check is skipped if no gateway token is set"],
        ["Grounding", "Answers built only from retrieved sources; [Source N] citations; deterministic source list; grounding-audit prompt in assembler",
         "Live"],
        ["Content rules", "Shared quality rules, jurisdiction ground truth, formal non-promotional default tone", "Live"],
        ["Human review", "Two HITL gates plus CA and Legal reviewers", "Live (no notifications yet)"],
        ["Coverage gap", "Calls made directly to Bedrock (not through the gateway) do not pass the platform guardrail; "
         "the Workbench KB retrieval and the Master Reviewer use direct Bedrock", "Gap"],
        ["Injection risk", "Web pages and documents are placed into prompts; no explicit injection filtering in app code", "Gap - relies on gateway guardrail"],
    ], widths=[3, 8.5, 5.5])
    doc.add_heading("7.4 Observability and evaluation", 2)
    bullets(doc, [
        "LangSmith tracing headers are passed through every workflow step, so a request can be followed across agents.",
        "A daily job (EventBridge ca-langsmith-export-daily, 02:00 UTC) exports LangSmith data to S3 "
        "(ca-workbench-langsmith-export) [Live].",
        "Prompt and model evaluation is manual: prompt_testing/, model_test_temp/ (Gemini model comparison) and "
        "scripts such as evaluate_prompts.py [Code]. There is no automated evaluation in CI.",
    ])
    doc.add_page_break()

    # ------------------------------------------------------- 8. knowledge
    doc.add_heading("8. Knowledge base and ingestion", 1)
    figure(doc, d4, "Figure 5 - Knowledge pipeline [Code].")
    table(doc, ["Item", "Detail"], [
        ["Source", "SharePoint site SAICDIAandCapgeminiTeam-DIA-India, library 'PMI Test Artifacts CA' via Microsoft Graph; "
         "credentials in Secrets Manager (pmi/sharepoint/credentials)"],
        ["File types", ".docx, .pptx, .pdf, .xlsx, .msg, .eml"],
        ["Metadata", "theme-level-1, theme-level-2, jurisdiction, language, department, owner, valid-till, source URL; "
         "SharePoint fields plus an LLM classifier"],
        ["Theme taxonomy", "Level 1: Smoke-free products / heated tobacco, Combustible cigarettes, Corporate Equity. "
         "Level 2: Regulatory / product standards, Fiscal and taxes, Illicit trade, Scientific, Youth access prevention, Sustainability, Others"],
        ["Knowledge bases", "English: Titan v2, 512-token semantic chunks (KB WQURRONWPQ). Multilingual: Cohere, 450-token chunks "
         "(KB LPMWAHDZS8). Separate OpenSearch collections because the vector spaces differ"],
        ["Created by", "Platform KB Management API (OAuth2), scripts in ccaiaa-dev-platform-deployment/litellm-account/knowledge-base"],
        ["Retrieval", "Hybrid search, metadata filters, LLM query enrichment, Cohere rerank, through the LiteLLM gateway"],
        ["Failures", "Sync-failure handler moves failed files to Exception_docs/; KMS key-policy grant needed for platform roles on new KBs"],
    ], widths=[3.5, 13.5])
    note(doc, "Knowledge-base IDs differ between components. The research workflow uses WQURRONWPQ and LPMWAHDZS8 via "
              "the gateway. The Workbench and the KB builder default to OSJDPJLTNC (pmi-experimental-knowledge-base, "
              "in the dev account) [Code, Live]. Confirm which KB each component should use.")
    para(doc, "The SharePoint ingestion code documents a daily 06:00 UTC schedule, but no such EventBridge rule exists "
              "in the account. The rule TriggerBedrockKBSyncFromS3 does exist [Live]. Ingestion may currently be "
              "triggered manually.", italic=True, size=9)
    doc.add_page_break()

    # -------------------------------------------------- 9. AWS services
    doc.add_heading("9. AWS services inventory", 1)
    para(doc, "Resources found in account 603433800649, eu-west-1, that belong to CCAIAA [Live]. Unrelated account "
              "resources (patching, controls framework, labs) are left out.")
    table(doc, ["Service", "Resources", "Purpose"], [
        ["AWS Amplify", "caaiaa_agentic_app (drp6k4av42dyw) - dev; PMICAUI, PMI-React-App (older)", "Hosts the React SPA"],
        ["Amazon Cognito", "User pool ccaiaa-authentication (eu-west-1_Cu9LDnjrk)", "User sign-in (Hosted UI, OAuth code flow)"],
        ["API Gateway (HTTP)", "y97ca45wk1 pmi-agentic-ai-api-dev; l0xhkyycki latest-records; 8tst29fjdh ingestion; 601e7izjc4 dev-ui",
         "Requests, HITL, reviews, uploads, request list, ingestion"],
        ["API Gateway (REST)", "cxb47goss9 ca-workbench-api; p3e6nk579c pmi-agentic-ai-api; x790ajq294 policy-updates", "Workbench, documents, signed docs, policy feed"],
        ["AWS Lambda", "88 functions in the account, about 80 for CCAIAA, in 4 generations (see 10.4)", "All business logic and agents"],
        ["AWS Step Functions", "pmi-research-workflow-client-demo2 (live); pmi-agentic-ai-workflow-client-demo1; pmi-agentic-ai-workflow-dev (fast path, no HITL)",
         "Workflow orchestration"],
        ["Amazon Bedrock AgentCore", "Runtime caWorkbenchAgentcore-vrKjOJ5qFA; Memory CA_Workbench_Memory-62CKDsBH4r [Code]", "Workbench agent hosting and memory"],
        ["Bedrock Prompt Management", "44 prompts (section 7.1)", "Central prompt store"],
        ["Bedrock Knowledge Bases", "pmi-experimental-knowledge-base (OSJDPJLTNC) + test KBs; production KBs in the platform account", "RAG"],
        ["OpenSearch Serverless", "5 bedrock-knowledge-base-* collections", "KB vector stores"],
        ["Amazon DynamoDB", "pmi-agentic-ai-requests(-dev), -hitl(-dev), -users, -curated-links, -policy-updates(-output), -knowledge-base (legacy); "
         "ChatConversations, ChatMessages, ChatJobs", "Requests, checkpoints, users, chat"],
        ["Amazon S3", "pmi-agentic-ai-documents-603433800649-eu-west-1; pmi-agentic-ai-documents-sandbox-603433800649; ccaiaa-kb-dev; "
         "ccaiaa-workbench-dev; ca-workbench-langsmith-export", "Documents, KB source, chat content, trace export"],
        ["Amazon ECR", "ca-workbench, ca-lambda-workbench, ca-lambda-reviewflow, ca-langsmith-export, ca-query-cost-join, pmi-agentic/input-validator-dev",
         "Container images"],
        ["AWS CodeBuild", "ca-workbench-build, ca-workbench-lambda-build, pmi-agentic-lambdas-builder, ca-reviewflow-lambda-build, "
         "ca-workbench-export-build, ca-workbench-query-cost-join-build", "Image builds"],
        ["Amazon EventBridge", "TriggerBedrockKBSyncFromS3; ca-langsmith-export-daily (02:00 UTC)", "KB sync, trace export"],
        ["AWS Secrets Manager", "pmi/sharepoint/credentials, /pmi-agentic-ai/dev/secrets, ca-workbench/langsmith-export, Aurora credentials (2)", "Secrets"],
        ["Amazon SNS", "None", "HITL notifications are not configured"],
    ], widths=[3.3, 9, 4.7], font=8)
    doc.add_page_break()

    # ----------------------------------------------------------- 10. data
    doc.add_heading("10. Data model and deployment units", 1)
    doc.add_heading("10.1 DynamoDB", 2)
    table(doc, ["Table", "Key", "Holds"], [
        ["pmi-agentic-ai-requests", "request_id", "Request fields, status, progress, current_hitl_id, task token, document keys, errors"],
        ["pmi-agentic-ai-hitl", "hitl_id; GSIs RequestIdIndex, StatusIndex", "Checkpoints: sources, counts, decision, feedback, removed sources, who and when"],
        ["pmi-agentic-ai-users", "email", "Role (admin, reviewer roles) and reviewer details"],
        ["pmi-agentic-ai-curated-links", "(not read)", "Curated internal links for research"],
        ["ChatConversations", "user_id + conversation_id", "Title, status, soft-delete flag, counts"],
        ["ChatMessages", "conversation_id + message_sort_key", "Role, preview, status, S3 pointer to full text, job id"],
        ["ChatJobs", "job_id; GSI user_id-created_at-index", "Async job status for the Workbench"],
    ], widths=[4.3, 4.7, 8])
    doc.add_heading("10.2 S3", 2)
    table(doc, ["Bucket", "Content"], [
        ["pmi-agentic-ai-documents-603433800649-eu-west-1", "Generated .docx documents, document versions, research artefacts, SharePoint mirror (sharepoint/), Exception_docs/"],
        ["pmi-agentic-ai-documents-sandbox-603433800649", "Signed documents (signed_documents/); presigned URLs valid 15 minutes, 100 MB limit"],
        ["ccaiaa-kb-dev", "KB source documents + .metadata.json (English/..., Multilingual/sharepoint/)"],
        ["ccaiaa-workbench-dev", "Full Workbench chat content (chat-messages/{user}/{conversation}/{message}/)"],
    ], widths=[6.5, 10.5])
    doc.add_heading("10.3 Main API routes", 2)
    table(doc, ["API", "Routes", "Backend"], [
        ["y97ca45wk1 (HTTP)", "POST /requests; GET /requests/{id}; reviews, reviews/assigned, reviews/reviewers, reviews/decision; complete; "
         "legal-redraft; discussion; smart-revision", "pmi-api-handler-client-demo1"],
        ["y97ca45wk1 (HTTP)", "GET/POST /requests/{research|draft}/hitl/{hitl_id}", "pmi-hitl-interface"],
        ["y97ca45wk1 (HTTP)", "POST /uploads/presigned-url", "pmi-agentic-ai-uploads-presigned-handler-dev"],
        ["l0xhkyycki (HTTP)", "GET /requests/latest?user=", "latest-records handler (3-month window)"],
        ["p3e6nk579c (REST)", "/documents/... (download, list, compare, content, preview); /signed-documents (list, upload-url, download, delete)", "document + signed-docs Lambdas"],
        ["cxb47goss9 (REST)", "/conversations, /conversations/{id}/messages, /messages, /jobs/{id}, /draft/*, /chat/*", "ca-workbench-api-proxy"],
        ["x790ajq294 (REST)", "/dev/policy-updates?email=", "pmi-agentic-ai-policy-updates"],
    ], widths=[3, 9.5, 4.5], font=8)
    doc.add_heading("10.4 Lambda generations", 2)
    para(doc, "Four generations of the same agents are deployed side by side [Live]. Only one is used by the live UI path.")
    table(doc, ["Generation", "Examples", "Used by"], [
        ["Monolith", "pmi-input-validator, pmi-master-researcher, pmi-master-drafter, pmi-master-reviewer", "pmi-agentic-ai-workflow-dev (fast path)"],
        ["client-demo1 (zip)", "pmi-*-client-demo1", "pmi-agentic-ai-workflow-client-demo1"],
        ["client-demo2 (zip)", "pmi-research-*-client-demo2, pmi-draft-*-client-demo2", "Deploy script target; not the live state machine"],
        ["-dev (container image)", "pmi-research-*-dev, pmi-draft-*-dev, pmi-hitl-gate-dev", "pmi-research-workflow-client-demo2 (LIVE)"],
    ], widths=[3.5, 8, 5.5])
    doc.add_page_break()

    # ------------------------------------------------------- 11. security
    doc.add_heading("11. Security and identity", 1)
    doc.add_heading("11.1 What is in place", 2)
    bullets(doc, [
        "Cognito Hosted UI sign-in with the OAuth authorization-code flow; tokens kept in cookies (1 day, secure on HTTPS).",
        "Secrets in AWS Secrets Manager and HashiCorp Vault, not in code.",
        "Model access governed by the platform: per-tenant key, guardrail, and cost tracking.",
        "Presigned URLs for uploads and downloads (15 minutes for signed documents, 24 hours for generated documents).",
        "DynamoDB point-in-time recovery and S3 versioning in the original infrastructure definition [Code].",
    ])
    doc.add_heading("11.2 Gaps found", 2)
    table(doc, ["#", "Finding", "Evidence", "Risk"], [
        ["S1", "No API authorizer on any API. HTTP routes are AuthorizationType NONE; REST APIs have no authorizers",
         "[Live]", "Anyone who can reach the URL can call the APIs"],
        ["S2", "User identity taken from client-supplied values (?user=, X-User-Id, body user_id)", "[Code]", "Users can act as other users"],
        ["S3", "UI does not send the access token on most calls (Authorization set outside headers in request())", "[Code]", "Blocks adding an authorizer until fixed"],
        ["S4", "Roles not from Cognito groups; reviewer view inferred from status or route; user.email not set after Cognito sign-in", "[Code]", "Wrong view or broken calls for real users"],
        ["S5", "Generated documents downloaded directly from the S3 bucket URL by the browser", "[Code]", "Requires readable objects; prefer presigned URLs"],
        ["S6", "TLS certificate verification disabled on gateway calls (verify=False / CERT_NONE)", "[Code]", "Man-in-the-middle exposure inside the network"],
        ["S7", "CORS '*' on APIs", "[Code]", "Any site can call the APIs from a browser"],
        ["S8", "Full request events and user questions logged at INFO", "[Code]", "Sensitive content in CloudWatch logs"],
        ["S9", ".env files committed; personal SSO profile in platform scripts; Gemini key in URL query", "[Code]", "Secret and config hygiene"],
        ["S10", "Over-broad IAM policies and stale roles (see the separate dev security audit workbook)", "[Live]", "Least-privilege gap"],
    ], widths=[1, 8, 1.8, 6.2], font=8)
    doc.add_page_break()

    # --------------------------------------------------------- 12. delivery
    doc.add_heading("12. Delivery, environments and operations", 1)
    doc.add_heading("12.1 Source and branching", 2)
    para(doc, "Four Bitbucket repositories in project CCAIAA. Branch model: feature/* -> dev -> qa -> main (prod). "
              "dev branches were created from the latest feature branches. One repository per component and "
              "one branch per environment, so the code tested in QA is the code promoted to PROD.")
    doc.add_heading("12.2 Pipelines", 2)
    table(doc, ["Component", "How it is built and deployed"], [
        ["UI", "Jenkins (CloudBees): checkout with service account S-DSD-CCAIAA -> Node 18 -> vite build (--mode qa for QA) -> zip -> "
         "Amplify CreateDeployment/StartDeployment. Jenkinsfile (dev, app drp6k4av42dyw) and Jenkinsfile.qa (QA, app d10bktbssu5hye). "
         "AWS credentials from Jenkins credential store (aws-amplify-deploy, aws-amplify-deploy-qa)"],
        ["Workflow Lambdas", "Python deploy scripts (deploy_lambdas.py, deploy_lambdas_demo2.py) and CodeBuild pmi-agentic-lambdas-builder for images"],
        ["Workbench", "CodeBuild ca-workbench-build (AgentCore ARM64 image -> ECR ca-workbench) and ca-workbench-lambda-build (proxy -> ECR ca-lambda-workbench)"],
        ["Platform config", "Scripts in ccaiaa-dev-platform-deployment (guardrails, KBs, cost reports), run by engineers"],
        ["Infrastructure", "An AWS CDK stack exists but is out of date. The live environment was built with scripts and the console"],
    ], widths=[3.5, 13.5])
    doc.add_heading("12.3 Environment status", 2)
    table(doc, ["Environment", "Status"], [
        ["dev", "Running end to end"],
        ["QA", "Front-end pipeline (Jenkinsfile.qa) passes checkout, build and package. The deploy stage fails with AccessDenied on "
         "amplify:CreateDeployment for user bitbucket-amplify-deployer in 793012896927 - the policy's actions and resource ARN need "
         "checking. Still needed: QA backend (APIs, Cognito, Lambdas, tables, platform tenant) and real values in .env.qa. Most UI "
         "API hosts are hard-coded to dev and must become variables"],
        ["PROD", "Not started"],
    ], widths=[3, 14])
    doc.add_heading("12.4 Operations", 2)
    bullets(doc, [
        ("Monitoring.", "CloudWatch Logs for Lambdas; Step Functions execution history. Step Functions logging and "
         "X-Ray tracing are OFF on all three state machines [Live]."),
        ("Error handling.", "Retries with back-off, timeouts and catch states in the workflow; the error handler sets "
         "*_FAILED statuses; failed research branches degrade to empty results."),
        ("Cost.", "Platform Cost API (LiteLLM, LangSmith, Tavily, licence) plus the tenant account bill. Direct Bedrock "
         "calls in the tenant account are the largest cost driver (see the cost reports)."),
        ("Support runbooks.", "Guardrail and KB runbooks exist in ccaiaa-dev-platform-deployment. Application runbooks do not."),
    ])
    doc.add_page_break()

    # -------------------------------------------------------- 13. risks
    doc.add_heading("13. Risks, gaps and recommendations", 1)
    table(doc, ["Priority", "Recommendation", "Why", "Effort"], [
        ["P1", "Add a Cognito JWT authorizer to every API; derive the user from the token, not from request values; fix the UI to send the token",
         "S1-S3: security before QA/PROD holds real data", "M"],
        ["P1", "Make every API host and bucket a build variable in the UI (remove the 5 hard-coded dev hosts)", "QA/PROD cannot work otherwise", "S"],
        ["P1", "Describe the live stack as infrastructure-as-code (Terraform/CDK) and retire the stale CDK stack",
         "Repeatable QA/PROD; drift control", "L"],
        ["P2", "Retire unused Lambda generations and state machines (monolith, demo1, demo2 zips) after confirming no callers",
         "Confusion, cost, attack surface", "M"],
        ["P2", "Turn on Step Functions logging (ERROR at least) and X-Ray", "Faster incident diagnosis", "S"],
        ["P2", "Route all model and KB calls through the LiteLLM gateway", "Guardrail coverage and single cost view", "M"],
        ["P2", "Use Cognito groups for reviewer roles and populate the user's email", "Correct reviewer views; remove demo roles", "M"],
        ["P2", "Create the SNS topic (or email) for HITL notifications", "Users currently get no notice that a review is waiting", "S"],
        ["P2", "Align knowledge-base IDs across components", "Different answers from Workbench and workflow", "S"],
        ["P3", "Re-enable TLS verification with the PMI CA bundle; remove full-event logging", "S6, S8", "S"],
        ["P3", "Add automated tests and a golden-set evaluation for prompts in CI", "No tests today; safe prompt changes", "M"],
        ["P3", "Cap draft re-draft cycles; decide behaviour when the draft gate errors (it currently reports success)", "Predictable workflow", "S"],
        ["P3", "Update the READMEs (they describe older designs)", "Onboarding", "S"],
    ], widths=[1.5, 8, 5.5, 2], font=8)
    para(doc, "Effort: S = days, M = 1-3 weeks, L = more than 3 weeks.", italic=True, size=9)

    # ---------------------------------------------------------- glossary
    doc.add_heading("14. Glossary", 1)
    table(doc, ["Term", "Meaning"], [
        ["Agent", "A component that uses an LLM to make a decision or produce content (here mostly one Lambda per agent)"],
        ["AgentCore", "Amazon Bedrock AgentCore: managed runtime and memory for AI agents"],
        ["CA", "Corporate Affairs"],
        ["Guardrail", "A policy that checks model input and output (harmful content, PII, prompt attacks)"],
        ["HITL", "Human-in-the-loop: a step where a person must approve before the workflow continues"],
        ["KB / RAG", "Knowledge base / retrieval-augmented generation: search documents first, then answer from them"],
        ["LangGraph", "Open-source library for building agent workflows as graphs"],
        ["LiteLLM gateway", "PMI's shared proxy in front of all models; applies keys, guardrails, logging and cost tracking"],
        ["Prompt Management", "Bedrock service that stores and versions prompts outside the code"],
        ["Task token", "A Step Functions token that lets an external call resume a paused workflow"],
        ["Tenant", "A product team's identity on the shared platform (here ccaiaa-dev)"],
    ], widths=[3.5, 13.5])

    doc.add_heading("Appendix A - Source files", 1)
    table(doc, ["Area", "Where to look"], [
        ["Workflow definition", "ccaiaa-agentic-api/infrastructure/step_functions_definition_client_demo2.json; live in Step Functions console"],
        ["Agents", "ccaiaa-agentic-api/agents/* (validator, researcher_*, drafter_*, hitl_research_gate, workflow_error_handler)"],
        ["Prompts (code)", "ccaiaa-agentic-api/core/system_prompts.py, core/prompt_registry_new.py, templates/"],
        ["API handlers", "ccaiaa-agentic-api/api/*_new.py"],
        ["Ingestion and KB", "ccaiaa-agentic-api/ingestion/handler.py, knowledge_base/build_kb_from_s3.py"],
        ["Workbench", "ccaiaa-workbench/CA Workbench/AgentCore/agentcore_scripts/*, Proxy_lambda/lambda_scripts/*"],
        ["UI", "ccaiaa-agentic-ui/src/services/api.js, App.jsx, components/*; Jenkinsfile, Jenkinsfile.qa"],
        ["Platform", "ccaiaa-dev-platform-deployment/litellm-account/{guardrails, knowledge-base, litellm_cost}"],
    ], widths=[3.5, 13.5])

    doc.save(OUT)
    return OUT


if __name__ == "__main__":
    print("Saved:", build())
