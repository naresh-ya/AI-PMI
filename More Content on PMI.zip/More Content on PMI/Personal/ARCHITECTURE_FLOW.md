# PMI Excel Agent - Complete Architecture Flow

## 🏗️ System Overview

```
┌────────────────────────────────────────────────────────────────────┐
│                         USER INTERFACE                              │
│                    (Next.js Frontend - React)                       │
└────────────────────────────────────────────────────────────────────┘
                                  ↓
┌────────────────────────────────────────────────────────────────────┐
│                      FRONTEND LAYER                                 │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Chat Components (page.tsx, excel-agent-chat.tsx)           │  │
│  │  • User input collection                                     │  │
│  │  • Message history management                                │  │
│  │  • Real-time streaming display                               │  │
│  │  • Theme & UI state management                               │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                          ↓                                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Service Layer (excel-agent-service.ts)                      │  │
│  │  • API request construction                                  │  │
│  │  • SSE stream parsing                                        │  │
│  │  • Event handling & callbacks                                │  │
│  │  • Final answer extraction                                   │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘
                                  ↓
                    HTTP POST /api/excel-agent
                    { query, threadId }
                                  ↓
┌────────────────────────────────────────────────────────────────────┐
│                    NEXT.JS API ROUTE LAYER                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  API Route Handler (app/api/excel-agent/route.ts)           │  │
│  │  • Request validation                                        │  │
│  │  • Thread/Run/Message ID generation                          │  │
│  │  • Session ID generation                                     │  │
│  │  • AWS credential retrieval (fromEnv)                        │  │
│  │  • AWS SigV4 request signing (aws4)                          │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘
                                  ↓
              Signed HTTPS POST to AgentCore Runtime
              (bedrock-agentcore.eu-west-1.amazonaws.com)
              Headers: Authorization, X-Amzn-Session-Id
                                  ↓
┌────────────────────────────────────────────────────────────────────┐
│                    AWS AGENTCORE RUNTIME                            │
│  • Manages agent lifecycle (thread/run management)                 │
│  • Enforces AG-UI protocol compliance                              │
│  • Handles checkpointing & state persistence                       │
│  • Routes requests to backend container                            │
│  • Streams events back via SSE                                     │
└────────────────────────────────────────────────────────────────────┘
                                  ↓
                  Forwards to Backend Container
                  POST /invocations (AG-UI protocol)
                                  ↓
┌────────────────────────────────────────────────────────────────────┐
│                    BACKEND CONTAINER                                │
│                    (FastAPI + LangGraph)                            │
│  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │
│  ┃  AG-UI Server (agui_server_aws.py)                          ┃  │
│  ┃  ┌────────────────────────────────────────────────────────┐ ┃  │
│  ┃  │ FastAPI Application                                    │ ┃  │
│  ┃  │ • POST /invocations endpoint                           │ ┃  │
│  ┃  │ • EventEncoder (SSE formatting)                        │ ┃  │
│  ┃  │ • LangGraphAgent wrapper (ag-ui-langgraph)             │ ┃  │
│  ┃  │ • Event filtering & sanitization                       │ ┃  │
│  ┃  │ • ThreadId injection into state                        │ ┃  │
│  ┃  └────────────────────────────────────────────────────────┘ ┃  │
│  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │
│                                  ↓                                  │
│  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │
│  ┃  Graph Wrapper (agui/graph_wrapper.py)                      ┃  │
│  ┃  ┌────────────────────────────────────────────────────────┐ ┃  │
│  ┃  │ build_agui_graph()                                     │ ┃  │
│  ┃  │ • Creates StateGraph(AGUIExcelState)                   │ ┃  │
│  ┃  │ • Lazy graph loading                                   │ ┃  │
│  ┃  │ • Checkpointer setup (MemorySaver/Postgres)            │ ┃  │
│  ┃  │ • Recursion limit: 50                                  │ ┃  │
│  ┃  └────────────────────────────────────────────────────────┘ ┃  │
│  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │
│                                  ↓                                  │
│  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │
│  ┃                    LANGGRAPH PIPELINE                       ┃  │
│  ┃                  (Flattened Architecture)                   ┃  │
│  ┃                                                             ┃  │
│  ┃  START                                                      ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [1] parse_messages                                         ┃  │
│  ┃      • Extract query from AG-UI messages                   ┃  │
│  ┃      • Discover Excel files from S3                        ┃  │
│  ┃      • Set output_dir (S3 URI)                             ┃  │
│  ┃      • Extract threadId for memory session                 ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [2] context_enrichment                                     ┃  │
│  ┃      • Load previous Q&A from memory                       ┃  │
│  ┃      • Enrich query with conversation context              ┃  │
│  ┃      • Track enrichment metadata                           ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [3] normalize_query (Node2 step 1)                        ┃  │
│  ┃      • Question normalization                              ┃  │
│  ┃      • Glossary term matching                              ┃  │
│  ┃      • Standardization                                     ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [4] domain_validation (Node2 step 2)                      ┃  │
│  ┃      • Question type classification                        ┃  │
│  ┃      • Confidence scoring                                  ┃  │
│  ┃      ├─ greeting → format_response                         ┃  │
│  ┃      ├─ non-financial → format_response                    ┃  │
│  ┃      └─ financial → continue                               ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [5] intent (Node2 step 3)                                 ┃  │
│  ┃      • Analysis type detection                             ┃  │
│  ┃      • Metric extraction                                   ┃  │
│  ┃      • Aggregation requirements                            ┃  │
│  ┃      • Time context parsing                                ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [6] mapping (Node2 step 4)                                ┃  │
│  ┃      • File & sheet mapping                                ┃  │
│  ┃      • Multi-month detection                               ┃  │
│  ┃      • Confidence scoring per source                       ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [7] sheet_selector (Node2 step 5)                         ┃  │
│  ┃      • Final sheet selection                               ┃  │
│  ┃      • Copy selected_sources to top-level state            ┃  │
│  ┃      └─ no sources → format_response                       ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [8] structure_analyzer                                     ┃  │
│  ┃      • Excel profiling (headers, dtypes, samples)          ┃  │
│  ┃      • Schema extraction                                   ┃  │
│  ┃      • Data quality checks                                 ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [9] query_context_builder                                 ┃  │
│  ┃      • Multi-month registry construction                   ┃  │
│  ┃      • Context consolidation                               ┃  │
│  ┃      • Column mapping & validation                         ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [10] code_generator                                        ┃  │
│  ┃      • Python/Pandas code generation (Claude Sonnet 4.6)  ┃  │
│  ┃      • Multi-file handling logic                           ┃  │
│  ┃      • Error handling injection                            ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [11] code_executor                                         ┃  │
│  ┃      • Sandboxed code execution                            ┃  │
│  ┃      • Result extraction                                   ┃  │
│  ┃      • Error capture                                       ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [12] narrative_explainer                                   ┃  │
│  ┃      • Business-friendly narrative generation              ┃  │
│  ┃      • Markdown formatting                                 ┃  │
│  ┃      • Insight extraction                                  ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [13] context_storage                                       ┃  │
│  ┃      • Store Q&A pair to memory                            ┃  │
│  ┃      • Associate with threadId session                     ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [14] results_logger                                        ┃  │
│  ┃      • Log execution metadata                              ┃  │
│  ┃      • Audit trail                                         ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  [15] format_response                                       ┃  │
│  ┃      • Convert final_answer to AIMessage                   ┃  │
│  ┃      • Append to messages list                             ┃  │
│  ┃    ↓                                                        ┃  │
│  ┃  END                                                        ┃  │
│  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │
└────────────────────────────────────────────────────────────────────┘
                                  ↓
                    SSE Event Streaming (↑)
                                  ↓
┌────────────────────────────────────────────────────────────────────┐
│                    EVENT STREAM FLOW                                │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Backend Events (ag-ui-langgraph)                            │  │
│  │  • RUN_STARTED                                               │  │
│  │  • STEP_STARTED (for each node)                              │  │
│  │  • STATE_SNAPSHOT (node outputs)                             │  │
│  │  • TEXT_MESSAGE_CONTENT (streaming text)                     │  │
│  │  • MESSAGES_SNAPSHOT (final messages)                        │  │
│  │  • RUN_FINISHED / RUN_ERROR                                  │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                          ↓                                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Event Filtering (agui_server_aws.py)                        │  │
│  │  • Filter out RAW events                                     │  │
│  │  • Sanitize STATE_SNAPSHOT (keep only display fields)        │  │
│  │  • Compress MESSAGES_SNAPSHOT (last 6 messages)              │  │
│  │  • EventEncoder for SSE formatting                           │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                          ↓                                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  SSE Stream Format                                           │  │
│  │  data: {"type": "STEP_STARTED", "stepName": "intent"}       │  │
│  │  data: {"type": "STATE_SNAPSHOT", "snapshot": {...}}        │  │
│  │  data: {"type": "TEXT_MESSAGE_CONTENT", "delta": "..."}     │  │
│  │  data: [DONE]                                                │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘
                                  ↑
                      Passed through AgentCore
                                  ↑
                      Streamed through API Route
                                  ↑
┌────────────────────────────────────────────────────────────────────┐
│                    FRONTEND RENDERING                               │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  SSE Parsing (excel-agent-service.ts)                        │  │
│  │  • ReadableStream reader                                     │  │
│  │  • Line-by-line event parsing                                │  │
│  │  • Event callback invocation                                 │  │
│  │  • Final answer extraction                                   │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                          ↓                                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  UI Updates (page.tsx)                                       │  │
│  │  • STEP_STARTED → Update currentStep                         │  │
│  │  • STATE_SNAPSHOT → Show intermediate state                  │  │
│  │  •   - domain_validation details                             │  │
│  │  •   - analysis_spec (intent)                                │  │
│  │  •   - mapping_result (sheet selection)                      │  │
│  │  • TEXT_MESSAGE_CONTENT → Append to streamingText            │  │
│  │  • RUN_FINISHED → Complete message                           │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                          ↓                                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Chat Display                                                │  │
│  │  • User message bubble                                       │  │
│  │  • Processing steps (animated)                               │  │
│  │  • Assistant response (Markdown rendered)                    │  │
│  │  • Timestamp                                                 │  │
│  │  • Chat history management                                   │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Details

### 1. **Request Flow (Frontend → Backend)**

```
User Input (query)
  → ChatComponent.handleSend()
  → askExcelAgent(query, chatId, onEvent)
  → POST /api/excel-agent { query, threadId }
  → API Route Handler:
      - Generate IDs (thread/run/message/session)
      - Retrieve AWS credentials
      - Sign request with AWS SigV4
  → HTTPS POST to AgentCore Runtime (signed)
  → AgentCore forwards to Backend Container
  → FastAPI /invocations endpoint
  → LangGraphAgent.run(RunAgentInput)
  → StateGraph execution begins
```

### 2. **Response Flow (Backend → Frontend)**

```
Graph Node Execution
  → Node emits StateUpdate
  → LangGraphAgent yields AG-UI Events:
      - RUN_STARTED
      - STEP_STARTED (per node)
      - STATE_SNAPSHOT (node outputs)
      - TEXT_MESSAGE_CONTENT (streaming)
      - MESSAGES_SNAPSHOT
      - RUN_FINISHED
  → Event Filtering (_filter_stream_event):
      - Drop RAW events
      - Sanitize STATE_SNAPSHOT (keep display fields only)
      - Compress MESSAGES_SNAPSHOT (last 6)
  → EventEncoder.encode() → SSE format
  → StreamingResponse
  → AgentCore streams events
  → API Route proxies stream
  → Frontend ReadableStream reader
  → SSE parsing (line-by-line)
  → Event callback invocation
  → UI updates (currentStep, processingSteps, streamingText)
  → Final answer extraction
  → Assistant message appended to chat
```

### 3. **State Management Flow**

```
AGUIExcelState (TypedDict)
├─ AG-UI Protocol Fields:
│  ├─ messages: List[HumanMessage | AIMessage]
│  ├─ threadId: str (injected by server)
│  └─ runId: str
├─ Pipeline Core Fields:
│  ├─ query: str (extracted from messages)
│  ├─ question: str (alias for node2 compatibility)
│  ├─ excel_files: List[str] (S3 URIs)
│  ├─ output_dir: str (S3 URI)
│  └─ final_answer: str
├─ Node2 Outputs (Flattened):
│  ├─ normalized_question: str
│  ├─ glossary_matches: List[Dict]
│  ├─ domain_validation: Dict
│  ├─ analysis_spec: Dict (intent)
│  ├─ intent_result: Dict
│  ├─ mapping_result: Dict
│  └─ selected_sources: List[Dict]
├─ Confidence Tracking:
│  ├─ confidence: float
│  ├─ sheet_selection_confidence: float
│  ├─ sheet_selection_warning: Optional[str]
│  └─ context_builder_confidence: float
├─ Multi-Month Support:
│  ├─ multi_month_registry: Dict[str, Dict]
│  ├─ current_month: str
│  └─ current_year: str
└─ Context Enrichment (NEW):
   ├─ memory_session_id: str (threadId)
   ├─ original_query: str
   ├─ enriched_query: str
   ├─ previous_qa: List[Dict]
   └─ context_enrichment_applied: bool
```

---

## 🔌 Protocol Layer: AG-UI

### **What is AG-UI?**

AG-UI (Agent Gateway User Interface) is AWS's protocol for building conversational AI agents with:
- **Streaming events** (SSE)
- **State management** (checkpointing)
- **Human-in-the-loop** (HITL) support
- **Standardized request/response format**

### **Key Components**

| Component | Purpose | Location |
|-----------|---------|----------|
| **RunAgentInput** | Standard request format | `ag_ui.core` |
| **EventEncoder** | SSE formatting | `ag_ui.encoder` |
| **LangGraphAgent** | LangGraph wrapper | `ag-ui-langgraph` |
| **Event Types** | Streaming events | `ag_ui.core` |

### **Event Types**

```python
# Core AG-UI Events
RUN_STARTED          # Agent execution begins
STEP_STARTED         # Node execution begins
STATE_SNAPSHOT       # Node output (state update)
TEXT_MESSAGE_CONTENT # Streaming text deltas
MESSAGES_SNAPSHOT    # Full message history
RUN_FINISHED         # Agent execution complete
RUN_ERROR            # Error occurred
RAW                  # Raw internal events (filtered)
```

### **Request Format**

```typescript
interface RunAgentInput {
  threadId: string;        // Conversation thread (for memory)
  runId: string;           // Unique run identifier
  messages: Array<{
    id: string;
    role: "user" | "assistant";
    content: string;
  }>;
  state?: any;             // Initial state (we inject threadId here)
  tools?: any[];
  context?: any[];
  forwardedProps?: any;
}
```

### **Response Format (SSE)**

```
data: {"type": "RUN_STARTED", "timestamp": "2025-05-25T10:00:00Z"}
data: {"type": "STEP_STARTED", "stepName": "parse_messages"}
data: {"type": "STATE_SNAPSHOT", "snapshot": {"query": "...", "confidence": 95}}
data: {"type": "TEXT_MESSAGE_CONTENT", "delta": "The total revenue..."}
data: {"type": "MESSAGES_SNAPSHOT", "messages": [{"role": "assistant", "content": "..."}]}
data: {"type": "RUN_FINISHED", "timestamp": "2025-05-25T10:00:30Z"}
data: [DONE]
```

---

## 🗄️ External Dependencies

### **AWS Services**

| Service | Purpose | Configuration |
|---------|---------|---------------|
| **AWS Bedrock AgentCore** | Agent runtime & orchestration | `AGENTCORE_RUNTIME_ARN` |
| **Amazon S3** | Excel file storage | `mbr-data-lake` bucket |
| **AWS Credentials** | Authentication | ENV vars or IAM role |

### **Python Libraries**

| Library | Purpose | Version |
|---------|---------|---------|
| **FastAPI** | Web framework | `^0.115.0` |
| **LangGraph** | Graph orchestration | `^0.3.31` |
| **ag-ui-langgraph** | AG-UI adapter | `^0.1.0` |
| **LangChain** | LLM framework | `^0.3.15` |
| **pandas** | Data processing | `^2.2.3` |
| **openpyxl** | Excel reading | `^3.1.5` |
| **boto3** | AWS SDK | `^1.35.0` |

### **Node.js Libraries**

| Library | Purpose | Version |
|---------|---------|---------|
| **Next.js** | React framework | `^15.1.0` |
| **React** | UI library | `^19.0.0` |
| **@aws-sdk/credential-providers** | AWS auth | `^3.729.0` |
| **aws4** | AWS SigV4 signing | `^1.14.0` |
| **react-markdown** | Markdown rendering | `^9.0.2` |

---

## 🔐 Security & Authentication

### **Request Signing Flow**

```
1. Frontend sends query to Next.js API route
2. API route retrieves AWS credentials (fromEnv)
3. Request payload constructed (RunAgentInput)
4. Session ID generated
5. AWS SigV4 signature computed (aws4.sign)
   - Service: bedrock-agentcore
   - Region: eu-west-1
   - Headers: Authorization, X-Amzn-Session-Id
6. Signed request sent to AgentCore
7. AgentCore validates signature
8. Request forwarded to backend container
```

### **Credential Chain**

```
AWS Credentials → Next.js API Route
  ↓
  fromEnv() provider
  ↓
  Check: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN
  ↓
  Sign request with aws4
  ↓
  Authorization header with SigV4 signature
  ↓
  AgentCore validates
```

---

## 📊 State Persistence

### **Checkpointing**

| Backend | Purpose | When Used |
|---------|---------|-----------|
| **MemorySaver** | In-memory (current request only) | Always (HITL disabled) |
| **AsyncPostgresSaver** | Durable persistence | Optional (HITL enabled) |

### **Configuration**

```python
# Environment Variables
EXCEL_AGENT_CHECKPOINT_BACKEND = "memory"  # or "postgres"
EXCEL_AGENT_CHECKPOINT_POSTGRES_DSN = "postgresql://..."

# Checkpointer Selection
# - MemorySaver: No cross-request persistence
# - Postgres: Durable checkpoints for HITL
```

### **Chat History (Frontend)**

```typescript
// Browser localStorage
interface ChatHistory {
  id: string;               // chat_<timestamp>_<random>
  title: string;            // First 50 chars of first message
  timestamp: Date;
  messages: AgentMessage[];
  pinned?: boolean;
}

// Persistence
localStorage.setItem("chatHistory", JSON.stringify(chatHistory));
```

---

## 🎨 Key Design Patterns

### 1. **Flattened Graph Architecture**

**Why:** AG-UI needs visibility into each node's output for real-time streaming.

```python
# Before (Subgraph - Opaque)
graph.add_node("node2", node2_subgraph)  # Black box

# After (Flattened - Transparent)
graph.add_node("normalize_query", normalize_query_node)
graph.add_node("domain_validation", domain_validation_node)
graph.add_node("intent", intent_node)
graph.add_node("mapping", mapping_node)
graph.add_node("sheet_selector", sheet_selector_node)
```

**Result:** Each node emits STATE_SNAPSHOT → Frontend sees progress in real-time.

### 2. **State Wrapper Pattern**

**Why:** Preserve critical fields through node execution.

```python
def wrapper(state):
    result = original_node(state)
    # Explicitly preserve fields
    for field in ["mapping_result", "multi_month_registry"]:
        if field in state and field not in result:
            result[field] = state[field]
    return result
```

**Ensures:** Multi-month registry, mapping results, etc. propagate through pipeline.

### 3. **Event Filtering Pattern**

**Why:** Reduce payload size and prevent client overload.

```python
def _filter_stream_event(event):
    # Drop RAW events (internal only)
    if event_type == "RAW":
        return None
    
    # Sanitize STATE_SNAPSHOT (keep display fields only)
    if event_type == "STATE_SNAPSHOT":
        return StateSnapshotEvent(
            snapshot=_sanitize_snapshot(event.snapshot)
        )
```

**Result:** Only relevant data streamed to frontend.

### 4. **Lazy Graph Loading**

**Why:** Speed up container startup.

```python
_agui_graph = None
async def get_graph():
    global _agui_graph
    if _agui_graph is None:
        _agui_graph = await build_agui_graph()
    return _agui_graph
```

**Result:** Graph compiled on first request, not startup.

### 5. **ThreadId Injection Pattern**

**Why:** AG-UI keeps threadId separate from state, but we need it for memory.

```python
# Server injects threadId into state
if run_input.state is None:
    run_input.state = {}
run_input.state["threadId"] = run_input.thread_id

# Node accesses it
thread_id = state.get("threadId")
memory_session_id = thread_id
```

**Result:** Memory operations can associate Q&A with thread.

---

## 🔍 Debugging & Observability

### **Log Locations**

| Component | Log File | Format |
|-----------|----------|--------|
| Backend | `context_enrichment_debug.log` | Structured (Python logging) |
| Backend | `server.log` | Standard output |
| Frontend API | Next.js console | Structured JSON |
| Frontend UI | Browser console | Debug messages |

### **Key Log Events**

```python
# Backend
logger.info("[INVOCATIONS] Request received")
logger.info(f"🔵 NEW REQUEST: threadId={...}")
logger.info("[GRAPH] Complete")

# Frontend API Route
console.log('[Excel Agent] Request:', { threadId, runId })
console.log('[Excel Agent] Response status:', response.status)

# Frontend Service
console.log('State snapshot:', event.snapshot)
console.warn('Failed to parse SSE event:', error)
```

### **State Visibility**

```typescript
// Frontend can inspect state snapshots
if (event.type === "STATE_SNAPSHOT" && event.snapshot) {
  console.log("Domain validation:", event.snapshot.domain_validation);
  console.log("Analysis spec:", event.snapshot.analysis_spec);
  console.log("Mapping result:", event.snapshot.mapping_result);
  console.log("Multi-month registry:", event.snapshot.multi_month_registry);
}
```

---

## 🚀 Deployment Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     AWS CLOUD                                │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  AWS Bedrock AgentCore Runtime                         │ │
│  │  ARN: arn:aws:bedrock-agentcore:eu-west-1:...:runtime │ │
│  │  • Manages agent lifecycle                             │ │
│  │  • Routes requests to backend                          │ │
│  │  • Handles state persistence                           │ │
│  └────────────────────────────────────────────────────────┘ │
│                          ↓                                   │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Backend Container (Docker)                            │ │
│  │  • FastAPI application (agui_server_aws.py)            │ │
│  │  • LangGraph pipeline                                  │ │
│  │  • Port: 8080                                          │ │
│  │  • Image: mbr-excel-agent:latest                       │ │
│  └────────────────────────────────────────────────────────┘ │
│                          ↓                                   │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Amazon S3                                             │ │
│  │  Bucket: mbr-data-lake                                 │ │
│  │  • /raw_data/ - Excel files                            │ │
│  │  • /analysis-output/ - Results                         │ │
│  │  • /metadata/static/ - Glossary                        │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              ↕
                    HTTPS (SigV4 signed)
                              ↕
┌─────────────────────────────────────────────────────────────┐
│              NEXT.JS APPLICATION (Vercel/AWS)                │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Next.js 15 (React 19)                                 │ │
│  │  • Server-side API routes                              │ │
│  │  • Client-side React components                        │ │
│  │  • SSR + Client-side rendering                         │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## 📝 Configuration Files

### **Backend**

- `agui_server_aws.py` - FastAPI server
- `agui/graph_wrapper.py` - Graph builder
- `core/settings.py` - Environment config
- `Dockerfile` - Container definition

### **Frontend**

- `src/app/api/excel-agent/route.ts` - API handler
- `src/services/excel-agent-service.ts` - Service layer
- `src/app/page.tsx` - Main chat UI
- `src/lib/agentcore-config.ts` - AgentCore config
- `next.config.ts` - Next.js config

---

## 🎯 Key Metrics

| Metric | Value | Note |
|--------|-------|------|
| **Graph Nodes** | 15 | Flattened architecture |
| **Recursion Limit** | 50 | Set in agent config |
| **State Fields** | 35+ | Tracked in AGUIExcelState |
| **Event Types** | 7 | AG-UI protocol |
| **SSE Events/Request** | 20-50 | Depends on pipeline |
| **Avg Response Time** | 30-60s | Full pipeline |

---

## 🔧 Troubleshooting Guide

### Common Issues

| Issue | Cause | Solution |
|-------|-------|----------|
| **No STATE_SNAPSHOT events** | Node not returning dict | Ensure node returns `Dict[str, Any]` |
| **Missing multi_month_registry** | Not preserved through nodes | Use wrapper pattern |
| **threadId not available** | Not injected by server | Check server injection logic |
| **SSE parsing errors** | Malformed JSON | Check EventEncoder output |
| **401 Unauthorized** | Invalid AWS credentials | Verify ENV vars |
| **504 Gateway Timeout** | AgentCore timeout | Check backend health |

---

## 📚 Further Reading

- [AG-UI Protocol Documentation](https://docs.aws.amazon.com/bedrock/agentcore/)
- [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)
- [FastAPI Streaming](https://fastapi.tiangolo.com/advanced/custom-response/#streamingresponse)
- [Server-Sent Events (SSE)](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events)
- [AWS SigV4 Signing](https://docs.aws.amazon.com/general/latest/gr/signature-version-4.html)

---

**Generated:** 2025-05-25  
**Architecture Version:** 2.0 (Flattened + Context Enrichment)  
**Status:** ✅ Production Ready
