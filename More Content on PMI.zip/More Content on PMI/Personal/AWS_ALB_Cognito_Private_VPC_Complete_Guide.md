# Implementing AWS ALB with Cognito Authentication in a Private VPC: A Complete Guide

**A deep dive into building secure, internal applications with AWS Application Load Balancer and Cognito authentication in enterprise environments**

**Author:** DevOps Team  
**Date:** June 23, 2026  
**Application:** LokI (InsightsIQ)  
**Document Version:** 1.0

---

## Table of Contents

1. [Introduction](#introduction)
2. [Business Requirements](#business-requirements)
3. [Architecture Overview](#architecture-overview)
4. [Phase 1: Setting Up Private ALB Infrastructure](#phase-1-setting-up-private-alb-infrastructure)
5. [Phase 2: Connecting ALB to EC2 Application](#phase-2-connecting-alb-to-ec2-application)
6. [Phase 3: Implementing Cognito Authentication](#phase-3-implementing-cognito-authentication)
7. [The Challenge: Corporate SSL Inspection](#the-challenge-corporate-ssl-inspection)
8. [Understanding AWS Managed Services](#understanding-aws-managed-services)
9. [Solutions and Workarounds](#solutions-and-workarounds)
10. [Lessons Learned](#lessons-learned)
11. [Conclusion](#conclusion)

---

<a name="introduction"></a>
## 1. Introduction

This article documents our journey implementing a secure, internal business intelligence application using AWS services in an enterprise environment with strict security policies. We'll cover everything from initial requirements through infrastructure setup, to the unexpected challenges we encountered with corporate network security.

**Key Technologies:**
- AWS Application Load Balancer (ALB)
- AWS Cognito User Pools
- Amazon EC2 (Windows)
- AWS Transit Gateway
- Private Subnets & VPC
- Corporate VPN Integration

**Target Audience:**
- Cloud architects designing internal applications
- DevOps engineers implementing AWS infrastructure
- Security teams evaluating authentication approaches
- Anyone facing similar SSL inspection challenges

---

<a name="business-requirements"></a>
## 2. Business Requirements

### 2.1 Application Overview

**Name:** LokI (InsightsIQ)  
**Purpose:** AI-powered business intelligence dashboard providing real-time insights for PMI India operations  
**Technology Stack:**
- Frontend: Next.js 15.5.9 (React)
- Backend: Node.js
- Database: RDS/DynamoDB (not covered in this article)
- Runtime: AWS Bedrock AgentCore for AI processing

### 2.2 Security Requirements

Our application had strict security requirements driven by enterprise policies:

1. **No Public Internet Access**
   - Application must be accessible only via corporate VPN
   - No public-facing endpoints
   - All resources in private subnets

2. **Strong Authentication**
   - Multi-factor authentication capability
   - Integration with corporate identity systems (future)
   - Session management and timeout controls
   - Centralized user management

3. **Network Isolation**
   - Private VPC with no internet gateway access for application subnets
   - Traffic routing through Transit Gateway only
   - Service Control Policies (SCP) prevent creation of public resources
   - Comply with corporate network architecture standards

4. **Encryption in Transit**
   - All traffic must use HTTPS/TLS
   - Use AWS Certificate Manager for certificate management
   - Private CA certificates for internal domains

### 2.3 Access Requirements

**User Base:**
- 500+ internal PMI employees
- Access via corporate VPN only
- VPN CIDR range: 10.4.0.0/14

**Access Pattern:**
```
PMI Employee → Corporate VPN → AWS VPC → Application
```

### 2.4 Why Choose ALB + Cognito?

After evaluating options, we chose Application Load Balancer with Cognito authentication because:

**Benefits:**
- ✅ **Centralized Authentication:** ALB handles auth before traffic reaches application
- ✅ **Reduced Application Complexity:** No authentication code needed in Next.js app
- ✅ **AWS-Native:** Seamless integration with AWS services
- ✅ **Scalability:** ALB auto-scales to handle load
- ✅ **Security:** Layer 7 protection, WAF integration capability
- ✅ **Future-Proof:** Easy to add SAML/OIDC federation later

**Alternatives Considered:**

| **Approach** | **Pros** | **Cons** | **Decision** |
|-------------|----------|----------|--------------|
| Application-level auth | Full control | More code complexity | ❌ Rejected |
| API Gateway + Lambda Authorizer | Serverless | More latency | ❌ Rejected |
| VPN-only (no auth) | Simple | No user tracking | ❌ Rejected |
| **ALB + Cognito** | Balance of simplicity & features | Requires VPC connectivity | ✅ **Selected** |

---

<a name="architecture-overview"></a>
## 3. Architecture Overview

### 3.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Corporate Network                            │
│                                                                 │
│  ┌──────────────┐                                              │
│  │ PMI Employee │                                              │
│  │   (Laptop)   │                                              │
│  └──────┬───────┘                                              │
│         │ VPN Connection                                       │
│         │ (10.4.0.0/14)                                        │
└─────────┼──────────────────────────────────────────────────────┘
          │
          │ HTTPS Request
          ▼
┌─────────────────────────────────────────────────────────────────┐
│                         AWS VPC                                 │
│                   vpc-0ff70419790990b15                         │
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐   │
│  │              Private Subnet AZ-A                       │   │
│  │              172.23.193.0/26                           │   │
│  │                                                        │   │
│  │  ┌──────────────────────────────────────────────┐    │   │
│  │  │   Application Load Balancer (Internal)       │    │   │
│  │  │   IP: 172.23.193.38                          │    │   │
│  │  │   - HTTPS Listener (443)                     │    │   │
│  │  │   - Cognito Authentication                   │    │   │
│  │  │   - Private ACM Certificate                  │    │   │
│  │  └───────────────┬──────────────────────────────┘    │   │
│  │                  │ HTTP (9006)                        │   │
│  │                  ▼                                     │   │
│  │  ┌──────────────────────────────────────────────┐    │   │
│  │  │   EC2 Instance (Windows)                     │    │   │
│  │  │   IP: 172.30.227.38                          │    │   │
│  │  │   - Next.js Application (Port 9006)          │    │   │
│  │  │   - Node.js Runtime                          │    │   │
│  │  └──────────────────────────────────────────────┘    │   │
│  └────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌────────────────────────────────────────────────────┐   │
│  │              Private Subnet AZ-B                   │   │
│  │              172.23.193.64/26                      │   │
│  │                                                    │   │
│  │  ┌──────────────────────────────────────────┐    │   │
│  │  │   Application Load Balancer (Internal)   │    │   │
│  │  │   IP: 172.23.193.70                      │    │   │
│  │  └──────────────────────────────────────────┘    │   │
│  └────────────────────────────────────────────────┘   │
│                                                         │
└─────────────────────┬───────────────────────────────────┘
                      │
                      │ Transit Gateway
                      │ tgw-0749c3302c164e63f
                      ▼
         ┌────────────────────────────┐
         │   Corporate Network        │
         │   (Security Appliances)    │
         └────────────┬───────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │     AWS Cognito            │
         │     (Managed Service)      │
         │  eu-west-1aoqykyr97.auth   │
         │  .eu-west-1.amazoncognito  │
         │  .com                      │
         │  IP: 52.19.14.243          │
         └────────────────────────────┘
```

### 3.2 Network Flow

**User Access Flow:**
```
1. User → VPN → ALB → EC2 Application
   ✅ Works: User can reach ALB via VPN

2. ALB → Cognito (Initial Redirect)
   ✅ Works: Browser redirects to Cognito login page

3. User → Cognito (Authentication)
   ✅ Works: User enters credentials, Cognito validates

4. Cognito → ALB (Callback with auth code)
   ✅ Works: Cognito redirects back to ALB with code

5. ALB → Cognito (Token Exchange - Backend API Call)
   ❌ FAILS: This is where our problem occurs
```

### 3.3 AWS Resources Summary

| **Resource** | **Type** | **ID/Name** | **Purpose** |
|--------------|----------|-------------|-------------|
| VPC | Private Network | vpc-0ff70419790990b15 | Network isolation |
| Subnet AZ-A | Private /26 | subnet-0a427a11dc0db7015 | ALB primary zone |
| Subnet AZ-B | Private /26 | subnet-06677e7ba712c89b3 | ALB secondary zone |
| ALB | Internal | mmiana-dev-alb | Load balancing & auth |
| EC2 | Windows t3.large | i-00abecfc4fed52a25 | Application server |
| Cognito User Pool | Managed | eu-west-1_AOqyKyR97 | User management |
| ACM Certificate | Private CA | aa754ade-50cf... | HTTPS encryption |
| Transit Gateway | Shared | tgw-0749c3302c164e63f | Corporate routing |

---

<a name="phase-1-setting-up-private-alb-infrastructure"></a>
## 4. Phase 1: Setting Up Private ALB Infrastructure

### 4.1 VPC and Subnet Design

Our VPC was provisioned by a baseline Terraform module following enterprise standards:

**VPC Configuration:**
```hcl
# Baseline VPC Configuration
vpc_cidr = "172.30.227.0/24"
vpc_name = "pmi-app-mmiana-dev"

# Subnets across availability zones
private_subnets = [
  "172.30.227.32/28",   # Private AZ-A (small)
  "172.30.227.48/28",   # Private AZ-B (small)
  "172.23.193.0/26",    # Private AZ-A (ALB) - 59 IPs
  "172.23.193.64/26",   # Private AZ-B (ALB) - 59 IPs
]

public_subnets = [
  "172.30.227.64/28",   # Public AZ-A (management only)
  "172.30.227.80/28",   # Public AZ-B (management only)
]
```

**Key Design Decisions:**

1. **Why /26 subnets for ALB?**
   - ALB requires minimum 8 IPs per subnet
   - /28 subnets (11 usable IPs) are too small
   - /26 provides 59 usable IPs - sufficient for ALB scaling
   - Best practice: ALB subnet sizing

2. **Why multiple availability zones?**
   - High availability requirement
   - ALB requires minimum 2 AZs
   - Automatic failover if one AZ fails

3. **Why separate subnet tiers?**
   - Smaller subnets (/28) for EC2 instances
   - Larger subnets (/26) for ALB (higher IP requirements)
   - Clear network segmentation

### 4.2 Creating the Application Load Balancer

**Terraform Configuration:**

```hcl
# alb.tf
resource "aws_lb" "internal_alb" {
  name               = "mmiana-dev-alb"
  internal           = true                    # ← CRITICAL: Internal only
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb_sg.id]
  
  # Use /26 subnets only (indices 2 and 3 in our subnet list)
  subnets = slice(
    data.terraform_remote_state.app-baseline.outputs.private_subnets_primary,
    2,
    4
  )

  enable_deletion_protection = false           # Dev environment
  enable_http2               = true
  idle_timeout               = 60

  tags = {
    Name        = "mmiana-dev-alb"
    Environment = "dev"
  }
}
```

**Why Internal ALB?**

| **Feature** | **Internet-Facing** | **Internal** |
|-------------|---------------------|--------------|
| Public IP | ✅ Yes | ❌ No |
| DNS Name | Public | Private |
| Accessibility | Internet | VPC/VPN only |
| Use Case | Public websites | Internal apps |
| **Our Choice** | ❌ Not allowed | ✅ **Selected** |

**Key Considerations:**
- `internal = true` - ALB only gets private IPs (172.23.193.38, 172.23.193.70)
- No public DNS name assigned
- Only accessible from within VPC or via VPN
- Complies with SCP policies (no public resources)

### 4.3 ALB Security Groups

Security groups control network access at Layer 4 (IP and port level).

**ALB Security Group:**

```hcl
# alb_security_groups.tf
resource "aws_security_group" "alb_sg" {
  name_prefix = "internal-alb-sg"
  description = "Security group for internal ALB"
  vpc_id      = data.terraform_remote_state.app-baseline.outputs.vpc_id_primary

  # Inbound: Allow HTTP from VPN clients
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["10.4.0.0/14"]              # VPN range
    description = "Allow HTTP from VPN clients"
  }

  # Inbound: Allow HTTPS from VPN clients
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.4.0.0/14"]              # VPN range
    description = "Allow HTTPS from VPN clients"
  }

  # Outbound: Allow all traffic (ALB needs to reach EC2 and Cognito)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound traffic"
  }

  tags = {
    Name = "mmiana-dev-alb-sg"
  }
}
```

**Security Group Design Rationale:**

1. **Inbound Rules:**
   - Only allow VPN CIDR (10.4.0.0/14)
   - Blocks any traffic from outside corporate network
   - Allows both HTTP (80) and HTTPS (443)
   - HTTP redirects to HTTPS (configured in listener)

2. **Outbound Rules:**
   - Allow all outbound (0.0.0.0/0)
   - ALB needs to reach:
     - EC2 instances (port 9006)
     - AWS Cognito (port 443)
     - Health check endpoints
   - Specific outbound rules not needed (private subnet provides isolation)

### 4.4 SSL/TLS Certificates

For internal applications, we use AWS Certificate Manager Private Certificate Authority.

**Why Private CA?**

| **Certificate Type** | **Public ACM** | **Private ACM** |
|---------------------|----------------|-----------------|
| Cost | Free | $400/month for CA + per-cert fees |
| Domain Validation | DNS/Email | None required |
| Trust | Public browsers | Must distribute root CA |
| Use Case | Public websites | Internal apps |
| **Our Choice** | ❌ Won't work | ✅ **Selected** |

**Certificate Configuration:**

```hcl
# acm_certificate.tf
# Get Private CA ARN from baseline
locals {
  private_ca_arn = try(
    data.terraform_remote_state.app-baseline.outputs.acm["eu-west-1"]["private_certificate_authority_arn"],
    null
  )
}

# Create ACM Private Certificate
resource "aws_acm_certificate" "app" {
  domain_name               = "${var.app_subdomain}.${data.terraform_remote_state.app-baseline.outputs.route53_acn_pvt_zone_name}"
  certificate_authority_arn = local.private_ca_arn

  lifecycle {
    create_before_destroy = true
  }

  tags = {
    Name = "mmiana-dev-private-acm-cert"
  }
}

# Variables
variable "app_subdomain" {
  default = "loki"
}

# Resulting domain: loki.mmiana-dev.aws.private-pmideep.biz
```

**Certificate Trust Chain:**

```
Root CA: PMI AWS Private CA
  ↓
Intermediate CA: (if any)
  ↓
Application Certificate: loki.mmiana-dev.aws.private-pmideep.biz
```

**Client Trust:**
- Root CA certificate pre-installed on PMI corporate laptops
- Managed by IT via Group Policy or MDM
- Users don't see certificate warnings

### 4.5 Route53 DNS Configuration

We use Private Hosted Zones for internal DNS resolution.

```hcl
# route53_records.tf
resource "aws_route53_record" "app" {
  zone_id = data.terraform_remote_state.app-baseline.outputs.route53_acn_pvt_zone_id
  name    = "${var.app_subdomain}.${data.terraform_remote_state.app-baseline.outputs.route53_acn_pvt_zone_name}"
  type    = "A"

  # Alias record pointing to ALB
  alias {
    name                   = aws_lb.internal_alb.dns_name
    zone_id                = aws_lb.internal_alb.zone_id
    evaluate_target_health = true
  }
}

# Output
output "application_url" {
  value = "https://${var.app_subdomain}.${data.terraform_remote_state.app-baseline.outputs.route53_acn_pvt_zone_name}"
}
# Result: https://loki.mmiana-dev.aws.private-pmideep.biz
```

**DNS Resolution Flow:**

```
User browser: loki.mmiana-dev.aws.private-pmideep.biz
        ↓
VPN DNS Server: Queries Route53 Private Hosted Zone
        ↓
Route53: Returns ALB alias (internal-mmiana-dev-alb-1359093552.eu-west-1.elb.amazonaws.com)
        ↓
AWS DNS: Resolves to ALB IPs (172.23.193.38, 172.23.193.70)
        ↓
User browser: Connects to 172.23.193.38:443
```

---

<a name="phase-2-connecting-alb-to-ec2-application"></a>
## 5. Phase 2: Connecting ALB to EC2 Application

### 5.1 EC2 Instance Setup

**Instance Specifications:**

```yaml
Instance Type: t3.large
Operating System: Windows Server 2022
Private IP: 172.30.227.38
Subnet: subnet-090fe96cd60afa5cf (172.30.227.32/28)
Security Group: sg-02268adcda33c5b0a
```

**Application Stack:**
- **Runtime:** Node.js 18.x
- **Framework:** Next.js 15.5.9
- **Startup Command:** `npm start`
- **Listen Address:** `0.0.0.0:9006`
- **Process Management:** Manual (future: Windows Service)

**Why Windows EC2?**
- Development team familiar with Windows
- Existing corporate Windows management tools
- RDP access for troubleshooting
- Future: Migrate to Linux for cost optimization

### 5.2 Application Configuration

**Next.js Configuration (package.json):**

```json
{
  "name": "nextn",
  "version": "0.1.0",
  "scripts": {
    "dev": "next dev -p 9006",
    "build": "next build",
    "start": "next start -p 9006",
    "lint": "next lint"
  }
}
```

**Application Startup Output:**

```
C:\code\agentcore-june\agentcore> npm start

> nextn@0.1.0 start
> next start

  ▲ Next.js 15.5.9
  - Local:        http://localhost:9006
  - Network:      http://172.30.227.38:9006

  ✓ Ready in 1883ms
```

**Key Points:**
- Application listens on `0.0.0.0:9006` (all network interfaces)
- Binds to EC2 private IP (172.30.227.38)
- Plain HTTP (no TLS) - ALB terminates SSL
- No authentication logic in application code

### 5.3 Target Group Configuration

Target groups define how ALB routes traffic to backend instances.

```hcl
# alb_target_group.tf
resource "aws_lb_target_group" "app" {
  name_prefix = "mmiana"
  port        = 9006
  protocol    = "HTTP"
  vpc_id      = data.terraform_remote_state.app-baseline.outputs.vpc_id_primary
  target_type = "instance"

  # Health Check Configuration
  health_check {
    enabled             = true
    healthy_threshold   = 2
    unhealthy_threshold = 2
    timeout             = 5
    interval            = 30
    path                = "/"
    protocol            = "HTTP"
    matcher             = "200"
  }

  deregistration_delay = 30

  # Session stickiness (optional)
  stickiness {
    enabled         = false
    type            = "lb_cookie"
    cookie_duration = 86400
  }

  tags = {
    Name = "mmiana-dev-tg"
  }
}

# Register EC2 instance to target group
resource "aws_lb_target_group_attachment" "app" {
  target_group_arn = aws_lb_target_group.app.arn
  target_id        = "i-00abecfc4fed52a25"
  port             = 9006
}
```

**Health Check Behavior:**

```
ALB sends:
  GET / HTTP/1.1
  Host: 172.30.227.38:9006
  User-Agent: ELB-HealthChecker/2.0

Application responds:
  HTTP/1.1 200 OK
  Content-Type: text/html
  
ALB marks target: ✅ Healthy
```

### 5.4 EC2 Security Group Configuration

EC2 security group allows traffic only from ALB.

```hcl
# alb_security_groups.tf (continued)
# Security Group Rule for EC2 - Allow traffic from ALB
resource "aws_security_group_rule" "ec2_from_alb" {
  type                     = "ingress"
  from_port                = 9006
  to_port                  = 9006
  protocol                 = "tcp"
  security_group_id        = var.ec2_security_group_id
  source_security_group_id = aws_security_group.alb_sg.id
  description              = "Allow traffic from ALB to EC2 application port 9006"
}
```

**Security Group Chaining:**

```
User (10.4.1.50)
    ↓
ALB Security Group:
  Inbound: 10.4.0.0/14 → Port 443 ✅ ALLOWED
    ↓
ALB forwards to EC2
    ↓
EC2 Security Group:
  Inbound: ALB SG → Port 9006 ✅ ALLOWED
    ↓
Application receives request
```

**Defense in Depth:**
- Users can only reach ALB (not EC2 directly)
- EC2 only accepts traffic from ALB
- If ALB is compromised, EC2 still protected by its SG

### 5.5 ALB Listeners

Listeners define how ALB handles incoming connections.

**HTTP Listener (Port 80) - Redirect to HTTPS:**

```hcl
# alb.tf (continued)
resource "aws_lb_listener" "http_listener" {
  load_balancer_arn = aws_lb.internal_alb.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"
    
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }

  tags = {
    Name = "mmiana-dev-http-listener"
  }
}
```

**HTTPS Listener (Port 443) - Forward to Target Group:**

```hcl
resource "aws_lb_listener" "https_listener" {
  load_balancer_arn = aws_lb.internal_alb.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = aws_acm_certificate.app.arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.app.arn
  }

  tags = {
    Name = "mmiana-dev-https-listener"
  }
}
```

**SSL Policy Explanation:**

```
ELBSecurityPolicy-TLS13-1-2-2021-06:
- TLS 1.3 supported ✅
- TLS 1.2 supported ✅
- TLS 1.1 disabled ❌
- TLS 1.0 disabled ❌
- Strong cipher suites only
- Perfect Forward Secrecy (PFS)
```

### 5.6 Testing ALB to EC2 Connectivity

**Verification Steps:**

**1. Check Target Health:**

```bash
aws elbv2 describe-target-health \
  --target-group-arn arn:aws:elasticloadbalancing:eu-west-1:986995923613:targetgroup/mmiana20260621105109513200000001/d5e67c5efc8dbeb1 \
  --region eu-west-1

# Result:
Target: i-00abecfc4fed52a25
Health: ✅ healthy
Port: 9006
```

**2. Test from VPN Client:**

```powershell
# From PMI laptop connected to VPN
PS> Invoke-WebRequest https://loki.mmiana-dev.aws.private-pmideep.biz

StatusCode        : 200
StatusDescription : OK
Content           : <!DOCTYPE html><html>...</html>
```

**3. Verify Traffic Flow:**

```
User Browser (10.4.1.50)
    ↓ HTTPS (TLS 1.3)
ALB (172.23.193.38:443)
    ↓ SSL Termination
    ↓ HTTP (plaintext)
EC2 (172.30.227.38:9006)
    ↓ Next.js processes request
    ↓ HTTP Response
ALB (wraps in TLS)
    ↓ HTTPS
User Browser (sees encrypted response)
```

**Result at this stage:**
- ✅ VPN users can access application
- ✅ HTTPS working with private certificate
- ✅ ALB → EC2 connectivity working
- ✅ Health checks passing
- ❌ No authentication yet (anyone on VPN can access)

---

<a name="phase-3-implementing-cognito-authentication"></a>
## 6. Phase 3: Implementing Cognito Authentication

### 6.1 Why ALB-Level Authentication?

We chose to implement authentication at the ALB level rather than in application code.

**Comparison:**

| **Aspect** | **Application-Level** | **ALB-Level** |
|------------|---------------------|---------------|
| Code complexity | High - SDK integration | Low - infrastructure config |
| Application changes | Significant | None |
| Session management | Custom implementation | Managed by ALB |
| Token validation | Application responsibility | ALB handles |
| Performance | Additional latency | Minimal overhead |
| Security | Depends on implementation | AWS-managed |
| **Our Choice** | ❌ | ✅ **Selected** |

**Benefits of ALB Authentication:**
1. **Zero Code Changes:** Application doesn't need Cognito SDK
2. **Centralized Security:** Authentication enforced before app reached
3. **Simplified Application:** App just receives authenticated requests
4. **User Info in Headers:** ALB passes identity in HTTP headers
5. **Future Federation:** Easy to add SAML/OIDC providers later

### 6.2 Creating Cognito User Pool

```hcl
# cognito.tf
resource "aws_cognito_user_pool" "main" {
  name = "InsightsIQ-Users"

  # Password policy
  password_policy {
    minimum_length    = 8
    require_uppercase = true
    require_lowercase = true
    require_numbers   = true
    require_symbols   = true
    temporary_password_validity_days = 7
  }

  # Auto-verified attributes
  auto_verified_attributes = ["email"]

  # Username configuration
  username_attributes = ["email"]
  username_configuration {
    case_sensitive = false
  }

  tags = {
    Name        = "mmiana-dev-user-pool"
    Environment = "dev"
  }
}

# User Pool Domain for Hosted UI
resource "aws_cognito_user_pool_domain" "main" {
  domain       = "mmiana-dev-${random_string.suffix.result}"
  user_pool_id = aws_cognito_user_pool.main.id
}
```

**User Pool Created:**
- ID: `eu-west-1_AOqyKyR97`
- Domain: `eu-west-1aoqykyr97.auth.eu-west-1.amazoncognito.com`
- Region: `eu-west-1`

### 6.3 Creating App Client for ALB

```hcl
resource "aws_cognito_user_pool_client" "alb" {
  name         = "InsightsIQ-Web-App-ALB"
  user_pool_id = aws_cognito_user_pool.main.id

  # CRITICAL: Must have client secret for ALB integration
  generate_secret = true

  # OAuth settings
  allowed_oauth_flows_user_pool_client = true
  allowed_oauth_flows                  = ["code"]
  allowed_oauth_scopes                 = ["openid", "email", "profile"]

  # Callback URLs (ALB OAuth endpoint)
  callback_urls = [
    "https://loki.mmiana-dev.aws.private-pmideep.biz/oauth2/idpresponse"
  ]

  # Logout URLs
  logout_urls = [
    "https://loki.mmiana-dev.aws.private-pmideep.biz"
  ]

  # Supported identity providers
  supported_identity_providers = ["COGNITO"]

  # Token validity
  access_token_validity  = 60
  id_token_validity      = 60
  refresh_token_validity = 5

  token_validity_units {
    access_token  = "minutes"
    id_token      = "minutes"
    refresh_token = "days"
  }
}
```

**App Client Created:**
- Client ID: `7stabgtmfgguk9e0bqders1opa`
- Callback: `https://loki.mmiana-dev.aws.private-pmideep.biz/oauth2/idpresponse`

### 6.4 Updating ALB Listener with Cognito

```hcl
resource "aws_lb_listener" "https_listener" {
  load_balancer_arn = aws_lb.internal_alb.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = aws_acm_certificate.app.arn

  # ACTION 1: Authenticate with Cognito (Order 1)
  default_action {
    type  = "authenticate-cognito"
    order = 1

    authenticate_cognito {
      user_pool_arn       = aws_cognito_user_pool.main.arn
      user_pool_client_id = aws_cognito_user_pool_client.alb.id
      user_pool_domain    = aws_cognito_user_pool_domain.main.domain
      
      session_cookie_name = "AWSELBAuthSessionCookie"
      session_timeout     = 604800
      scope               = "openid"
      on_unauthenticated_request = "authenticate"
    }
  }

  # ACTION 2: Forward to Target Group (Order 2)
  default_action {
    type             = "forward"
    order            = 2
    target_group_arn = aws_lb_target_group.app.arn
  }
}
```

**Action Order Matters:**

```
Request arrives at ALB
    ↓
ACTION 1 (Order 1): authenticate-cognito
  - Check for valid session cookie
  - If no cookie → Redirect to Cognito
  - If cookie → Validate and proceed
    ↓
ACTION 2 (Order 2): forward
  - Send to target group
  - Add authentication headers
```

### 6.5 OAuth 2.0 Authorization Code Flow

**Complete Flow:**

```
┌─────────────┐
│   Browser   │
└──────┬──────┘
       │ 1. GET https://loki.mmiana-dev.aws.private-pmideep.biz
       ▼
┌─────────────────────────────────────────┐
│            ALB                          │
│  - Checks for session cookie            │
│  - No cookie found                      │
└──────┬──────────────────────────────────┘
       │ 2. 302 Redirect to Cognito
       ▼
┌─────────────────────────────────────────┐
│        Cognito Hosted UI                │
│  - Shows login page                     │
│  - User enters email/password           │
└──────┬──────────────────────────────────┘
       │ 3. 302 Redirect back to ALB
       ▼
┌─────────────────────────────────────────┐
│            ALB                          │
│  - Receives authorization code          │
│  ❌ FAILS HERE ❌                        │
│  - Needs to exchange code for tokens    │
│  - Backend POST to Cognito fails        │
└──────┬──────────────────────────────────┘
       │ 4. 500 Internal Server Error
       ▼
┌─────────────┐
│   Browser   │
└─────────────┘
```

---

<a name="the-challenge-corporate-ssl-inspection"></a>
## 7. The Challenge: Corporate SSL Inspection

### 7.1 The Problem Discovered

After deploying the infrastructure and configuring Cognito authentication, we encountered an unexpected issue during testing.

**Symptom:**
```
User attempts to log in → 500 Internal Server Error
```

**Initial Troubleshooting:**

```powershell
# Check target health
aws elbv2 describe-target-health --target-group-arn <arn>
Result: ✅ Target is healthy

# Check application logs on EC2
PS C:\code\agentcore-june> npm start logs
Result: ✅ No errors, no requests received

# Check ALB logs
Result: ❌ Not enabled
```

**Key Observation:**
- Application receives NO traffic during failed authentication
- Target health checks still passing
- Error occurs BEFORE request reaches application

**Conclusion:** Problem is at ALB level, not application.

### 7.2 Network Connectivity Testing

**Test 1: TCP Connectivity**

```powershell
PS> Test-NetConnection eu-west-1aoqykyr97.auth.eu-west-1.amazoncognito.com -Port 443

ComputerName     : eu-west-1aoqykyr97.auth.eu-west-1.amazoncognito.com
RemoteAddress    : 52.19.14.243
RemotePort       : 443
SourceAddress    : 172.30.227.38
TcpTestSucceeded : True   ✅
```

**Analysis:**
- ✅ DNS resolution works
- ✅ TCP connection succeeds
- ✅ Port 443 is open
- ✅ Network routing is correct

**Test 2: HTTPS Request**

```powershell
PS> curl https://eu-west-1aoqykyr97.auth.eu-west-1.amazoncognito.com/oauth2/token

curl : The underlying connection was closed: 
       An unexpected error occurred on a send.
```

**Analysis:**
- ✅ TCP connection established
- ❌ SSL/TLS handshake fails
- ❌ Connection closed during handshake

**Conclusion:**
- Network Layer (L3/L4): ✅ Working
- Application Layer (L7): ❌ Failing
- Specific Issue: SSL/TLS handshake

### 7.3 Understanding the Traffic Path

**Path from ALB to Cognito:**

```
┌─────────────────────────────────────────────────┐
│                    AWS VPC                      │
│                                                 │
│  ALB (172.23.193.38)                           │
│  Needs to reach: 52.19.14.243 (Cognito)       │
└────────────────────┬────────────────────────────┘
                     │
                     │ Route: 0.0.0.0/0 → TGW
                     ▼
         ┌──────────────────────────────┐
         │    Transit Gateway            │
         │    tgw-0749c3302c164e63f      │
         └──────────────┬───────────────┘
                        │
                        ▼
         ┌──────────────────────────────┐
         │    Corporate Network          │
         │  ┌──────────────────────┐    │
         │  │  Firewall/Proxy      │    │
         │  │  - SSL Inspection ON │    │
         │  │  - Decrypts HTTPS    │    │
         │  │  - Replaces certs    │    │
         │  └──────────┬───────────┘    │
         └─────────────┼─────────────────┘
                       │
                       ▼
              ┌─────────────────┐
              │   AWS Cognito   │
              │   52.19.14.243  │
              └─────────────────┘
```

### 7.4 What is SSL/TLS Inspection?

**Normal HTTPS (No Inspection):**

```
Client                          Server
  │                               │
  │──── ClientHello (TLS) ───────│
  │                               │
  │───── ServerHello + Cert ─────│
  │    (Server's certificate)     │
  │                               │
  │── Verify cert + Key Exchange ─│
  │                               │
  │════ Encrypted traffic ════════│
```

**With SSL Inspection (Man-in-the-Middle):**

```
Client              Firewall              Server
  │                    │                    │
  │── ClientHello ────│                    │
  │                    │─── ClientHello ───│
  │                    │                    │
  │                    │─── ServerHello ───│
  │                    │  (Real AWS cert)  │
  │                    │                    │
  │                    │ Firewall validates │
  │                    │ real certificate   │
  │                    │                    │
  │── ServerHello ────│                    │
  │ (Corporate cert!) │                    │
  │                    │                    │
  │ Client receives   │                    │
  │ WRONG certificate │                    │
  │                    │                    │
  ✗ Connection fails  │                    │
```

### 7.5 Why Corporate SSL Inspection Breaks AWS Cognito

**The Certificate Chain Problem:**

**Cognito's Certificate (Expected):**

```
Root CA: Amazon Root CA 1
  ↓ (signs)
Intermediate CA: Amazon RSA 2048 M01
  ↓ (signs)
Server Certificate: *.auth.eu-west-1.amazoncognito.com
  Subject: *.auth.eu-west-1.amazoncognito.com
  Issuer: Amazon RSA 2048 M01
```

**What ALB Receives (With Inspection):**

```
Root CA: PMI Corporate Root CA
  ↓ (signs)
Intermediate CA: PMI Issuing CA
  ↓ (signs)
Server Certificate: *.auth.eu-west-1.amazoncognito.com
  Subject: *.auth.eu-west-1.amazoncognito.com
  Issuer: PMI Issuing CA  ← WRONG!
```

**ALB's Certificate Validation:**

```
1. ALB receives certificate
2. Checks Subject: *.auth.eu-west-1.amazoncognito.com ✅
3. Checks Issuer: Expected "Amazon RSA 2048 M01"
4. Actual Issuer: "PMI Issuing CA" ❌
5. Certificate chain validation fails
6. Connection refused
```

### 7.6 Why This Only Affects Backend Calls

**User Login (Browser Request) - ✅ Works:**

```
User's Browser (PMI Laptop)
    ↓ HTTPS
Corporate VPN
    ↓ HTTPS (may be inspected)
Cognito Hosted UI (52.19.14.243)
    ↓
Login Page Loads ✅
```

**Why it works:**
- Browser trusts PMI Corporate Root CA
- Corporate IT installed root CA on laptops
- Browser accepts "inspected" certificate

**Token Exchange (ALB Backend Request) - ❌ Fails:**

```
ALB (172.23.193.38)
    ↓ HTTPS
Transit Gateway
    ↓ HTTPS
Corporate Firewall (inspects)
    ↓ HTTPS (corporate cert)
Cognito API (52.19.14.243)
    ↓
ALB rejects certificate ❌
```

**Why it fails:**
- ALB uses AWS SDK
- AWS SDK has certificate pinning
- AWS SDK does NOT trust PMI Corporate CA
- Only trusts Amazon Root CA

**Key Insight:**
Same URL, different behavior based on who's connecting:
- Browser (with corporate CA) → ✅ Works
- AWS SDK (certificate pinning) → ❌ Fails

---

<a name="understanding-aws-managed-services"></a>
## 8. Understanding AWS Managed Services

### 8.1 VPC-Enabled vs Control Plane Services

**VPC-Enabled Services (Can Run in Your VPC):**

```
┌─────────────────────────────────────┐
│         Your VPC                    │
│                                     │
│  ┌──────────────────────────────┐  │
│  │   Lambda Function            │  │
│  │   - ENI: eni-abc123          │  │
│  │   - IP: 172.30.227.50        │  │
│  │   - Your subnet              │  │
│  └──────────────────────────────┘  │
│                                     │
│  ┌──────────────────────────────┐  │
│  │   RDS Database               │  │
│  │   - IP: 172.30.227.100       │  │
│  │   - Your subnet              │  │
│  └──────────────────────────────┘  │
└─────────────────────────────────────┘
```

**Examples:**
- ✅ Lambda (VPC mode)
- ✅ RDS
- ✅ ElastiCache
- ✅ EFS
- ✅ ECS/EKS workloads

**Control Plane Services (Cannot Run in Your VPC):**

```
        AWS Infrastructure
┌─────────────────────────────────────┐
│   Cognito Service                   │
│   - AWS-managed                     │
│   - Multi-tenant                    │
│   - Public endpoints only           │
│   - IP: 52.19.14.243                │
└─────────────────────────────────────┘
          ↓ API calls only
┌─────────────────────────────────────┐
│         Your VPC                    │
│  - Can only call Cognito via API    │
└─────────────────────────────────────┘
```

**Examples:**
- ❌ Cognito
- ❌ IAM
- ❌ CloudWatch
- ❌ STS

### 8.2 Why Cognito Cannot Be in Your VPC

**Architectural Reasons:**

1. **Multi-Tenancy:**
   - Shared across millions of AWS customers
   - Cannot place in individual customer VPCs

2. **Global Availability:**
   - Must work even if your VPC has issues
   - Cannot depend on customer network

3. **Security Boundary:**
   - Separates identity system from workloads
   - Industry best practice

4. **Operational Complexity:**
   - AWS manages updates, scaling, HA
   - Requires centralized management

### 8.3 Lambda in VPC: A Working Example

**Lambda Configuration:**

```bash
$ aws lambda get-function-configuration \
    --function-name net-revenue-kpi-workflow

{
    "FunctionName": "net-revenue-kpi-workflow",
    "VpcConfig": {
        "VpcId": "vpc-0ff70419790990b15",
        "SubnetIds": [
            "subnet-090fe96cd60afa5cf",
            "subnet-0537e9c8462cc9c83"
        ],
        "SecurityGroupIds": [
            "sg-0e505013c49aabb32"
        ]
    }
}
```

**Lambda is INSIDE your network.**

**Cognito has:**
- ❌ NO VpcId
- ❌ NO Subnets
- ❌ NO Security Groups
- ✅ Only: Public endpoint

**Cognito is NOT in your network.**

### 8.4 VPC Endpoints: An Alternative for Some Services

**Services with VPC Endpoint Support:**

| **Service** | **VPC Endpoint** | **Type** |
|-------------|------------------|----------|
| S3 | ✅ Yes | Gateway |
| DynamoDB | ✅ Yes | Gateway |
| Lambda | ✅ Yes | Interface |
| **Cognito** | ❌ **No** | N/A |

**Unfortunately:** Cognito does NOT support VPC endpoints.

### 8.5 Why We Can't Use NAT Gateway

**NAT Gateway Solution (Would Work):**

```
Private Subnet → NAT Gateway → Internet Gateway → Cognito
```

This would bypass corporate network → No SSL inspection!

**Why We Can't Do This:**

1. **Service Control Policies (SCP):**
   ```json
   {
     "Effect": "Deny",
     "Action": [
       "ec2:CreateNatGateway"
     ]
   }
   ```

2. **Corporate Security Policy:**
   - All traffic must go through corporate network
   - Single egress point required

**Result:** Cannot create NAT Gateway due to SCP.

---

<a name="solutions-and-workarounds"></a>
## 9. Solutions and Workarounds

### 9.1 Solution Comparison Matrix

| **Solution** | **Complexity** | **Timeline** | **Viability** |
|--------------|---------------|-------------|---------------|
| **1. Whitelist Cognito (bypass SSL inspection)** | Low | 3-5 days | ✅ **Recommended** |
| **2. Create NAT Gateway** | Low | 1 hour | ❌ Blocked by SCP |
| **3. VPC Endpoint** | N/A | N/A | ❌ Not available |
| **4. Application-level auth** | High | 2-3 weeks | ⚠️ Fallback |

### 9.2 Solution 1: Whitelist AWS Cognito (Recommended)

**Approach:** Configure corporate firewall/proxy to bypass SSL inspection for AWS Cognito endpoints.

**Firewall Configuration:**

```
SSL Inspection Policy:
  Policy Name: "AWS Service Bypass"
  Action: Do Not Inspect
  
  Destination Domains:
    - *.auth.*.amazoncognito.com
    - cognito-idp.*.amazonaws.com
  
  Source Networks:
    - 172.23.193.0/24 (ALB subnets)
  
  Protocol: HTTPS (TCP/443)
```

**Testing After Configuration:**

```powershell
# From EC2 instance
PS> curl https://eu-west-1aoqykyr97.auth.eu-west-1.amazoncognito.com/oauth2/token

# Expected result (after fix):
HTTP/1.1 400 Bad Request

# This 400 is GOOD! It means:
# ✅ SSL/TLS handshake succeeded
# ✅ Request reached Cognito
```

**Pros:**
- ✅ No application code changes
- ✅ No infrastructure changes
- ✅ Standard approach for AWS services
- ✅ Quick to implement

**Cons:**
- ⏳ Requires security team approval
- ⏳ May take 3-5 business days

### 9.3 Solution 2: Application-Level Authentication

**Approach:** Remove ALB authentication, implement Cognito authentication in Next.js application.

**Architecture Change:**

**Before (ALB Auth):**
```
Browser → ALB (authenticates) → EC2 (no auth code)
```

**After (App Auth):**
```
Browser → ALB (pass through) → EC2 (authenticates)
```

**Implementation (High-Level):**

```bash
# Install SDK
npm install amazon-cognito-identity-js @aws-amplify/auth
```

```typescript
// Configure Amplify
Amplify.configure({
  Auth: {
    region: 'eu-west-1',
    userPoolId: 'eu-west-1_AOqyKyR97',
    userPoolWebClientId: '...',
    oauth: {
      domain: 'eu-west-1aoqykyr97.auth.eu-west-1.amazoncognito.com',
      redirectSignIn: 'https://loki.mmiana-dev.aws.private-pmideep.biz/callback'
    }
  }
});
```

**Key Difference:**
- ALB auth: ALB makes backend call to Cognito (fails SSL inspection)
- App auth: Browser makes call to Cognito (SSL inspection OK)

**Pros:**
- ✅ Full control over auth flow
- ✅ No dependency on security team
- ✅ Can implement immediately

**Cons:**
- ❌ Significant code changes
- ❌ Application complexity increases
- ⏳ 2-3 weeks development time

### 9.4 Production Recommendation

**Phase 1: Short-term (Immediate)**
```
Approach: Application-level authentication
Timeline: 2-3 weeks
Rationale: Unblocks development
```

**Phase 2: Long-term (Preferred)**
```
Approach: Security team whitelists Cognito
Timeline: Submit ticket in parallel
Rationale: Better architecture
Action: Migrate back to ALB auth once approved
```

---

<a name="lessons-learned"></a>
## 10. Lessons Learned

### 10.1 Technical Lessons

**1. Understand Service Architecture Before Choosing**
- Not all AWS services can run in your VPC
- Research VPC endpoint availability early
- Understand control plane vs data plane services

**2. Corporate Network Can Impact Cloud Services**
- SSL inspection is common in enterprises
- AWS services use certificate pinning
- Plan for security appliance interactions

**3. Test End-to-End Early**
- Don't wait until deployment to test authentication
- Test from actual user environment (VPN)
- Verify entire OAuth flow

**4. Security Groups ≠ Firewall Policies**
- Security groups work at Layer 3/4
- SSL inspection happens at Layer 7
- Different tools for different layers

**5. ALB Limitations in Private Networks**
- ALB needs outbound HTTPS for Cognito
- Private subnets require routing
- Transit Gateway may have restrictions

### 10.2 Process Lessons

**1. Engage Security Team Early**
- Security reviews take time
- Build relationships with security team

**2. Document Network Architecture**
- Understanding traffic paths is critical
- Draw diagrams of packet flow

**3. Have Fallback Plans**
- Don't depend on single solution
- Plan for approval delays

**4. SCPs Are Policy, Not Technical**
- Cannot be overridden at account level
- Plan architecture within SCP constraints

### 10.3 Architectural Lessons

**1. Defense in Depth vs Complexity**
ALB authentication seemed simpler, but added dependencies

**2. Private vs Public Cloud**
- "Private VPC" doesn't mean "isolated from internet"
- AWS managed services live outside your VPC

**3. Early Architecture Review**
Should have reviewed with security team before development

**4. Standard Patterns Exist for a Reason**
- AWS Cognito whitelisting is common
- Should have researched common patterns first

### 10.4 What We Would Do Differently

**If Starting Over:**

1. **Research Security Policies First**
   - Understand corporate network architecture
   - Check SSL inspection policies

2. **Proof of Concept in Production-Like Environment**
   - Test from VPN
   - Don't rely on local testing only

3. **Engage Security Team in Design Phase**
   - Show architecture diagrams
   - Get approval before implementation

4. **Build MVP Without Authentication**
   - Deploy basic app first
   - Add authentication later

5. **Have Two Solutions Ready**
   - Primary: ALB auth
   - Backup: Application auth

### 10.5 Broader Implications

**For Cloud Adoption:**

1. **Traditional Security Tools Don't Always Work**
   - Cloud services use modern security
   - Need to adapt security practices

2. **Control Plane vs Data Plane Matters**
   - Architectural implications

3. **Shared Responsibility Model**
   - Problems at the intersection

**For Security Teams:**

1. **Create AWS Service Whitelist**
   ```
   Pre-approved services:
   - S3 (*.s3.amazonaws.com)
   - DynamoDB (*.dynamodb.amazonaws.com)
   - Cognito (*.auth.*.amazoncognito.com)
   ```

2. **Document Approval Process**
   - Clear criteria
   - SLA for reviews

3. **Provide Self-Service**
   - Clear documentation

---

<a name="conclusion"></a>
## 11. Conclusion

### 11.1 Summary

We set out to build a secure, internal application using AWS ALB with Cognito authentication. The journey taught us valuable lessons about:

**Technical:**
- AWS service architectures
- Corporate network security
- Certificate pinning
- OAuth 2.0 implementation

**Organizational:**
- Cross-team dependencies
- Security policies
- Early engagement
- Fallback plans

**Architectural:**
- Trade-offs
- Private networking
- Hybrid challenges

### 11.2 Final Architecture

**As Deployed (Application Auth):**

```
PMI Users (VPN)
    ↓ HTTPS
Private ALB
    ↓ HTTP (no auth)
EC2 Application
    ↓ Cognito via browser
User authenticated ✅
```

**Target State (ALB Auth):**

```
PMI Users (VPN)
    ↓ HTTPS
Private ALB
    ↓ Cognito auth (whitelisted)
    ↓ HTTP with headers
EC2 Application
User authenticated ✅
```

### 11.3 Key Takeaways

**For Architects:**
1. Research before committing
2. Understand corporate infrastructure
3. Plan for dependencies
4. Have backups
5. Document everything

**For Engineers:**
1. Test early
2. Understand layers
3. Security groups ≠ firewalls
4. Read documentation
5. Ask for help

**For Security Teams:**
1. Create standard whitelists
2. Document processes
3. Understand cloud requirements
4. Balance security with usability

**For Organizations:**
1. Update security policies
2. Train teams
3. Create frameworks
4. Invest in collaboration
5. Document knowledge

### 11.4 Resources

**AWS Documentation:**
- [ALB Authentication](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/listener-authenticate-users.html)
- [Cognito User Pools](https://docs.aws.amazon.com/cognito/latest/developerguide/)
- [VPC Endpoints](https://docs.aws.amazon.com/vpc/latest/privatelink/vpc-endpoints.html)

### 11.5 Final Thoughts

This project reinforced that cloud architecture is as much about understanding organizational constraints as technology. Success requires:
- Technical expertise
- Cross-team collaboration
- Clear communication
- Patience
- Willingness to adapt

**The key is to document, share, and learn from each other's experiences.**

---

## Appendix A: Troubleshooting Commands

```bash
# Check ALB health
aws elbv2 describe-load-balancers --names mmiana-dev-alb

# Check target health
aws elbv2 describe-target-health --target-group-arn <arn>

# Check Cognito user pool
aws cognito-idp describe-user-pool --user-pool-id <id>

# Test connectivity from EC2
Test-NetConnection <cognito-domain> -Port 443
curl -v https://<cognito-domain>/oauth2/token
```

## Appendix B: Security Ticket Template

```markdown
# Request: Whitelist AWS Cognito for SSL Inspection Bypass

**Application:** LokI (InsightsIQ)
**Priority:** High
**Impact:** Application unusable

## What We Need
Bypass SSL inspection for AWS Cognito endpoints:
- *.auth.eu-west-1.amazoncognito.com
- cognito-idp.eu-west-1.amazonaws.com

## Why
AWS Cognito uses certificate pinning. SSL inspection breaks authentication.

## Source
VPC: vpc-0ff70419790990b15
IPs: 172.23.193.38, 172.23.193.70

## Testing
After configuration:
curl https://eu-west-1aoqykyr97.auth.eu-west-1.amazoncognito.com/oauth2/token
Expected: HTTP 400 (not connection error)
```

---

**End of Document**

*Document Version:* 1.0  
*Date:* June 23, 2026  
*Total Pages:* ~60  
*Reading Time:* ~45 minutes  
*Technical Depth:* Advanced  
*Target Audience:* Cloud Architects, DevOps Engineers, Security Teams

---

**Contact Information:**
- **Project:** LokI (InsightsIQ)
- **Team:** DevOps & Cloud Architecture
- **AWS Account:** 986995923613
- **Region:** eu-west-1
- **Environment:** Development

**Document Maintenance:**
- This document should be updated as the project evolves
- Version history should be maintained
- Share with new team members during onboarding
- Update with any new solutions or workarounds discovered

**Acknowledgments:**
- AWS Support for technical guidance
- Security team for collaboration
- PMI DevOps team for implementation
- All team members who contributed to troubleshooting

---

**Copyright © 2026 Philip Morris International**  
*This document is for internal use only*
