"""
Helper function to transform insights.py JSON output to frontend StoryData format
"""

from typing import Dict, Any, List

def transform_insights_json_to_story(generated_data: Dict[str, Any], config) -> Dict[str, Any]:
    """
    Transform the December_insights_response.json format to frontend StoryData format

    Input structure (from insights.py):
    {
        "metadata": {...},
        "dashboard_header": {...},
        "risk_signals": [...],
        "acts": [...]
    }

    Output structure (for frontend):
    {
        "monthTitle": str,
        "subtitle": str,
        "themeTag": str,
        "heroTitle": str,
        "heroLead": str,
        "kpis": [...],
        "sections": {...},
        "watchouts": [...],
        "actions": [...],
        "footnotes": [...]
    }
    """

    print(f"🔄 Transforming insights.py JSON to frontend format...")

    # Extract main sections
    metadata = generated_data.get('metadata', {})
    header = generated_data.get('dashboard_header', {})
    risk_signals = generated_data.get('risk_signals', [])
    acts = generated_data.get('acts', [])

    # Extract period info
    period = metadata.get('period', {})
    month = period.get('month', config.get_month())
    year = period.get('year', config.get_year())

    print(f"  📅 Period: {month} {year}")
    print(f"  📊 Risks: {len(risk_signals)}")
    print(f"  📈 Acts: {len(acts)}")

    # Build hero section
    monthTitle = f"{month} Story of the Month"  # Dynamic month from config
    subtitle = f"Performance Snapshot & Key Risks - {year}"  # Use title from header or default
    themeTag = header.get('headline', 'Performance Analysis')
    heroTitle = header.get('headline', f'The Story of {month}')
    heroLead = header.get('executive_summary', 'Analysis generated from data insights')

    # Build KPIs from Act 1 metrics
    kpis = []
    if acts and len(acts) > 0:
        act1 = acts[0]  # First act is usually "The Win"
        metrics = act1.get('metrics_summary', {})

        # NOR (Net Operating Revenue)
        nor_ytd_growth = metrics.get('nor_ytd_growth_pct', 0)
        nor_monthly = metrics.get('nor_monthly_actual', 0)
        if nor_ytd_growth or nor_monthly:
            kpis.append({
                "label": "Net Revenue",
                "value": f"+{nor_ytd_growth:.1f}% YTD" if nor_ytd_growth > 0 else f"{nor_ytd_growth:.1f}% YTD",
                "delta": f"₹{nor_monthly/1000:.1f}K monthly" if nor_monthly else "",
                "tone": "good" if nor_ytd_growth > 0 else "warn",
                "hint": "Year-to-date net operating revenue growth"
            })

        # Shipments
        ship_yoy = metrics.get('ship_yoy_pct', 0)
        ship_mom = metrics.get('ship_mom_pct', 0)
        if ship_yoy or ship_mom:
            kpis.append({
                "label": "Primary Shipments",
                "value": f"+{ship_yoy:.1f}% YoY" if ship_yoy > 0 else f"{ship_yoy:.1f}% YoY",
                "delta": f"{ship_mom:+.1f}% MoM",
                "tone": "good" if ship_yoy > 0 else "warn",
                "hint": "Primary shipment volume growth"
            })

        # Secondary offtake
        sec_yoy = metrics.get('sec_yoy_pct', 0)
        if sec_yoy:
            kpis.append({
                "label": "Secondary Offtake",
                "value": f"+{sec_yoy:.1f}% YoY" if sec_yoy > 0 else f"{sec_yoy:.1f}% YoY",
                "tone": "good" if sec_yoy > 0 else "warn",
                "hint": "Distributor to retailer shipments"
            })

        # Achievement vs Target
        nor_achievement = metrics.get('nor_ytd_achievement_vs_ob_pct', 0)
        if nor_achievement:
            kpis.append({
                "label": "Target Achievement",
                "value": f"{nor_achievement:.1f}%",
                "tone": "good" if nor_achievement >= 100 else "warn",
                "hint": "YTD achievement vs operating budget"
            })

    # If no KPIs extracted, try to build minimal set from available data
    if not kpis and acts and len(acts) > 0:
        # Try to extract at least one KPI from Act 1 data
        act1 = acts[0]
        metrics = act1.get('metrics_summary', {})

        # Try any available metric
        for key, val in metrics.items():
            if isinstance(val, (int, float)) and val != 0:
                kpis.append({
                    "label": key.replace('_', ' ').title(),
                    "value": f"{val:.1f}%",
                    "tone": "good" if val > 0 else "warn",
                    "hint": f"Analysis period: {month} {year}"
                })
                if len(kpis) >= 2:  # Get at least 2 KPIs
                    break

    # Absolute fallback - data completely missing
    if not kpis:
        kpis = [{"label": "Data Unavailable", "value": "—", "tone": "neutral", "hint": f"No metrics extracted for {month} {year}"}]

    # Build sections from Acts
    sections = {
        "wins": [],
        "twist": [],
        "faultLines": [],
        "innovation": []
    }

    for act in acts:
        act_num = act.get('act_number', 0)
        title = act.get('title', '').lower()
        insights = act.get('insights', [])

        # Extract bullet points (no truncation - let frontend handle display)
        bullets = []
        if isinstance(insights, list):
            # New format: insights is a list of strings
            bullets = insights
        elif isinstance(insights, dict):
            # Old format: insights is a dict with bullet_1, bullet_2, etc.
            bullet_keys = sorted([k for k in insights.keys() if k.startswith('bullet_')])
            bullets = [insights[k] for k in bullet_keys if insights[k]]

        # Map to sections based on act number and title
        if act_num == 1 or 'win' in title:
            sections['wins'] = bullets if bullets else []
        elif act_num == 2 or 'twist' in title:
            sections['twist'] = bullets if bullets else []
        elif act_num == 3 or 'fault' in title or 'risk' in title:
            sections['faultLines'] = bullets if bullets else []
        elif act_num == 4 or 'innov' in title:
            sections['innovation'] = bullets if bullets else []

    # Only fill empty sections if ALL sections are empty (complete data failure)
    # This indicates generation failed entirely, not just one act missing
    all_empty = not any([sections['wins'], sections['twist'], sections['faultLines'], sections['innovation']])

    if all_empty:
        sections['wins'] = [f"Analysis for {month} {year} - Review detailed acts below for insights"]
        sections['twist'] = [f"Competitive dynamics and market position for {month}"]
        sections['faultLines'] = [f"Structural considerations for {month}"]
        sections['innovation'] = [f"Innovation and new initiative tracking for {month}"]

    # Build watchouts from risk_signals
    watchouts = []
    for risk in risk_signals[:4]:  # Max 4 risks
        popup = risk.get('popup', {})

        # Generate short chip label (first 2-3 words or text before delimiter)
        full_title = risk.get('title', 'Risk')
        # Split by common delimiters and take first part
        chip_label = full_title
        for delimiter in [' → ', ' — ', ': ', ' - ']:
            if delimiter in full_title:
                chip_label = full_title.split(delimiter)[0]
                break
        # If still too long, take first 3 words
        if len(chip_label) > 30:
            words = chip_label.split()
            chip_label = ' '.join(words[:3])

        watchout = {
            "id": risk.get('id', 'risk'),
            "chipLabel": chip_label,  # Short label for chip
            "title": full_title,  # Full title for drawer
            "severity": risk.get('severity', 'MEDIUM').lower(),
            "description": popup.get('risk', risk.get('short_description', 'Risk description')),
            "soWhat": popup.get('so_what', 'Potential business impact'),
            "signals": popup.get('signals_to_watch', ['Monitor key indicators']),
            "nowWhat": popup.get('next_actions', ['Take appropriate action'])
        }
        watchouts.append(watchout)

    # Build actions from risk next_actions
    action_items = []
    actions_added = set()

    for risk in risk_signals[:3]:  # Top 3 risks
        popup = risk.get('popup', {})
        next_actions = popup.get('next_actions', [])

        if next_actions and risk.get('title') not in actions_added:
            action_items.append({
                "title": f"{risk.get('title', 'Action Required')} Response",
                "bullets": next_actions[:3]  # Max 3 bullets per action
            })
            actions_added.add(risk.get('title'))

    # Fallback: create basic actions from risk titles if no detailed actions
    if not action_items and risk_signals:
        for risk in risk_signals[:3]:
            action_items.append({
                "title": f"Address: {risk.get('title', 'Risk Area')}",
                "bullets": [
                    "Review current metrics and identify root causes",
                    "Develop targeted response plan",
                    "Monitor weekly and adjust as needed"
                ]
            })

    # Absolute fallback if completely no data
    if not action_items:
        action_items = [
            {"title": f"Review {month} {year} Performance", "bullets": ["Detailed metric analysis required", "Validate data sources", "Generate actionable insights"]}
        ]

    # Build footnotes
    footnotes = [
        f"Based on data analysis for {month} {year}",
        "Insights generated using AI-powered agentic workflow",
        "Recommendations should be validated with current market conditions"
    ]

    # Extract complete acts data with charts and tables for frontend
    acts_data = []
    for act in acts:
        act_num = act.get('act_number', 0)
        act_title = act.get('title', f'Act {act_num}')
        act_subtitle = act.get('subtitle', '')
        ai_insight = act.get('ai_insight', '')
        insights_list = act.get('insights', [])
        metrics_summary = act.get('metrics_summary', {})

        # Extract insights bullets (can be dict or list)
        bullet_list = []
        if isinstance(insights_list, dict):
            # Extract bullets from dict format (bullet_1, bullet_2, etc.)
            for key in sorted(insights_list.keys()):
                if key.startswith('bullet_'):
                    bullet_list.append(insights_list[key])
        elif isinstance(insights_list, list):
            bullet_list = insights_list

        # Keep full bullet content - let frontend handle text overflow/truncation as needed
        # No server-side truncation to preserve complete insights

        act_data = {
            "actNumber": act_num,
            "title": act_title,
            "subtitle": act_subtitle,
            "aiInsight": ai_insight,
            "insights": bullet_list,
            "chartData": None,
            "tableData": None
        }

        # ACT 1: Revenue Trend Chart (12-month line/area chart)
        if act_num == 1:
            # Try act.trend_data first (from S3), then metrics_summary
            trend_data_obj = act.get('trend_data', {})
            if trend_data_obj and 'trend_values' in trend_data_obj:
                print(f"  🔍 Act 1: Using trend_data from act")
                trend_values = trend_data_obj.get('trend_values', [])
                trend_labels = trend_data_obj.get('trend_labels', [])
                # Use the label from backend (e.g., "PRIMARY SHIPMENT VOLUME — 12-MONTH TREND")
                chart_title = trend_data_obj.get('label', 'PRIMARY SHIPMENT VOLUME — 12-MONTH TREND')
            else:
                print(f"  🔍 Act 1: Using trend from metrics_summary")
                trend_values = metrics_summary.get('trend_12m', [])
                trend_labels = metrics_summary.get('trend_labels', [])
                chart_title = 'PRIMARY SHIPMENT VOLUME — 12-MONTH TREND'

            if trend_values and trend_labels:
                print(f"  ✅ Act 1: Setting chartData with {len(trend_values)} months, title: {chart_title}")
                act_data["chartData"] = {
                    "type": "area",
                    "title": chart_title,
                    "labels": trend_labels,
                    "values": trend_values
                }
            else:
                print(f"  ❌ Act 1: No trend data found")

            # Add threeMonthAnalysis for Act 1 (Growth Analysis section)
            if 'threeMonthAnalysis' in act:
                print(f"  ✅ Act 1: Including threeMonthAnalysis for Growth Analysis section")
                act_data["threeMonthAnalysis"] = act['threeMonthAnalysis']
            else:
                print(f"  ⚠️  Act 1: No threeMonthAnalysis found")

        # ACT 2: Market Share Bars
        elif act_num == 2:
            # Extract top 3 competitors by share
            market_share_data = []

            print(f"  🔍 Act 2: Building market share chart...")
            print(f"     metrics_summary has data: {bool(metrics_summary)}")

            # FIRST: Try to use act.market_share object directly (from S3 data)
            market_share_obj = act.get('market_share', {})
            if market_share_obj and 'companies' in market_share_obj:
                try:
                    print(f"     Using market_share.companies from act")
                    companies = market_share_obj['companies'][:3]  # Top 3
                    for comp in companies:
                        name = comp.get('name', '')
                        # Handle both string and numeric values
                        share_val = comp.get('share_pct', 0)
                        share = float(share_val) if share_val else 0
                        change_val = comp.get('change', 0)
                        change = float(change_val) if change_val else 0

                        # Map company names to display names
                        brand_name = "PMI" if "Philip Morris" in name or "PMI" in name else \
                                    "ITC" if "Itc" in name or "ITC" in name else \
                                    "Godfrey Phillips" if "Godfrey" in name else name

                        fill_color = "#1a56db" if "PMI" in brand_name else \
                                    "#64748b" if "ITC" in brand_name else \
                                    "#cbd5e1"

                        market_share_data.append({
                            "brand": brand_name,
                            "share": share,
                            "delta": f"+{change:.2f}pp" if change >= 0 else f"{change:.2f}pp",
                            "fill": fill_color
                        })
                except Exception as e:
                    print(f"     ❌ Error parsing market_share.companies: {e}")
                    # Fall through to metrics_summary fallback
            # FALLBACK: Try metrics_summary
            else:
                print(f"     Fallback to metrics_summary")
                # PMI
                pmi_share = metrics_summary.get('share_philip_morris', 0)
                pmi_change = metrics_summary.get('share_change_philip_morris', 0)
                if pmi_share:
                    market_share_data.append({
                        "brand": "PMI",
                        "share": pmi_share,
                        "delta": f"+{pmi_change:.2f}pp" if pmi_change >= 0 else f"{pmi_change:.2f}pp",
                        "fill": "#1a56db"
                    })

                # ITC
                itc_share = metrics_summary.get('share_itc_ltd', 0)
                itc_change = metrics_summary.get('share_change_itc_ltd', 0)
                if itc_share:
                    market_share_data.append({
                        "brand": "ITC",
                        "share": itc_share,
                        "delta": f"+{itc_change:.2f}pp" if itc_change >= 0 else f"{itc_change:.2f}pp",
                        "fill": "#64748b"
                    })

                # Godfrey Phillips
                gp_share = metrics_summary.get('share_godfrey_phillips', 0)
                gp_change = metrics_summary.get('share_change_godfrey_phillips', 0)
                if gp_share:
                    market_share_data.append({
                        "brand": "Godfrey Phillips",
                        "share": gp_share,
                        "delta": f"+{gp_change:.2f}pp" if gp_change >= 0 else f"{gp_change:.2f}pp",
                        "fill": "#cbd5e1"
                    })

            print(f"     Market share data items: {len(market_share_data)}")
            if market_share_data:
                print(f"     ✅ Setting chartData for Act 2 with {len(market_share_data)} items")
                act_data["chartData"] = {
                    "type": "bars",
                    "title": "Market Share by Manufacturer",
                    "data": market_share_data
                }
            else:
                print(f"     ❌ No market share data found, chartData will be NULL")

        # ACT 3: State Concentration Table with YoY changes
        elif act_num == 3:
            state_data = []

            print(f"  🔍 Act 3: Building state table...")

            # FIRST: Try act.state_breakdown.state_table (from S3 data)
            state_breakdown_obj = act.get('state_breakdown', {})
            if state_breakdown_obj and 'state_table' in state_breakdown_obj:
                try:
                    print(f"     Using state_breakdown.state_table from act")
                    state_table = state_breakdown_obj['state_table'][:4]  # Top 4 states

                    for state_row in state_table:
                        state_name = state_row.get('state', '')
                        share_pct = float(state_row.get('vol_share_pct', 0))

                        # Try seq_change_display first (formatted string like "+2.5%"), then seq_change_pct, then yoy_change
                        seq_text = state_row.get('seq_change_display')
                        if not seq_text:
                            # Fallback to numeric seq_change_pct or yoy_change
                            seq_change = float(state_row.get('seq_change_pct', state_row.get('yoy_change', 0)))
                            seq_text = f"+{seq_change:.1f}%" if seq_change >= 0 else f"{seq_change:.1f}%"

                        # Determine status from seq value
                        status = state_row.get('row_class', state_row.get('signal', 'ok'))
                        # Normalize status values
                        if status == 'positive': status = 'good'
                        elif status == 'negative': status = 'warn'

                        state_data.append({
                            "state": state_name.title(),
                            "share": f"{share_pct:.1f}%",
                            "seq": seq_text,
                            "seq_change_display": state_row.get('seq_change_display', seq_text),
                            "seq_change_pct": state_row.get('seq_change_pct', 0),
                            "status": status
                        })

                    # Get top 2 concentration from state_breakdown if available
                    top2_conc = state_breakdown_obj.get('top2_concentration', 0)

                except Exception as e:
                    print(f"     ❌ Error parsing state_breakdown: {e}")
                    # Fall through to metrics_summary fallback

            # FALLBACK: Try metrics_summary
            if not state_data:
                print(f"     Fallback to metrics_summary")
                top_states = metrics_summary.get('top_states', {})
                state_yoy = metrics_summary.get('state_yoy', {})

                if top_states and isinstance(top_states, dict):
                    # Get top 4 states
                    sorted_states = sorted(top_states.items(), key=lambda x: x[1], reverse=True)[:4]

                    for state_name, share_pct in sorted_states:
                        # Get YoY change for this state
                        yoy_change = state_yoy.get(state_name, None)

                        if yoy_change is not None:
                            seq_text = f"+{yoy_change:.1f}%" if yoy_change >= 0 else f"{yoy_change:.1f}%"
                            status = "good" if yoy_change > 0 else "warn" if yoy_change < 0 else "ok"
                        else:
                            seq_text = "—"
                            status = "ok"
                            yoy_change = 0

                        state_data.append({
                            "state": state_name.title(),
                            "share": f"{share_pct:.1f}%",
                            "seq": seq_text,
                            "seq_change_display": seq_text,
                            "seq_change_pct": yoy_change if yoy_change is not None else 0,
                            "status": status
                        })

                    # Calculate top 2 concentration
                    top2_conc = metrics_summary.get('top2_conc', 0)

            if state_data:
                print(f"     ✅ Setting tableData for Act 3 with {len(state_data)} states")
                act_data["tableData"] = {
                    "type": "states",
                    "title": f"Top State Concentration (Top 2: {top2_conc:.1f}%)" if top2_conc else "Top State Concentration",
                    "data": state_data
                }
            else:
                print(f"     ❌ No state data found, tableData will be NULL")

        # ACT 4: New Variant/Launch Metrics - Show variant volumes table
        elif act_num == 4:
            print(f"  🔍 Act 4: Building variant/launch table...")

            # Try launch_scorecard from act first
            launch_scorecard = act.get('launch_scorecard', {})
            if launch_scorecard and 'metrics' in launch_scorecard:
                try:
                    print(f"     Using launch_scorecard.metrics from act")
                    metrics = launch_scorecard['metrics']
                    variant_name = launch_scorecard.get('variant', 'New Variant')
                    day = launch_scorecard.get('day', 0)
                    status = launch_scorecard.get('status', 'active')

                    # Create table with columns for each metric
                    columns = ["Metric"]
                    metric_values = {}

                    for metric in metrics:
                        metric_name = metric.get('name', '')
                        value = metric.get('value', 0)
                        unit = metric.get('unit', '')
                        target = metric.get('target', 0)
                        severity = metric.get('severity', 'low')

                        # Store metric with formatted value
                        metric_values[metric_name] = {
                            'value': f"{value}{unit}",
                            'target': f"{target}{unit}",
                            'severity': severity
                        }

                    # Build single row with all metrics
                    row = {
                        "Variant": variant_name,
                        "Day": str(day),
                        "Status": status
                    }

                    # Add each metric as a column
                    for metric_name, metric_info in metric_values.items():
                        row[metric_name] = metric_info['value']
                        columns.append(metric_name)

                    act_data["tableData"] = {
                        "type": "launch",
                        "title": "New Variant Launch Scorecard",
                        "columns": ["Variant", "Day", "Status"] + list(metric_values.keys()),
                        "rows": [row],
                        "metricsDetails": metric_values  # Include for frontend to show targets/severity
                    }
                    print(f"     ✅ Setting tableData for Act 4 from launch_scorecard")
                except Exception as e:
                    print(f"     ❌ Error parsing launch_scorecard: {e}")

            # Fallback: metrics_summary.new_var_vols
            if not act_data.get("tableData"):
                print(f"     Fallback to metrics_summary.new_var_vols")
                new_var_vols = metrics_summary.get('new_var_vols', {})
                new_var_coverage = metrics_summary.get('new_var_coverage', 0)

                if new_var_vols and isinstance(new_var_vols, dict):
                    # Create table data with variant names and volumes
                    variant_data = []
                    for variant_name, volume in sorted(new_var_vols.items(), key=lambda x: x[1], reverse=True)[:5]:
                        variant_data.append({
                            "variant": variant_name,
                            "volume": f"{volume:,.0f}",
                            "coverage": f"{new_var_coverage:.1f}%" if new_var_coverage else "N/A"
                        })

                    if variant_data:
                        print(f"     ✅ Setting tableData for Act 4 with {len(variant_data)} variants")
                        act_data["tableData"] = {
                            "type": "variants",
                            "title": f"Top New Variant Volumes (Coverage: {new_var_coverage:.1f}%)" if new_var_coverage else "Top New Variant Volumes",
                            "data": variant_data
                        }
                else:
                    # Fallback: show count only
                    new_offers_count = metrics_summary.get('new_offers_count', 0)
                    if new_offers_count > 0:
                        print(f"     ✅ Setting tableData for Act 4 with count={new_offers_count}")
                        act_data["tableData"] = {
                            "type": "launch",
                            "title": f"New Variant Performance ({new_offers_count} active)",
                            "count": new_offers_count
                        }
                    else:
                        print(f"     ❌ No variant data found, tableData will be NULL")

        acts_data.append(act_data)

    # Construct final story data
    story_data = {
        "monthTitle": monthTitle,
        "subtitle": subtitle,
        "themeTag": themeTag,
        "heroTitle": heroTitle,
        "heroLead": heroLead,
        "kpis": kpis,
        "acts": acts_data,  # Add complete acts with charts and tables
        "sections": sections,
        "watchouts": watchouts,
        "actions": action_items,
        "footnotes": footnotes
    }

    print(f"✅ Transformation complete:")
    print(f"   - {len(kpis)} KPIs")
    print(f"   - {len(watchouts)} watchouts")
    print(f"   - {len(action_items)} actions")

    return story_data
