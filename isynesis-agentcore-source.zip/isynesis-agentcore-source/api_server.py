"""
FastAPI Server for iSynesis Insights - AgentCore Version
"""
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
import json
import os
from datetime import datetime
import logging
import uvicorn

import insights
from transform_helper import transform_insights_json_to_story

logger = logging.getLogger(__name__)
app = FastAPI(title="iSynesis API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:9002", "http://127.0.0.1:9002"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"status": "running", "service": "iSynesis Insights API", "version": "1.0.0"}

@app.get("/ping")
async def ping():
    """AgentCore health check - required by Bedrock AgentCore"""
    # Check openpyxl availability
    openpyxl_available = False
    pandas_version = "unknown"
    try:
        import openpyxl
        openpyxl_available = True
        openpyxl_version = openpyxl.__version__
    except ImportError:
        openpyxl_version = "NOT_INSTALLED"

    try:
        import pandas as pd
        pandas_version = pd.__version__
    except:
        pass

    return {
        "status": "healthy",
        "version": "73",
        "fix": "verify_openpyxl",
        "openpyxl": openpyxl_version,
        "openpyxl_importable": openpyxl_available,
        "pandas": pandas_version
    }

@app.post("/invocations")
async def agentcore_invocations(request: Request):
    """AgentCore invocation endpoint"""
    try:
        body = await request.json()
        input_data = body.get("input", body)
        
        action = input_data.get("action", "get")
        year = input_data.get("year")
        month = input_data.get("month")
        
        logger.info(f"[AgentCore] Invocation: action={action}, month={month}, year={year}")
        
        # Try S3 first
        import boto3
        from botocore.exceptions import ClientError

        country = "India"
        s3_key = f"metadata/dynamic/{country}/{year}/{month}/isynesis/{month}_insights_response.json"
        s3_client = boto3.client('s3', region_name='eu-west-1')

        try:
            response = s3_client.get_object(Bucket='mbr-data-lake', Key=s3_key)
            s3_data = json.loads(response['Body'].read())

            logger.info(f"[AgentCore] Found S3 data for {month} {year}")

            config = insights.get_config()
            insights.set_month_year(year, month, sync_to_lambda=False)
            story_data = transform_insights_json_to_story(s3_data, config)

            return {
                "output": {
                    "status": "success",
                    "source": "s3",
                    "data": story_data,
                    "period": f"{month} {year}"
                }
            }

        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                logger.info(f"[AgentCore] No S3 data, generating for {month} {year}")

                # Generate synchronously
                insights.main(auto_month=month, auto_year=year, skip_prompt=True)

                # Read generated data
                response = s3_client.get_object(Bucket='mbr-data-lake', Key=s3_key)
                s3_data = json.loads(response['Body'].read())

                config = insights.get_config()
                insights.set_month_year(year, month, sync_to_lambda=False)
                story_data = transform_insights_json_to_story(s3_data, config)

                return {
                    "output": {
                        "status": "success",
                        "source": "generated",
                        "data": story_data,
                        "period": f"{month} {year}"
                    }
                }
            else:
                raise
            
    except Exception as e:
        logger.error(f"[AgentCore] Error: {e}", exc_info=True)
        return {
            "output": {"error": str(e), "message": "Invocation failed"}
        }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080, log_level="info")
