"""
Period State Management
Stores current period in S3
"""
import boto3
import json
from datetime import datetime

S3_BUCKET = "mbr-data-lake"
S3_STATE_KEY = "metadata/dynamic/India/current_period.json"

s3_client = boto3.client('s3')

def save_current_period(year: str, month: str, country: str = "India"):
    """Save the current selected period to S3"""
    try:
        state = {
            "year": year,
            "month": month,
            "country": country,
            "updated_at": datetime.utcnow().isoformat()
        }

        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=S3_STATE_KEY,
            Body=json.dumps(state),
            ContentType='application/json'
        )

        print(f"[OK] Saved current period to S3: {month} {year}")
        return True
    except Exception as e:
        print(f"[WARN] Failed to save period state: {e}")
        return False

def load_current_period():
    """Load the current selected period from S3"""
    try:
        response = s3_client.get_object(
            Bucket=S3_BUCKET,
            Key=S3_STATE_KEY
        )

        state = json.loads(response['Body'].read())

        year = state.get('year')
        month = state.get('month')
        country = state.get('country', 'India')

        print(f"[OK] Loaded current period from S3: {month} {year} ({country})")
        return year, month, country

    except s3_client.exceptions.NoSuchKey:
        print("[INFO] No saved period state found, using defaults")
        return None, None, None
    except Exception as e:
        print(f"[WARN] Failed to load period state: {e}")
        return None, None, None
