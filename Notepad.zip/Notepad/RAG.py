"""
KB Builder Lambda
=================
S3 → Text Extract → Chunk → Bedrock Embedding → DynamoDB

Optimized for:
- Low Lambda size
- Fast cold starts
- High reliability
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import re
import traceback
import urllib.parse
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Callable

import boto3

# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────

REGION = os.environ.get("REGION", "eu-west-1")
KB_TABLE_NAME = os.environ.get("KB_TABLE_NAME", "pmi-agentic-ai-knowledge-base")

EMBEDDING_MODEL = "amazon.titan-embed-text-v2:0"
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50
MAX_EMBED_WORDS = 6000

# ──────────────────────────────────────────────────────────────────────────────
# Logging & clients (reused across invocations)
# ──────────────────────────────────────────────────────────────────────────────

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb", region_name=REGION)
bedrock = boto3.client("bedrock-runtime", region_name=REGION)

TABLE = dynamodb.Table(KB_TABLE_NAME)

# ──────────────────────────────────────────────────────────────────────────────
# Text extraction helpers
# ──────────────────────────────────────────────────────────────────────────────

def _read_zip_xml(content: bytes, path: str):
    import zipfile
    import xml.etree.ElementTree as ET

    with zipfile.ZipFile(io.BytesIO(content)) as z:
        with z.open(path) as f:
            return ET.parse(f).getroot()


def extract_docx(content: bytes) -> str:
    W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    root = _read_zip_xml(content, "word/document.xml")
    return "\n\n".join(
        "".join(t.text or "" for t in p.iter(f"{{{W}}}t")).strip()
        for p in root.iter(f"{{{W}}}p")
        if "".join(t.text or "" for t in p.iter(f"{{{W}}}t")).strip()
    )


def extract_pptx(content: bytes) -> str:
    import zipfile
    import xml.etree.ElementTree as ET

    A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    texts = []

    with zipfile.ZipFile(io.BytesIO(content)) as z:
        for slide in sorted(n for n in z.namelist() if n.startswith("ppt/slides/") and n.endswith(".xml")):
            root = ET.parse(z.open(slide)).getroot()
            slide_text = " ".join(t.text.strip() for t in root.iter(f"{{{A}}}t") if t.text)
            if slide_text:
                texts.append(slide_text)

    return "\n\n".join(texts)


def extract_xlsx(content: bytes) -> str:
    try:
        root = _read_zip_xml(content, "xl/sharedStrings.xml")
    except Exception:
        return ""

    S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    return "\n\n".join(t.text.strip() for t in root.iter(f"{{{S}}}t") if t.text)


def extract_pdf(content: bytes) -> str:
    import PyPDF2
    reader = PyPDF2.PdfReader(io.BytesIO(content))
    return "\n\n".join(p.extract_text().strip() for p in reader.pages if p.extract_text())


def extract_msg(content: bytes) -> str:
    import extract_msg
    msg = extract_msg.Message(io.BytesIO(content))
    parts = [msg.subject, msg.sender, msg.to, msg.date, msg.body]
    return "\n\n".join(p for p in parts if p)


def extract_eml(content: bytes) -> str:
    import email
    from email.policy import default

    msg = email.message_from_bytes(content, policy=default)
    body = []
    for part in msg.walk():
        if part.get_content_type() == "text/plain":
            body.append(part.get_content())

    headers = [msg[x] for x in ("Subject", "From", "To", "Date") if msg[x]]
    return "\n\n".join(headers + body)


EXTRACTORS: Dict[str, Callable[[bytes], str]] = {
    ".docx": extract_docx,
    ".pptx": extract_pptx,
    ".ppt": extract_pptx,
    ".xlsx": extract_xlsx,
    ".pdf": extract_pdf,
    ".msg": extract_msg,
    ".eml": extract_eml,
    ".txt": lambda b: b.decode("utf-8", errors="replace"),
}

def extract_text(content: bytes, ext: str) -> str:
    fn = EXTRACTORS.get(ext)
    if not fn:
        return content.decode("utf-8", errors="replace")
    return fn(content)

# ──────────────────────────────────────────────────────────────────────────────
# Chunking
# ──────────────────────────────────────────────────────────────────────────────

def chunk_text(text: str) -> List[str]:
    paragraphs = [p for p in re.split(r"\n{2,}", text) if p.strip()]
    words = " ".join(paragraphs).split()

    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i:i + CHUNK_SIZE])
        if len(chunk) > 50:
            chunks.append(chunk)
        i += CHUNK_SIZE - CHUNK_OVERLAP
    return chunks

# ──────────────────────────────────────────────────────────────────────────────
# Embeddings
# ──────────────────────────────────────────────────────────────────────────────

def embed(text: str) -> List[Decimal]:
    trimmed = " ".join(text.split()[:MAX_EMBED_WORDS])
    res = bedrock.invoke_model(
        modelId=EMBEDDING_MODEL,
        body=json.dumps({"inputText": trimmed}),
        contentType="application/json",
        accept="application/json",
    )
    vec = json.loads(res["body"].read())["embedding"]
    return [Decimal(str(round(v, 6))) for v in vec]

# ──────────────────────────────────────────────────────────────────────────────
# Lambda handler
# ──────────────────────────────────────────────────────────────────────────────

def lambda_handler(event: Dict[str, Any], context: Any) -> dict:
    stored = failed = 0

    for r in event.get("Records", []):
        try:
            bucket = r["s3"]["bucket"]["name"]
            key = urllib.parse.unquote_plus(r["s3"]["object"]["key"])
            filename = key.split("/")[-1]
            ext = os.path.splitext(filename)[1].lower()

            obj = s3.get_object(Bucket=bucket, Key=key)
            content = obj["Body"].read()

            text = extract_text(content, ext)
            if not text.strip():
                failed += 1
                continue

            chunks = chunk_text(text)
            doc_id = hashlib.sha256(key.encode()).hexdigest()
            now = datetime.utcnow().isoformat()

            for i, chunk in enumerate(chunks):
                TABLE.put_item(Item={
                    "chunk_id": f"{doc_id}_{i:04d}",
                    "chunk_text": chunk,
                    "embedding": embed(chunk),
                    "file_name": filename,
                    "s3_url": f"s3://{bucket}/{key}",
                    "created_at": now,
                })
                stored += 1

        except Exception:
            failed += 1
            logger.error(traceback.format_exc())

    return {
        "statusCode": 200,
        "body": json.dumps({
            "stored": stored,
            "failed": failed,
        })
    }
