"""
KB Builder Lambda — S3-Triggered Document Chunking + Embedding + DynamoDB Storage
===================================================================================
Triggered by: S3 ObjectCreated event (prefix: sharepoint/)

Pipeline:
  S3 file → extract text → chunk → Bedrock embedding → DynamoDB

Supported file types: .docx, .pdf, .pptx, .xlsx, .txt, .msg

Self-contained: uses only stdlib (zipfile, xml.etree) for docx/pptx extraction.
PyPDF2 is bundled in the Lambda deployment package for PDF support.
"""

import hashlib
import io
import json
import logging
import os
import re
import traceback
import urllib.parse
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ── AWS clients ────────────────────────────────────────────────────────────────
s3_client      = boto3.client("s3")
dynamodb       = boto3.resource("dynamodb", region_name=os.environ.get("REGION", "eu-west-1"))
bedrock_client = boto3.client("bedrock-runtime", region_name=os.environ.get("REGION", "eu-west-1"))

KB_TABLE_NAME   = os.environ.get("KB_TABLE_NAME", "pmi-agentic-ai-knowledge-base")
EMBEDDING_MODEL = "amazon.titan-embed-text-v2:0"
CHUNK_SIZE      = 500   # approximate words per chunk
CHUNK_OVERLAP   = 50    # words overlap between consecutive chunks


# ── Text extraction ────────────────────────────────────────────────────────────

def extract_text_from_docx(content: bytes) -> str:
    """
    Extract text from a .docx file using stdlib zipfile + xml.etree.
    .docx is a ZIP archive; paragraphs live in word/document.xml as <w:t> nodes.
    """
    import zipfile
    import xml.etree.ElementTree as ET

    W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    paragraphs = []

    with zipfile.ZipFile(io.BytesIO(content)) as z:
        with z.open("word/document.xml") as f:
            root = ET.parse(f).getroot()

    for para in root.iter(f"{{{W}}}p"):
        text = "".join(t.text or "" for t in para.iter(f"{{{W}}}t")).strip()
        if text:
            paragraphs.append(text)

    return "\n\n".join(paragraphs)


def extract_text_from_pdf(content: bytes) -> str:
    """Extract text from a .pdf file using PyPDF2 (bundled in Lambda package)."""
    import PyPDF2

    reader = PyPDF2.PdfReader(io.BytesIO(content))
    pages  = [page.extract_text().strip() for page in reader.pages if page.extract_text()]
    return "\n\n".join(pages)


def extract_text_from_pptx(content: bytes) -> str:
    """
    Extract text from a .pptx file using stdlib zipfile + xml.etree.
    .pptx is a ZIP archive; slides live in ppt/slides/slideN.xml as <a:t> nodes.
    """
    import zipfile
    import xml.etree.ElementTree as ET

    A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    slides_text = []

    with zipfile.ZipFile(io.BytesIO(content)) as z:
        slide_files = sorted(
            n for n in z.namelist()
            if n.startswith("ppt/slides/slide") and n.endswith(".xml")
        )
        for slide_file in slide_files:
            with z.open(slide_file) as f:
                root = ET.parse(f).getroot()
            texts = [
                t.text.strip()
                for t in root.iter(f"{{{A}}}t")
                if t.text and t.text.strip()
            ]
            if texts:
                slides_text.append(" ".join(texts))

    return "\n\n".join(slides_text)


def extract_text_from_xlsx(content: bytes) -> str:
    """
    Extract text from a .xlsx file using stdlib zipfile + xml.etree.
    .xlsx is a ZIP archive; shared strings live in xl/sharedStrings.xml as <t> nodes.
    """
    import zipfile
    import xml.etree.ElementTree as ET

    S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    texts = []

    try:
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            if "xl/sharedStrings.xml" in z.namelist():
                with z.open("xl/sharedStrings.xml") as f:
                    root = ET.parse(f).getroot()
                for t in root.iter(f"{{{S}}}t"):
                    if t.text and t.text.strip():
                        texts.append(t.text.strip())
    except Exception as e:
        logger.error(f"XLSX extraction failed: {e}")

    return "\n\n".join(texts)


def extract_text_from_msg(content: bytes) -> str:
    """Extract text from .msg files using extract_msg."""
    try:
        import extract_msg
        msg = extract_msg.Message(io.BytesIO(content))
        
        parts = []
        if msg.subject:
            parts.append(f"Subject: {msg.subject}")
        if msg.sender:
            parts.append(f"From: {msg.sender}")
        if msg.to:
            parts.append(f"To: {msg.to}")
        if msg.date:
            parts.append(f"Date: {msg.date}")
        if msg.body:
            parts.append(msg.body)
            
        return "\n\n".join(parts)
    except Exception as e:
        logger.error(f"MSG extraction failed: {e}")
        return ""


def extract_text_from_eml(content: bytes) -> str:
    """Extract text from .eml files using stdlib email package."""
    import email
    from email.policy import default

    try:
        msg = email.message_from_bytes(content, policy=default)
        parts = []
        
        if msg['Subject']:
            parts.append(f"Subject: {msg['Subject']}")
        if msg['From']:
            parts.append(f"From: {msg['From']}")
        if msg['To']:
            parts.append(f"To: {msg['To']}")
        if msg['Date']:
            parts.append(f"Date: {msg['Date']}")
            
        # Walk through the email payload to find text/plain
        body_parts = []
        for part in msg.walk():
            if part.get_content_type() == "text/plain" and not part.is_multipart():
                try:
                    text = part.get_content()
                    if text and text.strip():
                        body_parts.append(text.strip())
                except Exception as e:
                    logger.warning(f"Failed to decode text/plain part in EML: {e}")
        
        if body_parts:
            parts.append("\n".join(body_parts))
            
        return "\n\n".join(parts)
    except Exception as e:
        logger.error(f"EML extraction failed: {e}")
        return ""


def extract_text(content: bytes, file_ext: str, filename: str) -> str:
    """Route file content to the appropriate text extractor."""
    ext = file_ext.lower()
    try:
        if ext == ".docx":
            return extract_text_from_docx(content)
        elif ext == ".pdf":
            return extract_text_from_pdf(content)
        elif ext in (".pptx", ".ppt"):
            return extract_text_from_pptx(content)
        elif ext == ".xlsx":
            return extract_text_from_xlsx(content)
        elif ext == ".msg":
            return extract_text_from_msg(content)
        elif ext == ".eml":
            return extract_text_from_eml(content)
        elif ext == ".txt":
            return content.decode("utf-8", errors="replace")
        else:
            logger.warning(f"Unsupported file type '{ext}' for {filename} — attempting UTF-8 decode")
            return content.decode("utf-8", errors="replace")
    except Exception as e:
        logger.error(f"Text extraction failed for {filename}: {e}")
        return ""


# ── Chunking ───────────────────────────────────────────────────────────────────

def chunk_text(
    text:       str,
    chunk_size: int = CHUNK_SIZE,
    overlap:    int = CHUNK_OVERLAP,
) -> List[Dict]:
    """
    Split text into overlapping word-based chunks.

    Each returned chunk dict contains:
      - text            : the chunk string
      - paragraphs      : list of source paragraph strings within this chunk
      - paragraph_count : number of paragraphs
    """
    raw_paragraphs = [p.strip() for p in re.split(r"\n{2,}", text) if p.strip()]

    # Flatten paragraphs into a single word list and track which index each paragraph ends at.
    words:            List[str] = []
    para_texts:       List[str] = []
    para_end_indices: List[int] = []

    for para in raw_paragraphs:
        para_words = para.split()
        if not para_words:
            continue
        words.extend(para_words)
        para_end_indices.append(len(words) - 1)
        para_texts.append(para)

    if not words:
        return []

    chunks = []
    start  = 0

    while start < len(words):
        end         = min(start + chunk_size, len(words))
        chunk_str   = " ".join(words[start:end])

        # Collect paragraphs whose end-index falls within the window [start, end)
        chunk_paras = [
            pt for pt, pe in zip(para_texts, para_end_indices)
            if start <= pe < end
        ]

        if len(chunk_str.strip()) > 50:   # skip near-empty chunks
            chunks.append({
                "text":            chunk_str,
                "paragraphs":      chunk_paras,
                "paragraph_count": len(chunk_paras),
            })

        start += chunk_size - overlap

    return chunks


# ── Bedrock embedding ──────────────────────────────────────────────────────────

def generate_embedding(text: str) -> List[float]:
    """
    Generate an embedding vector using Amazon Titan Embed Text v2 via Bedrock.
    Truncates to ~6000 words to stay within the 8192-token model limit.
    """
    truncated = " ".join(text.split()[:6000])
    try:
        response = bedrock_client.invoke_model(
            modelId=EMBEDDING_MODEL,
            body=json.dumps({"inputText": truncated}),
            contentType="application/json",
            accept="application/json",
        )
        return json.loads(response["body"].read())["embedding"]
    except Exception as e:
        # Fail loudly — silently storing empty vectors would corrupt KB searches.
        raise RuntimeError(
            f"Bedrock embedding failed (is Titan Embeddings enabled in Model Access?): {e}"
        )


# ── DynamoDB storage ───────────────────────────────────────────────────────────

def store_chunks_to_dynamodb(
    table_name:     str,
    s3_key:         str,
    bucket:         str,
    filename:       str,
    chunks:         List[Dict],
    sharepoint_url: str = "",
    document_type:  str = "",
    document_subtype: str = "",
    document_format: str = "",
    document_title: str = "",
    last_modified_date: str = "",
    author:         str = "",
    country:        str = "",
) -> int:
    """
    Store each chunk as a DynamoDB item with flat top-level keys for easy querying
    and a nested metadata map for rich context.

    Item schema:
      chunk_id          (PK)   — deterministic: sha256(s3_key) + 4-digit chunk index
      chunk_text               — raw text used for RAG retrieval
      embedding                — Decimal list of float values (Titan Embed vector)
      file_name                — original filename including extension
      document_title           — clean, readable title for the document
      document_type            — high-level category (e.g. "Notes", "External Engagements")
      document_subtype         — sub-category (e.g. "Leave-behind notes", "Speeches")
      document_format          — file extension without dot (e.g. "docx", "pdf", "pptx", "xlsx", "msg")
      last_modified_date       — ISO timestamp of document authoring
      sharepoint_url           — link to document online
      s3_url                   — pointer to object storage
      created_at               — ISO timestamp of ingestion
      metadata                 — nested Map with chunk-level provenance
    """
    table   = dynamodb.Table(table_name)
    doc_id  = hashlib.sha256(s3_key.encode()).hexdigest()
    now     = datetime.utcnow().isoformat()
    stored  = 0

    for idx, chunk in enumerate(chunks):
        chunk_str   = chunk["text"]
        chunk_paras = chunk.get("paragraphs", [])
        para_count  = chunk.get("paragraph_count", len(chunk_paras))

        try:
            embedding = generate_embedding(chunk_str)

            item = {
                # ── Flat top-level keys ────────────────────────────────────
                "chunk_id":          f"{doc_id}_{idx:04d}",
                "chunk_text":        chunk_str,
                "embedding":         [Decimal(str(round(v, 6))) for v in embedding] if embedding else [],
                "document_title":    document_title,
                "document_type":     document_type,
                "document_subtype":  document_subtype,
                "document_format":   document_format,   # e.g. "docx", "pdf", "pptx", "xlsx", "msg"
                "last_modified_date": last_modified_date,
                "sharepoint_url":    sharepoint_url,
                "s3_url":            f"s3://{bucket}/{s3_key}",
                "created_at":        now,
                "country":           country,

                # ── Nested metadata map ────────────────────────────────────
                "metadata": {
                    "file_name":       filename,
                    "author":          author,
                    "country":         country,
                    "chunk_number":    idx + 1,        # 1-based, human-readable
                    "chunk_index":     idx,             # 0-based, programmatic
                    "chunk_type":      "paragraph_group",
                    "s3_key":          s3_key,
                    "s3_bucket":       bucket,
                    "total_chunks":    len(chunks),
                    "word_count":      len(chunk_str.split()),
                    "paragraph_count": para_count,
                },
            }

            table.put_item(Item=item)
            stored += 1

            if idx % 10 == 0:
                logger.info(f"  Stored chunk {idx + 1}/{len(chunks)} for {filename}")

        except Exception as e:
            logger.error(f"Failed to store chunk {idx} for {filename}: {e}")

    return stored


# ── Lambda entry point ─────────────────────────────────────────────────────────

def lambda_handler(event: Dict[str, Any], context: Any) -> dict:
    """
    Entry point — triggered by S3 ObjectCreated event (prefix: sharepoint/).
    For each new file: extract text → chunk → embed → store in DynamoDB.
    """
    logger.info("KB Builder triggered by S3 event")

    records = event.get("Records", [])
    if not records:
        logger.warning("No S3 records in event")
        return {"status": "skipped", "message": "No S3 records"}

    total_stored = 0
    total_failed = 0
    processed:  List[Dict] = []

    for record in records:
        bucket   = record["s3"]["bucket"]["name"]
        raw_key  = record["s3"]["object"]["key"]
        key      = urllib.parse.unquote_plus(raw_key)
        filename = key.split("/")[-1]
        file_ext        = os.path.splitext(filename)[1].lower()
        document_format = file_ext.lstrip(".")   # e.g. "docx", "pdf", "pptx", "xlsx", "msg"

        # Reconstruct SharePoint URL from S3 key structure:
        # sharepoint/<hostname>/<site_path>/.../<filename>
        key_parts = key.split("/")
        if len(key_parts) >= 3:
            sp_host        = key_parts[1]
            sp_path        = "/".join(key_parts[2:])
            sharepoint_url = f"https://{sp_host}/{sp_path}"
        else:
            sharepoint_url = f"s3://{bucket}/{key}"

        logger.info(f"Processing: s3://{bucket}/{key}")
        logger.info(f"SharePoint URL: {sharepoint_url}")

        try:
            # 1. Download from S3
            response = s3_client.get_object(Bucket=bucket, Key=key)
            content  = response["Body"].read()
            logger.info(f"Downloaded {len(content):,} bytes — {filename}")

            # Resolve document_type and document_subtype from SharePoint S3 metadata
            # (set by ingestion/handler.py from the folder path hierarchy)
            s3_meta = response.get("Metadata", {})
            final_doc_type    = s3_meta.get("sharepoint-document-type", "")
            final_doc_subtype = s3_meta.get("sharepoint-document-subtype", "")
            last_modified_date = s3_meta.get("sharepoint-last-modified", "")
            author             = s3_meta.get("sharepoint-author", "")
            country            = s3_meta.get("sharepoint-country", "")
            
            # Create a clean title (e.g. "Meeting_Notes_v2.docx" -> "Meeting Notes v2")
            doc_title = os.path.splitext(filename)[0].replace("_", " ").replace("-", " ")

            # 2. Extract text
            text = extract_text(content, file_ext, filename)
            if not text.strip():
                logger.warning(f"No text extracted from {filename} — skipping")
                total_failed += 1
                continue
            logger.info(f"Extracted {len(text):,} chars from {filename}")

            # 3. Chunk
            chunks = chunk_text(text)
            logger.info(f"Created {len(chunks)} chunks for {filename}")

            # 4. Embed + store
            stored = store_chunks_to_dynamodb(
                table_name=KB_TABLE_NAME,
                s3_key=key,
                bucket=bucket,
                filename=filename,
                chunks=chunks,
                sharepoint_url=sharepoint_url,
                document_type=final_doc_type,
                document_subtype=final_doc_subtype,
                document_format=document_format,
                document_title=doc_title,
                last_modified_date=last_modified_date,
                author=author,
                country=country,
            )
            total_stored += stored
            processed.append({
                "file":            filename,
                "document_format": document_format,
                "document_type":   final_doc_type,
                "document_subtype": final_doc_subtype,
                "chunks":          len(chunks),
                "stored":          stored,
                "sharepoint_url":  sharepoint_url,
            })
            logger.info(f"Stored {stored}/{len(chunks)} chunks for {filename}")

        except Exception as e:
            logger.error(f"Failed to process {filename}: {e}")
            traceback.print_exc()
            total_failed += 1

    logger.info(
        f"SUMMARY — Files processed: {len(processed)}, "
        f"Total chunks stored: {total_stored}, Failed: {total_failed}"
    )

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message":      "KB build complete",
            "processed":    processed,
            "total_stored": total_stored,
            "failed":       total_failed,
        }, default=str),
    }
