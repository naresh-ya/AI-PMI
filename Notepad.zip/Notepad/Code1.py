"job-1779944511225-5u675wh"
import json
import logging
import os
import ssl
import time
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup
import requests
from dotenv import load_dotenv
 
requests.packages.urllib3.disable_warnings()
 
# Monkey-patch SSL for Corporate Proxy
original_request = requests.Session.request
def unverified_request(self, *args, **kwargs):
    kwargs['verify'] = False
    return original_request(self, *args, **kwargs)
requests.Session.request = unverified_request
 
logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)
 
load_dotenv()
 
LITELLM_ENDPOINT = 'https://litellm.aiplat-dev.aws.private-pmideep.biz/chat/completions'
LITELLM_MODEL    = 'anthropic.claude-3-haiku-20240307-v1:0'
LITELLM_KEY      = os.environ.get('AWS_BEARER_TOKEN_BEDROCK', 'sk-missing')
TAVILY_API_KEY   = os.environ.get('TAVILY_API_KEY', '')
 
TARGET_DOMAINS = [
    "mohfw.gov.in",
    "commerce.gov.in",
    "cbic.gov.in",
    "financialservices.gov.in",
    "tobaccoboard.in"
]
 
# Selecting 3 diverse questions from the user's list for the evaluation
QUESTIONS = [
    "What is the COTPA act and how does it regulate tobacco in India?",
    "What are the GST rates applicable on tobacco and tobacco products?",
    "What is the process to export tobacco from India to international markets?"
]
 
def call_litellm(messages, tools=None):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    headers = {"Authorization": f"Bearer {LITELLM_KEY}", "Content-Type": "application/json"}
    data = {"model": LITELLM_MODEL, "messages": messages, "temperature": 0.1}
    if tools:
        data["tools"] = tools
        data["tool_choice"] = "auto"
    try:
        req = urllib.request.Request(LITELLM_ENDPOINT, data=json.dumps(data).encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req, context=ctx, timeout=60) as response:
            return json.loads(response.read().decode('utf-8'))['choices'][0]['message']
    except Exception as e:
        return {"role": "assistant", "content": f"API Error: {e}"}
 
# ==========================================
# METHOD 1: Native Claude (The Hallucinator)
# ==========================================
def eval_native(query):
    start = time.time()
    prompt = f"Using your internal knowledge, answer: {query} Focus on data from these domains: {', '.join(TARGET_DOMAINS)}"
    msg = call_litellm([{"role": "user", "content": prompt}])
    return msg.get("content", "Error"), time.time() - start
 
# ==========================================
# METHOD 2: Manual Scraper (The Crash-Prone)
# ==========================================
def eval_manual_scraper(query):
    start = time.time()
    try:
        search_url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query + ' site:cbic.gov.in')}"
        resp = requests.get(search_url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        soup = BeautifulSoup(resp.text, 'html.parser')
        urls = [a['href'] for a in soup.find_all('a', class_='result__url')]
        if not urls:
            return "ERROR - Pipeline Crash: DuckDuckGo returned 0 results. Corporate IP Rate-Limited.", time.time() - start
       
        target = urls[0]
        page_resp = requests.get(target, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        text = BeautifulSoup(page_resp.text, 'html.parser').get_text()[:2000]
       
        prompt = f"Answer '{query}' using this raw text scraped from {target}:\n{text}"
        msg = call_litellm([{"role": "user", "content": prompt}])
        return msg.get("content", "Error"), time.time() - start
    except Exception as e:
        return f"ERROR - Pipeline Crash: {e}", time.time() - start
 
# ==========================================
# METHOD 3: Agentic Tavily (The Enterprise standard)
# ==========================================
def eval_tavily_agent(query):
    start = time.time()
    def search_tavily(q):
        try:
            resp = requests.post("https://api.tavily.com/search", json={"api_key": TAVILY_API_KEY, "query": q, "include_domains": TARGET_DOMAINS}, timeout=20)
            data = resp.json()
            ctx = "\n".join([f"Source: {r.get('url')}\nContent: {r.get('content')}" for r in data.get('results', [])])
            return ctx if ctx.strip() else "No results found on target domains."
        except Exception as e:
            return str(e)
 
    tools = [{"type": "function", "function": {"name": "tavily_search", "description": "Search target domains", "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}}]
    messages = [{"role": "system", "content": "You are a Research Agent. Answer the query using the provided tool, and provide URL citations."}, {"role": "user", "content": query}]
   
    for _ in range(3):
        msg = call_litellm(messages, tools)
        messages.append(msg)
        if "tool_calls" in msg and msg["tool_calls"]:
            for call in msg["tool_calls"]:
                args = json.loads(call["function"]["arguments"])
                messages.append({"role": "tool", "tool_call_id": call["id"], "name": call["function"]["name"], "content": search_tavily(args["query"])})
            continue
        return msg.get("content", "Error"), time.time() - start
    return "Agent Loop Exhausted", time.time() - start
 
if __name__ == "__main__":
    print("="*80)
    print("STARTING COMPREHENSIVE RESEARCH PIPELINE EVALUATION")
    print("="*80)
   
    report = "# Agentic RAG vs Scraper vs Native LLM: Performance Evaluation\n\n"
   
    for i, q in enumerate(QUESTIONS):
        print(f"\n[{i+1}/3] Evaluating Query: {q}")
       
        print("  -> Testing Native Claude...")
        ans1, t1 = eval_native(q)
       
        print("  -> Testing Manual Scraper...")
        ans2, t2 = eval_manual_scraper(q)
       
        print("  -> Testing Tavily Agent...")
        ans3, t3 = eval_tavily_agent(q)
       
        report += f"## Query {i+1}: {q}\n"
        report += f"### Method 1: Native Claude Baseline (Time: {t1:.1f}s)\n*Result*: {ans1}\n\n"
        report += f"### Method 2: Custom Manual Scraper (Time: {t2:.1f}s)\n*Result*: {ans2}\n\n"
        report += f"### Method 3: Tavily Agentic Pipeline (Time: {t3:.1f}s)\n*Result*: {ans3}\n\n---\n"
 
    with open("comprehensive_evaluation_report.md", "w", encoding="utf-8") as f:
        f.write(report)
       
    print("\nSUCCESS: Evaluation complete! Results saved to comprehensive_evaluation_report.md")