# PMI Agentic AI - Lambda Functions Architecture Analysis

**Account:** 603433800649 (CA - Dev)  
**Region:** eu-west-1  
**Analysis Date:** 2026-06-26

---

## Executive Summary

The PMI Agentic AI system consists of **48 Lambda functions** organized into **7 major functional groups**:

1. **Agentic AI Research Workflow** - AI-powered research and document generation
2. **Knowledge Base Management** - Document indexing and search
3. **SharePoint Ingestion** - Document ingestion from SharePoint
4. **API & Request Management** - External API interfaces
5. **Human-in-the-Loop (HITL)** - Human review and approval
6. **Infrastructure & Utilities** - Supporting services
7. **Authentication** - Cognito/Amplify auth triggers

---

## 1. Agentic AI Research Workflow System

### Overview
This is the **core AI system** that conducts research, generates drafts, and manages the entire agentic AI workflow. It uses **AWS Step Functions** to orchestrate multiple Lambda functions working together.

### Architecture

```
User Request (API Gateway)
    ↓
[Input Validator] → Validates request, checks requirements
    ↓
[Research Planner] → Creates research plan using Claude Opus 4.8
    ↓
┌──────────────────── Parallel Research Phase ────────────────────┐
│                                                                  │
│  [User Sources Search]    [KB Search]    [Web Search]           │
│         ↓                      ↓              ↓                  │
│  User-provided docs    Bedrock KB    Tavily API (external)     │
│                                                                  │
│  [Curated Links Search] ← DynamoDB: curated-links               │
│         ↓                                                        │
└──────────────────────────────────────────────────────────────────┘
    ↓
[Research Synthesis] → Combines all research using Claude Sonnet 4.6
    ↓
[Draft Planner] → Plans document structure
    ↓
[Draft Generator] → Generates draft content
    ↓
[Draft Assembler] → Assembles final document
    ↓
[HITL Gate] → Checks if human review is required
    ↓
[HITL Interface] → Human review (if needed)
    ↓
Final Document → Stored in S3
```

### Lambda Functions in this Group

#### **1.1 Input Validation & Planning**

| Function | Purpose | AI Model | Timeout |
|----------|---------|----------|---------|
| `pmi-input-validator` | Validates user requests | N/A | 900s |
| `pmi-input-validator-client-demo1` | Demo1 input validator | Claude Haiku | 900s |
| `pmi-input-validator-client-demo2` | Demo2 input validator | Claude Haiku | 900s |
| `pmi-research-planner-client-demo2` | Creates research plan | Claude Opus 4.8 | 900s |
| `pmi-draft-planner-client-demo2` | Plans document structure | Claude Opus 4.8 | 900s |

#### **1.2 Research Phase**

| Function | Purpose | Data Source | AI Model |
|----------|---------|-------------|----------|
| `pmi-research-user-sources-client-demo2` | Searches user-provided documents | S3 | Claude Sonnet 4.6 |
| `pmi-research-kb-search-client-demo2` | Searches internal knowledge base | Bedrock KB (OSJDPJLTNC) | Claude Sonnet 4.6 |
| `pmi-research-web-search-client-demo2` | Web search (external) | **Tavily API** | Claude Sonnet 4.6 |
| `pmi-research-curated-links-client-demo2` | Searches curated links | DynamoDB | Claude Sonnet 4.6 |
| `pmi-research-synthesis-client-demo2` | Synthesizes all research | All sources | Claude Sonnet 4.6 |

**Note:** All research functions use:
- Fast model: Claude Haiku 4.5
- Default model: Claude Sonnet 4.6  
- Reasoning model: Claude Opus 4.8

#### **1.3 Draft Generation**

| Function | Purpose | AI Model | Timeout |
|----------|---------|----------|---------|
| `pmi-draft-generator-client-demo2` | Generates draft content | Claude Sonnet 4.6 | 900s |
| `pmi-draft-assembler-client-demo2` | Assembles final document | Claude Sonnet 4.6 | 900s |
| `pmi-master-drafter` | Master drafting orchestrator | Claude (Bedrock) | 900s |
| `pmi-master-drafter-client-demo1` | Demo1 drafter | Claude Sonnet 4.6 | 900s |
| `pmi-master-drafter-client-demo2` | Demo2 drafter | Claude Sonnet 4.6 | 900s |

#### **1.4 Master Orchestrators**

| Function | Purpose | Calls | Timeout |
|----------|---------|-------|---------|
| `pmi-master-researcher` | Orchestrates research phase | `pmi-kb-searcher` | 900s |
| `pmi-master-researcher-client-demo1` | Demo1 research orchestrator | Multiple research functions | 900s |
| `pmi-master-reviewer` | Reviews generated content | N/A | 900s |

### Step Functions Workflows

#### **Workflow 1: `pmi-agentic-ai-workflow-dev`**
- **Purpose:** Main production workflow
- **Lambdas Used:**
  - `pmi-input-validator`
  - `pmi-master-researcher`
  - `pmi-master-drafter`

#### **Workflow 2: `pmi-agentic-ai-workflow-client-demo1`**
- **Purpose:** Client demo 1 workflow
- **Lambdas Used:**
  - `pmi-input-validator-client-demo1`
  - `pmi-master-researcher-client-demo1`
  - `pmi-master-drafter-client-demo1`
  - `pmi-hitl-gate-client-demo1` (human review gate)

#### **Workflow 3: `pmi-research-workflow-client-demo2`**
- **Purpose:** Full research workflow with all phases
- **Lambdas Used (in order):**
  1. `pmi-input-validator-client-demo2`
  2. `pmi-research-planner-client-demo2`
  3. `pmi-research-user-sources-client-demo2`
  4. `pmi-research-kb-search-client-demo2`
  5. `pmi-research-web-search-client-demo2`
  6. `pmi-research-curated-links-client-demo2`
  7. `pmi-research-synthesis-client-demo2`
  8. `pmi-draft-planner-client-demo2`
  9. `pmi-draft-generator-client-demo2`
  10. `pmi-draft-assembler-client-demo2`

### Data Flow

```
DynamoDB Tables:
├── pmi-agentic-ai-requests-dev (tracks all requests)
├── pmi-agentic-ai-curated-links (curated research sources)
├── pmi-agentic-ai-activity-logs-dev (audit logs)
├── pmi-agentic-ai-request-timeline-dev (request timeline)
└── pmi-agentic-ai-workflow-executions-dev (workflow status)

S3 Buckets:
├── pmi-agentic-ai-documents-603433800649-eu-west-1 (main documents)
└── pmi-agentic-ai-documents-sandbox-603433800649 (testing)

External APIs:
├── AWS Bedrock (Claude AI models)
├── Bedrock Knowledge Base (OSJDPJLTNC)
└── Tavily API (web search) - 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
```

---

## 2. Knowledge Base Management System

### Overview
Manages document indexing, search, and synchronization with AWS Bedrock Knowledge Base.

### Architecture

```
SharePoint Documents → S3 Upload
    ↓
EventBridge Rule: TriggerBedrockKBSyncFromS3
    ↓
[KB Builder] → Indexes documents
    ↓
Bedrock Knowledge Base (OpenSearch Serverless)
    ↓
[KB Searcher] ← Search queries from research functions
    ↓
Results → Research workflow
```

### Lambda Functions

| Function | Purpose | Triggered By | Storage |
|----------|---------|--------------|---------|
| `pmi-kb-builder` | Builds/updates knowledge base index | Manual/EventBridge | Bedrock KB |
| `pmi-aws-knowledge-base-builder` | Syncs with AWS Bedrock KB | S3 events | KB: OSJDPJLTNC |
| `pmi-kb-searcher` | Searches DynamoDB KB | Research functions | DynamoDB: `pmi-agentic-ai-knowledge-base` |
| `pmi-kb-searcher-client-demo1` | Demo KB searcher | HITL interface, research | DynamoDB |
| `pmi-aws-knowledge-base-searcher` | Searches AWS Bedrock KB | Research functions | Bedrock KB |
| `pmi-kb-sync-failure-handler` | Handles KB sync failures | EventBridge (failure) | CloudWatch Logs |
| `KB-retrieval-testing` | Tests KB retrieval | Manual testing | Bedrock KB |

### Knowledge Base Details

**Bedrock Knowledge Bases:**
1. **pmi-experimental-knowledge-base** (OSJDPJLTNC)
   - Model: Amazon Titan Embed Text v2
   - Storage: OpenSearch Serverless
   
2. **knowledge-base-ccaiaa-dev-test** (MTAS2JIFNH)
   - Model: Cohere Embed Multilingual v3
   - Storage: OpenSearch Serverless

**DynamoDB Table:** `pmi-agentic-ai-knowledge-base`
- Stores: Document metadata, embeddings references

---

## 3. SharePoint Ingestion System

### Overview
Ingests documents from PMI SharePoint into the system for processing and indexing.

### Architecture

```
SharePoint Site
    ↓
[SharePoint Ingestion] ← EventBridge: cron(0 6 * * ? *)
    ↓
Secrets Manager: pmi/sharepoint/credentials
    ↓
Downloads Documents
    ↓
S3: pmi-agentic-ai-documents-sandbox-603433800649
    ↓
DynamoDB: document_metadata
    ↓
EventBridge: TriggerBedrockKBSyncFromS3
    ↓
KB Builder (indexes documents)
```

### Lambda Functions

| Function | Purpose | Schedule | Status |
|----------|---------|----------|--------|
| `pmi-sharepoint-ingestion` | Production ingestion | Daily 6 AM UTC | Active |
| `pmi-sharepoint-ingestion-experimental` | Testing new features | Manual | Experimental |
| `pmi-sharepoint-ingest` | Legacy function | Manual | Low timeout (3s) |
| `pmi-test-sharepoint` | Testing SharePoint connection | Manual | Testing |
| `pmi-ingestion-handler` | Alternative ingestion handler | API Gateway | Active |

### Credentials

**Secrets Manager:**
- `pmi/sharepoint/credentials` - Production SharePoint credentials
- `pmi-ingestion/sharepoint/credentials-*` - Ingestion-specific credentials

**API Gateway Integration:**
- **API:** `pmi-ingestion-api` (8tst29fjdh)
- **Endpoint:** POST to trigger `pmi-sharepoint-ingestion`

---

## 4. API & Request Management System

### Overview
External-facing APIs for creating requests, managing documents, and retrieving data.

### Architecture

```
User/Frontend
    ↓
API Gateway: pmi-agentic-ai-api-dev (y97ca45wk1)
    ↓
┌─────────────────── API Routes ───────────────────┐
│                                                   │
│  POST /create-request                            │
│      → [Create Request Handler] → Step Function  │
│                                                   │
│  POST /upload-presigned                          │
│      → [Uploads Presigned Handler] → S3          │
│                                                   │
│  POST /hitl                                      │
│      → [HITL Interface] → Human Review           │
│                                                   │
│  POST /documents                                 │
│      → [Document Handler] → S3 Download          │
│                                                   │
└───────────────────────────────────────────────────┘
    ↓
DynamoDB: pmi-agentic-ai-requests-dev
```

### API Gateways & Lambda Mappings

#### **API 1: pmi-agentic-ai-api-dev** (y97ca45wk1)
**Type:** HTTP API  
**Purpose:** Main application API

| Endpoint | Lambda Function | Purpose |
|----------|-----------------|---------|
| POST /create-request | `pmi-agentic-ai-create-request-handler-dev` | Creates new research request |
| POST /upload-presigned | `pmi-agentic-ai-uploads-presigned-handler-dev` | Generates S3 presigned URLs |
| POST /hitl | `pmi-hitl-interface` | Human review interface |
| POST /api | `pmi-api-handler-client-demo1` | Client demo API |

#### **API 2: pmi-agentic-ai-latest-records-api** (l0xhkyycki)
**Type:** HTTP API  
**Purpose:** Retrieve latest requests

| Endpoint | Lambda Function | Purpose |
|----------|-----------------|---------|
| POST /latest | `pmi-api-latest-requests-handler` | Fetches recent requests |

#### **API 3: pmi-ingestion-api** (8tst29fjdh)
**Type:** HTTP API  
**Purpose:** Document ingestion

| Endpoint | Lambda Function | Purpose |
|----------|-----------------|---------|
| POST /ingest | `pmi-sharepoint-ingestion` | Triggers SharePoint ingestion |

#### **API 4: pmi-agentic-ai-api-dev-ui** (601e7izjc4)
**Type:** HTTP API  
**Purpose:** Frontend UI API (no Lambda integrations found - likely S3 hosting)

### Lambda Functions

| Function | Purpose | Triggers Step Function | Database |
|----------|---------|------------------------|----------|
| `pmi-agentic-ai-create-request-handler-dev` | Creates request, starts workflow | `pmi-agentic-ai-workflow-dev` | DynamoDB + RDS (disabled) |
| `pmi-api-handler-client-demo1` | Demo API handler | `pmi-agentic-ai-workflow-client-demo1` | DynamoDB |
| `pmi-api-handler` | Production API handler | `pmi-agentic-ai-workflow` | DynamoDB: `pmi-requests` |
| `pmi-api-latest-requests-handler` | Fetches recent requests | None | DynamoDB |
| `pmi-agentic-ai-uploads-presigned-handler-dev` | Generates S3 upload URLs | None | S3 |
| `pmi-agentic-ai-document-handler` | Downloads documents | None | S3 |
| `pmi-document-handler-client-demo1` | Demo document handler | None | S3 |

### Request Lifecycle

1. **Create Request** → API Gateway → `create-request-handler` → DynamoDB
2. **Start Workflow** → Step Function started with request ID
3. **Track Progress** → Updates DynamoDB timeline and activity logs
4. **Store Documents** → S3 bucket with presigned URLs
5. **Retrieve Results** → API Gateway → document handler → S3

---

## 5. Human-in-the-Loop (HITL) System

### Overview
Allows human reviewers to validate AI-generated research and drafts before finalization.

### Architecture (Detailed)

```
Step Function Workflow
    ↓
[HITL Gate] → Checks if human review required
    ↓ (if required)
DynamoDB: pmi-agentic-ai-hitl-dev (status: pending_review)
    ↓
Human Reviewer (via UI/API)
    ↓
API Gateway: POST /hitl
    ↓
[HITL Interface] 
    ↓
┌────── HITL Interface Actions ──────┐
│                                    │
│  1. Retrieve pending review item   │
│  2. Fetch additional context:      │
│     - Tavily web search (external) │
│     - KB search (internal)         │
│     - Curated links                │
│  3. Present to human reviewer      │
│  4. Collect human feedback         │
│  5. Update DynamoDB status         │
│                                    │
└────────────────────────────────────┘
    ↓
Continue Step Function
```

### Lambda Functions

| Function | Purpose | External API | DynamoDB Tables |
|----------|---------|--------------|-----------------|
| `pmi-hitl-interface` | Main HITL interface | **Tavily API** | `pmi-agentic-ai-hitl-dev`, `pmi-agentic-ai-requests-dev`, `pmi-agentic-ai-curated-links` |
| `pmi-hitl-gate-client-demo1` | Checks if review needed | None | `pmi-agentic-ai-hitl-dev`, `pmi-agentic-ai-requests-dev` |

### HITL Interface Details

**Function:** `pmi-hitl-interface`

**External Dependencies:**
1. **Tavily API** - Web search for verification
   - API Key: `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`
   - Purpose: Verify AI findings with web search

2. **KB Searcher** - Internal knowledge base
   - Calls: `pmi-kb-searcher-client-demo1`
   - Purpose: Find supporting internal documents

3. **Claude AI (Bedrock)** - AI assistance
   - Model: Claude Haiku (fast)
   - Purpose: Summarize findings for reviewer

**Data Flow:**
1. Reviewer accesses HITL UI
2. UI calls API Gateway → `pmi-hitl-interface`
3. Lambda fetches pending item from DynamoDB
4. Lambda searches Tavily + KB + curated links
5. Presents enriched context to reviewer
6. Reviewer approves/rejects/edits
7. Lambda updates DynamoDB status
8. Step Function continues

---

## 6. Infrastructure & Utilities

### Overview
Supporting Lambda functions for infrastructure, monitoring, and testing.

### Lambda Functions

| Function | Purpose | Triggered By | Category |
|----------|---------|--------------|----------|
| `DEEP-Patching-Helper` | Manages EC2 patching windows | EventBridge cron | Infrastructure |
| `DEEP-Patching-Logger` | Logs patching results | SSM patching events | Monitoring |
| `DEEP-ssm-log-parser` | Parses SSM logs | CloudWatch Logs | Logging |
| `pmi-agentcore-input-validator` | Validates agent core inputs | Agent Core | AgentCore |
| `terraform-demo-lambda` | Terraform testing | Manual | Testing |

### EventBridge Rules

| Rule | Schedule | Lambda |
|------|----------|--------|
| `DEEPPatchingHelper` | cron(0 10,22 * * ? *) | `DEEP-Patching-Helper` |
| `DEEPPatchingLogger` | On SSM completion | `DEEP-Patching-Logger` |
| `pmi-ingestion-daily-ingestion` | cron(0 6 * * ? *) | `pmi-sharepoint-ingestion` |
| `TriggerBedrockKBSyncFromS3` | On S3 upload | `pmi-aws-knowledge-base-builder` |

---

## 7. Authentication System

### Overview
Cognito/Amplify custom authentication triggers for the login system.

### Architecture

```
User Login Attempt
    ↓
Cognito User Pool: amplify_backend_manager_dtnpl3xf4hrg2
    ↓
┌────── Lambda Triggers (Amplify) ──────┐
│                                        │
│  [Define Auth Challenge]               │
│       ↓                                │
│  [Create Auth Challenge]               │
│       ↓                                │
│  User enters challenge                 │
│       ↓                                │
│  [Verify Auth Challenge]               │
│       ↓                                │
│  [Custom Message] (email/SMS)          │
│                                        │
└────────────────────────────────────────┘
    ↓
Authentication Success/Failure
```

### Lambda Functions

| Function | Trigger | Purpose |
|----------|---------|---------|
| `amplify-login-define-auth-challenge-228803b5` | DefineAuthChallenge | Determines which challenge to present |
| `amplify-login-create-auth-challenge-228803b5` | CreateAuthChallenge | Creates custom challenge |
| `amplify-login-verify-auth-challenge-228803b5` | VerifyAuthChallenge | Verifies user's challenge response |
| `amplify-login-custom-message-228803b5` | CustomMessage | Customizes email/SMS messages |

**Runtime:** Node.js 20.x  
**Cognito Pool:** `eu-west-1_8n7fW5vob`

---

## Cross-Cutting Concerns

### 1. VPC Configuration

**VPC:** `pmi-app-ccaiaa-dev` (172.28.164.0/27)

**Lambdas in VPC:**
- `pmi-hitl-interface`
- `pmi-input-validator-client-demo1`
- `pmi-input-validator-client-demo2`
- `pmi-agentic-ai-create-request-handler-dev`
- All research functions (client-demo2)

**Security Group:** `Lambda-LLM` (sg-059b5633724e8d9ca)

**Subnets:**
- Private: `subnet-006279d48a05b9eef`, `subnet-095b022568aeb5af1`

### 2. Corporate Proxy

Many Lambdas use corporate proxy for external API calls:

```
HTTP_PROXY: http://your-corporate-proxy.com:8080
HTTPS_PROXY: http://your-corporate-proxy.com:8080
NO_PROXY: 169.254.169.254,.aws.private-pmideep.biz,.amazonaws.com
```

### 3. AI Models Usage

| Model | Purpose | Lambda Functions |
|-------|---------|------------------|
| Claude Opus 4.8 | Complex reasoning, planning | Research planner, Draft planner |
| Claude Sonnet 4.6 | Default AI tasks | Research, synthesis, drafting |
| Claude Haiku 4.5 | Fast operations | Validation, quick checks |
| Claude Haiku (Legacy) | Legacy HITL interface | `pmi-hitl-interface` |

**Bedrock Bearer Token:** `sk-aHl_Upvol7F9A24c3Ta4cA` (shared across functions)

### 4. External APIs

| API | Purpose | API Key/Token | Used By |
|-----|---------|---------------|---------|
| Tavily | Web search | `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` | `pmi-hitl-interface` |
| AWS Bedrock | Claude AI models | Bearer token | All AI functions |
| SharePoint | Document ingestion | Secrets Manager | Ingestion functions |

### 5. IAM Roles

**Primary Role:** `pmi-lambda-execution-role`

**Permissions:**
- AWSLambdaVPCAccessExecutionRole
- SecretsManagerReadWrite
- AWSLambdaBasicExecutionRole
- AmazonDynamoDBFullAccess
- AmazonS3FullAccess
- AWSLambda_FullAccess (allows Lambda→Lambda invocation)

**Other Roles:**
- `pmi-ingestion-role` - SharePoint ingestion
- `pmi-agentic-ai-create-request-handler-role-dev` - API handler
- `pmi-agentcore-validator-role` - Agent Core
- `amplify-login-lambda-228803b5` - Cognito triggers

---

## Complete System Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER / FRONTEND                         │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│               API GATEWAY (pmi-agentic-ai-api-dev)              │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐ │
│  │ /create      │ /upload      │ /hitl        │ /documents   │ │
│  └──────┬───────┴──────┬───────┴──────┬───────┴──────┬───────┘ │
└─────────┼──────────────┼──────────────┼──────────────┼─────────┘
          │              │              │              │
          ↓              ↓              ↓              ↓
┌─────────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐
│   Create    │  │ Presigned│  │   HITL   │  │   Document   │
│   Request   │  │   URLs   │  │Interface │  │   Handler    │
│   Handler   │  │  Handler │  │          │  │              │
└──────┬──────┘  └────┬─────┘  └────┬─────┘  └──────┬───────┘
       │              │              │                │
       │              │              │                │
       ↓              ↓              ↓                ↓
┌─────────────────────────────────────────────────────────────────┐
│                         AWS RESOURCES                           │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐ │
│  │  DynamoDB    │   S3 Bucket  │    Secrets   │  Bedrock KB  │ │
│  │   Tables     │  (Documents) │   Manager    │              │ │
│  └──────────────┴──────────────┴──────────────┴──────────────┘ │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│              STEP FUNCTION: pmi-research-workflow               │
│                                                                 │
│  1. [Input Validator] ──→ Validates request                    │
│          ↓                                                      │
│  2. [Research Planner] ──→ Plans research strategy             │
│          ↓                                                      │
│  3. ┌─── Parallel Research ───┐                                │
│     │  [User Sources]          │                                │
│     │  [KB Search]             │                                │
│     │  [Web Search] (Tavily)   │                                │
│     │  [Curated Links]         │                                │
│     └──────────┬───────────────┘                                │
│                ↓                                                │
│  4. [Research Synthesis] ──→ Combines findings                 │
│          ↓                                                      │
│  5. [Draft Planner] ──→ Plans document structure               │
│          ↓                                                      │
│  6. [Draft Generator] ──→ Generates content                    │
│          ↓                                                      │
│  7. [Draft Assembler] ──→ Assembles final doc                 │
│          ↓                                                      │
│  8. [HITL Gate] ──→ Human review needed?                       │
│          ↓ (if yes)                                            │
│  9. [HITL Interface] ──→ Human approves/edits                  │
│          ↓                                                      │
│  10. Final Document ──→ Stored in S3                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│                    BACKGROUND PROCESSES                         │
│  ┌──────────────┬──────────────┬──────────────┐                │
│  │  SharePoint  │   KB Sync    │   Patching   │                │
│  │  Ingestion   │   (S3→KB)    │   Helper     │                │
│  │  (Daily)     │   (S3 event) │   (Cron)     │                │
│  └──────────────┴──────────────┴──────────────┘                │
└─────────────────────────────────────────────────────────────────┘
```

---

## Lambda Functional Groups Summary

### Group 1: Core Research Workflow (10 functions)
- Input validators (3)
- Research planner (1)
- Research executors (5: user sources, KB, web, curated, synthesis)
- Draft planner (1)

### Group 2: Draft Generation (3 functions)
- Draft generator
- Draft assembler  
- Master drafter orchestrators (3 versions)

### Group 3: Knowledge Base (7 functions)
- KB builders (2)
- KB searchers (3)
- Sync failure handler (1)
- Testing (1)

### Group 4: SharePoint Ingestion (5 functions)
- Production ingestion (1)
- Experimental (1)
- Legacy (1)
- Testing (1)
- Ingestion handler (1)

### Group 5: API & Request Management (7 functions)
- Create request handlers (2)
- Upload handlers (1)
- Document handlers (2)
- Latest requests (1)
- API handlers (2)

### Group 6: HITL System (2 functions)
- HITL interface (1)
- HITL gate (1)

### Group 7: Authentication (4 functions)
- Cognito triggers (4)

### Group 8: Infrastructure (5 functions)
- Patching helper/logger (3)
- Agent Core validator (1)
- Terraform demo (1)

---

## Integration Patterns

### Pattern 1: Step Function Orchestration
**Used By:** Research workflow, agentic AI workflow  
**How:** Step Functions call Lambda functions sequentially and in parallel

### Pattern 2: Direct Lambda Invocation
**Used By:** Master orchestrators, HITL interface  
**How:** Lambda invokes another Lambda directly (e.g., `pmi-master-researcher` → `pmi-kb-searcher`)

### Pattern 3: API Gateway → Lambda
**Used By:** All external APIs  
**How:** HTTP request triggers Lambda via API Gateway integration

### Pattern 4: EventBridge → Lambda
**Used By:** Scheduled tasks, S3 events  
**How:** EventBridge rule triggers Lambda on schedule or event

### Pattern 5: DynamoDB Streams (Not Currently Used)
**Potential:** Could trigger Lambdas on table updates

### Pattern 6: S3 Events → EventBridge → Lambda
**Used By:** KB sync  
**How:** S3 upload → EventBridge rule → KB builder Lambda

---

## Deployment Variants

The system has **3 deployment variants**:

### 1. Production (`pmi-agentic-ai-workflow`)
- Simplest workflow
- Uses: `pmi-input-validator`, `pmi-master-researcher`, `pmi-master-drafter`
- DynamoDB: `pmi-requests`, `pmi-users`

### 2. Client Demo 1 (`pmi-agentic-ai-workflow-client-demo1`)
- Includes HITL gate
- Uses: `*-client-demo1` suffix functions
- DEPLOYMENT_CONTEXT: "client-demo1"

### 3. Client Demo 2 (`pmi-research-workflow-client-demo2`)
- Full granular workflow with all phases
- Uses: `*-client-demo2` suffix functions
- Most advanced AI models (Opus 4.8 for reasoning)
- DEPLOYMENT_CONTEXT: "client-demo2"

---

## For QA Deployment: Critical Dependencies

### 1. External API Keys (Must Create New for QA)
- ✅ **Tavily API key** - Get QA key from tavily.com
- ✅ **AWS Bedrock bearer token** - Generate QA token
- ✅ **SharePoint credentials** - Create QA service account

### 2. DynamoDB Tables (Must Create 12 tables)
```
pmi-agentic-ai-requests-qa
pmi-agentic-ai-curated-links-qa
pmi-agentic-ai-hitl-qa
pmi-agentic-ai-activity-logs-qa
pmi-agentic-ai-request-timeline-qa
pmi-agentic-ai-workflow-executions-qa
pmi-agentic-ai-knowledge-base-qa
pmi-agentic-ai-users-qa
pmi-requests-qa
pmi-users-qa
document_metadata-qa
```

### 3. S3 Buckets (Must Create)
```
pmi-agentic-ai-documents-[QA-ACCOUNT-ID]-eu-west-1
pmi-agentic-ai-documents-sandbox-[QA-ACCOUNT-ID]
ccaiaa-kb-qa
```

### 4. Bedrock Knowledge Base (Must Create)
- Create new KB in QA
- Get new KB ID (replace OSJDPJLTNC)
- Update all Lambda env vars with QA KB ID

### 5. VPC & Networking (Must Replicate)
- VPC with same CIDR scheme
- Private subnets across 2 AZs
- Security group for Lambda-LLM
- NAT Gateway for external API calls

### 6. API Gateways (Must Create 4)
- pmi-agentic-ai-api-qa
- pmi-agentic-ai-api-qa-ui
- pmi-ingestion-api-qa
- pmi-agentic-ai-latest-records-api-qa

### 7. Step Functions (Must Create 3)
- pmi-agentic-ai-workflow-qa
- pmi-agentic-ai-workflow-client-demo1-qa
- pmi-research-workflow-client-demo2-qa

### 8. EventBridge Rules (Must Create 4)
- Daily SharePoint ingestion (cron)
- KB sync on S3 upload (event pattern)
- Patching helper (cron)
- Patching logger (event pattern)

### 9. Secrets Manager (Must Create)
- pmi/sharepoint/credentials-qa
- pmi-aurora-credentials-qa
- pmi-agentic-ai/aurora/pg-credentials-qa

### 10. IAM Roles (Must Create)
- pmi-lambda-execution-role-qa (with all policies)
- pmi-ingestion-role-qa
- pmi-stepfunctions-execution-role-qa
- API Gateway execution roles

---

## Recommendations for Terraform

### Module Structure
```
modules/
├── lambda/                  # Reusable Lambda module
├── api-gateway/            # API Gateway module
├── step-functions/         # Step Functions module
├── dynamodb/               # DynamoDB tables
├── knowledge-base/         # Bedrock KB setup
└── networking/             # VPC, subnets, security groups

environments/
├── dev/                    # Dev environment (current CA account)
└── qa/                     # QA environment (new)

```

### Variable Strategy
- Use `environment` variable: "dev", "qa", "prod"
- Suffix all resources with environment: `pmi-kb-searcher-${var.environment}`
- Separate tfvars files for each environment
- Store API keys in AWS Secrets Manager, reference in Terraform

### Next Steps
1. Review this architecture with dev team
2. Confirm which functions are needed for QA (likely all)
3. Decide on QA naming convention
4. Create Terraform modules for each functional group
5. Set up QA AWS account resources

---

**End of Analysis**