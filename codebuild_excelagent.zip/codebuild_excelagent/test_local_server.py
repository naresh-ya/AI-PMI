"""Local server test - send query to running AG-UI server."""

import requests
import json
import uuid                 
import sys
import os
from datetime import datetime

# Fix Windows console encoding issues
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except:
        pass

SERVER_URL = "http://127.0.0.1:8080/invocations"

# JWT Token (optional - set via environment variable or hardcode here)
JWT_TOKEN = os.environ.get('TEST_JWT_TOKEN', '')

def test_query(query: str, jwt_token: str = None):
    """Send query to local AG-UI server and print response.
    
    Args:
        query: The question to ask the agent
        jwt_token: Optional JWT token for user-specific month tracking
    """

    thread_id = f"local-test-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    run_id = f"run-{uuid.uuid4()}"

    payload = {
        "threadId": thread_id,
        "runId": run_id,
        "messages": [
            {
                "id": f"msg-{uuid.uuid4()}",
                "role": "user",
                "content": query
            }
        ],
        "state": {},
        "tools": [],
        "context": [],
        "forwardedProps": {}
    }
                                               
    print("=" * 80)
    print("LOCAL AG-UI SERVER TEST")
    print("=" * 80)
    print(f"Query: {query}")
    print(f"Thread ID: {thread_id}")
    print(f"Run ID: {run_id}")
    if jwt_token:
        print(f"JWT Token: Present (length: {len(jwt_token)})")
    else:
        print("JWT Token: Not provided (will use system default month)")
    print("=" * 80)
    print()

    # Prepare headers
    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream"
    }
    
    # Add JWT token if provided
    if jwt_token:
        headers["Authorization"] = f"Bearer {jwt_token}"

    try:
        response = requests.post(
            SERVER_URL,
            json=payload,
            headers=headers,
            stream=True,
            timeout=300
        )

        if response.status_code != 200:
            print(f"ERROR: Server returned status {response.status_code}")
            print(response.text)
            return

        print("Streaming response...")
        print("-" * 80)

        final_answer = ""
        step_count = 0
        verbose = True  # Set to False for less output

        # Track what we've already shown to avoid duplicates
        shown_fields = set()

        for line in response.iter_lines():
            if not line:
                continue

            line = line.decode('utf-8')

            if not line.startswith('data: '):
                continue

            data = line[6:]  # Remove 'data: ' prefix

            try:
                event = json.loads(data)
                event_type = event.get("type", "UNKNOWN")

                if event_type == "STEP_STARTED":
                    step_name = event.get("stepName", "?")
                    step_count += 1

                    # Custom messages for specific steps
                    custom_messages = {
                        "structure_analyzer": "Reviewing PMI files...",
                        "code_generator": "Generating code securely...",
                        "narrative_explainer": "Understanding the code, please wait..."
                    }

                    if step_name in custom_messages:
                        print(f"\n[{step_count}] STEP: {step_name} - {custom_messages[step_name]}")
                    else:
                        print(f"\n[{step_count}] STEP: {step_name}")

                elif event_type == "STEP_FINISHED":
                    # Don't print finish messages
                    pass

                elif event_type == "TEXT_MESSAGE_CONTENT":
                    delta = event.get("delta", "")
                    if delta:
                        print(delta, end="", flush=True)
                        final_answer += delta  # Accumulate the streamed content

                elif event_type == "STATE_SNAPSHOT":
                    snapshot = event.get("snapshot") or {}

                    if verbose:
                        output_lines = []
                         
                        # Context Enrichment - only show if NEW
                        if "context_enrichment_status" in snapshot and snapshot["context_enrichment_status"]:
                            if "context_enrichment_status" not in shown_fields:
                                output_lines.append("[Context Enrichment]")
                                status = snapshot["context_enrichment_status"]
                                output_lines.append(f"  Status: {status}")

                                # Show relatedness check details if available
                                relatedness = snapshot.get("relatedness_check")
                                if relatedness:
                                    output_lines.append(f"  Is Related: {relatedness.get('is_related', '?')}")
                                    output_lines.append(f"  Confidence: {relatedness.get('confidence', '?')}%")
                                    reasoning = relatedness.get('reasoning', '')
                                    if reasoning:
                                        output_lines.append(f"  Reasoning: {reasoning}")

                                # Show original vs enriched query
                                original_q = snapshot.get("original_query")
                                enriched_q = snapshot.get("enriched_query")
                                if original_q and enriched_q and original_q != enriched_q:
                                    output_lines.append(f"  Original Query: {original_q}")
                                    output_lines.append(f"  Enriched Query: {enriched_q}")

                                # Show previous Q+A if available
                                prev_qa = snapshot.get("previous_qa")
                                if prev_qa:
                                    output_lines.append(f"  Previous Question: {prev_qa.get('question', '')[:100]}...")
                                    output_lines.append(f"  Previous Answer: {prev_qa.get('answer', '')[:100]}...")

                                shown_fields.add("context_enrichment_status")

                        # Normalize Query (Glossary Matches) - only show if NEW
                        if "glossary_matches" in snapshot and snapshot["glossary_matches"]:
                            if "glossary_matches" not in shown_fields:
                                matches = snapshot["glossary_matches"]
                                if matches:
                                    output_lines.append("[Query Normalization]")
                                    output_lines.append(f"  Glossary Terms Matched: {len(matches)}")
                                    for match in matches:
                                        matched = match.get('matched_term', '?')
                                        canonical = match.get('canonical_term', '?')
                                        output_lines.append(f"    {matched} → {canonical}")
                                    shown_fields.add("glossary_matches")

                        # Domain Validation - only show if NEW
                        if "domain_validation" in snapshot and snapshot["domain_validation"]:
                            if "domain_validation" not in shown_fields:
                                dv = snapshot["domain_validation"]
                                output_lines.append("[Domain Validation]")

                                # Show question type
                                output_lines.append(f"  Question Type: {dv.get('question_type', '?')}")

                                # Show confidence
                                conf = dv.get('confidence_score', dv.get('confidence', '?'))
                                if conf != '?':
                                    output_lines.append(f"  Confidence: {conf}%")

                                # Show is_relevant flag if present
                                if 'is_relevant' in dv:
                                    output_lines.append(f"  Is Relevant: {dv.get('is_relevant')}")

                                # Show reason (full text)
                                reason = dv.get('reason', dv.get('confidence_reason', ''))
                                if reason:
                                    output_lines.append(f"  Reason: {reason}")

                                # Show greeting response if present
                                greeting = dv.get('greeting_response', '')
                                if greeting:
                                    output_lines.append(f"  Greeting: {greeting}")

                                # Show rejection message if present
                                rejection = dv.get('rejection_message', '')
                                if rejection:
                                    output_lines.append(f"  Rejection: {rejection}")

                                shown_fields.add("domain_validation")
                                 
                        # Intent Analysis - only show if NEW and NOT empty dict
                        if "analysis_spec" in snapshot:
                            intent = snapshot.get("analysis_spec")
                            # Check if it's a non-empty dict and we haven't shown it yet
                            if intent and isinstance(intent, dict) and "analysis_spec" not in shown_fields:
                                if output_lines:
                                    output_lines.append("")
                                output_lines.append("[Intent Analysis]")

                                # Show all fields from intent
                                analysis_type = intent.get('analysis_type', intent.get('intent', '?'))
                                output_lines.append(f"  Analysis Type: {analysis_type}")

                                metrics = intent.get('primary_metrics', intent.get('metrics', []))
                                if metrics:
                                    output_lines.append(f"  Primary Metrics: {', '.join(metrics)}")

                                # Show business dimensions
                                dimensions = intent.get('business_dimensions', [])
                                if dimensions:
                                    output_lines.append(f"  Business Dimensions: {', '.join(dimensions)}")

                                # Show time context
                                time_context = intent.get('time_context', '')
                                if time_context:
                                    output_lines.append(f"  Time Context: {time_context}")

                                # Show filters
                                filters = intent.get('filters', [])
                                if filters:
                                    output_lines.append(f"  Filters: {', '.join(filters)}")

                                # Show aggregations
                                aggregations = intent.get('aggregations', [])
                                if aggregations:
                                    output_lines.append(f"  Aggregations: {', '.join(aggregations)}")

                                # Show comparison context
                                comparison = intent.get('comparison_context', '')
                                if comparison:
                                    output_lines.append(f"  Comparison Context: {comparison}")

                                # Show output format
                                output_format = intent.get('output_format', '')
                                if output_format:
                                    output_lines.append(f"  Output Format: {output_format}")

                                # Show reasoning
                                reasoning = intent.get('reasoning', intent.get('reason', ''))
                                if reasoning:
                                    output_lines.append(f"  Reasoning: {reasoning}")

                                shown_fields.add("analysis_spec")

                        # Mapping Result - only show if NEW
                        if "mapping_result" in snapshot and snapshot["mapping_result"]:
                            if "mapping_result" not in shown_fields:
                                mapping = snapshot["mapping_result"]

                                if output_lines:
                                    output_lines.append("")
                                output_lines.append("[Sheet Mapping]")

                                # Show overall confidence
                                overall_conf = mapping.get("confidence", "?")
                                output_lines.append(f"  Overall Confidence: {overall_conf}%")

                                # Show confidence reason
                                conf_reason = mapping.get("confidence_reason", "")
                                if conf_reason:
                                    output_lines.append(f"  Confidence Reason: {conf_reason}")

                                # Show file and sheet mapping details
                                file_mapping = mapping.get("file_and_sheet_mapping", [])
                                if file_mapping:
                                    output_lines.append(f"  Number of Sources: {len(file_mapping)}")
                                    output_lines.append("")

                                    # Show all files (all of them, not just 5)
                                    for idx, entry in enumerate(file_mapping, 1):
                                        if len(file_mapping) > 1:
                                            output_lines.append(f"  Source {idx}:")
                                        output_lines.append(f"    File: {entry.get('file_name', '?')}")
                                        output_lines.append(f"    Sheet: {entry.get('tab_name', '?')}")
                                        output_lines.append(f"    Confidence: {entry.get('confidence', mapping.get('confidence', '?'))}%")

                                        # Show why
                                        why = entry.get('why', '')
                                        if why:
                                            output_lines.append(f"    Why: {why}")

                                        # Show how_to_reach_answer
                                        how_to = entry.get('how_to_reach_answer', '')
                                        if how_to:
                                            output_lines.append(f"    How to Reach Answer: {how_to}")

                                        # Show granularity type
                                        granularity = entry.get('granularity_type', '')
                                        if granularity:
                                            output_lines.append(f"    Granularity: {granularity}")

                                        # Show calculation approach
                                        calc_approach = entry.get('calculation_approach', '')
                                        if calc_approach:
                                            output_lines.append(f"    Calculation Approach: {calc_approach}")

                                        # Show priority rationale
                                        priority = entry.get('priority_rationale', '')
                                        if priority:
                                            output_lines.append(f"    Priority Rationale: {priority}")

                                        if idx < len(file_mapping):
                                            output_lines.append("")  # Blank line between sources

                                # Show warning if present
                                warning = mapping.get("warning")
                                if warning:
                                    output_lines.append("")
                                    output_lines.append(f"  WARNING: {warning}")

                                # Show linked files
                                linked = mapping.get("linked_files", [])
                                if linked:
                                    output_lines.append(f"  Linked Files: {', '.join(linked)}")

                                # Show requires cross-file
                                cross_file = mapping.get("requires_cross_file")
                                if cross_file is not None:
                                    output_lines.append(f"  Requires Cross-File: {cross_file}")

                                shown_fields.add("mapping_result")

                        # Sheet Selection - only show if NEW
                        if "sheet_selection_confidence" in snapshot and snapshot["sheet_selection_confidence"]:
                            if "sheet_selection_confidence" not in shown_fields:
                                sc = snapshot["sheet_selection_confidence"]
                                if output_lines:
                                    output_lines.append("")
                                output_lines.append("[Sheet Selector]")

                                # Overall metrics
                                output_lines.append(f"  Selected Sources: {len(sc.get('selected_sources', []))}")
                                output_lines.append(f"  Overall Confidence: {sc.get('overall_confidence', '?')}%")

                                # Overall reason
                                overall_reason = sc.get('overall_reason', '')
                                if overall_reason:
                                    output_lines.append(f"  Overall Reason: {overall_reason}")

                                # Show ALL per-source details (not just first 3)
                                sources = sc.get('selected_sources', [])
                                if sources:
                                    output_lines.append("")
                                    for idx, src in enumerate(sources, 1):
                                        output_lines.append(f"  Source {idx}: {src.get('file', '?')} / {src.get('sheet', '?')}")
                                        output_lines.append(f"    Confidence: {src.get('confidence', '?')}%")

                                        # Show reason for this source
                                        reason = src.get('reason', '')
                                        if reason:
                                            output_lines.append(f"    Reason: {reason}")

                                        # Show granularity
                                        granularity = src.get('granularity_type', '')
                                        if granularity:
                                            output_lines.append(f"    Granularity: {granularity}")

                                        # Show calculation approach
                                        calc = src.get('calculation_approach', '')
                                        if calc:
                                            output_lines.append(f"    Calculation: {calc}")

                                        if idx < len(sources):
                                            output_lines.append("")

                                shown_fields.add("sheet_selection_confidence")

                        # Sheet Selection Warning - only show if NEW
                        if "sheet_selection_warning" in snapshot and snapshot["sheet_selection_warning"]:
                            if "sheet_selection_warning" not in shown_fields:
                                warning = snapshot["sheet_selection_warning"]
                                if output_lines:
                                    output_lines.append("")
                                output_lines.append(f"  WARNING: {warning}")
                                shown_fields.add("sheet_selection_warning")

                        # Structure Analyzer - only show if NEW
                        if "structures" in snapshot and snapshot["structures"]:
                            if "structures" not in shown_fields:
                                structures = snapshot["structures"]
                                if output_lines:
                                    output_lines.append("")
                                output_lines.append("[Structure Analyzer]")
                                output_lines.append(f"  Number of Sources Analyzed: {len(structures)}")

                                # Show summary for each structure
                                for source_key, struct in structures.items():
                                    output_lines.append(f"  Source: {source_key}")

                                    # Show tables found
                                    tables = struct.get('tables', [])
                                    if tables:
                                        output_lines.append(f"    Tables Found: {len(tables)}")

                                    # Show hierarchies found
                                    hierarchies = struct.get('hierarchies', [])
                                    if hierarchies:
                                        output_lines.append(f"    Hierarchies Found: {len(hierarchies)}")

                                    # Show catalog info
                                    catalog = struct.get('catalog', {})
                                    if catalog:
                                        total_cols = catalog.get('total_columns', 0)
                                        total_rows = catalog.get('total_rows', 0)
                                        if total_cols or total_rows:
                                            output_lines.append(f"    Dimensions: {total_rows} rows × {total_cols} columns")

                                shown_fields.add("structures")

                        # Query Context Builder Summary - only show if NEW
                        if "context_builder_summary" in snapshot and snapshot["context_builder_summary"]:
                            if "context_builder_summary" not in shown_fields:
                                if output_lines:
                                    output_lines.append("")
                                output_lines.append("[Query Context Builder]")
                                output_lines.append(f"  Summary: {snapshot['context_builder_summary']}")
                                shown_fields.add("context_builder_summary")

                        # Matched Filters - only show if NEW
                        if "matched_filters" in snapshot and snapshot["matched_filters"]:
                            if "matched_filters" not in shown_fields:
                                filters = snapshot["matched_filters"]
                                if filters:
                                    if not output_lines or output_lines[-1] != "[Query Context Builder]":
                                        if output_lines:
                                            output_lines.append("")
                                        output_lines.append("[Query Context Builder]")
                                    output_lines.append(f"  Matched Filters: {len(filters)}")
                                    for f in filters:
                                        user_term = f.get('user_term', '?')
                                        column = f.get('column', '?')
                                        col_num = f.get('column_number', '?')
                                        exact_val = f.get('exact_value', '?')
                                        output_lines.append(f"    '{user_term}' → Column {column} (#{col_num}) = '{exact_val}'")
                                    shown_fields.add("matched_filters")

                        # Measure Columns - only show if NEW
                        if "measure_columns" in snapshot and snapshot["measure_columns"]:
                            if "measure_columns" not in shown_fields:
                                measures = snapshot["measure_columns"]
                                if measures:
                                    if not output_lines or output_lines[-1] != "[Query Context Builder]":
                                        if output_lines:
                                            output_lines.append("")
                                        output_lines.append("[Query Context Builder]")
                                    output_lines.append(f"  Measure Columns: {len(measures)}")
                                    for m in measures:
                                        column = m.get('column', '?')
                                        col_num = m.get('column_number', '?')
                                        desc = m.get('description', '')
                                        if desc:
                                            output_lines.append(f"    Column {column} (#{col_num}): {desc}")
                                        else:
                                            output_lines.append(f"    Column {column} (#{col_num})")
                                    shown_fields.add("measure_columns")

                        # Operation Detail & Reasoning - show for ALL sources
                        if "column_usage" in snapshot and snapshot["column_usage"]:
                            if "operation_detail" not in shown_fields:
                                column_usage = snapshot["column_usage"]
                                if column_usage:
                                    # Add header once
                                    if not output_lines or output_lines[-1] != "[Query Context Builder]":
                                        if output_lines:
                                            output_lines.append("")
                                        output_lines.append("[Query Context Builder]")

                                    # Show operation detail and reasoning for EACH source
                                    for source_key, source_data in column_usage.items():
                                        operation = source_data.get('operation', '')
                                        operation_detail = source_data.get('operation_detail', '')
                                        reasoning = source_data.get('reasoning', '')
                                        file_name = source_data.get('file', '')
                                        sheet_name = source_data.get('sheet', '')

                                        if operation_detail or reasoning:
                                            output_lines.append(f"\n  Source: {file_name} :: {sheet_name}")
                                            if operation:
                                                output_lines.append(f"    Operation: {operation}")
                                            if operation_detail:
                                                output_lines.append(f"    Operation Detail: {operation_detail}")
                                            if reasoning:
                                                output_lines.append(f"    Reasoning: {reasoning}")

                                    shown_fields.add("operation_detail")

                        # Query Context Builder Confidence - only show if NEW
                        if "context_builder_confidence" in snapshot and snapshot["context_builder_confidence"]:
                            if "context_builder_confidence" not in shown_fields:
                                cbc = snapshot["context_builder_confidence"]
                                if not output_lines or output_lines[-1] != "[Query Context Builder]":
                                    if output_lines:
                                        output_lines.append("")
                                    output_lines.append("[Query Context Builder]")
                                output_lines.append(f"  Confidence: {cbc.get('overall_confidence', '?')}%")
                                output_lines.append(f"  Column Relevance: {cbc.get('column_relevance_score', '?')}%")

                                # Show details if present
                                details = cbc.get('details', '')
                                if details:
                                    output_lines.append(f"  Details: {details}")

                                # Show potential issues if any
                                issues = cbc.get('potential_issues', [])
                                if issues and issues != ['None']:
                                    output_lines.append(f"  Issues: {', '.join(issues)}")

                                shown_fields.add("context_builder_confidence")

                        # Code Execution - only show if NEW
                        if "execution_result" in snapshot and snapshot["execution_result"]:
                            if "execution_result" not in shown_fields:
                                result = snapshot["execution_result"]
                                if output_lines:
                                    output_lines.append("")
                                output_lines.append("[Code Execution]")
                                if result.get('success'):
                                    output_lines.append(f"  Status: Results generated successfully")
                                else:
                                    output_lines.append(f"  Status: Error")
                                    # Show full error without truncation
                                    error = result.get('error', '')
                                    if error:
                                        for line in error.split('\n')[:10]:  # Limit to 10 lines for readability
                                            output_lines.append(f"  Error: {line}")
                                shown_fields.add("execution_result")

                        # Narrative Confidence - REMOVED

                        # Only print if there's new data
                        if output_lines:
                            print("\n".join(output_lines))

                        # Final Answer - capture if present (check both final_answer and answer fields)
                        answer = snapshot.get("final_answer") or snapshot.get("answer")
                        if answer and isinstance(answer, str) and answer.strip():
                            final_answer = answer
                    else:
                        answer = snapshot.get("final_answer") or snapshot.get("answer")
                        if answer and isinstance(answer, str) and answer.strip():
                            final_answer = answer

                elif event_type == "RUN_FINISHED":
                    outcome = event.get("outcome") or {}
                    print(f"\n\n{'='*80}")
                    print(f"[FINISHED] Outcome: {outcome.get('type', 'success')}")
                    print(f"{'='*80}")

                elif event_type == "RUN_ERROR":
                    print(f"\n\n{'='*80}")
                    print(f"[ERROR] {event.get('code')}: {event.get('message')}")
                    print(f"{'='*80}")

            except json.JSONDecodeError:
                continue

        print()
        print("=" * 80)

        if final_answer:
            print("FINAL ANSWER:")
            print("=" * 80)
            print(final_answer)
        else:
            print("No final answer captured (check steps above)")

        print("=" * 80)
        print("Test completed successfully!")

    except requests.exceptions.RequestException as e:
        print(f"ERROR: Request failed: {e}")
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # Fixed: removed unicode dash character (U+2011)
    query = "Hi, please help with Marlboro volume trends from Oct'25 to Apr'26 for Delhi NCR"
    
    # Use JWT token from environment variable or pass it directly
    jwt_token = JWT_TOKEN if JWT_TOKEN else None
    
    if not jwt_token:
        print("\n" + "="*80)
        print("NOTE: No JWT token provided - using system default month")
        print("To use user-specific month, set environment variable:")
        print('  $env:TEST_JWT_TOKEN="your-token-here"  (PowerShell)')
        print('  export TEST_JWT_TOKEN="your-token-here"  (Bash)')
        print("="*80 + "\n")
    
    test_query(query, jwt_token)
