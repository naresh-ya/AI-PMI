#!/bin/bash

##############################################################################
# AWS ECR + CodeBuild Setup Script
# This script automates the complete setup of ECR repository and CodeBuild
##############################################################################

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

##############################################################################
# Configuration Variables
##############################################################################

# Prompt for AWS credentials if not set
if [ -z "$AWS_ACCESS_KEY_ID" ]; then
    read -p "Enter AWS_ACCESS_KEY_ID: " AWS_ACCESS_KEY_ID
    export AWS_ACCESS_KEY_ID
fi

if [ -z "$AWS_SECRET_ACCESS_KEY" ]; then
    read -sp "Enter AWS_SECRET_ACCESS_KEY: " AWS_SECRET_ACCESS_KEY
    echo
    export AWS_SECRET_ACCESS_KEY
fi

if [ -z "$AWS_SESSION_TOKEN" ]; then
    read -sp "Enter AWS_SESSION_TOKEN (press Enter to skip if not using temporary credentials): " AWS_SESSION_TOKEN
    echo
    export AWS_SESSION_TOKEN
fi

# Get AWS region
AWS_REGION=${AWS_DEFAULT_REGION:-$(aws configure get region || echo "eu-west-1")}
print_info "Using AWS Region: $AWS_REGION"

# Get AWS Account ID
print_info "Getting AWS Account ID..."
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
print_success "AWS Account ID: $AWS_ACCOUNT_ID"

# Repository Configuration
ECR_REPO_NAME=${ECR_REPO_NAME:-"excelagent"}
ECR_REPO_NAME_SECONDARY=${ECR_REPO_NAME_SECONDARY:-"excel-agent"}
IMAGE_TAG_SECONDARY=${IMAGE_TAG_SECONDARY:-"improvedspeeddeployedOn29thJune"}

# CodeBuild Configuration
CODEBUILD_PROJECT_NAME=${CODEBUILD_PROJECT_NAME:-"excelagent-build"}
CODEBUILD_SERVICE_ROLE=${CODEBUILD_SERVICE_ROLE:-"CodeBuildServiceRole"}
GITHUB_REPO=${GITHUB_REPO:-"https://github.com/ShivamCapgemini23/codebuild_excelagent.git"}

print_info "Configuration:"
echo "  - Primary ECR Repository: $ECR_REPO_NAME"
echo "  - Secondary ECR Repository: $ECR_REPO_NAME_SECONDARY"
echo "  - Secondary Image Tag: $IMAGE_TAG_SECONDARY"
echo "  - CodeBuild Project: $CODEBUILD_PROJECT_NAME"
echo "  - GitHub Repository: $GITHUB_REPO"
echo ""

read -p "Continue with this configuration? (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_error "Setup cancelled by user"
    exit 1
fi

##############################################################################
# Step 1: Create Primary ECR Repository
##############################################################################

print_info "Step 1: Creating primary ECR repository: $ECR_REPO_NAME"

if aws ecr describe-repositories --repository-names "$ECR_REPO_NAME" --region "$AWS_REGION" &>/dev/null; then
    print_warning "Repository $ECR_REPO_NAME already exists, skipping creation"
else
    aws ecr create-repository \
        --repository-name "$ECR_REPO_NAME" \
        --image-scanning-configuration scanOnPush=true \
        --region "$AWS_REGION" \
        --output json > /dev/null
    print_success "Created ECR repository: $ECR_REPO_NAME"
fi

PRIMARY_REPO_URI="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${ECR_REPO_NAME}"
print_success "Primary Repository URI: $PRIMARY_REPO_URI"

##############################################################################
# Step 2: Verify Secondary ECR Repository Exists
##############################################################################

print_info "Step 2: Checking secondary ECR repository: $ECR_REPO_NAME_SECONDARY"

if aws ecr describe-repositories --repository-names "$ECR_REPO_NAME_SECONDARY" --region "$AWS_REGION" &>/dev/null; then
    print_success "Secondary repository $ECR_REPO_NAME_SECONDARY exists"
else
    print_warning "Secondary repository $ECR_REPO_NAME_SECONDARY does not exist"
    read -p "Create it? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        aws ecr create-repository \
            --repository-name "$ECR_REPO_NAME_SECONDARY" \
            --image-scanning-configuration scanOnPush=true \
            --region "$AWS_REGION" \
            --output json > /dev/null
        print_success "Created ECR repository: $ECR_REPO_NAME_SECONDARY"
    fi
fi

SECONDARY_REPO_URI="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${ECR_REPO_NAME_SECONDARY}"
print_success "Secondary Repository URI: $SECONDARY_REPO_URI"

##############################################################################
# Step 3: Create buildspec.yml
##############################################################################

print_info "Step 3: Creating buildspec.yml file"

cat > buildspec.yml << 'EOF'
version: 0.2

phases:
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com
      - REPOSITORY_URI=$AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$IMAGE_REPO_NAME
      - COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-7)
      - IMAGE_TAG=${COMMIT_HASH:=tillMonthchangesperscreen}
      - echo "Repository URI is $REPOSITORY_URI"
      - echo "Image tag is $IMAGE_TAG"

  build:
    commands:
      - echo Build started on `date`
      - echo Building the Docker image...
      - docker build -t $IMAGE_REPO_NAME:tillMonthchangesperscreen .
      - docker tag $IMAGE_REPO_NAME:tillMonthchangesperscreen $REPOSITORY_URI:tillMonthchangesperscreen
      - docker tag $IMAGE_REPO_NAME:tillMonthchangesperscreen $REPOSITORY_URI:$IMAGE_TAG

  post_build:
    commands:
      - echo Build completed on `date`
      - echo Pushing the Docker images...
      - docker push $REPOSITORY_URI:tillMonthchangesperscreen
      - docker push $REPOSITORY_URI:$IMAGE_TAG
      - echo Pushing to excel-agent repository with special tag...
      - EXCEL_AGENT_URI=$AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/excel-agent
      - docker tag $IMAGE_REPO_NAME:tillMonthchangesperscreen $EXCEL_AGENT_URI:improvedspeeddeployedOn29thJune
      - docker push $EXCEL_AGENT_URI:improvedspeeddeployedOn29thJune
      - echo Writing image definitions file...
      - printf '[{"name":"%s","imageUri":"%s"}]' $IMAGE_REPO_NAME $REPOSITORY_URI:$IMAGE_TAG > imagedefinitions.json

artifacts:
  files:
    - imagedefinitions.json
EOF

print_success "buildspec.yml created successfully"

##############################################################################
# Step 4: Create/Update CodeBuild Project
##############################################################################

print_info "Step 4: Creating CodeBuild project: $CODEBUILD_PROJECT_NAME"

# Check if service role exists
ROLE_ARN="arn:aws:iam::${AWS_ACCOUNT_ID}:role/${CODEBUILD_SERVICE_ROLE}"

if aws iam get-role --role-name "$CODEBUILD_SERVICE_ROLE" &>/dev/null; then
    print_success "IAM Role $CODEBUILD_SERVICE_ROLE exists"
else
    print_error "IAM Role $CODEBUILD_SERVICE_ROLE does not exist. Please create it first."
    exit 1
fi

# Check if CodeBuild project already exists
if aws codebuild batch-get-projects --names "$CODEBUILD_PROJECT_NAME" --region "$AWS_REGION" --query 'projects[0].name' --output text 2>/dev/null | grep -q "$CODEBUILD_PROJECT_NAME"; then
    print_warning "CodeBuild project $CODEBUILD_PROJECT_NAME already exists"
    read -p "Update the existing project? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        aws codebuild update-project \
            --name "$CODEBUILD_PROJECT_NAME" \
            --source type=GITHUB,location="$GITHUB_REPO",buildspec=buildspec.yml \
            --environment type=LINUX_CONTAINER,image=aws/codebuild/standard:7.0,computeType=BUILD_GENERAL1_SMALL,privilegedMode=true,environmentVariables="[{name=AWS_DEFAULT_REGION,value=${AWS_REGION},type=PLAINTEXT},{name=AWS_ACCOUNT_ID,value=${AWS_ACCOUNT_ID},type=PLAINTEXT},{name=IMAGE_REPO_NAME,value=${ECR_REPO_NAME},type=PLAINTEXT}]" \
            --region "$AWS_REGION" \
            --output json > /dev/null
        print_success "Updated CodeBuild project: $CODEBUILD_PROJECT_NAME"
    fi
else
    aws codebuild create-project \
        --name "$CODEBUILD_PROJECT_NAME" \
        --description "Build and push Excel Agent Docker image to ECR" \
        --source type=GITHUB,location="$GITHUB_REPO",buildspec=buildspec.yml \
        --artifacts type=NO_ARTIFACTS \
        --environment type=LINUX_CONTAINER,image=aws/codebuild/standard:7.0,computeType=BUILD_GENERAL1_SMALL,privilegedMode=true,environmentVariables="[{name=AWS_DEFAULT_REGION,value=${AWS_REGION},type=PLAINTEXT},{name=AWS_ACCOUNT_ID,value=${AWS_ACCOUNT_ID},type=PLAINTEXT},{name=IMAGE_REPO_NAME,value=${ECR_REPO_NAME},type=PLAINTEXT}]" \
        --service-role "$ROLE_ARN" \
        --region "$AWS_REGION" \
        --output json > /dev/null
    print_success "Created CodeBuild project: $CODEBUILD_PROJECT_NAME"
fi

##############################################################################
# Step 5: Commit and Push to Git (Optional)
##############################################################################

print_info "Step 5: Git operations"

if [ -d .git ]; then
    read -p "Commit and push buildspec.yml to GitHub? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        git add buildspec.yml
        git commit -m "Add/Update CodeBuild buildspec for ECR automated deployment" || print_warning "No changes to commit"

        read -p "Push to main branch? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
            git push origin "$CURRENT_BRANCH:main"
            print_success "Pushed to GitHub"
        fi
    fi
else
    print_warning "Not a git repository. Skipping git operations."
fi

##############################################################################
# Step 6: Start Build
##############################################################################

print_info "Step 6: Starting CodeBuild build"

read -p "Start a build now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    BUILD_OUTPUT=$(aws codebuild start-build --project-name "$CODEBUILD_PROJECT_NAME" --region "$AWS_REGION" --output json)
    BUILD_ID=$(echo "$BUILD_OUTPUT" | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)
    print_success "Build started: $BUILD_ID"

    print_info "Monitoring build status (this may take 5-10 minutes)..."

    # Monitor build status
    while true; do
        BUILD_STATUS=$(aws codebuild batch-get-builds --ids "$BUILD_ID" --region "$AWS_REGION" --query 'builds[0].buildStatus' --output text)
        BUILD_PHASE=$(aws codebuild batch-get-builds --ids "$BUILD_ID" --region "$AWS_REGION" --query 'builds[0].currentPhase' --output text)

        if [ "$BUILD_STATUS" = "SUCCEEDED" ]; then
            print_success "Build completed successfully!"
            break
        elif [ "$BUILD_STATUS" = "FAILED" ] || [ "$BUILD_STATUS" = "FAULT" ] || [ "$BUILD_STATUS" = "TIMED_OUT" ] || [ "$BUILD_STATUS" = "STOPPED" ]; then
            print_error "Build failed with status: $BUILD_STATUS"
            exit 1
        else
            print_info "Build in progress... Phase: $BUILD_PHASE, Status: $BUILD_STATUS"
            sleep 30
        fi
    done

    ##############################################################################
    # Step 7: Verify Images
    ##############################################################################

    print_info "Step 7: Verifying images in ECR"

    # Check primary repository
    print_info "Images in $ECR_REPO_NAME repository:"
    aws ecr describe-images --repository-name "$ECR_REPO_NAME" --region "$AWS_REGION" --query 'imageDetails[*].[imageTags[0],imagePushedAt,imageSizeInBytes]' --output table

    # Check secondary repository
    print_info "Images in $ECR_REPO_NAME_SECONDARY repository:"
    aws ecr describe-images --repository-name "$ECR_REPO_NAME_SECONDARY" --region "$AWS_REGION" --query 'imageDetails[*].[imageTags[0],imagePushedAt,imageSizeInBytes]' --output table

    print_success "Image with tag '$IMAGE_TAG_SECONDARY' is now available in $ECR_REPO_NAME_SECONDARY repository"
fi

##############################################################################
# Summary
##############################################################################

echo ""
echo "=========================================================================="
echo -e "${GREEN}Setup Complete!${NC}"
echo "=========================================================================="
echo ""
echo "Resources Created:"
echo "  ✓ ECR Repository: $ECR_REPO_NAME"
echo "  ✓ ECR Repository URI: $PRIMARY_REPO_URI"
echo "  ✓ Secondary ECR: $ECR_REPO_NAME_SECONDARY"
echo "  ✓ Secondary URI: $SECONDARY_REPO_URI"
echo "  ✓ CodeBuild Project: $CODEBUILD_PROJECT_NAME"
echo "  ✓ buildspec.yml created"
echo ""
echo "Image Locations:"
echo "  • ${PRIMARY_REPO_URI}:tillMonthchangesperscreen"
echo "  • ${SECONDARY_REPO_URI}:${IMAGE_TAG_SECONDARY}"
echo ""
echo "Pull Command:"
echo "  aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin ${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
echo "  docker pull ${SECONDARY_REPO_URI}:${IMAGE_TAG_SECONDARY}"
echo ""
echo "AWS Console Links:"
echo "  • ECR: https://${AWS_REGION}.console.aws.amazon.com/ecr/repositories/private/${AWS_ACCOUNT_ID}/${ECR_REPO_NAME_SECONDARY}"
echo "  • CodeBuild: https://${AWS_REGION}.console.aws.amazon.com/codesuite/codebuild/projects/${CODEBUILD_PROJECT_NAME}"
echo ""
echo "To start a new build:"
echo "  aws codebuild start-build --project-name $CODEBUILD_PROJECT_NAME --region $AWS_REGION"
echo ""
echo "=========================================================================="
