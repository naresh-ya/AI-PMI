"""AG-UI graph wrapper for Excel Agent pipeline.

This module wraps your existing Excel analysis pipeline to work with AG-UI protocol.

Architecture:
    AG-UI Request → parse_messages → existing pipeline → format_response → AG-UI Response

Key additions:
1. Message parser: Extracts query from AG-UI messages
2. Interrupt handler: Replaces input() with LangGraph interrupts for confidence < 90
3. Response formatter: Converts pipeline output to conversational messages
4. Checkpointer: Postgres for production HITL, MemorySaver for local dev

Information sources:
- Your existing pipeline: graphs/langgraph.py (build_pipeline function)
- Interrupt mechanism: LangGraph docs on interrupt_before/interrupt_after
- Durable checkpoints: LangGraph Postgres checkpointer docs
- node2 logic: nodes/node2.py (confidence < 90 follow-up questions)
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict, List

from langchain_core.messages import AIMessage, HumanMessage
from langgraph.graph import END, StateGraph
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)

from agui.state import AGUIExcelState
from core.settings import settings
from helpers.s3_storage import default_raw_s3_uri, default_output_s3_uri
from helpers.file_registry import discover_excel_files

_FORCE_MEMORY_CHECKPOINTER = os.getenv(
    "EXCEL_AGENT_FORCE_MEMORY_CHECKPOINTER", ""
).strip().lower() in {"1", "true", "yes", "on"}
_POSTGRES_POOL = None
_POSTGRES_SAVER = None


# ═══════════════════════════════════════════════════════════════════════════
# CHECKPOINTER CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

def _normalize_backend_name() -> str:
    """Resolve the requested checkpoint backend from settings."""
    backend = (settings.checkpoint_backend or "auto").strip().lower()
    valid = {"auto", "memory", "postgres"}
    if backend not in valid:
        raise ValueError(
            "EXCEL_AGENT_CHECKPOINT_BACKEND must be one of: auto, memory, postgres"
        )

    if backend == "auto":
        return "postgres" if settings.checkpoint_postgres_dsn else "memory"
    return backend


def _durable_runtime_error() -> RuntimeError:
    """Create a clear production error for missing durable checkpoint config."""
    return RuntimeError(
        "Durable checkpointing is required for AG-UI HITL in production. "
        "Configure EXCEL_AGENT_CHECKPOINT_BACKEND=postgres and provide "
        "EXCEL_AGENT_CHECKPOINT_POSTGRES_DSN to a reachable Postgres instance."
    )


async def _get_postgres_checkpointer():
    """Create or reuse the shared AsyncPostgresSaver instance."""
    global _POSTGRES_POOL, _POSTGRES_SAVER

    if _POSTGRES_SAVER is not None:
        return _POSTGRES_SAVER

    postgres_dsn = (settings.checkpoint_postgres_dsn or "").strip()
    if not postgres_dsn:
        raise _durable_runtime_error()

    try:
        from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
        from psycopg.rows import dict_row
        from psycopg_pool import AsyncConnectionPool
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Postgres checkpoint dependencies are missing. Install "
            "langgraph-checkpoint-postgres and psycopg[binary,pool]."
        ) from exc

    pool_kwargs = {
        "autocommit": True,
        "row_factory": dict_row,
        # Avoid prepared-statement issues with poolers and keep the runtime portable.
        "prepare_threshold": 0,
    }
    _POSTGRES_POOL = AsyncConnectionPool(
        conninfo=postgres_dsn,
        min_size=settings.checkpoint_postgres_min_pool_size,
        max_size=settings.checkpoint_postgres_max_pool_size,
        open=False,
        timeout=settings.checkpoint_postgres_timeout_seconds,
        kwargs=pool_kwargs,
    )

    try:
        await _POSTGRES_POOL.open(
            wait=True,
            timeout=settings.checkpoint_postgres_timeout_seconds,
        )
        _POSTGRES_SAVER = AsyncPostgresSaver(conn=_POSTGRES_POOL)
        await _POSTGRES_SAVER.setup()
    except Exception:
        await _POSTGRES_POOL.close()
        _POSTGRES_POOL = None
        _POSTGRES_SAVER = None
        raise

    return _POSTGRES_SAVER


async def get_checkpointer():
    """No checkpointer needed - HITL disabled."""
    return None


async def close_checkpointer() -> None:
    """Close persistent async checkpoint resources on server shutdown."""
    global _POSTGRES_POOL, _POSTGRES_SAVER

    if _POSTGRES_POOL is not None:
        await _POSTGRES_POOL.close()
        _POSTGRES_POOL = None
        _POSTGRES_SAVER = None


# ═══════════════════════════════════════════════════════════════════════════
# MESSAGE PARSING NODE
# ═══════════════════════════════════════════════════════════════════════════

def parse_messages_node(state: AGUIExcelState) -> AGUIExcelState:
    """Extract query and Excel files from AG-UI messages.

    What this does:
    1. Takes AG-UI messages (from frontend chat)
    2. Extracts user's query from last HumanMessage
    3. Discovers Excel files from S3 (same as main.py does)
    4. Sets output_dir (S3 URI for AgentCore compatibility)
    5. Sets "question" field for node2 compatibility

    Why needed:
    Your existing pipeline expects `query` field directly.
    AG-UI sends `messages` list instead.
    Node2 steps expect `question` field.

    Flow:
        AG-UI: {"messages": [{"role": "user", "content": "What's the revenue?"}]}
        →
        Pipeline: {"query": "What's the revenue?", "question": "What's the revenue?", "excel_files": ["s3://bucket/file1.xlsx", ...]}

    Source: Your main.py:38-39 (discover_excel_files)
    """
    messages = state.get("messages", [])

    # Extract query from last human message
    query = ""
    for msg in reversed(messages):
        if isinstance(msg, HumanMessage):
            query = msg.content
            break

    # Get Excel files from state or discover from S3
    # This matches what main.py does: discover_excel_files([s3_dir])
    excel_files = state.get("excel_files")
    if not excel_files:
        # Get default S3 directory and discover all Excel files in it
        default_uri = default_raw_s3_uri()
        if default_uri:
            # Use discover_excel_files to expand directory into file list
            # This is the key fix: same logic as main.py line 39
            excel_files = discover_excel_files([default_uri])
        else:
            excel_files = []

    # Set output directory - use S3 for both local and AgentCore
    # This ensures the same code works in both environments
    output_dir = state.get("output_dir")
    if not output_dir:
        output_dir = default_output_s3_uri() or "s3://mbr-data-lake/analysis-output/"

    # Get thread_id for memory session
    # Server injects threadId into state before calling graph
    thread_id = state.get("threadId") or state.get("thread_id")

    if not thread_id:
        from datetime import datetime
        thread_id = f"session-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        logger.warning("No threadId in state - generated fallback session: %s", thread_id)

    # Preserve user_jwt_token from server injection
    user_jwt_token = state.get("user_jwt_token")
    if user_jwt_token:
        logger.info("✅ [parse_messages] Preserving user JWT token (length: %d)", len(user_jwt_token))
    else:
        logger.warning("⚠️ [parse_messages] No user JWT token found in state")

    return {
        "query": query,
        "question": query,  # Node2 compatibility
        "original_query": query,  # NEW: Preserve for memory storage
        "excel_files": excel_files,
        "output_dir": output_dir,
        "memory_session_id": thread_id,  # NEW: Use threadId as memory session
        "context_enrichment_applied": False,  # NEW: Default to False
        "user_jwt_token": user_jwt_token,  # NEW: Preserve JWT token for user-specific month tracking
    }


# ═══════════════════════════════════════════════════════════════════════════
# RESPONSE FORMATTING NODE
# ═══════════════════════════════════════════════════════════════════════════

def format_response_node(state: AGUIExcelState) -> AGUIExcelState:
    """Convert pipeline output to AG-UI message format.

    What this does:
    1. Takes final_answer (from full pipeline) OR answer (from domain_validation shortcuts)
    2. Wraps it in AIMessage
    3. Returns updated messages list

    Why needed:
    Your pipeline produces `final_answer` string for financial queries.
    Domain validation produces `answer` string for greetings/rejections.
    AG-UI needs messages list for chat display.

    Flow:
        Full Pipeline: {"final_answer": "Total revenue is $10M"}
        → AG-UI: {"messages": [..., AIMessage(content="Total revenue is $10M")]}

        Greeting/Rejection: {"answer": "Hello! I'm your PMI assistant..."}
        → AG-UI: {"messages": [..., AIMessage(content="Hello! I'm your PMI assistant...")]}

    Source: narrative_explainer_node (full pipeline) or domain_validation_node (shortcuts)
    """
    # Priority 1: Check final_answer (from full pipeline - financial queries)
    final_answer = state.get("final_answer", "")

    # Priority 2: Fallback to answer field (from domain_validation - greetings/rejections)
    if not final_answer:
        final_answer = state.get("answer", "")

    # Priority 3: Final fallback if neither field is populated
    if not final_answer:
        final_answer = "I couldn't process your query. Please check the Excel files and try again."

    return {
        "messages": [AIMessage(content=final_answer)],
        "final_answer": final_answer  # Preserve in state for test script to capture
    }


# ═══════════════════════════════════════════════════════════════════════════
# PROGRESS STREAMING NODES (Optional but recommended)
# ═══════════════════════════════════════════════════════════════════════════

def send_progress(state: AGUIExcelState, message: str) -> AGUIExcelState:
    """Send progress update to user.

    What this does:
    Streams intermediate progress messages to user during long operations.

    Why needed:
    Your pipeline can take 30-60s (profiling, structure analysis, code execution).
    Users need feedback that agent is working.

    Example:
        "Analyzing Excel structure..." → User sees this in chat
        "Generating code..." → User sees this in chat
        "Total revenue is $10M" → Final answer

    Source: AG-UI streaming pattern (messages are streamed as they're added)
    """
    return {
        "messages": [AIMessage(content=message)]
    }


# Node wrappers defined inside build_agui_graph() where imports are available


def sheet_selector_wrapper(state: AGUIExcelState) -> AGUIExcelState:
    """Wrapper for sheet_selector that copies selected_sources to top level."""
    from nodes.node2 import sheet_selector_node as _sheet_selector

    # Run original sheet_selector
    result = _sheet_selector(state)

    # Copy selected_sources from mapping_result to top level for downstream nodes
    mapping = result.get("mapping_result") or state.get("mapping_result") or {}
    selected = mapping.get("selected_sources", [])

    if selected:
        result["selected_sources"] = selected

    return result


def _normalize_followup_answers(raw_response: Any, questions: List[str]) -> str:
    """Convert AG-UI resume payloads into the clarification text node2 expects."""
    if raw_response is None:
        return ""

    if isinstance(raw_response, dict):
        if isinstance(raw_response.get("answers"), list):
            answers = [str(answer).strip() for answer in raw_response["answers"]]
            pairs = [
                f"- {question}: {answer}"
                for question, answer in zip(questions, answers)
                if answer
            ]
            return "\n".join(pairs)

        for key in ("answer", "response", "text"):
            value = raw_response.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()

        return json.dumps(raw_response, ensure_ascii=False)

    if isinstance(raw_response, list):
        answers = [str(answer).strip() for answer in raw_response if str(answer).strip()]
        pairs = [
            f"- {question}: {answer}"
            for question, answer in zip(questions, answers)
            if answer
        ]
        return "\n".join(pairs) if pairs else "\n".join(answers)

    return str(raw_response).strip()


# ═══════════════════════════════════════════════════════════════════════════
# BUILD AG-UI COMPATIBLE GRAPH
# ═══════════════════════════════════════════════════════════════════════════

async def build_agui_graph() -> StateGraph:
    """Build AG-UI compatible graph with flattened node2 steps for full visibility.

    Graph topology (flattened):
        START
          → parse_messages
          → normalize_query (node2 step 1)
          → domain_validation (node2 step 2)
          → intent (node2 step 3)
          → mapping (node2 step 4)
          → sheet_selector (node2 step 5)
          → structure_analyzer
          → query_context_builder
          → code_generator
          → code_executor
          → narrative_explainer
          → context_storage
          → format_response
          → END

    Key change: Flattened node2 subgraph so AG-UI can stream intermediate state.
    Each node2 step now emits STATE_SNAPSHOT with visible data.
    """

    # Import node2 individual steps (previously hidden in subgraph)
    from nodes.node2 import (
        normalize_query_node,
        domain_validation_node,
        intent_node,
        mapping_node,
    )

    # Import context enrichment nodes (NEW)
    from nodes.context_enricher import context_enrichment_node
    from nodes.context_storage import context_storage_node

    # Import rest of pipeline nodes
    from nodes.structure_analyzer import structure_analyzer_node
    from nodes.async_query_context_builder import async_query_context_builder_node  # NEW - ASYNC
    from nodes.code_generator import code_generator_node
    from nodes.code_executor import code_executor_node
    from nodes.async_parallel_executor import async_parallel_executor_node  # NEW - TRUE parallelism
    from nodes.narrative_explainer import narrative_explainer_node
    from nodes.context_storage import context_storage_node
    # from nodes.confidence_summary import confidence_summary_node  # REMOVED

    # Create graph with AG-UI state
    graph = StateGraph(AGUIExcelState)

    # ── Create node wrappers ──

    async def intent_wrapper(state):
        """Wrapper to ensure analysis_spec is properly set, handle field compatibility, and preserve JWT token."""
        # Preserve JWT token
        user_jwt_token = state.get("user_jwt_token")
        
        # Ensure normalized_question exists - use query as fallback
        if "normalized_question" not in state:
            state = dict(state)
            state["normalized_question"] = state.get("query", "")

        # intent_node is an async generator - consume it
        result = state
        async for value in intent_node(state):
            result = value
        
        # Ensure JWT token is preserved
        if user_jwt_token and "user_jwt_token" not in result:
            result = dict(result)
            result["user_jwt_token"] = user_jwt_token
        
        return result

    def selector_wrapper(state):
        """Wrapper to copy selected_sources to top-level state, filter by confidence, load registry, and resolve file paths."""
        from nodes.node2 import sheet_selector_node as _sheet_selector
        import re
        from pathlib import Path as _Path
        from helpers.file_registry import get_file_path_by_name, clear_profile_registry_cache
        from nodes import node2

        result = _sheet_selector(state)
        mapping = result.get("mapping_result") or state.get("mapping_result") or {}
        selected = mapping.get("selected_sources", [])

        # OPTIMIZATION: Don't load profiler registry here anymore
        # It will be lazy-loaded in structure_analyzer_node for ONLY selected files
        # This saves 285-395ms per query by not loading all 12 profiler files
        # Keep minimal registry for fallback file path resolution (if needed)
        registry = state.get("file_registry", {})

        # Apply 80% confidence threshold filtering
        if selected:
            try:
                raw_map = mapping.get("file_and_sheet_mapping", []) or []
                # Build quick lookup {(file_name, tab_name): confidence}
                conf_lookup: dict = {}
                overall_conf = mapping.get("confidence", 0)
                for e in raw_map:
                    fn = (e.get("file_name", "") or "").casefold()
                    tn = (e.get("tab_name", "") or "").casefold()
                    try:
                        conf = int(e.get("confidence", overall_conf) or overall_conf)
                    except Exception:
                        conf = int(overall_conf or 0)
                    conf_lookup[(fn, tn)] = conf

                THRESHOLD = 80
                filtered = []

                for s in selected:
                    f = (s.get("file", "") or "").casefold()
                    t = (s.get("sheet", "") or "").casefold()
                    conf = conf_lookup.get((f, t))

                    # Fallback: try matching by file name AND sheet name
                    if conf is None and f:
                        for (rf, rt), v in conf_lookup.items():
                            if f and (f in rf or rf in f):
                                # Also check if sheet matches
                                if t and (t in rt or rt in t):
                                    conf = v
                                    break

                    if conf is None or conf >= THRESHOLD:
                        filtered.append(s)

                # If filtering removed everything, fall back to original selections
                if filtered:
                    selected = filtered
                    # Update BOTH selected_sources AND file_and_sheet_mapping
                    mapping["selected_sources"] = filtered

                    # Also filter file_and_sheet_mapping to match
                    filtered_file_sheet_mapping = []
                    for entry in raw_map:
                        entry_file = (entry.get("file_name", "") or "").casefold()
                        entry_sheet = (entry.get("tab_name", "") or "").casefold()
                        # Check if this entry matches any filtered source
                        for s in filtered:
                            s_file = (s.get("file", "") or "").casefold()
                            s_sheet = (s.get("sheet", "") or "").casefold()
                            if (entry_file in s_file or s_file in entry_file) and (entry_sheet in s_sheet or s_sheet in entry_sheet):
                                filtered_file_sheet_mapping.append(entry)
                                break

                    if filtered_file_sheet_mapping:
                        mapping["file_and_sheet_mapping"] = filtered_file_sheet_mapping
                        logger.info(f"[CONFIDENCE FILTER] Also filtered file_and_sheet_mapping to {len(filtered_file_sheet_mapping)} entries")

                    result["mapping_result"] = mapping

                    # Also update sheet_selection_confidence for UI display
                    if "sheet_selection_confidence" in result:
                        ssc = result["sheet_selection_confidence"]
                        # Filter the selected_sources in sheet_selection_confidence to match filtered list
                        filtered_ssc_sources = []
                        for src in ssc.get("selected_sources", []):
                            src_file = (src.get("file", "") or "").casefold()
                            src_sheet = (src.get("sheet", "") or "").casefold()
                            # Check if this matches any filtered source
                            for f in filtered:
                                f_file = (f.get("file", "") or "").casefold()
                                f_sheet = (f.get("sheet", "") or "").casefold()
                                if (src_file in f_file or f_file in src_file) and (src_sheet in f_sheet or f_sheet in src_sheet):
                                    filtered_ssc_sources.append(src)
                                    break
                        ssc["selected_sources"] = filtered_ssc_sources
                        result["sheet_selection_confidence"] = ssc
                else:
                    logger.warning("All sources filtered out by confidence threshold, keeping original %d selections", len(selected))

            except Exception as e:
                logger.error("Error during confidence filtering: %s, keeping original selections", e)

            # File path resolution (same logic as langgraph.py node2_entry)
            excel_files = state.get("excel_files", [])
            for s in selected:
                if not s.get("file_path"):
                    file_name = s.get("file", "")
                    file_stem = _Path(file_name).stem
                    want = re.sub(r"[_\-\s]+", " ", file_stem).casefold()

                    best_match = None
                    best_len = -1

                    for ef in excel_files:
                        stem = re.sub(r"[_\-\s]+", " ", _Path(ef).stem).casefold()
                        if not want:
                            continue
                        if want == stem:
                            best_match = ef
                            best_len = len(stem)
                            break
                        if want in stem or stem in want:
                            if len(stem) > best_len:
                                best_match = ef
                                best_len = len(stem)

                    if best_match:
                        s["file_path"] = best_match
                    else:
                        logger.warning("No file path match found for: %s", file_name)

                    # Fallback to registry helper if still not resolved
                    if not s.get("file_path"):
                        try:
                            fp = get_file_path_by_name(registry, s.get("file", ""))
                            if fp:
                                s["file_path"] = fp
                        except Exception:
                            pass

            result["selected_sources"] = selected
            # Also make registry available downstream
            result["file_registry"] = registry

        return result

    # ── Add nodes ──

    # AG-UI adapter nodes
    graph.add_node("parse_messages", parse_messages_node)
    graph.add_node("format_response", format_response_node)

    # Context enrichment node (NEW - runs after parse_messages)
    graph.add_node("context_enrichment", context_enrichment_node)

    # Node2 individual steps (flattened for visibility)
    def normalize_query_wrapper(state):
        """Wrapper to preserve JWT token through normalize_query_node."""
        # Extract JWT token before calling node
        user_jwt_token = state.get("user_jwt_token")
        
        # Call the actual node
        result = normalize_query_node(state)
        
        # Ensure JWT token is preserved in result
        if user_jwt_token and "user_jwt_token" not in result:
            result = dict(result)
            result["user_jwt_token"] = user_jwt_token
        
        return result
    
    async def domain_validation_wrapper(state):
        """Wrapper to preserve JWT token through domain_validation_node."""
        user_jwt_token = state.get("user_jwt_token")
        
        # domain_validation_node is an async generator - consume it
        result = state
        async for value in domain_validation_node(state):
            result = value
        
        # Preserve JWT token
        if user_jwt_token and "user_jwt_token" not in result:
            result = dict(result)
            result["user_jwt_token"] = user_jwt_token
        
        return result
    
    async def mapping_wrapper(state):
        """Wrapper to preserve JWT token through mapping_node."""
        user_jwt_token = state.get("user_jwt_token")
        
        # mapping_node is an async generator - consume it
        result = state
        async for value in mapping_node(state):
            result = value
        
        # Preserve JWT token
        if user_jwt_token and "user_jwt_token" not in result:
            result = dict(result)
            result["user_jwt_token"] = user_jwt_token
        
        return result
    
    graph.add_node("normalize_query", normalize_query_wrapper)
    graph.add_node("domain_validation", domain_validation_wrapper)
    graph.add_node("intent", intent_wrapper)  # Use wrapper
    graph.add_node("mapping", mapping_wrapper)  # Use wrapper for JWT preservation
    graph.add_node("sheet_selector", selector_wrapper)

    # Rest of pipeline nodes
    graph.add_node("structure_analyzer", structure_analyzer_node)
    graph.add_node("query_context_builder", async_query_context_builder_node)  # NEW - ASYNC
    graph.add_node("code_generator", code_generator_node)
    graph.add_node("code_executor", code_executor_node)
    graph.add_node("parallel_executor", async_parallel_executor_node)  # NEW - async parallel path
    graph.add_node("narrative_explainer", narrative_explainer_node)
    graph.add_node("context_storage", context_storage_node)  # NEW - runs after narrative_explainer
    # graph.add_node("confidence_summary", confidence_summary_node)  # REMOVED

    # ── Define edges ──

    # Entry point and initial parse
    graph.set_entry_point("parse_messages")
    graph.add_edge("parse_messages", "context_enrichment")  # NEW: Add context enrichment first
    graph.add_edge("context_enrichment", "normalize_query")  # NEW: Then continue to normalize

    # Node2 flow (flattened) - direct edges
    graph.add_edge("normalize_query", "domain_validation")

    # Route after domain validation (handle greetings/rejections)
    def route_after_domain_validation(state: AGUIExcelState) -> str:
        """Skip to response if greeting or non-financial question."""
        dv = state.get("domain_validation") or {}
        q_type = (dv.get("question_type") or "").lower()

        if q_type == "greeting":
            return "format_response"
        elif q_type != "relevant":
            return "format_response"

        # Relevant question - continue to intent
        return "intent"

    graph.add_conditional_edges(
        "domain_validation",
        route_after_domain_validation,
        {
            "format_response": "format_response",
            "intent": "intent",
        }
    )

    graph.add_edge("intent", "mapping")
    graph.add_edge("mapping", "sheet_selector")

    # After sheet selection, check if we have sources
    def route_after_sheet_selector(state: AGUIExcelState) -> str:
        """Route after sheet selection - check if sources were found."""
        mapping = state.get("mapping_result") or {}
        selected = mapping.get("selected_sources", [])

        # Also check top-level selected_sources (backup)
        if not selected:
            selected = state.get("selected_sources", [])

        if not selected:
            return "format_response"

        return "structure_analyzer"

    graph.add_conditional_edges(
        "sheet_selector",
        route_after_sheet_selector,
        {
            "format_response": "format_response",
            "structure_analyzer": "structure_analyzer",
        }
    )

    # Rest of pipeline - direct edges
    graph.add_edge("structure_analyzer", "query_context_builder")

    # Route after context builder - choose parallel or sequential path
    def route_after_context_builder(state: AGUIExcelState) -> str:
        """Route to parallel executor if multiple independent sources."""
        requires_cross_file = state.get("requires_cross_file", False)
        selected_sources = state.get("selected_sources", [])

        # Use parallel path if:
        # 1. Multiple sources AND
        # 2. No cross-file dependency
        if len(selected_sources) > 1 and not requires_cross_file:
            logger.info(f"[ROUTER] Using parallel execution for {len(selected_sources)} independent sources")
            return "parallel_executor"
        else:
            logger.info(f"[ROUTER] Using sequential execution (cross_file={requires_cross_file}, sources={len(selected_sources)})")
            return "code_generator"

    graph.add_conditional_edges(
        "query_context_builder",
        route_after_context_builder,
        {
            "parallel_executor": "parallel_executor",
            "code_generator": "code_generator",
        }
    )

    # Sequential path
    graph.add_edge("code_generator", "code_executor")

    # Both paths converge at narrative_explainer
    graph.add_edge("code_executor", "narrative_explainer")
    graph.add_edge("parallel_executor", "narrative_explainer")

    graph.add_edge("narrative_explainer", "context_storage")  # NEW: Store to memory after answer
    graph.add_edge("context_storage", "format_response")  # Direct to format_response
    # graph.add_edge("confidence_summary", "format_response")  # REMOVED
    graph.add_edge("format_response", END)

    # ── Compile with MemorySaver (required by ag-ui-langgraph, but HITL disabled) ──
    # Note: MemorySaver is required by the AG-UI wrapper even without HITL
    # It only stores state during the current request, no persistence across requests

    # Compile graph (recursion_limit set in agent config, not here)
    compiled = graph.compile(checkpointer=MemorySaver())

    return compiled


# ═══════════════════════════════════════════════════════════════════════════
# EXPORT
# ═══════════════════════════════════════════════════════════════════════════

# This is what agui_server.py will import
__all__ = ["build_agui_graph", "AGUIExcelState"]
