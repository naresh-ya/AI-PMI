"""AG-UI integration for Excel Agent.

This package contains AG-UI protocol adapters for AWS Bedrock AgentCore deployment.
"""
