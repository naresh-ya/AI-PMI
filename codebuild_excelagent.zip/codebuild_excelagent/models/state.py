"""Pydantic schemas for LLM-structured output and the LangGraph TypedDict state."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional
from typing_extensions import TypedDict

from pydantic import BaseModel, Field


class SheetSelectionResponse(BaseModel):
    """LLM output when choosing the most relevant sheet."""
    selected_sheet: str = Field(..., description="Exact sheet name to use.")
    reasoning: str = Field("", description="Brief explanation of why this sheet was chosen.")


class TableInfo(BaseModel):
    """Description of a single table detected inside a sheet."""
    table_id: int = Field(..., ge=1)
    name: str = Field("", description="Human-readable name derived from headers.")
    header_rows: list[int] = Field(default_factory=lambda: [1])
    data_start_row: int = Field(2, ge=1)
    data_end_row: int = Field(0, ge=0)
    label_columns: list[str] = Field(default_factory=list)
    data_columns: list[str] = Field(default_factory=list)
    description: str = ""


class HierarchyInfo(BaseModel):
    """A vertical / horizontal hierarchy detected in the sheet."""
    type: str = Field("vertical", description="vertical | horizontal | block")
    column: str = ""
    description: str = ""


class StructureAnalysisResponse(BaseModel):
    """LLM output for Phase 2b — full structural understanding of a sheet."""
    tables: list[TableInfo] = Field(default_factory=list)
    hierarchies: list[HierarchyInfo] = Field(default_factory=list)
    notes: str = ""


class MatchedFilter(BaseModel):
    """A single user-term to exact-catalog-value binding."""
    user_term: str = ""
    column: str = ""
    exact_value: str = ""
    column_number: int = Field(0, ge=0)


class MeasureColumn(BaseModel):
    """A numeric column the code should read from the original file."""
    column: str = ""
    column_number: int = Field(0, ge=0)
    description: str = ""


class QueryMatchResponse(BaseModel):
    """LLM output for Phase 3 — mapping user query to catalog values."""
    matched_filters: list[MatchedFilter] = Field(default_factory=list)
    measure_columns: list[MeasureColumn] = Field(default_factory=list)
    target_table: str = ""
    operation: str = ""
    operation_detail: str = ""
    header_rows_to_skip: list[int] = Field(default_factory=lambda: [1])
    reasoning: str = ""


class ExecutionResult(BaseModel):
    """Outcome of a single code-execution attempt."""
    success: bool = False
    output: str = ""
    error: Optional[str] = None
    code: str = ""
    diagnostics: Optional[str] = None
    attempts: int = 0


class FileInfo(TypedDict, total=False):
    """Information about a single Excel file."""
    file_path: str
    file_name: str
    profile: Dict[str, Any]
    structures: Dict[str, Dict[str, Any]]


class PipelineState(TypedDict, total=False):
    """Full pipeline state supporting multiple Excel files."""

    # ── Multi-file inputs ──
    excel_files: List[str]
    query: str
    output_dir: str
    user_jwt_token: Optional[str]  # JWT token for user-specific month tracking
    threadId: Optional[str]  # AG-UI thread ID for memory operations

    # ── Multi-file profiling ──
    file_registry: Dict[str, Any]
    global_summary: str

    # ── Sheet selection (may span multiple files) ──
    selected_sources: List[Dict[str, str]]
    requires_cross_file: bool

    # ── Structure analysis ──
    structures: Dict[str, Dict[str, Any]]

    # ── Query context ──
    query_context: str
    matched_filters: List[Dict[str, Any]]
    measure_columns: List[Dict[str, Any]]
    per_source_contexts: Dict[str, str]  # NEW - pre-built contexts for parallel execution

    # ── Code generation & execution ──
    generated_code: str
    execution_result: Dict[str, Any]
    diagnostics_output: Optional[str]

    # ── Retry / backtracking ──
    retry_count: int
    max_retries: int
    error_history: List[str]

    # ── Selection trail & column usage (backtracking visibility) ──
    selection_trace: List[Dict[str, Any]]   # step-by-step candidate evaluation from node2
    column_usage: Dict[str, Any]            # per-source column breakdown from context builder
    backtrack_log: List[Dict[str, Any]]     # history of backtracking attempts (scores, decisions)

    # ── Results ──
    final_answer: str
    success: bool


# ─── Sheet-selection pipeline TypedDicts ─────────────────────────────────────

class GlossaryMatch(TypedDict):
    matched_term: str
    canonical_term: str
    occurrences: int


class StepTrace(TypedDict):
    step: str
    reason: str
    detail: str


class SheetSelectionState(TypedDict, total=False):
    question: str
    normalized_question: str
    glossary_matches: list[GlossaryMatch]
    domain_validation: dict[str, Any] | None
    analysis_spec: dict[str, Any] | None
    mapping_result: dict[str, Any] | None
    answer: str
    answer_struct: Any
    followup_done: bool
    overflow_attempted: bool  # True after overflow_check_node has run (kept for state compat)
    column_context: str       # column summary + fetched overflow, injected into mapping
    user_clarifications: str  # separate field for user answers to avoid duplication
    step_trace: list[StepTrace]  # audit trail for every node — useful for testing
    user_answer_provider: Callable[[list[str]], list[str]] | None