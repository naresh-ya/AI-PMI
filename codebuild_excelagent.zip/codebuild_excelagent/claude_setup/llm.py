"""LangChain-friendly LiteLLM/Bedrock client wrapper.

This keeps the existing `get_model()` / `get_fast_model()` API used across the
pipeline, but routes requests through the Bedrock-compatible LiteLLM endpoint
configured in `core.settings`.
"""

from __future__ import annotations

import sys
import json
import requests
from threading import Lock
from typing import Any, AsyncIterator, Iterator

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import AIMessage, BaseMessage

from core.settings import settings

# Import and configure LangSmith with Pydantic model rebuild
try:
    from pathlib import Path  # Required for RunTree model
    from langsmith import traceable
    from langsmith.run_trees import RunTree
    # Force Pydantic model rebuild to fix "RunTree not fully defined" error
    RunTree.model_rebuild()
except Exception as e:
    # If LangSmith import fails, create a no-op decorator
    import logging
    logging.getLogger(__name__).warning(f"LangSmith traceable unavailable: {e}")
    def traceable(*args, **kwargs):
        def decorator(func):
            return func
        if args and callable(args[0]):
            return decorator(args[0])
        return decorator


_model = None
_fast_model = None
_lock = Lock()


class CLITokenCallback(BaseCallbackHandler):
    def on_llm_new_token(self, token: str, **kwargs):
        sys.stdout.write(token)
        sys.stdout.flush()


def _stringify_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict):
                if item.get("type") == "text":
                    parts.append(str(item.get("text", "")))
                else:
                    parts.append(str(item))
            else:
                parts.append(str(item))
        return "\n".join(part for part in parts if part)
    return str(content)


def _normalize_prompt(prompt: str | list[BaseMessage] | list[Any]) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """Normalize prompt input into Bedrock `system` and `messages` payloads."""
    if isinstance(prompt, str):
        return [], [{"role": "user", "content": [{"text": prompt}]}]

    if not isinstance(prompt, list):
        raise TypeError(f"Unsupported prompt type: {type(prompt)}")

    system_blocks: list[dict[str, str]] = []
    messages: list[dict[str, Any]] = []

    for msg in prompt:
        role = getattr(msg, "type", None) or getattr(msg, "role", None) or "user"
        text = _stringify_content(getattr(msg, "content", msg))
        if not text.strip():
            continue

        if role == "system":
            system_blocks.append({"text": text})
            continue

        bedrock_role = "assistant" if role in {"ai", "assistant"} else "user"
        messages.append({"role": bedrock_role, "content": [{"text": text}]})

    if not messages:
        messages.append({"role": "user", "content": [{"text": ""}]})

    return system_blocks, messages


@traceable(
    run_type="llm",  # Mark this as an LLM call for LangSmith
    name="litellm_bedrock_call"
)
def _call_bedrock(
    prompt: str | list[BaseMessage] | list[Any],
    *,
    max_tokens: int,
    model_name: str,
) -> str:
    """Invoke the Bedrock-compatible LiteLLM endpoint via HTTP POST with bearer token."""
    import logging
    logger = logging.getLogger(__name__)

    if not settings.bedrock_bearer_token:
        raise RuntimeError(
            "Missing EXCEL_AGENT_BEDROCK_BEARER_TOKEN. "
            "Add it to your environment or .env file."
        )

    system_blocks, messages = _normalize_prompt(prompt)

    # Construct the Bedrock Converse API payload
    payload: dict[str, Any] = {
        "modelId": model_name,
        "messages": messages,
        "inferenceConfig": {
            "maxTokens": max_tokens,
            "temperature": 0,
        },
    }
    if system_blocks:
        payload["system"] = system_blocks

    # Send request to LiteLLM proxy with bearer token
    headers = {
        "Authorization": f"Bearer {settings.bedrock_bearer_token}",
        "Content-Type": "application/json",
    }

    # LiteLLM proxy endpoint for Bedrock Converse API
    # Format: /bedrock/model/{modelId}/converse
    base_url = settings.bedrock_endpoint_url.rstrip("/")
    endpoint = f"{base_url}/model/{model_name}/converse"


    response = requests.post(
        endpoint,
        json=payload,
        headers=headers,
        verify=not settings.bedrock_skip_tls_verify,
        timeout=300,  # Increased from 120s to 300s for complex multi-file queries
    )

    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        # Add more context to HTTP errors
        error_msg = f"LiteLLM request failed: {e}"
        try:
            error_detail = response.json()
            error_msg += f" - Response: {error_detail}"
        except:
            error_msg += f" - Response text: {response.text[:200]}"
        logger.error(f"HTTP {response.status_code} - {error_msg}")
        raise RuntimeError(error_msg) from e

    result = response.json()
    content = result.get("output", {}).get("message", {}).get("content", [])
    texts = [str(block.get("text", "")) for block in content if isinstance(block, dict)]
    return "".join(texts).strip()


def _call_bedrock_stream(
    prompt: str | list[BaseMessage] | list[Any],
    *,
    max_tokens: int,
    model_name: str,
) -> Iterator[str]:
    """Stream tokens from Bedrock-compatible LiteLLM endpoint using AWS Event Stream format.

    Based on LiteLLM streaming documentation:
    https://docs.litellm.ai/docs/completion/streaming

    Yields tokens as they arrive from the model.

    Note: LiteLLM proxy returns AWS Event Stream binary format, not SSE.
    """
    import logging
    import re
    logger = logging.getLogger(__name__)

    if not settings.bedrock_bearer_token:
        raise RuntimeError(
            "Missing EXCEL_AGENT_BEDROCK_BEARER_TOKEN. "
            "Add it to your environment or .env file."
        )

    system_blocks, messages = _normalize_prompt(prompt)

    # Construct the Bedrock Converse API payload
    payload: dict[str, Any] = {
        "modelId": model_name,
        "messages": messages,
        "inferenceConfig": {
            "maxTokens": max_tokens,
            "temperature": 0,
        },
    }
    if system_blocks:
        payload["system"] = system_blocks

    headers = {
        "Authorization": f"Bearer {settings.bedrock_bearer_token}",
        "Content-Type": "application/json",
    }

    # Use converse-stream endpoint for streaming
    base_url = settings.bedrock_endpoint_url.rstrip("/")
    endpoint = f"{base_url}/model/{model_name}/converse-stream"

    # Track repeated chunks for infinite loop detection (LiteLLM feature)
    repeated_chunk_tracker = {}
    REPEATED_STREAMING_CHUNK_LIMIT = 100

    try:
        with requests.post(
            endpoint,
            json=payload,
            headers=headers,
            verify=not settings.bedrock_skip_tls_verify,
            timeout=300,
            stream=True  # Enable streaming
        ) as response:
            response.raise_for_status()

            # Parse AWS Event Stream binary format
            # Each line contains binary data with embedded JSON
            for line in response.iter_lines(decode_unicode=False):
                if not line:
                    continue

                # Convert bytes to string with latin-1 (preserves binary as-is)
                line_str = line.decode('latin-1') if isinstance(line, bytes) else line

                # DEBUG: Log raw line to see format
                if logger.isEnabledFor(logging.DEBUG):
                    logger.debug(f"Raw stream line: {repr(line_str[:200])}")

                # Try to parse as JSON first (more robust)
                try:
                    # Look for JSON objects - try to find the embedded event JSON
                    # AWS Event Stream format may have binary framing, look for JSON content
                    json_start = line_str.find('{')
                    if json_start >= 0:
                        json_str = line_str[json_start:]
                        import json as json_lib
                        event_data = json_lib.loads(json_str)

                        # Extract text from delta if present
                        if 'delta' in event_data and 'text' in event_data['delta']:
                            text = event_data['delta']['text']

                            if text:
                                # Infinite loop detection (LiteLLM safety feature)
                                if text in repeated_chunk_tracker:
                                    repeated_chunk_tracker[text] += 1
                                    if repeated_chunk_tracker[text] > REPEATED_STREAMING_CHUNK_LIMIT:
                                        raise RuntimeError(
                                            f"Model entered infinite loop: chunk '{text[:50]}...' "
                                            f"repeated {repeated_chunk_tracker[text]} times"
                                        )
                                else:
                                    repeated_chunk_tracker[text] = 1

                                yield text
                except (json_lib.JSONDecodeError, ValueError):
                    # Fallback to regex if JSON parsing fails
                    # Pattern: {"contentBlockIndex":N,"delta":{"text":"..."},...}
                    # Use non-greedy match and handle escaped quotes
                    json_pattern = r'\{"contentBlockIndex":\d+,"delta":\{"text":"((?:[^"\\]|\\.)*)"\}'
                    match = re.search(json_pattern, line_str)

                    if match:
                        text = match.group(1)
                        # Unescape JSON escapes
                        text = text.replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\')

                        if text:
                            # Infinite loop detection
                            if text in repeated_chunk_tracker:
                                repeated_chunk_tracker[text] += 1
                                if repeated_chunk_tracker[text] > REPEATED_STREAMING_CHUNK_LIMIT:
                                    raise RuntimeError(
                                        f"Model entered infinite loop: chunk '{text[:50]}...' "
                                        f"repeated {repeated_chunk_tracker[text]} times"
                                    )
                            else:
                                repeated_chunk_tracker[text] = 1

                            yield text

                # Check for messageStop event (end of stream)
                if ':event-type' in line_str and 'messageStop' in line_str:
                    break

    except requests.HTTPError as e:
        error_msg = f"LiteLLM streaming request failed: {e}"
        try:
            error_detail = response.json()
            error_msg += f" - Response: {error_detail}"
        except:
            error_msg += f" - Response text: {response.text[:200]}"
        logger.error(f"HTTP {response.status_code} - {error_msg}")
        raise RuntimeError(error_msg) from e


async def _call_bedrock_async_stream(
    prompt: str | list[BaseMessage] | list[Any],
    *,
    max_tokens: int,
    model_name: str,
) -> AsyncIterator[str]:
    """Async stream tokens from Bedrock-compatible LiteLLM endpoint using AWS Event Stream format.

    Based on LiteLLM async streaming documentation:
    https://docs.litellm.ai/docs/completion/streaming

    Example usage:
        async for token in _call_bedrock_async_stream(...):
            print(token, end='')

    Note: LiteLLM proxy returns AWS Event Stream binary format, not SSE.
    """
    import httpx
    import logging
    import re
    logger = logging.getLogger(__name__)

    if not settings.bedrock_bearer_token:
        raise RuntimeError(
            "Missing EXCEL_AGENT_BEDROCK_BEARER_TOKEN. "
            "Add it to your environment or .env file."
        )

    system_blocks, messages = _normalize_prompt(prompt)

    payload: dict[str, Any] = {
        "modelId": model_name,
        "messages": messages,
        "inferenceConfig": {
            "maxTokens": max_tokens,
            "temperature": 0,
        },
    }
    if system_blocks:
        payload["system"] = system_blocks

    headers = {
        "Authorization": f"Bearer {settings.bedrock_bearer_token}",
        "Content-Type": "application/json",
    }

    base_url = settings.bedrock_endpoint_url.rstrip("/")
    endpoint = f"{base_url}/model/{model_name}/converse-stream"

    # Track repeated chunks for infinite loop detection
    repeated_chunk_tracker = {}
    REPEATED_STREAMING_CHUNK_LIMIT = 100

    try:
        async with httpx.AsyncClient(
            timeout=300.0,
            verify=not settings.bedrock_skip_tls_verify
        ) as client:
            async with client.stream('POST', endpoint, json=payload, headers=headers) as response:
                response.raise_for_status()

                # Parse AWS Event Stream binary format
                # Use aiter_lines() which handles line buffering automatically
                async for line_bytes in response.aiter_lines():
                    if not line_bytes:
                        continue

                    # Convert bytes to string with latin-1 (preserves binary as-is)
                    line_str = line_bytes if isinstance(line_bytes, str) else line_bytes.decode('latin-1')

                    # DEBUG: Log raw line to see format
                    if logger.isEnabledFor(logging.DEBUG):
                        logger.debug(f"Raw async stream line: {repr(line_str[:200])}")

                    # Try to parse as JSON first (more robust)
                    try:
                        # Look for JSON objects - try to find the embedded event JSON
                        json_start = line_str.find('{')
                        if json_start >= 0:
                            json_str = line_str[json_start:]
                            import json as json_lib
                            event_data = json_lib.loads(json_str)

                            # Extract text from delta if present
                            if 'delta' in event_data and 'text' in event_data['delta']:
                                text = event_data['delta']['text']

                                if text:
                                    # Infinite loop detection
                                    if text in repeated_chunk_tracker:
                                        repeated_chunk_tracker[text] += 1
                                        if repeated_chunk_tracker[text] > REPEATED_STREAMING_CHUNK_LIMIT:
                                            raise RuntimeError(
                                                f"Model entered infinite loop: chunk '{text[:50]}...' "
                                                f"repeated {repeated_chunk_tracker[text]} times"
                                            )
                                    else:
                                        repeated_chunk_tracker[text] = 1

                                    yield text
                    except (json_lib.JSONDecodeError, ValueError):
                        # Fallback to regex if JSON parsing fails
                        # Pattern: {"contentBlockIndex":N,"delta":{"text":"..."},...}
                        # Use non-greedy match and handle escaped quotes
                        json_pattern = r'\{"contentBlockIndex":\d+,"delta":\{"text":"((?:[^"\\]|\\.)*)"\}'
                        match = re.search(json_pattern, line_str)

                        if match:
                            text = match.group(1)
                            # Unescape JSON escapes
                            text = text.replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\')

                            if text:
                                # Infinite loop detection
                                if text in repeated_chunk_tracker:
                                    repeated_chunk_tracker[text] += 1
                                    if repeated_chunk_tracker[text] > REPEATED_STREAMING_CHUNK_LIMIT:
                                        raise RuntimeError(
                                            f"Model entered infinite loop: chunk '{text[:50]}...' "
                                            f"repeated {repeated_chunk_tracker[text]} times"
                                        )
                                else:
                                    repeated_chunk_tracker[text] = 1

                                yield text

                    # Check for messageStop event (end of stream)
                    if ':event-type' in line_str and 'messageStop' in line_str:
                        break

    except httpx.HTTPStatusError as e:
        error_msg = f"LiteLLM async streaming request failed: {e}"
        try:
            error_detail = e.response.json()
            error_msg += f" - Response: {error_detail}"
        except:
            error_msg += f" - Response text: {e.response.text[:200]}"
        logger.error(f"HTTP {e.response.status_code} - {error_msg}")
        raise RuntimeError(error_msg) from e


class LLMAdapter:
    """Minimal adapter preserving the existing `.invoke()`-based usage with streaming support."""

    def __init__(self, *, model_name: str, max_tokens: int):
        self.model_name = model_name
        self.max_tokens = max_tokens

    def __call__(self, prompt: str | list[BaseMessage] | list[Any]) -> AIMessage:
        return self.invoke(prompt)

    def invoke(self, prompt: str | list[BaseMessage] | list[Any]) -> AIMessage:
        """Non-streaming invocation (original behavior)."""
        text = _call_bedrock(
            prompt,
            max_tokens=self.max_tokens,
            model_name=self.model_name,
        )
        return AIMessage(content=text)

    def stream(self, prompt: str | list[BaseMessage] | list[Any]) -> Iterator[str]:
        """Stream tokens synchronously.

        Example:
            model = get_model()
            for token in model.stream(messages):
                print(token, end='', flush=True)
        """
        return _call_bedrock_stream(
            prompt,
            max_tokens=self.max_tokens,
            model_name=self.model_name,
        )

    async def astream(self, prompt: str | list[BaseMessage] | list[Any]) -> AsyncIterator[str]:
        """Stream tokens asynchronously.

        Example:
            model = get_model()
            async for token in model.astream(messages):
                print(token, end='', flush=True)
        """
        async for token in _call_bedrock_async_stream(
            prompt,
            max_tokens=self.max_tokens,
            model_name=self.model_name,
        ):
            yield token


def get_model() -> LLMAdapter:
    """Return the shared LLM instance (higher accuracy)."""
    global _model
    if _model is None:
        with _lock:
            if _model is None:
                _model = LLMAdapter(
                    model_name=settings.llm_model,
                    max_tokens=settings.llm_max_tokens,
                )
    return _model


def get_fast_model() -> LLMAdapter:
    """Return a faster LLM instance for lightweight tasks."""
    global _fast_model
    if _fast_model is None:
        with _lock:
            if _fast_model is None:
                _fast_model = LLMAdapter(
                    model_name=getattr(settings, "llm_fast_model", settings.llm_model),
                    max_tokens=6000,
                )
    return _fast_model


get_llm = get_model
