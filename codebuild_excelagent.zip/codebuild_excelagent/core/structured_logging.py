"""Structured, console logger for every pipeline phase."""

from __future__ import annotations
import logging
import sys

# time , level(error, warnings) , logger name (error name), message (our message)
_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(name)-28s | %(message)s"
)

def get_logger(name: str) -> logging.Logger:
    """Return a consistently-formatted logger for *name*."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(_FORMAT, datefmt="%H:%M:%S"))
        logger.addHandler(handler)
        logger.setLevel(logging.WARNING)  # Changed from DEBUG to WARNING for production performance
    return logger