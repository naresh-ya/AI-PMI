"""Application-wide configuration backed by environment variables.

IMPORTANT:
- All S3 paths are STRINGS (never pathlib.Path)
- Legacy module-level exports are preserved for CLI tools
- Pydantic settings remain strict and frozen
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

import requests
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

_logger = logging.getLogger(__name__)

# Load .env if present (local / dev use)
load_dotenv()

# core/
SETTINGS_DIR = Path(__file__).resolve().parent

# project root (repo root)
BASE_DIR = SETTINGS_DIR.parent

# legacy alias (used by older scripts)
PROJECT_ROOT = BASE_DIR

# S3 paths - NO LONGER HARDCODED
# All paths must come from user-specific month API (requires JWT token)
# Use get_s3_paths(user_jwt_token) to fetch paths dynamically

GLOSSARY_PATH = "s3://mbr-data-lake/metadata/static/Glossary_PMI.csv"
ENHANCED_CSV_PATH = "s3://mbr-data-lake/metadata/static/raw_intents_enhanced_v2.csv"
MBR_MAPPING_PATH = None  # Not used - kept for backward compatibility
DEFAULT_OUTPUT_PATH = "s3://mbr-data-lake/analysis-output/"

# Dynamic paths - REMOVED: All paths must come from get_s3_paths(user_jwt_token)
# No static/hardcoded paths allowed - user-specific month API required
PROFILE_DIR = None  # DEPRECATED - Use get_s3_paths(user_jwt_token)['PROFILE_DIR']
S3_DATA_PATH = None  # DEPRECATED - Use get_s3_paths(user_jwt_token)['S3_DATA_PATH']


def get_s3_paths(user_jwt_token: str = None):
    """
    Fetch S3 paths using user-specific month tracking.
    
    REQUIRES JWT TOKEN - No fallback to old API.
    
    Args:
        user_jwt_token: REQUIRED JWT token for user-specific month

    Returns a dict with all S3 paths:
    - PROFILE_DIR: metadata/dynamic path
    - S3_DATA_PATH: raw_data path
    - GLOSSARY_PATH: static glossary file
    - ENHANCED_CSV_PATH: static enhanced CSV file
    - DEFAULT_OUTPUT_PATH: analysis output path

    Raises:
        Exception: If JWT token is missing or API call fails

    Example:
        from core.user_month_settings import get_user_specific_s3_paths
        paths = get_s3_paths(state['user_jwt_token'])
    """
    # REQUIRE JWT token - no fallback
    if not user_jwt_token:
        raise Exception(
            "JWT token is required for user-specific month tracking. "
            "No JWT token found in state['user_jwt_token']. "
            "Make sure the frontend is passing the JWT token in the Authorization header."
        )
    
    # Use new user-specific API
    try:
        from core.user_month_settings import get_user_specific_s3_paths
        return get_user_specific_s3_paths(user_jwt_token)
    except Exception as e:
        _logger.error(f"Error fetching user-specific S3 paths: {e}")
        raise Exception(
            f"Failed to fetch user-specific month data: {str(e)}. "
            "Please ensure you are logged in and have selected a month."
        )


def get_current_month(user_jwt_token: str = None) -> dict:
    """
    Fetch current reporting month from user-specific API.
    
    Args:
        user_jwt_token: JWT token for user-specific month (REQUIRED)

    Returns:
        dict: {
            'month': 'December',
            'year': '2025',
            'period': 'December 2025'
        }

    Raises:
        Exception: If JWT token is missing or API call fails
    """
    if not user_jwt_token:
        raise Exception(
            "JWT token is required for get_current_month(). "
            "No JWT token found in state['user_jwt_token']."
        )
    
    try:
        from core.user_month_settings import get_user_current_month
        return get_user_current_month(user_jwt_token)
    except Exception as e:
        _logger.error("Error fetching current month from user-specific API: %s", e)
        raise Exception(f"Failed to fetch current month: {str(e)}")



def load_formula_file_from_s3(s3_uri: str) -> dict:
    """
    Load a single formula JSON file from S3.

    Args:
        s3_uri: Full S3 URI (s3://bucket/key)

    Returns:
        Parsed JSON dict
    """
    import boto3
    import json

    # Parse S3 URI
    s3_path_parts = s3_uri.replace("s3://", "").split("/", 1)
    bucket = s3_path_parts[0]
    key = s3_path_parts[1]

    # Read from S3
    s3_client = boto3.client('s3')
    response = s3_client.get_object(Bucket=bucket, Key=key)
    return json.loads(response['Body'].read().decode('utf-8'))


def _normalize_filename(filename: str) -> str:
    """
    Normalize filename for fuzzy matching: lowercase, remove extensions and special chars.

    Examples:
        "PMI India Industry Segmentation.xlsx" → "pmi india industry segmentation"
        "industry_segmentation.json" → "industry segmentation"
        "PMI vs Competition Mapping_Jun26.xlsx" → "pmi vs competition mapping jun26"
    """
    import re
    # Remove file extension
    filename = re.sub(r'\.(xlsx?|csv|json)$', '', filename, flags=re.IGNORECASE)
    # Convert to lowercase
    filename = filename.lower()
    # Replace underscores with spaces
    filename = filename.replace('_', ' ')
    # Remove special characters, keep alphanumeric and spaces
    filename = re.sub(r'[^a-z0-9\s]', ' ', filename)
    # Normalize whitespace
    filename = ' '.join(filename.split())
    return filename


def get_formula_files_for_sources(selected_sources: list, available_files: list) -> list:
    """
    Determine which formula files to load based on selected sources.
    Uses fuzzy matching on FILENAMES (no file loading needed!).

    FIXED: Removed common_rules.json dependency - all formulas are optional.

    Edge cases handled:
    1. No selected_sources → returns EMPTY list (no formulas needed)
    2. Source file has no formula match → skip gracefully
    3. Multiple sources → returns all matched files

    Args:
        selected_sources: List of {file, sheet, ...} dicts from selector node
        available_files: List from BUSINESS_FORMULAS_FILES API response

    Returns:
        List of formula file dicts with s3_uri to load
    """
    from difflib import SequenceMatcher

    # Edge case 1: No selected sources → return EMPTY (no formulas needed)
    if not selected_sources:
        return []

    needed_files = set()
    matched_count = 0

    # Extract formula file patterns from filenames
    formula_patterns = {}
    for f in available_files:
        filename = f["filename"]
        # Extract pattern: "industry_segmentation.json" → "industry segmentation"
        pattern = _normalize_filename(filename)
        formula_patterns[filename] = pattern

    # Match each selected source to formula files
    for src in selected_sources:
        src_file = src.get("file", "")
        src_sheet = src.get("sheet", "")

        if not src_file:
            _logger.warning("Source has no file name, skipping")
            continue

        src_file_normalized = _normalize_filename(src_file)

        best_match = None
        best_score = 0

        for formula_filename, formula_pattern in formula_patterns.items():
            # Try substring match first (faster)
            if formula_pattern in src_file_normalized:
                score = 1.0
            else:
                # Fallback to fuzzy match
                score = SequenceMatcher(None, formula_pattern, src_file_normalized).ratio()

            if score > best_score:
                best_score = score
                best_match = formula_filename

        # Accept match if score >= 0.6 (60% similarity)
        if best_match and best_score >= 0.6:
            needed_files.add(best_match)
            matched_count += 1

    # Find matching files from API response
    result = []
    available_filenames = {f["filename"]: f for f in available_files}

    for filename in needed_files:
        if filename in available_filenames:
            result.append(available_filenames[filename])
        else:
            _logger.warning(f"Formula file '{filename}' not found in API response")

    return result

HIGH_CARDINALITY_THRESHOLD = 300
OVERFLOW_VALUES_PER_CHUNK = 200
OVERFLOW_BUDGET_CHARS = 50_000
TOKEN_BUDGET_CHARS = 200_000                

CATALOG_COL_MAP = {
    "source_key": "Source Key",
    "file_name": "File Name",
    "sheet_name": "Sheet Name",
    "column_name": "Column Name",
    "data_type": "Data Type",
    "description": "Description",
}


class Settings(BaseSettings):
    # Claude / Bedrock / LiteLLM
    llm_model: str = "bedrock/us.anthropic.claude-sonnet-4-20250514-v1:0"
    llm_fast_model: str | None = None
    aws_region: str = "us-east-1"

    # Default provided to avoid startup crashes
    bedrock_endpoint_url: str = "https://litellm.aiplat-dev.aws.private-pmideep.biz/bedrock"

    bedrock_bearer_token: str | None = None
    bedrock_skip_tls_verify: bool = True
    llm_max_tokens: int = 16384  # Max output tokens for Claude Sonnet 4 (increased from 12288)  

    # Runtime knobs retained for the rest of the pipeline
    llm_base_url: str | None = None
    llm_api_key: str | None = None
    max_code_retries: int = 2
    max_transition_rows_in_prompt: int = 100
    value_catalog_max_chars: int = 500_000
    high_cardinality_threshold: int = 200
    max_code_lines: int = 50
    sample_row_count: int = 5
    code_execution_timeout: int = 240  # 4 minutes for complex multi-file analysis

    # Parallel execution and HTTP connection pool settings
    # These control how many sources can be processed concurrently and HTTP connection limits
    max_parallel_sources: int = 20  # Maximum number of sources to process in parallel (realistic limit for LLM throughput)
    http_max_connections: int = 100  # Maximum total HTTP connections in pool (allows burst traffic)
    http_max_keepalive: int = 50  # Maximum persistent keepalive connections (50% of max for SSL reuse efficiency)

    # Default S3 locations
    s3_bucket: str | None = "mbr-data-lake"
    s3_raw_prefix: str = ""  # DEPRECATED - Use get_s3_paths()['S3_DATA_PATH']
    s3_output_prefix: str = "analysis-output/"
    default_output_dir: str = ""  # DEPRECATED - Use get_s3_paths()['PROFILE_DIR']
    runtime_staging_dir: str = ""  # DEPRECATED - Use get_s3_paths()['PROFILE_DIR']

    # LangGraph checkpoint persistence
    checkpoint_backend: str = "auto"
    checkpoint_require_durable: bool = False
    checkpoint_postgres_dsn: str | None = None
    checkpoint_postgres_min_pool_size: int = 1
    checkpoint_postgres_max_pool_size: int = 5
    checkpoint_postgres_timeout_seconds: int = 30

    model_config = {
        "env_prefix": "EXCEL_AGENT_",
        "frozen": True,
    }

    def model_post_init(self, __context) -> None:
        """Propagate LiteLLM Bedrock token to boto3-compatible env var."""
        if self.bedrock_bearer_token:
            os.environ["AWS_BEARER_TOKEN_BEDROCK"] = self.bedrock_bearer_token


settings = Settings()
