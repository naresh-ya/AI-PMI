"""
User-Specific Month Tracking Integration

This module provides functions to fetch S3 paths based on individual user's
selected month from DynamoDB, enabling user-isolated month preferences.

Usage in graph nodes:
    from core.user_month_settings import get_user_specific_s3_paths
    
    def my_node(state):
        user_token = state.get('user_jwt_token')
        if user_token:
            paths = get_user_specific_s3_paths(user_token)
        else:
            paths = get_s3_paths()  # Fallback to system default
"""

import logging
import requests
from typing import Dict, Any, Optional

_logger = logging.getLogger(__name__)

# User-specific month API endpoints
USER_MONTH_API_URL = "https://zaev3lnhzc.execute-api.eu-west-1.amazonaws.com/user-month-preference"
USER_MONTH_AVAILABLE_URL = "https://zaev3lnhzc.execute-api.eu-west-1.amazonaws.com/user-month-preference/available"

# Static paths (never change based on month)
GLOSSARY_PATH = "s3://mbr-data-lake/metadata/static/Glossary_PMI.csv"
ENHANCED_CSV_PATH = "s3://mbr-data-lake/metadata/static/raw_intents_enhanced_v2.csv"
DEFAULT_OUTPUT_PATH = "s3://mbr-data-lake/analysis-output/"


def get_user_specific_s3_paths(user_jwt_token: str) -> Dict[str, Any]:
    """
    Fetch S3 paths based on user's selected month from DynamoDB.
    
    Each user has their own month preference stored in DynamoDB.
    This function queries the user-month-preference API with the user's JWT token
    to get paths for their selected month.
    
    Args:
        user_jwt_token: Cognito JWT token (id_token) from frontend
        
    Returns:
        dict: {
            'PROFILE_DIR': 's3://mbr-data-lake/metadata/dynamic/India/2026/May/',
            'S3_DATA_PATH': 's3://mbr-data-lake/raw_data/India/2026/May/',
            'GLOSSARY_PATH': 's3://mbr-data-lake/metadata/static/Glossary_PMI.csv',
            'ENHANCED_CSV_PATH': 's3://mbr-data-lake/metadata/static/raw_intents_enhanced_v2.csv',
            'DEFAULT_OUTPUT_PATH': 's3://mbr-data-lake/analysis-output/',
            'BUSINESS_FORMULAS_BASE_PATH': 's3://mbr-data-lake/metadata/static/businessFormulae/',
            'BUSINESS_FORMULAS_FILES': [...],  # List of available formula files
            'BUSINESS_FORMULAS_VALIDATION': {...}  # Validation metadata
        }
        
    Raises:
        Exception: If API call fails or returns invalid data
        
    Example:
        >>> user_token = state.get('user_jwt_token')
        >>> paths = get_user_specific_s3_paths(user_token)
        >>> df = pd.read_excel(paths['S3_DATA_PATH'] + 'file.xlsx')
        
        # User A (selected May 2026):
        # paths['S3_DATA_PATH'] = 's3://mbr-data-lake/raw_data/India/2026/May/'
        
        # User B (selected December 2025):
        # paths['S3_DATA_PATH'] = 's3://mbr-data-lake/raw_data/India/2025/December/'
    """
    if not user_jwt_token:
        raise Exception("Cannot load month preference. Please try again later.")
    
    try:
        headers = {
            'Authorization': f'Bearer {user_jwt_token}',
            'Content-Type': 'application/json'
        }
        
        _logger.info("Fetching user-specific S3 paths from API")
        
        response = requests.get(
            USER_MONTH_API_URL,
            headers=headers,
            timeout=15
        )
        
        response.raise_for_status()
        data = response.json()
        
        if data.get('status') != 'success':
            error_msg = data.get('message', 'Unknown error')
            _logger.error(f"User month API returned error: {error_msg}")
            raise Exception("Cannot load month preference. Please try again later.")
        
        # Extract paths from response
        paths = data.get('data', {}).get('paths', {})
        
        if not paths:
            _logger.error("User month API returned no paths")
            raise Exception("Cannot load month preference. Please try again later.")
        
        # Log which month/year was loaded for this user
        config = data.get('data', {}).get('config', {})
        period = config.get('period', 'Unknown')
        source = data.get('source', 'unknown')
        
        _logger.info(
            f"✅ Loaded user-specific paths for period: {period} "
            f"(source: {source})"
        )
        
        # Validate required paths exist
        required_keys = ['PROFILE_DIR', 'S3_DATA_PATH']
        missing_keys = [k for k in required_keys if k not in paths]
        
        if missing_keys:
            _logger.error(f"Missing required path keys: {missing_keys}")
            raise Exception("Cannot load month preference. Please try again later.")
        
        return paths
        
    except requests.exceptions.Timeout:
        _logger.error("Timeout fetching user-specific paths (>15s)")
        raise Exception("Cannot change the month. Please try again later.")
        
    except requests.exceptions.HTTPError as e:
        status_code = e.response.status_code
        
        if status_code == 401:
            _logger.error("Unauthorized: Invalid or expired JWT token")
            raise Exception("Cannot change the month. Please try again later.")
        elif status_code == 404:
            _logger.error("User month preference API endpoint not found")
            raise Exception("Cannot change the month. Please try again later.")
        else:
            _logger.error(f"HTTP {status_code} error from user month API")
            raise Exception("Cannot change the month. Please try again later.")
            
    except requests.exceptions.RequestException as e:
        _logger.error(f"Network error fetching user-specific paths: {e}")
        raise Exception("Cannot change the month. Please try again later.")
        
    except Exception as e:
        # If it's already our custom error message, re-raise it
        if "Cannot" in str(e):
            raise
        # Otherwise, wrap it
        _logger.error(f"Unexpected error in get_user_specific_s3_paths: {e}")
        raise Exception("Cannot change the month. Please try again later.")


def get_user_current_month(user_jwt_token: str) -> Optional[Dict[str, str]]:
    """
    Get the month configuration for a specific user.
    
    Args:
        user_jwt_token: Cognito JWT token
        
    Returns:
        dict: {
            'month': 'May',
            'year': '2026',
            'period': 'May 2026',
            'source': 'user_preference' or 'system_default'
        }
        
        Returns None if API call fails.
        
    Example:
        >>> month_info = get_user_current_month(user_token)
        >>> print(f"User is viewing: {month_info['period']}")
        User is viewing: May 2026
    """
    if not user_jwt_token:
        _logger.warning("No JWT token provided to get_user_current_month")
        return None
    
    try:
        headers = {
            'Authorization': f'Bearer {user_jwt_token}',
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            USER_MONTH_API_URL,
            headers=headers,
            timeout=10
        )
        
        response.raise_for_status()
        data = response.json()
        
        if data.get('status') == 'success':
            config = data.get('data', {}).get('config', {})
            return {
                'month': config.get('month'),
                'year': config.get('year'),
                'period': config.get('period'),
                'source': data.get('source')
            }
        else:
            _logger.error(f"User month API error: {data.get('message')}")
            return None
            
    except Exception as e:
        _logger.error(f"Error fetching user current month: {e}")
        return None


def get_available_months_for_user(user_jwt_token: str) -> Dict[str, Any]:
    """
    Get all available months for user to select from.
    
    Args:
        user_jwt_token: Cognito JWT token
        
    Returns:
        dict: {
            'current': {
                'year': '2026',
                'month': 'May',
                'period': 'May 2026'
            },
            'all_months': [
                {
                    'year': '2026',
                    'month': 'May',
                    'period': 'May 2026',
                    'paths': {...},
                    'has_raw_data': True,
                    'has_metadata': True
                },
                ...
            ]
        }
        
        Returns empty dict if API call fails.
    """
    if not user_jwt_token:
        _logger.warning("No JWT token provided to get_available_months_for_user")
        return {}
    
    try:
        headers = {
            'Authorization': f'Bearer {user_jwt_token}',
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            USER_MONTH_AVAILABLE_URL,
            headers=headers,
            timeout=10
        )
        
        response.raise_for_status()
        data = response.json()
        
        if data.get('status') == 'success':
            return data.get('data', {})
        else:
            _logger.error(f"Available months API error: {data.get('message')}")
            return {}
            
    except Exception as e:
        _logger.error(f"Error fetching available months: {e}")
        return {}


def is_user_month_tracking_enabled(state: Dict[str, Any]) -> bool:
    """
    Check if user-specific month tracking is enabled for this request.
    
    Args:
        state: LangGraph state dict
        
    Returns:
        bool: True if user_jwt_token exists in state, False otherwise
        
    Example:
        >>> if is_user_month_tracking_enabled(state):
        >>>     paths = get_user_specific_s3_paths(state['user_jwt_token'])
        >>> else:
        >>>     paths = get_s3_paths()  # Fallback to system default
    """
    user_token = state.get('user_jwt_token')
    return bool(user_token and isinstance(user_token, str) and len(user_token) > 0)


# For backward compatibility with existing code - REMOVED FALLBACK
# Use get_user_specific_s3_paths() directly in nodes
# If JWT token is missing, the function will raise an error
