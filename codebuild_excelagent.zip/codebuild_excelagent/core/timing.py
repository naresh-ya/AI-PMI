"""Lightweight timing utilities for performance profiling."""

from __future__ import annotations

import time
import logging
from contextlib import contextmanager

_log = logging.getLogger("TIMING")
if not _log.handlers:
    import sys
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s | TIMING   | %(message)s", datefmt="%H:%M:%S"
    ))
    _log.addHandler(handler)
    _log.setLevel(logging.INFO)

# Cumulative timing store
_timings: dict[str, float] = {}
_pipeline_start: float | None = None


def start_pipeline():
    """Mark the pipeline start time."""
    global _pipeline_start
    _pipeline_start = time.perf_counter()


def pipeline_elapsed() -> float:
    """Seconds since pipeline start."""
    if _pipeline_start is None:
        return 0.0
    return time.perf_counter() - _pipeline_start


@contextmanager
def timed(label: str):
    """Context manager that logs the wall-clock duration of a block."""
    t0 = time.perf_counter()
    _log.info("START  %-50s (pipeline %.1fs)", label, pipeline_elapsed())
    try:
        yield
    finally:
        elapsed = time.perf_counter() - t0
        _timings[label] = _timings.get(label, 0.0) + elapsed
        _log.info("END    %-50s  %.2fs  (pipeline %.1fs)", label, elapsed, pipeline_elapsed())


def print_summary():
    """Print a sorted summary of all recorded timings."""
    total = pipeline_elapsed()
    _log.info("=" * 70)
    _log.info("TIMING SUMMARY  (total pipeline: %.2fs)", total)
    _log.info("=" * 70)
    for label, secs in sorted(_timings.items(), key=lambda x: -x[1]):
        pct = (secs / total * 100) if total > 0 else 0
        _log.info("  %6.2fs  %5.1f%%  %s", secs, pct, label)
    _log.info("=" * 70)
