"""FastAPI AG-UI server following AWS sample pattern.
                                                              
Combines:
- AWS sample structure (EventEncoder + manual endpoint)
- Our LangGraph agent (LangGraphAgent wrapper from ag-ui-langgraph)

This uses the EXACT pattern from AWS samples but with our Excel agent.
"""

import asyncio
import sys
import logging
import time
from typing import Any, Dict, List

from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse

from ag_ui_langgraph import LangGraphAgent
from ag_ui.core import MessagesSnapshotEvent, RunAgentInput, RunErrorEvent, StateSnapshotEvent
from ag_ui.encoder import EventEncoder

from agui.graph_wrapper import build_agui_graph, close_checkpointer
from core.settings import settings

# Logging - INFO level to see node progress (WARNING for production)
logging.basicConfig(
    level=logging.INFO,  # Changed from WARNING to INFO to see node logs
    format='%(asctime)s [%(levelname)s] %(name)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ],
    force=True
)
logger = logging.getLogger(__name__)
sys.stdout.reconfigure(line_buffering=True)
sys.stderr.reconfigure(line_buffering=True)

# FastAPI app
app = FastAPI(
    title="Excel Agent AG-UI",
    description="LangGraph agent with AG-UI protocol (AWS pattern)",
    version="1.0.0"
)

# Lazy load graph (not agent - agents can't be reused)
_agui_graph = None                                                                                                 
_graph_lock = asyncio.Lock()

SNAPSHOT_OUTPUT_KEYS = [
    "query",
    "question",
    "normalized_question",
    "glossary_matches",
    "selected_sources",
    "confidence",
    "sheet_selection_confidence",
    "sheet_selection_warning",
    "context_builder_confidence",
    "final_answer",
    "code_error",
    # Node2 intermediate results
    "domain_validation",
    "analysis_spec",
    "intent_result",
    "mapping_result",
    # Context enrichment fields
    "memory_session_id",
    "original_query",
    "enriched_query",
    "previous_qa",
    "context_enrichment_applied",
    "context_enrichment_status",  # NEW - human readable status
    "relatedness_check",  # NEW - LLM check result
    # Query context builder fields (NEW - expose LLM matching results)
    "matched_filters",
    "measure_columns",
    "column_usage",
    "query_context",  # Full context string for debugging
    "context_builder_summary",  # NEW - human readable summary
]


def _model_to_dict(value: Any) -> Any:
    """Convert SDK/Pydantic objects to plain Python data when needed."""
    if hasattr(value, "model_dump"):
        return value.model_dump(by_alias=True)
    return value


def _get_event_type(event: Any) -> str:
    """Extract a normalized string event type from SDK events or dicts."""
    if isinstance(event, dict):
        event_type = event.get("type")
    else:
        event_type = getattr(event, "type", None)

    if hasattr(event_type, "value"):
        return str(event_type.value)
    return str(event_type or "")


def _sanitize_snapshot(snapshot: Any) -> Dict[str, Any]:
    """Keep only the lightweight state fields the clients actually use."""
    snapshot_dict = _model_to_dict(snapshot)
    if not isinstance(snapshot_dict, dict):
        return {}

    sanitized: Dict[str, Any] = {}
    for key in SNAPSHOT_OUTPUT_KEYS:
        if key in snapshot_dict and snapshot_dict[key] is not None:
            sanitized[key] = snapshot_dict[key]
    return sanitized


def _sanitize_messages(messages: Any) -> List[Dict[str, Any]]:
    """Reduce message snapshots to compact role/content records."""
    messages_list = _model_to_dict(messages)
    if not isinstance(messages_list, list):
        return []

    sanitized: List[Dict[str, Any]] = []
    for message in messages_list[-6:]:
        message_dict = _model_to_dict(message)
        if not isinstance(message_dict, dict):
            continue

        role = message_dict.get("role")
        content = message_dict.get("content")
        if not isinstance(role, str) or not isinstance(content, str):
            continue

        compact_message: Dict[str, Any] = {
            "role": role,
            "content": content,
        }
        if isinstance(message_dict.get("id"), str):
            compact_message["id"] = message_dict["id"]
        if isinstance(message_dict.get("name"), str):
            compact_message["name"] = message_dict["name"]

        sanitized.append(compact_message)

    return sanitized


def _filter_stream_event(event: Any) -> Any | None:
    """Drop oversized raw events and shrink snapshot payloads before encoding."""
    event_type = _get_event_type(event)

    if event_type == "RAW":
        return None

    event_dict = _model_to_dict(event)
    if not isinstance(event_dict, dict):
        return event

    if event_type == "STATE_SNAPSHOT":
        return StateSnapshotEvent(
            type="STATE_SNAPSHOT",
            timestamp=event_dict.get("timestamp"),
            snapshot=_sanitize_snapshot(event_dict.get("snapshot")),
        )

    if event_type == "MESSAGES_SNAPSHOT":
        return MessagesSnapshotEvent(
            type="MESSAGES_SNAPSHOT",
            timestamp=event_dict.get("timestamp"),
            messages=_sanitize_messages(event_dict.get("messages")),
        )

    return event

async def get_graph():
    """Lazy-load graph to speed up container startup."""
    global _agui_graph
    if _agui_graph is not None:
        return _agui_graph

    async with _graph_lock:
        if _agui_graph is not None:
            return _agui_graph

        _agui_graph = await build_agui_graph()
        return _agui_graph


async def create_agent():
    """Create a fresh agent instance for each request.

    IMPORTANT: LangGraphAgent instances cannot be reused across requests
    due to internal state management. Each request must get a new agent.
    """
    graph = await get_graph()

    # Configure exposed output keys for STATE_SNAPSHOT events
    agent_config = {
        "configurable": {
            "recursion_limit": 50,  # Increased from default 25 to handle flattened graph
            "schema_keys": {
                "output": SNAPSHOT_OUTPUT_KEYS
            }
        }
    }

    agent = LangGraphAgent(
        name="excel_agent",
        graph=graph,
        description=(
            "Excel data analysis agent for PMI business intelligence. "
            "Analyzes Excel files from S3, generates Python code for data extraction, "
            "and provides business-friendly narrative answers. "
            "Includes confidence tracking at each pipeline stage."
        ),
        config=agent_config,
    )
    return agent


@app.on_event("startup")
async def startup_event():
    """Fail fast in production if durable checkpointing is misconfigured."""
    backend = (settings.checkpoint_backend or "auto").strip().lower()
    should_validate = settings.checkpoint_require_durable or backend == "postgres"
    if should_validate:
        await get_graph()  # Pre-load graph for faster first request


@app.on_event("shutdown")
async def shutdown_event():
    """Close async checkpoint resources on shutdown."""
    await close_checkpointer()


@app.get("/ping")
async def ping():
    """Health check - AWS AgentCore pattern."""
    return JSONResponse({
        "status": "Healthy",
        "time_of_last_update": int(time.time())
    })


@app.post("/invocations")
async def invocations(input_data: dict, request: Request):
    """Main AG-UI endpoint - AWS sample pattern.

    This follows the EXACT pattern from AWS agentcore-samples:
    - Uses EventEncoder for proper SSE formatting
    - Streams events from agent.run() async iterator
    - No manual event construction
    """
    try:
        agent = await create_agent()  # Fresh agent for each request
        accept_header = request.headers.get("accept")
        encoder = EventEncoder(accept=accept_header)
        
        # Extract JWT token for user-specific month tracking
        # When running locally: JWT is in Authorization header
        # When running in AgentCore: JWT is in custom header (Authorization is used by SigV4)
        auth_header = request.headers.get("authorization", "")
        custom_jwt_header = request.headers.get("x-amzn-bedrock-agentcore-runtime-custom-jwt", "")
        user_jwt_token = None
        
        if custom_jwt_header:
            # AgentCore deployment - JWT in custom header
            user_jwt_token = custom_jwt_header
            logger.info(f"✅ Received user JWT token from custom header (length: {len(user_jwt_token)})")
        elif auth_header.startswith("Bearer "):
            # Local development - JWT in Authorization header
            user_jwt_token = auth_header[7:]  # Remove "Bearer " prefix
            logger.info(f"✅ Received user JWT token from Authorization header (length: {len(user_jwt_token)})")
        else:
            logger.warning("⚠️ No JWT token in Authorization or custom header - using system default month")

        async def event_generator():
            """Generate SSE events - AWS pattern."""
            try:
                # Parse AG-UI input
                run_input = RunAgentInput(**input_data)

                # IMPORTANT: Inject threadId into state so it's available in graph nodes
                # AG-UI keeps threadId separate from state, but we need it for memory operations
                if run_input.state is None:
                    run_input.state = {}
                if isinstance(run_input.state, dict):
                    run_input.state["threadId"] = run_input.thread_id
                    
                    # Inject user JWT token for user-specific month tracking
                    if user_jwt_token:
                        run_input.state["user_jwt_token"] = user_jwt_token
                        logger.info("✅ Injected user JWT token into agent state")
                    else:
                        logger.warning("⚠️ No JWT token - agent will use system default month")
                else:
                    logger.warning("State is not a dict (type=%s), cannot inject threadId", type(run_input.state))

                # Stream events from agent
                async for event in agent.run(run_input):
                    filtered_event = _filter_stream_event(event)
                    if filtered_event is None:
                        continue
                    yield encoder.encode(filtered_event)

            except Exception as e:
                logger.error(f"[ERROR] {e}", exc_info=True)
                error_event = RunErrorEvent(
                    type="RUN_ERROR",
                    code="AGENT_ERROR",
                    message=str(e)
                )
                yield encoder.encode(error_event)

        # Return StreamingResponse (AWS pattern)
        return StreamingResponse(
            event_generator(),
            media_type=encoder.get_content_type(),
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            }
        )

    except Exception as e:
        logger.error(f"[ERROR] Endpoint failed: {e}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": str(e)}
        )


@app.get("/test-jwt")
async def test_jwt(request: Request):
    """Test endpoint to verify JWT extraction and user month API integration.
    
    Usage:
        curl -H "Authorization: Bearer YOUR_JWT_TOKEN" http://localhost:8080/test-jwt
    """
    auth_header = request.headers.get("authorization", "")
    
    if not auth_header.startswith("Bearer "):
        return JSONResponse({
            "jwt_received": False,
            "error": "No Authorization header or invalid format",
            "expected_format": "Authorization: Bearer <token>"
        })
    
    token = auth_header[7:]  # Remove "Bearer " prefix
    
    # Try to get user-specific month info
    try:
        from core.user_month_settings import get_user_current_month
        month_info = get_user_current_month(token)
        
        return JSONResponse({
            "jwt_received": True,
            "token_length": len(token),
            "token_valid": True,
            "user_month_info": month_info,
            "message": "✅ JWT token extraction working correctly"
        })
        
    except Exception as e:
        return JSONResponse({
            "jwt_received": True,
            "token_length": len(token),
            "token_valid": False,
            "error": str(e),
            "message": "❌ JWT token received but failed to fetch user month"
        }, status_code=500)


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "Excel Agent AG-UI (AWS Pattern)",
        "version": "1.0.0",
        "status": "ready"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
