#!/bin/bash
export AWS_ACCESS_KEY_ID="ASIA6LTMKTKOVJQBRCPJ"
export AWS_SECRET_ACCESS_KEY="u9W4X1bBHr9Aoe3h24+r5PhQJhy+il7GNLQH5mvP"
export AWS_SESSION_TOKEN="IQoJb3JpZ2luX2VjEM3//////////wEaCWV1LXdlc3QtMSJIMEYCIQCtB8HroobgP0s81vJYwcHT5K07L6FABblMXIUu2HEAhAIhANS91DCcaubKxfNSc0Z+2O7EOVy/C1SwmKFdqFVs4jT4Ku4DCJb//////////wEQABoMOTg2OTk1OTIzNjEzIgzTKlsuOrJrnwtM6QMqwgNducJshk9Ui1bTSN/7Tr2aVuXgateqGu68611cueWXXRqnQ7YYK6xj23Xmdnp3ghDdh+3V9UIXuaROX2iorpYSberajhEynffyPsMk9yFfkz76n1MgAgTe+0iLjec5iKGPsDjN8zzbLVZ/1JnY8qpVuYEAlDuXbJPx+Husz627S6K4YRXy5A1zzwC/thuUvxRMGnsXGsyumZfr1am6/gbf+mmTr3ZD+h5ysdBz60A7/3mnTB88uknobGQYV8X8LgfiGdzLGac+DZOgbkcngtm36vIGMXxZPSPoUppIbM7dx12lwdTnXYk16djJd5GFol+jy09ha8NTsxUWTO590icL8jnjOZijXqKbA5DukqGX/HDRinzDDLT7RqkoHgapNq58YmUl42kn0HpN6vAUKI3qpDqNeOWWpJoNpiOHtOYZka0q/PINpOUxrEhw06iGLHxUAVut8x4VoSNKIhHbQpJuTCLUIkDlyNYr6UIVwIvZAFPK3JJ+uM7KQvFWfFtPyO/YmcnUiXsKoTvw4wIlsLpXIL+YeADtosVjSda4OxQzwaf+KgPLJ3H62jzcT9WE4m9CcXAMYdRsqCBIK80anWxDYyswntO80gY6pwHSq3vcRsP8aDMlxuzwvm/ED0IaXi0a1y4FEA4DHnOqqFEkTEvFP324Fz1qHKJmYZzk4VnpYclDuTIIJJhR7RKlTIHE0uroSicTJosZiJvei37fvwFEVzRvyn3KNY2u8tdKt/+7OnqTO04v2DjZWz1LOPz1dmo4fSjf8Bpvy2skHktr03dWQgfXIviJTIIZW5LxFMYMPEPsLTbKIEK4IHvjP8VYfCmr0w=="

AWS_REGION="eu-west-1"
CODEBUILD_PROJECT_NAME="excelagent-build"

echo "Starting CodeBuild build..."
BUILD_OUTPUT=$(aws codebuild start-build --project-name "$CODEBUILD_PROJECT_NAME" --region "$AWS_REGION" --output json)

if [ $? -eq 0 ]; then
    BUILD_ID=$(echo "$BUILD_OUTPUT" | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)
    echo "Build started successfully!"
    echo "Build ID: $BUILD_ID"
    echo ""
    echo "Monitoring build status (this will take 5-10 minutes)..."
    echo ""
    
    while true; do
        BUILD_STATUS=$(aws codebuild batch-get-builds --ids "$BUILD_ID" --region "$AWS_REGION" --query 'builds[0].buildStatus' --output text)
        BUILD_PHASE=$(aws codebuild batch-get-builds --ids "$BUILD_ID" --region "$AWS_REGION" --query 'builds[0].currentPhase' --output text)
        
        echo "[$(date +%T)] Phase: $BUILD_PHASE | Status: $BUILD_STATUS"
        
        if [ "$BUILD_STATUS" = "SUCCEEDED" ]; then
            echo ""
            echo "✅ Build completed successfully!"
            break
        elif [ "$BUILD_STATUS" = "FAILED" ] || [ "$BUILD_STATUS" = "FAULT" ] || [ "$BUILD_STATUS" = "TIMED_OUT" ] || [ "$BUILD_STATUS" = "STOPPED" ]; then
            echo ""
            echo "❌ Build failed with status: $BUILD_STATUS"
            exit 1
        fi
        
        sleep 15
    done
else
    echo "Failed to start build"
    exit 1
fi
