"""
User-prompt builder functions for every node in the pipeline.
All inline f-string prompts are centralised here.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from helpers.context_util import estimate_tokens, trim_to_budget

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# node2 — domain validation
# ─────────────────────────────────────────────────────────────────────────────

def build_domain_validation_prompt(
    normalized_question: str,
    glossary_matches: list[dict],
) -> str:
    return f"""Classify this question into one category: "greeting", "relevant", or "other".

Rules:
- "greeting" = social greeting or thanks only
- "relevant" = asks about business, sales, products, markets, operations, strategy, "why" business questions, product portfolio/availability, regional presence, KPIs, data analysis, or any PMI-related business topic
- "other" = ONLY non-business topics (weather, sports, personal advice, entertainment)

Question: "{normalized_question}"

Glossary matches: {json.dumps(glossary_matches, ensure_ascii=False)}

Respond with ONLY this JSON structure (no other text):
{{
  "question_type": "greeting|relevant|other",
  "confidence": 0-100,
  "reason": "Brief explanation for classification",
  "greeting_response": "Friendly greeting response (only for greeting type)",
  "rejection_message": "Polite rejection message (only for other type)"
}}""".strip()


# ─────────────────────────────────────────────────────────────────────────────
# node2 — intent
# ─────────────────────────────────────────────────────────────────────────────

def build_intent_prompt(
    normalized_question: str,
    glossary_matches: list[dict],
    current_month_info: dict = None,
) -> str:
    # Build current month context if available
    current_month_context = ""
    if current_month_info and current_month_info.get('period'):
        current_month_context = f"""
**CURRENT REPORTING PERIOD:** {current_month_info['period']}
- If the user does NOT specify a time period, use this as the current month
- Use this to anchor all time-based calculations (Rolling 3M, Prior 3M, etc.)
"""

    # Build the prompt using string concatenation to avoid f-string conflicts with JSON
    base_section = """
You are a senior PMI business intelligence expert with 20+ years of domain experience. Your task is to interpret the user's business question and produce a precise, actionable analysis specification.

CRITICAL RULES:
- Use ONLY the normalized question and glossary evidence provided below
- Be specific about metrics (e.g., "shipment_volume", "IMS_volume", "market_share")
- Identify the exact analysis type needed (variance_decomposition, trend_analysis, benchmarking, etc.)
- Specify clear temporal context for comparisons
- Return ONLY valid JSON, no explanatory text

"""

    time_guidelines = current_month_context + """
# Time-Based Calculations Guidelines

## 1. Identify Current Month First
- The latest available month in the dataset is shown above as CURRENT REPORTING PERIOD
- If user doesn't specify a time period, anchor calculations to this current reporting period
- All calculations must be anchored to this **Current Month**.

---

## 2. Rolling Periods

- **Rolling 3M (Current 3 Months):**
  Includes the **current month and the two preceding months**.
  Formula: `Current Month, Current Month - 1, Current Month - 2`
  Example: If Current Month = December → Oct, Nov, Dec

- **Rolling 6M (Current 6 Months):**
  Includes the **current month and the five preceding months**.
  Formula: `Current Month, Current Month - 1, ..., Current Month - 5`
  Example: If Current Month = December → Jul, Aug, Sep, Oct, Nov, Dec

---

## 3. Prior Periods (Same Year Only)

- **Prior 3M:**
  The **3 months immediately before the Rolling 3M period**, within the same calendar year.
  Example: Rolling 3M = Oct–Dec → Prior 3M = Jul–Sep

- **Prior 6M:**
  The **6 months immediately before the Rolling 6M period**, within the same calendar year.
  Example: Rolling 6M = Jul–Dec → Prior 6M = Jan–Jun

---

## 4. Year-over-Year (YoY)

- Compare the **same month in the previous year**.
- Formula: `Current Month vs Same Month Last Year`
- Example: Dec 2025 vs Dec 2024

---

## Important Rules (to Avoid Ambiguity)

- Always calculate periods **relative to the Current Month**.
- Periods must be **continuous (no gaps)**.
- **Do not mix calendar years** for Prior periods.
- Month arithmetic must correctly handle boundaries:
- Example: Jan − 1 = Dec (previous year)

NORMALIZED QUESTION:
"""

    question_section = f"""{normalized_question}

GLOSSARY REPLACEMENTS APPLIED:
{json.dumps(glossary_matches, ensure_ascii=False)}

RETURN JSON IN THIS EXACT SHAPE:
{{
  "user_intent": "string",
  "analysis_type": "string",
  "primary_metrics": ["string"],
  "time_context": "string",
  "business_dimensions": ["string"]
}}
"""

    return (base_section + time_guidelines + question_section).strip()


# ─────────────────────────────────────────────────────────────────────────────
# node2 — intent refinement
# ─────────────────────────────────────────────────────────────────────────────

def build_intent_refinement_prompt(
    original_spec: dict[str, Any],
    column_context: str,
    user_clarifications: str,
    normalized_question: str,
) -> str:
    clarification_section = (
        f"\n\nUSER CLARIFICATIONS:\n{user_clarifications}"
        if user_clarifications.strip() else ""
    )
    if len(column_context) > 2000:
        column_section = f"\n\nCOLUMN CONTEXT FROM CANDIDATE SHEETS:\n{column_context[:2000]}..."
    elif column_context.strip():
        column_section = f"\n\nCOLUMN CONTEXT FROM CANDIDATE SHEETS:\n{column_context}"
    else:
        column_section = ""

    return f"""
You are a senior PMI data architect. Your task is to REFINE the existing analysis specification using newly available contextual information. The original specification was created from the user's question alone. Now you have additional context from actual data sources.

REFINEMENT RULES:
- PRESERVE the core user intent - do NOT change the fundamental analysis goal
- ENHANCE specificity using actual column names and values discovered
- ADD exact metric names found in the data sources
- REFINE business dimensions based on available data structure
- UPDATE time context if data reveals specific time periods available
- Return ONLY valid JSON, no explanatory text

ORIGINAL QUESTION:
{normalized_question}

CURRENT ANALYSIS SPECIFICATION:
{json.dumps(original_spec, ensure_ascii=False)}{clarification_section}{column_section}

RETURN REFINED JSON IN THIS EXACT SHAPE:
{{
  "user_intent": "string",
  "analysis_type": "string",
  "primary_metrics": ["string"],
  "time_context": "string",
  "business_dimensions": ["string"],
  "data_requirements": ["string"],
  "refinement_reason": "string"
}}
""".strip()


# ─────────────────────────────────────────────────────────────────────────────
# node2 — mapping
# ─────────────────────────────────────────────────────────────────────────────

def build_mapping_prompt(
    normalized_question: str,
    analysis_spec: dict[str, Any],
    catalog_rows: list[dict[str, str]],
    buscont_rows: list[dict[str, Any]],
    column_context: str = "",
    user_clarifications: str = "",
) -> str:
    """
    Build the file/sheet mapping prompt with Raw/Aggregated prioritisation.
    """
    # Condense spec if too large
    if len(str(analysis_spec)) > 2000:
        spec_summary: dict[str, Any] = {
            "user_intent": analysis_spec.get("user_intent", "")[:200] + "...",
            "analysis_type": analysis_spec.get("analysis_type", ""),
            "primary_metrics": analysis_spec.get("primary_metrics", [])[:8],
            "time_context": analysis_spec.get("time_context", ""),
            "business_dimensions": analysis_spec.get("business_dimensions", [])[:6],
            "_note": "Analysis spec condensed for prompt efficiency",
        }
        spec_json = json.dumps(spec_summary, ensure_ascii=False)
        logger.info(
            "Condensed analysis spec from %d to %d chars",
            len(str(analysis_spec)), len(spec_json),
        )
    else:
        spec_json = json.dumps(analysis_spec, ensure_ascii=False)

    catalog_json = json.dumps(catalog_rows, ensure_ascii=False)
    clarification_section = (
        f"\n\nUSER CLARIFICATIONS:\n{user_clarifications}"
        if user_clarifications.strip() else ""
    )

    header = f"""You are a senior PMI data architect with 20+ years of experience.
Your task: identify the exact Excel file(s) and sheet(s) that contain the data needed to answer the query.

DATA SOURCE PRIORITIZATION FRAMEWORK:
**PRIORITY 1 - RAW DATA (granularity_type: "Raw"):**
- Use when: Custom calculations needed, specific time periods, granular breakdowns
- Preferred for: variance analysis, trend calculations, detailed segmentation
- Examples: Secondary Vol, Financial Shipment Summary, P&L Database_Detailed

**PRIORITY 2 - AGGREGATED DATA (granularity_type: "Aggregated"):**
- Use when: Raw data insufficient OR standard KPIs already calculated
- Acceptable for: quick lookups, pre-computed metrics, summary reporting
- Examples: MBR sheets, Nielsen Insights, PMI Cigarette Dashboard main sheet

**DECISION MATRIX:**
- Need calculations → Prefer Raw data
- Need standard KPIs → Aggregated acceptable
- Need cross-file analysis → Use sheet_information linkage guidance
- Insufficient Raw data → Escalate to Aggregated + explain rationale

STRICT OUTPUT RULES:
- Return ONLY a single valid JSON object — no prose, no markdown fences.
- No trailing commas.  No line breaks inside string values.
- Set confidence (per entry AND overall) = 90-100 ONLY when evidence is unambiguous.
- Set per-entry "confidence" (0-100) for EVERY entry in file_and_sheet_mapping.
- Focus on BUSINESS RELEVANCE in "why" field, NOT execution strategy.

QUESTION:
{normalized_question}{clarification_section}

ANALYSIS SPECIFICATION:
{spec_json}

MATCHING RULES:
- primary_metrics → data_type field (synonyms and abbreviations allowed).
- question intent → purpose / sheet_information field.
- business dimensions → sheet_information field.
- granularity_type → prioritization (Raw preferred, Aggregated fallback).

CRITICAL SOURCE SELECTION RULES:
- 'sales' or 'volume' WITHOUT qualifier → SELECT ONLY Secondary Volume
- 'in market sales' or 'IMS' or 'secondary sales' → SELECT ONLY Secondary Volume
- 'PMI sales' → SELECT ONLY Secondary Volume (NOT Financial Shipments, NOT P&L)
- 'performance' (without explicit comparison words) → SELECT ONLY Secondary Volume to show actual results
- OB and RF Volume → ONLY if query EXPLICITLY asks for comparison vs plan/budget/OB/forecast/RF using words like: 'vs OB', 'vs RF', 'against plan', 'vs budget', 'vs forecast', 'gap analysis', 'better than plan', 'performance vs target'
- Financial Shipments → ONLY if query explicitly mentions 'shipment', 'primary sales', 'PMI to GPI', 'sell-in'
- P&L Database → ONLY if query explicitly mentions 'revenue', 'profit', 'margins', 'P&L', 'financial performance', 'NR', 'NOR', 'net revenue'
- Do NOT select multiple sources for simple volume/sales/performance queries - be precise and select ONE primary source!
"""
# - unique_values_summary → value hints per column; use to verify the sheet contains relevant dimension values.  [disabled]

    sections: list[tuple[str, str]] = [
        ("MBR CATALOG (file/sheet registry)", catalog_json),
    ]
    if column_context.strip():
        sections.append(("COLUMN-LEVEL DETAIL FOR CANDIDATE SHEETS", column_context))

    # Generous limit using 50% of Claude Sonnet 4.6's 200K token context window
    data_block = trim_to_budget(sections, max_chars=400_000)

    # If the catalog was larger than the allocated data_block, add an explicit
    # in-prompt warning so the LLM and downstream logs surface potential bias
    # toward earlier catalog entries.
    try:
        if len(data_block) < len(catalog_json):
            # WARNING NOTE: overflow-related notice disabled because overflow
            # checks are currently turned off. Preserve catalog truncation
            # behavior but do not append an overflow-specific warning.
            # warning_note = (
            #     "\n\n[WARNING: the catalog content was truncated to fit the mapping "
            #     "prompt budget. Selection may be biased toward earlier entries. "
            #     "Consider running the overflow check or narrowing candidate files.]"
            # )
            # data_block = data_block + warning_note
            pass
    except Exception:
        # Be resilient: do not fail prompt construction on any length check error
        logger.exception("build_mapping_prompt: error while checking/truncation warning")

    if estimate_tokens(header + data_block) > 60_000:
        logger.warning(
            "build_mapping_prompt: prompt exceeds 60K tokens even after trim — "
            "falling back to catalog-only mode"
        )
        data_block = trim_to_budget(
            [("MBR CATALOG (file/sheet registry)", catalog_json)],
            max_chars=150_000,
        )

    schema = """
CRITICAL: Return ONLY valid JSON. No explanatory text before or after.

RETURN JSON IN THIS EXACT SHAPE:
{
  "file_and_sheet_mapping": [
    {
      "file_name": "string",
      "tab_name": "string",
      "confidence": 0,
      "why": "string (max 150 chars - business relevance only)",
      "granularity_type": "Raw|Aggregated"
    }
  ],
  "confidence": 0
}
"""

    return (header + data_block + schema).strip()


# ─────────────────────────────────────────────────────────────────────────────
# node2 — overflow check
# ─────────────────────────────────────────────────────────────────────────────

def build_overflow_check_prompt(
    query: str,
    column_summary: str,
    overflow_index: str,
) -> str:
    # FUNCTION DISABLED: Original overflow prompt body commented out below.
    # def build_overflow_check_prompt(
    #     query: str,
    #     column_summary: str,
    #     overflow_index: str,
    # ) -> str:
    #     return (
    #         f"QUERY: {query}\n\n"
    #         f"COLUMN SUMMARY FOR CANDIDATE SHEETS:\n{column_summary}\n\n"
    #         f"AVAILABLE OVERFLOW COLUMNS (values not yet shown):\n{overflow_index}\n\n"
    #         "Do you need overflow values for any column to confirm the correct sheet selection?\n\n"
    #         "Respond ONLY with this JSON:\n"
    #         "{\n"
    #         '  "needs_overflow": true/false,\n'
    #         '  "requested_columns": [\n'
    #         '    {"file": "...", "sheet": "...", "column": "..."}\n'
    #         "  ],\n"
    #         '  "reason": "one-sentence explanation"\n'
    #         "}"
    #     )

    # Disabled stub return (kept to avoid None returns when called accidentally)
    return "OVERFLOW CHECK FUNCTION COMMENTED OUT"


# ─────────────────────────────────────────────────────────────────────────────
# code_generator — code generation
# ─────────────────────────────────────────────────────────────────────────────

def build_code_generation_prompt(query: str, query_context: str) -> str:
    return f"""QUERY: {query}

{query_context}

CRITICAL: Write EXECUTION-ONLY code. This code will be executed automatically.
- NO comments (#)
- NO decorative lines (===, ---)
- NO section headers or print banners
- ONLY: imports, data ops, concise print statements with results
- Keep prints minimal: "Metric: value unit"

Output ONLY raw Python code:

"""


def build_code_regen_prompt(query: str, query_context: str) -> str:
    return f"""QUERY: {query}

{query_context}

IMPORTANT: Previous code was TRUNCATED. Write ONLY 20-30 lines. Keep it simple.
Output ONLY raw Python code:"""


# ─────────────────────────────────────────────────────────────────────────────
# code_executor — fix broken code
# ─────────────────────────────────────────────────────────────────────────────

def build_code_fix_prompt(
    code: str,
    error: str,
    output: str,
    query_context: str,
    diagnostics: str | None = None,
) -> str:
    diag_section = ""
    if diagnostics:
        diag_section = f"""
ACTUAL DATA FROM FILE (from diagnostic script):
{diagnostics}

Use this to verify correct column indices and filter values."""

    return f"""ERROR:
{error[-1000:]}

PARTIAL OUTPUT:
{output[-500:] if output else 'None'}
{diag_section}
QUERY CONTEXT:
{query_context[:4000]}

BROKEN CODE:
{code}

Output ONLY the fixed Python code:"""


# ─────────────────────────────────────────────────────────────────────────────
# query_context_builder — value catalog matching
# ─────────────────────────────────────────────────────────────────────────────

def build_query_context_match_prompt(
    user_query: str,
    file_name: str,
    sheet_name: str,
    table_desc: str,
    value_catalog: str,
    samples_text: str,
) -> str:
    return f"""QUERY: {user_query}

SOURCE: {file_name} :: {sheet_name}

TABLES:
{table_desc}

VALUE CATALOG:
{value_catalog}

SAMPLE ROWS:
{samples_text}

Match the query terms to exact values and identify relevant columns."""


# ─────────────────────────────────────────────────────────────────────────────
# structure_analyzer — sheet structure analysis
# ─────────────────────────────────────────────────────────────────────────────

def build_structure_analysis_prompt(
    file_name: str,
    sheet_name: str,
    total_rows: int,
    total_cols: int,
    cols_text: str,
    transition_count: int,
    trans_text: str,
    samples_text: str,
    merges_text: str,
    source_context: str = "",
) -> str:
    return f"""FILE: '{file_name}'
SHEET: '{sheet_name}'
Dimensions: {total_rows} rows x {total_cols} columns

COLUMNS:
{cols_text}

TRANSITION ROWS (rows where the pattern changes):
Total transitions: {transition_count}
{trans_text}

SAMPLE ROWS (evenly spaced through the sheet):
{samples_text}

MERGED CELLS:
{merges_text}{source_context}"""


def build_narrative_explainer_prompt(query: str, raw_output: str) -> str:
    """Build prompt for converting raw data output into business narrative."""
    return f"""USER QUESTION:
{query}

RAW DATA OUTPUT FROM ANALYSIS:
{raw_output}

TASK:
Answer the user's question directly using the data above.

REQUIREMENTS:
1. Start with a direct answer to the specific question asked
2. Interpret the numbers in business context
3. If asked about trends/momentum: state the conclusion clearly (accelerating/decelerating/stable)
4. Support your answer with specific numbers from the output
5. CRITICAL: If the output contains dimensional breakdowns (by Brand, Region, Variant, Segment, etc.):
   - Cite the TOP 3-5 specific dimensions driving the pattern
   - Include their numeric contributions from the data
   - Use this as EVIDENCE for your explanation (not speculation)
   - Example: "Driven by Brand X (+25% QoQ) and Region Y (+18% QoQ)"
6. DO NOT speculate about causes if dimensional data is not in the output
7. If dimensional breakdown is missing but needed, state: "Further breakdown by [dimension] needed to identify specific drivers"
8. Keep it brief and focused - avoid unnecessary details
9. Use bullet points to highlight top drivers with metrics

Generate a clear, executive-ready answer with evidence-based explanations:"""

# ─────────────────────────────────────────────────────────────────────────────
# Context Node
#  ───────────────────────────────────────────────────────────────────────────
def context_merger_user(prev_question: str, prev_answer: str, new_question: str) -> str:
    """User prompt for context merger."""
    return f"""Previous Question: {prev_question}

Previous Answer: {prev_answer}

New Question: {new_question}

Create an enriched question that merges relevant context from the previous conversation with the new question."""


def relatedness_check_user(prev_question: str, prev_answer: str, new_question: str) -> str:
    """User prompt for relatedness check."""
    return f"""Previous Question: {prev_question}

Previous Answer: {prev_answer}

New Question: {new_question}

Is the new question related to the previous conversation context?"""