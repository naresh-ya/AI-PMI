"""Fuzzy filename and sheet-name matching helpers."""
from __future__ import annotations

import re


def fuzzy_match_file(want: str, registry: dict) -> str | None:
    """Return the first registry key that is a substring of `want` or vice-versa.

    Improves robustness by canonicalizing names: replace underscores and
    punctuation with spaces and collapse whitespace before performing
    substring checks. This ensures keys like 'Primary_Trade_Offers'
    match 'Primary Trade Offers'.
    """
    if not want:
        return None

    def _canonical(s: str) -> str:
        return re.sub(r"[_\-\s]+", " ", (s or "")).casefold().strip()

    want_c = _canonical(want)
    best: str | None = None
    best_len = -1
    for key in registry:
        key_c = _canonical(key)
        if not key_c:
            continue
        if want_c in key_c or key_c in want_c:
            if len(key_c) > best_len:
                best = key
                best_len = len(key_c)
    return best


def fuzzy_match_sheet(want: str, sheets: dict) -> str | None:
    """Return the first sheet name that fuzzy-matches `want`.

    Uses the same canonicalization as file matching so names with underscores,
    punctuation, or minor formatting differences still resolve.
    """
    if not want:
        return None

    def _canonical(s: str) -> str:
        return re.sub(r"[_\-\s]+", " ", (s or "")).casefold().strip()

    want_c = _canonical(want)
    for name in sheets:
        name_c = _canonical(name)
        if not name_c:
            continue
        if want_c in name_c or name_c in want_c:
            return name
    return None
