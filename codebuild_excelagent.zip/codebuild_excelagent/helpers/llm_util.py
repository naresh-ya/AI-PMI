"""LLM invocation and JSON response parsing utilities."""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from claude_setup.llm import get_llm, get_fast_model
from core.timing import timed

LOGGER = logging.getLogger(__name__)
MODEL = get_llm()
FAST_MODEL = get_fast_model()


def _friendly_llm_error(error: Exception | str) -> str:
    message = str(error)

    if "AccessDeniedException" in message and "service control policy" in message:
        return (
            "AWS Bedrock access is blocked by an organization Service Control Policy (SCP). "
            "Your code is configured correctly, but this AWS principal cannot call "
            "`bedrock:InvokeModel` for the selected Anthropic model. Ask your AWS admin to allow "
            "Bedrock model invocation for this account/role, or use credentials from an account "
            "that already has Claude access."
        )

    if "AccessDeniedException" in message and "bedrock:InvokeModel" in message:
        return (
            "AWS Bedrock denied `bedrock:InvokeModel` for the selected model. Verify IAM permissions, "
            "Bedrock model access, and the target AWS region."
        )

    return message


def _clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def parse_llm_json(text: Any) -> tuple[dict[str, Any] | None, str | None]:
    """Parse JSON from an LLM response, handling fences, comments, and minor formatting issues.

    Returns ``(parsed_dict, None)`` on success and ``(None, error_message)`` on failure.
    """
    if isinstance(text, list):
        text = " ".join(
            _clean_text(item.get("text", item)) if isinstance(item, dict) else _clean_text(item)
            for item in text
        )

    text = _clean_text(text)

    # Extract from code fences first
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    if fenced:
        text = fenced.group(1).strip()

    # Remove comments
    text = re.sub(r"//.*", "", text)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)

    # Find JSON boundaries more carefully
    start = text.find("{")
    if start == -1:
        return None, "No JSON object found"

    # Count braces to find proper end
    brace_count = 0
    end = start
    for i, char in enumerate(text[start:], start):
        if char == "{":
            brace_count += 1
        elif char == "}":
            brace_count -= 1
            if brace_count == 0:
                end = i
                break

    if brace_count != 0:
        # Fallback to rfind if brace counting fails
        end = text.rfind("}")
        if end == -1:
            return None, "Unclosed JSON object"

    payload = text[start : end + 1]

    # Try direct parsing first
    try:
        return json.loads(payload), None
    except json.JSONDecodeError:
        pass

    # Fix missing commas between object fields (common LLM error)
    payload = re.sub(r'"\s*\n\s*"', '",\n    "', payload)
    payload = re.sub(r'"\s*([}\]]\s*)"', r'",\1"', payload)
    payload = re.sub(r'(\]\s*)"([a-zA-Z_])', r'\1,"\2', payload)
    payload = re.sub(r'(\}\s*)"([a-zA-Z_])', r'\1,"\2', payload)
    payload = re.sub(r'([0-9]\s*)"([a-zA-Z_])', r'\1,"\2', payload)

    # Remove trailing commas
    payload = re.sub(r",\s*([}\]])", r"\1", payload)

    # Fix unquoted keys
    payload = re.sub(r"([,{]\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*:)", r'\1"\2"\3', payload)

    # Fix string values that span multiple lines
    payload = re.sub(r'"([^"]*?)\n\s*([^"]*?)"', r'"\1 \2"', payload)

    try:
        return json.loads(payload), None
    except json.JSONDecodeError as exc:
        try:
            error_pos = getattr(exc, "pos", len(payload))
            truncated = payload[:error_pos]
            last_comma   = truncated.rfind(",")
            last_brace   = truncated.rfind("}")
            last_bracket = truncated.rfind("]")
            cutoff = max(last_comma, last_brace, last_bracket)
            if cutoff > 0:
                attempt = truncated[:cutoff] + "}"
                result = json.loads(attempt)
                LOGGER.warning("JSON parse recovered partial result, truncated at position %d", cutoff)
                return result, None
        except Exception:
            pass

        return None, f"JSON parse error: {exc}"


def invoke_json(system_prompt: str, user_prompt: str, max_retries: int = 2) -> dict[str, Any]:
    """Invoke the LLM and parse the response as JSON, with retry logic for malformed responses.

    NOTE: This is sync version - for async streaming use invoke_json_async() instead.
    """
    last_error = None

    for attempt in range(max_retries + 1):
        try:
            with timed(f"LLM_CALL invoke_json attempt={attempt+1}"):
                response = MODEL.invoke(
                    [
                        SystemMessage(content=system_prompt),
                        HumanMessage(content=user_prompt),
                    ]
                )
            content = getattr(response, "content", str(response))


            payload, error = parse_llm_json(content)
            if payload is not None:
                return payload

            LOGGER.warning("JSON parse attempt %d failed: %s", attempt + 1, error)
            last_error = error

            if attempt < max_retries:
                user_prompt = (
                    user_prompt
                    + "\n\nIMPORTANT: Return ONLY valid JSON. Ensure all strings are properly "
                    "quoted and arrays/objects are properly closed."
                )

        except Exception as e:
            last_error = _friendly_llm_error(e)
            LOGGER.warning("LLM invocation attempt %d failed: %s", attempt + 1, e)

    raise ValueError(
        f"Failed to get valid JSON after {max_retries + 1} attempts. Last error: {last_error}"
    )


async def invoke_json_async(system_prompt: str, user_prompt: str, max_retries: int = 2, stream_callback=None) -> dict[str, Any]:
    """Async version with streaming support - streams tokens via callback, returns parsed JSON.

    Args:
        stream_callback: Optional function to call with each token (for visibility)
    """
    from langchain_core.messages import AIMessage

    last_error = None

    for attempt in range(max_retries + 1):
        try:
            with timed(f"LLM_CALL invoke_json_async attempt={attempt+1}"):
                # Stream the response token by token
                # Note: astream() yields plain strings, not AIMessage objects
                full_response = []
                async for token in MODEL.astream(
                    [
                        SystemMessage(content=system_prompt),
                        HumanMessage(content=user_prompt),
                    ]
                ):
                    # astream() yields plain strings
                    full_response.append(token)

                    # Call callback for streaming visibility
                    if stream_callback:
                        stream_callback(AIMessage(content=token))

                content = "".join(full_response)

            payload, error = parse_llm_json(content)
            if payload is not None:
                return payload

            LOGGER.warning("JSON parse attempt %d failed: %s", attempt + 1, error)
            last_error = error

            if attempt < max_retries:
                user_prompt = (
                    user_prompt
                    + "\n\nIMPORTANT: Return ONLY valid JSON. Ensure all strings are properly "
                    "quoted and arrays/objects are properly closed."
                )

        except Exception as e:
            last_error = _friendly_llm_error(e)
            LOGGER.warning("LLM invocation attempt %d failed: %s", attempt + 1, e)

    raise ValueError(
        f"Failed to get valid JSON after {max_retries + 1} attempts. Last error: {last_error}"
    )


def invoke_json_fast(system_prompt: str, user_prompt: str, max_retries: int = 1) -> dict[str, Any]:
    """Same as invoke_json but uses the fast (haiku) model for simple classification tasks.

    NOTE: This is sync version - for async streaming use invoke_json_fast_async() instead.
    """
    last_error = None

    for attempt in range(max_retries + 1):
        try:
            with timed(f"LLM_CALL_FAST invoke_json_fast attempt={attempt+1}"):
                response = FAST_MODEL.invoke(
                    [
                        SystemMessage(content=system_prompt),
                        HumanMessage(content=user_prompt),
                    ]
                )
            content = getattr(response, "content", str(response))


            payload, error = parse_llm_json(content)
            if payload is not None:
                return payload

            LOGGER.warning("Fast JSON parse attempt %d failed: %s", attempt + 1, error)
            last_error = error

        except Exception as e:
            last_error = _friendly_llm_error(e)
            LOGGER.warning("Fast LLM invocation attempt %d failed: %s", attempt + 1, e)

    raise ValueError(
        f"Fast model: Failed to get valid JSON after {max_retries + 1} attempts. Last error: {last_error}"
    )


async def invoke_json_fast_async(system_prompt: str, user_prompt: str, max_retries: int = 1, stream_callback=None) -> dict[str, Any]:
    """Async version with streaming support - streams tokens via callback, returns parsed JSON.

    Args:
        stream_callback: Optional function to call with each token (for visibility)
    """
    from langchain_core.messages import AIMessage

    last_error = None
    last_response = None

    for attempt in range(max_retries + 1):
        try:
            # On retry attempts, add the failed response and explicit correction instruction
            retry_user_prompt = user_prompt
            if attempt > 0 and last_response:
                retry_user_prompt = (
                    user_prompt +
                    f"\n\n[RETRY {attempt}/{max_retries}] Your previous response was invalid:\n"
                    f"Response: {last_response[:500]}\n"
                    f"Error: {last_error}\n\n"
                    "Return ONLY a valid JSON object. Start with {{ and end with }}. "
                    "No markdown code fences (```), no explanations, no text outside the JSON object."
                )

            with timed(f"LLM_CALL_FAST invoke_json_fast_async attempt={attempt+1}"):
                # Stream the response token by token
                full_response = []
                chunk_count = 0
                async for token in FAST_MODEL.astream(
                    [
                        SystemMessage(content=system_prompt),
                        HumanMessage(content=retry_user_prompt),
                    ]
                ):
                    chunk_count += 1

                    # astream() yields plain strings, not AIMessage objects
                    # Skip empty tokens
                    if token:
                        full_response.append(token)

                    # Call callback for streaming visibility
                    if stream_callback and token:
                        stream_callback(AIMessage(content=token))

                content = "".join(full_response)

            # Store for retry feedback
            last_response = content

            payload, error = parse_llm_json(content)
            if payload is not None:
                return payload

            LOGGER.warning("Fast JSON parse attempt %d failed: %s", attempt + 1, error)
            last_error = error

        except Exception as e:
            last_error = _friendly_llm_error(e)
            LOGGER.warning("Fast LLM invocation attempt %d failed: %s", attempt + 1, e)

    raise ValueError(
        f"Fast model: Failed to get valid JSON after {max_retries + 1} attempts. Last error: {last_error}"
    )
