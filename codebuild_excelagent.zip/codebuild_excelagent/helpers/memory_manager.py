"""AgentCore Memory Manager for Excel Agent.

This module provides a simple interface to AWS Bedrock AgentCore Memory
for storing and retrieving conversation context (Question + Answer pairs).

Usage:
    manager = ExcelAgentMemoryManager(
        region="eu-west-1",
        memory_id="memoryMBRshort-T8GbYmGACP"
    )

    # Store a Q+A pair
    manager.store_qa(
        session_id="thread-12345",
        question="What's the revenue for India?",
        answer="India revenue is $10M from MBR Dec'25"
    )

    # Retrieve previous Q+A
    prev_qa = manager.get_previous_qa(session_id="thread-12345")
    # Returns: {"question": "...", "answer": "..."}
"""

from __future__ import annotations

import logging
from typing import Optional

from bedrock_agentcore.memory import MemoryClient

logger = logging.getLogger(__name__)


class ExcelAgentMemoryManager:
    """Manager for AgentCore Memory operations.

    This class handles:
    - Connection to existing AgentCore Memory resource
    - Creating memory sessions per conversation thread
    - Storing question+answer pairs
    - Retrieving previous context

    Design:
    - One memory resource (shared across all conversations)
    - One session per AG-UI thread (session_id = thread_id)
    - One actor for entire pipeline (actor_id = "excel-agent-main")
    """

    ACTOR_ID = "excel-agent-main"  # Shared actor for all nodes

    def __init__(
        self,
        region: str,
        memory_id: str,
    ):
        """Initialize memory manager.

        Args:
            region: AWS region (e.g., "eu-west-1")
            memory_id: Existing AgentCore Memory ID (e.g., "memoryMBRshort-T8GbYmGACP")
        """
        self.region = region
        self.memory_id = memory_id

        # Initialize memory client (memory_id is passed per method call, not here)
        try:
            self.client = MemoryClient(region_name=region)
            logger.info(
                f"Memory manager initialized: memory_id={memory_id}, region={region}"
            )
        except Exception as e:
            logger.error(f"Failed to initialize memory manager: {e}")
            raise

    def get_previous_qa(self, session_id: str) -> Optional[dict[str, str]]:
        """Retrieve the most recent question+answer pair from memory.

        Args:
            session_id: Conversation thread ID (AG-UI threadId)

        Returns:
            {"question": "...", "answer": "..."} if previous conversation exists
            None if this is the first turn in the conversation

        Example:
            prev = manager.get_previous_qa("thread-12345")
            if prev:
        """
        try:
            # Retrieve last conversation turn using get_last_k_turns
            # This returns the most recent turn (USER + ASSISTANT pair)
            turns = self.client.get_last_k_turns(
                memory_id=self.memory_id,
                actor_id=self.ACTOR_ID,
                session_id=session_id,
                k=1,  # Get the last 1 turn (1 Q+A pair)
            )

            if not turns:
                logger.info(f"No previous conversation found for session={session_id}")
                return None

            # Extract the most recent turn
            # Format: [[{message_dict}, {message_dict}]]
            last_turn = turns[0] if turns else []

            if not last_turn or len(last_turn) < 2:
                logger.warning(f"Incomplete turn in memory: {len(last_turn)} messages")
                return None

            # Debug: log the actual format

            # Extract question and answer from the turn
            # Messages are dicts with 'content' and 'role' keys
            question = None
            answer = None

            for msg in last_turn:
                if not isinstance(msg, dict):
                    logger.warning(f"Unexpected message format: {type(msg)}")
                    continue

                content = msg.get("content", "")
                role = msg.get("role", "")

                # Extract text from content dict
                if isinstance(content, dict):
                    content = content.get("text", "")

                # Convert role to string if needed
                if hasattr(role, "value"):
                    role = role.value
                role = str(role).upper() if role else ""

                if role == "USER":
                    question = str(content) if content else None
                elif role == "ASSISTANT":
                    answer = str(content) if content else None

            if not question or not answer:
                logger.warning(
                    f"Incomplete Q+A pair in memory: question={bool(question)}, answer={bool(answer)}"
                )
                return None

            logger.info(
                f" Retrieved previous Q+A for session={session_id}: "
                f"Q={question[:50]}..., A={answer[:50]}..."
            )

            return {
                "question": question,
                "answer": answer,
            }

        except Exception as e:
            logger.error(f" Failed to retrieve previous Q+A: {e}")
            # Graceful degradation - return None so pipeline can continue
            return None

    def store_qa(
        self,
        session_id: str,
        question: str,
        answer: str,
    ) -> bool:
        """Store a question+answer pair to memory.

        Args:
            session_id: Conversation thread ID (AG-UI threadId)
            question: User's original question
            answer: Final answer from narrative explainer

        Returns:
            True if stored successfully, False otherwise

        Example:
            success = manager.store_qa(
                session_id="thread-12345",
                question="What's the revenue for India?",
                answer="India revenue is $10M from MBR Dec'25"
            )
        """
        try:
            # Create event with both user and assistant messages
            # Format as conversational turn
            # Note: MessageRole values need to be strings ("USER", "ASSISTANT")
            messages = [
                (question, "USER"),
                (answer, "ASSISTANT"),
            ]

            # Store to memory using create_event
            # Note: Parameter names are snake_case for Python SDK
            result = self.client.create_event(
                memory_id=self.memory_id,
                actor_id=self.ACTOR_ID,
                session_id=session_id,
                messages=messages,
            )

            event_id = result.get("eventId") if isinstance(result, dict) else None
            logger.info(
                f" Stored Q+A to memory: session={session_id}, event_id={event_id}"
            )

            return True

        except Exception as e:
            logger.error(f" Failed to store Q+A to memory: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            import traceback
            logger.error(f"   Traceback: {traceback.format_exc()}")
            # Graceful degradation - log error but don't crash pipeline
            return False

    def clear_session(self, session_id: str) -> bool:
        """Clear all memory for a specific session.

        Note: Currently not implemented by AgentCore Memory API.
        Sessions auto-expire based on retention period (7 days).

        Args:
            session_id: Conversation thread ID to clear

        Returns:
            False (not implemented)
        """
        logger.warning(
            f"Session clearing not implemented - sessions auto-expire. "
            f"session={session_id}"
        )
        return False


# Global singleton instance (lazy-initialized)
_memory_manager: Optional[ExcelAgentMemoryManager] = None


def get_memory_manager(
    region: str = "eu-west-1",
    memory_id: str = "memoryMBRshort-T8GbYmGACP",
) -> ExcelAgentMemoryManager:
    """Get or create global memory manager instance.

    Args:
        region: AWS region
        memory_id: AgentCore Memory ID

    Returns:
        Singleton ExcelAgentMemoryManager instance
    """
    global _memory_manager

    if _memory_manager is None:
        _memory_manager = ExcelAgentMemoryManager(
            region=region,
            memory_id=memory_id,
        )

    return _memory_manager
