"""Shared S3 helpers for listing, reading, and writing S3-backed artifacts."""

from __future__ import annotations

import hashlib
import json
from io import BytesIO
from pathlib import Path
from typing import Iterable

import boto3
from botocore.exceptions import ClientError

from core.settings import settings


EXCEL_SUFFIXES = (".xlsx", ".xls")
SUPPORT_FILENAMES = ("Glossary_PMI.csv", "raw_intents_enhanced_v2.csv")


def is_s3_uri(value: str) -> bool:
    return str(value or "").strip().lower().startswith("s3://")


def parse_s3_uri(uri: str) -> tuple[str, str]:
    if not is_s3_uri(uri):
        raise ValueError(f"Not an S3 URI: {uri}")

    remainder = uri[5:]
    bucket, _, key = remainder.partition("/")
    return bucket, key


def build_s3_uri(bucket: str, key: str) -> str:
    return f"s3://{bucket}/{key.lstrip('/')}"


def default_raw_s3_uri() -> str | None:
    if not settings.s3_bucket:
        return None
    return build_s3_uri(settings.s3_bucket, settings.s3_raw_prefix)


def default_output_s3_uri() -> str | None:
    if not settings.s3_bucket:
        return None
    return build_s3_uri(settings.s3_bucket, settings.s3_output_prefix)


def default_support_s3_uri(filename: str) -> str | None:
    raw_uri = default_raw_s3_uri()
    if not raw_uri:
        return None
    bucket, prefix = parse_s3_uri(raw_uri)
    prefix = prefix.rstrip("/")
    key = f"{prefix}/{filename}" if prefix else filename
    return build_s3_uri(bucket, key)


def get_s3_client():
    return boto3.client("s3")


def source_name(value: str) -> str:
    if is_s3_uri(value):
        _, key = parse_s3_uri(value)
        return Path(key).name
    return Path(value).name


def source_stem(value: str) -> str:
    return Path(source_name(value)).stem


def profile_artifact_name(source: str) -> str:
    return f"{source_stem(source)}_profile.json"


def structure_artifact_name(source: str, sheet_name: str) -> str:
    return f"{source_stem(source)}_{sheet_name}_structure.json"


def profile_artifact_uri(output_uri: str, source: str) -> str:
    return f"{str(output_uri).rstrip('/')}/{profile_artifact_name(source)}"


def structure_artifact_uri(output_uri: str, source: str, sheet_name: str) -> str:
    return f"{str(output_uri).rstrip('/')}/{structure_artifact_name(source, sheet_name)}"


def _list_keys(bucket: str, prefix: str) -> list[str]:
    client = get_s3_client()
    paginator = client.get_paginator("list_objects_v2")
    keys: list[str] = []

    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for item in page.get("Contents", []):
            key = item.get("Key", "")
            if key and not key.endswith("/"):
                keys.append(key)

    return keys


def list_keys_for_uri(uri: str, suffixes: Iterable[str] | None = None) -> list[tuple[str, str]]:
    bucket, key = parse_s3_uri(uri)
    suffixes_tuple = tuple(s.lower() for s in (suffixes or ()))

    if key.lower().endswith(suffixes_tuple or EXCEL_SUFFIXES):
        return [(bucket, key)]

    prefix = key if not key or key.endswith("/") else f"{key}/"
    pairs = [(bucket, obj_key) for obj_key in _list_keys(bucket, prefix)]

    if suffixes_tuple:
        pairs = [pair for pair in pairs if pair[1].lower().endswith(suffixes_tuple)]

    return pairs


def list_s3_uris(uri: str, suffixes: Iterable[str] | None = None) -> list[str]:
    return [build_s3_uri(bucket, key) for bucket, key in list_keys_for_uri(uri, suffixes=suffixes)]


def read_s3_bytes(uri: str) -> bytes:
    bucket, key = parse_s3_uri(uri)
    response = get_s3_client().get_object(Bucket=bucket, Key=key)
    return response["Body"].read()


def s3_object_exists(uri: str) -> bool:
    bucket, key = parse_s3_uri(uri)
    try:
        get_s3_client().head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as exc:
        code = str(exc.response.get("Error", {}).get("Code", ""))
        if code in {"404", "NoSuchKey", "NotFound"}:
            return False
        raise


def read_text(uri: str | Path, encoding: str = "utf-8") -> str:
    if is_s3_uri(str(uri)):
        return read_s3_bytes(str(uri)).decode(encoding)
    return Path(uri).read_text(encoding=encoding)


def read_json(uri: str | Path) -> dict | list:
    return json.loads(read_text(uri, encoding="utf-8"))


def write_s3_bytes(uri: str, payload: bytes, content_type: str | None = None) -> str:
    bucket, key = parse_s3_uri(uri)
    kwargs = {"Bucket": bucket, "Key": key, "Body": payload}
    if content_type:
        kwargs["ContentType"] = content_type
    get_s3_client().put_object(**kwargs)
    return uri


def write_text(uri: str | Path, text: str, encoding: str = "utf-8") -> str:
    if is_s3_uri(str(uri)):
        return write_s3_bytes(str(uri), text.encode(encoding), content_type="text/plain; charset=utf-8")
    Path(uri).write_text(text, encoding=encoding)
    return str(uri)


def write_json(uri: str | Path, payload: dict | list) -> str:
    return write_text(uri, json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def append_text(uri: str | Path, text: str, encoding: str = "utf-8") -> str:
    if is_s3_uri(str(uri)):
        existing = ""
        try:
            existing = read_text(uri, encoding=encoding)
        except Exception:
            existing = ""
        return write_text(uri, existing + text, encoding=encoding)

    with Path(uri).open("a", encoding=encoding) as fh:
        fh.write(text)
    return str(uri)


def excel_bytes_buffer(uri: str) -> BytesIO:
    return BytesIO(read_s3_bytes(uri))


def compute_source_hash(uri: str) -> str:
    if is_s3_uri(uri):
        return hashlib.md5(read_s3_bytes(uri)).hexdigest()

    digest = hashlib.md5()
    with open(uri, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stage_s3_objects(
    uri: str,
    local_dir: str | Path,
    suffixes: Iterable[str] | None = None,
) -> list[str]:
    local_root = Path(local_dir)
    local_root.mkdir(parents=True, exist_ok=True)

    client = get_s3_client()
    local_paths: list[str] = []

    for bucket, key in list_keys_for_uri(uri, suffixes=suffixes):
        target = local_root / Path(key).name
        target.parent.mkdir(parents=True, exist_ok=True)
        client.download_file(bucket, key, str(target))
        local_paths.append(str(target.resolve()))

    return local_paths


def upload_file_to_s3(local_path: str | Path, bucket: str, key: str) -> str:
    client = get_s3_client()
    client.upload_file(str(local_path), bucket, key)
    return build_s3_uri(bucket, key)


def upload_paths_to_prefix(
    local_paths: Iterable[str | Path],
    output_s3_uri: str,
) -> list[str]:
    bucket, prefix = parse_s3_uri(output_s3_uri)
    prefix = prefix.rstrip("/")
    uploaded: list[str] = []

    for local_path in local_paths:
        path = Path(local_path)
        key = f"{prefix}/{path.name}" if prefix else path.name
        uploaded.append(upload_file_to_s3(path, bucket, key))

    return uploaded


def ensure_support_file(filename: str, local_path: str | Path) -> Path:
    target = Path(local_path)
    if target.exists():
        return target

    support_uri = default_support_s3_uri(filename)
    if not support_uri:
        raise FileNotFoundError(f"S3 support file location is not configured for {filename}")

    staged = stage_s3_objects(support_uri, target.parent, suffixes=(target.suffix,))
    if not staged:
        raise FileNotFoundError(f"Could not stage support file from S3: {support_uri}")

    staged_path = Path(staged[0])
    if staged_path.resolve() != target.resolve():
        target.parent.mkdir(parents=True, exist_ok=True)
        staged_path.replace(target)
    return target
