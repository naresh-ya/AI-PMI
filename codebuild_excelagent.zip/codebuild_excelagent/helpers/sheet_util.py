"""Column-level summary and overflow chunk builders scoped to matched sheets."""
from __future__ import annotations

import logging
from typing import Any

from core.settings import HIGH_CARDINALITY_THRESHOLD, OVERFLOW_VALUES_PER_CHUNK
from helpers.fuzzy_util import fuzzy_match_file, fuzzy_match_sheet

LOGGER = logging.getLogger(__name__)


def build_sheet_column_summary(
    profile_registry: dict,
    matched_sources: list[dict],
    max_chars: int = 100_000,
) -> str:
    """
    Build a column-level detail block for *only* the matched (file, sheet) pairs.

    Low-cardinality columns (≤ HIGH_CARDINALITY_THRESHOLD) show all values.
    High-cardinality columns show a 10-value sample with an overflow notice.
    """
    parts: list[str] = []
    total_chars = 0

    for src in matched_sources:
        reg_key = fuzzy_match_file(src.get("file", ""), profile_registry)
        if reg_key is None:
            parts.append(f"[No profile found for '{src.get('file', '')}']")
            continue

        sheets: dict = profile_registry[reg_key]["profile"].get("sheets", {})
        actual_sheet = fuzzy_match_sheet(src.get("sheet", ""), sheets)
        if actual_sheet is None:
            parts.append(f"[Sheet '{src.get('sheet', '')}' not found in profile for '{reg_key}']")
            continue

        si = sheets[actual_sheet]
        # Note: total_rows and total_cols removed - show column count instead
        num_cols = len(si.get("column_profiles", {}))
        header = (
            f"{'=' * 60}\n"
            f"FILE: {reg_key}\n"
            f"  SHEET: '{actual_sheet}' ({num_cols} columns)\n"
        )
        parts.append(header)
        total_chars += len(header)

        text_parts: list[str] = []
        num_cols: list[str] = []

        for col, cp in si.get("column_profiles", {}).items():
            ctype = cp.get("type", "")
            if ctype in ("text", "mixed"):
                texts: list[str] = cp.get("unique_texts", [])
                count = cp.get("unique_text_count", len(texts))
                if count <= HIGH_CARDINALITY_THRESHOLD:
                    vals = ", ".join(f"'{v}'" for v in texts)
                    line = f"    Col {col}: {ctype}, {count} unique\n      Values: {vals}"
                else:
                    sample = ", ".join(f"'{v}'" for v in texts[:10])
                    line = (
                        f"    Col {col}: {ctype}, {count} unique\n"
                        f"      Sample (first 10): {sample}\n"
                        f"      … (+{count - 10} more — available in overflow chunks)"
                    )
                text_parts.append(line)
                total_chars += len(line)
                if total_chars >= max_chars:
                    text_parts.append("  … (budget reached — remaining columns omitted)")
                    break
            elif ctype == "numeric":
                num_cols.append(col)

        if text_parts:
            parts.append("  Text/Label columns:")
            parts.extend(text_parts)
        if num_cols:
            parts.append(f"  Numeric columns: {', '.join(num_cols)}")
        parts.append("")

    return "\n".join(parts)


def build_sheet_overflow_chunks(
    profile_registry: dict,
    matched_sources: list[dict],
    chunk_size: int = OVERFLOW_VALUES_PER_CHUNK,
) -> list[dict]:
    # FUNCTION DISABLED: build_sheet_overflow_chunks
    # Original implementation commented out for safe disable; kept below for reference.
    # chunks: list[dict] = []
    # for src in matched_sources:
    #     reg_key = fuzzy_match_file(src.get("file", ""), profile_registry)
    #     if reg_key is None:
    #         continue
    #     sheets = profile_registry[reg_key]["profile"].get("sheets", {})
    #     actual_sheet = fuzzy_match_sheet(src.get("sheet", ""), sheets)
    #     if actual_sheet is None:
    #         continue
    #     for col, cp in sheets[actual_sheet].get("column_profiles", {}).items():
    #         if cp.get("type") not in ("text", "mixed"):
    #             continue
    #         texts: list[str] = cp.get("unique_texts", [])
    #         if len(texts) <= HIGH_CARDINALITY_THRESHOLD:
    #             continue
    #         total = (len(texts) + chunk_size - 1) // chunk_size
    #         for i in range(total):
    #             start = i * chunk_size
    #             chunks.append({
    #                 "file": reg_key,
    #                 "sheet": actual_sheet,
    #                 "column": col,
    #                 "chunk_index": i,
    #                 "total_chunks": total,
    #                 "values": texts[start: start + chunk_size],
    #             })
    # return chunks

    # Disabled stub to preserve API — returns empty list when called.
    return []


def format_overflow_chunk(chunk: dict) -> str:
    # FUNCTION DISABLED: format_overflow_chunk
    # Original implementation commented out for reference.
    # vals = ", ".join(f"'{v}'" for v in chunk["values"])
    # return (
    #     f"OVERFLOW — {chunk['file']} :: {chunk['sheet']} :: Col {chunk['column']} "
    #     f"(chunk {chunk['chunk_index'] + 1}/{chunk['total_chunks']})\n"
    #     f"  Values: {vals}"
    # )

    return "OVERFLOW CHUNK FUNCTION COMMENTED OUT"
