"""Token budget and section-trimming utilities for prompt assembly."""

from __future__ import annotations


def estimate_tokens(text: str) -> int:
    """Rough token estimate: 1 token ≈ 4 characters."""
    return len(text) // 4


def trim_to_budget(
    sections: list[tuple[str, str]],
    max_chars: int,
) -> str:
    """
    Assemble labelled sections in priority order, truncating lower-priority ones
    if the total would exceed max_chars.  Adds a [TRUNCATED] notice when cut.

    Args:
        sections: [(label, content), ...] — highest priority first.
        max_chars: hard char cap.

    Returns:
        Assembled block string ready to embed in a prompt.
    """
    parts: list[str] = []
    remaining = max_chars
    for label, content in sections:
        header = f"\n{label}:\n"
        block = header + content
        if len(block) <= remaining:
            parts.append(block)
            remaining -= len(block)
        else:
            usable = max(0, remaining - len(header) - 60)
            if usable > 300:
                parts.append(
                    header
                    + content[:usable]
                    + "\n... [TRUNCATED — token budget reached]"
                )
            elif parts:
                parts.append(f"\n[{label}: omitted — token budget exhausted]")
            remaining = 0
            break
    return "".join(parts)
