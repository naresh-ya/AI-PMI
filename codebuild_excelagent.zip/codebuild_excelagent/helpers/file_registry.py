"""File registry for managing multiple Excel files."""

from __future__ import annotations

import csv
import json
import logging
import os
import re
from io import StringIO
from pathlib import Path
from typing import Any, Dict, List, Optional

_logger = logging.getLogger(__name__)

from core.settings import (
    BASE_DIR as _BASE_DIR,
    PROJECT_ROOT as _PROJECT_ROOT,
    get_s3_paths,
)
from core.timing import timed
from helpers.s3_storage import (
    EXCEL_SUFFIXES,
    is_s3_uri,
    list_s3_uris,
    profile_artifact_uri,
    read_json,
    read_text,
    s3_object_exists,
    source_stem,
)


def _clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


# Maps raw column headers → canonical Python key names (sourced from core.settings).


def discover_excel_files(paths: List[str]) -> List[str]:
    """
    Accept a mix of file paths and directory paths.
    Returns a flat list of all .xlsx / .xls files found.
    """
    excel_files = []
    for p in paths:
        p = str(p).strip()
        if is_s3_uri(p):
            try:
                excel_files.extend(list_s3_uris(p, suffixes=EXCEL_SUFFIXES))
            except Exception as exc:
                code = (
                    getattr(exc, "response", {})
                    .get("Error", {})
                    .get("Code", "")
                )
                if code == "ExpiredToken":
                    _logger.error("AWS session token expired for %s. Please refresh credentials.", p)
                else:
                    _logger.error("Could not read S3 path %s: %s", p, exc)
        elif os.path.isdir(p):
            for root, _, files in os.walk(p):
                for f in files:
                    if f.endswith(('.xlsx', '.xls')) and not f.startswith('~$'):
                        excel_files.append(os.path.join(root, f))
        elif os.path.isfile(p) and p.endswith(('.xlsx', '.xls')):
            excel_files.append(p)
        else:
            _logger.warning("Skipping invalid path: %s", p)

    # Remove duplicates, preserve order
    seen = set()
    unique = []
    for f in excel_files:
        if is_s3_uri(f):
            normalized = f.strip().rstrip("/")
        else:
            normalized = os.path.normpath(os.path.abspath(f))
        if normalized not in seen:
            seen.add(normalized)
            unique.append(f if is_s3_uri(f) else normalized)

    return unique


def build_source_key(file_path: str, sheet_name: str) -> str:
    """Build a unique key for a file::sheet combination."""
    file_name = source_stem(file_path)
    return f"{file_name}::{sheet_name}"


def parse_source_key(key: str) -> tuple:
    """Parse a source key back into (file_name, sheet_name)."""
    parts = key.split("::", 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return key, ""


# ── Constants for summary budget ──────────────────────────────────
MAX_SUMMARY_CHARS = 200_000        # ~50K tokens — safe for most models
HIGH_CARDINALITY_THRESHOLD = 50    # columns with >50 unique texts get chunked
VALUES_PER_CHUNK = 200             # how many values per overflow chunk


def _estimate_char_budget(file_registry: Dict) -> int:
    """Estimate per-sheet char budget based on total number of sheets."""
    total_sheets = sum(
        len(info.get("profile", {}).get("sheets", {}))
        for info in file_registry.values()
    )
    if total_sheets == 0:
        return MAX_SUMMARY_CHARS
    return max(MAX_SUMMARY_CHARS // max(total_sheets, 1), 10_000)


def _build_column_value_text(
    col_letter: str,
    cp: dict,
    budget_remaining: int,
    compact: bool = False,
) -> tuple:
    """
    Build text for a single column's values.
    Returns (text, chars_used).
    If compact=True, only sends count + first 5 values as fallback.
    """
    col_type = cp.get("type", "")
    if col_type not in ("text", "mixed"):
        return "", 0

    unique_texts = cp.get("unique_texts", [])
    unique_count = cp.get("unique_text_count", len(unique_texts))

    if not unique_texts:
        return "", 0

    if compact:
        # Tier 1: minimal fingerprint
        sample = ", ".join(f"'{v}'" for v in unique_texts[:5])
        suffix = f" (+{unique_count - 5} more)" if unique_count > 5 else ""
        line = f"    Col {col_letter}: {col_type}, {unique_count} unique — {sample}{suffix}"
        return line, len(line)

    # Tier 2/3: try to send ALL values
    all_vals_str = ", ".join(f"'{v}'" for v in unique_texts)
    full_line = (
        f"    Col {col_letter}: {col_type}, {unique_count} unique\n"
        f"      Values: {all_vals_str}"
    )

    if len(full_line) <= budget_remaining:
        # Fits in budget — send everything
        return full_line, len(full_line)

    # Doesn't fit — truncate to what fits, note the overflow
    max_vals = max(budget_remaining // 20, 10)  # rough estimate: ~20 chars per value
    truncated_vals = ", ".join(f"'{v}'" for v in unique_texts[:max_vals])
    trunc_line = (
        f"    Col {col_letter}: {col_type}, {unique_count} unique\n"
        f"      Values: {truncated_vals}\n"
        f"      ... (+{unique_count - max_vals} more — available in overflow chunks)"
    )
    return trunc_line, len(trunc_line)


def build_global_summary(
    file_registry: Dict,
    max_chars: int = MAX_SUMMARY_CHARS,
    send_all_values: bool = True,
) -> str:
    """
    Build a summary of ALL files and sheets for LLM sheet selection.
    
    If send_all_values=True (default), sends all unique text values for
    each column, respecting the char budget. High-cardinality columns
    that don't fit are truncated with a note.
    """
    summary_parts = []
    per_sheet_budget = _estimate_char_budget(file_registry)
    total_chars = 0

    for file_name, file_info in file_registry.items():
        file_path = file_info.get("file_path", "")
        profile = file_info.get("profile", {})
        structures = file_info.get("structures", {})

        header = f"{'='*60}\nFILE: {file_name}\n  Path: {file_path}"
        summary_parts.append(header)
        total_chars += len(header)

        sheets = profile.get("sheets", {})
        summary_parts.append(f"  Sheets: {len(sheets)}")

        for sheet_name, sheet_info in sheets.items():
            # Note: total_rows and total_cols removed - show column count instead
            num_cols = len(sheet_info.get("column_profiles", {}))

            sheet_header = f"\n  SHEET: '{sheet_name}' ({num_cols} columns)"
            summary_parts.append(sheet_header)
            total_chars += len(sheet_header)

            # ── Column values ──
            col_profiles = sheet_info.get("column_profiles", {})
            text_col_parts = []
            num_cols = []
            sheet_budget_remaining = per_sheet_budget

            for col_letter, cp in col_profiles.items():
                if cp.get("type") in ("text", "mixed"):
                    if send_all_values and total_chars < max_chars:
                        col_text, chars_used = _build_column_value_text(
                            col_letter, cp,
                            budget_remaining=min(sheet_budget_remaining, max_chars - total_chars),
                            compact=False,
                        )
                    else:
                        # Over budget — fall back to compact
                        col_text, chars_used = _build_column_value_text(
                            col_letter, cp,
                            budget_remaining=1000,
                            compact=True,
                        )
                    text_col_parts.append(col_text)
                    total_chars += chars_used
                    sheet_budget_remaining -= chars_used
                elif cp.get("type") == "numeric":
                    num_cols.append(col_letter)

            if text_col_parts:
                summary_parts.append("  Text/Label columns:")
                summary_parts.extend(text_col_parts)

            if num_cols:
                summary_parts.append(f"  Numeric columns: {', '.join(num_cols[:20])}")
                if len(num_cols) > 20:
                    summary_parts.append(f"    ... (+{len(num_cols) - 20} more)")

            # ── Structure info (unchanged) ──
            structure = structures.get(sheet_name, {})
            tables = structure.get("tables", [])
            if tables:
                summary_parts.append("  Tables detected:")
                for t in tables[:3]:
                    summary_parts.append(
                        f"    - '{t.get('name', '?')}': rows {t.get('data_start_row')}-{t.get('data_end_row')}, "
                        f"labels={t.get('label_columns', [])}, data={t.get('data_columns', [])}"
                    )
                    desc = t.get("description", "")
                    if desc:
                        summary_parts.append(f"      Description: {desc[:200]}")

            hierarchies = structure.get("hierarchies", [])
            if hierarchies:
                summary_parts.append("  Hierarchies:")
                for h in hierarchies[:4]:
                    summary_parts.append(
                        f"    - Col {h.get('column', '?')}: {h.get('description', '')[:150]}"
                    )

            notes = structure.get("notes", "")
            if notes:
                summary_parts.append(f"  Notes: {notes[:300]}")

        summary_parts.append("")

    return "\n".join(summary_parts)


def build_overflow_chunks(
    file_registry: Dict,
    chunk_size: int = VALUES_PER_CHUNK,
) -> List[Dict]:
    """
    Build overflow chunks for high-cardinality columns that couldn't
    fit in the main summary. Each chunk contains values for one column.
    
    Returns list of dicts:
      {"file": str, "sheet": str, "column": str, "chunk_index": int,
       "total_chunks": int, "values": list[str]}
    """
    # FUNCTION DISABLED: build_overflow_chunks
    # Original implementation commented out for reference.
    # chunks = []
    # for file_name, file_info in file_registry.items():
    #     profile = file_info.get("profile", {})
    #     for sheet_name, sheet_info in profile.get("sheets", {}).items():
    #         for col_letter, cp in sheet_info.get("column_profiles", {}).items():
    #             if cp.get("type") not in ("text", "mixed"):
    #                 continue
    #             unique_texts = cp.get("unique_texts", [])
    #             if len(unique_texts) <= HIGH_CARDINALITY_THRESHOLD:
    #                 continue
    #             # Split into chunks
    #             total_chunks = (len(unique_texts) + chunk_size - 1) // chunk_size
    #             for i in range(total_chunks):
    #                 start = i * chunk_size
    #                 end = start + chunk_size
    #                 chunks.append({
    #                     "file": file_name,
    #                     "sheet": sheet_name,
    #                     "column": col_letter,
    #                     "chunk_index": i,
    #                     "total_chunks": total_chunks,
    #                     "values": unique_texts[start:end],
    #                 })
    # return chunks

    # Disabled stub to preserve API — returns empty list when called.
    return []


def format_overflow_chunk(chunk: Dict) -> str:
    """Format a single overflow chunk for LLM consumption."""
    # FUNCTION DISABLED: format_overflow_chunk
    # Original implementation commented out for reference.
    # vals = ", ".join(f"'{v}'" for v in chunk["values"])
    # return (
    #     f"OVERFLOW — {chunk['file']} :: {chunk['sheet']} :: Col {chunk['column']} "
    #     f"(chunk {chunk['chunk_index']+1}/{chunk['total_chunks']})\n"
    #     f"  Values: {vals}"
    # )

    return "OVERFLOW CHUNK FUNCTION COMMENTED OUT"


def _canonical_name(value: str) -> str:
    if not value:
        return ""
    value = source_stem(value) if is_s3_uri(value) else value
    path = Path(value)
    if path.suffix.lower() in (".xlsx", ".xls", ".csv", ".json"):
        value = path.stem
    value = re.sub(r"(_profile|_structure)$", "", value, flags=re.IGNORECASE)
    value = re.sub(r"[_\-\s]+", " ", value)
    return value.casefold().strip()


def get_file_path_by_name(file_registry: Dict, file_name: str) -> Optional[str]:
    """Look up full file path from a file name or partial match."""
    if file_name in file_registry:
        return file_registry[file_name].get("file_path")

    canonical_name = _canonical_name(file_name)
    best_match_path: Optional[str] = None
    best_len = -1

    for name, info in file_registry.items():
        name_canonical = _canonical_name(name)
        if canonical_name == name_canonical:
            return info.get("file_path")

        if canonical_name and (canonical_name in name_canonical or name_canonical in canonical_name):
            if len(name_canonical) > best_len:
                best_match_path = info.get("file_path")
                best_len = len(name_canonical)

    return best_match_path


# ─────────────────────────────────────────────────────────────────────────────
# Glossary loader
# ─────────────────────────────────────────────────────────────────────────────

def load_glossary_index(user_jwt_token: str = None) -> dict[str, dict[str, str]]:
    """
    Loads a cleaned glossary index mapping abbreviations and synonyms → full form.
    Fixes issues with:
    - Excel NBSP characters
    - empty/misaligned fields
    - duplicate abbreviations
    - hidden whitespace
    
    Args:
        user_jwt_token: Optional JWT token for user-specific month tracking
    """

    def clean(s: str) -> str:
        if not s:
            return ""
        s = s.replace("\u00A0", " ")
        s = re.sub(r"[\t\r\f\v]+", " ", s)
        s = re.sub(r"\s+", " ", s)
        return s.strip()

    glossary_index: dict[str, dict[str, str]] = {}

    # Fetch paths from user-specific API
    paths = get_s3_paths(user_jwt_token)
    glossary_path = paths.get('GLOSSARY_PATH')

    if not glossary_path:
        _logger.warning("GLOSSARY_PATH not found in API Gateway response. Continuing without glossary normalization.")
        return {}

    try:
        raw_text = read_text(glossary_path, encoding="utf-8")
    except Exception as exc:
        _logger.warning("Glossary file could not be read (%s). Continuing without glossary normalization.", exc)
        return {}

    try:
        with StringIO(raw_text, newline="") as f:
            reader = csv.DictReader(f, delimiter=",")

            for raw_row in reader:
                raw_abbr = (
                    raw_row.get("Abbreviation")
                    or raw_row.get("Abbreviation ".strip())
                    or raw_row.get("\ufeffAbbreviation")
                    or ""
                )
                raw_syn  = raw_row.get("Synonym") or raw_row.get("Synonym ".strip()) or ""
                raw_full = (
                    raw_row.get("Full form")
                    or raw_row.get("Full form ".strip())
                    or raw_row.get("Full\u00A0form")
                    or raw_row.get("Full\u00A0form ".strip())
                    or ""
                )

                term      = _clean_text(raw_abbr or "")
                synonym   = _clean_text(raw_syn  or "")
                canonical = _clean_text(raw_full or "")

                if not canonical:
                    continue

                if term:
                    key = term.casefold()
                    if key not in glossary_index:
                        glossary_index[key] = {"term": term, "canonical": canonical}

                if synonym:
                    key = synonym.casefold()
                    if key not in glossary_index:
                        glossary_index[key] = {"term": synonym, "canonical": canonical}
    except Exception as exc:
        _logger.warning("Failed to parse glossary file at %s: %s", glossary_path, exc)
        return {}

    return glossary_index



# ─────────────────────────────────────────────────────────────────────────────
# Profile registry — loads *_profile.json files produced by excel_profiler
# ─────────────────────────────────────────────────────────────────────────────

def clear_profile_registry_cache():
    """Legacy function - no longer needed as caching has been removed from all registry loaders."""
    pass  # No-op: all @lru_cache decorators removed per user request


def _filter_column_profiles(column_profiles: dict) -> dict:
    """
    Filter column profiles to keep only essential fields.

    Keeps only 3 fields per column:
    - col_letter: Column reference (A, B, C, etc.)
    - type: Data type (text, numeric, mixed)
    - unique_texts: Sample values for LLM prompt enrichment

    Removes 7 unused fields:
    - header_name (redundant - structure has it)
    - unique_text_count (redundant - just len(unique_texts))
    - excel_col (redundant - can derive from col_letter)
    - text_count, num_count, empty_count, fill_rate (never used)

    Size impact: 49 KB -> 12 KB per profile (75% reduction)
    """
    filtered = {}
    for col_letter, col_data in column_profiles.items():
        filtered[col_letter] = {
            'col_letter': col_data.get('col_letter', col_letter),
            'type': col_data.get('type', ''),
            'unique_texts': col_data.get('unique_texts', [])
        }
    return filtered


def load_profile_registry(
    profile_dir: str | Path | None = None,
    expected_files: tuple[str, ...] = (),
    user_jwt_token: str = None,
) -> dict[str, dict]:
    """
    Scans PROFILE_DIR for *_profile.json files and returns a registry keyed
    by file_name, e.g. {"Secondary Vol 2024 2025": {"file_path": ..., "profile": {"sheets": {...}}}}.

    Handles both:
    - File-level profiles: FileName_profile.json with "sheets": {...} inside
    - Sheet-level profiles: FileName_SheetName_profile.json (consolidated under FileName)

    Optimization: Filters column profiles to keep only 3 essential fields
    (col_letter, type, unique_texts) for 75% size reduction.
    
    Args:
        profile_dir: Optional explicit profile directory path
        expected_files: Optional tuple of expected file paths
        user_jwt_token: Optional JWT token for user-specific month tracking
    """
    registry: dict[str, dict] = {}

    # Use user-specific API path if profile_dir not explicitly provided
    if profile_dir is None:
        paths = get_s3_paths(user_jwt_token)
        target_dir = paths.get('PROFILE_DIR', '')
        data_dir = paths.get('S3_DATA_PATH', '')  # Dynamic data path for Excel files
        if not target_dir:
            _logger.warning("PROFILE_DIR not found in API Gateway response.")
            return registry
    else:
        target_dir = str(profile_dir)
        # Also get data path from API when profile_dir is explicitly provided
        paths = get_s3_paths(user_jwt_token)
        data_dir = paths.get('S3_DATA_PATH', '')

    # Note: expected_files parameter is kept for backward compatibility but not used
    # We ALWAYS construct file paths dynamically from data_dir + filename

    if is_s3_uri(target_dir):
        try:
            # Build candidate file-level profile URIs
            file_level_candidates = [profile_artifact_uri(target_dir, path) for path in expected_files] if expected_files else []

            # Check which file-level profiles exist, and discover sheet-level profiles for missing ones
            profile_uris = []
            for candidate_uri in file_level_candidates:
                if s3_object_exists(candidate_uri):
                    profile_uris.append(candidate_uri)
                else:
                    # File-level profile missing — discover sheet-level profiles
                    file_stem = source_stem(candidate_uri).replace("_profile", "")
                    # List all profiles matching FileName_*_profile.json pattern
                    all_profiles = list_s3_uris(target_dir, suffixes=("_profile.json",))
                    sheet_profiles = [uri for uri in all_profiles if source_stem(uri).startswith(f"{file_stem}_")]
                    profile_uris.extend(sheet_profiles)

            # If no expected files, discover all profiles
            if not expected_files:
                profile_uris = sorted(list_s3_uris(target_dir, suffixes=("_profile.json",)))

            # First pass: Load file-level profiles and identify sheet-level profiles
            sheet_level_profiles = []

            for profile_uri in profile_uris:
                try:
                    data = read_json(profile_uri)
                    profile_stem = source_stem(profile_uri).replace("_profile", "")

                    # Check if this is a file-level profile (has "sheets" dict) or sheet-level
                    if "sheets" in data and isinstance(data.get("sheets"), dict) and data["sheets"]:
                        # File-level profile
                        file_name = data.get("file_name") or profile_stem
                        file_path_from_profile = data.get("file", "")

                        # Extract filename from profile path and construct dynamic path
                        from pathlib import Path as PathLib
                        filename_only = PathLib(file_path_from_profile).name if file_path_from_profile else f"{file_name}.xlsx"
                        dynamic_file_path = f"{data_dir.rstrip('/')}/{filename_only}" if data_dir else file_path_from_profile

                        # Filter column profiles to keep only 3 essential fields
                        sheets_data = data.get("sheets", {})
                        for sheet_name, sheet_data in sheets_data.items():
                            if "column_profiles" in sheet_data:
                                sheet_data["column_profiles"] = _filter_column_profiles(sheet_data["column_profiles"])

                        # ALWAYS use dynamic_file_path (never matched_expected which has hardcoded December 2025 paths)
                        registry[file_name] = {
                            "file_path": dynamic_file_path,  # ALWAYS use dynamic API Gateway path
                            "profile": {"sheets": sheets_data},
                            "file_hash": data.get("file_hash", ""),
                            "profile_uri": profile_uri,
                        }
                    else:
                        # Sheet-level profile - save for second pass
                        sheet_level_profiles.append((profile_uri, data, profile_stem))
                except Exception as exc:
                    _logger.warning("Failed to load profile %s: %s", profile_uri, exc)

            # Second pass: Consolidate sheet-level profiles under parent file
            for profile_uri, data, profile_stem in sheet_level_profiles:
                try:
                    # Extract file name and sheet name from stem
                    # Pattern: "FileName_SheetName" -> extract base file name
                    parts = profile_stem.rsplit("_", 1)
                    if len(parts) == 2:
                        file_name, sheet_name = parts
                    else:
                        # Fallback: treat entire stem as file name
                        file_name = profile_stem
                        sheet_name = data.get("sheet_name", "Sheet1")

                    # Find or create parent file entry
                    if file_name not in registry:
                        file_path_from_profile = data.get("file", "")

                        # Extract filename from profile path and construct dynamic path
                        from pathlib import Path as PathLib
                        filename_only = PathLib(file_path_from_profile).name if file_path_from_profile else f"{file_name}.xlsx"
                        dynamic_file_path = f"{data_dir.rstrip('/')}/{filename_only}" if data_dir else file_path_from_profile

                        # ALWAYS use dynamic_file_path (never matched_expected which has hardcoded December 2025 paths)
                        registry[file_name] = {
                            "file_path": dynamic_file_path or f"{file_name}.xlsx",  # ALWAYS use dynamic API Gateway path
                            "profile": {"sheets": {}},
                            "file_hash": data.get("file_hash", ""),
                            "profile_uri": profile_uri,  # Use first sheet profile URI
                        }

                    # Add sheet data to parent
                    # Note: total_rows and total_cols removed - no longer in profile.json
                    # Filter column profiles to keep only 3 essential fields
                    column_profiles = data.get("column_profiles", {})
                    if column_profiles:
                        column_profiles = _filter_column_profiles(column_profiles)

                    sheet_data = {
                        "column_profiles": column_profiles,
                        "columns": data.get("columns", []),
                    }
                    # Copy other fields that exist in the profile
                    for field in ["transition_rows", "sample_rows", "detected_header_row", "header_values", "merged_cells"]:
                        if field in data:
                            sheet_data[field] = data[field]

                    registry[file_name]["profile"]["sheets"][sheet_name] = sheet_data

                except Exception as exc:
                    _logger.warning("Failed to consolidate sheet profile %s: %s", profile_uri, exc)

        except Exception as exc:
            _logger.warning("Profile directory not found: %s (%s)", target_dir, exc)
            return registry
    else:
        # Local filesystem not supported - only S3 paths are used
        _logger.error("Local filesystem profile loading not supported. Only S3 paths (s3://) are accepted. Got: %s", target_dir)
        return registry

    return registry


def prioritize_data_sources(
    catalog_rows: list[dict[str, str]],
    analysis_type: str = "",
) -> list[dict[str, str]]:
    """Sort catalog rows by priority: Raw data first, Aggregated second."""
    raw_sources = [row for row in catalog_rows if row.get("granularity_type", "Raw") == "Raw"]
    agg_sources = [row for row in catalog_rows if row.get("granularity_type", "Raw") == "Aggregated"]
    return raw_sources + agg_sources


def extract_file_linkages(catalog_rows: list[dict[str, str]]) -> dict[str, list[str]]:
    """
    Extract cross-file linkage information from the business_facts field.

    Returns a dictionary mapping file names to lists of related file names.
    """
    linkage_map: dict[str, list[str]] = {}
    patterns = [
        r"Link with excel ([^\s,]+)",
        r"link with ([^\s,]+)",
        r"Source file.*?([A-Za-z0-9_\s]+\.xlsx)",
        r"Can be joined with ([^\s,]+)",
    ]
    for row in catalog_rows:
        file_name = row.get("file_name", "")
        business_facts = row.get("business_facts", "")
        if not (file_name and business_facts):
            continue
        linked_files: list[str] = []
        for pattern in patterns:
            for match in re.findall(pattern, business_facts, re.IGNORECASE):
                clean_match = match.strip().replace("excel ", "")
                if clean_match and clean_match not in linked_files:
                    linked_files.append(clean_match)
        if linked_files:
            linkage_map[file_name] = linked_files
    return linkage_map


# ─────────────────────────────────────────────────────────────────────────────
# CSV-based catalog — reads raw_intents_enhanced.csv as the routing source
# ─────────────────────────────────────────────────────────────────────────────

def load_enhanced_csv_catalog(user_jwt_token: str = None) -> list[dict[str, str]]:
    """
    Load raw_intents_enhanced.csv and return a list of catalog dicts with the
    same shape as the old MBR catalog plus extra fields for richer LLM context.

    CSV columns → catalog keys:
        sr_no               → sr_no
        File_ID             → file_id
        file                → file_name
        sheet               → tab_name
        expressed_in        → data_type
        units               → units
        description         → purpose
        business_facts      → sheet_information / business_facts
        granularity_type    → granularity_type
        actual_columns      → columns_list
        # unique_values_summary → unique_values_summary   (new)  [disabled]
        # unique_values       → unique_values             (new)  [disabled]
        
    Args:
        user_jwt_token: Optional JWT token for user-specific month tracking
    """
    # Fetch paths from user-specific API
    paths = get_s3_paths(user_jwt_token)
    csv_path = paths.get('ENHANCED_CSV_PATH')

    if not csv_path:
        _logger.warning("ENHANCED_CSV_PATH not found in API Gateway response.")
        return []

    rows: list[dict[str, str]] = []
    csv_text = read_text(csv_path, encoding="utf-8-sig")
    with StringIO(csv_text, newline="") as fh:
        reader = csv.DictReader(fh)
        for raw in reader:
            file_name = _clean_text(raw.get("file", ""))
            tab_name = _clean_text(raw.get("sheet", ""))
            if not (file_name and tab_name):
                continue

            # Preserve commonly useful identifiers if present
            sr_no_val = _clean_text(raw.get("sr_no", ""))
            file_id_val = _clean_text(raw.get("File_ID", ""))

            row = {
                "file_name":             file_name,
                "tab_name":              tab_name,
                "data_type":             _clean_text(raw.get("expressed_in", "")),
                "units":                 _clean_text(raw.get("units", "")),
                "purpose":               _clean_text(raw.get("description", "")),
                "sheet_information":     _clean_text(raw.get("business_facts", "")),
                "business_facts":        _clean_text(raw.get("business_facts", "")),
                "granularity_type":      _clean_text(raw.get("granularity_type", "Raw")),
                "columns_list":          _clean_text(raw.get("actual_columns", "")),
                # "unique_values_summary": _clean_text(raw.get("unique_values_summary", "")),  # [disabled]
                # "unique_values":         _clean_text(raw.get("unique_values", "")),  # [disabled]
                "unique_values_summary": "",
                "unique_values":         "",
            }

            if sr_no_val:
                # keep numeric-looking sr_no as-is (string type retained for safety)
                row["sr_no"] = sr_no_val
            if file_id_val:
                row["file_id"] = file_id_val

            rows.append(row)

    return rows


def compressed_csv_catalog(include_business_facts: bool = True, user_jwt_token: str = None) -> list[dict[str, str]]:
    """
    Return catalog rows from raw_intents_enhanced.csv for use in mapping_node().
    Includes richer fields (actual_columns, unique_values_summary) compared to
    the old MBR-based catalog.
    
    Args:
        include_business_facts: Whether to include business facts in the catalog
        user_jwt_token: Optional JWT token for user-specific month tracking
    """
    all_rows = load_enhanced_csv_catalog(user_jwt_token)
    result: list[dict[str, str]] = []
    for row in all_rows:
        entry: dict[str, str] = {
            "file_name":             row["file_name"],
            "tab_name":              row["tab_name"],
            "data_type":             row["data_type"],
            "units":                 row["units"],
            "purpose":               row["purpose"],
            "granularity_type":      row["granularity_type"],
            "columns_list":          row["columns_list"],
            # "unique_values_summary": row["unique_values_summary"],  # [disabled]
            "unique_values_summary": "",
        }
        # propagate optional identifiers when present
        if row.get("sr_no"):
            entry["sr_no"] = row["sr_no"]
        if row.get("file_id"):
            entry["file_id"] = row["file_id"]
        if include_business_facts:
            entry["sheet_information"] = row["sheet_information"]
        result.append(entry)
    return result
