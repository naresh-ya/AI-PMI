"""Query normalization and glossary-term matching helpers."""
from __future__ import annotations

import re

from helpers.file_registry import load_glossary_index
from models.state import GlossaryMatch


def normalize_query_terms(question: str, user_jwt_token: str = None) -> tuple[str, list[GlossaryMatch]]:
    """
    Replaces abbreviations with their full forms using a robust and safe tokenizer.
    Fixes:
    - unicode whitespace
    - NBSP
    - punctuation boundaries
    - IMS and similar terms failing to convert
    
    Args:
        question: The user's question to normalize
        user_jwt_token: JWT token for user-specific month (passed to glossary loader)
    """
    glossary = load_glossary_index(user_jwt_token)
    normalized = question
    matches: list[GlossaryMatch] = []

    # Sort longest first to avoid short conflicts (PF vs Premium Filter)
    ordered = sorted(glossary.values(), key=lambda x: len(x["term"]), reverse=True)

    for entry in ordered:
        term = entry["term"]
        canonical = entry["canonical"]

        # Avoid replacing terms whose full form equals the abbreviation
        if term.casefold() == canonical.casefold():
            continue

        safe_term = re.escape(term)

        # Unicode-safe word boundaries
        pattern = re.compile(rf"\b{safe_term}\b", re.IGNORECASE)

        normalized, count = pattern.subn(canonical, normalized)

        if count > 0:
            matches.append({
                "matched_term": term,
                "canonical_term": canonical,
                "occurrences": count,
            })

    return normalized, matches
