"""Shared code extraction and validation utilities."""

import re


def extract_code(text: str) -> str:
    """Robustly extract Python code from LLM response."""
    match = re.search(r'```python\s*\n(.*?)```', text, re.DOTALL)
    if match:
        return match.group(1).strip()
    match = re.search(r'```\s*\n(.*?)```', text, re.DOTALL)
    if match:
        return match.group(1).strip()
    match = re.search(r'^(import |from |#)', text, re.MULTILINE)
    if match:
        return text[match.start():].strip()
    return text.strip()


def is_code_complete(code: str) -> bool:
    """Check if code is syntactically complete."""
    if not code or not code.strip():
        return False
    opens = code.count('(') + code.count('[') + code.count('{')
    closes = code.count(')') + code.count(']') + code.count('}')
    if opens != closes:
        return False
    lines = code.strip().split('\n')
    last_line = lines[-1].strip() if lines else ""
    if last_line.endswith((',', '(', '[', '{', '\\', '+')):
        return False
    try:
        compile(code, "<check>", "exec")
        return True
    except SyntaxError:
        return False