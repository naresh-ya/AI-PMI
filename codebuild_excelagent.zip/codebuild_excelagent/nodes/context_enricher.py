"""Context Enrichment Node - Merges previous conversation context into new questions.

Flow:
1. Check if previous Q+A exists in memory
2. If yes: Check if new question relates to previous context (LLM call 1 - Haiku)
3. If related: Merge context into new question (LLM call 2 - Sonnet)
4. Return enriched query or original query

This node runs at the START of the pipeline (right after parse_messages).
"""

from __future__ import annotations

import json
import logging
from typing import Dict, Any

from langchain_core.messages import HumanMessage, SystemMessage

from claude_setup.llm import get_fast_model
from helpers.memory_manager import get_memory_manager
from prompts.system_prompts import (
    relatedness_check_system,
    context_merger_system
)
from prompts.user_prompts import(
    relatedness_check_user,
    context_merger_user
)
from core.settings import settings

logger = logging.getLogger(__name__)


async def context_enrichment_node(state: Dict[str, Any]):
    """Enrich user query with previous conversation context if relevant.

    Steps:
    1. Retrieve last Q+A from memory
    2. If no previous context → return (no changes)
    3. Check if new question relates to previous Q+A (LLM call 1)
    4. If unrelated → return (no changes)
    5. If related → Merge contexts (LLM call 2) → replace query

    Args:
        state: AGUIExcelState with 'query' and 'memory_session_id'

    Yields:
        Updated state with enriched 'query' field (if context merged)

    WITH STREAMING: Async generator that uses astream() for all LLM calls.
    """
    try:
        session_id = state.get("memory_session_id")
        current_query = state.get("query", "")
        original_query = state.get("original_query", current_query)

        if not session_id or not current_query:
            logger.warning("Missing session_id or query - skipping context enrichment")
            yield {}
            return

        # Step 1: Retrieve previous Q+A
        memory_manager = get_memory_manager(
            region=settings.aws_region,
            memory_id="memoryMBRshort-T8GbYmGACP",
        )

        prev_qa = memory_manager.get_previous_qa(session_id)

        # Step 2: No previous context
        if not prev_qa:
            yield {
                "context_enrichment_status": "No previous conversation - using original query"
            }
            return

        # Step 3: Check relatedness (LLM Call 1 - Haiku with streaming)
        is_related, confidence, reasoning = await _check_relatedness(
            prev_qa["question"],
            prev_qa["answer"],
            current_query,
        )

        # Step 4: Unrelated - don't enrich
        if not is_related or confidence < 70:
            yield {
                "context_enrichment_status": f"Questions unrelated (confidence: {confidence}%) - no enrichment applied",
                "relatedness_check": {
                    "is_related": is_related,
                    "confidence": confidence,
                    "reasoning": reasoning,
                }
            }
            return

        # Step 5: Related - merge context (LLM Call 2 - Sonnet with streaming)
        enriched_query = await _merge_contexts(
            prev_qa["question"],
            prev_qa["answer"],
            current_query,
        )

        # Yield updated state
        yield {
            "query": enriched_query,  # Replace query for pipeline
            "question": enriched_query,  # Also update for node2 compatibility
            "enriched_query": enriched_query,  # Keep for debugging
            "original_query": current_query,  # Preserve original
            "previous_qa": prev_qa,  # Keep for debugging
            "context_enrichment_applied": True,  # Flag for tracking
            "context_enrichment_status": f"Context merged (confidence: {confidence}%)",
            "relatedness_check": {
                "is_related": is_related,
                "confidence": confidence,
                "reasoning": reasoning,
            }
        }

    except Exception as e:
        logger.error(f"[CONTEXT] Context enrichment failed: {e}")
        logger.error(f"[CONTEXT] Error type: {type(e).__name__}")
        import traceback
        logger.error(f"[CONTEXT] Traceback: {traceback.format_exc()}")
        # Graceful degradation - yield empty dict (no changes)
        yield {}


async def _check_relatedness(
    prev_question: str,
    prev_answer: str,
    new_question: str,
) -> tuple[bool, int, str]:
    """Check if new question relates to previous Q+A using LLM.

    Uses: Haiku (fast & cheap model)

    Args:
        prev_question: Previous user question
        prev_answer: Previous assistant answer
        new_question: New user question

    Returns:
        (is_related, confidence_score, reasoning)

    Example:
        is_related, conf, reason = await _check_relatedness(
            "What's India revenue?",
            "India revenue is $10M",
            "What about profit?"
        )
        # Returns: (True, 95, "Same region, different metric")
    """
    try:
        # Use fast model (Haiku) for quick check
        model = get_fast_model()

        system_prompt = relatedness_check_system()
        user_prompt = relatedness_check_user(prev_question, prev_answer, new_question)

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ]

        # Stream tokens (for JSON, can't use progressively but shows work happening)
        # Note: astream() yields plain strings, not AIMessage objects
        full_response = []
        async for token in model.astream(messages):
            full_response.append(token)

        response_text = "".join(full_response)

        # Parse response (pretend it's an object with .content attribute)
        class Response:
            def __init__(self, content):
                self.content = content

        response = Response(response_text)

        # Parse JSON response (handle markdown code blocks)
        content = response.content.strip()

        # Remove markdown code blocks if present
        if content.startswith("```json"):
            content = content.replace("```json", "").replace("```", "").strip()
        elif content.startswith("```"):
            content = content.replace("```", "").strip()

        try:
            result = json.loads(content)
            is_related = result.get("is_related", False)
            confidence = int(result.get("confidence", 0))
            reasoning = result.get("reasoning", "No reasoning provided")
        except json.JSONDecodeError:
            logger.warning(f"[CONTEXT] Failed to parse LLM response: {content}")
            # Try to extract from text
            content_lower = content.lower()
            is_related = "true" in content_lower or "related" in content_lower
            confidence = 50  # Default low confidence
            reasoning = "Could not parse structured response"

        return is_related, confidence, reasoning

    except Exception as e:
        logger.error(f"[CONTEXT] Relatedness check failed: {e}")
        # Default to unrelated on error
        return False, 0, f"Error: {str(e)}"


async def _merge_contexts(
    prev_question: str,
    prev_answer: str,
    new_question: str,
) -> str:
    """Merge previous context into new question using LLM.

    Uses: Sonnet (smart & accurate model)

    Args:
        prev_question: Previous user question
        prev_answer: Previous assistant answer
        new_question: New user question

    Returns:
        Enriched question string

    Example:
        enriched = await _merge_contexts(
            "What's India revenue in December?",
            "India revenue in December is $10M",
            "What about profit?"
        )
        # Returns: "What is the profit for India in December?"
    """
    try:
        # Use fast model (Haiku) for context merging
        model = get_fast_model()

        system_prompt = context_merger_system()
        user_prompt = context_merger_user(prev_question, prev_answer, new_question)

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ]

        # Stream tokens (text generation - can show progressively!)
        # Note: astream() yields plain strings, not AIMessage objects
        full_response = []
        async for token in model.astream(messages):
            full_response.append(token)

        enriched_query = "".join(full_response).strip()

        # Skip the old invoke() path - we have streaming result
        class Response:
            def __init__(self, content):
                self.content = content

        response = Response(enriched_query)

        # LLM returns the enriched question directly
        enriched_query = response.content.strip()

        # Sanity check - make sure we got a reasonable response
        if not enriched_query or len(enriched_query) < 5:
            logger.warning(
                f"[CONTEXT] LLM returned invalid enriched query: '{enriched_query}' "
                f"- using original"
            )
            return new_question

        return enriched_query

    except Exception as e:
        logger.error(f"[CONTEXT] Context merge failed: {e}")
        # Fallback to original question
        return new_question
