"""Narrative explainer node — converts raw code output into business narrative."""

from __future__ import annotations

from claude_setup.llm import get_model
from core.structured_logging import get_logger
from helpers.file_registry import load_glossary_index
from models.state import PipelineState
from prompts.system_prompts import narrative_explainer_system
from prompts.user_prompts import build_narrative_explainer_prompt

log = get_logger(__name__)


def format_glossary_for_prompt(glossary: dict) -> str:
    """
    Format glossary dictionary into readable text for LLM consumption.

    Args:
        glossary: Dictionary mapping lowercase terms to {term, canonical} dicts

    Returns:
        Formatted string with glossary terms, one per line
    """
    if not glossary:
        return ""

    # Extract unique term -> canonical mappings
    items = []
    seen = set()
    for entry in glossary.values():
        term = entry.get("term", "")
        canonical = entry.get("canonical", "")
        if term and canonical and canonical not in seen:
            items.append(f"- {term}: {canonical}")
            seen.add(canonical)

    # Sort alphabetically for consistency
    return "\n".join(sorted(items))


async def narrative_explainer_node(state: PipelineState):
    """
    LangGraph node that generates a business narrative explanation
    from the raw code execution output.

    Takes the technical output and user's original query, then produces
    an executive-friendly answer that directly addresses the question.

    WITH STREAMING: Collects tokens and yields final result with messages.
    ASYNC GENERATOR: Single yield with combined state + messages.
    """
    from langchain_core.messages import AIMessage

    exec_result = state.get("execution_result", {})

    if not exec_result.get("success"):
        yield {"narrative_answer": None}
        return

    query = state.get("query", "")
    raw_output = exec_result.get("output", "")

    if not raw_output or not query:
        yield {"narrative_answer": None}
        return

    # Load glossary for domain context (no cache, fresh data)
    try:
        user_jwt_token = state.get('user_jwt_token')
        glossary = load_glossary_index(user_jwt_token) if user_jwt_token else {}
        glossary_text = format_glossary_for_prompt(glossary) if glossary else ""
        log.info("Loaded glossary with %d terms for narrative context", len(glossary))
    except Exception as e:
        log.warning("Failed to load glossary for narrative explainer: %s", e)
        glossary_text = ""

    system_prompt = narrative_explainer_system(glossary_text)
    user_prompt = build_narrative_explainer_prompt(query, raw_output)

    try:
        llm = get_model()
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        # Collect tokens for streaming to frontend
        streaming_tokens = []
        async for token in llm.astream(messages):
            streaming_tokens.append(token)

        narrative = "".join(streaming_tokens).strip()

        # Add confidence warning if mapping confidence < 80
        mapping_result = state.get("mapping_result", {})
        confidence = mapping_result.get("confidence", 100)

        if confidence < 80:
            warning = f"""WARNING - Confidence Level: {confidence}%

This analysis has moderate confidence. The sheet selection was uncertain. Please review the results to ensure they address your question correctly.

---

"""
            narrative = warning + narrative

        # Yield single result with both state AND streaming message
        result = {
            "narrative_answer": narrative,
            "final_answer": narrative,
        }

        # Add streaming message for frontend display
        if streaming_tokens:
            result["messages"] = [AIMessage(content=f"[Narrative Explanation]\n{narrative}")]

        yield result

    except Exception as e:
        log.error("Failed to generate narrative: %s", e)
        yield {"narrative_answer": None}
