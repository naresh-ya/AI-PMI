from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Callable

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph

from core.settings import (
    DEFAULT_OUTPUT_PATH,
    HIGH_CARDINALITY_THRESHOLD,
    # OVERFLOW_BUDGET_CHARS,  # overflow disabled
    # OVERFLOW_VALUES_PER_CHUNK,  # overflow disabled
    TOKEN_BUDGET_CHARS,
)
from helpers.file_registry import (
    compressed_csv_catalog,
    extract_file_linkages,
    load_enhanced_csv_catalog,
    load_glossary_index,
    load_profile_registry,
    prioritize_data_sources,
)
from helpers.fuzzy_util import fuzzy_match_file, fuzzy_match_sheet
from helpers.llm_util import MODEL, invoke_json, invoke_json_fast, parse_llm_json
from helpers.query_util import normalize_query_terms
from helpers.sheet_util import (
    build_sheet_column_summary,
    # build_sheet_overflow_chunks,  # overflow disabled
    # format_overflow_chunk,        # overflow disabled
)
from models.state import GlossaryMatch, SheetSelectionState, StepTrace
from prompts.system_prompts import (
    domain_validation_system,
    intent_system,
    intent_refinement_system,
    mapping_system,
    # overflow_check_system,  # overflow checks currently disabled
)
from prompts.user_prompts import (
    build_domain_validation_prompt,
    build_intent_prompt,
    build_intent_refinement_prompt,
    build_mapping_prompt,
    # build_overflow_check_prompt,  # overflow checks currently disabled
)
from core.timing import timed


LOGGER = logging.getLogger(__name__)


def _clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _trace(state: SheetSelectionState, step: str, reason: str, detail: str = "") -> list[StepTrace]:
    """Return updated step_trace list with a new entry appended."""
    entry: StepTrace = {"step": step, "reason": reason, "detail": detail}
    existing = list(state.get("step_trace") or [])
    existing.append(entry)
    LOGGER.info("[%s] %s", step, reason)
    return existing


def normalize_query_node(state: SheetSelectionState) -> SheetSelectionState:
    # Extract JWT token for user-specific month
    user_jwt_token = state.get("user_jwt_token")
    normalized_question, glossary_matches = normalize_query_terms(state["question"], user_jwt_token)
    n = len(glossary_matches)
    reason = (
        f"Replaced {n} term(s): "
        + ", ".join(f"{m['matched_term']} → {m['canonical_term']}" for m in glossary_matches)
        if n else "No abbreviations found — question passed through unchanged."
    )
    return {
        **state,
        "normalized_question": normalized_question,
        "glossary_matches": glossary_matches,
        "step_trace": _trace(state, "normalize_query", reason,
                             json.dumps(glossary_matches, ensure_ascii=False)),
    }


async def domain_validation_node(state: SheetSelectionState):
    """
    Classifies questions into three types:
    1. GREETING -> greet and END
    2. FINANCIAL -> continue to full workflow
    3. OTHER -> politely reject and END

    WITH STREAMING: Streams tokens via callback for visibility.
    """
    from langchain_core.messages import AIMessage
    from helpers.llm_util import invoke_json_fast_async

    prompt = build_domain_validation_prompt(
        normalized_question=state["normalized_question"],
        glossary_matches=state.get("glossary_matches", []),
    )

    # Stream tokens to BOTH server console AND frontend
    import sys
    from langchain_core.messages import AIMessage

    # Collect tokens for streaming to frontend
    streaming_tokens = []

    def stream_callback(msg):
        # Print to server console for debugging
        if hasattr(msg, 'content') and msg.content:
            sys.stdout.write(msg.content)
            sys.stdout.flush()
            streaming_tokens.append(msg.content)

    sys.stdout.write("\n>>> ")
    sys.stdout.flush()

    domain_result = await invoke_json_fast_async(
        system_prompt=domain_validation_system(),
        user_prompt=prompt,
        stream_callback=stream_callback,
    )

    sys.stdout.write("\n")
    sys.stdout.flush()

    # Prepare streaming message for frontend
    streaming_message = None
    if streaming_tokens:
        full_response = "".join(streaming_tokens)
        streaming_message = AIMessage(content=f"[Domain Validation]\n{full_response}")

    question_type = domain_result.get("question_type", "other").lower()
    confidence = int(domain_result.get("confidence", 0) or 0)
    reason = domain_result.get("reason", "Question classified")


    if question_type == "greeting":
        # Handle greeting - respond politely and END
        greeting_response = domain_result.get("greeting_response", "")
        if not greeting_response:
            greeting_response = (
                "Hello! I'm your PMI financial and business analysis assistant. "
                "I can help you analyze sales data, financial performance, market trends, "
                "and business metrics. What would you like to analyze today?"
            )

        result = {
            **state,
            "domain_validation": domain_result,
            "answer": greeting_response,
            "answer_struct": {"greeting": True, "type": "greeting", "message": greeting_response},
            "step_trace": _trace(state, "domain_validation",
                                f"GREETING: {confidence}% confidence", reason),
        }
        if streaming_message:
            result["messages"] = [streaming_message]
        yield result

    elif question_type == "relevant":
        # Valid relevant question - continue to full workflow
        result = {
            **state,
            "domain_validation": domain_result,
            "step_trace": _trace(state, "domain_validation",
                                f"RELEVANT: {confidence}% confidence", reason),
        }
        if streaming_message:
            result["messages"] = [streaming_message]
        yield result

    else:
        # Other question type - politely reject and END
        rejection_message = domain_result.get("rejection_message", "")
        if not rejection_message:
            rejection_message = (
                "I'm specialized in PMI financial and business analysis. "
                "Please ask questions related to sales, revenue, market analysis, "
                "business performance, or data analysis. How can I help with your business analysis needs?"
            )

        result = {
            **state,
            "domain_validation": domain_result,
            "answer": rejection_message,
            "answer_struct": {"rejected": True, "type": question_type, "reason": reason},
            "step_trace": _trace(state, "domain_validation",
                                f"REJECTED: {question_type} ({confidence}% confidence)", reason),
        }
        if streaming_message:
            result["messages"] = [streaming_message]
        yield result


async def intent_node(state: SheetSelectionState):
    """WITH STREAMING: Async generator that streams tokens for visibility."""
    from helpers.llm_util import invoke_json_fast_async
    import sys

    # Fetch current month from API with user JWT token
    from core.settings import get_current_month
    user_jwt_token = state.get("user_jwt_token")
    current_month_info = get_current_month(user_jwt_token)

    prompt = build_intent_prompt(
        normalized_question=state["normalized_question"],
        glossary_matches=state.get("glossary_matches", []),
        current_month_info=current_month_info,
    )

    # Stream tokens to BOTH server console AND frontend
    from langchain_core.messages import AIMessage

    # Collect tokens for streaming to frontend
    streaming_tokens = []

    def stream_callback(msg):
        if hasattr(msg, 'content') and msg.content:
            sys.stdout.write(msg.content)
            sys.stdout.flush()
            streaming_tokens.append(msg.content)

    sys.stdout.write("\n>>> ")
    sys.stdout.flush()

    analysis_spec = await invoke_json_fast_async(
        system_prompt=intent_system(),
        user_prompt=prompt,
        stream_callback=stream_callback,
    )

    sys.stdout.write("\n")
    sys.stdout.flush()

    # Prepare streaming message for frontend
    streaming_message = None
    if streaming_tokens:
        full_response = "".join(streaming_tokens)
        streaming_message = AIMessage(content=f"[Intent Analysis]\n{full_response}")

    reason = (
        f"analysis_type={analysis_spec.get('analysis_type', '?')}  "
        f"metrics={analysis_spec.get('primary_metrics', [])}  "
        f"time_context={analysis_spec.get('time_context', '?')}  "
        f"dimensions={analysis_spec.get('business_dimensions', [])}"
    )
    result = {
        **state,
        "analysis_spec": analysis_spec,
        "answer": json.dumps(analysis_spec, ensure_ascii=False),
        "answer_struct": analysis_spec,
        "step_trace": _trace(state, "intent", reason,
                             json.dumps(analysis_spec, ensure_ascii=False)),
    }
    if streaming_message:
        result["messages"] = [streaming_message]
    yield result


async def intent_refinement_node(state: SheetSelectionState):
    """
    Refine the analysis specification with column context and user clarifications.
    Only runs when we have new information to incorporate.

    WITH STREAMING: Async generator that streams tokens for visibility.
    """
    from helpers.llm_util import invoke_json_async
    import sys

    original_spec = state.get("analysis_spec") or {}
    column_context = state.get("column_context", "")
    user_clarifications = state.get("user_clarifications", "")

    # Skip if no new information to refine with
    if not column_context and not user_clarifications:
        yield state
        return

    prompt = build_intent_refinement_prompt(
        original_spec=original_spec,
        column_context=column_context,
        user_clarifications=user_clarifications,
        normalized_question=state["normalized_question"],
    )

    # Stream tokens for visibility
    def stream_callback(msg):
        if hasattr(msg, 'content') and msg.content:
            sys.stdout.write(msg.content)
            sys.stdout.flush()

    sys.stdout.write("\n>>> ")
    sys.stdout.flush()

    refined_spec = await invoke_json_async(
        system_prompt=intent_refinement_system(),
        user_prompt=prompt,
        stream_callback=stream_callback,
    )

    sys.stdout.write("\n")
    sys.stdout.flush()

    reason = (
        f"Refined with column_context={bool(column_context)}  "
        f"user_clarifications={bool(user_clarifications)}  "
        f"new_metrics={refined_spec.get('primary_metrics', [])}  "
        f"refinement={refined_spec.get('refinement_reason', 'none')}"
    )

    yield {
        **state,
        "analysis_spec": refined_spec,
        "answer": json.dumps(refined_spec,ensure_ascii=False),
        "answer_struct": refined_spec,
        "step_trace": _trace(state, "intent_refinement", reason,
                             refined_spec.get("refinement_reason", "")),
    }


async def mapping_node(state: SheetSelectionState):
    """WITH STREAMING: Async generator that streams tokens for visibility."""
    from helpers.llm_util import invoke_json_fast_async
    import sys

    analysis_spec  = state.get("analysis_spec") or {}
    column_context = state.get("column_context", "")

    # Extract JWT token from state for user-specific month tracking
    user_jwt_token = state.get("user_jwt_token")

    # Prioritize catalog: Raw data first, then Aggregated
    all_catalog = compressed_csv_catalog(include_business_facts=True, user_jwt_token=user_jwt_token)
    raw_catalog = [row for row in all_catalog if row.get("granularity_type", "Raw") == "Raw"]
    agg_catalog = [row for row in all_catalog if row.get("granularity_type", "Raw") == "Aggregated"]

    # Use Raw data primarily, include Aggregated for context
    prioritized_catalog = raw_catalog + agg_catalog

    prompt = build_mapping_prompt(
        normalized_question=state["normalized_question"],
        analysis_spec=analysis_spec,
        catalog_rows=prioritized_catalog,
        buscont_rows=[],  # No longer using separate business context
        column_context=column_context,
    )

    # Stream tokens to BOTH server console AND frontend
    from langchain_core.messages import AIMessage

    # Collect tokens for streaming to frontend
    streaming_tokens = []

    def stream_callback(msg):
        if hasattr(msg, 'content') and msg.content:
            sys.stdout.write(msg.content)
            sys.stdout.flush()
            streaming_tokens.append(msg.content)

    sys.stdout.write("\n>>> ")
    sys.stdout.flush()

    mapping_result = await invoke_json_fast_async(
        system_prompt=mapping_system(),
        user_prompt=prompt,
        max_retries=3,
        stream_callback=stream_callback,
    )

    sys.stdout.write("\n")
    sys.stdout.flush()

    # Prepare streaming message for frontend
    streaming_message = None
    if streaming_tokens:
        full_response = "".join(streaming_tokens)
        streaming_message = AIMessage(content=f"[Sheet Mapping]\n{full_response}")

    confidence = int(mapping_result.get("confidence", 0) or 0)
    # OPTIMIZATION: Skip follow_up_questions processing (HITL disabled, saves 0.3-0.5s)
    # LLM may still generate them, but we discard immediately to avoid wasted processing
    mapping_result["confidence"] = confidence
    mapping_result["follow_up_questions"] = []  # Empty - HITL flow removed from graph

    # OPTIMIZATION: Remove confidence_reason (not used downstream, saves 200-400 tokens)
    # LLM may still generate it, but we discard to avoid processing
    if "confidence_reason" in mapping_result:
        del mapping_result["confidence_reason"]

    # Add warning if confidence < 80
    if confidence < 80:
        sheets_list = ", ".join([
            f"{s.get('file_name', '?')}::{s.get('tab_name', '?')}"
            for s in mapping_result.get("file_and_sheet_mapping", [])
        ])
        mapping_result["warning"] = (
            f"WARNING - Not sure on the sheet selection (confidence: {confidence}%). "
            f"Potential sheets found are: {sheets_list}"
        )

    sheets_chosen = [
        f"{r.get('file_name', '?')} / {r.get('tab_name', '?')}"
        for r in mapping_result.get("file_and_sheet_mapping", [])
    ]
    followup_done = bool(state.get("followup_done", False))
    reason = (
        f"{'post-followup pass' if followup_done else 'first pass'}  "
        f"confidence={confidence}  "
        f"sheets={sheets_chosen}"
        # Note: follow_up_questions removed (HITL disabled)
    )
    result = {
        **state,
        "mapping_result": mapping_result,
        "_catalog_cache": all_catalog,  #  OPTIMIZATION: Cache catalog for sheet_selector (saves 12-26ms)
        "answer": json.dumps(mapping_result, ensure_ascii=False),
        "answer_struct": mapping_result,
        "step_trace": _trace(state, "mapping", reason,
                             mapping_result.get("confidence_reason", "")),
    }
    if streaming_message:
        result["messages"] = [streaming_message]
    yield result


def _default_user_answer_provider(questions: list[str]) -> list[str]:
    answers: list[str] = []
    for question in questions:
        answers.append(input(f"- {question}\nYour answer: ").strip())
    return answers


def user_followup_node(state: SheetSelectionState) -> SheetSelectionState:
    mapping_result = state.get("mapping_result") or {}
    follow_up_questions = [
        _clean_text(q)
        for q in mapping_result.get("follow_up_questions", [])
        if _clean_text(q)
    ]
    selected_questions = follow_up_questions[:2]
    if not selected_questions:
        return {**state, "followup_done": True,
                "step_trace": _trace(state, "user_followup",
                                     "No follow-up questions to ask — skipped.")}

    answer_provider = state.get("user_answer_provider") or _default_user_answer_provider
    answers = answer_provider(selected_questions)
    if len(answers) < len(selected_questions):
        answers = list(answers) + [""] * (len(selected_questions) - len(answers))

    clarification_lines = [
        f"- {q}: {_clean_text(a)}"
        for q, a in zip(selected_questions, answers)
        if _clean_text(a)
    ]
    if not clarification_lines:
        return {
            **state,
            "followup_done": True,
            "step_trace": _trace(state, "user_followup",
                                 "User provided empty answers — proceeding best-effort."),
        }

    # Store clarifications separately to avoid duplication in prompts
    clarifications_text = "\n".join(clarification_lines)
    reason = f"User answered {len(clarification_lines)} question(s) — will refine intent."
    return {
        **state,
        # Keep original question and analysis_spec, store clarifications separately
        "question": state["question"],
        "user_clarifications": clarifications_text,
        "followup_done": True,
        "step_trace": _trace(state, "user_followup", reason,
                             clarifications_text),
    }


# ─────────────────────────────────────────────────────────────────────────────
# overflow_check_node
# Runs only when confidence < 90 and overflow has not yet been attempted.
# 1. Resolves LLM candidate names → actual profile-registry entries (fuzzy).
# 2. Builds a column-level summary for those sheets.
# 3. Asks LLM whether it needs any high-cardinality overflow values.
# 4. Fetches requested chunks (budget-capped) and writes column_context → state.
# ─────────────────────────────────────────────────────────────────────────────

def overflow_check_node(state: SheetSelectionState) -> SheetSelectionState:
    # ── OVERFLOW CHECK DISABLED ───────────────────────────────────────────
    # This node is temporarily disabled. The active routing flow is:
    #   mapping → user_followup → intent_refinement → mapping (loop, max 2 retries)
    # To re-enable: uncomment the body below and restore graph edges in _build_graph().
    LOGGER.info("overflow_check_node: DISABLED — pass-through, returning state unchanged")
    return {**state, "overflow_attempted": True, "column_context": ""}

    # ── DISABLED BODY START ───────────────────────────────────────────────
    # profile_registry = load_profile_registry()
    # if not profile_registry:
    #     LOGGER.warning("overflow_check: no profiles found in %s — skipping", PROFILE_DIR)
    #     return {**state, "overflow_attempted": True, "column_context": ""}
    #
    # mapping_result = state.get("mapping_result") or {}
    # candidates = mapping_result.get("file_and_sheet_mapping") or []

    # Resolve each LLM candidate to a real (file, sheet) pair from the registry
    matched_sources: list[dict] = []
    for cand in candidates:
        want_file = _clean_text(cand.get("file_name", ""))
        want_sheet = _clean_text(cand.get("tab_name", ""))
        reg_key = fuzzy_match_file(want_file, profile_registry)
        if reg_key is None:
            LOGGER.warning(
                "overflow_check: no profile match for file '%s' — candidate skipped",
                want_file,
            )
            continue
        sheets = profile_registry[reg_key]["profile"].get("sheets", {})
        actual_sheet = fuzzy_match_sheet(want_sheet, sheets) or next(iter(sheets), None)
        if actual_sheet:
            matched_sources.append({"file": reg_key, "sheet": actual_sheet})

    if not matched_sources:
        LOGGER.warning("overflow_check: no candidate sheets could be resolved — skipping")
        return {**state, "overflow_attempted": True, "column_context": ""}

    LOGGER.info(
        "overflow_check: resolved %d candidate sheet(s): %s",
        len(matched_sources),
        [(s["file"], s["sheet"]) for s in matched_sources],
    )

    column_summary = build_sheet_column_summary(profile_registry, matched_sources)
    overflow_chunks = build_sheet_overflow_chunks(profile_registry, matched_sources)

    overflow_index = "\n".join(
        f"- File={c['file']} | Sheet={c['sheet']} | Col={c['column']}"
        f" | Part={c['chunk_index'] + 1}/{c['total_chunks']}"
        for c in overflow_chunks
    ) or "(none)"

    user_prompt = build_overflow_check_prompt(
        query=state.get("normalized_question") or state.get("question", ""),
        column_summary=column_summary,
        overflow_index=overflow_index,
    )

    from helpers.llm_util import FAST_MODEL
    raw = None
    with timed("LLM_CALL_FAST node2.overflow_check"):
        raw = FAST_MODEL.invoke([
            SystemMessage(content=overflow_check_system()),
            HumanMessage(content=user_prompt),
        ])
    decision, err = parse_llm_json(getattr(raw, "content", str(raw)))

    if err or decision is None:
        LOGGER.warning("overflow_check: LLM response could not be parsed (%s) — using column summary only", err)
        return {**state, "overflow_attempted": True, "column_context": column_summary}

    needs_overflow: bool = bool(decision.get("needs_overflow"))
    overflow_reason: str  = decision.get("reason", "")
    LOGGER.info(
        "overflow_check: needs_overflow=%s  reason=%s",
        needs_overflow, overflow_reason,
    )

    overflow_text = ""
    if needs_overflow and decision.get("requested_columns"):
        budget = OVERFLOW_BUDGET_CHARS
        fetched: list[str] = []

        for req in decision["requested_columns"]:
            r_file  = (req.get("file")   or "").casefold()
            r_sheet = (req.get("sheet")  or "").casefold()
            r_col   = (req.get("column") or "").casefold()

            for chunk in overflow_chunks:
                c_f = chunk["file"].casefold()
                c_s = chunk["sheet"].casefold()
                c_c = chunk["column"].casefold()
                if (r_file in c_f or c_f in r_file) \
                        and (r_sheet in c_s or c_s in r_sheet) \
                        and r_col == c_c:
                    formatted = format_overflow_chunk(chunk)
                    if budget - len(formatted) < 0:
                        LOGGER.info("overflow_check: %d-char budget exhausted", OVERFLOW_BUDGET_CHARS)
                        break
                    fetched.append(formatted)
                    budget -= len(formatted)

        if fetched:
            overflow_text = (
                "\n\nOVERFLOW VALUES (LLM-requested columns):\n" + "\n".join(fetched)
            )
            LOGGER.info(
                "overflow_check: attached %d chunk(s) (%.1f KB)",
                len(fetched), len(overflow_text) / 1024,
            )
        else:
            LOGGER.info("overflow_check: no matching chunks found for requested columns")
    else:
        LOGGER.info("overflow_check: LLM decided no overflow needed — column summary is sufficient")

    # col_ctx = column_summary + overflow_text
    # trace_reason = (
    #     f"Resolved {len(matched_sources)} sheet(s).  "
    #     f"LLM needs_overflow={needs_overflow}.  "
    #     f"overflow_chunks_attached={len(overflow_text) > 0}.  "
    #     f"reason='{overflow_reason}'"
    # )
    # return {
    #     **state,
    #     "overflow_attempted": True,
    #     "column_context": col_ctx,
    #     "step_trace": _trace(state, "overflow_check", trace_reason,
    #                          f"{len(col_ctx)} chars of column context assembled"),
    # }
    # ── DISABLED BODY END ─────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# sheet_selector_node
# Final validation pass: fuzzy-match LLM-chosen candidates against the MBR
# catalog to produce canonical file/sheet names.  Handles fallback gracefully.
# ─────────────────────────────────────────────────────────────────────────────

def sheet_selector_node(state: SheetSelectionState) -> SheetSelectionState:
    """
    Enhanced validation pass: fuzzy-match LLM-chosen candidates against the MBR catalog
    to produce canonical file/sheet names with granularity_type validation.
    Passes through business context (description, business_facts, catalog_columns) for context_builder.
    Falls back gracefully if nothing matches.
    """
    mapping = dict(state.get("mapping_result") or {})
    candidates: list[dict] = mapping.get("file_and_sheet_mapping") or []

    # Extract JWT token from state for user-specific month tracking
    user_jwt_token = state.get("user_jwt_token")

    # OPTIMIZATION: Use cached catalog from mapping_node (saves 12-26ms)
    catalog = state.get("_catalog_cache")
    if catalog is None:
        # Fallback: load if cache not available (shouldn't happen in normal flow)
        LOGGER.info(" Catalog cache miss - loading from S3 (fallback)")
        catalog = load_enhanced_csv_catalog(user_jwt_token)
    else:
        LOGGER.debug(" Using cached catalog (%d entries)", len(catalog))

    # Single-entry catalog → auto-select without further matching
    if len(catalog) == 1:
        row = catalog[0]
        cand_0 = candidates[0] if candidates else {}

        mapping["selected_sources"] = [{
            "file":               row["file_name"],
            "sheet":              row["tab_name"],
            "reason":             "Only one MBR catalog entry — auto-selected.",
            "granularity_type":   row.get("granularity_type", "Raw"),
            # Business context from catalog (authoritative source)
            "description":        _clean_text(row.get("purpose", "")),
            "business_facts":     _clean_text(row.get("business_facts", "")),
            "catalog_columns":    _clean_text(row.get("columns_list", "")),
        }]
        mapping["requires_cross_file"] = False
        trace = _trace(state, "sheet_selector", "Auto-selected (single catalog entry).")
        return {
            **state,
            "mapping_result": mapping,
            "answer": json.dumps(mapping, ensure_ascii=False),
            "answer_struct": mapping,
            "step_trace": trace,
        }

    selected: list[dict] = []
    raw_count = 0
    agg_count = 0
    
    for cand in candidates:
        want_file = _clean_text(cand.get("file_name", ""))
        want_tab  = _clean_text(cand.get("tab_name",  ""))
        reason    = _clean_text(cand.get("why", ""))
        granularity_type = _clean_text(cand.get("granularity_type", "Raw"))

        matched_row: dict | None = None
        for row in catalog:
            fn = row["file_name"]
            tn = row["tab_name"]
            file_ok = (
                want_file.casefold() in fn.casefold()
                or fn.casefold() in want_file.casefold()
            )
            tab_ok = (
                not want_tab
                or want_tab.casefold() in tn.casefold()
                or tn.casefold() in want_tab.casefold()
            )
            if file_ok and tab_ok:
                matched_row = row
                break

        if matched_row:
            # Validate granularity type consistency
            catalog_granularity = matched_row.get("granularity_type", "Raw")
            if granularity_type != catalog_granularity:
                LOGGER.warning(
                    "Granularity type mismatch: LLM suggested '%s', catalog has '%s' for %s/%s",
                    granularity_type, catalog_granularity, want_file, want_tab
                )
                # Use catalog granularity as authoritative
                granularity_type = catalog_granularity

            selected.append({
                "file":               matched_row["file_name"],
                "sheet":              matched_row["tab_name"],
                "reason":             reason,
                "granularity_type":   granularity_type,
                # Business context from catalog (authoritative source)
                "description":        _clean_text(matched_row.get("purpose", "")),
                "business_facts":     _clean_text(matched_row.get("business_facts", "")),
                "catalog_columns":    _clean_text(matched_row.get("columns_list", "")),
            })
            
            # Count raw vs aggregated sources
            if granularity_type == "Raw":
                raw_count += 1
            else:
                agg_count += 1
        else:
            LOGGER.warning(
                "sheet_selector: no MBR catalog match for '%s / %s' — keeping LLM names as-is",
                want_file, want_tab,
            )
            selected.append({
                "file":               want_file,
                "sheet":              want_tab,
                "reason":             f"[No MBR match] {reason}",
                "granularity_type":   granularity_type,
                # Business context unavailable (no catalog match)
                "description":        _clean_text(cand.get("description", "")),
                "business_facts":     _clean_text(cand.get("business_facts", "")),
                "catalog_columns":    _clean_text(cand.get("catalog_columns", "")),
            })

    # Global fallback: nothing matched → take first catalog entry
    if not selected and catalog:
        row = catalog[0]
        LOGGER.warning("sheet_selector: no candidates resolved — using first catalog entry as fallback")
        selected.append({
            "file":               row["file_name"],
            "sheet":              row["tab_name"],
            "reason":             "Global fallback — no candidate matched MBR catalog.",
            "granularity_type":   row.get("granularity_type", "Raw"),
            # No business context available for fallback
            "description":        "",
            "business_facts":     "",
            "catalog_columns":    "",
        })
        raw_count = 1 if row.get("granularity_type", "Raw") == "Raw" else 0
        agg_count = 1 if row.get("granularity_type", "Raw") == "Aggregated" else 0

    unique_files = {s["file"] for s in selected if s["file"]}
    mapping["selected_sources"]   = selected
    # Placeholder: Will be determined by context_builder after analyzing actual columns
    # Context builder has full column information and can accurately detect cross-file needs
    mapping["requires_cross_file"] = False  # Placeholder - will be overridden by context_builder
    
    # Add priority summary
    mapping["priority_summary"] = {
        "raw_sources_count": raw_count,
        "aggregated_sources_count": agg_count,
        "priority_followed": raw_count > 0,  # True if we have any Raw data sources
    }

    trace_detail = "  |  ".join(
        f"{s['file']} / {s['sheet']} ({s.get('granularity_type', 'Unknown')})"
        for s in selected
    )
    trace_reason = (
        f"Validated {len(selected)} source(s) against MBR catalog  "
        f"(cross_file={mapping['requires_cross_file']}, "
        f"raw={raw_count}, aggregated={agg_count})"
    )
    trace = _trace(
        state, "sheet_selector", trace_reason, trace_detail,
    )

    # Build sheet_selection_confidence for confidence_summary_node
    detailed_sources = []
    for entry in candidates:
        file_name = _clean_text(entry.get("file_name", ""))
        tab_name = _clean_text(entry.get("tab_name", ""))
        if not file_name or not tab_name:
            continue
        entry_conf = entry.get("confidence")
        if entry_conf is not None:
            try:
                entry_conf = int(entry_conf)
            except (ValueError, TypeError):
                entry_conf = state.get("mapping_result", {}).get("confidence", 80)
        else:
            entry_conf = state.get("mapping_result", {}).get("confidence", 80)
        detailed_sources.append({
            "file": file_name,
            "sheet": tab_name,
            "confidence": entry_conf,
            "reason": _clean_text(entry.get("why", "Selected by LLM")),
        })

    sheet_selection_confidence = {
        "overall_confidence": state.get("mapping_result", {}).get("confidence", 80),
        "overall_reason": "Sheet selection completed",  # confidence_reason removed for optimization
        "selected_sources": detailed_sources,
    }

    return {
        **state,
        "mapping_result": mapping,
        "sheet_selection_confidence": sheet_selection_confidence,
        "answer": json.dumps(mapping, ensure_ascii=False),
        "answer_struct": mapping,
        "step_trace": trace,
    }


def route_after_mapping(state: SheetSelectionState) -> str:
    """Always proceed to sheet_selector regardless of confidence (HITL disabled)."""
    mapping_result  = state.get("mapping_result") or {}
    confidence      = int(mapping_result.get("confidence", 0) or 0)

    LOGGER.info("route_after_mapping → sheet_selector (confidence=%d, HITL disabled)", confidence)
    return "sheet_selector"


def route_after_domain_validation(state: SheetSelectionState) -> str:
    """
    Route after domain validation based on question type:
    - greeting -> END (already responded)
    - financial -> intent (continue to full workflow)
    - other -> END (already rejected)
    """
    domain_validation = state.get("domain_validation") or {}
    question_type = domain_validation.get("question_type", "other").lower()
    
    if question_type == "greeting":
        LOGGER.info("route_after_domain_validation → END  (greeting processed: %s)", question_type)
        return "END"
    elif question_type == "relevant":
        LOGGER.info("route_after_domain_validation → intent  (relevant question: %s)", question_type)
        return "intent"
    else:
        LOGGER.info("route_after_domain_validation → END  (non-relevant question rejected: %s)", question_type)
        return "END"


def route_after_user_followup(state: SheetSelectionState) -> str:
    # User provided answers → refine intent with clarifications, then re-run mapping
    if state.get("user_clarifications", "").strip():
        LOGGER.info("route_after_user_followup → intent_refinement (incorporate clarifications)")
        return "intent_refinement"
    # Empty/skipped answers → best-effort, go directly to sheet_selector
    LOGGER.info("route_after_user_followup → sheet_selector (empty answers, best-effort)")
    return "sheet_selector"

    # ── OLD ROUTING (disabled) ────────────────────────────────────────────
    # elif state.get("analysis_spec") is None and state.get("mapping_result") is None:
    #     LOGGER.info("route_after_user_followup → normalize_query  (full pipeline reset)")
    #     return "normalize_query"
    # LOGGER.info("route_after_user_followup → sheet_selector  (no reset)")
    # return "sheet_selector"


def _build_graph():
    """
    Graph topology:

        START
          ↓
        normalize_query
          ↓
        domain_validation ── greeting/other → END
          ↓ (financial)
        intent
          ↓
        mapping ─── conf ≥ 80 ────────────────────────────► sheet_selector → END
          |                                                         ▲
          └── conf < 80 AND followup not done                      |
                  ↓                                                |
              user_followup (ask ≤2 questions)                     |
                  ↓                                                |
              intent_refinement                                    |
                  ↓                                                |
              mapping (second pass)                                |
                  ├── conf ≥ 80 ───────────────────────────────┘
                  └── conf < 80, followup done → sheet_selector (best-effort)

    NOTE: overflow_check node is DISABLED. To re-enable, uncomment the
    overflow_check node/edges below and restore route_after_mapping logic.
    """
    graph = StateGraph(SheetSelectionState)

    def _t(name, fn):
        """Wrapper that handles both regular functions and async generators."""
        import inspect

        if inspect.isasyncgenfunction(fn):
            # Async generator function (uses yield)
            async def async_gen_wrapper(state):
                with timed(f"node2.{name}"):
                    # Consume the async generator and return the last yielded value
                    result = state
                    async for value in fn(state):
                        result = value
                    return result
            return async_gen_wrapper
        elif inspect.iscoroutinefunction(fn):
            # Async function (uses return)
            async def async_wrapper(state):
                with timed(f"node2.{name}"):
                    return await fn(state)
            return async_wrapper
        else:
            # Regular sync function
            def wrapper(state):
                with timed(f"node2.{name}"):
                    return fn(state)
            return wrapper

    # ── Nodes ──────────────────────────────────────────────────────────────────
    graph.add_node("normalize_query", _t("normalize_query", normalize_query_node))
    graph.add_node("domain_validation", _t("domain_validation", domain_validation_node))
    graph.add_node("intent",          _t("intent", intent_node))
    graph.add_node("mapping",         _t("mapping", mapping_node))
    graph.add_node("sheet_selector",  _t("sheet_selector", sheet_selector_node))

    # ── Edges ─────────────────────────────────────────────────────────────────
    graph.add_edge(START, "normalize_query")
    graph.add_edge("normalize_query", "domain_validation")
    
    # Domain validation routing: valid → intent, invalid → END
    graph.add_conditional_edges(
        "domain_validation",
        route_after_domain_validation,
        {
            "intent": "intent",
            "END":    END,
        },
    )
    
    graph.add_edge("intent", "mapping")

    # Direct edge - no HITL, always proceed to sheet_selector
    graph.add_edge("mapping", "sheet_selector")

    graph.add_edge("sheet_selector", END)

    return graph.compile()


APP = _build_graph()


# ─────────────────────────────────────────────────────────────────────────────
# Routing table formatter — 80% confidence threshold display
# ─────────────────────────────────────────────────────────────────────────────

def format_routing_table(
    file_and_sheet_mapping: list[dict],
    overall_confidence: int = 0,
) -> str:
    """
    Format the LLM mapping results into a clean routing table.

    Files with per-entry confidence ≥ 80 are shown as SELECTED.
    Files below 80 are shown as NOT SELECTED with the reason.

    If per-entry confidence is not set by the LLM, falls back to the overall
    confidence for all entries so the table always renders.
    """
    THRESHOLD = 80
    col_widths = {"num": 3, "file": 34, "sheet": 20, "conf": 6, "why": 40}
    sep = (
        "+"
        + "-" * (col_widths["num"] + 2)
        + "+"
        + "-" * (col_widths["file"] + 2)
        + "+"
        + "-" * (col_widths["sheet"] + 2)
        + "+"
        + "-" * (col_widths["conf"] + 2)
        + "+"
        + "-" * (col_widths["why"] + 2)
        + "+"
    )

    def _row(num: str, file: str, sheet: str, conf: str, why: str) -> str:
        return (
            f"| {num:<{col_widths['num']}} "
            f"| {file:<{col_widths['file']}} "
            f"| {sheet:<{col_widths['sheet']}} "
            f"| {conf:<{col_widths['conf']}} "
            f"| {why:<{col_widths['why']}} |"
        )

    def _trunc(text: str, width: int) -> str:
        return text[:width - 1] + "…" if len(text) > width else text

    header = _row("#", "File", "Sheet", "Conf%", "Why")

    selected: list[str] = []
    not_selected: list[str] = []
    sel_idx = 1

    for entry in file_and_sheet_mapping:
        file_name  = _clean_text(entry.get("file_name", ""))
        tab_name   = _clean_text(entry.get("tab_name", ""))
        why        = _clean_text(entry.get("why", ""))
        # Per-entry confidence preferred; fall back to overall
        entry_conf = entry.get("confidence", overall_confidence)
        try:
            entry_conf = int(entry_conf)
        except (TypeError, ValueError):
            entry_conf = overall_confidence

        conf_str = f"{entry_conf}%"
        file_t   = _trunc(file_name, col_widths["file"])
        sheet_t  = _trunc(tab_name, col_widths["sheet"])
        why_t    = _trunc(why, col_widths["why"])

        if entry_conf >= THRESHOLD:
            selected.append(_row(str(sel_idx), file_t, sheet_t, conf_str, why_t))
            sel_idx += 1
        else:
            reason = why_t if why_t else "Below confidence threshold"
            not_selected.append(_row("-", file_t, sheet_t, conf_str, reason))

    lines: list[str] = [sep, header, sep]

    if selected:
        lines.append(_row("", "  >>> SELECTED  (>= 80%)", "", "", ""))
        lines.append(sep)
        lines.extend(selected)
        lines.append(sep)

    if not_selected:
        lines.append(_row("", "  NOT SELECTED  (< 80%)", "", "", ""))
        lines.append(sep)
        lines.extend(not_selected)
        lines.append(sep)

    if not selected and not not_selected:
        lines.append(_row("-", "(no sources returned)", "", "N/A", "LLM returned empty mapping"))
        lines.append(sep)

    return "\n".join(lines)


def to_sheet_selector_output(result_state: SheetSelectionState) -> dict[str, Any]:
    """
    Convert the final pipeline state into a clean, consumer-friendly dict with
    enhanced Raw/Aggregated prioritization information.

    ``selected_sources`` is always a list of::

        {
          "file":               str,   # exact Excel filename from MBR catalog
          "sheet":              str,   # exact sheet/tab name
          "reason":             str,   # why this source was chosen (business relevance)
          "granularity_type":   str,   # "Raw" or "Aggregated"
          "description":        str,   # high-level purpose from catalog
          "business_facts":     str,   # business context from catalog
          "catalog_columns":    str,   # generic column names from catalog
        }
    """
    mapping_result = result_state.get("mapping_result") or {}

    # ── Prefer validated names from sheet_selector_node ───────────────────
    if mapping_result.get("selected_sources"):
        selections: list[dict] = mapping_result["selected_sources"]
    else:
        # Fallback: derive from raw LLM output (sheet_selector_node not reached)
        selections = [
            {
                "file":               _clean_text(row.get("file_name", "")),
                "sheet":              _clean_text(row.get("tab_name", "")),
                "reason":             _clean_text(row.get("why", "")),
                "granularity_type":   _clean_text(row.get("granularity_type", "Raw")),
                "description":        _clean_text(row.get("description", "")),
                "business_facts":     _clean_text(row.get("business_facts", "")),
                "catalog_columns":    _clean_text(row.get("catalog_columns", "")),
            }
            for row in mapping_result.get("file_and_sheet_mapping", [])
            if _clean_text(row.get("file_name", "")) and _clean_text(row.get("tab_name", ""))
        ]

    unique_files = {s["file"] for s in selections if s["file"]}

    # Build routing table from the raw LLM mapping entries
    raw_mapping = mapping_result.get("file_and_sheet_mapping", [])
    overall_conf = int(mapping_result.get("confidence", 0))
    routing_table = format_routing_table(raw_mapping, overall_conf)

    # Build detailed confidence structure for each selected source
    detailed_sources = []
    for entry in raw_mapping:
        file_name = _clean_text(entry.get("file_name", ""))
        tab_name = _clean_text(entry.get("tab_name", ""))
        if not file_name or not tab_name:
            continue

        # Get per-entry confidence or fall back to overall
        entry_conf = entry.get("confidence")
        if entry_conf is not None:
            try:
                entry_conf = int(entry_conf)
            except (ValueError, TypeError):
                entry_conf = overall_conf
        else:
            entry_conf = overall_conf

        detailed_sources.append({
            "file": file_name,
            "sheet": tab_name,
            "confidence": entry_conf,
            "reason": _clean_text(entry.get("why", "Selected by LLM")),
        })

    output = {
        "selected_sources":  selections,
        "requires_cross_file": mapping_result.get(
            "requires_cross_file", len(unique_files) > 1
        ),
        "confidence":        overall_conf,
        "routing_table":     routing_table,
        "file_and_sheet_mapping": raw_mapping,
        "sheet_selection_confidence": {
            "overall_confidence": overall_conf,
            "overall_reason": "Sheet selection completed",  # confidence_reason removed for optimization
            "selected_sources": detailed_sources,
        },
        "analysis_spec":     result_state.get("analysis_spec") or {},
        "normalized_question": result_state.get("normalized_question", ""),
        "glossary_matches":  result_state.get("glossary_matches", []),
        "step_trace":        result_state.get("step_trace") or [],
        "priority_summary":  mapping_result.get("priority_summary", {
            "raw_sources_count": 0,
            "aggregated_sources_count": 0,
            "priority_followed": False,
        }),
        "linked_files":      mapping_result.get("linked_files", []),
        "domain_validation": result_state.get("domain_validation", {}),
        # Add intermediate node results for AG-UI streaming visibility
        "intent_result":     result_state.get("analysis_spec") or {},  # Intent stored as analysis_spec
        "mapping_result":    mapping_result,  # Full mapping result with confidence reasoning
    }

    # Add warning if confidence < 80
    if overall_conf < 80:
        sheets_list = ", ".join([f"{s['file']}::{s['sheet']}" for s in selections])
        output["sheet_selection_warning"] = (
            f"WARNING - Not sure on the sheet selection (confidence: {overall_conf}%). "
            f"Potential sheets found are: {sheets_list}"
        )

    return output


def run_query(
    question: str,
    *,
    user_answer_provider: Callable[[list[str]], list[str]] | None = None,
    output_path: Path | None = DEFAULT_OUTPUT_PATH,
) -> SheetSelectionState:
    initial_state: SheetSelectionState = {
        "question": question,
        "normalized_question": "",
        "glossary_matches": [],
        "domain_validation": None,  # NEW: Initialize domain validation result
        "analysis_spec": None,
        "mapping_result": None,
        "answer": "",
        "answer_struct": None,
        "followup_done": False,
        "overflow_attempted": False,
        "column_context": "",
        "user_clarifications": "",
        "step_trace": [],
        "user_answer_provider": user_answer_provider,
    }
    result = APP.invoke(initial_state)

    output = to_sheet_selector_output(result)

    if output_path is not None:
        Path(output_path).write_text(result.get("answer", ""), encoding="utf-8")

    return result


def sheet_selection_prototype_node(state: dict[str, Any]) -> dict[str, Any]:
    query = _clean_text(state.get("query", ""))
    if not query:
        raise ValueError("sheet_selection_prototype_node requires a non-empty 'query'")

    result = run_query(
        query,
        user_answer_provider=state.get("user_answer_provider"),
        output_path=None,
    )
    return to_sheet_selector_output(result)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    # Test with a financial domain question
    financial_question = (
        "What are the key drivers of shipment and IMS volume variance versus prior year and latest forecast (base demand, trade loading, one‑offs, distribution changes)? "
    )
    final_state = run_query(financial_question)
    result_json = json.dumps(to_sheet_selector_output(final_state), ensure_ascii=False)
   
    