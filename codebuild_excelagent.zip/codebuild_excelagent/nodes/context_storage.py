"""Context Storage Node - Stores Q+A to memory after pipeline completes.

This node runs after narrative_explainer and before format_response.
It stores the original user question + final answer for the next turn to use.
"""

from __future__ import annotations

import logging
from typing import Dict, Any

from helpers.memory_manager import get_memory_manager
from core.settings import settings

logger = logging.getLogger(__name__)


def context_storage_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Store (original_query, final_answer) to memory for next turn.

    This runs after narrative_explainer produces final_answer.

    Args:
        state: AGUIExcelState with:
            - memory_session_id: Session ID for memory
            - original_query: User's actual words (before enrichment)
            - final_answer: Final answer from narrative_explainer (or answer field)

    Returns:
        Empty dict (no state changes needed)
    """
    try:
        session_id = state.get("memory_session_id")
        original_query = state.get("original_query")
        final_answer = state.get("final_answer") or state.get("answer")

        # Validation
        if not session_id:
            logger.warning("[STORAGE] No memory_session_id - skipping storage")
            return {}

        if not original_query:
            logger.warning("[STORAGE] No original_query - skipping storage")
            return {}

        if not final_answer:
            logger.warning("No final_answer - skipping context storage")
            return {}

        # Store to memory
        memory_manager = get_memory_manager(
            region=settings.aws_region,
            memory_id="memoryMBRshort-T8GbYmGACP",
        )

        success = memory_manager.store_qa(
            session_id=session_id,
            question=original_query,
            answer=final_answer,
        )

        if not success:
            logger.warning("Failed to store Q+A to context memory")

        # No state changes needed
        return {}

    except Exception as e:
        logger.error(f"[STORAGE] Context storage failed: {e}")
        logger.error(f"[STORAGE] Error type: {type(e).__name__}")
        import traceback
        logger.error(f"[STORAGE] Traceback: {traceback.format_exc()}")
        # Graceful degradation - don't crash pipeline
        return {}
