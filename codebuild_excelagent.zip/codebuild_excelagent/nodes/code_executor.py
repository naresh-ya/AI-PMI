"""Code executor — executes generated code with diagnostic-based retry."""

import os
import sys
import subprocess
import tempfile
from typing import Dict, Any, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage

from claude_setup.llm import get_model
from models.state import PipelineState
from core.structured_logging import get_logger
from prompts.system_prompts import code_executor_fix_system
from prompts.user_prompts import build_code_fix_prompt
from helpers.code_util import extract_code, is_code_complete
from core.timing import timed

logger = get_logger(__name__)


_S3_PANDAS_PRELUDE = """
from io import BytesIO
from urllib.parse import urlparse
import boto3

_original_read_excel = pd.read_excel

def _read_excel_with_s3_support(io, *args, **kwargs):
    if isinstance(io, str) and io.startswith("s3://"):
        parsed = urlparse(io)
        bucket = parsed.netloc
        key = parsed.path.lstrip("/")
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        return _original_read_excel(BytesIO(body), *args, **kwargs)
    return _original_read_excel(io, *args, **kwargs)

pd.read_excel = _read_excel_with_s3_support
""".strip()


def _wrap_code_for_execution(code: str) -> str:
    """Inject S3-aware pandas.read_excel support into generated scripts."""
    lines = code.splitlines()
    if lines and lines[0].strip() == "import pandas as pd":
        return "\n".join([lines[0], _S3_PANDAS_PRELUDE, *lines[1:]])
    return "\n".join(["import pandas as pd", _S3_PANDAS_PRELUDE, code])


def _build_diagnostic_script(sources: List[Dict]) -> str:
    """Build diagnostic script that inspects all source files."""
    lines = ["import pandas as pd"]
    for i, src in enumerate(sources):
        file_path = src.get("file_path", "")
        sheet_name = src.get("sheet", "")
        var = f"df{i + 1}" if len(sources) > 1 else "df"
        lines.append(f'\nprint("=== Source {i + 1}: {src.get("file", "")} :: {sheet_name} ===")')
        lines.append(f'{var} = pd.read_excel(r"{file_path}", sheet_name="{sheet_name}", header=None)')
        lines.append(f'print(f"Shape: {{{var}.shape}}")')
        lines.append(f'print(f"\\nFirst 5 rows:")')
        lines.append(f'print({var}.iloc[0:5, :].to_string())')
        lines.append(f'print(f"\\nColumn types:")')
        lines.append(f'for j in range(min({var}.shape[1], 22)):')
        lines.append(f'    col = {var}.iloc[:, j]')
        lines.append(f'    non_null = col.dropna()')
        lines.append(f'    sample = non_null.head(3).tolist() if len(non_null) > 0 else []')
        lines.append(f'    print(f"  Col {{j+1}}: {{len(non_null)}} non-null, samples: {{sample}}")')
    return "\n".join(lines)


def _fix_code(
    code: str,
    error: str,
    output: str,
    query_context: str,
    diagnostics: Optional[str] = None,
    stream_callback = None
):
    """Fix broken code using error + diagnostics. With streaming support.

    Args:
        stream_callback: Optional callback function to receive streaming tokens
    """
    from langchain_core.messages import AIMessage

    model = get_model()

    messages = [
        SystemMessage(content=code_executor_fix_system()),
        HumanMessage(content=build_code_fix_prompt(code, error, output, query_context, diagnostics)),
    ]

    with timed("LLM_CALL code_executor_fix"):
        # Stream the fixed code token by token
        full_response = []
        for token in model.stream(messages):
            full_response.append(token)

            # If callback provided, send streaming updates
            if stream_callback:
                stream_callback(AIMessage(content=token))

        response_text = "".join(full_response)

    fixed = extract_code(response_text)
    return fixed


def code_executor_node(state: PipelineState) -> dict:
    """Execute code with diagnostic-based retry."""
    code = state.get("generated_code", "")
    query = state.get("query", "")
    query_context = state.get("query_context", "")
    selected_sources = state.get("selected_sources", [])
    max_retries = state.get("max_retries", 2)

    current_code = code
    diagnostics_output = None
    error_history = []

    for attempt in range(max_retries + 1):
        if not is_code_complete(current_code):
            error_history.append("Code is incomplete/truncated")
            if attempt < max_retries:
                current_code = _fix_code(
                    current_code,
                    "Code is incomplete/truncated.",
                    "", query_context, diagnostics_output
                )
                continue
            else:
                return {
                    "execution_result": {
                        "success": False, "output": "",
                        "error": "Incomplete code after retries",
                        "code": current_code
                    },
                    "success": False,
                    "error_history": error_history,
                }

        # Execute
        with tempfile.NamedTemporaryFile(
            mode='w', suffix='.py', delete=False, encoding='utf-8'
        ) as tmp:
            tmp.write(_wrap_code_for_execution(current_code))
            tmp_path = tmp.name

        try:
            with timed(f"SUBPROCESS code_execution attempt={attempt+1}"):
                result = subprocess.run(
                    [sys.executable, tmp_path],
                    capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, env=os.environ.copy()
                )

            if result.returncode == 0 and result.stdout and result.stdout.strip():
                return {
                    "execution_result": {
                        "success": True,
                        "output": result.stdout.strip(),
                        "error": None,
                        "code": current_code,
                    },
                    "generated_code": current_code,
                    "final_answer": result.stdout.strip(),
                    "success": True,
                    "error_history": error_history,
                }

            error_msg = (
                result.stderr if result.returncode != 0
                else "Code ran but produced NO output."
            )
            error_history.append(error_msg[:500])

            if attempt < max_retries:
                # Run diagnostics on first failure
                if diagnostics_output is None:
                    diag_code = _build_diagnostic_script(selected_sources)
                    with tempfile.NamedTemporaryFile(
                        mode='w', suffix='.py', delete=False, encoding='utf-8'
                    ) as dtmp:
                        dtmp.write(_wrap_code_for_execution(diag_code))
                        dtmp_path = dtmp.name
                    try:
                        diag_result = subprocess.run(
                            [sys.executable, dtmp_path],
                            capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, env=os.environ.copy()
                        )
                        diagnostics_output = (
                            diag_result.stdout[:3000]
                            if diag_result.stdout
                            else "Diagnostic script also failed."
                        )
                    except Exception:
                        diagnostics_output = "Diagnostic script timed out."
                    finally:
                        try:
                            os.unlink(dtmp_path)
                        except OSError:
                            pass

                current_code = _fix_code(
                    current_code, error_msg,
                    result.stdout, query_context, diagnostics_output
                )
            else:
                return {
                    "execution_result": {
                        "success": False,
                        "output": result.stdout,
                        "error": error_msg,
                        "code": current_code,
                        "diagnostics": diagnostics_output,
                    },
                    "success": False,
                    "diagnostics_output": diagnostics_output,
                    "error_history": error_history,
                }

        except subprocess.TimeoutExpired:
            return {
                "execution_result": {
                    "success": False, "output": "",
                    "error": "Timed out after 120s",
                    "code": current_code,
                },
                "success": False,
                "error_history": error_history,
            }
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    return {
        "execution_result": {
            "success": False, "output": "",
            "error": "Max retries exceeded",
            "code": current_code,
        },
        "success": False,
        "error_history": error_history,
    }
