"""
ASYNC parallel pipeline executor for TRUE concurrency.

Uses asyncio + httpx to avoid GIL blocking on HTTP calls.
This achieves TRUE parallel code generation (~40s for 3 sources instead of 120s).
"""

import asyncio
import re
import json
import os
import sys
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Any, List

from langchain_core.messages import HumanMessage, SystemMessage

from models.state import PipelineState
from core.structured_logging import get_logger
from prompts.system_prompts import code_generator_system
from prompts.user_prompts import build_code_generation_prompt
from helpers.code_util import extract_code, is_code_complete
from helpers.file_registry import get_file_path_by_name
from core.timing import timed

# Import execution utilities from code_executor
from nodes.code_executor import _wrap_code_for_execution, _build_diagnostic_script

logger = get_logger(__name__)


async def _call_llm_async(client, messages: list, model_name: str, max_tokens: int) -> str:
    """
    Make async LLM call using httpx (non-blocking, non-streaming).
    Uses SHARED httpx client for connection pooling (faster SSL reuse).

    Args:
        client: Shared httpx.AsyncClient for connection pooling
        messages: LangChain messages
        model_name: Model ID
        max_tokens: Max tokens
    """
    from core.settings import settings

    # Build Bedrock payload
    system_blocks = []
    bedrock_messages = []

    for msg in messages:
        role = getattr(msg, "type", "user")
        content = msg.content if hasattr(msg, "content") else str(msg)

        if role == "system":
            system_blocks.append({"text": content})
        else:
            bedrock_role = "assistant" if role == "ai" else "user"
            bedrock_messages.append({"role": bedrock_role, "content": [{"text": content}]})

    payload = {
        "modelId": model_name,
        "messages": bedrock_messages,
        "inferenceConfig": {
            "maxTokens": max_tokens,
            "temperature": 0,
        },
    }
    if system_blocks:
        payload["system"] = system_blocks

    headers = {
        "Authorization": f"Bearer {settings.bedrock_bearer_token}",
        "Content-Type": "application/json",
    }

    base_url = settings.bedrock_endpoint_url.rstrip("/")
    endpoint = f"{base_url}/model/{model_name}/converse"

    # Use shared client for connection pooling (reuses SSL handshake)
    response = await client.post(endpoint, json=payload, headers=headers)
    response.raise_for_status()

    result = response.json()
    content = result.get("output", {}).get("message", {}).get("content", [])
    texts = [str(block.get("text", "")) for block in content if isinstance(block, dict)]
    return "".join(texts).strip()


async def _call_llm_async_stream(client, messages: list, model_name: str, max_tokens: int):
    """
    Stream LLM response asynchronously using httpx with SSE.
    Based on LiteLLM async streaming documentation.

    Args:
        client: Shared httpx.AsyncClient for connection pooling
        messages: LangChain messages
        model_name: Model ID
        max_tokens: Max tokens

    Yields:
        str: Token chunks as they arrive
    """
    import json
    from core.settings import settings

    # Build Bedrock payload
    system_blocks = []
    bedrock_messages = []

    for msg in messages:
        role = getattr(msg, "type", "user")
        content = msg.content if hasattr(msg, "content") else str(msg)

        if role == "system":
            system_blocks.append({"text": content})
        else:
            bedrock_role = "assistant" if role == "ai" else "user"
            bedrock_messages.append({"role": bedrock_role, "content": [{"text": content}]})

    payload = {
        "modelId": model_name,
        "messages": bedrock_messages,
        "inferenceConfig": {
            "maxTokens": max_tokens,
            "temperature": 0,
        },
    }
    if system_blocks:
        payload["system"] = system_blocks

    headers = {
        "Authorization": f"Bearer {settings.bedrock_bearer_token}",
        "Content-Type": "application/json",
    }

    base_url = settings.bedrock_endpoint_url.rstrip("/")
    endpoint = f"{base_url}/model/{model_name}/converse-stream"  # Note: -stream suffix

    # Track repeated chunks for infinite loop detection (LiteLLM safety feature)
    repeated_chunk_tracker = {}
    REPEATED_STREAMING_CHUNK_LIMIT = 100

    try:
        async with client.stream('POST', endpoint, json=payload, headers=headers) as response:
            response.raise_for_status()

            # Parse SSE stream
            async for line in response.aiter_lines():
                if not line:
                    continue

                # SSE format: "data: {json}"
                if line.startswith('data:'):
                    data_str = line[5:].strip()

                    if data_str == '[DONE]':
                        break

                    try:
                        chunk_data = json.loads(data_str)
                        chunk_type = chunk_data.get('type', '')

                        if chunk_type == 'content_block_delta':
                            delta = chunk_data.get('delta', {})
                            text = delta.get('text', '')

                            if text:
                                # Infinite loop detection
                                if text in repeated_chunk_tracker:
                                    repeated_chunk_tracker[text] += 1
                                    if repeated_chunk_tracker[text] > REPEATED_STREAMING_CHUNK_LIMIT:
                                        raise RuntimeError(
                                            f"Model entered infinite loop: chunk '{text[:50]}...' "
                                            f"repeated {repeated_chunk_tracker[text]} times"
                                        )
                                else:
                                    repeated_chunk_tracker[text] = 1

                                yield text

                        elif chunk_type == 'message_stop':
                            break

                    except json.JSONDecodeError:
                        continue

    except Exception as e:
        logger.error(f"Streaming error: {e}")
        raise


async def _generate_code_async(
    client,
    query: str,
    context: str,
    source: dict,
    file_registry: dict,
    business_formulas: str,
    model_name: str,
    max_tokens: int
) -> str:
    """Generate Python code for a single source using async LLM."""
    from prompts.system_prompts import code_generator_system

    # Build read instruction
    file_path = source.get("file_path", "")
    if not file_path:
        file_path = get_file_path_by_name(file_registry, source.get("file", "")) or source.get("file", "")

    read_code = (
        f"df = pd.read_excel("
        f"r\"{file_path}\", "
        f"sheet_name=\"{source['sheet']}\", header=None)"
    )

    sys_prompt = code_generator_system(read_code, "", business_formulas)
    messages = [SystemMessage(content=sys_prompt)]

    for attempt in range(3):
        if attempt == 0:
            user_msg = build_code_generation_prompt(query, context)
        else:
            user_msg = """Your previous code was incomplete or truncated.

CRITICAL REQUIREMENTS FOR COMPLETE CODE:
- Must end with print() statement that outputs the final answer
- All brackets must be closed: (), [], {}
- All quotes must be closed: "", ''
- Code must be syntactically complete

Generate the COMPLETE, CORRECT code now (no comments, no explanations):"""

        messages.append(HumanMessage(content=user_msg))

        # ASYNC LLM call
        response_text = await _call_llm_async(client, messages, model_name, max_tokens)
        code = extract_code(response_text)

        if is_code_complete(code):
            pass  # Removed verbose logging for performance
            return code

        logger.warning(f"Attempt {attempt + 1} incomplete for {source.get('file', '?')}::{source.get('sheet', '?')}, retrying...")

    logger.error(f"All 3 attempts failed for {source.get('file', '?')}::{source.get('sheet', '?')}")
    return code


def _execute_code_sync(code: str, source: dict) -> dict:
    """Execute code synchronously (file I/O is inherently sync)."""
    with tempfile.NamedTemporaryFile(
        mode='w', suffix='.py', delete=False, encoding='utf-8'
    ) as tmp:
        tmp.write(_wrap_code_for_execution(code))
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True, text=True, encoding='utf-8',
            errors='replace', timeout=120, env=os.environ.copy()
        )

        if result.returncode == 0 and result.stdout and result.stdout.strip():
            return {
                "success": True,
                "output": result.stdout.strip(),
                "error": None,
                "code": code,
                "source": f"{source.get('file', '?')}::{source.get('sheet', '?')}"
            }
        else:
            error_msg = result.stderr if result.returncode != 0 else "Code ran but produced NO output."
            return {
                "success": False,
                "output": result.stdout,
                "error": error_msg,
                "code": code,
                "source": f"{source.get('file', '?')}::{source.get('sheet', '?')}"
            }
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


async def _process_source_async(
    client,
    source: dict,
    context: str,
    query: str,
    file_registry: dict,
    business_formulas: str,
    model_name: str,
    max_tokens: int
) -> dict:
    """Process single source: async code gen → sync execution."""
    source_key = f"{source.get('file', '?')}::{source.get('sheet', '?')}"
    # Removed verbose logging for performance

    try:
        # Step 1: Async code generation (TRUE PARALLEL!)
        code = await _generate_code_async(
            client, query, context, source, file_registry,
            business_formulas, model_name, max_tokens
        )

        if not code:
            return {
                "success": False,
                "output": "",
                "error": "Code generation failed",
                "source": source_key
            }

        # Step 2: Sync execution (fast anyway ~5s)
        result = _execute_code_sync(code, source)

        pass  # Removed verbose logging for performance
        return result

    except Exception as e:
        logger.error(f"[ASYNC] Pipeline failed for {source_key}: {e}", exc_info=True)
        return {
            "success": False,
            "output": "",
            "error": str(e),
            "source": source_key
        }


async def _parallel_execute_async(
    selected_sources: list,
    per_source_contexts: dict,
    query: str,
    file_registry: dict,
    business_formulas: str,
    model_name: str,
    max_tokens: int
) -> list:
    """Execute all sources in TRUE parallel using asyncio.gather with shared HTTP client."""
    import httpx
    from core.settings import settings

    # Create ONE shared client for ALL parallel LLM calls (connection pooling!)
    async with httpx.AsyncClient(
        timeout=300.0,
        verify=not settings.bedrock_skip_tls_verify,
        limits=httpx.Limits(
            max_connections=settings.http_max_connections,
            max_keepalive_connections=settings.http_max_keepalive
        )
    ) as client:
        tasks = []

        for src in selected_sources:
            source_key = f"{src.get('file', '?')}::{src.get('sheet', '?')}"
            context = per_source_contexts.get(source_key, "")

            if not context:
                logger.warning(f"No context for {source_key}, skipping")
                continue

            task = _process_source_async(
                client=client,  # Pass shared client
                source=src,
                context=context,
                query=query,
                file_registry=file_registry,
                business_formulas=business_formulas,
                model_name=model_name,
                max_tokens=max_tokens
            )
            tasks.append(task)

        # Run ALL tasks concurrently (TRUE PARALLELISM with shared connection pool!)
        results = await asyncio.gather(*tasks, return_exceptions=True)

    # Convert exceptions to error dicts
    final_results = []
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            source_key = f"{selected_sources[i].get('file', '?')}::{selected_sources[i].get('sheet', '?')}"
            final_results.append({
                "success": False,
                "output": "",
                "error": str(result),
                "source": source_key
            })
        else:
            final_results.append(result)

    return final_results


def async_parallel_executor_node(state: PipelineState) -> dict:
    """
    ASYNC parallel executor - TRUE concurrency without GIL blocking.

    Expected speedup:
    - Old: 120s (40s × 3 sequential due to GIL)
    - New: ~45s (max of 3 parallel 40s calls + overhead)
    """
    from core.settings import settings

    query = state["query"]
    selected_sources = state.get("selected_sources", [])
    file_registry = state.get("file_registry", {})
    per_source_contexts = state.get("per_source_contexts", {})
    business_formulas = state.get("business_formulas_full_text", "")

    # Run async executor
    results = asyncio.run(_parallel_execute_async(
        selected_sources=selected_sources,
        per_source_contexts=per_source_contexts,
        query=query,
        file_registry=file_registry,
        business_formulas=business_formulas,
        model_name=settings.llm_model,
        max_tokens=settings.llm_max_tokens
    ))

    # Merge results
    successful = [r for r in results if r.get("success")]
    failed = [r for r in results if not r.get("success")]

    if not successful:
        error_msg = "All sources failed:\n" + "\n".join([
            f"  - {r.get('source')}: {r.get('error', 'Unknown')}" for r in failed
        ])
        return {
            "execution_result": {"success": False, "output": "", "error": error_msg, "code": ""},
            "success": False,
            "final_answer": error_msg
        }

    # Combine outputs
    combined_output = []
    for r in successful:
        combined_output.append(f"═══ {r.get('source', 'Unknown')} ═══\n{r.get('output', '')}")

    if failed:
        combined_output.append(f"\n⚠️ {len(failed)} source(s) failed:")
        for r in failed:
            combined_output.append(f"  - {r.get('source')}: {r.get('error', 'Unknown')[:100]}")

    final_output = "\n\n".join(combined_output)

    # Removed verbose logging for performance

    return {
        "execution_result": {
            "success": True,
            "output": final_output,
            "error": None,
            "code": f"# Async parallel execution of {len(successful)} sources"
        },
        "generated_code": f"# Async parallel execution of {len(successful)} sources",
        "final_answer": final_output,
        "success": True
    }
