"""Structure analyzer — loads structure artifacts for selected sheets from S3."""

from __future__ import annotations

import re
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from models.state import PipelineState
from helpers.file_registry import build_source_key, clear_profile_registry_cache
from core.settings import get_s3_paths
from core.structured_logging import get_logger
from helpers.s3_storage import (
    is_s3_uri,
    read_json,
    s3_object_exists,
    source_stem,
    structure_artifact_uri,
)

logger = get_logger(__name__)


def _canonical_name(value: str) -> str:
    """Normalize file/sheet names for fuzzy matching."""
    if not value:
        return ""
    value = source_stem(value) if Path(value).suffix.lower() in (".xlsx", ".xls", ".csv", ".json") or is_s3_uri(value) else value
    value = re.sub(r"(_profile|_structure)$", "", value, flags=re.IGNORECASE)
    # Remove ALL whitespace, underscores, hyphens for better fuzzy matching
    # This allows "BrandF" to match "Brand Family" and "BRAND_SUB_FAMILY" to match "Brand Subfamily"
    return re.sub(r"[_\-\s]+", "", value).casefold().strip()


def _match_registry_file(file_name: str, file_registry: dict) -> tuple[str, dict]:
    """Return the best matching registry key/info for a requested file name."""
    if file_name in file_registry:
        return file_name, file_registry[file_name]

    want = _canonical_name(file_name)
    best_match: tuple[str, dict] | None = None
    best_len = -1

    for key, value in file_registry.items():
        have = _canonical_name(key)
        if not want:
            continue
        if want == have:
            return key, value
        if want in have or have in want:
            if len(have) > best_len:
                best_match = (key, value)
                best_len = len(have)

    return best_match if best_match is not None else (file_name, {})


def _match_sheet_name(sheet_name: str, sheet_map: dict) -> str:
    """Return the best matching sheet name from a profiled sheet map."""
    if sheet_name in sheet_map:
        return sheet_name

    want = _canonical_name(sheet_name)
    for key in sheet_map:
        have = _canonical_name(key)
        if want and (want in have or have in want):
            return key

    return sheet_name


def _normalize_selected_sources(state: PipelineState, file_registry: dict) -> list[dict]:
    """Normalize source selections from either validated or raw node2 output."""
    raw_sources = state.get("selected_sources") or []
    if not raw_sources:
        mapping_result = state.get("mapping_result") or {}
        raw_sources = (
            mapping_result.get("selected_sources")
            or mapping_result.get("file_and_sheet_mapping")
            or state.get("file_and_sheet_mapping")
            or []
        )

    normalized = []
    seen = set()

    for src in raw_sources:
        file_name = src.get("file") or src.get("file_name") or ""
        sheet_name = src.get("sheet") or src.get("tab_name") or ""
        if not file_name or not sheet_name:
            continue

        item = {
            "file": file_name,
            "sheet": sheet_name,
            "file_path": src.get("file_path", ""),
            "reason": src.get("reason") or src.get("why") or "",
            "granularity_type": src.get("granularity_type", ""),
            # Business context for context_builder
            "description": src.get("description", ""),
            "business_facts": src.get("business_facts", ""),
            "catalog_columns": src.get("catalog_columns", ""),
        }

        dedupe_key = (item["file"].casefold(), item["sheet"].casefold())
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        normalized.append(item)

    if state.get("analyze_all_sheets", False):
        expanded = []
        expanded_seen = set()
        for src in normalized:
            matched_file_name, matched_file_info = _match_registry_file(src["file"], file_registry)
            sheet_map = matched_file_info.get("profile", {}).get("sheets", {})
            if not sheet_map:
                dedupe_key = (src["file"].casefold(), src["sheet"].casefold())
                if dedupe_key not in expanded_seen:
                    expanded_seen.add(dedupe_key)
                    expanded.append(src)
                continue

            for sheet_name in sheet_map:
                dedupe_key = (matched_file_name.casefold(), sheet_name.casefold())
                if dedupe_key in expanded_seen:
                    continue
                expanded_seen.add(dedupe_key)
                expanded.append({
                    **src,
                    "file": matched_file_name,
                    "sheet": sheet_name,
                    "reason": src.get("reason") or "Expanded to all sheets for selected file",
                })
        normalized = expanded

    if not normalized:
        for file_name, file_info in file_registry.items():
            for sheet_name in file_info.get("profile", {}).get("sheets", {}):
                normalized.append({
                    "file": file_name,
                    "sheet": sheet_name,
                    "file_path": file_info.get("file_path", ""),
                    "reason": "Fallback: analyze all profiled sheets",
                    "granularity_type": "",
                    # No business context for fallback
                    "description": "",
                    "business_facts": "",
                    "catalog_columns": "",
                })

    return normalized


def _load_single_sheet_structure(
    *,
    file_name: str,
    file_path: str,
    sheet_name: str,
    file_hash: str,
    output_dir: str,
    user_jwt_token: str = None,
) -> dict:
    """Load a single structure artifact from S3."""
    # Structure files are in PROFILE_DIR (metadata/dynamic/), use user-specific API
    paths = get_s3_paths(user_jwt_token)
    structure_dir = paths.get('PROFILE_DIR', '')

    if not is_s3_uri(structure_dir):
        raise ValueError(
            f"Structure loading is S3-only for this pipeline. Received non-S3 structure_dir: {structure_dir}"
        )

    structure_uri = structure_artifact_uri(structure_dir, file_path, sheet_name)
    if not s3_object_exists(structure_uri):
        raise FileNotFoundError(
            f"Missing structure artifact for {file_name}::{sheet_name}: {structure_uri}"
        )
    structure = read_json(structure_uri)

    # Validate file hash if both profile and structure have it
    structure_hash = structure.get("file_hash") or ""
    profile_hash = file_hash or ""

    # Only validate if at least one hash is present
    if structure_hash or profile_hash:
        if structure_hash != profile_hash:
            logger.warning(
                "Structure artifact hash mismatch for %s::%s: profile_hash=%s, structure_hash=%s (URI: %s)",
                file_name, sheet_name, profile_hash, structure_hash, structure_uri
            )
            # Don't raise error - many older artifacts don't have file_hash field
            # raise ValueError(
            #     f"Structure artifact hash mismatch for {file_name}::{sheet_name}: {structure_uri}"
            # )

    structure["file_name"] = file_name
    structure["sheet"] = sheet_name
    return structure


def structure_analyzer_node(state: PipelineState) -> dict:
    """Load structure artifacts for all selected sources from S3."""
    file_registry = state.get("file_registry", {})
    
    # Extract JWT token for user-specific month tracking
    user_jwt_token = state.get("user_jwt_token")
    if user_jwt_token:
        logger.info("✅ Using user-specific month for structure loading")
    else:
        logger.warning("⚠️ No JWT token found - using system default month")

    # Get dynamic path from user-specific API
    paths = get_s3_paths(user_jwt_token)
    profile_dir_dynamic = paths.get('PROFILE_DIR', '')

    output_dir = state.get("output_dir") or profile_dir_dynamic
    excel_files = tuple(state.get("excel_files", []))

    if not is_s3_uri(output_dir):
        raise ValueError(f"Expected S3 output_dir for structure artifacts, got: {output_dir}")

    # OPTIMIZATION: Lazy-load profiler ONLY for selected files
    if not file_registry:
        try:
            from nodes import node2 as _node2
            from pathlib import Path

            # First get selected sources to know which files we need (without registry)
            selected_sources_preview = _normalize_selected_sources(state, {})

            # Extract unique file names/paths from selected sources
            selected_file_paths = set()
            for src in selected_sources_preview:
                file_name = src.get("file", "")
                file_path = src.get("file_path", "")

                # Prefer file_path if available, else try to match file_name against excel_files
                if file_path:
                    selected_file_paths.add(file_path)
                elif file_name:
                    # Try to find matching path from excel_files list
                    for ef in excel_files:
                        ef_stem = Path(ef).stem.lower().replace("_", " ").replace("-", " ")
                        fn_stem = Path(file_name).stem.lower().replace("_", " ").replace("-", " ")
                        if fn_stem in ef_stem or ef_stem in fn_stem:
                            selected_file_paths.add(ef)
                            break

            # Load ONLY profilers for selected files (not all files!)
            selected_files_tuple = tuple(selected_file_paths) if selected_file_paths else excel_files

            # Removed verbose logging for performance

            # Clear cache to ensure fresh profile data
            clear_profile_registry_cache()

            # Load profiles ONLY for selected files using dynamic API Gateway path
            file_registry = _node2.load_profile_registry(profile_dir_dynamic, selected_files_tuple, user_jwt_token)
        except Exception as e:
            logger.warning("Could not auto-load profile registry from PROFILE_DIR: %s", e)

    selected_sources = _normalize_selected_sources(state, file_registry)

    structures = state.get("structures", {})
    updated_registry = dict(file_registry)

    # ═══════════════════════════════════════════════════════════════════
    # PARALLEL S3 STRUCTURE LOADING
    # ═══════════════════════════════════════════════════════════════════
    # Load structure artifacts in parallel using ThreadPoolExecutor.
    # Pure I/O-bound operation (S3 GET requests), no LLM calls.
    # S3 scales to 5,500 GET/s per prefix - safe to use 5+ workers.
    # Boto3 client is thread-safe, no resource contention concerns.
    # ═══════════════════════════════════════════════════════════════════

    def _load_structure_for_source(idx: int, src: dict, user_jwt_token: str = None) -> tuple:
        """Load structure artifact for a single source (thread worker function)."""
        file_name = src["file"]
        sheet_name = src["sheet"]
        requested_file_path = src.get("file_path", "")

        # Fuzzy match file name in registry
        matched_file_name, file_info = _match_registry_file(file_name, file_registry)
        profile = file_info.get("profile", {})

        # Fuzzy match sheet name in profile
        actual_sheet_name = _match_sheet_name(sheet_name, profile.get("sheets", {}))
        sheet_info = profile.get("sheets", {}).get(actual_sheet_name, {})

        file_path_used = requested_file_path or file_info.get("file_path", "") or matched_file_name
        source_key = build_source_key(file_path_used, actual_sheet_name)
        file_hash = file_info.get("file_hash", "")

        if not sheet_info:
            logger.warning("  No profile for %s::%s", file_name, sheet_name)
            return idx, None, None, None, None, None

        # Load structure from S3 (blocking I/O - this is what we parallelize)
        structure = _load_single_sheet_structure(
            file_name=matched_file_name,
            file_path=file_path_used,
            sheet_name=actual_sheet_name,
            file_hash=file_hash,
            output_dir=output_dir,
            user_jwt_token=user_jwt_token,
        )

        # Return all needed data for assembly phase
        return (
            idx,
            source_key,
            structure,
            matched_file_name,
            file_path_used,
            actual_sheet_name,
        )

    # Track timing for performance monitoring
    start_time = time.time()
    load_times = []

    # Parallel loading phase
    # Use up to 5 workers (S3 has no rate limits, thread-safe Boto3 client)
    max_workers = min(5, len(selected_sources) or 1)
    results = [None] * len(selected_sources)

    # Removed verbose logging for performance

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        # Submit all load tasks
        futures = {
            pool.submit(_load_structure_for_source, i, src, user_jwt_token): i
            for i, src in enumerate(selected_sources)
        }

        # Collect results as they complete
        for future in as_completed(futures):
            idx = futures[future]
            try:
                load_start = time.time()
                result = future.result()
                load_elapsed = time.time() - load_start
                load_times.append(load_elapsed)
                results[idx] = result
            except Exception as e:
                logger.error(f"  Failed to load structure for source {idx}: {e}")
                results[idx] = (idx, None, None, None, None, None)

    # Assembly phase - update structures dict and registry (fast, order-dependent)
    for idx, result in enumerate(results):
        if result is None:
            continue

        idx_val, source_key, structure, matched_file_name, file_path_used, actual_sheet_name = result

        if structure is None:
            continue

        # Update structures dict
        structures[source_key] = structure

        # Update registry with structure
        if matched_file_name in updated_registry:
            if "structures" not in updated_registry[matched_file_name]:
                updated_registry[matched_file_name]["structures"] = {}
            updated_registry[matched_file_name]["structures"][actual_sheet_name] = structure

        # Update source with corrected names
        selected_sources[idx]["file"] = matched_file_name
        selected_sources[idx]["file_path"] = file_path_used
        selected_sources[idx]["sheet"] = actual_sheet_name

    # Removed verbose performance logging

    return {
        "structures": structures,
        "file_registry": updated_registry,
        "selected_sources": selected_sources,
    }
