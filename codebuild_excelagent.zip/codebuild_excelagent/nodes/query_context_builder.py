"""
Query context builder — builds focused, query-aware context from all selected sources.
Supports multi-file queries with cross-file context.
"""

import re
import json
import time
from pathlib import Path
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor, as_completed
import boto3

from openpyxl.utils import get_column_letter
from langchain_core.messages import HumanMessage, SystemMessage

from claude_setup.llm import get_model
from models.state import PipelineState
from helpers.file_registry import build_source_key, load_glossary_index
from core.structured_logging import get_logger
from prompts.system_prompts import query_context_builder_system
from prompts.user_prompts import build_query_context_match_prompt
from core.timing import timed
from core.settings import get_s3_paths, get_formula_files_for_sources, load_formula_file_from_s3

logger = get_logger(__name__)


def _load_business_formulas_for_sources(selected_sources: List[dict], paths: dict) -> dict:
    """
    Load relevant formula files based on selected sources.
    Uses fuzzy matching on filenames (no metadata loading needed).
    Returns dict with loaded formulas keyed by filename.
    """
    try:
        # Get available files from API
        available_files = paths.get('BUSINESS_FORMULAS_FILES', [])
        validation = paths.get('BUSINESS_FORMULAS_VALIDATION', {})

        if not validation.get('valid'):
            logger.warning("Formula files validation failed")
            return {}

        # Determine which files to load (uses fuzzy matching on filenames)
        files_to_load = get_formula_files_for_sources(selected_sources, available_files)

        if not files_to_load:
            return {}

        # Load files from S3 in PARALLEL for better performance
        from concurrent.futures import ThreadPoolExecutor, as_completed

        loaded_formulas = {}
        total_bytes = 0

        def load_single_formula(file_info):
            """Load a single formula file from S3."""
            filename = file_info['filename']
            s3_uri = file_info['s3_uri']
            try:
                content = load_formula_file_from_s3(s3_uri)
                return filename, content, file_info['size_bytes'], None
            except Exception as e:
                return filename, None, 0, str(e)

        # Load all files in parallel (up to 5 concurrent S3 reads)
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = {executor.submit(load_single_formula, fi): fi for fi in files_to_load}

            for future in as_completed(futures):
                filename, content, size, error = future.result()
                if error:
                    logger.error(f"Failed to load {filename}: {error}")
                else:
                    loaded_formulas[filename] = content
                    total_bytes += size

        return loaded_formulas

    except Exception as e:
        logger.error(f"Failed to load business formulas: {e}")
        return {}


def _format_business_formulas_full(loaded_formulas: dict) -> str:
    """
    Format ALL loaded formula content using NEW standardized JSON schema (v1).
    Reads labels (CRITICAL, WARNING, INFO) from JSON instead of hardcoding in Python.
    This makes the code future-proof - new files/sections work automatically!

    Schema structure expected in JSON:
    {
        "file_metadata": {"name": "...", "description": "...", "priority": "..."},
        "sections": {
            "section_key": {
                "title": "...",
                "priority": "CRITICAL|WARNING|INFO",
                "description": "...",
                "items": [
                    {
                        "name": "...",
                        "type": "CRITICAL|WARNING|INFO",
                        "formula": "...",
                        "code": "...",
                        "warnings": [...],
                        "example": "...",
                        etc.
                    }
                ]
            }
        }
    }
    """
    if not loaded_formulas:
        return ""

    formula_text = "\n" + "═" * 70 + "\n"
    formula_text += "BUSINESS FORMULAS - USE THESE EXACT CALCULATIONS\n"
    formula_text += "═" * 70 + "\n\n"

    section_num = 1

    # Process ALL files generically (no hardcoded filenames!)
    for filename, content in loaded_formulas.items():

        # File-level metadata
        file_meta = content.get("file_metadata", {})
        file_name = file_meta.get("name", filename)
        file_priority = file_meta.get("priority", "")

        # Show file header if it has multiple sections
        sections = content.get("sections", {})
        if len(sections) > 1:
            formula_text += f"\n{'─' * 70}\n"
            if file_priority:
                formula_text += f"[{file_priority}] FROM {file_name.upper()}\n"
            else:
                formula_text += f"FROM {file_name.upper()}\n"
            formula_text += f"{'─' * 70}\n"

        # Process sections
        for section_key, section_data in sections.items():
            title = section_data.get("title", section_key)
            priority = section_data.get("priority", "")
            desc = section_data.get("description", "")

            # Section header
            formula_text += f"\n{section_num}. {title.upper()}"
            if priority:
                formula_text += f" ({priority})"
            formula_text += ":\n"

            if desc:
                formula_text += f"   {desc}\n"

            section_num += 1

            # Process items
            items = section_data.get("items", [])
            for item in items:
                formula_text += _format_item(item, indent=1)

            formula_text += "\n"

    formula_text += "═" * 70 + "\n\n"
    return formula_text


def _format_item(item: dict, indent: int = 1) -> str:
    """
    Format a single formula/rule item from new schema.
    Reads type/priority labels from JSON itself!
    """
    prefix = "   " * indent
    text = ""

    # Name/Title with type label
    name = item.get("name", "")
    item_type = item.get("type", "")

    if name:
        if item_type and item_type in ("CRITICAL", "WARNING"):
            text += f"{prefix}[{item_type}] {name}:\n"
        else:
            text += f"{prefix}• {name}:\n"

    # Formula / Rule / Definition
    formula = item.get("formula") or item.get("rule") or item.get("definition", "")
    if formula:
        text += f"{prefix}  Formula: {formula}\n"

    # Code
    code = item.get("code", "")
    if code:
        text += f"{prefix}  Code: {code}\n"

    # Unit
    unit = item.get("unit", "")
    if unit:
        text += f"{prefix}  Unit: {unit}\n"

    # Why (reasoning)
    why = item.get("why", "")
    if why:
        text += f"{prefix}  Why: {why}\n"

    # Description (if present and name already shown)
    description = item.get("description", "")
    if description and name:
        text += f"{prefix}  {description}\n"

    # Example
    example = item.get("example", "")
    if example:
        if isinstance(example, dict):
            ex_desc = example.get("description", "")
            if ex_desc:
                text += f"{prefix}  Example: {ex_desc}\n"
            if 'values' in example:
                text += f"{prefix}    Values: {example['values']}\n"
            if 'calculation' in example:
                text += f"{prefix}    Calculation: {example['calculation']}\n"
            if 'code' in example:
                text += f"{prefix}    Code: {example['code']}\n"
        else:
            text += f"{prefix}  Example: {example}\n"

    # Warnings (CRITICAL/WARNING from JSON!)
    warnings = item.get("warnings", [])
    if warnings:
        for warning in warnings:
            text += f"{prefix}  WARNING: {warning}\n"

    # Steps
    steps = item.get("steps", [])
    if steps:
        text += f"{prefix}  Steps:\n"
        for step in steps:
            text += f"{prefix}    - {step}\n"

    # Condition
    condition = item.get("condition", "")
    if condition:
        text += f"{prefix}  Condition: {condition}\n"

    # Correct vs Wrong approaches
    wrong = item.get("wrong_approach", "")
    correct = item.get("correct_approach", "")
    if wrong:
        text += f"{prefix}  WRONG: {wrong}\n"
    if correct:
        text += f"{prefix}  CORRECT: {correct}\n"

    # Components (for P&L)
    components = item.get("components", [])
    if components:
        text += f"{prefix}  Components: {', '.join(components)}\n"

    # Definitions/Terms (for units, terminology)
    definitions = item.get("definitions", [])
    if definitions:
        for defn in definitions:
            if isinstance(defn, dict):
                unit_name = defn.get("unit", "")
                desc = defn.get("description", "")
                text += f"{prefix}  • {unit_name}: {desc}\n"

    terms = item.get("terms", [])
    if terms:
        for term in terms:
            if isinstance(term, dict):
                term_name = term.get("term", "")
                meaning = term.get("meaning", "")
                text += f"{prefix}  • {term_name}: {meaning}\n"

    # Workflow (for brand family)
    workflow = item.get("workflow", [])
    if workflow:
        for step in workflow:
            text += f"{prefix}  - {step}\n"

    # Note
    note = item.get("note", "")
    if note:
        text += f"{prefix}  Note: {note}\n"

    return text


def _assess_context_confidence(
    query: str,
    all_filters: List[dict],
    all_measures: List[str],
    selected_sources: List[dict],
) -> dict:
    """
    Assess confidence in the query context match.

    Factors:
    1. Column relevance: How many filter/measure columns were found?
    2. Data coverage: Are we missing critical columns?
    3. Query complexity vs data structure alignment
    """

    # Extract query keywords (simple approach)
    query_lower = query.lower()
    query_words = set(re.findall(r'\b\w+\b', query_lower))

    # Filter relevance score (0-100)
    filter_score = 100
    if all_filters:
        # Have filters - high confidence
        filter_score = min(100, 80 + len(all_filters) * 5)
    elif any(word in query_words for word in ['where', 'filter', 'only', 'specific']):
        # Query implies filters but none found
        filter_score = 50

    # Measure relevance score (0-100)
    measure_score = 100
    if all_measures:
        # Have measures - high confidence
        measure_score = min(100, 80 + len(all_measures) * 5)
    elif any(word in query_words for word in ['total', 'sum', 'average', 'count']):
        # Query implies measures but none found
        measure_score = 60

    # Data availability score (0-100) - based on number of sources
    availability_score = 90
    if not selected_sources:
        availability_score = 0
    elif len(selected_sources) == 1:
        availability_score = 95
    else:
        # Multi-source - slightly less confident
        availability_score = 85

    # Overall confidence (weighted average)
    overall = int((filter_score * 0.3 + measure_score * 0.4 + availability_score * 0.3))

    # Build details message
    details_parts = []
    if all_filters:
        details_parts.append(f"{len(all_filters)} filter column(s) matched")
    if all_measures:
        details_parts.append(f"{len(all_measures)} measure column(s) found")
    details_parts.append(f"{len(selected_sources)} source(s) selected")

    details = ". ".join(details_parts) + "."

    potential_issues = []
    if filter_score < 70:
        potential_issues.append("Some expected filter columns may be missing")
    if measure_score < 70:
        potential_issues.append("Some measure columns may not be explicitly identified")
    if len(selected_sources) > 3:
        potential_issues.append("Query spans many sources - may be complex")

    return {
        "overall_confidence": overall,
        "column_relevance_score": int((filter_score + measure_score) / 2),
        "details": details,
        "potential_issues": potential_issues if potential_issues else ["None"],
    }


def _build_source_context(
    file_name: str,
    file_path: str,
    sheet_name: str,
    sheet_info: dict,
    structure: dict,
    user_query: str,
    model,
    business_description: str = "",
    business_facts: str = "",
    catalog_columns: str = "",
    current_month_info: dict = None,
    business_formulas_text: str = "",
    user_jwt_token: str = None
) -> dict:
    """
    Build query-matched context for a single source.
    Returns match_result dict.

    Args:
        business_description: High-level purpose from catalog
        business_facts: Business context and calculation guidance from catalog
        catalog_columns: Generic column names from catalog
        current_month_info: Current reporting period from API
        business_formulas_text: Formatted business formulas (from loaded formula files)
    """

    # ── Glossary Section (domain terminology) ────────────────────────
    glossary_section = ""
    try:
        glossary = load_glossary_index(user_jwt_token) if user_jwt_token else {}
        if glossary:
            glossary_lines = ["GLOSSARY (Domain Terms - PMI Business Terminology):"]
            # Sort by canonical term for readability
            sorted_entries = sorted(glossary.values(), key=lambda x: x["canonical"].lower())
            for entry in sorted_entries:
                term = entry["term"]
                canonical = entry["canonical"]
                # Only include if they're different (avoid redundant entries)
                if term.lower() != canonical.lower():
                    glossary_lines.append(f"  {term} = {canonical}")

            if len(glossary_lines) > 1:  # Has entries beyond header
                glossary_section = "\n".join(glossary_lines) + "\n\n"
    except Exception as e:
        logger.warning("  Failed to load glossary: %s", e)

    # ── Business Formulas Section ────────────────────────────────────────
    # Use the FULL version (same as code generator - single source of truth)
    formulas_section = business_formulas_text

    # ── Business Context Section (from catalog) ──────────────────────
    business_context_section = ""
    if business_description or business_facts or catalog_columns:
        business_context_section = "BUSINESS CONTEXT (from catalog):\n"
        if business_description:
            business_context_section += f"Description: {business_description}\n\n"
        if business_facts:
            business_context_section += f"Business Facts:\n{business_facts}\n\n"
        if catalog_columns:
            business_context_section += f"Expected Columns (generic): {catalog_columns}\n\n"
        business_context_section += (
            "IMPORTANT: The catalog columns are generic labels."
            "You MUST use the ACTUAL column positions and values from the structure below.\n\n"
        )

    # ── Header rows section ──────────────────────────────────────────
    # Always show the actual header row content so the LLM knows EXACT
    # column positions for multi-row headers (e.g. "Due to | Mix" at col T).
    # Show up to 3 rows - most files have headers in rows 1-3, rows 4+ are data (already in sample_rows)
    header_lines = []
    transition_rows = sheet_info.get("transition_rows", [])
    for tr in transition_rows[:7]: 
        row_num = tr.get("excel_row", "?")
        content = tr.get("content", [])
        col_parts = []
        for i, val in enumerate(content):
            if val is not None:
                col_letter_h = get_column_letter(i + 1)
                col_parts.append(f"{col_letter_h}(#{i+1})='{val}'")
        if col_parts:
            header_lines.append(f"  Excel Row {row_num}: {', '.join(col_parts)}")
    header_section = (
        "HEADER ROWS (use these for exact column positions):\n"
        + ("\n".join(header_lines) if header_lines else "  (none captured)")
    )

    # ── Value catalog ─────────────────────────────────────────────────
    # Include text/mixed columns (data values) AND numeric columns whose
    # unique_texts are non-empty (those are the header labels for numeric cols).
    value_catalog_lines = []
    for col_letter, cp in sheet_info.get("column_profiles", {}).items():
        col_type = cp.get("type", "")
        unique_texts = cp.get("unique_texts", [])

        if col_type in ("text", "mixed") and unique_texts:
            texts = unique_texts
            if len(texts) > 200:
                vals_str = ", ".join(f"'{v}'" for v in texts[:200])
                vals_str += f" ... (+{len(texts) - 200} more)"
            else:
                vals_str = ", ".join(f"'{v}'" for v in texts)
            value_catalog_lines.append(
                f"Column {col_letter}: "
                f"{len(unique_texts)} unique values\n  Values: {vals_str}"
            )
        elif col_type == "numeric" and unique_texts:
            # These are header labels sitting in an otherwise numeric column.
            # Show them so the LLM can map query terms to the right column.
            vals_str = ", ".join(f"'{v}'" for v in unique_texts[:10])
            value_catalog_lines.append(
                f"Column {col_letter}: "
                f"[NUMERIC — header labels: {vals_str}]"
            )

    value_catalog = glossary_section + formulas_section + business_context_section + header_section + "\n\nCOLUMN VALUE CATALOG:\n" + "\n".join(value_catalog_lines)

    # Table descriptions
    tables = structure.get("tables", [])
    table_desc_lines = []
    for t in tables:
        table_desc_lines.append(
            f"Table '{t.get('name', '?')}': "
            f"header rows {t.get('header_rows')}, "
            f"data rows {t.get('data_start_row')}-{t.get('data_end_row')}, "
            f"label cols {t.get('label_columns')}, "
            f"data cols {t.get('data_columns')}"
        )
    table_desc = "\n".join(table_desc_lines)

    # Sample rows
    sample_lines = []
    for sr in sheet_info.get("sample_rows", []):
        col_letters = [get_column_letter(i + 1) for i in range(len(sr.get("content", [])))]
        parts = []
        for cl, val in zip(col_letters, sr.get("content", [])):
            if val is not None:
                parts.append(f"{cl}='{val}'")
        sample_lines.append(f"  Row {sr.get('excel_row', '?')}: {', '.join(parts)}")
    samples_text = "\n".join(sample_lines)

    # LLM matching WITH STREAMING
    messages = [
        SystemMessage(content=query_context_builder_system(current_month_info)),
        HumanMessage(content=build_query_context_match_prompt(
            user_query, file_name, sheet_name, table_desc, value_catalog, samples_text
        )),
    ]

    with timed(f"LLM_CALL query_context_builder({file_name}::{sheet_name})"):
        # Note: This runs in ThreadPoolExecutor (sync context), so we use sync stream()
        # The node itself will be async, but the parallel workers are sync
        full_response = []
        for token in model.stream(messages):
            full_response.append(token)

        response_text = "".join(full_response)

        # Create response object with content attribute
        class Response:
            def __init__(self, content):
                self.content = content

        response = Response(response_text)

    json_match = re.search(r'\{.*\}', response.content, re.DOTALL)
    match_result = {}
    if json_match:
        try:
            match_result = json.loads(json_match.group())
        except json.JSONDecodeError:
            raw = json_match.group()
            raw = re.sub(r',\s*}', '}', raw)
            raw = re.sub(r',\s*]', ']', raw)
            try:
                match_result = json.loads(raw)
            except Exception as e:
                logger.warning("Failed to parse LLM response for %s::%s: %s", file_name, sheet_name, e)
                match_result = {}

    return match_result


def _build_focused_context(
    file_name: str,
    file_path: str,
    sheet_name: str,
    sheet_info: dict,
    structure: dict,
    match_result: dict
) -> str:
    """Build the focused context string for code generation."""
    tables = structure.get("tables", [])

    # Find target table
    target_table = None
    target_name = match_result.get("target_table") or ""
    for t in tables:
        if t.get("name", "").lower() == target_name.lower():
            target_table = t
            break
    if target_table is None and tables:
        target_table = tables[0]

    ctx_lines = []
    ctx_lines.append(f"SOURCE: {file_name} :: '{sheet_name}'")
    ctx_lines.append(f"FILE: r\"{file_path}\"")
    ctx_lines.append("")

    if target_table:
        ctx_lines.append("TARGET TABLE:")
        ctx_lines.append(f"  Name: {target_table.get('name', 'Main')}")
        ctx_lines.append(f"  Header rows: {target_table.get('header_rows', [1])}")
        data_start = target_table.get('data_start_row', 2)
        data_end = target_table.get('data_end_row', 0)
        if data_end and data_end > 0:
            ctx_lines.append(f"  Data rows: {data_start} to {data_end}")
        else:
            ctx_lines.append(f"  Data start row: {data_start}")
        ctx_lines.append(f"  Label columns: {target_table.get('label_columns', [])}")
        ctx_lines.append(f"  Data/numeric columns: {target_table.get('data_columns', [])}")
        ctx_lines.append("")

    # Relevant columns
    relevant_cols = set()
    for mf in match_result.get("matched_filters", []):
        relevant_cols.add(mf.get("column", ""))
    for mc in match_result.get("measure_columns", []):
        relevant_cols.add(mc.get("column", ""))

    ctx_lines.append("RELEVANT COLUMNS:")
    for col_letter, cp in sheet_info.get("column_profiles", {}).items():
        if col_letter in relevant_cols or not relevant_cols:
            ctx_lines.append(
                f"  Column {col_letter}: type={cp.get('type', '?')}"
            )
            if cp.get("unique_texts") and cp.get("type") in ("text", "mixed"):
                vals = ", ".join(f"'{v}'" for v in cp["unique_texts"][:100])
                ctx_lines.append(f"    Unique values: {vals}")
    ctx_lines.append("")

    # Matched filters
    ctx_lines.append("QUERY MATCHING (use these EXACT values in code):")
    for mf in match_result.get("matched_filters", []):
        ctx_lines.append(
            f"  User said: '{mf.get('user_term')}' -> "
            f"Filter column {mf.get('column')} (#{mf.get('column_number')}) "
            f"for EXACT value: '{mf.get('exact_value')}'"
        )
    ctx_lines.append("")

    # Operation
    ctx_lines.append("OPERATION NEEDED:")
    ctx_lines.append(
        f"  {match_result.get('operation', 'analyze')}: "
        f"{match_result.get('operation_detail', '')}"
    )
    ctx_lines.append("")

    # Measure columns
    ctx_lines.append("MEASURE COLUMNS:")
    for mc in match_result.get("measure_columns", []):
        ctx_lines.append(
            f"  Column {mc.get('column')} (#{mc.get('column_number')}): "
            f"{mc.get('description', '')}"
        )
    ctx_lines.append("")

    # Sample rows
    ctx_lines.append("SAMPLE ROWS:")
    for sr in sheet_info.get("sample_rows", []):
        col_letters = [get_column_letter(i + 1) for i in range(len(sr.get("content", [])))]
        parts = []
        for cl, val in zip(col_letters, sr.get("content", [])):
            if val is not None:
                parts.append(f"{cl}='{val}'")
        ctx_lines.append(f"  Row {sr.get('excel_row', '?')}: {', '.join(parts)}")
    ctx_lines.append("")

    # Merged cells
    relevant_merges = [
        mc for mc in sheet_info.get("merged_cells", [])
        if mc.get("start_col_letter") in relevant_cols
        or mc.get("merge_type") == "vertical"
    ]
    if relevant_merges:
        ctx_lines.append("MERGED CELLS:")
        for mc in relevant_merges[:20]:
            ctx_lines.append(f"  '{mc.get('value')}' | {mc.get('range')} | {mc.get('merge_type')}")
        ctx_lines.append("")

    # Hierarchies - handle both old array format and new top-level format
    hierarchies = structure.get("hierarchies", [])
    if hierarchies:
        # Old format: hierarchies is an array
        for h in hierarchies:
            ctx_lines.append(
                f"HIERARCHY: {h.get('type')} in column {h.get('column')} — "
                f"{h.get('description')}"
            )
    elif structure.get("type") and structure.get("column"):
        # New format: hierarchy at top-level
        ctx_lines.append(
            f"HIERARCHY: {structure.get('type')} in column {structure.get('column')} — "
            f"{structure.get('description', '')}"
        )
    if hierarchies or structure.get("type"):
        ctx_lines.append("")

    # Code instructions
    header_rows = target_table.get("header_rows", [1]) if target_table else [1]
    ctx_lines.append("CODE INSTRUCTIONS:")
    ctx_lines.append(
        f"  1. df = pd.read_excel(r\"{file_path}\", "
        f"sheet_name=\"{sheet_name}\", header=None)"
    )
    ctx_lines.append(f"  2. df.iloc[R-1, C-1] for Excel Row R, Column C")
    ctx_lines.append(f"  3. Header rows: {header_rows}")

    # Conditional ffill instruction based on data source (changed for merge cell for illicit - 25-06-2026)
    # Nielsen/Industry/Competitor data has flat structure - do NOT use ffill()
    if any(keyword in sheet_name.lower() for keyword in ['nielsen', 'industry', 'illicit', 'competitor']):
        ctx_lines.append(f"  4. DO NOT use .ffill() - this data source has flat structure")
    else:
        ctx_lines.append(f"  4. For merged cells: use df.iloc[:, col].ffill()")

    ctx_lines.append(f"  5. Filter using EXACT values from QUERY MATCHING above")
    ctx_lines.append(f"  6. Print clear, labeled results")

    return "\n".join(ctx_lines)


def query_context_builder_node(state: PipelineState) -> dict:
    """
    Build query-aware context for ALL selected sources.
    Combines contexts if cross-file query.
    """
    query = state["query"]
    selected_sources = state.get("selected_sources", [])
    file_registry = state.get("file_registry", {})
    structures = state.get("structures", {})
    requires_cross_file = state.get("requires_cross_file", False)

    # Extract JWT token for user-specific month tracking
    user_jwt_token = state.get("user_jwt_token")
    
    # Fetch current month from user-specific API
    from core.settings import get_current_month
    current_month_info = get_current_month(user_jwt_token)

    # ═══════════════════════════════════════════════════════════════════
    # LOAD BUSINESS FORMULAS (ONCE) - Selective loading based on sources
    # ═══════════════════════════════════════════════════════════════════
    # Extract JWT token for user-specific month tracking
    user_jwt_token = state.get("user_jwt_token")
    paths = get_s3_paths(user_jwt_token)
    loaded_formulas = _load_business_formulas_for_sources(selected_sources, paths)

    # Format FULL version - used by BOTH context builder AND code generator
    business_formulas_full_text = _format_business_formulas_full(loaded_formulas)

    # Removed verbose logging for performance

    model = get_model()
    all_contexts = []
    all_column_usage: dict = {}
    all_filters = []
    all_measures = []

    # --- Phase 1: resolve file/sheet info for each source (cheap, sequential) ---
    prepared_sources = []
    for src in selected_sources:
        file_name = src["file"]
        sheet_name = src["sheet"]

        # Exact lookup first; fall back to canonical fuzzy match (handles .xlsx suffix,
        # underscore vs space, case differences from node2 output).
        file_info = file_registry.get(file_name, {})
        if not file_info:
            _want = re.sub(r"[_\-\s]+", " ", Path(file_name).stem).casefold()
            for _key, _val in file_registry.items():
                _have = re.sub(r"[_\-\s]+", " ", _key).casefold()
                if _want and (_want in _have or _have in _want):
                    file_info = _val
                    file_name = _key  # use canonical key for logging
                    break

        # ALWAYS use file_path from registry (has dynamic May 2026 path from API Gateway)
        # NEVER use file_path from src (has hardcoded December 2025 path)
        file_path = file_info.get("file_path", src.get("file_path", ""))

        profile = file_info.get("profile", {})

        # Exact sheet lookup; fall back to canonical fuzzy match.
        sheet_info = profile.get("sheets", {}).get(sheet_name, {})
        if not sheet_info:
            _want_s = re.sub(r"[_\-\s]+", " ", sheet_name).casefold()
            for _skey, _sval in profile.get("sheets", {}).items():
                _have_s = re.sub(r"[_\-\s]+", " ", _skey).casefold()
                if _want_s and (_want_s in _have_s or _have_s in _want_s):
                    sheet_info = _sval
                    sheet_name = _skey
                    break

        # Re-derive source_key after potential name corrections.
        source_key = build_source_key(file_path or file_name, sheet_name)
        structure = structures.get(source_key, {})

        if not sheet_info:
            logger.warning("  No profile for %s::%s", file_name, sheet_name)
            continue

        prepared_sources.append({
            "file_name": file_name,
            "file_path": file_path,
            "sheet_name": sheet_name,
            "sheet_info": sheet_info,
            "structure": structure,
            # Business context from mapping/sheet_selector
            "description": src.get("description", ""),
            "business_facts": src.get("business_facts", ""),
            "catalog_columns": src.get("catalog_columns", ""),
        })

    # --- Phase 2: parallel LLM calls for all sources ---
    match_results = [None] * len(prepared_sources)

    def _run_match(idx, ps):
        return idx, _build_source_context(
            file_name=ps["file_name"],
            file_path=ps["file_path"],
            sheet_name=ps["sheet_name"],
            sheet_info=ps["sheet_info"],
            structure=ps["structure"],
            user_query=query,
            model=model,
            # Business context from catalog
            business_description=ps.get("description", ""),
            business_facts=ps.get("business_facts", ""),
            catalog_columns=ps.get("catalog_columns", ""),
            current_month_info=current_month_info,
            # Business formulas (loaded once, passed to all sources)
            business_formulas_text=business_formulas_full_text,
            user_jwt_token=user_jwt_token,  # Pass JWT token for glossary loading
        )

    # Limit concurrent workers to 3 to avoid 503 rate limiting errors
    # NOTE: For multi-source independent queries, this is the ONLY expensive step
    # The parallel_executor will reuse these contexts for code gen
    with ThreadPoolExecutor(max_workers=min(3, len(prepared_sources) or 1)) as pool:
        futures = {
            pool.submit(_run_match, i, ps): i
            for i, ps in enumerate(prepared_sources)
        }
        for fut in as_completed(futures):
            try:
                idx, result = fut.result()
                match_results[idx] = result
            except RuntimeError as e:
                # Retry once on 503 Service Unavailable errors
                if "503" in str(e) or "Service Unavailable" in str(e):
                    idx = futures[fut]
                    logger.warning("503 error on source %d, retrying after 2s", idx)
                    time.sleep(2)
                    try:
                        idx, result = _run_match(idx, prepared_sources[idx])
                        match_results[idx] = result
                    except Exception as retry_error:
                        logger.error("  Retry failed for source %d: %s", idx, retry_error)
                        raise
                else:
                    raise

    # --- Phase 3: assemble contexts from results (cheap, sequential) ---
    for ps, match_result in zip(prepared_sources, match_results):
        file_name = ps["file_name"]
        file_path = ps["file_path"]
        sheet_name = ps["sheet_name"]
        sheet_info = ps["sheet_info"]
        structure = ps["structure"]

        all_filters.extend(match_result.get("matched_filters", []))
        all_measures.extend(match_result.get("measure_columns", []))

        # Build per-source column usage entry for backtracking visibility
        source_key_usage = f"{file_name}::{sheet_name}"
        all_column_usage[source_key_usage] = {
            "file": file_name,
            "sheet": sheet_name,
            "file_path": file_path,
            "filter_columns": [
                {"column": mf.get("column", ""), "column_number": mf.get("column_number", 0),
                 "exact_value": mf.get("exact_value", ""), "user_term": mf.get("user_term", "")}
                for mf in match_result.get("matched_filters", [])
            ],
            "measure_columns": [
                {"column": mc.get("column", ""), "column_number": mc.get("column_number", 0),
                 "description": mc.get("description", "")}
                for mc in match_result.get("measure_columns", [])
            ],
            "target_table": match_result.get("target_table", ""),
            "operation": match_result.get("operation", ""),
            "operation_detail": match_result.get("operation_detail", ""),
            "reasoning": match_result.get("reasoning", ""),
        }

        # Build focused context
        focused = _build_focused_context(
            file_name=file_name,
            file_path=file_path,
            sheet_name=sheet_name,
            sheet_info=sheet_info,
            structure=structure,
            match_result=match_result
        )
        all_contexts.append(focused)

    # Combine contexts
    if len(all_contexts) == 1:
        final_context = all_contexts[0]
    elif len(all_contexts) > 1:
        separator = f"\n{'─' * 60}\n"
        header = (
            "MULTI-SOURCE QUERY — The following sources are needed:\n"
            f"Number of sources: {len(all_contexts)}\n"
            "Generate code that reads from ALL sources and combines results.\n"
        )
        final_context = header + separator + separator.join(all_contexts)
        final_context += f"\n\nCROSS-FILE INSTRUCTIONS:\n"
        final_context += f"  1. Read each file separately with pd.read_excel()\n"
        final_context += f"  2. Apply filters to each DataFrame independently\n"
        final_context += f"  3. Combine or compare results as needed by the query\n"
        final_context += f"  4. Print a clear comparison or combined result\n"
    else:
        final_context = "No context available."

    # Try to get LLM-provided confidence from match results
    llm_confidences = []
    for mr in match_results:
        if mr and "overall_confidence" in mr:
            try:
                llm_confidences.append(int(mr["overall_confidence"]))
            except (ValueError, TypeError):
                pass

    # Use LLM confidence if available, otherwise calculate
    if llm_confidences:
        # Average of all source confidences
        overall_confidence = int(sum(llm_confidences) / len(llm_confidences))
        context_confidence = {
            "overall_confidence": overall_confidence,
            "column_relevance_score": overall_confidence,
            "details": f"LLM confidence from {len(llm_confidences)} source(s)",
            "potential_issues": [],
        }
    else:
        # Fallback: calculate from state data
        context_confidence = _assess_context_confidence(
            query=query,
            all_filters=all_filters,
            all_measures=all_measures,
            selected_sources=selected_sources,
        )

    # Build human-readable summary for frontend display
    context_builder_summary = f"Analyzed {len(selected_sources)} source(s): "
    if all_filters:
        filter_terms = [f.get('user_term', '') for f in all_filters if f.get('user_term')]
        context_builder_summary += f"Found {len(all_filters)} filter(s) [{', '.join(filter_terms[:3])}], "
    if all_measures:
        measure_cols = [m.get('column', '') for m in all_measures if m.get('column')]
        context_builder_summary += f"{len(all_measures)} measure column(s) [{', '.join(measure_cols[:3])}]"

    # NEW: Store per-source contexts for parallel_executor to reuse
    per_source_contexts = {}
    for ps, match_result in zip(prepared_sources, match_results):
        source_key = f"{ps['file_name']}::{ps['sheet_name']}"
        focused = _build_focused_context(
            file_name=ps["file_name"],
            file_path=ps["file_path"],
            sheet_name=ps["sheet_name"],
            sheet_info=ps["sheet_info"],
            structure=ps["structure"],
            match_result=match_result
        )
        per_source_contexts[source_key] = focused

    return {
        "query_context": final_context,
        "matched_filters": all_filters,
        "measure_columns": all_measures,
        "column_usage": all_column_usage,
        "context_builder_confidence": context_confidence,
        "context_builder_summary": context_builder_summary,  # NEW - human readable summary
        "business_formulas_full_text": business_formulas_full_text,  # NEW - full formulas for code generator
        "per_source_contexts": per_source_contexts,  # NEW - for parallel_executor reuse
    }