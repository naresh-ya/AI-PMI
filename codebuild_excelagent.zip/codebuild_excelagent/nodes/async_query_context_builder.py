"""
ASYNC Query context builder — TRUE parallel context building.

Uses asyncio + httpx to build contexts for all sources in parallel without GIL blocking.
Expected speedup: 63s → 25s for 3 sources.
"""

import asyncio
import re
import json
from pathlib import Path
from typing import Dict, Any, List

from openpyxl.utils import get_column_letter

from models.state import PipelineState
from helpers.file_registry import build_source_key, load_glossary_index
from core.structured_logging import get_logger
from prompts.system_prompts import query_context_builder_system
from prompts.user_prompts import build_query_context_match_prompt
from core.timing import timed
from core.settings import get_s3_paths, get_formula_files_for_sources, load_formula_file_from_s3

logger = get_logger(__name__)


# Import formula loading functions (same as original)
from nodes.query_context_builder import (
    _load_business_formulas_for_sources,
    _format_business_formulas_full,
    _assess_context_confidence,
    _build_focused_context
)


async def _call_llm_async(client, messages: list, model_name: str, max_tokens: int) -> str:
    """
    Make async LLM call using httpx (non-blocking, non-streaming).
    Uses SHARED httpx client for connection pooling (faster SSL reuse).

    Args:
        client: Shared httpx.AsyncClient for connection pooling
        messages: LangChain messages
        model_name: Model ID
        max_tokens: Max tokens
    """
    from core.settings import settings

    # Build Bedrock payload
    system_blocks = []
    bedrock_messages = []

    for msg in messages:
        role = getattr(msg, "type", "user")
        content = msg.content if hasattr(msg, "content") else str(msg)

        if role == "system":
            system_blocks.append({"text": content})
        else:
            bedrock_role = "assistant" if role == "ai" else "user"
            bedrock_messages.append({"role": bedrock_role, "content": [{"text": content}]})

    payload = {
        "modelId": model_name,
        "messages": bedrock_messages,
        "inferenceConfig": {
            "maxTokens": max_tokens,
            "temperature": 0,
        },
    }
    if system_blocks:
        payload["system"] = system_blocks

    headers = {
        "Authorization": f"Bearer {settings.bedrock_bearer_token}",
        "Content-Type": "application/json",
    }

    base_url = settings.bedrock_endpoint_url.rstrip("/")
    endpoint = f"{base_url}/model/{model_name}/converse"

    # Use shared client for connection pooling (reuses SSL handshake)
    response = await client.post(endpoint, json=payload, headers=headers)
    response.raise_for_status()

    result = response.json()
    content = result.get("output", {}).get("message", {}).get("content", [])
    texts = [str(block.get("text", "")) for block in content if isinstance(block, dict)]
    return "".join(texts).strip()


async def _call_llm_async_stream(client, messages: list, model_name: str, max_tokens: int):
    """
    Stream LLM response asynchronously using httpx with SSE.
    Based on LiteLLM async streaming API.

    Args:
        client: Shared httpx.AsyncClient for connection pooling
        messages: LangChain messages
        model_name: Model ID
        max_tokens: Max tokens

    Yields:
        str: Token chunks as they arrive
    """
    import json
    from core.settings import settings

    # Build Bedrock payload
    system_blocks = []
    bedrock_messages = []

    for msg in messages:
        role = getattr(msg, "type", "user")
        content = msg.content if hasattr(msg, "content") else str(msg)

        if role == "system":
            system_blocks.append({"text": content})
        else:
            bedrock_role = "assistant" if role == "ai" else "user"
            bedrock_messages.append({"role": bedrock_role, "content": [{"text": content}]})

    payload = {
        "modelId": model_name,
        "messages": bedrock_messages,
        "inferenceConfig": {
            "maxTokens": max_tokens,
            "temperature": 0,
        },
    }
    if system_blocks:
        payload["system"] = system_blocks

    headers = {
        "Authorization": f"Bearer {settings.bedrock_bearer_token}",
        "Content-Type": "application/json",
    }

    base_url = settings.bedrock_endpoint_url.rstrip("/")
    endpoint = f"{base_url}/model/{model_name}/converse-stream"  # Note: -stream suffix

    # Track repeated chunks for infinite loop detection (LiteLLM safety)
    repeated_chunk_tracker = {}
    REPEATED_STREAMING_CHUNK_LIMIT = 100

    try:
        async with client.stream('POST', endpoint, json=payload, headers=headers) as response:
            response.raise_for_status()

            # Parse SSE stream
            async for line in response.aiter_lines():
                if not line:
                    continue

                # SSE format: "data: {json}"
                if line.startswith('data:'):
                    data_str = line[5:].strip()

                    if data_str == '[DONE]':
                        break

                    try:
                        chunk_data = json.loads(data_str)
                        chunk_type = chunk_data.get('type', '')

                        if chunk_type == 'content_block_delta':
                            delta = chunk_data.get('delta', {})
                            text = delta.get('text', '')

                            if text:
                                # Infinite loop detection
                                if text in repeated_chunk_tracker:
                                    repeated_chunk_tracker[text] += 1
                                    if repeated_chunk_tracker[text] > REPEATED_STREAMING_CHUNK_LIMIT:
                                        raise RuntimeError(
                                            f"Model entered infinite loop: chunk '{text[:50]}...' "
                                            f"repeated {repeated_chunk_tracker[text]} times"
                                        )
                                else:
                                    repeated_chunk_tracker[text] = 1

                                yield text

                        elif chunk_type == 'message_stop':
                            break

                    except json.JSONDecodeError:
                        continue

    except Exception as e:
        logger.error(f"Streaming error: {e}")
        raise


async def _build_source_context_async(
    client,
    file_name: str,
    file_path: str,
    sheet_name: str,
    sheet_info: dict,
    structure: dict,
    user_query: str,
    model_name: str,
    max_tokens: int,
    business_description: str = "",
    business_facts: str = "",
    catalog_columns: str = "",
    current_month_info: dict = None,
    business_formulas_text: str = "",
    user_jwt_token: str = None
) -> dict:
    """
    Build query-matched context for a single source using ASYNC LLM call.
    This is the core optimization - uses httpx instead of requests.
    """
    from langchain_core.messages import HumanMessage, SystemMessage

    # ── Glossary Section (domain terminology) ────────────────────────
    glossary_section = ""
    try:
        glossary = load_glossary_index(user_jwt_token) if user_jwt_token else {}
        if glossary:
            glossary_lines = ["GLOSSARY (Domain Terms - PMI Business Terminology):"]
            sorted_entries = sorted(glossary.values(), key=lambda x: x["canonical"].lower())
            for entry in sorted_entries:
                term = entry["term"]
                canonical = entry["canonical"]
                if term.lower() != canonical.lower():
                    glossary_lines.append(f"  {term} = {canonical}")

            if len(glossary_lines) > 1:
                glossary_section = "\n".join(glossary_lines) + "\n\n"
    except Exception as e:
        logger.warning("  Failed to load glossary: %s", e)

    # ── Business Formulas Section ────────────────────────────────────────
    formulas_section = business_formulas_text

    # ── Business Context Section (from catalog) ──────────────────────
    business_context_section = ""
    if business_description or business_facts or catalog_columns:
        business_context_section = "BUSINESS CONTEXT (from catalog):\n"
        if business_description:
            business_context_section += f"Description: {business_description}\n\n"
        if business_facts:
            business_context_section += f"Business Facts:\n{business_facts}\n\n"
        if catalog_columns:
            business_context_section += f"Expected Columns (generic): {catalog_columns}\n\n"
        business_context_section += (
            "IMPORTANT: The catalog columns are generic labels. "
            "You MUST use the ACTUAL column positions and values from the structure below.\n\n"
        )

    # ── Header rows section ──────────────────────────────────────────
    header_lines = []
    transition_rows = sheet_info.get("transition_rows", [])
    for tr in transition_rows[:7]:
        row_num = tr.get("excel_row", "?")
        content = tr.get("content", [])
        col_parts = []
        for i, val in enumerate(content):
            if val is not None:
                col_letter_h = get_column_letter(i + 1)
                col_parts.append(f"{col_letter_h}(#{i+1})='{val}'")
        if col_parts:
            header_lines.append(f"  Excel Row {row_num}: {', '.join(col_parts)}")
    header_section = (
        "HEADER ROWS (use these for exact column positions):\n"
        + ("\n".join(header_lines) if header_lines else "  (none captured)")
    )

    # ── Value catalog ─────────────────────────────────────────────────
    value_catalog_lines = []
    for col_letter, cp in sheet_info.get("column_profiles", {}).items():
        col_type = cp.get("type", "")
        unique_texts = cp.get("unique_texts", [])

        if col_type in ("text", "mixed") and unique_texts:
            texts = unique_texts
            if len(texts) > 200:
                vals_str = ", ".join(f"'{v}'" for v in texts[:200])
                vals_str += f" ... (+{len(texts) - 200} more)"
            else:
                vals_str = ", ".join(f"'{v}'" for v in texts)
            value_catalog_lines.append(
                f"Column {col_letter}: "
                f"{len(unique_texts)} unique values\n  Values: {vals_str}"
            )
        elif col_type == "numeric" and unique_texts:
            vals_str = ", ".join(f"'{v}'" for v in unique_texts[:10])
            value_catalog_lines.append(
                f"Column {col_letter}: "
                f"[NUMERIC — header labels: {vals_str}]"
            )

    value_catalog = glossary_section + formulas_section + business_context_section + header_section + "\n\nCOLUMN VALUE CATALOG:\n" + "\n".join(value_catalog_lines)

    # Table descriptions
    tables = structure.get("tables", [])
    table_desc_lines = []
    for t in tables:
        table_desc_lines.append(
            f"Table '{t.get('name', '?')}': "
            f"header rows {t.get('header_rows')}, "
            f"data rows {t.get('data_start_row')}-{t.get('data_end_row')}, "
            f"label cols {t.get('label_columns')}, "
            f"data cols {t.get('data_columns')}"
        )
    table_desc = "\n".join(table_desc_lines)

    # Sample rows
    sample_lines = []
    for sr in sheet_info.get("sample_rows", []):
        col_letters = [get_column_letter(i + 1) for i in range(len(sr.get("content", [])))]
        parts = []
        for cl, val in zip(col_letters, sr.get("content", [])):
            if val is not None:
                parts.append(f"{cl}='{val}'")
        sample_lines.append(f"  Row {sr.get('excel_row', '?')}: {', '.join(parts)}")
    samples_text = "\n".join(sample_lines)

    # Build messages
    messages = [
        SystemMessage(content=query_context_builder_system(current_month_info)),
        HumanMessage(content=build_query_context_match_prompt(
            user_query, file_name, sheet_name, table_desc, value_catalog, samples_text
        )),
    ]

    # ASYNC LLM call - THE KEY CHANGE!
    # Removed verbose logging for performance
    response_text = await _call_llm_async(client, messages, model_name, max_tokens)

    # Parse response (same as original)
    json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
    match_result = {}
    if json_match:
        try:
            match_result = json.loads(json_match.group())
        except json.JSONDecodeError:
            raw = json_match.group()
            raw = re.sub(r',\s*}', '}', raw)
            raw = re.sub(r',\s*]', ']', raw)
            try:
                match_result = json.loads(raw)
            except Exception as e:
                logger.warning("Failed to parse LLM response for %s::%s: %s", file_name, sheet_name, e)
                match_result = {}

    # Removed verbose logging for performance
    return match_result


async def _build_all_contexts_async(
    prepared_sources: list,
    query: str,
    current_month_info: dict,
    business_formulas_text: str,
    model_name: str,
    max_tokens: int,
    user_jwt_token: str = None
) -> list:
    """Build contexts for all sources in TRUE parallel using asyncio.gather with shared HTTP client."""
    import httpx
    from core.settings import settings

    # Create ONE shared client for ALL parallel LLM calls (connection pooling!)
    async with httpx.AsyncClient(
        timeout=300.0,
        verify=not settings.bedrock_skip_tls_verify,
        limits=httpx.Limits(
            max_connections=settings.http_max_connections,
            max_keepalive_connections=settings.http_max_keepalive
        )
    ) as client:
        tasks = []
        for ps in prepared_sources:
            task = _build_source_context_async(
                client=client,  # Pass shared client
                file_name=ps["file_name"],
                file_path=ps["file_path"],
                sheet_name=ps["sheet_name"],
                sheet_info=ps["sheet_info"],
                structure=ps["structure"],
                user_query=query,
                model_name=model_name,
                max_tokens=max_tokens,
                business_description=ps.get("description", ""),
                business_facts=ps.get("business_facts", ""),
                catalog_columns=ps.get("catalog_columns", ""),
                current_month_info=current_month_info,
                business_formulas_text=business_formulas_text,
                user_jwt_token=user_jwt_token,  # Pass JWT token for glossary loading
            )
            tasks.append(task)

        # Run ALL tasks concurrently (TRUE PARALLELISM with shared connection pool!)
        # Removed verbose logging for performance
        results = await asyncio.gather(*tasks, return_exceptions=True)

    # Convert exceptions to empty dicts
    final_results = []
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            logger.error(f"[ASYNC] Context building failed for source {i}: {result}")
            final_results.append({})
        else:
            final_results.append(result)

    # Removed verbose logging for performance
    return final_results


def _detect_cross_file_with_llm(
    query: str,
    all_column_usage: dict,
    selected_sources: list
) -> bool:
    """
    Use LLM to detect if the query requires cross-file operations (JOIN/MERGE/COMPARE).

    This function analyzes the query along with the actual columns found in each source
    to determine if row-level operations across files are needed.

    Args:
        query: User's original query
        all_column_usage: Dict mapping source_key -> {filter_columns, measure_columns, operation}
        selected_sources: List of selected source dicts

    Returns:
        bool: True if cross-file operations needed, False if sources are independent
    """
    from langchain_core.messages import HumanMessage, SystemMessage
    from claude_setup.llm import get_model

    # Build summary of what was found in each source
    sources_summary = []
    for src in selected_sources:
        source_key = f"{src.get('file', '?')}::{src.get('sheet', '?')}"
        usage = all_column_usage.get(source_key, {})

        filter_cols = [f"{f['column']} = {f['exact_value']}" for f in usage.get("filter_columns", [])]
        measure_cols = [m['column'] for m in usage.get("measure_columns", [])]
        operation = usage.get("operation", "unknown")

        sources_summary.append(
            f"Source: {source_key}\n"
            f"  Operation: {operation}\n"
            f"  Filter columns: {', '.join(filter_cols) if filter_cols else 'none'}\n"
            f"  Measure columns: {', '.join(measure_cols) if measure_cols else 'none'}"
        )

    sources_text = "\n\n".join(sources_summary)

    system_prompt = """You are a data analysis expert. Determine if a query requires CROSS-FILE operations.

DEFINITION: Cross-file operations require combining, matching, or calculating across data from multiple sources at the row level or aggregate level.

Return TRUE if the query requires ANY of:
1. ROW-LEVEL operations across files:
   - JOIN/MERGE on common keys (e.g., matching products, SKUs, IDs across files)
   - INTERSECTION (items in both files)
   - DIFFERENCE (items in one file but not another)
   - UNION with deduplication

2. AGGREGATE-LEVEL calculations across files:
   - Mathematical operations between file totals (subtraction, division, ratios)
   - Gap analysis (File A total - File B total)
   - Variance comparisons requiring cross-file arithmetic
   - Percentage calculations involving multiple file aggregates

3. CONDITIONAL logic spanning files:
   - "If value from File A, then lookup in File B"
   - Filters dependent on values from multiple files

Return FALSE if:
- Each file answers a different dimension independently
- Results are simply listed side-by-side without mathematical combination
- Query wants separate reports even if using "and" or "with"

DECISION RULE: Ask yourself - "Must the code perform arithmetic operations or joins between data from different files?"
- If YES → return TRUE
- If NO (just separate reports) → return FALSE

Return ONLY a JSON object: {"requires_cross_file": true/false, "reasoning": "brief explanation"}"""

    user_prompt = f"""Query: {query}

Sources found and their columns:
{sources_text}

Analysis instructions:
1. Check if the query requires ARITHMETIC between file aggregates (subtract, divide, compare totals)
2. Check if the query requires MATCHING rows across files (joins, intersections)
3. Check if each file answers an independent dimension with no cross-file calculations

If the query asks for variance, gap, difference, ratio, or comparison BETWEEN sources, that requires cross-file operations.
If the query just wants separate metrics from each source listed together, that does NOT require cross-file operations.

Return JSON only."""

    try:
        model = get_model()
        response = model.invoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt)
        ])

        content = getattr(response, "content", str(response))

        # Parse JSON response
        import json
        import re
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            result = json.loads(json_match.group())
            requires_cross_file = result.get("requires_cross_file", False)
            return bool(requires_cross_file)
        else:
            logger.warning("[CROSS_FILE_DETECT] Failed to parse LLM response, defaulting to False")
            return False

    except Exception as e:
        logger.error(f"[CROSS_FILE_DETECT] Error detecting cross-file dependency: {e}", exc_info=True)
        # Safe fallback: assume independent sources (parallel is faster)
        return False


def async_query_context_builder_node(state: PipelineState) -> dict:
    """
    ASYNC query context builder - TRUE parallel context building.

    Expected speedup: 63s → 25s for 3 sources.
    Uses asyncio.gather + httpx instead of ThreadPoolExecutor + requests.
    """
    from core.settings import settings

    query = state["query"]
    selected_sources = state.get("selected_sources", [])
    file_registry = state.get("file_registry", {})
    structures = state.get("structures", {})
    requires_cross_file = state.get("requires_cross_file", False)

    # Extract JWT token for user-specific month tracking
    user_jwt_token = state.get("user_jwt_token")
    
    # Fetch current month from user-specific API
    from core.settings import get_current_month
    current_month_info = get_current_month(user_jwt_token)

    # Load business formulas (ONCE)
    # Extract JWT token for user-specific month tracking
    user_jwt_token = state.get("user_jwt_token")
    paths = get_s3_paths(user_jwt_token)
    loaded_formulas = _load_business_formulas_for_sources(selected_sources, paths)
    business_formulas_full_text = _format_business_formulas_full(loaded_formulas)

    all_contexts = []
    all_column_usage: dict = {}
    all_filters = []
    all_measures = []

    # --- Phase 1: resolve file/sheet info for each source (cheap, sequential) ---
    prepared_sources = []
    for src in selected_sources:
        file_name = src["file"]
        sheet_name = src["sheet"]

        # Exact lookup first; fall back to canonical fuzzy match
        file_info = file_registry.get(file_name, {})
        if not file_info:
            _want = re.sub(r"[_\-\s]+", " ", Path(file_name).stem).casefold()
            for _key, _val in file_registry.items():
                _have = re.sub(r"[_\-\s]+", " ", _key).casefold()
                if _want and (_want in _have or _have in _want):
                    file_info = _val
                    file_name = _key
                    break

        file_path = file_info.get("file_path", src.get("file_path", ""))
        profile = file_info.get("profile", {})

        sheet_info = profile.get("sheets", {}).get(sheet_name, {})
        if not sheet_info:
            _want_s = re.sub(r"[_\-\s]+", " ", sheet_name).casefold()
            for _skey, _sval in profile.get("sheets", {}).items():
                _have_s = re.sub(r"[_\-\s]+", " ", _skey).casefold()
                if _want_s and (_want_s in _have_s or _have_s in _want_s):
                    sheet_info = _sval
                    sheet_name = _skey
                    break

        source_key = build_source_key(file_path or file_name, sheet_name)
        structure = structures.get(source_key, {})

        if not sheet_info:
            logger.warning("  No profile for %s::%s", file_name, sheet_name)
            continue

        prepared_sources.append({
            "file_name": file_name,
            "file_path": file_path,
            "sheet_name": sheet_name,
            "sheet_info": sheet_info,
            "structure": structure,
            "description": src.get("description", ""),
            "business_facts": src.get("business_facts", ""),
            "catalog_columns": src.get("catalog_columns", ""),
        })

    # --- Phase 2: ASYNC parallel LLM calls for all sources (THE OPTIMIZATION!) ---
    with timed("ASYNC_PARALLEL context_building"):
        match_results = asyncio.run(_build_all_contexts_async(
            prepared_sources=prepared_sources,
            query=query,
            current_month_info=current_month_info,
            business_formulas_text=business_formulas_full_text,
            model_name=settings.llm_model,
            max_tokens=settings.llm_max_tokens,
            user_jwt_token=user_jwt_token  # Pass JWT token for glossary loading
        ))

    # --- Phase 3: assemble contexts from results (cheap, sequential) ---
    per_source_contexts = {}

    for ps, match_result in zip(prepared_sources, match_results):
        file_name = ps["file_name"]
        file_path = ps["file_path"]
        sheet_name = ps["sheet_name"]
        sheet_info = ps["sheet_info"]
        structure = ps["structure"]

        all_filters.extend(match_result.get("matched_filters", []))
        all_measures.extend(match_result.get("measure_columns", []))

        # Build per-source column usage entry
        source_key_usage = f"{file_name}::{sheet_name}"
        all_column_usage[source_key_usage] = {
            "file": file_name,
            "sheet": sheet_name,
            "file_path": file_path,
            "filter_columns": [
                {"column": mf.get("column", ""), "column_number": mf.get("column_number", 0),
                 "exact_value": mf.get("exact_value", ""), "user_term": mf.get("user_term", "")}
                for mf in match_result.get("matched_filters", [])
            ],
            "measure_columns": [
                {"column": mc.get("column", ""), "column_number": mc.get("column_number", 0),
                 "description": mc.get("description", "")}
                for mc in match_result.get("measure_columns", [])
            ],
            "target_table": match_result.get("target_table", ""),
            "operation": match_result.get("operation", ""),
            "operation_detail": match_result.get("operation_detail", ""),
            "reasoning": match_result.get("reasoning", ""),
        }

        # Build focused context
        focused = _build_focused_context(
            file_name=file_name,
            file_path=file_path,
            sheet_name=sheet_name,
            sheet_info=sheet_info,
            structure=structure,
            match_result=match_result
        )
        all_contexts.append(focused)
        per_source_contexts[source_key_usage] = focused

    # --- Detect cross-file dependency based on actual column analysis ---
    detected_requires_cross_file = False
    if len(selected_sources) > 1:
        # Use LLM to analyze if cross-file operations are needed
        detected_requires_cross_file = _detect_cross_file_with_llm(
            query=query,
            all_column_usage=all_column_usage,
            selected_sources=selected_sources
        )

    # Combine contexts based on cross-file detection
    if len(all_contexts) == 1:
        final_context = all_contexts[0]
    elif len(all_contexts) > 1:
        separator = f"\n{'─' * 60}\n"

        if detected_requires_cross_file:
            # Cross-file operations: emphasize JOIN/MERGE
            header = (
                "CROSS-FILE QUERY — Data must be JOINED/MERGED across sources:\n"
                f"Number of sources: {len(all_contexts)}\n"
                "CRITICAL: Generate ONE unified script that performs cross-file operations.\n"
            )
            final_context = header + separator + separator.join(all_contexts)
            final_context += f"\n\nCROSS-FILE OPERATION REQUIREMENTS:\n"
            final_context += f"  1. Read each file into separate DataFrames (df1, df2, etc.)\n"
            final_context += f"  2. Apply filters to each DataFrame independently\n"
            final_context += f"  3. JOIN/MERGE/MATCH the filtered results using pandas operations\n"
            final_context += f"     - Use pd.merge() for SQL-like joins\n"
            final_context += f"     - Use set operations for intersection/union/difference\n"
            final_context += f"     - Use comparison operators for cross-file comparisons\n"
            final_context += f"  4. Perform the cross-file calculation/comparison as specified in query\n"
            final_context += f"  5. Print a SINGLE unified result showing the cross-file analysis\n"
        else:
            # Independent sources: each answers different part
            header = (
                "MULTI-SOURCE QUERY — Independent sources (no cross-file operations):\n"
                f"Number of sources: {len(all_contexts)}\n"
                "Each source answers a different part of the query independently.\n"
            )
            final_context = header + separator + separator.join(all_contexts)
            final_context += f"\n\nINDEPENDENT SOURCE INSTRUCTIONS:\n"
            final_context += f"  1. Read each file separately with pd.read_excel()\n"
            final_context += f"  2. Apply filters to each DataFrame independently\n"
            final_context += f"  3. Report results from each source separately\n"
            final_context += f"  4. Print clear labels showing which results come from which source\n"
    else:
        final_context = "No context available."

    # Get LLM confidence
    llm_confidences = []
    for mr in match_results:
        if mr and "overall_confidence" in mr:
            try:
                llm_confidences.append(int(mr["overall_confidence"]))
            except (ValueError, TypeError):
                pass

    if llm_confidences:
        overall_confidence = int(sum(llm_confidences) / len(llm_confidences))
        context_confidence = {
            "overall_confidence": overall_confidence,
            "column_relevance_score": overall_confidence,
            "details": f"LLM confidence from {len(llm_confidences)} source(s)",
            "potential_issues": [],
        }
    else:
        context_confidence = _assess_context_confidence(
            query=query,
            all_filters=all_filters,
            all_measures=all_measures,
            selected_sources=selected_sources,
        )

    # Build human-readable summary
    context_builder_summary = f"Analyzed {len(selected_sources)} source(s): "
    if all_filters:
        filter_terms = [f.get('user_term', '') for f in all_filters if f.get('user_term')]
        context_builder_summary += f"Found {len(all_filters)} filter(s) [{', '.join(filter_terms[:3])}], "
    if all_measures:
        measure_cols = [m.get('column', '') for m in all_measures if m.get('column')]
        context_builder_summary += f"{len(all_measures)} measure column(s) [{', '.join(measure_cols[:3])}]"

    return {
        "query_context": final_context,
        "matched_filters": all_filters,
        "measure_columns": all_measures,
        "column_usage": all_column_usage,
        "context_builder_confidence": context_confidence,
        "context_builder_summary": context_builder_summary,
        "business_formulas_full_text": business_formulas_full_text,
        "per_source_contexts": per_source_contexts,
        "requires_cross_file": detected_requires_cross_file,  # NEW: Override the hardcoded value
    }
