"""Code generator — generates Python code for single or multi-file queries."""

import re
from pathlib import Path
from typing import Dict, Any

from langchain_core.messages import HumanMessage, SystemMessage, AIMessage

from claude_setup.llm import get_model
from models.state import PipelineState
from core.structured_logging import get_logger
from prompts.system_prompts import code_generator_system
from prompts.user_prompts import build_code_generation_prompt
from helpers.code_util import extract_code, is_code_complete
from helpers.file_registry import get_file_path_by_name
from core.timing import timed

logger = get_logger(__name__)


# NOTE: Business formulas are now loaded by context_builder and passed via state
# No S3 access needed here - formulas come from state["business_formulas_full_text"]


def _canonical_name(value: str) -> str:
    if not value:
        return ""
    path = Path(value)
    if path.suffix.lower() in (".xlsx", ".xls", ".csv"):
        value = path.stem
    value = re.sub(r"[_\-\s]+", " ", value)
    return value.casefold().strip()


def _resolve_source_path(src: dict, file_registry: dict[str, Any]) -> str:
    requested_path = (src.get("file_path", "") or "").strip()
    canonical_file = _canonical_name(src.get("file", ""))
    if not requested_path:
        return get_file_path_by_name(file_registry, src.get("file", "")) or src.get("file", "")

    requested_stem = _canonical_name(Path(requested_path).stem)
    if canonical_file and requested_stem and requested_stem != canonical_file:
        resolved = get_file_path_by_name(file_registry, src.get("file", ""))
        if resolved:
            return resolved

    return requested_path


async def code_generator_node(state: PipelineState) -> PipelineState:
    """
    Generate Python code from query context.
    Handles both single-file and multi-file scenarios.

    ASYNC FUNCTION: No streaming to frontend (as requested).
    Returns state dict.
    """
    query = state["query"]
    query_context = state.get("query_context", "")
    selected_sources = state.get("selected_sources", [])
    requires_cross_file = state.get("requires_cross_file", False)

    model = get_model()

    # Get business formulas from state (loaded by context builder - no S3 call!)
    business_formulas = state.get("business_formulas_full_text", "")

    # Build read instructions for each source
    read_instructions = []
    for i, src in enumerate(selected_sources):
        var_name = f"df{i + 1}" if len(selected_sources) > 1 else "df"
        file_path = _resolve_source_path(src, state.get("file_registry", {}))
        read_instructions.append(
            f"{var_name} = pd.read_excel("
            f"r\"{file_path}\", "
            f"sheet_name=\"{src['sheet']}\", header=None)"
        )

    read_code = "\n".join(read_instructions)

    multi_file_note = ""
    if requires_cross_file:
        multi_file_note = """
MULTI-FILE RULES:
- Read each file into a separate DataFrame (df1, df2, etc.)
- Apply filters to each independently
- Combine or compare results as needed
- Clearly label which results come from which file/sheet
"""

    sys_prompt = code_generator_system(read_code, multi_file_note, business_formulas)

    # Initialize conversation with system prompt - build on this for retries
    messages = [SystemMessage(content=sys_prompt)]

    code = ""
    for attempt in range(3):
        # Build user message
        if attempt == 0:
            # First attempt: full context
            user_msg = build_code_generation_prompt(query, query_context)
        else:
            # Retry: conversational prompt that sees previous attempt
            user_msg = """Your previous code was incomplete or truncated.

CRITICAL REQUIREMENTS FOR COMPLETE CODE:
- Must end with print() statement that outputs the final answer
- All brackets must be closed: (), [], {}
- All quotes must be closed: "", ''
- Code must be syntactically complete
- No line limit - write as many lines as needed to be correct

Generate the COMPLETE, CORRECT code now (no comments, no explanations):"""

        # Append user message to conversation
        messages.append(HumanMessage(content=user_msg))

        # Get LLM response (streaming internally, no yields to LangGraph)
        with timed(f"LLM_CALL code_generator attempt={attempt+1}"):
            full_response = []

            # Use astream() for async streaming (required by LangGraph async mode)
            # Note: astream() yields plain strings, not AIMessage objects
            async for token in model.astream(messages):
                full_response.append(token)

            response_text = "".join(full_response)

        code = extract_code(response_text)

        # Check if code is complete
        if is_code_complete(code):
            # Return state update with complete code
            return {"generated_code": code}

        # Add assistant's response to conversation for next retry
        messages.append(AIMessage(content=response_text))
        logger.warning("Attempt %d produced incomplete code, retrying...", attempt + 1)

    # Last resort: return what we have (will be caught by executor)
    logger.error("All 3 attempts produced incomplete code")
    return {"generated_code": code}