# RAG Design: Runbook Knowledge Base

## 1. Overview

**Purpose**: Enable the LangGraph agent to retrieve incident response procedures and troubleshooting guidance during triage.

**Data Source**: Historical runbooks, incident playbooks, and containment procedures (stored as markdown/PDF)

**Technology**: Amazon Bedrock Knowledge Bases with OpenSearch Vector Engine

**Query Pattern**:
```
Agent Query: "How do we respond to service-a high CPU after deployment?"
  ├─ Vector embedding (Bedrock Titan)
  ├─ Search OpenSearch index
  └─ Return: Top-5 relevant runbooks + procedures
```

---

## 2. Knowledge Base Architecture

### 2.1 Data Ingestion Pipeline

```
Source Documents (Runbooks)
├─ incident-response/service-a-outage.md
├─ incident-response/service-b-slow-queries.md
├─ incident-response/service-c-high-memory.md
├─ containment/emergency-rollback.md
├─ containment/config-revert-safely.md
├─ containment/traffic-shift-to-canary.md
├─ root-cause/common-errors.md
├─ root-cause/database-issues.md
└─ escalation/tier-1-to-tier-2-handoff.md
    ↓
S3 Bucket (us-east-1, ai-services account)
├─ Bucket: runbook-kb-source
├─ Versioning: enabled
├─ Encryption: SSE-S3
└─ Lifecycle: Retain indefinitely
    ↓
Bedrock Knowledge Base Data Preparation
├─ Read documents from S3
├─ Parse markdown/PDF format
├─ Chunk documents (1000 tokens, 200-token overlap)
│  ├─ Chunk 1: "If service-a CPU is high...[200 tokens]"
│  ├─ Chunk 2: "[overlap 200] ...and after code changes...[200 tokens]"
│  └─ Chunk N: "[overlap 200] ...recommended: rollback...[200 tokens]"
├─ Extract metadata:
│   ├─ source_document: "incident-response/service-a-outage.md"
│   ├─ service_name: "service-a"
│   ├─ severity: "CRITICAL"
│   ├─ procedure_steps: ["Check logs", "Verify connections", "Rollback if needed"]
│   └─ last_updated: "2026-09-01"
└─ Embed chunks (Bedrock Titan Embeddings)
    ├─ Embedding model: amazon.titan-embed-text-v2:0
    ├─ Dimension: 1024
    ├─ Latency: 100-200ms per document
    └─ Cost: ~$0.0001 per 1K tokens
        ↓
OpenSearch Cluster (ai-services VPC, 10.1.20.x)
├─ Instance type: t3.medium (2 vCPU, 2GB RAM)
├─ Storage: 100GB EBS (runbooks + vectors)
├─ Index: bedrock-kb-runbooks
├─ Replicas: 1 (HA across AZs)
├─ Retention: Indefinite (operational knowledge)
└─ Field mappings:
    {
      "chunk_id": "kb_chunk_abc123",
      "content": "If service-a CPU is high...",
      "embedding": [0.123, -0.456, ...],  # 1024 dimensions
      "source": "incident-response/service-a-outage.md",
      "service_name": "service-a",
      "severity": "CRITICAL",
      "procedures": ["check-logs", "verify-connections", "rollback"],
      "timestamp": "2026-09-21T00:00:00Z"
    }
```

### 2.2 Bedrock Knowledge Base Configuration

```python
import boto3

bedrock_client = boto3.client('bedrock-agent')

# Create knowledge base
kb_config = {
    "name": "ops-runbook-kb",
    "description": "Incident response procedures and troubleshooting guides",
    "type": "VECTOR",
    "vectorIngestionConfiguration": {
        "chunkingConfiguration": {
            "chunkingStrategy": "FIXED_SIZE",
            "fixedSizeChunkingConfiguration": {
                "maxTokens": 1000,
                "overlapPercentage": 20
            }
        },
        "parsingConfiguration": {
            "parsingStrategy": "BEDROCK_NATIVE",
            "bedrockNativeConfiguration": {}
        }
    },
    "storageConfiguration": {
        "type": "OPENSEARCH",
        "opensearchServerless": {
            "collectionArn": "arn:aws:aoss:us-east-1:AI_ACCOUNT:collection/bedrock-kb-runbooks",
            "vectorIndexName": "bedrock-kb-runbooks-index",
            "fieldMapping": {
                "vectorField": "embedding",
                "textField": "content",
                "metadataField": "metadata"
            }
        }
    },
    "roleArn": "arn:aws:iam::AI_ACCOUNT:role/bedrock-kb-role"
}

kb_response = bedrock_client.create_knowledge_base(**kb_config)
knowledge_base_id = kb_response['knowledgeBase']['id']
```

---

## 3. Ingest Process

### 3.1 Automated Ingest Trigger

**Manual Upload** (operational team):
1. Update runbooks in `runbook-kb-source` S3 bucket
2. EventBridge rule detects S3 PutObject event
3. Lambda function triggered:

```python
def ingest_runbook(event, context):
    """
    S3 file uploaded → Trigger Bedrock knowledge base ingestion
    """
    s3 = boto3.client('s3')
    bedrock = boto3.client('bedrock-agent')
    
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Validate file type (markdown, pdf)
    if not key.endswith(('.md', '.pdf')):
        print(f"Skipping non-document file: {key}")
        return
    
    # Trigger knowledge base ingestion
    source_uri = f"s3://{bucket}/{key}"
    
    response = bedrock.start_ingestion_job(
        knowledgeBaseId=knowledge_base_id,
        dataSource={
            "type": "S3",
            "s3Configuration": {
                "bucketArn": f"arn:aws:s3:::{bucket}",
                "inclusion_prefixes": [key]
            }
        },
        description=f"Ingest {key}",
        clientToken=str(uuid.uuid4())
    )
    
    print(f"Ingestion job started: {response['ingestionJob']['ingestionJobId']}")
    return response
```

### 3.2 Ingest Status Monitoring

```python
def monitor_ingestion(ingestion_job_id):
    """
    Poll ingestion job status until complete
    """
    bedrock = boto3.client('bedrock-agent')
    
    while True:
        response = bedrock.get_ingestion_job(
            knowledgeBaseId=knowledge_base_id,
            ingestionJobId=ingestion_job_id
        )
        
        job = response['ingestionJob']
        status = job['status']  # STARTING, IN_PROGRESS, COMPLETE, FAILED
        
        if status == 'COMPLETE':
            print(f"Ingestion complete. Processed {job['statistics']['numberOfDocumentsProcessed']} docs")
            return
        elif status == 'FAILED':
            print(f"Ingestion failed: {job['failureReasons']}")
            raise Exception("Ingestion job failed")
        
        time.sleep(5)  # Poll every 5 seconds
```

**Typical Ingestion Timeline**:
- Document uploaded: 0s
- Lambda triggered: ~1s
- Bedrock ingestion starts: ~2s
- Parsing + chunking: ~10s (per document)
- Embedding generation: ~30s (per document, parallel)
- OpenSearch indexing: ~5s
- **Total**: ~50s per runbook (~1 min per 10 runbooks)

---

## 4. Query Process

### 4.1 Agent Query Pattern

**During Incident Triage**:

```python
def retrieve_relevant_runbooks(incident_state):
    """
    Agent queries KB during incident triage
    """
    bedrock = boto3.client('bedrock-agent-runtime')
    
    # Construct query based on incident context
    query = f"""
    How should we respond to {incident_state['affected_services'][0]} 
    high CPU after code deployment to {incident_state['change_id']}?
    """
    
    response = bedrock.retrieve(
        knowledgeBaseId=knowledge_base_id,
        retrievalConfiguration={
            "vectorSearchConfiguration": {
                "numberOfResults": 5,
                "overrideSearchType": "SEMANTIC"  # Vector search (not keyword)
            }
        },
        retrievalQuery={
            "text": query
        }
    )
    
    results = response['retrievalResults']
    
    # Process results
    runbooks = []
    for result in results:
        runbooks.append({
            "source": result['metadata'].get('source_document'),
            "excerpt": result['content'],
            "relevance_score": result['score'],  # 0-1, higher = more relevant
            "procedures": result['metadata'].get('procedures', []),
            "service": result['metadata'].get('service_name')
        })
    
    return runbooks
```

### 4.2 Query Latency Analysis

```
Query execution timeline:
├─ 0ms: Query text received
├─ 50ms: Query embedding generated (Titan)
├─ 100ms: Vector search in OpenSearch
├─ 150ms: Results ranked
├─ 200ms: Metadata enriched
└─ 2500ms: Results returned

Total: ~2.5 seconds for top-5 runbooks
```

### 4.3 Fallback: Keyword Search

**If vector search fails** (e.g., query poorly matched):

```python
def retrieve_with_fallback(incident_state):
    """
    Try vector search; fallback to keyword search
    """
    try:
        results = vector_search(incident_state)
        if len(results) > 0 and results[0]['relevance_score'] > 0.7:
            return results  # Good match
    except:
        pass
    
    # Fallback to keyword search
    query = f"{incident_state['affected_services'][0]} {incident_state['change_id']}"
    results = keyword_search(query)
    return results
```

---

## 5. Knowledge Base Content

### 5.1 Sample Runbooks

**Runbook 1: incident-response/service-a-outage.md**

```markdown
# Service A Outage Recovery

## Symptoms
- CPU utilization > 90%
- Response latency > 5 seconds
- Error rate > 5%

## Common Causes After Deployment
1. Connection pool exhaustion (config change)
2. Infinite loop in new code
3. Database query regression
4. Memory leak in new service version

## Investigation Steps
1. Check CloudWatch metrics for service-a
   - CPU: Should be < 50% baseline
   - Memory: Should be < 60% baseline
   - Connection pool: Should be < 80% utilization
2. Check X-Ray traces
   - Filter for errors and slow requests
   - Look for timeout patterns
3. Review recent deployments (last 30 min)
4. Check application logs for errors

## Remediation
### Option 1: Rollback Deployment (FASTEST)
- Prerequisites: Previous deployment version available
- Time to execute: ~5 minutes
- Success rate: 95% (if issue is in new code)
- Command:
  ```
  aws cloudformation update-stack --stack-name service-a \
    --template-body file://service-a-v1234.yml
  ```

### Option 2: Config Revert
- Prerequisites: Config change made
- Time to execute: ~3 minutes
- Success rate: 80% (if issue is config-related)
- Command:
  ```
  aws ssm put-parameter --name /service-a/pool-size \
    --value 100 --overwrite
  ```

### Option 3: Scale Up
- Prerequisites: Auto-scaling configured
- Time to execute: ~2 minutes
- Success rate: 40% (only helps if capacity issue)
- Command:
  ```
  aws autoscaling set-desired-capacity --auto-scaling-group-name service-a-asg \
    --desired-capacity 10
  ```

## Escalation
- If not resolved in 15 minutes, escalate to Team A manager
- Contact: alice@company.com (Slack: @alice-manager)
- Broadcast: #incident-response Slack channel
```

**Runbook 2: containment/emergency-rollback.md**

```markdown
# Emergency Rollback Procedure

## Prerequisites
- Previous stable deployment version identified
- No state conflicts (data is compatible)
- Team A on-call notified

## Steps
1. Pause traffic (optional, for data consistency)
   ```
   aws elbv2 deregister-targets --target-group-arn <arn> --targets Id=i-xxx
   ```

2. Rollback to previous version
   ```
   aws cloudformation update-stack --stack-name service-a \
     --template-body file://service-a-previous.yml \
     --capabilities CAPABILITY_IAM
   ```

3. Wait for rollback to complete (~3-5 min)
   ```
   aws cloudformation describe-stacks --stack-name service-a | grep StackStatus
   ```

4. Monitor metrics for 5 minutes
   - CPU should drop to baseline
   - Error rate should drop to < 1%
   - Response latency should normalize

5. If metrics normal, re-register targets
   ```
   aws elbv2 register-targets --target-group-arn <arn> --targets Id=i-xxx
   ```

## Rollback Not Working?
- Ensure you're using correct template version
- Check for data incompatibilities
- Escalate to architecture team

## Post-Incident
- Review what changed
- Update monitoring/alarms
- Post to #post-incident channel
```

### 5.2 Runbook Metadata

Each runbook is indexed with:
- `service_name`: The service(s) affected (e.g., "service-a")
- `severity`: CRITICAL, HIGH, MEDIUM, LOW
- `category`: incident-response, containment, escalation, root-cause
- `keywords`: tags for search (e.g., "cpu", "high-memory", "timeout")
- `procedures`: Action items (e.g., "rollback", "scale-up", "revert-config")
- `owner`: Team responsible (e.g., "team-a")
- `last_updated`: Date of last review

---

## 6. Operational Concerns & Mitigation

### 6.1 Stale Embeddings

**Problem**: Runbooks are updated, but embeddings are old → Queries retrieve outdated procedures

**Mitigation**:
```python
def ingest_with_versioning(event):
    """
    When runbook is updated, mark old version as archived
    and ingest new version
    """
    old_version_id = f"kb_chunk_{timestamp_prev}"
    new_version_id = f"kb_chunk_{timestamp_now}"
    
    # Mark old as deprecated
    opensearch.update(index='bedrock-kb-runbooks', id=old_version_id, body={
        "doc": {"status": "archived"}
    })
    
    # Ingest new version
    bedrock.start_ingestion_job(...)
    
    # Queries will prefer latest (non-archived) versions
```

**Automation**: Runbooks are versioned in Git; CI/CD re-ingests on every commit to `runbooks/` directory.

### 6.2 Empty Retrieval

**Problem**: Query returns no results (or low relevance scores) → Agent lacks guidance

**Mitigation**:
```python
def retrieve_with_quality_threshold(incident_state):
    """
    If vector search returns low-relevance results, use keyword fallback
    """
    vector_results = bedrock.retrieve(query_text=query)
    
    # Check if top result is relevant enough
    if len(vector_results) == 0 or vector_results[0]['score'] < 0.6:
        print("Vector search poor quality, falling back to keyword search")
        keyword_results = opensearch.search(
            index='bedrock-kb-runbooks',
            body={
                "query": {
                    "multi_match": {
                        "query": query,
                        "fields": ["content", "service_name", "keywords"]
                    }
                }
            }
        )
        return keyword_results['hits']['hits']
    
    return vector_results
```

### 6.3 Hallucination (Agent Over-Trusts KB)

**Problem**: Agent reads runbook and makes unsupported inferences

**Mitigation**:
```python
def analyze_with_confidence_threshold(runbooks, metrics):
    """
    Agent uses runbooks as guidance, but validates with evidence
    """
    
    # Agent reads runbooks
    recommended_action = extract_action(runbooks)  # e.g., "rollback"
    
    # Agent validates with metrics
    if runbooks[0]['relevance_score'] < 0.8:
        print("⚠️ Low confidence in runbook recommendation")
        return {
            "action": recommended_action,
            "confidence": 0.6,
            "evidence": metrics,
            "note": "Runbook suggests rollback, but low relevance. Validate manually."
        }
    
    if metrics['error_rate'] < 1:
        print("⚠️ Metrics don't match runbook symptoms")
        return {
            "action": "NO_ACTION_NEEDED",
            "confidence": 0.9,
            "evidence": "Metrics normal despite runbook suggestion"
        }
    
    return {
        "action": recommended_action,
        "confidence": 0.94,
        "evidence": metrics
    }
```

### 6.4 PII in Runbooks

**Problem**: Runbooks might contain sensitive info (customer names, IPs, passwords)

**Mitigation**:
- Runbooks use placeholder names: `SERVICE_NAME`, `CUSTOMER_ID`, `IP_ADDRESS`
- Secrets never stored in runbooks (use Secrets Manager)
- IAM policies restrict KB access to incident response role only
- CloudTrail logs all KB queries (audit trail)

### 6.5 Cost Optimization

**Current Costs**:
```
Bedrock Embeddings: ~$0.0001 per 1K tokens
  └─ ~10 runbooks * 5000 tokens avg = 50K tokens
  └─ Initial ingest: ~$0.005
  └─ Re-ingest on update: ~$0.001

Bedrock Retrieval: $0.0005 per query (1000 vector DB units)
  └─ ~20 incidents/day * 3 queries per incident = 60 queries/day
  └─ 60 * $0.0005 * 365 = ~$11/year

OpenSearch Serverless: $24/month (pay-per-request model)
  └─ ~1-2GB storage (runbooks + vectors)
  └─ ~10K queries/month

Total: ~$40/month
```

**To Reduce**:
- Use OpenSearch on-demand instances (~$15/month) instead of serverless
- Cache frequently retrieved runbooks in agent memory
- Batch queries (retrieve once per incident, not per tool call)

---

## 7. Retrieval Quality Metrics

### 7.1 Relevance Scoring

**How Bedrock scores results**:
```
Score = 1.0 (perfect match)
  ├─ Vector distance to query embedding: 0.0
  ├─ Metadata match: service_name + keywords match exactly
  └─ Recent update: runbook updated < 30 days ago

Score = 0.7-0.9 (good match)
  ├─ Vector distance: 0.1-0.3
  ├─ Partial metadata match
  └─ Related but not exact

Score = 0.3-0.7 (poor match)
  └─ Vector distance: 0.4-0.8

Score < 0.3 (no match)
  └─ Vector distance: > 0.8
```

### 7.2 Recall & Precision Targets

| Metric | Target | How Measured |
|--------|--------|--------------|
| **Recall** | > 95% | "Did top-5 results include the correct runbook?" (post-incident review) |
| **Precision** | > 85% | "Were top-5 results relevant to the incident?" (post-incident review) |
| **Coverage** | 100% | "Do we have runbooks for all services?" |
| **Freshness** | > 95% | "Are runbooks updated within 30 days of known issues?" |

---

## 8. Example Query Flow

### Scenario: Service B Slow After Deployment

```
Incident State:
├─ incident_id: incident-2026-09-21-001
├─ change_id: deploy-2026-09-21-001
├─ affected_services: ["service-b"]
└─ metrics: {"p99_latency": 3200ms, "error_rate": 8%}

Agent Query #1:
├─ Text: "How do we respond to service-b high latency after deployment?"
└─ Results:
    [1] incident-response/service-b-slow-queries.md (score: 0.94)
        ├─ Excerpt: "If service-b latency > 2s after deployment: Check database query time..."
        ├─ Procedures: ["check-db-logs", "identify-slow-query", "rollback-or-optimize"]
        └─ Owner: team-b-oncall
    
    [2] containment/traffic-shift-to-canary.md (score: 0.71)
        ├─ Excerpt: "If service-b is slow, shift traffic to canary and debug..."
        └─ Confidence: Medium (relevance 0.71)
    
    [3] root-cause/database-issues.md (score: 0.68)
        └─ [Similar results...]

Agent Action:
├─ Reads: "Check database logs for slow queries"
├─ Correlates: Metrics show p99 latency spike at 14:22:00 (matches deployment time)
├─ Proposes: "Likely slow database query introduced in deploy-2026-09-21-001"
├─ Recommends: "Rollback to previous version OR optimize query"
└─ Confidence: 0.94

n8n Approval:
├─ Displays: "Service B slow due to query regression"
├─ Shows: Runbook: incident-response/service-b-slow-queries.md
├─ On-call approves: "Execute rollback"
└─ Incident resolved in 7 minutes
```

---

## 9. Design Decisions

| Decision | Rationale | Trade-off |
|----------|-----------|----------|
| **Vector embeddings** | Semantic search (understands concepts, not just keywords) | Requires initial embedding cost (~$0.005 per runbook) |
| **1000-token chunks** | Large enough for complete procedures, small enough for precision | May split complex procedures across chunks |
| **Bedrock KB** | Managed service (no vector DB ops), native to Bedrock agents | Vendor lock-in (AWS-specific) |
| **OpenSearch** | Fast retrieval (~100ms), HA by default | Cost ~$24/month even for low usage |
| **Manual ingest** | Operators control KB version, no accidental overwrites | Requires discipline (runbooks not auto-ingested) |
| **Confidence thresholds** | Prevents hallucination (low-score runbooks rejected) | May reject valid but unusual cases |

