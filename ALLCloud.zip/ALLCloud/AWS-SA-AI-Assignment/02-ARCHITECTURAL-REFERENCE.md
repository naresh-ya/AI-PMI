# Architectural Reference: Ops Change Impact Helper with AgentCore

## 1. Problem & Constraints

**Manual Pain**: After a bad deployment, on-call engineers manually dig through tickets, runbooks, CloudWatch metrics, X-Ray traces, and logs to understand blast radius and find owners. MTTR is high (30+ minutes), prone to errors, and requires broad access.

**Constraints**:
- Multi-account AWS Organization required (prod operations + AI services + hub)
- Hub-spoke networking (network hub, prod operations spoke, AI services spoke)
- Serverless control plane (API Gateway, Lambda, Step Functions)
- AgentCore Gateway (IAM inbound + JWT/OBO)
- Agent intentionally thin (LangGraph for correlation, not autonomous)
- RAG via Amazon Bedrock Knowledge Bases (runbooks as KB)
- Human approval gates for all containment actions (no auto-remediation)

---

## 2. Target Architecture

### 2.1 Multi-Account Topology

```
AWS Organization
├── Network Hub Account (shared-network)
│   ├── VPC (10.0.0.0/16)
│   ├── Public Subnets (NAT, ALB)
│   ├── Private App Subnets
│   ├── Private Data Subnets
│   ├── Egress Subnets (NAT Gateway)
│   └── Transit Gateway (TGW)
│
├── AI Services Account (ai-services)
│   ├── VPC (10.1.0.0/16) - attached to TGW
│   ├── AgentCore Gateway (API Gateway + Lambda Authorizer)
│   ├── LangGraph Agent Runtime (ECS Fargate)
│   ├── MCP Servers (CloudWatch, X-Ray, Runbook KB, Change Details, Service Topology)
│   ├── Bedrock Knowledge Base (runbooks)
│   └── CloudWatch Logs
│
├── Prod Operations Account (prod-operations)
│   ├── VPC (10.2.0.0/16) - attached to TGW
│   ├── CloudWatch (metrics, alarms, logs)
│   ├── X-Ray (distributed traces)
│   ├── Change tracking system
│   ├── Lambda orchestrator (incident trigger)
│   ├── Step Functions (correlation workflow)
│   ├── n8n approval engine (ECS Fargate)
│   └── Production systems (monitored via metrics)
│
├── Security & Logging Account (security-logging)
│   ├── CloudTrail (organization-wide)
│   ├── CloudWatch Logs aggregation
│   ├── GuardDuty
│   ├── SecurityHub
│   ├── Runbook KB (read-only backup for disaster recovery)
│   └── Audit bucket (immutable, versioning enabled)
│
└── Optional: Shared Services Account (shared-services)
    ├── Bedrock models (shared endpoint)
    └── Centralized Secrets Manager
```

### 2.2 Request Flow (Incident Triage)

```
1. Incident Triggered
   └─> Change deployed in prod-operations account
   └─> CloudWatch alarm fired OR change notification event
   
2. EventBridge triggers orchestration
   ├─> prod-operations Lambda
   ├─> Extracts: change_id, affected_services (tag-based)
   ├─> Timestamp: incident start
   └─> Invokes orchestration Lambda
   
3. Orchestration Lambda (prod-operations)
   └─> Calls AgentCore Gateway API (cross-account)
   └─> Includes: change_id, caller_context (incident commander)
   └─> Headers: Authorization: AWS SigV4 + x-caller-user: operator:john@company.com
   
4. API Gateway + Lambda Authorizer (ai-services)
   ├─> Validates SigV4 signature (prod-operations account)
   ├─> Extracts caller identity
   ├─> Returns IAM policy + context
   └─> Latency: ~100ms
   
5. LangGraph Agent (ECS Fargate, ai-services)
   ├─ Step 1: Query Bedrock Knowledge Base (runbooks)
   │  └─ Query: "Troubleshooting for [service] after changes to [changed_component]"
   │  └─ Returns: Top-5 relevant runbooks + procedures
   │  └─ Latency: 2-3 seconds
   │
   ├─ Step 2: Call MCP tools to gather data
   │  ├─ CloudWatch: Get metrics for affected services (CPU, latency, errors)
   │  ├─ X-Ray: Get traces showing where slowdowns occurred
   │  ├─ Change Details: What code/config actually changed
   │  └─ Service Topology: Map dependencies (A→B→C)
   │  └─ Latency: 5-8 seconds (parallel calls)
   │
   ├─ Step 3: LangGraph correlates data
   │  ├─ Matches metrics spike to service boundaries
   │  ├─ Identifies blast radius (affected downstream services)
   │  ├─ Reads runbooks for containment strategies
   │  └─ Proposes: "Rollback or config revert"
   │  └─ Latency: 3-5 seconds (inference + reasoning)
   │
   └─ Step 4: Return blast radius analysis
      └─ Response JSON:
         {
           "change_id": "deploy-2026-09-21-001",
           "blast_radius": {
             "directly_affected": ["service-a", "service-b"],
             "cascading_impact": ["service-c", "service-d"],
             "duration_seconds": 450,
             "user_impact_percent": 12.5,
             "estimated_revenue_impact": "$45000"
           },
           "root_cause": "Config change introduced infinite loop in service-a",
           "suggested_containment": {
             "action_1": "Rollback config to revision 1234",
             "action_2": "Traffic shift 100% to canary",
             "urgency": "CRITICAL",
             "estimated_recovery_time": "5 minutes"
           },
           "relevant_runbooks": [
             "incident-response/service-a-outage.md",
             "containment/emergency-rollback.md"
           ],
           "likely_owners": ["team-a-oncall", "platform-team"],
           "confidence": 0.94
         }
   └─ Latency: ~100ms (response serialization)
   
6. API Gateway returns to Orchestration Lambda (prod-operations)
   └─ Latency: ~50ms (cross-account via TGW)
   
7. Step Functions starts approval workflow
   ├─> Receives: blast_radius + recommendations
   ├─> State: WaitForApproval
   ├─> Timeout: 30 minutes (on-call needs time to investigate)
   └─> n8n polling begins
   
8. n8n Approval Workflow
   ├─> Polls for pending approvals every 5 seconds
   ├─> Displays to on-call engineer:
   │   └─ "Change deploy-2026-09-21-001 may be causing issues"
   │   └─ Affected: service-a, service-b, cascading to service-c/d
   │   └─ Duration: 7.5 minutes so far
   │   └─ Revenue impact: ~$45K/hour
   │   └─ Suggested action: Emergency rollback
   │   └─ Runbooks: [links to KB]
   │   └─ Owners: Team A on-call (contact: john@company.com)
   │
   ├─> Engineer reviews (30-120 seconds)
   ├─> Engineer clicks "Approve Rollback" or "Reject"
   └─> n8n invokes Step Functions callback
   
9. On Approval: Step Functions executes containment
   ├─> Calls MCP tool: ExecuteContainment
   │   └─ Action: Rollback config
   │   └─ OBO token shows: operator:jane@company.com
   ├─> CloudFormation updates config (via assumed cross-account role)
   ├─> Metrics return to normal
   └─> Incident resolved in < 10 minutes (vs 30+ manual)
   
10. Completion + Audit
    ├─> Step Functions logs completion
    ├─> CloudTrail event:
    │   ├─ Change ID: deploy-2026-09-21-001
    │   ├─ Blast radius identified: 4 services
    │   ├─ Action approved by: jane@company.com (on-call)
    │   ├─ Time to decision: 2 minutes
    │   ├─ Recovery time: 7 minutes
    │   └─ Cost avoided: ~$45K
    └─> Incident commander notified: "Incident resolved by agent recommendation + manual execution"
```

### 2.3 Key Sequence Flows

**Change Deployment Detection**:
```
CodePipeline deploys to prod
  ├─> CloudFormation stack update
  ├─> EventBridge rule: "StackEvent AND (CREATE|UPDATE)"
  ├─> Triggers: incident-detector Lambda
  └─> Lambda invokes: AgentCore Gateway with change details
```

**Metric Correlation**:
```
LangGraph Agent needs to answer: "What changed and what broke?"

Query: CloudWatch metrics for service-a (1 min before → 10 min after change)
  ├─ GetMetricStatistics: CPU utilization, p99 latency, errors
  ├─ Correlate: Spike at T+2min (matches change deployment time)
  └─ Conclusion: "This change likely caused the issue"

Query: X-Ray traces for service-b (which calls service-a)
  ├─ GetTraceSummary: Trace counts, error rates, latency distribution
  ├─ Identify: Response time increased 500ms (timeout threshold = 1000ms)
  └─ Conclusion: "Service-b affected downstream via service-a"

Query: Service topology
  ├─ GetServiceDependencies: service-a → [service-b, service-c]
  ├─ GetDownstream: service-a impacts [service-c, service-d] (cascading)
  └─ Result: Blast radius = {service-a, service-b, service-c, service-d}
```

---

## 3. MCP Tools: Observability APIs

### 3.1 CloudWatch Metrics Tool

**Endpoint**: `POST /mcp/cloudwatch-metrics`

```json
{
  "action": "get_metrics",
  "namespace": "AWS/ApplicationELB",
  "metric_names": ["TargetResponseTime", "HTTPCode_Target_5XX"],
  "service_name": "service-a",
  "start_time": "2026-09-21T14:20:00Z",
  "end_time": "2026-09-21T14:30:00Z",
  "statistics": ["Average", "Maximum", "Sum"]
}
```

**Response**:
```json
{
  "metric_data": [
    {
      "label": "TargetResponseTime",
      "datapoints": [
        {"timestamp": "2026-09-21T14:22:00Z", "average": 45, "maximum": 120},
        {"timestamp": "2026-09-21T14:23:00Z", "average": 850, "maximum": 1200},
        {"timestamp": "2026-09-21T14:24:00Z", "average": 950, "maximum": 1500}
      ],
      "spike_detected": true,
      "spike_time": "2026-09-21T14:22:00Z"
    }
  ]
}
```

**IAM**: Agent role has `cloudwatch:GetMetricStatistics` (not GetDashboard, not PutMetricData)

### 3.2 X-Ray Traces Tool

**Endpoint**: `POST /mcp/xray-traces`

```json
{
  "action": "get_traces",
  "service_name": "service-b",
  "start_time": "2026-09-21T14:20:00Z",
  "end_time": "2026-09-21T14:30:00Z",
  "filter": "http.status >= 500"
}
```

**Response**:
```json
{
  "trace_summary": {
    "total_requests": 1200,
    "error_rate_percent": 15.2,
    "p50_latency_ms": 45,
    "p99_latency_ms": 2100,
    "timeout_count": 240,
    "affected_endpoints": [
      {
        "name": "GET /api/process",
        "error_rate": 18.5,
        "avg_latency": 1850,
        "errors": "Timeout calling downstream service-a"
      }
    ]
  }
}
```

**IAM**: Agent role has `xray:GetTraceSummary, xray:GetServiceGraph` (not WriteTrace)

### 3.3 Runbook Retrieval Tool

**Endpoint**: `POST /mcp/bedrock-retrieve`

```json
{
  "query": "Incident response for service-a after deployment",
  "top_k": 5
}
```

**Response**:
```json
{
  "results": [
    {
      "source": "incident-response/service-a-outage.md",
      "excerpt": "If service-a CPU spikes after deployment:\n1. Check recent code changes\n2. Verify database connection pool\n3. Consider immediate rollback",
      "relevance_score": 0.94
    }
  ]
}
```

### 3.4 Change Details Tool

**Endpoint**: `POST /mcp/change-details`

```json
{
  "change_id": "deploy-2026-09-21-001",
  "include": ["code_changes", "config_updates", "affected_services"]
}
```

**Response**:
```json
{
  "change": {
    "id": "deploy-2026-09-21-001",
    "timestamp": "2026-09-21T14:20:00Z",
    "services_updated": ["service-a"],
    "code_changes": {
      "files_modified": 3,
      "summary": "Config cache TTL reduced from 1h to 5min"
    },
    "rollback_available": true,
    "rollback_version": "1234"
  }
}
```

### 3.5 Service Topology Tool

**Endpoint**: `POST /mcp/service-topology`

```json
{
  "service": "service-a",
  "direction": "both"
}
```

**Response**:
```json
{
  "upstream": ["api-gateway", "load-balancer"],
  "downstream": ["service-b", "service-c", "database"],
  "cascading_impact": {
    "if_service_a_down": ["service-b (critical)", "service-c (high)", "service-d (medium)"]
  }
}
```

### 3.6 Containment Proposal Tool (Gated)

**Endpoint**: `POST /mcp/propose-containment`

```json
{
  "incident_id": "incident-2026-09-21-001",
  "change_id": "deploy-2026-09-21-001",
  "proposed_action": "rollback_config",
  "rollback_version": "1234",
  "rationale": "Config cache TTL change causing service-a CPU spike"
}
```

**Response**:
```json
{
  "proposal_id": "proposal-2026-09-21-001",
  "status": "pending_approval",
  "action": "rollback_config",
  "estimated_recovery_time": "5 minutes",
  "requires_approval": true,
  "audit_log": "Proposed by ai-agent; awaiting on-call approval"
}
```

**IAM**: Agent can PROPOSE but NOT EXECUTE. Only n8n-approved Step Functions can execute.

---

## 4. Network Design (Hub-Spoke + Prod Access)

### 4.1 Prod Operations VPC (10.2.0.0/16)

**Subnets**:
- Private App: 10.2.10.0/24, 10.2.11.0/24 (Lambda, Step Functions, n8n)
- Private Data: 10.2.20.0/24, 10.2.21.0/24 (CloudWatch, X-Ray, Config)
- Egress: 10.2.100.0/24 (NAT for outbound)

**VPC Endpoints**:
- CloudWatch (Interface endpoint, VPC endpoint policy restricts to read-only)
- X-Ray (Interface endpoint)
- S3 (Gateway endpoint for config buckets)

**Security Groups**:
- `lambda-incident-detector-sg`: Outbound to CloudWatch, X-Ray, SQS
- `stepfunctions-sg`: Outbound to SQS, EventBridge, Lambda
- `n8n-approval-sg`: Outbound to Step Functions, SNS

### 4.2 Cross-Account Access (prod → ai-services)

**Network Path**:
```
Prod Operations (10.2.10.x)
  ├─ Security group: Allow outbound to 10.1.10.0/24 (AI app subnets)
  ├─ Route: 10.1.0.0/16 → TGW
  └─ TGW → AI Services VPC (10.1.0.0/16)
```

**IAM Trust (MCP Tool Roles in AI Services Account)**:
```json
{
  "Effect": "Allow",
  "Principal": {
    "AWS": "arn:aws:iam::PROD_ACCOUNT:role/incident-detector-lambda"
  },
  "Action": "sts:AssumeRole",
  "Condition": {
    "StringEquals": {
      "sts:ExternalId": "agentcore-prod-incident"
    }
  }
}
```

---

## 5. Approval Workflow (n8n)

### 5.1 Incident Triage Loop

```
1. Incident detected (change deployed)
2. Agent correlates: metrics + traces + runbooks
3. Agent proposes: "Rollback config" OR "Scale up service-a"
4. n8n displays to on-call engineer:
   - Blast radius visualization
   - Recommended action
   - Runbook links
   - Owners to contact
5. Engineer approves or rejects (2-5 min review)
6. If approved: Step Functions executes containment
7. If rejected: Escalate to manager OR manual investigation
```

### 5.2 Metrics

- **Triage time**: < 2 minutes (agent) + < 5 minutes (human review) = < 7 min vs 30+ min manual
- **Accuracy**: Blast radius identification > 90%
- **Approval rate**: > 85% (on-call trusts agent)

---

## 6. Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| LangGraph (not Claude Agents) | Fine control over tool ordering, transparency for debugging |
| Bedrock KB (runbooks) | Institutional knowledge searchable during incidents |
| 5-6 MCP tools | Rich observability access; more complex than simple document classification |
| OBO tokens | On-call engineer identity visible in all tool calls (audit trail) |
| Proposal-only (no auto-execute) | Incidents are high-stakes; human judgment required |
| n8n approval UI | Familiar to ops team; low-code; fast iteration |
| Step Functions orchestration | Built-in audit trail, retry logic, human gates |
| Multi-account isolation | Production observability in separate account; blast radius contained |

