# AgentCore Gateway Design

## 1. Overview

**Purpose**: Central API gateway that routes incident triage requests from prod-operations to LangGraph agents, performing authentication, authorization, and MCP tool management.

**Architecture**:
```
prod-operations (incident-detector Lambda)
  ├─ SigV4 signed request
  ├─ POST /incidents
  └─ Header: x-caller-user: operator:john@company.com
      ↓
API Gateway (ai-services) - PRIVATE endpoint
  ├─ VPC endpoint only (not internet-facing)
  └─> Lambda Authorizer
      ├─ Validate SigV4 signature
      ├─ Extract caller account (prod-operations)
      ├─ Extract operator identity (john@company.com)
      └─ Return IAM policy + context
          ↓
Route to LangGraph Agent (ECS Fargate)
  ├─ HTTP/gRPC call
  ├─ Pass context: incident_id, caller, operator
  └─> Agent correlates metrics + traces + runbooks
      └─> Return blast radius analysis + proposal
          ↓
API Gateway returns to prod-operations
  └─> incident-detector Lambda receives response
      └─> Passes to Step Functions orchestration
```

---

## 2. API Gateway Configuration

### 2.1 Endpoint Type

**Private Endpoint** (VPC-only, no internet exposure):
```
Endpoint: https://agentcore.vpc-endpoint-abc123.ai-services.internal

Configuration:
├─ Type: REST API
├─ Endpoint type: PRIVATE
├─ VPC: 10.1.0.0/16 (ai-services)
├─ Subnet: 10.1.10.0/24 (private app subnet, AZ: us-east-1a)
├─ Security Group: agentcore-gateway-sg
│  ├─ Ingress: 10.2.0.0/16 (prod-operations) on 443
│  ├─ Ingress: 10.1.10.0/24 (Lambda Authorizer) on 443
│  └─ Egress: 0.0.0.0/0 on 443 (to invoke agents)
└─ Resource Policy:
   {
     "Effect": "Allow",
     "Principal": "*",
     "Action": "execute-api:Invoke",
     "Resource": "*",
     "Condition": {
       "IpAddress": {
         "aws:SourceIp": "10.2.0.0/16"
       }
     }
   }
```

### 2.2 Routes

| Method | Path | Authorization | Throttle | Lambda Integration |
|--------|------|---------------|----------|-------------------|
| POST | /incidents | Authorizer | 100 req/sec | triage-agent-invoke |
| GET | /incidents/{incident_id} | Authorizer | 100 req/sec | get-incident-status |
| POST | /containment/{proposal_id}/approve | Authorizer | 10 req/sec | execute-containment |
| GET | /health | None | N/A | health-check |

---

## 3. Lambda Authorizer

### 3.1 Purpose

Validate incoming requests from prod-operations account, extract caller identity, and return an IAM policy allowing the request to proceed.

### 3.2 Request Processing

**Input**:
```json
{
  "type": "TOKEN",
  "authorizationToken": "AWS4-HMAC-SHA256 Credential=...",
  "methodArn": "arn:aws:execute-api:us-east-1:AI_ACCOUNT:agentcore/prod/POST/incidents"
}
```

**Steps**:
```python
def lambda_authorizer(event):
    # 1. Extract authorization header
    auth_header = event['authorizationToken']
    # Example: "AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/20260921/..."
    
    # 2. Parse SigV4 signature
    credential_scope = parse_credential(auth_header)
    # credential_scope = {
    #   "access_key": "AKIAIOSFODNN7EXAMPLE",
    #   "date": "20260921",
    #   "region": "us-east-1",
    #   "service": "execute-api"
    # }
    
    # 3. Look up access key in prod-operations account
    # (via cross-account IAM or shared Secrets Manager)
    caller_role = lookup_role_by_access_key(credential_scope['access_key'])
    # caller_role = "arn:aws:iam::PROD_ACCOUNT:role/incident-detector-role"
    
    # 4. Verify SigV4 signature
    if not verify_signature(auth_header, request_body):
        raise UnauthorizedException("Invalid signature")
    
    # 5. Extract caller identity from request context
    caller_user = event['headers'].get('x-caller-user')
    # caller_user = "operator:john@company.com"
    
    # 6. Extract incident context
    incident_context = json.loads(event['body'])
    incident_id = incident_context.get('incident_id', 'incident-auto')
    
    # 7. Return authorization policy
    return {
        "principalId": caller_role,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": "Allow",
                    "Resource": event['methodArn']
                }
            ]
        },
        "context": {
            "caller": caller_role,
            "operator": caller_user,
            "incident_id": incident_id,
            "timestamp": datetime.utcnow().isoformat()
        }
    }
```

### 3.3 Error Handling

```python
if not verify_signature(...):
    raise AuthorizerConfigurationException("Signature verification failed")
    # API Gateway returns 403 Forbidden to caller
    # CloudTrail logs: "Unauthorized incident API call from prod-operations"

if not caller_role:
    raise TokenExpiredException("Unknown caller role")
    # API Gateway returns 401 Unauthorized

if caller_user not in on_call_list():
    raise UnauthorizedException("Caller not on-call")
    # Custom: Only registered on-call engineers can trigger incidents
    # CloudTrail: "Non-oncall user john@company.com attempted incident triage"
```

**Latency**: 50-100ms (SigV4 verification, role lookup)

---

## 4. Request Flow: POST /incidents

### 4.1 Request Payload

```json
{
  "incident_id": "incident-2026-09-21-001",
  "change_id": "deploy-2026-09-21-001",
  "severity": "CRITICAL",
  "affected_services": ["service-a", "service-b"],
  "timestamp": "2026-09-21T14:22:00Z",
  "caller_context": {
    "account_id": "PROD_ACCOUNT",
    "role": "incident-detector-role",
    "operator": "john@company.com"
  },
  "additional_data": {
    "error_message": "Config cache TTL change caused cascade failure",
    "metrics_spike_start": "2026-09-21T14:22:00Z",
    "estimated_impact_users": 15000,
    "revenue_impact_per_minute": "$45000"
  }
}
```

### 4.2 Response Payload

```json
{
  "incident_id": "incident-2026-09-21-001",
  "status": "triage_complete",
  "triage_summary": {
    "blast_radius": {
      "directly_affected": ["service-a", "service-b"],
      "cascading_impact": ["service-c", "service-d"],
      "total_services_impacted": 4,
      "duration_seconds": 450,
      "estimated_user_impact_percent": 12.5,
      "estimated_revenue_impact": "$45000"
    },
    "root_cause_hypothesis": "Config change introduced infinite loop in service-a connection pooling",
    "confidence_score": 0.94,
    "evidence": {
      "metric_spike": "service-a CPU 100% at 2026-09-21T14:22:00Z",
      "trace_finding": "service-b timeout 500ms after change",
      "topology_analysis": "service-a → service-b → service-c/d cascade"
    }
  },
  "recommended_actions": [
    {
      "action_type": "rollback_config",
      "target": "service-a",
      "rollback_version": "1234",
      "estimated_recovery_time_minutes": 5,
      "urgency": "CRITICAL",
      "rationale": "Config TTL change matches incident timing exactly"
    }
  ],
  "relevant_runbooks": [
    {
      "runbook_id": "rb-001",
      "title": "incident-response/service-a-outage.md",
      "excerpt": "If service-a CPU spikes after deployment:\n1. Check recent code changes\n2. Verify database connection pool\n3. Consider immediate rollback",
      "relevance_score": 0.94
    },
    {
      "runbook_id": "rb-002",
      "title": "containment/emergency-rollback.md",
      "excerpt": "Steps to safely rollback config without losing state...",
      "relevance_score": 0.87
    }
  ],
  "likely_owners": [
    {
      "team": "team-a-oncall",
      "contact": "slack: @team-a-oncall",
      "escalation": "manager: alice@company.com"
    }
  ],
  "next_step": "n8n approval workflow awaiting operator decision",
  "proposal_id": "proposal-2026-09-21-001",
  "approval_timeout_seconds": 1800,
  "timestamp_received": "2026-09-21T14:22:00Z",
  "timestamp_completed": "2026-09-21T14:22:15Z",
  "processing_time_ms": 15234
}
```

---

## 5. Agent Invocation

### 5.1 Integration with ECS Fargate Agents

**API Gateway → ECS Service**:
```
POST /incidents
  ├─> API Gateway routes to Target Group
  │   └─ Target: ECS Fargate service (langraph-agents)
  │   └─ Port: 8000 (gRPC/HTTP)
  │   └─ Health check: /health every 30 sec
  ├─> Network Load Balancer (internal)
  │   └─ 3 agents across AZs for HA
  └─> Agent receives request:
      {
        "incident_id": "incident-2026-09-21-001",
        "change_id": "deploy-2026-09-21-001",
        "context": {
          "caller": "arn:aws:iam::PROD:role/incident-detector-role",
          "operator": "john@company.com",
          "timestamp": "2026-09-21T14:22:00Z"
        }
      }
```

### 5.2 Agent State Management

**Stateless Agent**:
- Agent receives request
- Processes immediately (no persistent state)
- Returns response
- EventBridge sends state to Step Functions (in prod-operations)

**State Storage** (DynamoDB in prod-operations account):
```
Table: incident-states
├─ Partition Key: incident_id
├─ Sort Key: timestamp
└─ Attributes:
    ├─ incident_id: "incident-2026-09-21-001"
    ├─ status: "triage_complete"
    ├─ blast_radius_json: {...}
    ├─ proposal_id: "proposal-2026-09-21-001"
    ├─ approval_status: "pending"
    ├─ created_by: "john@company.com"
    ├─ created_at: "2026-09-21T14:22:00Z"
    └─ expires_at: "2026-09-21T16:22:00Z" (TTL 2 hours)
```

---

## 6. MCP Tool Management

### 6.1 Tool Registration

Each MCP tool is registered in the agent's runtime:

```python
# tools.py
tools = [
    {
        "name": "cloudwatch_metrics",
        "description": "Query CloudWatch metrics for incident services",
        "access_level": "read_only",
        "endpoint": "https://monitoring.prod-operations.internal/api/metrics",
        "auth_method": "cross_account_assume_role",
        "required_role": "arn:aws:iam::PROD:role/agentcore-observability-reader",
        "timeout_seconds": 10
    },
    {
        "name": "xray_traces",
        "description": "Get X-Ray traces to identify root cause",
        "access_level": "read_only",
        "endpoint": "https://xray.prod-operations.internal/api/traces",
        "auth_method": "cross_account_assume_role",
        "required_role": "arn:aws:iam::PROD:role/agentcore-observability-reader",
        "timeout_seconds": 10
    },
    {
        "name": "bedrock_runbook_retrieval",
        "description": "Search incident response runbooks",
        "access_level": "read_only",
        "endpoint": "https://bedrock.ai-services.internal/api/retrieve",
        "auth_method": "iam_role",
        "required_role": "arn:aws:iam::AI:role/langraph-agent-role",
        "timeout_seconds": 15
    },
    {
        "name": "change_details",
        "description": "Look up what code/config changed",
        "access_level": "read_only",
        "endpoint": "https://changes.prod-operations.internal/api/details",
        "auth_method": "cross_account_assume_role",
        "required_role": "arn:aws:iam::PROD:role/agentcore-observability-reader",
        "timeout_seconds": 5
    },
    {
        "name": "service_topology",
        "description": "Get service dependencies and blast radius",
        "access_level": "read_only",
        "endpoint": "https://topology.prod-operations.internal/api/graph",
        "auth_method": "cross_account_assume_role",
        "required_role": "arn:aws:iam::PROD:role/agentcore-observability-reader",
        "timeout_seconds": 5
    },
    {
        "name": "propose_containment",
        "description": "Propose a containment action (rollback, revert, etc.)",
        "access_level": "proposal_only",
        "endpoint": "https://orchestration.prod-operations.internal/api/propose",
        "auth_method": "cross_account_assume_role",
        "required_role": "arn:aws:iam::PROD:role/agentcore-observability-reader",
        "approval_required": True,
        "timeout_seconds": 5
    }
]
```

### 6.2 Tool Invocation Pattern

**LangGraph Agent Code**:
```python
from langgraph.graph import StateGraph
from typing import Annotated
import anthropic

# Define state
class IncidentState:
    incident_id: str
    change_id: str
    affected_services: list[str]
    metrics: dict
    traces: dict
    runbooks: list[dict]
    blast_radius: dict
    proposal: dict

# Define nodes (tool calls)
def query_metrics(state: IncidentState) -> dict:
    """Call CloudWatch metrics tool"""
    client = boto3.client('sts')
    credentials = client.assume_role(
        RoleArn='arn:aws:iam::PROD:role/agentcore-observability-reader',
        RoleSessionName='incident-triage',
        ExternalId='agentcore-prod-observability',
        DurationSeconds=900
    )
    
    # Use credentials to call CloudWatch
    cw = boto3.client('cloudwatch', credentials=credentials['Credentials'])
    response = cw.get_metric_statistics(...)
    state.metrics = response
    return state

def query_traces(state: IncidentState) -> dict:
    """Call X-Ray traces tool"""
    # Similar to query_metrics
    pass

def retrieve_runbooks(state: IncidentState) -> dict:
    """Call Bedrock KB retrieval"""
    bedrock = boto3.client('bedrock-runtime')
    response = bedrock.retrieve(...)
    state.runbooks = response['results']
    return state

def correlate_and_analyze(state: IncidentState) -> dict:
    """LLM-based analysis of metrics + traces + runbooks"""
    client = anthropic.Anthropic()
    
    prompt = f"""
    Incident ID: {state.incident_id}
    Change ID: {state.change_id}
    
    Metrics data: {json.dumps(state.metrics)}
    Traces: {json.dumps(state.traces)}
    Runbooks: {json.dumps(state.runbooks)}
    
    Based on the metrics, traces, and relevant runbooks:
    1. What is the blast radius (directly affected services + cascading)?
    2. What is the root cause hypothesis?
    3. What is your confidence level (0-1)?
    4. What containment actions do you recommend?
    """
    
    response = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}]
    )
    
    # Parse response into blast_radius + proposal
    state.blast_radius = parse_blast_radius(response)
    state.proposal = parse_proposal(response)
    return state

# Define graph
graph = StateGraph(IncidentState)
graph.add_node("query_metrics", query_metrics)
graph.add_node("query_traces", query_traces)
graph.add_node("retrieve_runbooks", retrieve_runbooks)
graph.add_node("analyze", correlate_and_analyze)

# Parallel MCP calls
graph.add_edge("start", "query_metrics")
graph.add_edge("start", "query_traces")
graph.add_edge("start", "retrieve_runbooks")

# After all queries, analyze
graph.add_edge("query_metrics", "analyze")
graph.add_edge("query_traces", "analyze")
graph.add_edge("retrieve_runbooks", "analyze")
graph.add_edge("analyze", "end")

# Compile and invoke
agent = graph.compile()
result = agent.invoke(initial_state)
```

**Execution Timeline**:
```
0ms: Request received
├─ 5ms: Parallel calls start (CloudWatch, X-Ray, Runbook KB)
├─ 50ms: CloudWatch responds (time-series data)
├─ 60ms: X-Ray responds (traces summary)
├─ 2100ms: Runbook KB responds (vector search + ranking)
├─ 3000ms: All data collected, LLM analysis begins
├─ 5100ms: LLM inference complete (blast radius identified)
└─ 5200ms: Response serialized and returned
```

**Total E2E Latency**: ~5.2 seconds (agent side only)

---

## 7. Error Handling & Resilience

### 7.1 Circuit Breaker Pattern

**Per-Tool**:
```python
class ToolCircuitBreaker:
    def __init__(self, threshold=5, timeout=60):
        self.failure_count = 0
        self.threshold = threshold
        self.timeout = timeout
        self.state = "CLOSED"  # CLOSED (working), OPEN (broken), HALF_OPEN (testing)
    
    def call(self, tool_func):
        if self.state == "OPEN":
            if time.time() - self.last_failure_time > self.timeout:
                self.state = "HALF_OPEN"
            else:
                raise ToolUnavailableException(f"Circuit breaker open for {self.timeout}s")
        
        try:
            result = tool_func()
            self.failure_count = 0
            self.state = "CLOSED"
            return result
        except Exception as e:
            self.failure_count += 1
            if self.failure_count >= self.threshold:
                self.state = "OPEN"
                self.last_failure_time = time.time()
            raise
```

### 7.2 Timeout Handling

```python
# If any tool times out, continue with partial data
try:
    metrics = query_metrics(timeout=5)
except TimeoutError:
    metrics = None  # Proceed with "metrics unavailable"
    logging.warning("CloudWatch query timed out, proceeding with traces + runbooks")

try:
    traces = query_traces(timeout=5)
except TimeoutError:
    traces = None

# Agent infers with partial data
state.metrics = metrics
state.traces = traces
state.blast_radius = correlate_and_analyze(state)  # Works with None values
```

### 7.3 Fallback Strategies

```
If all MCP tools fail:
  └─ Return: "Unable to correlate metrics. Manual investigation required."
  
If only observability fails (metrics, traces):
  └─ Return: "Blast radius unknown. Runbook suggests rollback anyway."
  
If only runbooks fail:
  └─ Return: "Blast radius identified but no procedures. Escalate to team-a-oncall."
```

---

## 8. Cost & Scaling

### 8.1 API Gateway Costs

```
Pricing (US East):
├─ Per million requests: $0.35 (on-demand)
├─ Data transfer out: $0.09 per GB
└─ Estimated for ~20 incidents/day:
    - 20 * 365 = 7,300 requests/year
    - 7,300 * $0.35 / 1,000,000 = $0.003/year (negligible)
```

### 8.2 Lambda Authorizer Costs

```
Per authorizer invocation: $0.001
├─ 7,300 requests/year * $0.001 = $7.30/year
```

### 8.3 Agent Scaling

**ECS Fargate**:
- Baseline: 1 task (2 vCPU, 4GB RAM)
- Auto-scale rule: If concurrent requests > 5, add task
- Max tasks: 10 (capacity for 100 concurrent incidents)
- Cost: ~$30/month (baseline) + $3/month per additional task

---

## 9. Monitoring & Observability

### 9.1 CloudWatch Metrics

```
Namespace: AgentCore/Gateway

Metrics:
├─ RequestCount (dimension: Operation)
├─ RequestLatency (dimension: Operation, Unit: Milliseconds)
├─ ToolCallDuration (dimension: Tool)
│  ├─ cloudwatch_metrics_latency
│  ├─ xray_traces_latency
│  ├─ bedrock_runbook_latency
│  └─ analysis_latency
├─ ErrorCount (dimension: ErrorType)
│  ├─ AuthorizationFailures
│  ├─ ToolTimeouts
│  ├─ NetworkErrors
│  └─ InvalidRequests
└─ BlastRadiusAccuracy (dimension: none, Unit: Percent)
   └─ Calculated post-incident: Did our blast radius match actual impact?
```

### 9.2 Alarms

```
Alarm: HighLatency
├─ Metric: RequestLatency (99th percentile)
├─ Threshold: 30 seconds
├─ Action: Alert on-call platform team
└─ Reason: Incident triage taking too long

Alarm: AuthorizationFailures
├─ Metric: ErrorCount (AuthorizationFailures)
├─ Threshold: 5 in 5 minutes
├─ Action: Alert security team
└─ Reason: Possible attack or misconfigured caller

Alarm: ToolTimeout
├─ Metric: ErrorCount (ToolTimeouts)
├─ Threshold: 10% of requests
├─ Action: Alert platform team
└─ Reason: Observability system is slow or down
```

---

## 10. Design Decisions & Trade-offs

| Decision | Rationale | Trade-off |
|----------|-----------|----------|
| **Private VPC endpoint** | Security; no internet exposure | Requires VPC connectivity (TGW) |
| **Lambda Authorizer** | Flexible, custom logic for SigV4 | Adds ~50-100ms latency |
| **Stateless agents** | Horizontal scaling, fault tolerance | State persisted in DynamoDB (prod-operations) |
| **Parallel MCP calls** | Faster triage (5-6 sec total) | Complex error handling (partial data) |
| **Proposal-only tools** | No auto-remediation risks | Slower MTTR (needs human approval) |
| **OBO tokens** | Full audit trail with operator identity | Complexity in cross-account assumes |

