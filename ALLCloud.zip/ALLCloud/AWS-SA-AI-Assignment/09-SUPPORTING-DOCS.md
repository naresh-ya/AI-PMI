# Supporting Documentation

## 1. Threat Model & Security Analysis

### 1.1 Attack Scenarios

**Scenario 1: Compromised Prod Operations Account**

```
Attacker Gains: incident-detector-role credentials

Attack 1a: Trigger false incidents
├─ Attacker calls AgentCore Gateway with fake metrics
├─ Agent triages, proposes rollback
├─ On-call approves (thinks it's real)
├─ Production config rolled back (disruption)
└─ Defense: Metrics must be from official sources (EventBridge validation)

Attack 1b: Exfiltrate topology knowledge
├─ Attacker queries agent for service dependencies
├─ Agent reveals: "If service-a down, affects service-b, c, d"
├─ Attacker now knows high-value targets
└─ Defense: Topology is not secret; architecture known to team

Attack 1c: Read CloudWatch metrics (low risk)
├─ Attacker has permissions anyway (their job is monitoring)
├─ Agent doesn't add new attack surface
└─ Defense: OK (metrics not sensitive)
```

**Scenario 2: Compromised AI Services Account**

```
Attacker Gains: LangGraph agent runtime

Attack 2a: Read prod metrics
├─ Attacker queries CloudWatch via agent
├─ But: IAM policies on assumed role restrict (metrics only)
├─ Cannot modify alarms, delete logs, etc.
└─ Defense: Least privilege IAM on cross-account role

Attack 2b: Read X-Ray traces
├─ Traces might contain customer data (names in requests)
├─ Attacker sees trace contents
└─ Defense: X-Ray access already restricted; agent doesn't add attack surface

Attack 2c: Exfiltrate runbook KB
├─ Attacker reads runbook procedures
├─ Runbooks are operational knowledge, not secret
├─ But: Might reveal infrastructure decisions
└─ Defense: Runbooks stored in KB (not raw S3); access logged

Attack 2d: Execute arbitrary containment
├─ Attacker calls propose-containment with malicious action
├─ Example: "Delete production database"
├─ But: Proposal is just a suggestion, not executed automatically
├─ On-call must approve
└─ Defense: Human approval gate blocks unintended actions
```

**Scenario 3: Attacker Influences Agent Decision**

```
Attack 3a: Compromise training data (runbooks)
├─ Attacker modifies runbook: "Whenever service-a high CPU, rollback service-b"
├─ Agent reads malicious runbook
├─ Agent proposes: "Rollback service-b" (wrong service)
├─ On-call approves (trusts agent)
├─ Production degradation
└─ Defense: Runbooks in Git; changes require code review + approval

Attack 3b: Inject malicious metrics
├─ Attacker publishes fake CloudWatch metrics
├─ Agent sees spike, proposes action
├─ But: EventBridge source validation blocks fake events
├─ Only official deployments trigger incidents
└─ Defense: Event source validation at EventBridge level

Attack 3c: Confuse agent with contradictory data
├─ Metrics say CPU low, traces say timeouts high
├─ Agent confidence drops (detected contradiction)
├─ Agent returns: "Unable to determine root cause, escalate to team"
├─ On-call investigates manually
└─ Defense: Agent detects conflicts, doesn't guess
```

### 1.2 Security Controls

| Threat | Control | Implementation |
|--------|---------|-----------------|
| **Unauthorized access to metrics** | IAM least privilege | cloudwatch:GetMetricStatistics only |
| **Agent autonomously modifying prod** | Approval gate | All actions require on-call approval |
| **Confused deputy (cross-account)** | External ID | All cross-account assumes require ExternalId |
| **Audit trail tampering** | Immutable logs | CloudTrail → immutable S3 bucket |
| **Runbook tampering** | Git-ops + review | All runbook changes code-reviewed before ingest |
| **Metric injection** | Event source validation | Only official EventBridge sources accepted |
| **Agent drift** | Blast radius accuracy monitoring | Post-incident accuracy measured + alarmed |

---

## 2. Operational Runbooks

### 2.1 Runbook: Agent Latency High (>20 seconds)

**Symptoms**: Incident triage taking too long, on-call impatient

**Investigation**:
```bash
# Check agent health
curl -s https://agentcore.internal/health | jq .

# Check CloudWatch metrics for agent errors
aws cloudwatch get-metric-statistics \
  --namespace AgentCore/Gateway \
  --metric-name ErrorCount \
  --start-time $(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 60 \
  --statistics Sum

# Check if MCP tools are slow
aws cloudwatch get-metric-statistics \
  --namespace AgentCore/Gateway \
  --metric-name ToolCallDuration \
  --dimensions Name=Tool,Value=cloudwatch_metrics_latency \
  --start-time $(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 60 \
  --statistics Average,Maximum
```

**Common Causes & Fixes**:
```
1. CloudWatch endpoint slow
   ├─ Symptom: cloudwatch_metrics_latency > 5s
   ├─ Cause: VPC endpoint overloaded
   ├─ Fix: Check VPC endpoint status
   │   aws ec2 describe-vpc-endpoints --filters Name=tag:Name,Values=cw-endpoint
   └─ If down, alert AWS support

2. Runbook KB query slow
   ├─ Symptom: bedrock_runbook_latency > 3s
   ├─ Cause: OpenSearch slow (heavy indexing happening)
   ├─ Fix: Check OpenSearch cluster health
   │   aws opensearchserverless get-cluster-status
   └─ If unhealthy, contact support

3. LLM inference slow
   ├─ Symptom: Total latency 15-20s, tools fast
   ├─ Cause: Claude model slow (capacity issue)
   ├─ Fix: No action needed; Bedrock will auto-retry
   └─ Temporary: Use lighter model (Haiku) as fallback

4. Agent task capacity exhausted
   ├─ Symptom: Multiple concurrent incidents, each slow
   ├─ Cause: Only 1 ECS task running, queuing requests
   ├─ Fix: Manually scale up
   │   aws ecs update-service \
   │     --cluster ai-services \
   │     --service langraph-agents \
   │     --desired-count 3
   └─ Auto-scaling should have triggered; check CloudWatch alarms
```

**Resolution**: Alert platform team if manual intervention needed (usually auto-scaling handles)

### 2.2 Runbook: Blast Radius Accuracy Low (<85%)

**Symptoms**: Agent predictions often wrong; on-call loses trust

**Investigation**:
```bash
# Get last 10 incidents
aws dynamodb query \
  --table-name incident-states \
  --index-name StatusIndex \
  --key-condition-expression "#s = :status" \
  --expression-attribute-names '{"#s":"status"}' \
  --expression-attribute-values '{":status":{"S":"resolved"}}' \
  --limit 10 \
  --scan-index-forward false

# For each incident, compare predicted vs actual blast radius
# Example: Incident 2026-09-21-001
#   Predicted: [service-a, service-b, service-c]
#   Actual: [service-a, service-b, service-c, service-d]
#   Accuracy: 3/4 = 75% (missed service-d)

# Check: Was service-d in topology at prediction time?
aws dynamodb get-item \
  --table-name service-topology \
  --key '{"service":{"S":"service-a"}}' \
  | jq '.Item.downstream'

# If service-d not in topology, that's the problem
```

**Common Causes & Fixes**:
```
1. Service topology stale
   ├─ Cause: New services added, not in topology metadata
   ├─ Fix: Update service topology
   │   Update ServiceTopology DynamoDB table with new service
   └─ Verify: Next incident should include new service

2. Runbook KB doesn't have incident procedures
   ├─ Cause: Missing runbook for service type
   ├─ Fix: Create and ingest new runbook
   │   Add "incident-response/service-d-timeout.md"
   │   Upload to S3 → EventBridge triggers ingestion
   └─ Verify: Query KB for "service-d" should return procedures

3. Correlation logic wrong
   ├─ Cause: Agent inference using wrong criteria
   ├─ Fix: Review agent prompt, update if needed
   │   Check: Are we correctly identifying cascading failures?
   └─ Test: Run synthetic incident, validate proposal

4. Metrics misleading
   ├─ Cause: Spike threshold too low (too many false positives)
   ├─ Fix: Tune alarm threshold
   │   Example: CPU spike trigger: change from 80% to 85%
   └─ Verify: Next incident has fewer false services
```

**Resolution**: Update topology/runbooks, re-test with synthetic incident

### 2.3 Runbook: On-Call Not Approving Agent Proposals

**Symptoms**: Approval rate < 70%; on-call clicking "Reject" frequently

**Investigation**:
```
# Check last 20 proposals
aws dynamodb query \
  --table-name incident-proposals \
  --index-name ApprovalRateIndex \
  --scan-index-forward false \
  --limit 20 \
  | jq '.Items[] | {proposal_id, action, approval_status, operator_feedback}'

# Pattern analysis:
# - Are all rejections on high-risk actions (rollback)?
# - Are rejections happening for specific services?
# - Is on-call providing feedback (why rejected)?
```

**Common Causes & Fixes**:
```
1. On-call doesn't trust agent yet
   ├─ Cause: Agent is new, track record not established
   ├─ Fix: Continue pilot phase, build credibility
   │   Track accuracy over 2-4 weeks
   └─ Expected: Approval rate increases with time

2. Proposals are too aggressive
   ├─ Cause: Agent recommends "Rollback" when scaling up is safer
   ├─ Fix: Review agent prompt, add conservative bias
   │   Update: "Prefer scale-up over rollback if possible"
   └─ Verify: Next proposals less destructive

3. On-call lacks context for approval
   ├─ Cause: Agent proposal is too brief
   ├─ Fix: Enhance proposal with more evidence
   │   Add: Metrics graphs, trace screenshots, runbook excerpts
   └─ Test: n8n displays richer proposal → approval rate ↑

4. Legitimately bad proposals
   ├─ Cause: Agent correlation is faulty
   ├─ Fix: Improve RAG + correlation logic
   │   Review false rejections, identify pattern
   └─ Action: Post-incident review with on-call
```

**Resolution**: Gather feedback, adjust agent prompts/KB, re-calibrate

---

## 3. Incident Response Case Studies

### 3.1 Case Study 1: Service A High CPU (Real Incident)

**Timeline**:
```
14:20:00 - CodePipeline deploys service-a (new config)
14:22:00 - CloudWatch alarm: service-a CPU > 95%
14:22:05 - EventBridge triggers incident-detector Lambda
14:22:10 - incident-detector calls AgentCore Gateway
14:22:15 - Agent queries metrics, traces, KB (parallel)
14:22:18 - Agent inference: "Config cache TTL too low → CPU spike"
14:22:20 - Agent returns proposal: "Rollback config to version 1234"
14:22:25 - n8n displays to on-call (john@company.com)
14:22:30 - John reviews, clicks "Approve Rollback"
14:22:35 - Step Functions executes: CloudFormation update
14:22:40 - Config rolled back to version 1234
14:23:00 - CloudWatch alarm clears (service-a CPU drops to 20%)
14:23:30 - Incident marked: RESOLVED

Total MTTR: 3 minutes 30 seconds (vs 30+ min manual)
Savings: 26+ minutes
```

**Post-Incident Review**:
- Root cause: Config cache TTL change (1h → 5min) caused cache thrashing
- Agent accuracy: 100% (correctly identified service-a → service-b cascade)
- Decision: Approve rate 100% (on-call trusted agent proposal)
- Action: Update runbook "incident-response/service-a-outage.md" with this case

### 3.2 Case Study 2: Database Query Regression (Failed Incident)

**Timeline**:
```
16:30:00 - CodePipeline deploys service-b (new query logic)
16:32:00 - CloudWatch alarm: service-b response latency > 5s
16:32:05 - EventBridge triggers incident-detector
16:32:15 - Agent queries but X-Ray endpoint is slow (timeout)
16:32:25 - Agent proceeds with metrics + KB only (fallback)
16:32:35 - Agent proposes: "Scale up service-b" (missing evidence)
16:33:00 - n8n displays proposal to on-call (jane@company.com)
16:33:30 - Jane reviews, sees proposal is weak (no root cause)
16:33:45 - Jane clicks "Reject" + escalates to manager
16:35:00 - Manager reviews database logs, finds slow query
16:37:00 - Manager approves rollback (code change, not config)
16:38:00 - Code rolled back, incident resolved

Total MTTR: 8 minutes (agent added 5-10s latency, but not helpful)
Analysis: X-Ray timeout prevented full analysis
```

**Post-Incident Review**:
- Root cause: Query N+1 problem in new code
- Agent accuracy: 30% (proposed wrong action due to incomplete data)
- Decision: Improve X-Ray availability + increase timeout threshold
- Action: Add new runbook "incident-response/service-b-slow-queries.md"

---

## 4. ADRs (Architecture Decision Records)

### 4.1 ADR-001: Multi-Account Design

**Decision**: Separate AI services from prod operations (different accounts)

**Rationale**:
- Isolation: Compromise of AI account ≠ compromise of production
- Blast radius: Agent can read metrics but not modify production
- Audit trail: All cross-account calls logged separately

**Alternatives Considered**:
- Single account: Simpler but dangerous (agent has prod access)
- Three accounts: Needed (prod-ops + ai-services + security)

**Consequence**:
- ✓ Better security posture
- ✗ More complex cross-account IAM setup

---

### 4.2 ADR-002: Proposal-Only Architecture

**Decision**: Agent proposes actions but doesn't execute (human approval always)

**Rationale**:
- Incidents are high-stakes; human judgment needed
- Prevent autonomous mistakes (e.g., wrong rollback target)
- On-call remains in control loop

**Alternatives Considered**:
- Agent auto-executes if confidence > 0.95: Faster but risky
- Agent executes only for safe actions (scale-up): Still risky

**Consequence**:
- ✓ Safer (human approval gate)
- ✗ Slightly slower MTTR (needs approval time)

---

### 4.3 ADR-003: LangGraph over Claude Agents

**Decision**: Use LangGraph (explicit tool sequencing) instead of Claude Agents

**Rationale**:
- Transparency: Know exactly which tools are called when
- Debuggability: Each step is explicit (easier to trace issues)
- Reliability: No tool-call surprises (agent forced into LangGraph steps)

**Alternatives Considered**:
- Claude Agents: Simpler but black-box tool decisions
- Custom agent: Too much work, LangGraph is proven

**Consequence**:
- ✓ Transparent tool calling
- ✗ More code to write (vs Claude Agents)

---

## 5. Monitoring & Alerting

### 5.1 CloudWatch Dashboards

**Dashboard 1: Agent Health**
```
Panels:
├─ Request count (incidents/day)
├─ Request latency (p50, p99)
├─ Error count (by error type)
├─ Tool latency (CloudWatch, X-Ray, KB)
└─ Availability (% of successful requests)
```

**Dashboard 2: Incident Metrics**
```
Panels:
├─ MTTR trend (last 30 days)
├─ Blast radius accuracy (% correct)
├─ Approval rate (% approved)
├─ False alarm rate (% triggered unnecessarily)
└─ Cost vs savings (ROI)
```

### 5.2 Critical Alarms

```
Alarm 1: High MTTR
├─ Metric: IncidentMTTR (minutes)
├─ Threshold: > 15 minutes
├─ Action: Page platform team
└─ Reason: Something broke (agent latency or approval flow)

Alarm 2: Low Accuracy
├─ Metric: BlastRadiusAccuracy (%)
├─ Threshold: < 80%
├─ Action: Page platform team
└─ Reason: Agent correlation degraded

Alarm 3: Agent Errors
├─ Metric: AgentErrorCount
├─ Threshold: > 5 errors in 5 minutes
├─ Action: Page on-call (incidents can't be triaged)
└─ Reason: Agent failure requires manual investigation

Alarm 4: Unauthorized Access Attempts
├─ Metric: UnauthorizedAccessCount (CloudTrail)
├─ Threshold: > 10 in 5 minutes
├─ Action: Alert security team
└─ Reason: Possible attack on agent
```

---

## 6. Rollback & Failure Recovery

### 6.1 Quick Rollback

If agent is causing issues:

```bash
# Disable agent (switch to manual-only)
aws ecs update-service \
  --cluster ai-services \
  --service langraph-agents \
  --desired-count 0

# Disable EventBridge rule (stop triggering agent)
aws events disable-rule --name incident-detector-to-agentcore

# On-call investigates manually (revert to 30+ min MTTR)
# Investigation: Check CloudTrail, agent logs, recent changes
```

### 6.2 Graceful Restart

```bash
# Check agent logs
aws logs tail /ecs/langraph-agents --follow --since 1h

# If issue found, deploy fix
cd ai-services && git push # deploys new agent version via CI/CD

# Gradually restart tasks (blue-green deployment)
aws ecs update-service \
  --cluster ai-services \
  --service langraph-agents \
  --force-new-deployment
```

