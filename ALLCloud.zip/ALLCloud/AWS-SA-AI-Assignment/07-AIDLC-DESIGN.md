# AIDLC (Agent Incident Development Lifecycle) Design

## 1. Overview

**Purpose**: Define the development, validation, and operational lifecycle for the incident response agent, emphasizing careful iteration and incident-safe deployment.

**Phases**:
1. **Design**: Define incident scenarios, success metrics, MCP tools
2. **Development**: Build agent, implement MCP tool integrations
3. **Validation**: Test against synthetic incidents, validate blast radius accuracy
4. **Staging**: Dry-run on staging production clone
5. **Pilot**: Live incidents with strong approval gates
6. **Production**: Full automation with monitoring
7. **Operations**: Continuous improvement, runbook updates

---

## 2. Design Phase

### 2.1 Incident Scenario Definition

**Document**: Typical incident scenarios the agent must handle

| Incident Type | Trigger | Expected Blast Radius | Success Criteria |
|---------------|---------|----------------------|------------------|
| **Code Deploy → High CPU** | New code deployed, CPU spikes | 1-4 services | Identify within 2 min, propose rollback |
| **Config Change → High Memory** | Config update, memory leak | 1-2 services | Identify cause, suggest revert |
| **DB Query Regression** | Query slow after deploy | 3-5 services (cascading) | Trace root to database, propose rollback |
| **Traffic Spike (Legit)** | Black Friday, legitimate surge | All services | Distinguish from outage, recommend scale-up |
| **Regional Failure** | AZ down or region partition | 10+ services | Identify blast radius, propose failover |

**For Each Scenario**:
- What metrics indicate the problem?
- What is the blast radius?
- What is the root cause?
- What is the recommended containment?
- How long should remediation take?

### 2.2 Success Metrics

```
MTTR (Mean Time To Recovery)
├─ Target: < 5 minutes (vs 30+ min manual)
├─ Measurement: Incident start → On-call approves containment
├─ Current baseline (manual): 30-45 minutes
└─ Improvement: 6-8x faster

Blast Radius Accuracy
├─ Target: > 90% (agent vs actual)
├─ Measurement: Post-incident review
├─ Calculation: (Correctly identified services) / (Total impacted services)
├─ Example: Agent says A+B+C affected, actual is A+B+C+D
│   └─ Accuracy: 3/4 = 75% (missed D, but identified 3 correctly)
└─ Action: If < 85%, review KB and correlations

Approval Rate
├─ Target: > 85% (on-call approves agent recommendation)
├─ Measurement: Approvals / Total proposals
├─ If > 95%: Agent may be too conservative, consider more autonomy
└─ If < 75%: Agent decisions lack confidence, review prompts

False Alarm Rate
├─ Target: < 5% (agent triggers incident for non-problem)
├─ Measurement: Triggered incidents / Total metric spikes
├─ Example: 10 CPU spikes detected, 9 were real incidents, 1 was false alarm
├─ If > 10%: Tighten spike detection thresholds
└─ Action: Reduce unnecessary on-call pages

Cost Impact
├─ Target: < $100/month (agent infrastructure)
├─ Breakdown:
│   ├─ Bedrock embeddings + retrieval: ~$15/month
│   ├─ OpenSearch: ~$24/month
│   ├─ API Gateway + Lambda: < $1/month
│   ├─ ECS Fargate agents: ~$30/month
│   └─ Total: ~$70/month
└─ ROI: If agent prevents one incident / month at $45K cost = $45K savings / $70 cost = 640x ROI
```

### 2.3 MCP Tool Design Matrix

| Tool | API | Latency | Cost | Risk |
|------|-----|---------|------|------|
| CloudWatch Metrics | GetMetricStatistics | 50ms | < $0.01/month | Read-only ✓ |
| X-Ray Traces | GetTraceSummary | 50ms | < $0.01/month | Read-only ✓ |
| Runbook KB | Bedrock Retrieve | 2500ms | ~$0.0005/query | Read-only ✓ |
| Change Details | S3 GetObject | 50ms | < $0.01/month | Read-only ✓ |
| Service Topology | Custom API | 50ms | ~$0/month | Read-only ✓ |
| Propose Containment | Custom API | 100ms | ~$0/month | Gated ⚠️ |

---

## 3. Development Phase

### 3.1 Agent Architecture Decisions

**Tech Stack Decision Table**:

| Component | Option A | Option B | Option C | Decision |
|-----------|----------|----------|----------|----------|
| **Agent Framework** | LangGraph | Claude Agents | LLaMA Agentic | **LangGraph** ✓ |
| | ➕ Transparent tool calling | ➕ Simpler code | ➖ Complex inference | Reason: Fine control |
| | ➕ Non-blocking steps | ➖ Black box | ➖ Slow reasoning | over tool sequencing |
| **LLM** | Claude 3.5 Sonnet | GPT-4o | Mixtral | **Claude 3.5** ✓ |
| | ➕ Best reasoning | ➕ Cheaper | ➖ Lower quality | Reason: Incident |
| | ➕ Long context | ➕ Faster | | triage requires |
| | | | | reasoning excellence |
| **Deployment** | ECS Fargate | Lambda | SageMaker | **ECS Fargate** ✓ |
| | ➕ Python/LangGraph | ➖ Code package limits | ➖ Overkill, expensive | Reason: Flexibility, |
| | ➕ Scalable | ➖ Timeout limits | ➖ Complex setup | long-running agent |
| | ➕ Stateless | ➕ Simpler ops | | code needs |
| **State Storage** | DynamoDB | RDS | S3 | **DynamoDB** ✓ |
| | ➕ Serverless | ➖ Must manage | ➖ Slow reads | Reason: Fast |
| | ➕ Fast reads | | | lookups, TTL |
| | ➕ TTL support | | | expiration |
| **Vector DB** | OpenSearch | Pinecone | Weaviate | **OpenSearch** ✓ |
| | ➕ AWS-native | ➖ External API | ➖ Complex setup | Reason: AWS |
| | ➕ VPC-local | ➖ Vendor lock-in | ➖ Limited tooling | integration, VPC |
| | ➕ Cost predictable | | | security |

### 3.2 Development Phases (Timeline)

**Week 1: Core Agent**
```
Day 1-2: Scaffold LangGraph agent
  ├─ Create state machine (IncidentState)
  ├─ Define nodes (query_metrics, query_traces, analyze)
  └─ Basic error handling

Day 3-4: MCP Tool Integration (read-only)
  ├─ CloudWatch metrics tool
  ├─ X-Ray traces tool
  ├─ Change details tool
  └─ Service topology tool

Day 5: Bedrock KB Integration
  ├─ Runbook embedding + ingest
  └─ Query + retrieval logic
```

**Week 2: Refinement**
```
Day 1-2: Correlation Logic
  ├─ Implement blast radius identification
  ├─ Cascade analysis (A → B → C)
  └─ Confidence scoring

Day 3-4: Proposal Tool (gated)
  ├─ Implement propose_containment endpoint
  ├─ Validation (rollback version exists, etc.)
  └─ Error handling

Day 5: Integration Testing
  ├─ End-to-end incident flow
  ├─ Latency benchmarks
  └─ Error recovery
```

**Week 3: Deployment**
```
Day 1-2: Containerize (Docker)
  ├─ Dockerfile for LangGraph agent
  ├─ ECR repository
  └─ ECS task definition

Day 3-4: Staging Deployment
  ├─ Deploy to ai-services-staging account
  ├─ Test cross-account IAM access
  └─ Validate VPC networking

Day 5: Documentation
  ├─ Architecture diagram
  ├─ Runbook for troubleshooting
  └─ Operational guide
```

---

## 4. Validation Phase

### 4.1 Testing Strategy

**Unit Tests** (agent logic):
```python
def test_blast_radius_calculation():
    # Given: service-a CPU spike, traces show timeout to service-b
    metrics = {"service-a": {"cpu": 95}, "service-b": {"latency": 3000}}
    topology = {"service-a": ["service-b", "service-c"]}
    
    # When: agent correlates
    blast_radius = agent.correlate(metrics, topology)
    
    # Then: should identify 3 affected services
    assert blast_radius['directly_affected'] == ["service-a"]
    assert "service-b" in blast_radius['cascading_impact']
    assert blast_radius['confidence'] > 0.85
```

**Integration Tests** (tool calls):
```python
def test_cloudwatch_metrics_retrieval():
    # Given: incident with affected service
    incident = {"affected_services": ["service-a"], "timestamp": "..."}
    
    # When: agent calls CloudWatch tool
    metrics = agent.query_metrics(incident)
    
    # Then: should return time-series data
    assert len(metrics['datapoints']) > 0
    assert 'service-a' in metrics['metric_data']
```

**Synthetic Incident Tests** (end-to-end):
```python
def test_incident_cpu_spike():
    # Scenario: Service-a CPU spike after deployment
    
    # Setup: Pre-stage metrics + traces
    setup_metrics({
        "service-a": {"cpu": {"2026-09-21T14:22:00Z": 95}},
        "service-b": {"latency": {"2026-09-21T14:22:30Z": 3000}}
    })
    setup_traces({
        "service-b": {"errors": "Timeout calling service-a"}
    })
    
    # Trigger: Agent receives incident
    result = agent.triage_incident({
        "change_id": "deploy-2026-09-21-001",
        "affected_services": ["service-a"]
    })
    
    # Validate: Blast radius correct + proposal reasonable
    assert "service-a" in result['blast_radius']['directly_affected']
    assert "service-b" in result['blast_radius']['cascading_impact']
    assert result['recommended_actions'][0]['action_type'] == 'rollback_config'
    assert result['confidence_score'] > 0.85
```

### 4.2 Blast Radius Accuracy Validation

**Post-Incident Review Process**:

```
Incident Resolved:
  ├─ On-call executes containment action
  ├─ System recovers
  ├─ Incident marked: RESOLVED
  └─ 1 hour later: Automated review triggered

Comparison:
  ├─ Agent predicted blast radius: [service-a, service-b, service-c, service-d]
  ├─ Actual impact (CloudWatch alarm data): [service-a, service-b, service-c]
  ├─ Accuracy = 3 / 3 = 100% ✓
  └─ If agent predicted [service-a, service-b], missed [service-c, service-d]:
      └─ Accuracy = 2 / 4 = 50% ✗ (investigate why)

Metric Tracked in CloudWatch:
├─ Namespace: AgentCore/Metrics
├─ Metric: BlastRadiusAccuracy
├─ Dimensions:
│   ├─ ServiceName: [service-a, service-b, ...]
│   ├─ IncidentType: [cpu-spike, query-regression, ...]
│   └─ TimeRange: [day, week, month]
└─ Alarm: If BlastRadiusAccuracy < 85%, alert platform team
```

---

## 5. Staging Phase

### 5.1 Staging Environment Setup

**Staging Account**: `prod-operations-staging`
```
├─ Clone of prod (same services, smaller scale)
├─ Same CloudWatch metrics (but for staging traffic)
├─ Same X-Ray endpoints
├─ Same KB (runbooks)
├─ But: No automatic containment execution (manual approval always)
└─ Used for: Pre-production testing of agent + approval workflow
```

### 5.2 Dry-Run Incidents

**Scenario 1: Service CPU Spike**
```
1. Inject synthetic metric spike in service-a (staging)
2. EventBridge rule triggers incident-detector
3. Agent runs triage
4. Agent proposes: "Rollback config"
5. n8n displays to staging operator (not real on-call)
6. Staging operator clicks: "Approve"
7. Step Functions LOGS the action but DOES NOT EXECUTE
8. Operator verifies: "Would have rolled back config v1234"
9. Result logged to CloudTrail for review
```

**Scenario 2: Cascading Failure**
```
1. Inject: service-a down
2. Expected: service-b timeout → service-c slow → service-d degraded
3. Agent should identify all 4 services
4. Agent proposes: "Traffic shift to canary"
5. Validation: Proposal is reasonable for cascading failure
6. Metrics: Accuracy = 4/4 = 100% ✓
```

---

## 6. Pilot Phase

### 6.1 Pilot Deployment Strategy

**Phase 1a: Low-Risk Incidents Only** (Week 1)
```
├─ Agent enabled for: Non-production incidents (staging, test accounts)
├─ Real on-call team notified but can ignore agent
├─ n8n approval workflow: "Override agent with manual decision"
├─ Timeout: 30 minutes (on-call can wait for manual investigation)
└─ Metrics: Measure agent accuracy, approval rate, latency
```

**Phase 1b: Production Incidents (Week 2)**
```
├─ Agent enabled for: Production incidents in low-risk services
├─ Services: Batch processing, analytics (non-customer-facing)
├─ Real on-call team involved (approval required)
├─ n8n approval workflow: Agent proposal → On-call approves/rejects
├─ Timeout: 15 minutes (on-call decides action)
└─ Metrics: Track MTTR, approval rate, blast radius accuracy
```

**Phase 1c: All Services (Week 3)**
```
├─ Agent enabled for: All production services
├─ Real on-call team: Agent assists with all incidents
├─ n8n approval workflow: Same as 1b
├─ Timeout: 10 minutes (faster triage → faster decision)
└─ Metrics: Comprehensive MTTR tracking, cost savings calculation
```

### 6.2 Pilot Success Criteria

| Metric | Target | Status |
|--------|--------|--------|
| **MTTR** | < 10 min | ✓ Pass if actual triage + decision < 10 min |
| **Accuracy** | > 85% | ✓ Pass if blast radius accuracy > 85% |
| **Approval Rate** | > 80% | ✓ Pass if on-call approves > 80% of proposals |
| **False Alarms** | < 5% | ✓ Pass if spurious incidents < 5% of total |
| **Uptime** | > 99.5% | ✓ Pass if agent available for all incidents |

**If any metric fails**: Rollback to manual-only, investigate, and retry.

---

## 7. Production Phase

### 7.1 Full Deployment

**Rollout Timeline**:
```
Week 1: All services, strong approval gates
├─ n8n approval required for all containment actions
├─ Timeout: 10 minutes
├─ Monitoring: MTTR, accuracy, approval rate
└─ Contingency: If issues detected, rollback to manual

Week 2: Increased Autonomy (if metrics are good)
├─ Lower-risk services: Agent can auto-execute minor actions
│   └─ Example: Scale up (not destructive)
├─ Higher-risk services: Still require approval
│   └─ Example: Rollback (potentially data-destructive)
└─ Approval timeout: 5 minutes (time-sensitive decisions)

Week 3+: Continuous Optimization
├─ Monitor trends (improving MTTR? accuracy?  cost?)
├─ Update KB as new incidents occur
├─ Refine correlation logic based on false positives
└─ Expand agent autonomy for proven-safe actions
```

### 7.2 Operational Runbook (Agent Issues)

**If Agent Latency High (> 20 seconds)**:
```
1. Check: Is LangGraph agent responding?
   └─ curl https://agentcore.internal/health
   
2. Check: CloudWatch metrics for agent errors
   └─ aws cloudwatch get-metric-statistics --namespace AgentCore/Gateway
   
3. If errors high: Restart ECS tasks
   └─ aws ecs update-service --service langraph-agents --force-new-deployment
   
4. If restarted still slow: Check MCP tools
   └─ Are CloudWatch, X-Ray endpoints responding?
   
5. If endpoints slow: Fallback to keyword-only correlation
   └─ Agent can still use KB, just slower
```

**If Agent Accuracy Low (< 85%)**:
```
1. Review failed incidents (last 5)
   └─ What did agent predict? What was actual?
   
2. Check: Is KB missing runbooks?
   └─ If incident type not covered, ingest new runbook
   
3. Check: Is correlation logic wrong?
   └─ Maybe service topology is stale; update metadata
   
4. Check: Are metrics misleading?
   └─ Maybe spike detection threshold too low; tune threshold
```

---

## 8. Operations Phase

### 8.1 Continuous Monitoring

**CloudWatch Dashboards**:
```
Dashboard: AgentCore Operations

1. MTTR Trends
   ├─ Graph: MTTR (minutes) over time (last 30 days)
   ├─ Target: < 5 min (vs 30+ manual)
   └─ Alarm: If MTTR > 15 min, alert platform team

2. Accuracy Trends
   ├─ Graph: BlastRadiusAccuracy (%) over time
   ├─ Broken down by incident type (cpu, memory, query)
   └─ Alarm: If accuracy < 80%, alert on-call

3. Approval Rate
   ├─ Graph: Approvals / Total proposals (%)
   ├─ Insight: If 100%, agent may be too conservative
   └─ Insight: If < 70%, on-call doesn't trust agent

4. Cost vs Savings
   ├─ Cost: $70/month agent infrastructure
   ├─ Savings: Average incident severity * cost saved by faster MTTR
   │   └─ Example: 1 incident/month * 25 min faster * $3K/min = $75K savings
   ├─ ROI: $75K / $70 = 1,071x
   └─ Visibility: Dashboard shows cost-benefit monthly
```

### 8.2 Runbook Evolution

**Process**:
1. New incident occurs
2. On-call uses agent triage
3. Incident resolved
4. Post-incident review identifies missing runbook
5. Team writes new runbook + ingests to KB
6. Next similar incident: Agent has better context

**Tracking**:
```
Runbook Update Log:
├─ 2026-09-21: Added "incident-response/service-c-memory-leak.md"
│   └─ Reason: Incident 1234 (service-c OOM) lacked procedures
├─ 2026-09-28: Updated "containment/config-revert-safely.md"
│   └─ Reason: Incident 1240 showed procedure incomplete
└─ 2026-10-05: Added "escalation/regional-failover.md"
    └─ Reason: Regional failure incidents need specific procedures
```

### 8.3 Agent Health Checks

**Weekly Review**:
```
Checklist:
├─ [ ] MTTR trend: Is it improving? (expect gradual improvement)
├─ [ ] Accuracy trend: Is it stable? (expect > 90%)
├─ [ ] Approval rate: Is it in target range (80-95%)?
├─ [ ] False alarms: Is rate < 5%?
├─ [ ] KB freshness: Are runbooks updated (< 30 days)?
├─ [ ] MCP tool latency: Are tools responsive (< 10s total)?
└─ [ ] Cost: Is it within budget (< $100/month)?
```

**Quarterly Review**:
```
Questions:
1. How many incidents did agent help triage? (Expected: 20+)
2. What was average MTTR improvement? (Expected: 80%+ faster)
3. What revenue was saved? (ROI analysis)
4. What runbooks were added? (KB growing?)
5. What failed incidents teach us? (Improvements needed?)
6. Should we expand agent autonomy? (Safer actions auto-execute?)
```

---

## 9. Design Decisions

| Decision | Rationale | Trade-off |
|----------|-----------|----------|
| **LangGraph over Claude Agents** | Transparent tool sequencing, debuggable | More code to write |
| **Staged rollout** | Catch issues early, minimize blast radius | Slower time-to-value |
| **Proposal-only architecture** | No automatic fixes, human judgment required | Slower MTTR (needs approval) |
| **Strong approval gates in pilot** | Build trust in agent before autonomy | Requires on-call engagement |
| **Quarterly reviews** | Track metrics, catch degradation early | Administrative overhead |
| **KB versioning** | Trace runbook changes, blame issues | Must maintain Git history |

