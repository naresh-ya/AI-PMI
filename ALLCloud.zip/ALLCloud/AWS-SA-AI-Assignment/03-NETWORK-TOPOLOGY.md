# Network Topology Design

## 1. Multi-Account Structure

### Account Roles

| Account | Role | VPC CIDR | Purpose |
|---------|------|---------|---------|
| `shared-network` | Hub | 10.0.0.0/16 | Centralized networking, NAT, Transit Gateway |
| `ai-services` | Spoke | 10.1.0.0/16 | AgentCore Gateway, LangGraph Agent, MCP servers, Bedrock KB |
| `prod-operations` | Spoke | 10.2.0.0/16 | Production metrics, X-Ray traces, change tracking, n8n approval |
| `security-logging` | Spoke | 10.3.0.0/16 | CloudTrail, centralized logs, GuardDuty, audit bucket |
| `shared-services` | Spoke | 10.4.0.0/16 | (Optional) Bedrock shared endpoint, Secrets Manager |

---

## 2. Shared Network Hub (10.0.0.0/16)

### Subnet Layout

```
Shared Network Hub VPC (10.0.0.0/16)
├── Public Subnets (NAT, ALB, Bastion)
│   ├── us-east-1a: 10.0.1.0/24 (NAT Gateway A, ALB)
│   ├── us-east-1b: 10.0.2.0/24 (NAT Gateway B, ALB)
│   └── us-east-1c: 10.0.3.0/24 (NAT Gateway C, ALB)
│
├── Private Subnets (Reserved for future hub services)
│   ├── us-east-1a: 10.0.10.0/24
│   ├── us-east-1b: 10.0.11.0/24
│   └── us-east-1c: 10.0.12.0/24
│
└── Transit Gateway Attachment Point
    └── Route: All traffic for spokes (10.1.0.0/16, 10.2.0.0/16, 10.3.0.0/16) → TGW
```

### Key Components

**Transit Gateway (TGW)**:
- Region: us-east-1
- Route table: spoke-to-spoke enabled (hub-spoke topology)
- Default route propagation: enabled

**NAT Gateways**:
- One per AZ (3 total) behind public ALB
- Elastic IPs: xxx.xxx.xxx.1, xxx.xxx.xxx.2, xxx.xxx.xxx.3
- Used by all spokes for egress to internet (S3, ECR, Bedrock)

---

## 3. AI Services VPC (10.1.0.0/16)

### Subnet Design

```
AI Services VPC (10.1.0.0/16)
├── Private App Subnets (AgentCore, LangGraph)
│   ├── us-east-1a: 10.1.10.0/24
│   ├── us-east-1b: 10.1.11.0/24
│   └── us-east-1c: 10.1.12.0/24
│   └── Running: API Gateway (private), Lambda Authorizer, ECS Fargate agents
│
├── Private Data Subnets (Bedrock KB, RDS)
│   ├── us-east-1a: 10.1.20.0/24
│   ├── us-east-1b: 10.1.21.0/24
│   └── us-east-1c: 10.1.22.0/24
│   └── Running: Bedrock Agents, OpenSearch cluster (for embeddings), RDS (metadata)
│
└── VPC Endpoints (Interface)
    ├── Bedrock: vpce-bedrock (10.1.30.0/28)
    ├── Bedrock Agents: vpce-bedrock-agents (10.1.30.16/28)
    ├── CloudWatch Logs: vpce-logs (10.1.30.32/28)
    ├── Secrets Manager: vpce-secrets (10.1.30.48/28)
    └── S3: Gateway endpoint (no IP)
```

### Security Groups

**`agentcore-gateway-sg`**:
```
Ingress:
  - Source: prod-operations account via TGW (10.2.0.0/16)
    Protocol: HTTPS (443)
    Description: "Incident API calls from prod-operations"
  - Source: 10.1.10.0/24 (Lambda Authorizer)
    Protocol: HTTPS (443)
    Description: "Authorizer to Gateway communication"

Egress:
  - Destination: 10.1.20.0/24 (Data subnets)
    Protocol: HTTPS (443)
    Description: "Gateway to Bedrock KB + RDS"
  - Destination: VPC Endpoint (Bedrock)
    Protocol: HTTPS (443)
    Description: "Bedrock API calls"
  - Destination: 0.0.0.0/0
    Protocol: HTTPS (443)
    Description: "Internet (Bedrock Anthropic endpoints)"
```

**`langraph-agent-sg`**:
```
Ingress:
  - Source: agentcore-gateway-sg
    Protocol: TCP 8000 (gRPC/HTTP)
    Description: "Agent API calls from Gateway"

Egress:
  - Destination: 10.1.20.0/24
    Protocol: HTTPS (443)
    Description: "MCP tool calls to Bedrock KB"
  - Destination: VPC Endpoint (CloudWatch, Secrets Manager)
    Protocol: HTTPS (443)
    Description: "Logging and secret retrieval"
  - Destination: prod-operations via TGW (10.2.0.0/16)
    Protocol: HTTPS (443)
    Description: "MCP tool calls to prod observability (through TGW)"
  - Destination: 0.0.0.0/0
    Protocol: HTTPS (443)
    Description: "Internet (Bedrock inference)"
```

**`bedrock-kb-sg`**:
```
Ingress:
  - Source: langraph-agent-sg
    Protocol: HTTPS (443)
    Description: "Agent queries runbook KB"

Egress:
  - Destination: 0.0.0.0/0
    Protocol: HTTPS (443)
    Description: "Bedrock knowledge base API"
```

### Route Table

```
AI Services VPC Route Table
Destination         Next Hop          Source
0.0.0.0/0          TGW:spoke-rt      For traffic to prod-operations, security-logging
10.1.0.0/16        Local              Local subnets
169.254.169.254/32 Local              VPC metadata service
```

---

## 4. Prod Operations VPC (10.2.0.0/16) - CRITICAL for Incident Response

### Subnet Design

```
Prod Operations VPC (10.2.0.0/16)
├── Private App Subnets (Orchestration, n8n approval)
│   ├── us-east-1a: 10.2.10.0/24
│   ├── us-east-1b: 10.2.11.0/24
│   └── us-east-1c: 10.2.12.0/24
│   └── Running: incident-detector Lambda, Step Functions, n8n ECS Fargate
│
├── Private Data Subnets (CloudWatch, X-Ray, Config)
│   ├── us-east-1a: 10.2.20.0/24
│   ├── us-east-1b: 10.2.21.0/24
│   └── us-east-1c: 10.2.22.0/24
│   └── CloudWatch metrics endpoints, X-Ray ingest, change tracking
│
├── VPC Endpoints (Interface - CRITICAL for observability read)
│   ├── CloudWatch: vpce-cw (10.2.30.0/28) - READ-ONLY
│   ├── CloudWatch Logs: vpce-logs (10.2.30.16/28) - READ-ONLY
│   ├── X-Ray: vpce-xray (10.2.30.32/28) - READ-ONLY
│   ├── SNS: vpce-sns (10.2.30.48/28) - Publish for incidents
│   ├── SQS: vpce-sqs (10.2.30.64/28) - Async task queue
│   ├── Secrets Manager: vpce-secrets (10.2.30.80/28) - Cross-account role credentials
│   └── S3: Gateway endpoint - Config/backup buckets
│
└── Production Systems (tag: Environment=Production)
    ├── EC2 instances with CloudWatch agent
    ├── Microservices (service-a, service-b, service-c, service-d)
    └── RDS database (all services depend on it)
```

### Security Groups

**`incident-detector-lambda-sg`**:
```
Ingress:
  - None (Lambda only calls out)

Egress:
  - Destination: 10.2.20.0/24 (VPC Endpoint ENIs)
    Protocol: HTTPS (443)
    Description: "Read CloudWatch, X-Ray, SNS"
  - Destination: 10.2.10.0/24 (Step Functions)
    Protocol: HTTPS (443)
    Description: "Invoke Step Functions"
  - Destination: ai-services via TGW (10.1.0.0/16)
    Protocol: HTTPS (443)
    Description: "Call AgentCore Gateway API"
  - Destination: 0.0.0.0/0
    Protocol: HTTPS (443)
    Description: "Internet (AWS API calls)"
```

**`stepfunctions-sg`**:
```
Ingress:
  - Source: incident-detector-lambda-sg
    Protocol: HTTPS (443)
    Description: "Lambda invokes Step Functions"
  - Source: n8n-approval-sg
    Protocol: HTTPS (443)
    Description: "n8n sends approval callback"

Egress:
  - Destination: 10.2.20.0/24 (VPC Endpoints)
    Protocol: HTTPS (443)
    Description: "Update incident state in SNS"
  - Destination: ai-services via TGW (10.1.0.0/16)
    Protocol: HTTPS (443)
    Description: "Call ExecuteContainment MCP tool"
  - Destination: production-systems-sg
    Protocol: Varies (443 for API, 3306 for RDS)
    Description: "Execute rollback actions"
  - Destination: 0.0.0.0/0
    Protocol: HTTPS (443)
    Description: "Internet (AWS API calls)"
```

**`n8n-approval-sg`**:
```
Ingress:
  - Source: 10.2.10.0/24 (incident-detector Lambda, Step Functions)
    Protocol: HTTPS (443)
    Description: "Step Functions invokes n8n workflow"
  - Source: Internet (VPN/Bastion)
    Protocol: HTTPS (443)
    Description: "On-call engineer UI access"

Egress:
  - Destination: 10.2.10.0/24 (Step Functions)
    Protocol: HTTPS (443)
    Description: "Send approval decision back"
  - Destination: VPC Endpoint (SNS)
    Protocol: HTTPS (443)
    Description: "Notify on-call team"
  - Destination: 0.0.0.0/0
    Protocol: HTTPS (443)
    Description: "Internet (Slack, PagerDuty, email)"
```

**`cloudwatch-vpcendpoint-sg`**:
```
Ingress:
  - Source: incident-detector-lambda-sg, stepfunctions-sg
    Protocol: HTTPS (443)
    Description: "Read CloudWatch metrics/logs"

Egress:
  - None (VPC Endpoint has no outbound)
```

---

## 5. Security & Logging VPC (10.3.0.0/16)

```
Security & Logging VPC (10.3.0.0/16)
├── CloudTrail bucket
│   └─ All organization trails deliver here
├── CloudWatch Logs (aggregation)
│   └─ Subscription filters from all accounts
├── GuardDuty findings
├── SecurityHub
└── Immutable audit bucket (versioning + MFA delete)
    └─ All incident decisions logged here
```

---

## 6. Cross-Account IAM Access (Incident Response Path)

### Scenario: prod-operations → ai-services → MCP tools → prod-operations

```
1. incident-detector Lambda in prod-operations
   └─ Role: incident-detector-role
   └─ Trust: prod-operations account only
   └─ Permissions:
      - cloudwatch:GetMetricStatistics (read-only)
      - xray:GetTraceSummary (read-only)
      - lambda:InvokeFunction (invoke orchestrator)

2. incident-detector calls AgentCore Gateway API (ai-services)
   └─ Endpoint: https://agentcore.ai-services.internal/incidents
   └─ Auth: AWS SigV4 signature
   └─ Header: Authorization: AWS4-HMAC-SHA256 ...
   └─ Header: x-caller-user: operator:john@company.com

3. API Gateway receives request
   └─ Route: POST /incidents → Lambda Authorizer
   └─ Authorizer verifies SigV4 (caller is prod-operations account)
   └─ Authorizer returns IAM policy:
      {
        "principalId": "arn:aws:iam::PROD_ACCOUNT:role/incident-detector-role",
        "policyDocument": {
          "Version": "2012-10-17",
          "Statement": [
            {
              "Action": "execute-api:Invoke",
              "Effect": "Allow",
              "Resource": "arn:aws:execute-api:us-east-1:AI_ACCOUNT:agentcore/*"
            }
          ]
        },
        "context": {
          "caller": "operator:john@company.com",
          "incident_id": "incident-2026-09-21-001",
          "incident_severity": "CRITICAL"
        }
      }

4. LangGraph Agent (ECS Fargate, ai-services)
   └─ Receives request with context
   └─ Agent needs to call MCP tools in prod-operations account
   └─ Agent assumes cross-account role:
      arn:aws:iam::PROD_ACCOUNT:role/agentcore-observability-reader
   
   └─ Trust policy on agentcore-observability-reader:
      {
        "Effect": "Allow",
        "Principal": {
          "AWS": "arn:aws:iam::AI_ACCOUNT:role/langraph-agent-role"
        },
        "Action": "sts:AssumeRole",
        "Condition": {
          "StringEquals": {
            "sts:ExternalId": "agentcore-prod-observability"
          }
        }
      }

5. OBO Token Flow (On-Behalf-Of)
   └─ incident-detector Lambda in prod-operations
   └─ Carries: x-caller-user: operator:john@company.com
   └─ agentcore Gateway extracts caller from SigV4 + x-caller-user header
   └─ Passes to LangGraph Agent as context
   └─ Agent includes caller in OBO token when assuming cross-account role:
      {
        "on_behalf_of": "operator:john@company.com",
        "source_account": "PROD_ACCOUNT",
        "source_role": "incident-detector-role",
        "timestamp": "2026-09-21T14:22:00Z"
      }
   └─ CloudTrail logs show: "AssumeRole by LangGraph as john@company.com"

6. Permissions on agentcore-observability-reader role:
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Action": [
           "cloudwatch:GetMetricStatistics",
           "cloudwatch:DescribeAlarms",
           "cloudwatch:ListMetrics"
         ],
         "Resource": "*"
       },
       {
         "Effect": "Allow",
         "Action": [
           "xray:GetTraceSummary",
           "xray:GetServiceGraph",
           "xray:GetInsightSummaries"
         ],
         "Resource": "*"
       },
       {
         "Effect": "Allow",
         "Action": [
           "s3:GetObject"
         ],
         "Resource": "arn:aws:s3:::change-log-bucket/*",
         "Condition": {
           "StringLike": {
             "s3:prefix": "deploy-2026-09-21-*"
           }
         }
       }
     ]
   }
```

---

## 7. Network Latency Analysis

### Path 1: Incident Trigger → AgentCore Gateway

```
prod-operations (10.2.10.x)
  └─ incident-detector Lambda
  └─ Calls API Gateway in ai-services (10.1.10.x)
  └─ Route: Security Group allows 10.2.0.0/16 → 10.1.10.0/24 on 443
  └─ Network path: Lambda → TGW → ai-services VPC → ALB → API Gateway
  └─ Latency: ~50-100ms (cross-account, same region, TGW hop)
```

### Path 2: Agent Calls MCP Tools in Prod

```
ai-services (10.1.12.x, ECS Fargate Agent)
  └─ Calls CloudWatch Metrics API (10.2.30.x, VPC Endpoint)
  └─ Route: Security Group allows 10.1.12.0/24 → 10.2.30.0/28 on 443
  └─ Network path: Agent → TGW → prod-operations VPC → VPC Endpoint ENI
  └─ Latency: ~30-50ms (TGW route lookup + VPC Endpoint)
```

### Path 3: Step Functions Executes Containment

```
prod-operations (10.2.10.x, Step Functions)
  └─ Calls MCP tool ExecuteContainment in ai-services (10.1.10.x)
  └─ Route: TGW → API Gateway → Lambda
  └─ Latency: ~50-100ms
```

**Total E2E Latency** (Change detected → Agent correlates → Proposal returned):
```
1. Incident trigger Lambda: 100ms
2. TGW hop (prod → ai): 50ms
3. API Gateway + Authorizer: 100ms
4. Agent MCP calls (parallel):
   - CloudWatch: 50ms
   - X-Ray: 50ms
   - Runbook KB: 2000ms (inference)
   - Service Topology: 50ms
5. Agent correlation (inference): 3000ms
6. Response serialization: 50ms
7. TGW hop (ai → prod): 50ms
────────────────────────────
Total: ~5-6 seconds (agent's heavy lifting is inference, not network)
```

---

## 8. High Availability & Failover

### Multi-AZ Deployment

**AI Services Account**:
- LangGraph agents in 3 AZs (auto-scale)
- API Gateway cross-AZ by default
- Bedrock KB with cross-region standby

**Prod Operations Account**:
- incident-detector Lambda in 3 AZs
- CloudWatch Endpoints in 3 AZs
- X-Ray in 3 AZs
- n8n ECS Fargate in 3 AZs (for approval)

### Failure Scenarios

| Scenario | Blast Radius | Mitigation |
|----------|--------------|-----------|
| AI Services VPC down | Incidents cannot be triaged (manual fallback) | Alert on-call immediately, escalate |
| Prod Operations down | Observability access lost (production unmonitored!) | Regional failover to backup prod-ops account |
| CloudWatch Endpoint down | Only 1 AZ affected (others still work) | Auto-failover to another endpoint |
| Agent ECS task dies | CloudWatch auto-restart (3-5 sec) | Incident triage delayed by 5 seconds |

---

## 9. Security Posture Summary

| Control | Implementation |
|---------|-----------------|
| **Least Privilege** | Agent can read metrics but not modify infrastructure |
| **Network Isolation** | VPC endpoints restrict to prod-operations account only |
| **Cross-Account** | OBO tokens show on-call identity in all CloudTrail events |
| **Encryption in Transit** | All VPC Endpoint calls use HTTPS (TLS 1.2+) |
| **Audit Trail** | All MCP tool calls logged to CloudTrail with caller identity |
| **Approval Gate** | Step Functions holds incident until on-call approves |
| **Network Egress** | prod-operations has no internet egress (safe) |

