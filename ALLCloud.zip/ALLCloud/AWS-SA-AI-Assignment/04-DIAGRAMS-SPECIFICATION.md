# Diagrams Specification for Ops Change Impact Helper

## Overview
6 draw.io diagrams needed to communicate the architecture, data flows, and incident response design.

---

## Diagram 1: Multi-Account Topology

**Purpose**: Show how accounts are organized and connected via Transit Gateway

**Scope**: Organization level, AWS accounts, VPCs, TGW

**Elements**:
- AWS Organization box (top)
- 5 AWS Accounts:
  1. `shared-network` (hub) - center
  2. `ai-services` (spoke) - upper right
  3. `prod-operations` (spoke) - lower right
  4. `security-logging` (spoke) - lower left
  5. `shared-services` (spoke - optional) - upper left

**Connections**:
- Transit Gateway (center) connecting all spokes
- VPC CIDR labels: 10.0.0.0/16, 10.1.0.0/16, 10.2.0.0/16, 10.3.0.0/16, 10.4.0.0/16
- Colored lines:
  - Green: Data flow (incident triage)
  - Orange: Cross-account IAM assumes
  - Red: VPC Endpoint access (restricted)

**Key Labels**:
- `ai-services`: "AgentCore Gateway, LangGraph, Bedrock KB"
- `prod-operations`: "CloudWatch, X-Ray, n8n approval, Production systems"
- `security-logging`: "CloudTrail, Centralized logs"
- `shared-network`: "TGW, NAT Gateways"

**Layout**: Hub-spoke pattern (TGW centered, spokes radiating)

---

## Diagram 2: Network Topology & VPC Design

**Purpose**: Show subnets, security groups, and VPC Endpoints in each spoke VPC

**Scope**: Prod-Operations and AI-Services VPCs (most complex ones)

**AI-Services VPC (10.1.0.0/16)**:
- 3 AZs (us-east-1a, b, c)
- App subnets (10.1.10.x, 10.1.11.x, 10.1.12.x): Contains API Gateway, Lambda Authorizer, ECS Fargate agents
- Data subnets (10.1.20.x, 10.1.21.x, 10.1.22.x): Contains Bedrock KB, OpenSearch
- VPC Endpoints:
  - Bedrock (Interface)
  - Secrets Manager (Interface)
  - CloudWatch Logs (Interface)
  - S3 (Gateway)

**Prod-Operations VPC (10.2.0.0/16)**:
- 3 AZs (us-east-1a, b, c)
- App subnets (10.2.10.x, 10.2.11.x, 10.2.12.x): Contains incident-detector Lambda, Step Functions, n8n
- Data subnets (10.2.20.x, 10.2.21.x, 10.2.22.x): CloudWatch/X-Ray endpoints
- VPC Endpoints:
  - CloudWatch (Interface) - READ-ONLY
  - X-Ray (Interface) - READ-ONLY
  - SNS (Interface) - For incident notifications
  - Secrets Manager (Interface)
  - S3 (Gateway)
- Production systems tagged `Environment=Production`

**Security Groups** (shown as boxes around resources):
- `agentcore-gateway-sg` (ai-services)
- `langraph-agent-sg` (ai-services)
- `incident-detector-lambda-sg` (prod-operations)
- `stepfunctions-sg` (prod-operations)
- `n8n-approval-sg` (prod-operations)

**Connections**:
- Arrows showing allowed traffic:
  - prod-operations λ → ai-services API Gateway (HTTPS 443)
  - ai-services Agent → prod-operations VPC Endpoints (HTTPS 443)
  - prod-operations Step Functions → prod-operations VPC Endpoints (HTTPS 443)

---

## Diagram 3: Incident Triage Flow (Sequence Diagram)

**Purpose**: Visualize the step-by-step incident response automation

**Actors** (columns):
1. Change System (CodePipeline)
2. EventBridge (prod-operations)
3. incident-detector Lambda (prod-operations)
4. AgentCore Gateway (ai-services)
5. LangGraph Agent (ai-services)
6. MCP Tools (ai-services + prod-operations)
7. n8n Approval (prod-operations)
8. Step Functions Orchestration (prod-operations)

**Sequence**:
```
Change System
  └─> CodePipeline deploys to prod
      └─> CloudFormation stack update
          └─> EventBridge rule matches "StackUpdate"
              └─> incident-detector Lambda invoked
                  ├─ Extract: change_id, affected_services
                  └─> Call AgentCore Gateway API
                      └─ Header: Authorization (SigV4)
                      └─ Header: x-caller-user (operator:john@company.com)
                          └─> Lambda Authorizer validates SigV4
                              └─> Returns IAM policy + context
                                  └─> LangGraph Agent receives request
                                      ├─ Step 1: Query Bedrock KB (runbooks)
                                      │   └─ Response: Top-5 relevant procedures
                                      ├─ Step 2: Call MCP Tools (parallel):
                                      │   ├─ CloudWatch: Query metrics for service-a, b, c
                                      │   ├─ X-Ray: Get traces showing slow paths
                                      │   ├─ Change Details: What code/config changed
                                      │   └─ Service Topology: Map dependencies
                                      ├─ Step 3: Correlate data (LLM inference)
                                      │   └─ Identify: Change broke service-a, cascading to b, c, d
                                      └─> Return: Blast radius analysis + proposal
                                          └─> API Gateway returns to incident-detector
                                              └─> incident-detector passes to Step Functions
                                                  └─> Step Functions: WaitForApproval state
                                                      └─> n8n polling begins (every 5 sec)
                                                          ├─ n8n displays blast radius to on-call
                                                          ├─ On-call engineer reviews (2-5 min)
                                                          └─> Engineer approves containment action
                                                              └─> n8n invokes Step Functions callback
                                                                  └─> Step Functions: ExecuteContainment
                                                                      └─> MCP tool: Execute rollback
                                                                          └─> Incident resolved
```

**Timing Annotations**:
- Agent queries: 5-8 seconds (parallel MCP calls)
- Agent inference: 3-5 seconds (LLM correlation)
- Total agent time: 10-15 seconds
- Human approval time: 2-5 minutes
- Containment execution: 5 minutes
- **Total MTTR: ~7 minutes (vs 30+ manual)**

**Key Decision Points**:
- Agent → "Blast radius identified: 4 services, duration 7 min, revenue impact $45K"
- On-call → "Approve: Rollback config to version 1234"
- Step Functions → "Executing containment..."
- System → "Incident resolved by automatic rollback"

---

## Diagram 4: MCP Tools Architecture

**Purpose**: Show the 5-6 MCP tools, what they access, and approval gates

**Layout**: Tree structure

```
Agent (LangGraph)
├── CloudWatch Metrics Tool
│   ├─ Access: Read-only
│   ├─ IAM: cloudwatch:GetMetricStatistics
│   ├─ VPC Endpoint: 10.2.30.x/28 (prod-operations)
│   ├─ Query: Metrics for service-a, service-b (CPU, latency, errors)
│   └─ Response: Time-series data + spike detection
│
├── X-Ray Traces Tool
│   ├─ Access: Read-only
│   ├─ IAM: xray:GetTraceSummary, xray:GetServiceGraph
│   ├─ VPC Endpoint: 10.2.30.x/28 (prod-operations)
│   ├─ Query: Traces for service-b (slow endpoints, errors)
│   └─ Response: Trace summaries + root cause indicators
│
├── Runbook Retrieval Tool (Bedrock KB)
│   ├─ Access: Read-only
│   ├─ IAM: bedrock:Retrieve
│   ├─ Query: "Incident response for service-a deployment"
│   ├─ Response: Top-5 runbooks + procedures
│   └─ VPC Endpoint: 10.1.30.x/28 (ai-services)
│
├── Change Details Tool
│   ├─ Access: Read-only
│   ├─ IAM: s3:GetObject (change-log-bucket)
│   ├─ Query: "What changed in deploy-2026-09-21-001"
│   └─ Response: Code/config changes + rollback version
│
├── Service Topology Tool
│   ├─ Access: Read-only
│   ├─ IAM: Service discovery API (custom)
│   ├─ Query: "What services depend on service-a"
│   └─ Response: Dependency graph
│
└── Containment Proposal Tool ⛔ GATED
    ├─ Access: Proposal-only (NO execution)
    ├─ IAM: NO direct AWS permissions
    ├─ Proposal: "Rollback config to version 1234"
    ├─ Approval: Human (on-call) + Step Functions
    └─ Execution: Only Step Functions can execute (cross-account assume role)
```

**Approval Gate Details**:
- Agent can PROPOSE: `POST /mcp/propose-containment`
- But cannot EXECUTE: No `iam:AssumeRole` permission
- n8n reviews proposal: `approval_id = "proposal-2026-09-21-001"`
- On-call approves via n8n UI
- Step Functions executes via OBO token (on-call identity)

**Color Coding**:
- Green boxes: Read-only tools (safe)
- Yellow box: Proposal tool (gated)
- Red dashed border: "Requires human approval"

---

## Diagram 5: Authentication & Authorization Flow (OBO + SigV4)

**Purpose**: Explain how identity flows through the system

**Flow**:
```
1. prod-operations incident-detector Lambda
   ├─ Role: incident-detector-role
   ├─ Region: us-east-1
   └─ Initiates HTTP request

2. Request headers:
   ├─ Authorization: AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/...
   ├─ x-caller-user: operator:john@company.com
   ├─ x-incident-id: incident-2026-09-21-001
   └─ Content-Type: application/json

3. API Gateway (ai-services, public endpoint)
   └─> Lambda Authorizer intercepts request
       ├─ Validates SigV4 signature
       ├─ Extracts caller: "prod-operations account"
       ├─ Extracts operator: "john@company.com"
       ├─ Returns IAM policy:
       │  {
       │    "principalId": "arn:aws:iam::PROD:role/incident-detector-role",
       │    "policyDocument": { "Effect": "Allow", ... },
       │    "context": {
       │      "caller": "operator:john@company.com",
       │      "incident_id": "incident-2026-09-21-001"
       │    }
       │  }
       └─> Request allowed ✓

4. LangGraph Agent (ECS Fargate)
   ├─ Receives context:
   │  - caller_account: PROD_ACCOUNT
   │  - operator: john@company.com
   │  - incident_id: incident-2026-09-21-001
   └─> Agent assumes cross-account role:
       └─ Role: agentcore-observability-reader
       └─ Trust: "Allow LangGraph role from ai-services account"
       └─ ExternalId: "agentcore-prod-observability" ✓
       └─ OBO token: { "on_behalf_of": "john@company.com", ... }

5. MCP Tool Calls
   ├─ GET /metrics (prod-operations VPC Endpoint)
   │  ├─ Credential: Assumed role (agentcore-observability-reader)
   │  ├─ OBO: john@company.com
   │  └─ CloudTrail: "AssumeRole by LangGraph as john@company.com" ✓
   │
   └─ POST /propose-containment (same flow)
      ├─ Credential: Assumed role
      ├─ OBO: john@company.com
      └─ Response: Proposal (not executed)

6. n8n Approval Workflow
   ├─ Receives proposal from Step Functions
   └─ n8n UI shows:
      - "Incident triage completed"
      - "Blast radius: 4 services, 7 min duration"
      - "Proposed action: Rollback config"
      - "Approved by: john@company.com" (OBO token visible)
      - Button: [Approve] [Reject]

7. Step Functions Execution (on approval)
   ├─ Runs as: stepfunctions-execution-role (prod-operations)
   ├─ Assumes: agentcore-containment-executor (prod-operations)
   ├─ Executes: CloudFormation rollback
   └─ CloudTrail: "Config rolled back by step-function (authorized by john@company.com)"
```

**Key Points**:
- ✓ SigV4 proves prod-operations account made the request
- ✓ x-caller-user header carries on-call operator identity
- ✓ OBO token preserved through all service calls
- ✓ CloudTrail shows: "john@company.com initiated triage → approved containment"
- ✓ Audit trail is complete and tamper-proof

---

## Diagram 6: RAG Pipeline (Runbook Ingest & Query)

**Purpose**: Show how runbooks become queryable knowledge during incidents

**Two Phases**:

### Phase 1: Ingest (Setup)
```
Runbook Source Files (S3)
├─ incident-response/service-a-outage.md
├─ incident-response/service-b-slow-queries.md
├─ containment/emergency-rollback.md
├─ containment/traffic-shift-procedure.md
└─ root-cause/common-errors.md
    ↓
Bedrock Knowledge Base Ingest
├─ Read PDFs/markdown from S3
├─ Chunk: 1000 token windows (recursive)
├─ Embed: Bedrock Titan embeddings
├─ Index: OpenSearch cluster (ai-services VPC)
└─ Metadata:
    - runbook_id
    - severity_level
    - affected_service
    - procedures_list
    - last_updated
    ↓
Runbook KB Ready (indexed, searchable)
└─ Latency: <100ms for query
```

### Phase 2: Query (During Incident)
```
LangGraph Agent
├─ Input: change_id="deploy-2026-09-21-001", affected_services=["service-a"]
└─ Query: "Troubleshooting service-a after code deployment"
    ↓
Bedrock Retrieve API
├─ Vector search in OpenSearch
├─ Query embedding vs runbook embeddings
├─ Retrieve: Top-5 relevant chunks
└─ Return:
    {
      "results": [
        {
          "source": "incident-response/service-a-outage.md",
          "excerpt": "If service-a CPU spikes after deployment:\n1. Check recent code changes\n2. Verify database connection pool size\n3. Consider immediate rollback",
          "relevance_score": 0.94,
          "runbook_id": "rb-001"
        },
        ...
      ]
    }
    ↓
LangGraph combines results
├─ RAG context: Runbooks provide procedures
├─ MCP data: Metrics/traces provide evidence
└─ Agent infers: "Matches runbook rb-001 exactly, recommend rollback"
    ↓
Incident Response
└─ "Based on runbook incidents/service-a-outage.md, rolling back config is 94% likely to resolve"
```

**Key Metrics**:
- Ingest time: ~2-3 sec per runbook file (one-time)
- Query latency: 2-3 sec per incident (vector search + ranking)
- Recall: Top-5 runbooks include the correct procedure 98% of time
- Precision: Runbook excerpts are relevant to incident 85% of time

**Operational Concerns**:
- **Stale embeddings**: Runbooks updated → Re-embed (automated via SNS trigger)
- **Empty retrieval**: Query poorly matched → Fallback to keyword search
- **Hallucination**: Agent over-trusts RAG → Use confidence score threshold (>0.85)
- **Cost**: Titan embeddings ~$0.0001 per 1K tokens (~$10/month)

---

## Diagram Summary Table

| Diagram | Focus | Audience | Key Insight |
|---------|-------|----------|-------------|
| 1. Multi-Account | Organization structure | Architects | Hub-spoke isolation with TGW |
| 2. Network Topology | VPC design & security groups | Network team | VPC Endpoints restrict prod access |
| 3. Incident Triage | Automation flow | On-call team | Agent triage in ~15 sec, approval in 2-5 min, total MTTR <10 min |
| 4. MCP Tools | Tool design & gates | Builders | 5 read-only + 1 gated tool, proposal-only architecture |
| 5. Auth Flow | SigV4 + OBO identity | Security team | On-call identity visible in audit trail (john@company.com) |
| 6. RAG Pipeline | Runbook KB design | Knowledge team | Vector search for procedures, <3 sec query latency |

