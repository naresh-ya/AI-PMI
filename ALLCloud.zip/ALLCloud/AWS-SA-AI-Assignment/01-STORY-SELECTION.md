# Story Selection & Problem Definition

## Recommendation: STORY B - Ops Change Impact Helper

### Why Story B?
- **Complex agent reasoning** (correlate change → impact → blast radius)
- **Rich MCP tools** (observability APIs, runbook retrieval, change tracking)
- **High-value RAG application** (runbooks as knowledge source, incident history)
- **Real-world incident response scenario** (MTTR reduction = business impact)
- **Better SA judgment showcase** (multi-account observability access + security)
- **More sophisticated architecture** (5-6 MCP tools vs simpler document classification)

---

## Problem Statement

### Current State (Manual)
- **Pain**: After a bad deployment, on-call engineers manually dig through tickets, runbooks, CloudWatch metrics, X-Ray traces, and logs to determine what broke, who owns it, and how to contain it
- **Issues**:
  - High MTTR (Mean Time To Recovery): 30+ minutes to understand blast radius
  - Manual investigation prone to errors (missed services, incorrect assumptions)
  - Information scattered across multiple systems (no single source of truth)
  - Operators often request broader access than incident needs
  - Knowledge trapped in tribal memory (not documented in runbooks)
  - Alert fatigue (hard to correlate related failures)

### Target State (AI-Assisted)
- Agent receives change ID or alarm
- Queries allowed observability systems (CloudWatch, X-Ray, change logs)
- Correlates metrics + traces + runbooks to identify blast radius
- Proposes containment strategy (rollback, config revert, traffic shift)
- Drafts incident summary with likely root cause and owners
- **Human on-call engineer approves before executing any containment**
- **All decisions logged for post-incident review**

### Success Criteria
✓ Faster triage (MTTR reduced from 30 min to < 5 min)  
✓ Accurate blast radius identification (correlates changes to affected services)  
✓ Least-privilege access (agent can read metrics, but not modify)  
✓ Clear ownership handoff (proposes owner + runbook)  
✓ No automatic fixes (on-call approval required for any action)  
✓ Full audit trail (all decisions logged with timestamp + operator)  

---

## Design Constraints

### Must Use
- Multi-account AWS Organization (hub-spoke)
- Hub-spoke networking (centralized network account)
- Serverless control plane (API Gateway, Lambda, Step Functions)
- AgentCore Gateway with IAM + JWT/OBO
- At least 1 MCP server through AgentCore (**we use 5-6**)
- Agent framework: LangGraph (keep agent focused on correlation, not autonomous)
- ECS Fargate or AWS Batch (if GPU needed)
- Amazon Bedrock Knowledge Bases for RAG (**runbooks as KB**)
- n8n or Kestra for human approval workflows

### Keep Agent Thin
- Agent does NOT implement:
  - Automatic incident remediation
  - Self-healing logic
  - Production mutations without approval
- Agent ONLY:
  - Receives change ID / alarm
  - Calls allowed observability MCP tools
  - Correlates metrics + logs + runbooks
  - Returns blast radius analysis + proposals

---

## MCP Tools Overview

| Tool | Purpose | Access Level | Approval Gate |
|------|---------|--------------|---------------|
| **CloudWatch Metrics** | Query CPU, latency, errors for affected services | Read-only | None (safe) |
| **X-Ray Traces** | Find slow/error paths in distributed traces | Read-only | None (safe) |
| **Runbook Retrieval** | Query KB for incident response procedures | Read-only | None (safe) |
| **Change Details** | Look up what code/config changed | Read-only | None (safe) |
| **Service Topology** | Map dependencies (change in A affects B, C, D) | Read-only | None (safe) |
| **Containment Proposal** | Suggest rollback, config revert, traffic shift | Proposal-only (no execute) | **Human approval required** |

---

## Blast Radius Analysis

### If AI Spoke is Compromised
- ✓ Limited to reading prod observability (metrics, logs, traces)
- ✓ Cannot modify production systems (proposals only)
- ✓ Cannot access other accounts directly (cross-account role isolation)
- ✓ Runbook access is read-only (cannot modify procedures)
- ✓ Change details are immutable (audit trail)

### Containment Strategy
- AI spoke has read-only access to prod metrics
- No write permissions to observability systems
- All containment actions require human approval
- MCP tools run in separate account (prod operations account)
- Runbooks stored in secure knowledge base (security account)
- Containment execution through n8n gates (human decides)

### If Prod Operations Account is Compromised
- ✓ Agent can read metrics but not modify infrastructure
- ✓ Cannot change alarms, dashboards, or log retention
- ✓ Containment proposals still require on-call approval
- ✓ All reads logged with caller identity (OBO token)

**Blast Radius**: Read-only access to prod observability (not production systems)

